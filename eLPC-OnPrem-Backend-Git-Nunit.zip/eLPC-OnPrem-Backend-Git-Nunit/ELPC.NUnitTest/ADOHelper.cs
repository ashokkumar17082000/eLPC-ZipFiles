﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace ELPC.NUnitTest
{
    public class ADOHelper
    {
      
        static string ConnectionString;
        SqlConnection conn = new SqlConnection();
        public static Microsoft.Extensions.Configuration.IConfiguration Configuration { get; set; }

        public ADOHelper()
        {
            if (String.IsNullOrEmpty(ConnectionString))
            {
                ConnectionString = new Utility.Utility().GetConfigValue("ConnectionString");
            }
            conn = new SqlConnection(ConnectionString);

        }
        public int GetRowCount(string sqlQuery)
        {
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = sqlQuery;
            conn.Open();
            int res = (int)cmd.ExecuteScalar();
            conn.Close();
            return res;
        }

        public DataTable GetValueAsDataTable(string sqlQuery)
        {
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = sqlQuery;
            conn.Open();

            var dataReader = cmd.ExecuteReader();
            var dataTable = new DataTable();
            dataTable.Load(dataReader);
            conn.Close();
            return dataTable.Copy();
        }
    }
}
