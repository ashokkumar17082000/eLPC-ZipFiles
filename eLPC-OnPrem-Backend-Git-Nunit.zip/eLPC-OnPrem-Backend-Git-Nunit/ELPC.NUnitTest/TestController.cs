﻿using ELPC.Core;
using ELPC.DAL.Implementation;
using ELPC.NUnitTest;
using ELPC.Utility;
using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Http.Internal;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Primitives;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace Tests
{
    [TestFixture]
    public class TestController : TestBase
    {
        public static string SampleImage = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAdAAAAIZCAIAAACZMPm2AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAACVwSURBVHhe7d0JeFXlubfxtGo9x9bayXkABcQBUEFwQAGtttXjpf1OPa1TFaVOOHuoFgecQBlFj1oVwqBMWgsiOEtrracqqKj0VEBtZQijTAGEBJL4vXuvfzYraw/meSAhgft3Pdfu2u96E8q1s28XO1PRV0YPN29bYB5v3m5Sy+MmHdzh2X32Tsw/dt+n8Nx/xJX9297Yv93N/drf3q/9HZcdM6jbsYO6Hjfo18cPOvf4+3/Z8f5fnHD/WSfef8aJg3/WafCpnQefcHyvY4/v1f7429sef1ubjre26njroR1vadnxlhYdezbr2LNFu5tT0zY1B6fmJs1RN7XU/LbFMfeEOeDsoQecXZw9za8cd+jNE7Nn7xHT9wkzMjX7Vs9+I6fvP3L67qOnFz3z96+ZEb/aNMPDnBNN/ylX5Jxer1zRffLlV02+/OrJl10z+dK2g0/JN3qEANSLUru6CW7L457ddz9rcMNsweA2OzrM75q1+13zTbMpwekK3xQFt+mZjx7wX8Oyp/mVTx1683PZkylsFNloDgjzxPtNnni/6JkZBWd6PLLVc26Y/lOuzDn9plx5xaQrrpwcZfeyowb/ON/oEQJQLxRRi7oKbqq5mxHc29v3/vrgnnBPvuAedFzPA9vfEuago6OJ+puedj0zCY6Ce9BPH2zyy+HZ06L704f1nJQ9NSI78v2os2GapqfoDx8VmjHPZwpbc8772fhu/ad0zzmXTep++aRUds/7w0VH3P/jfKNHCEC9UEQt6jC4Ew9obg3u0wefGQW3+zEDvza4Xbrcny+4Bx5zS5MOtzXtcGs0B7aPpkaCw0TBbXbSgCa/Gp49B1/19OG3TErOrZPjkc10NsyB6Sl6+sNCM+KyeGRjc/4uIy/oN6V7zuk2KWpu92MfOb3N/SfnGz1CAOqFImpRh8ENk6nt63sl25pvah/ck7oMzhfc/Y+9ff9jbj9Ac1uTMB1S0zRT4XSCo+C2OLZ303NGZE/La/8Y8pqYVn1ezo7sQWGefK9Zeoqe/qDQ1IjseUXDzo9NCO5VOefWl6/6zaSrLp10VatBJxUYPUIA6oUialG3wX2u+VFRcN/fIxnWfDOg3U21D+4xeYK773F3hNnv2F7R7J+aHAlWcI+5p+m5I7PnkOvGt7rt+cQcPPiN7MiGaV4933zqg6ICk+psjcjGp9+Uq/PNJc9d3e25qw8fdFKB0SMEoF4oohZ1G9wwz+6zTwjujJpVLTAf7Hlg3/a9ahncEzsPzBncvY+/a+/j79wnmuPujPqbleBemeAeeN4T2XPI9eNb3f58Ypo/9lams5nItkjPwWFGvfetsdOLxuWfHJ39dWbaPtWt75Src87Fz13zn09dfNigLgVGjxCAeqGIWtR5cCe1PDYEN1HVwnNdhwG1DG6nLg/kDO6eHe8Os1dq7gqT7m+OBG8K7vlPZM+hN0xo3euFxBw89O3syIZpOerdaA4aNa1o7Pt55t3syKbnwtQUX7jjsIv6Trkm51z03NVHPHDqoQO7FBg9QgDqhSJqUQ/BTb2Sm0hq4bmmw8DNDO7uJ/ZOzQn37FE9e56QSXCqwlGCM8E96IIns+fQG59t3evFxLQc9k4ssursIek5ND2HjX63aOx7uWf069mRrZ6Louk75dqcc8vL1xwysHPh0SMEoF4oohZ1/5LCfgeE4P69ZlILz2879Kv1SwqDcgb3B53u/WGnPmF+FObEMOn+pqZGgjcF99ejsuew/362zR0vJqblE9OyIxt1Nszh6Skak2dG3JwzsunpGs19U67LOT1fvqLlwM6FR48QgHqhiFrUdXBTryeEqf0nzQYfdWO/9nds5ifNvtel7/e63Pf9zqn5Qed7U5NKcHWFqxOcCW6zC0dnz2E9Jra586XE5Itsq9HTomk9elpRaG7OSUZ2U2eLii+O5uAxl9732nXZc/To0w8e0Knw6BECUC8UUYu6DW70GbMwfzF8WVjP2gc335eFffekftHsFiYV32iUYFW4072bgnvR6Ow5/LfPHXHXy4mJIlvd2U2RjabNmNQUjcozeSKbmqFhLgnzzeJL7nvt+uzZfchxTQd3bjGgU4HRIwSgXiiiFnUY3OeaHRHVNppEWHPOW/u2qn1wu3QelC+4u/54wLd/POA7J6dm15P7p+ak/vEERxVWcE8a0LzrmOw5/KZJR979SmISF7OZyB5RPUeOmbrDk1OLck6is9WRjU23MInURhOCu9ejHVsMOLHA6BECUC8UUYs6DG68trUM7oC2N9Q+uB073pkvuHt1uvvfTxkUZpfUDPz2j6MZ8J10hZXgk/tHwW3+Hw83v3hs9rS6edKR97ySGEU23dlYZFOdPSo9bcdO/cGod4qezJ63C0S2en4T5t7XbkjMb567OAQ3TPMBJxYYPUIA6oUialFXwZ14QDNHcNM/SyEV3B4d+n5tcAv88Jr9OvX61k8G7xzNqff/W3riCd4lnWBd4f5XcYtLxmVP699NPqr3q4nJdDYe2aizYdql56gx7xQ98XZyRv61QGRTM+TSaNqMuSIR3D2HdoyC22zAiQVGjxCAeqGIWtRVcBO1DZNoa/Y8ccgvMsENsznBbdax5w4/e3DHMD99cKefPhDmWz8JM1gVrk6wgnvRmBbdnsqe1j2fP6rPa4nJjmzU2aM177RPT9HIt5JTfHeOyMY6m57LwuxcfNm9r90Yn6i2YZoOPLFZ/xPyjR4hAPVCEbUwBxcAECiiFgQXADwU0ZpmzpzZo0ePcKv7NRFcAPBQRGNCZ7t37961a9dwm7O5BBcAPBTRapnaRnI2l+ACgIcimhavbY8ePaKD7OYSXADwUERr1ra4uDishNvobqK5BBcAPBTR0tJEbSPx5mqJ4AKAjyJaWhqFNV7bSKa5uk9wAcBHEU0HN7u2kai5ukNwAcBHEU1XVUe5xM8SXADwUEQtCC4AeCiiFgQXADwUUQuCCwAeiqgFwQUAD0XUguACgIciarHVgvvOO++MGzdWdwCgsVFELeo1uGPHjl2+bNmKFSu+iFmyZMn06dOHDx+uTQDQGLxvV0/BnTVr1rp160JbzzrrrNatW82dO3fZsmXLly8PK+eff/4FF1ywcOHCTz75pO999+kNAKBhU0Qt6iO4w4qLQ1hPO+20adOmaSnL+vXru3XrtmjRokceeURLANCAKaIWdR7cp8aNW7BgQcuWB1dVVWkpvz/+8Zk333yzX79+ul/Hyt/7sOSHLed/u8n8XQ/84j/O1Woey7teU/Ldg8Lmku81Xz3wa/6rsPTUs8O21OY9Dt04t0SrALYhiqhF3QZ33Lhx8+bNa9asWTh+5pln5syZM3PmzOhUQlnZ+pEjR4aDNWvWzJgxo2fPntF6bcwr2r3AlPyghfbFlL3xVmJbNPP/bX/tiFnQpG1iWzQL9m6tHTHzdtgrsS0anU7Ltx4UOAWgQVFELeo2uJ9+9q+2bduGgyeffHJx2vz586NTCWVlZeFsdG07aNCgf3w889xzz4lOfa14pHLPDntpa9rq+x9LbojPN/bQvrSFzTskN8Sn5ubk2ZpTWVqavS1ayShwCkCDooha1GFwJ06cOH7i5JVp0SfHFi1aVCC4F1100cKFC6+99tpw94/jxw8YNDg69bXikco3lctXRJurysoTp3LMjntHm4PkqZrz5eg/al/Y+Y09EmezRzuzVjIKnALQoCiiFnUY3D+/+XabNm3CwdKlS0tKSvr06RN6Onfu3OhsQgju2LFjhw4dOm/evMrKyoqKigmTX7rwwgt1uqDckaqqiq+vuLxHtDzvm3vG18unvh92frWxouRHLePrlYuXhs2ldw+ML0bvIaj8Ynm4++WoZ3Q/XDU/PDy+M0x4n+E9b5j5aWalan1ZtDmzEiZayShwCkCDooha1FVww+XtI8VPvvvuu2vWrJn+4Ywjjzxy5IgRCxYsWLFiRViJrF27Vkdr1oQWv/rqq8uWLZv9yafnnXdeeA/vvffez3/+8+i9FZYvUl+cfUlmfcVlN0aLmZUwVWu/jBYjC/ZpnTm1uN0pYWXZr36TWVl66tnRNqn5OcB4x0t2PUirkcrKku8113FaZmcYLVUrcApAg6KIWtRVcF944YVLr0y9ODBh/Pg/v/G/06e/H4IbrnO7det2cS6fffbZK6+8EvZPnTbt+htScXziiZHX3XRL6n19nXyRqrGe7mP51Ok1FrMkzpa9/r/xlZLv1ixpTHyblvKLb15118D4xE9pN4AGSRG1qKvgzp49+yennREOPv/88wmTXgoHIbgfz5qd7zXc8rKy8ROeDQfhovjpZyeHg7vvvrtHr1p9H0Q8Ujln2TmXRTvX/M/QzOKq2+6NFuMyZ8Nkr8QnugTOiJ/SUn7xzQVGuwE0SIqoRV0Fd9GiRV1OTv+rfNmy3v0GhYMQ3Dffmlrgk2YjnhgVDl54/vnHR6Z+xsKYMaN/d2etviA30anEzN9pn6+q//W/8tqemfW1xaO1GpM5GyZaqVr7ZXwxMRXz9DW28cVopYD45gKj3QAaJEXUoq6CO2PGjDPOTL0CG8rbe+BD4SAE99nJLxcI7gMP/T4chOD2feDRcPDoo4/ecV+tvlAh0amcUzE39eeuvPaWzErpPan/DCRkzobRUlrJHofGT8Un2pC9UkB8c4HRbgANkiJqUVfBff311y+59IpwMGXKlJ73DJg5c2YI7pCRYz/99NMRw4dnz5Ivlt/Zp3/YX1FRcXWP28LBHXfc0XdwKsFfK1+kFjZrnzi1/oXXMncXtjgm2haXORtGSzVt+PD/5u1Y41sbNn7yz7AeX4l2FlBgc4FTABoURdSiroI7fPiwR4pHhcvboUOH3NJ74CmnnBKC22fQIwMfHvo/j4/8/bBRj48Y8/jIsY+NGPNI8ZMPPDZiwENDrr/59vCGd/V/qFWrVuGgrHzD0e3bp9/Z1ygQqexT2SsZy3656WsS5n+7iVZDZGd8rKNq8e+GWDtyXFjJ3A2z4obUXyRu1W01XoyOb9ZStQKnADQoiqhFXQU3GD/x+S5dOoeDiROf+23PO4YOGXLTnf3yvaRQVVV1+bU93njjjTv6PjhixLCwUjzqqbZtj4rOFpYvUhULFmWfiq+kFisro/Uvx02Ir5e/9W60Pn+nvcPd9S9Oie5G4l+0u+7ZF8PKqlv6ZFbCrB02JtoZ/mKZxcyflVlJLdZU4BSABkURtajD4I4ZM+bu3veGkg4aNHDQw0NuvvnmO/o+UOA13F+df2HfBx9r2bJluPvwQw/9YULqaxVqIx6pAhNtLp9W4yvDck/1N+xGtc3MosNPXHH17+IrYarKcnw7Q77ZOH9BYmf0thkFTgFoUBRRizoM7mefffbSK6917do1HPfu3fuRoU8O/v2wAsF98NFhp59xZmVl5YYNG1545U9HpX8IQ23EI5Vv4p8iS7y2mz1V5RuinfN3aZI4lZj5/17jh90kziam5Iep/5YktkUrGQVOAWhQFFGLOgxu0K9fv7femfbww6mvUrjpppuKnxw7a9as6FRC6Oxhhx1WUVERjkNwb/xvfSdubcQjlXNWXnertlZbfOzPEnsyU7VmrTalLWrdObEhM/N3bapNMYk9mSnZ41DtILjANkERtajb4AahuR98+NGQIUPC8ZVXXB4tZrvsskvDbfryduPf3no7WqylBXu3yjmL2/9k3YQXtCmXBfsdkfmJM+Fade3Ip3Qiy6I2neftuOnlhZIftcxcBWcr7TN4/s77btr8w4N1olr8/6SWqhU4BaBBUUQt6jy4wa233vr5558/8MAD0QVsPhMnTlyxYsUbb7zxz3+mvtAKABoyRdSiPoIbXH755e++++706dNHjx61cOHC+G9/WL169YD+/Tdu3DhnzpzWrVuHi1ydAIAGTBG1qKfgRs4551cvvPBCuNqdO3fuypUrw/VsSUlJ6OxHH33Utm3bPn16ax8ANHiKqEW9Bjeydu3as8/+xZlnnnnqqaecfvppt92W/IwWADR8iqjFVgguAGwDFFELggsAHoqoBcF1GjYs9f3HGWVlZccdd9xf/vIX3S8oetvy8vKnn346Whk/fnynTp2iYwCNgiJqsS0Et6hoS/4tdtttNx0VlPhDw93KysrVq1frfkHR265Zs6Z79+7hYNGiRbvvzrc5AI2MImpBcJNq+d6yg6ujWkhsnjlzZvQN0AAaEUXUYkumamvJ9GvXtKZNm+68887hbrgN/9IPB59++unRRx8dDsKF5EEHHdSkSZOOHTuGu6+//vrJJ5+8//77f//73z/rrLPCyr777hveW7gNxxs3bgzH7dq123HHHefMmRNWPvnkk7DSvn37b3zjG/FotmrVKnqr8vLy9957Lxx36NAh3G7YkPputLD5O9/5ziGHHBIuaaP90duuWrXqwAMPDAd77rnnLrvs0qJFi6qqqnCqTZs24W9RXFyc3guggVJELbap4O6www7RQbQSenraaaeFgxNOOGHx4sVTp07t3Dn14yKDnXbaKdxGwY1WMu8kc7DHHnssXZr6ZelBtBhuM98sl9kWyX7zIDoOwc2kNhKtZ4KbucI9/fTTJ0yYkNqR9f4BNDSKqMW28KzOtClcqEYHmZXoILq9/vrrw0HGv/71rxDce+65J70x+SbRQVz8VBA/DjJ3s/eE4EZ3M6L17OCG9bjUVgANlSJqsS08qzNtyg5u+Ld5aWlpu3btwvHo0aOvvTb1m9uD6BuICwc3XC/HvwU5iEcwfhxkv3kQHdc+uLvttlt5eXlqB4AGTxG1qFGNRirTuOzgvvPOO+F4yZIl0d1wPHXq1A8++CDakC+4n3322bp168LOnXfeORzfcMMN+++f+rm33bt3b9++fbg0btasWWZ/JHP3mGOOOeOMM8KeHXfccdq0aWGl9sFds2ZNODVr1qyJEydGL0MDaLAUUYsa1WikPvzww+jg73//e3SQWQnix8GECRPGjk39GvYgBG7x4sXRcWZbWVlZ3759o+OgX79+s2fP1p2vvlq+fPmgQamfZZ54t/G7oe+9evXKXB0ndgbRSkVFxccfp35bWvgT582blz6T8vjjj7/88su6A6ChUkQttoXgAkD9U0QtCC4AeCiiFgQXADwUUQuCCwAeiqgFwQUAD0XUguACgIciakFwAcBDEbUguADgoYhaEFwA8FBELQguAHgoohYEFwA8FFELggsAHoqoBcEFAA9F1ILgAoCHImpBcAHAQxG1ILgA4KGIWhBcAPBQRC0ILgB4KKIWBBcAPBRRC4ILAB6KqAXBBQAPRdSC4AKAhyJqQXABwEMRtSC4AOChiFoQXADwUEQtCC4AeCiiFgQXADwUUQuCCwAeiqgFwQUAD0XUguACgIciakFwAcBDEbUguADgoYhaEFwA8FBELQguAHgoohYEFwA8FFELggsAHoqoBcEFAA9F1ILgAoCHImpBcAHAQxG1ILgA4KGIWhBcAPBQRC0ILgB4KKIWBBcAPBRRC4ILAB6KqAXBBQAPRdSC4AKAhyJqQXABwEMRtSC4AOChiFoQXADwUEQtCC4AeCiiFgQXADwUUQuCCwAeiqgFwQUAD0XUguACgIciakFwAcBDEbUguADgoYhaEFwA8FBELQguAHgoohYEFwA8FFELggsAHoqoBcEFAA9F1ILgAoCHImpBcAHAQxG1ILgA4KGIWhBcAPBQRC0ILgB4KKIWBBcAPBRRC4ILAB6KqAXBBQAPRdSC4AKAhyJqQXABwEMRtSC4AOChiFoQXADwUEQtCC4AeCiiFgQXADwUUQuCCwAeiqgFwQUAD0XUguACgIciakFwAcBDEbUguADgoYhaEFwA8FBELQguAHgoohYEFwA8FFELggsAHoqoBcEFAA9F1ILgAoCHImpBcAHAQxG1ILgA4KGIWhBcAPBQRC0ILgB4KKIWBBcAPBRRC4ILAB6KqAXBBQAPRdSC4AKAhyJqQXABwEMRtSC4AOChiFoQXADwUEQtCC4AeCiiFgQXADwUUQuCCwAeiqgFwQUAD0XUguACgIciakFwAcBDEbUguADgoYhaEFwA8FBELQguAHgoohYEFwA8FFELggsAHoqoBcEFAA9F1ILgAoCHImpBcAHAQxG1ILgA4KGIWhBcAPBQRC0ILgB4KKIWBBcAPBRRC4ILAB6KqAXBBQAPRdSC4AKAhyJqQXABwEMRtSC4AOChiFoQXADwUEQtCC4AeCiiFgQXADwUUQuCCwAeiqgFwQUAD0XUguACgIciakFwAcBDEbUguADgoYhaEFwA8FBELQguAHgoohYEFwA8FFELggsAHoqoBcEFAA9F1ILgAoCHImpBcAHAQxG1ILgA4KGIWhBcAPBQRC0ILgB4KKIWBBcAPBRRC4ILAB6KqAXBBQAPRdSC4AKAhyJqQXABwEMRtSC4AOChiFoQXADwUEQtCC4AeCiiFgQXADwUUQuCCwAeiqgFwQUAD0XUguACgIciakFwAcBDEbUguADgoYhaEFwA8FBELQguAHgoohYEFwA8FFELggsAHoqoBcEFAA9F1ILgAoCHImpBcAHAQxG1ILgA4KGIWhBcAPBQRC0ILgB4KKIWBBcAPBRRC4ILAB6KqAXBBQAPRdSC4AKAhyJqQXABwEMRtSC4AOChiFoQXADwUEQtCC4AeCiiFgQXADwUUQuCCwAeiqgFwQUAD0XUguACgIciakFwAcBDEbUguADgoYhaEFwA8FBELQguAHgoohYEFwA8FFELggsAHoqoBcEFAA9F1ILgAoCHImpBcAHAQxG1ILgA4KGIWhBcAPBQRC0ILgB4KKIWBBcAPBRRC4ILAB6KqAXBBQAPRdSC4AKAhyJqQXABwEMRtSC4AOChiFoQXADwUEQtCC4AeCiiFgQXADwUUQuCCwAeiqgFwQUAD0XUguACgIciakFwAcBDEbUguADgoYhaEFwA8FBELQguAHgoohYEFwA8FFELggsAHoqoBcEFAA9F1ILgAoCHImpBcAHAQxG1ILgwq6z66h9L1r36aWk0MxZ9GVaA7Y0iakFwYRPaGiI76oNl8Xlx9qoKoovtjCJqQXBh8/HSdYnaRvPBwi+1A9g+KKIWBBc2k2euTKQ2mkkzV2oHsH1QRC0ILmye/ceKRGqjeXrGcu0Atg+KqAXBhU2+K9yJH3OFi+2LImpBcLHJkjUbZi5dH82i1Ru0WlO+13A/WrROO7K8+fnqB/+2OJqXZq+srOLTa9gWKKIWBBcpGyqr5q0qf3f+2mmxmbuyvLwiGceKyqpwKlHbt+et2ZC1MwhtfWrG8qsnzYlP/78uDH+cdgCNliJqQXCREq5n46nNTM7r3FDLcD078ePUawvhNhxvzBPQP/+zNFHbaJ7jM2xo/BRRC4KLlBmL1iVSG82C0twvLNTSXX8qSaQ2mgf/tlg7gEZLEbUguEh5rySZ2mg2M7g3PD83kdpoCC62AYqoBcFFyqyl6xOpjWbeqnLtcHnorcWJ1EZDcLENUEQtCC5S8r2Gu7B0s4Kb7zXcF2ev0g6g0VJELQguUqqqvpqZdZE764v1FZv3JVyVVVXhYjZR2yHTluo00JgpohYEFxLSGq5z/7Fk3fsLvvx4yfoFpRu2yNfLhuaG69z+f114w/Nz7/pTSbi2LdtYqXNAY6aIWhBcAPBQRC0ILgB4KKIWBBcAPBRRC4ILAB6KqAXBBQAPRdSC4AKAhyJqQXC3UxWVVcvXbVy4esP8VeXhNhzX2y8lW7J2w91/WvD/Rn3a8bGPw204Dis6BzQeiqgFwd0ehbYuKE2lNj4LSsvz/dCvLSi09fSRs0Nq4/PT4bND9LUDaCQUUQuCuz0K17OJ2kZTWlahHXUmXM8mahvNba+WaAfQSCiiFgR3e7R4TfLyNppV6+s8uL/+wz8TqY3m6klztANoJBRRC4K7PdqKwb2A4GJboYhaENzt0bIvt9pLCre9WpJIbTQ9X56vHUAjoYhaENzt0cbKqpLSZG3DSs7fS7ZlLVy94ZRhsxK1DStzVpZpB9BIKKIWBHc7FZobrnOjr1UIt+G4HmobCc0N17PR1yqE29++NI/aojFSRC0ILgB4KKIWBBcAPBRRC4ILAB6KqAXBBQAPRdSC4AKAhyJqQXABwEMRtSC42KS8orK8oqp6ttiveqyK/TbK+DHQqCmiFgQXUraxcnVZRXzWb6ys3Ow+hsJm0zmgMVNELQguUsL1bKK20ZRv3q80V19z0Q6g0VJELQguUtZtyB3cso2bVUbFNRftABotRdSC4CJlTVZqoynfvO/3VVxz0Q6g0VJELQguUr7ckExtNFzhAvkoohYEFynlWZ8xi6Ysz2u4lVVVlVXhNpq89VRcs+g00JgpohYEF/Jl1su46zbk/h1nYXVjZVV8KizN1QmgkVNELQguNgnXuSG7a8oqwm2+V2/D9WyittHU8jpXS0Djp4haEFzYVGSlNpp6+y3rQAOhiFoQXNjkC24Y7QC2D4qoBcGFDVe4QEQRtSC4sMn/Gq42ANsJRdSC4MIs+yK3wGfMgG2VImpBcOERrmej7IZbrm2xfVJELQguAHgoohYEFwA8FFELggsAHoqoBcEFAA9F1ILgAoCHImpBcAHAQxG1ILgA4KGIWhBcAPBQRC0ILgB4KKIWBBcAPBRRC4ILAB6KqAXBBQAPRdSC4AKAhyJqQXABwEMRtSC4AOChiFoQXADwUEQtCC4AeCiiFgQXADwUUQuCCwAeiqgFwQUAD0XUguACgIciakFwAcBDEbUguADgoYhaEFwA8FBELQguAHgoohYEFwA8FFELggsAHoqoBcEFAA9F1ILgAoCHImpBcAHAQxG1ILgA4KGIWhBcAPBQRC0ILgB4KKIWBBcAPBRRC4ILAB6KqAXBBQAPRdSC4AKAhyJqQXABwEMRtSC4AOChiFoQXADwUEQtCC4AeCiiFgQXADwUUQuCCwAeiqgFwQUAD0XUguACgIciakFwAcBDEbUguADgoYhaEFwA8FBELQguAHgoohYEFwA8FFELggsAHoqoBcEFAA9F1ILgAoCHImpBcAHAQxG1ILgA4KGIWhBcAPBQRC0ILgB4KKIWBBcAPBRRC4ILAB6KqAXBBQAPRdSC4AKAhyJqQXABwEMRtSC4AOChiFoQXADwUEQtCC4AeCiiFgQXADwUUQuCCwAeiqgFwQUAD0XUguACgIciakFwAcBDEbUguADgoYhaEFwA8FBELQguAHgoohYEFwA8FFELggsAHoqoBcEFAA9F1ILgAoCHImpBcAHAQxG1ILgA4KGIWhBcAPBQRC0ILgB4KKIWBBcAPBRRC4ILAB6KqAXBBQAPRdSC4AKAhyJqQXABwEMRtSC4AOChiFoQXADwUEQtCC4AeCiiFgQXADwUUQuCCwAeiqgFwQUAD0XUguACgIciakFwAcBDEbUguADgoYhaEFwA8FBELQguAHgoohYEFwA8FFELggsAHoqoBcEFAA9F1ILgAoCHImpBcAHAQxG1ILgA4KGIWhBcAPBQRC0ILgB4KKIWBBcAPBRRC4ILAB6KqAXBBQAPRdSC4AKAhyJqQXABwEMRtSC4AOChiFoQXADwUEQtCC4AeCiiFgQXADwUUQuCCwAeiqgFwQUAD0XUguACgIciakFwAcBDEbUguADgoYhaEFwA8FBELQguAHgoohYEFwA8FFELggsAHoqoBcEFAA9F1ILgAoCHImpBcAHAQxG1ILgA4KGIWhBcAPBQRC0ILgB4KKIWBBcAPErtCC4AeCiiFgQXADwUUQuCCwAeiqgFwQUAD0XUguACgIciakFwAcBDEbUguADgoYhaEFwA8FBELQguAHgoohYEFwA8FFELggsAHoqoBcEFAA9F1ILgAoCHImpBcAHAQxG1ILgA4KGIWhBcAPBQRC0ILgB4KKIWBBcAPBRRC4ILAB6KqAXBBQAPRdSC4AKAhyJqQXABwEMRtSC4AOChiFoQXADwUEQtCC4AeCiiFgQXADwUUQuCCwAeiqgFwQUAD0XUguACgIciakFwAcBDEbUguADgoYhaEFwA8FBELQguAHgoohYEFwA8FFELggsAHoqoBcEFAA9F1ILgAoCHImpBcAHAQxG1ILgA4KGIWhBcAPBQREtLi4uLdZRL/CzBBQAPRbS0tGvXrvmaG9bDWd0huADgo4img5uzuVFtA90nuADgo4iWlnbv3j0Ka7y5mdqGs1oiuADgo4iWls6cOTPR3Hhtw9loW0BwAcBDEU2LN7dHjx7RQaK2AcEFAA9FtFq8uUF2bQOCCwAeimhMprk5axsQXADwUERrCp3t0aNHztoGBBcAPBRRC4ILAB6KqAXBBQAPRdSC4AKAhyJqQXABwEMRtSC4AOChiFoQXADwUEQtCC4AeCiiFgQXADwUUQuCCwAeiqgFwQUAD0XUguACgIciakFwAcBDEbUguADgoYhaEFwA8FBELQguAHgoohYEFwA8FFGLIv1vXXofgIueQthWEFyg4dJTCNsKggs0XHoKYVuxucHN/JbKoLi4WKs16WMHgJGeQthCQqOiWOX7rbp1bbOCW5vaBvrYAWCkpxC2nK3bXH9wa1nbQB87AIz0FMIWtRWb6wxu7Wsb6GMHgJGeQtjStlZzPcE11TbQxw4AIz2FUAe2SnM9we3Ro0f0fzQcaKkgfewAMNJTCHXDmrLNxxUu0HDpKYQ60GiucANTc/WxA8BITyFsaVultoEzuEHtm6uPHQBGegphi9patQ38wQ1q2Vx97AAw0lMIW85WrG2wWcENatNcfewAMNJTCFvI1q1tsLnBrQ197AAw0lMI2wqCCzRcegphW0FwgYZLTyFsG0pL/z8+5G3ngiaM+wAAAABJRU5ErkJggg==";
        public List<HintImage> ListHintimages = new List<HintImage>() { new HintImage() { FileContent = SampleImage, ImageTitle = "Sample.jpg" } };
        public string sWebRootFolder = Directory.GetCurrentDirectory() + "\\TestData";

        [SetUp]
        public void Setup()
        {

        }
    }

    public class AuthControllerTest : TestController
    {
        [Test]
        public void GetUserList()
        {
            var controller = base.GetActiveDirectoryController();
            var result = controller.GetUserListByName("Venkatesh Govindaraj");
            Assert.GreaterOrEqual(result.Count, 0);
        }
    }

    public class AssessorTemplateControllerTest : TestController
    {
        [Test]
        public void GetAssessorTemplates()
        {
            var controller = base.GetAssessorTemplateController();
            int ActualCount = controller.GetAssessorTemplates().Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetAssessorTemplateCount();
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void ValidateAssessorTemplateName()
        {
            var controller = base.GetAssessorTemplateController();
            int ActualCount = controller.ValidateAssessorTemplateName("VAssessorTest").Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetAssessorTemplateNameCountByName("VAssessorTest");
            Assert.AreEqual(ExpectedCount, ActualCount);
        }


        [Test]
        public void GetAssessorTemplatesHistory()
        {
            var controller = base.GetAssessorTemplateController();
            int ActualCount = controller.GetAssessorTemplatesHistory(10).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetAssessorTemplateHistoryCountByAssessorTemplateID(10);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void GetAssessors()
        {
            var controller = base.GetAssessorTemplateController();
            int ActualCount = controller.GetAssessors().Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetAssessorCount();
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void GetAssessorsByTemplateID()
        {
            var controller = base.GetAssessorTemplateController();
            int ActualCount = controller.GetAssessorsByTemplateID(10).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetAssessorCountByAssessorTemplateID(10);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void AssessorsRestoreByTemplateHistoryID()
        {
            int historyId = 1070;
            var controller = base.GetAssessorTemplateController();
            bool status = controller.AssessorsRestoreByTemplateHistoryID(historyId).Result.ResultCode == 0;
            Assert.AreEqual(true, status);
        }

        [Test]
        public void InsertAssessorTemplate()
        {
            var controller = base.GetAssessorTemplateController();
            AssessorTemplate assessorTemplate = new AssessorTemplate
            {
                AssessorTemplateID = 23,
                AssessorTemplateName = "VAssessorTest",
                IsLocked = false,
                ModifiedBy_NTID = "JNK1COB",
                CreatedBy_UserID = "JNK1COB",
                IsTargetFrequencyDefined = true,
                IsDeleted = false,
                Assessors = new List<Assessor>
                {
                    new Assessor
                    {
                        AssessorID = 1064,
                        AssessorName = "A1",
                        TargetFrequencyValue = "2",
                        AssessorTemplateID = 23,
                        TargetFrequencyTypeID="2"
                    },
                     new Assessor
                    {
                        AssessorID = 1065,
                        AssessorName = "A2",
                        TargetFrequencyValue = "1",
                        AssessorTemplateID = 23,
                        TargetFrequencyTypeID="1"
                    }
                }
            };

            var result = controller.InsertAssessorTemplate(assessorTemplate);
            int count = result.Result.Count;
            Assert.AreEqual(0, count);

        }

        [Test]
        public void InsertAssessorTemplate_Catch()
        {
            var controller = base.GetAssessorTemplateController();
            AssessorTemplate assessorTemplate = null;

            bool status = controller.InsertAssessorTemplate(assessorTemplate).Exception.InnerExceptions.Count > 0;
            Assert.AreEqual(true, status);
        }

        // TODO: ImportExcel
        [Test]
        public async Task ImportExcel()
        {
            string sFileName = @"AssessorTemplate.xlsx";

            var memory = new MemoryStream();
            using (var stream = new FileStream(Path.Combine(sWebRootFolder, sFileName), FileMode.Open))
            {
                await stream.CopyToAsync(memory);
            }
            memory.Position = 0;
            FormFile file = new FormFile(memory, 0, memory.Length, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", sFileName);

            var httpContext = new DefaultHttpContext();
            httpContext.Request.Headers.Add("Content-Type", "multipart/form-data");
            httpContext.Request.Form = new FormCollection(new Dictionary<string, StringValues>(), new FormFileCollection { file });

            var _HttpContext = new Mock<HttpContext>();
            _HttpContext.Setup(_ => _.Request).Returns(httpContext.Request);

            HttpContextAccessor = new HttpContextAccessor();
            HttpContextAccessor.HttpContext = _HttpContext.Object;



            var controller = base.GetAssessorTemplateController(HttpContextAccessor);
            var result = await controller.ImportExcel();
            if (result != null)
            {
                Assert.AreEqual(true, result != null);
            }
            else
            {
                Assert.AreEqual(true, result == null);
            }
        }

        [Test]
        public void AssessorExportExcel()
        {
            var controller = base.GetAssessorTemplateController();
            var result = controller.ExportExcel();
            Assert.AreEqual("AssessorTemplate.xlsx", ((Microsoft.AspNetCore.Mvc.FileResult)result).FileDownloadName.ToString());
        }


        [Test]
        public void DeleteAssessorTemplate()
        {
            AssessorTemplate assessorTemplate = new AssessorTemplate();
            var controller = base.GetAssessorTemplateController();
            bool status = controller.DeleteAssessorTemplate(assessorTemplate).Result.ResultCode == 0;
            Assert.AreEqual(true, status);
        }

        [Test]
        public void DeleteAssessorTemplate_Else()
        {
            AssessorTemplate assessorTemplate = new AssessorTemplate()
            {
                AssessorTemplateID = 10,
                ModifiedBy_NTID = "JNK1COB",
                ModifiedAt = System.DateTime.Now,

            };
            var controller = base.GetAssessorTemplateController();
            bool status = controller.DeleteAssessorTemplate(assessorTemplate).Result.ResultCode == 1;
            Assert.AreEqual(true, status);
        }

        [Test]
        public void DeleteAssessorTemplate_Catch()
        {
            AssessorTemplate assessorTemplate = null;
            var controller = base.GetAssessorTemplateController();
            bool status = controller.DeleteAssessorTemplate(assessorTemplate).Exception.InnerExceptions.Count > 0;
            Assert.AreEqual(true, status);
        }

        // TODO: InsertAssessorTemplateProxy


        [Test]
        public void AssessorProxiesByAssessorTemplateID()
        {
            var controller = base.GetAssessorTemplateController();
            int ActualCount = controller.AssessorProxiesByAssessorTemplateID(10).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetAssessorProxiesCountByAssessorTemplateID(10);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void FetchAssessorTemplateByTemplateID()
        {
            var controller = base.GetAssessorTemplateController();
            int ActualCount = controller.FetchAssessorTemplateByTemplateID(10).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetAssessorTemplateCountByAssessorTemplateID(10);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

    }

    public class AuditControllerTest : TestController
    {
        [Test]
        public async Task GetAudits()
        {
            var controller = base.GetAuditController();
            var result = await controller.GetAuditsByNTID("JNK1COB","04","2024");
            int ActualCount = result.Count;
            Assert.GreaterOrEqual(ActualCount, 0);
        }

        [Test]
        public async Task InsertAuditAsync()
        {
            Audit audit = new Audit()
            {
                AuditID = 23,
                ModifiedBy_NTID = "JNK1COB",
                StartDate = System.DateTime.Now,
                EndDate = System.DateTime.Now.AddDays(14)
            };

            var controller = base.GetAuditController();
            var result = await controller.InsertAudit(audit);
            Assert.IsNull(result);
        }

        [Test]
        public void InsertAudit_Catch()
        {
            Audit audit = null;

            var controller = base.GetAuditController();
            bool status = controller.InsertAudit(audit).Exception.InnerExceptions.Count > 0;
            Assert.AreEqual(true, status);
        }

        [Test]
        public void InsertAuditQuestion()
        {
            AuditQuestion auditQuestion = new AuditQuestion()
            {
                AuditID = 23,
                ModifiedBy_NTID = "JNK1COB",
            };

            var controller = base.GetAuditController();
            var result = controller.AddEditAuditQuestion(auditQuestion);
            Assert.AreEqual(0, result.Result.ResultCode);
        }

        [Test]
        public void DeleteAudit_Catch()
        {
            Audit audit = null;
            var controller = base.GetAuditController();
            bool status = controller.DeleteAudit(audit).Result.ResultCode == 9;
            Assert.AreEqual(true, status);
        }

        [Test]
        public void AuditByAuditID()
        {
            int auditID = 1020;

            var controller = base.GetAuditController();
            int ActualCount = (controller.AuditByAuditID(auditID).Result) != null ? 1 : 0;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.AuditByAuditID(auditID);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void AuditQuestionsByAuditID()
        {
            int auditID = 1020;

            var controller = base.GetAuditController();
            int ActualCount = controller.AuditQuestionsByAuditID(auditID).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.AuditQuestionsByAuditID(auditID);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void PendingAuditsByAuditID()
        {
            int auditID = 1020;

            var controller = base.GetAuditController();
            int ActualCount = controller.PendingAuditsByAuditID(auditID).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.PendingAuditsByAuditID(auditID);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void AuditQuestionsByAuditAndAssessorID()
        {
            int auditID = 1020;
            string NTID = "JNK1COB";
            var controller = base.GetAuditController();
            int ActualCount = controller.AuditQuestionsByAuditAndAssessorID(auditID, NTID).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.AuditQuestionsByAuditAndAssessorID(auditID, NTID);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void AuditQuestionsByCurrentAssessorAndTemplateID()
        {
            int auditID = 1020;
            string NTID = "JNK1COB";
            int templateID = 1;

            var controller = base.GetAuditController();
            int ActualCount = controller.AuditQuestionsByCurrentAssessorAndTemplateID(auditID, NTID).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.AuditQuestionsByCurrentAssessorAndTemplateID(auditID, templateID);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void AuditQuestionsByAuditAndTemplateID()
        {
            int auditID = 1020;
            int templateID = 1;

            var controller = base.GetAuditController();
            int ActualCount = controller.AuditQuestionsByAuditAndTemplateID(auditID, templateID,1).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.AuditQuestionsByAuditAndTemplateID(auditID, templateID);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void AuditAssessorsByAuditID()
        {
            int auditID = 1020;

            var controller = base.GetAuditController();
            int ActualCount = controller.AuditAssessorsByAuditID(auditID).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.AuditAssessorsByAuditID(auditID);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void UpdateAuditQuestion()
        {
            AuditQuestion auditQuestion = new AuditQuestion()
            {
                ID = 1241,
                Answer = "Updated from Unit test",
                AuditID = 1019
            };

            var controller = base.GetAuditController();
            bool status = controller.UpdateAuditQuestion(auditQuestion).Result.ResultCode == 0;
            Assert.AreEqual(true, status);
        }

        // TODO: InsertAuditDetail
        [Test]
        public void InsertAuditDetail()
        {
            AuditDetail auditDetail = new AuditDetail();
            var controller = base.GetAuditController();
            var result = controller.InsertAuditDetail(auditDetail);
            if (result != null)
            {
                Assert.AreEqual(true, result != null);
            }
            else
            {
                Assert.AreEqual(true, result == null);
            }
        }

        [Test]
        public void AuditAssessorsByAuditAndTemplateID()
        {
            int auditID = 1020;
            int templateID = 1;

            var controller = base.GetAuditController();
            int ActualCount = controller.AuditAssessorsByAuditAndTemplateID(auditID, templateID).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.AuditAssessorsByAuditAndTemplateID(auditID, templateID);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void OtherAuditAssessorsByAuditAndTemplateID()
        {
            int auditID = 1020;
            int templateID = 1;

            var controller = base.GetAuditController();
            int ActualCount = controller.OtherAuditAssessorsByAuditAndTemplateID(auditID, templateID).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.OtherAuditAssessorsByAuditAndTemplateID(auditID, templateID);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void ValuestreamCountByTagID()
        {
            var controller = base.GetAuditController();
            int ActualCount = controller.ValueStreamsByTagID(10).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetValuestreamCountByTagID(10);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void ValidateAssessorByAuditAndNTID()
        {
            int auditID = 1020;
            string NTID = "JNK1COB";

            var controller = base.GetAuditController();
            int ActualCount = (controller.ValidateAssessorByAuditAndNTID(auditID, NTID).Result) != null ? 1 : 0;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.ValidateAssessorByAuditAndNTID(auditID, NTID);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void RequiredAttendeesByAuditID()
        {
            int auditID = 1020;

            var controller = base.GetAuditController();
            int ActualCount = controller.RequiredAttendeesByAuditID(auditID).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.RequiredAttendeesByAuditID(auditID);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void OptionalAttendeesByAuditID()
        {
            int auditID = 1020;

            var controller = base.GetAuditController();
            int ActualCount = controller.OptionalAttendeesByAuditID(auditID).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.OptionalAttendeesByAuditID(auditID);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void EmailToAttendees()
        {
            List<User> Users = new List<User>()
            {
                new User { EmailAddress = "external.govindaraj.venkatesh@in.bosch.com"}
            };

            Audit audit = new Audit()
            {
                OptionalAttendees = Users,
                RequiredAttendees = Users,
                EmailAddress = "external.govindaraj.venkatesh@in.bosch.com",
                TagName = "Email from Unit test case",
                StartDate = System.DateTime.Now,
                EndDate = System.DateTime.Now.AddDays(14),
                ValueStreamName = "Test",
            };

            var controller = base.GetAuditController();
            bool status = controller.EmailToAttendees(audit).Result.ResultCode == 0;
            Assert.AreEqual(true, status);
        }
    }

    public class CommonControllerTest : TestController
    {

        [Test]
        public void GetChoiceDisplayTypes()
        {
            var controller = base.GetCommonController();
            int ActualCount = controller.GetChoiceDisplayTypes().Result.Count;
            int ExpectedCount = new ELPC.NUnitTest.TestScripts().GetChoiceDisplayTypesCount();
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void GetAnswerTypes()
        {
            var controller = base.GetCommonController();
            int ActualCount = controller.GetAnswerTypes().Result.Count;
            int ExpectedCount = new ELPC.NUnitTest.TestScripts().GetAnswerTypesCount();
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void GetUsers()
        {
            var controller = base.GetCommonController();
            int ActualCount = controller.GetUsers().Result.Count;
            int ExpectedCount = new ELPC.NUnitTest.TestScripts().GetUsers();
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        // TODO: ActiveDirectoryListByName

        [Test]
        public void ActiveDirectoryListByName()
        {
            var user = new User()
            {
                UserName = "EXTERNAL Venkatesh Govindaraj (Nous, RBEI/BSA4)",
                FirstName = "Govindaraj",
                LastName = "Venkatesh",
                EmailAddress = "external.Govindaraj.Venkatesh@in.bosch.com",
                NTID = "EGV1COB",
                Role_roleID = 1
            };
            var controller = base.GetActiveDirectoryController();
            int ActualCount = controller.ActiveDirectoryListByName(user).Count;
            Assert.AreNotEqual(-1, ActualCount);
        }


        [Test]
        public void InsertUser()
        {
            var user = new User()
            {
                UserName = "EXTERNAL Venkatesh Govindaraj (Nous, RBEI/BSA4)",
                FirstName = "Govindaraj",
                LastName = "Venkatesh",
                EmailAddress = "external.Govindaraj.Venkatesh@in.bosch.com",
                NTID = "EGV1COB",
                Role_roleID = 1
            };

            var controller = base.GetCommonController();
            var result = controller.InsertUser(user).Result.ResultCode == 0;
            Assert.AreEqual(true, result);
        }


        [Test]
        public void GetUserByNTID()
        {
            string NTID = "JNK1COB";
            var controller = base.GetActiveDirectoryController();
            int ActualCount = controller.GetUserListByNTID(NTID).Count;
            int ExpectedCount = new ELPC.NUnitTest.TestScripts().GetUserByNTID(NTID);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void InsertIntoDeviation()
        {
            Deviation deviation = new Deviation()
            {
                ValueStreamID = 115,
                DeviationDescription = "Test description from unit test",
                ResponsibleEmployee = "EGV1COB",
                CreatedBy_NTID = "JNK1COB",
                ModifiedBy_NTID = "JNK1COB",
                HintImages = ListHintimages,
            };
            var controller = base.GetCommonController();
            bool status = controller.InsertIntoDeviation(deviation).Result.ResultCode == 0;
            Assert.AreEqual(true, status);
        }

        [Test]
        public void InsertIntoAuditDeviation()
        {
            Deviation deviation = new Deviation()
            {
                ValueStreamID = 115,
                DeviationDescription = "Test description from unit test",
                ResponsibleEmployee = "EGV1COB",
                CreatedBy_NTID = "JNK1COB",
                ModifiedBy_NTID = "JNK1COB",
                HintImages = ListHintimages,
            };
            var controller = base.GetCommonController();
            bool status = controller.InsertIntoAuditDeviation(deviation).Result.ResultCode == 0;
            Assert.AreEqual(true, status);
        }

        [Test]
        public void SendDeviationEmail()
        {
            Deviation deviation = new Deviation()
            {
                ValueStreamID = 115,
                DeviationDescription = "Test description from unit test",
                ResponsibleEmployee = "EGV1COB",
                CreatedBy_NTID = "JNK1COB",
                ModifiedBy_NTID = "JNK1COB",
                ManagerEmailAddress = "external.govindaraj.venkatesh@in.bosch.com",
                UserEmailAddress = "external.govindaraj.venkatesh@in.bosch.com",
                ValueStreamName = "",
                HintImages = ListHintimages,
            };
            var controller = base.GetCommonController();
            bool status = controller.SendDeviationEmail(deviation).Result.ResultCode == 0;
            Assert.AreEqual(true, status);
        }

        [Test]
        public void SendDeviationEmailByID()
        {
            Deviation deviation = new Deviation()
            {
                ValueStreamID = 115,
                DeviationDescription = "Test description from unit test",
                ResponsibleEmployee = "Venkatesh Govindaraj",
                CreatedBy_NTID = "JNK1COB",
                ModifiedBy_NTID = "JNK1COB",
                ManagerEmailAddress = "external.govindaraj.venkatesh@in.bosch.com",
                UserEmailAddress = "external.govindaraj.venkatesh@in.bosch.com",
                ResponsibleEmployeeEmailAddress = "external.govindaraj.venkatesh@in.bosch.com",
                ValueStreamName = "",
                QuestionID = 43,
                HintImages = ListHintimages,
            };
            var controller = base.GetCommonController();
            bool status = controller.SendDeviationEmail(deviation).Result.ResultCode == 0;
            Assert.AreEqual(true, status);
        }
    }

    public class CustomModeControllerTest : TestController
    {

        [Test]
        public void GetCustomModeByNTID()
        {
            string NTID = "JNK1COB";
            int customModeID = 20;

            var controller = base.GetCustomModeController();
            var data = controller.GetCustomModeByNTID(NTID).Result;
            int ActualCount = data[0].questions.Count + data[0].tags.Count;
            int ExpectedCount = new ELPC.NUnitTest.TestScripts().GetCustomModeByNTIDCount(customModeID);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }


        [Test]
        public void InsertCustomMode()
        {
            List<Tag> tags = new List<Tag>();
            var tag = new Tag()
            {
                AnonymizeUserDataSettingID = 1,
                //Assigned_AssessorTemplateID = 1,
                //Assigned_ValueStreamCategoryID = 0,
                //Assigned_ValueStreamTemplateID = 1,
                CreatedBy = "FIXED-TERM Janarthanan Krishnasamy (RBEI/BSA4)",
                CreatedBy_NTID = "JNK1COB",
                CustomQuestionTagsID = 0,
                ModifiedBy = "D_Manish Karn (RBEI/BSA4)",
                ModifiedBy_NTID = "MIK1COB",
                TagID = 1,
                TagModeTagsID = 0,
                TagName = "Tag1",
                TagTypeID = 1,
                Tag_PriorityID = 4,
            };
            tags.Add(tag);

            CustomMode customMode = new CustomMode()
            {
                CustomModeID = 0,
                CreatedBy_UserID = 1,
                CreatedBy_NTID = "JNK1COB",
                tags = tags
            };

            var controller = base.GetCustomModeController();
            bool status = controller.InsertCustomMode(customMode).Result.ResultCode == 0;
            Assert.AreEqual(true, status);
        }

        [Test]
        public void InsertCustomMode_Catch()
        {
            CustomMode customMode = null;

            var controller = base.GetCustomModeController();
            bool status = controller.InsertCustomMode(customMode).Result.ResultCode == 9;
            Assert.AreEqual(true, status);
        }


        [Test]
        public void GetCustomTags()
        {
            var controller = base.GetCustomModeController();
            int ActualCount = controller.GetCustomTags().Result.Count;
            int ExpectedCount = new ELPC.NUnitTest.TestScripts().GetCustomModeCount();
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void RemoveFromCustomModeList()
        {
            var tag = new Tag()
            {
                //Assigned_AssessorTemplateID = 1,
                //Assigned_ValueStreamCategoryID = 0,
                //Assigned_ValueStreamTemplateID = 1,
                CreatedBy = "FIXED-TERM Janarthanan Krishnasamy (RBEI/BSA4)",
                CreatedBy_NTID = "JNK1COB",
                CustomQuestionTagsID = 1159,
                ModifiedBy = "D_Manish Karn (RBEI/BSA4)",
                ModifiedBy_NTID = "MIK1COB",
                TagID = 21,
                TagModeTagsID = 0,
                TagName = "Tag26.03.1",
                TagTypeID = 1,
                Tag_PriorityID = 4,
                TagDisplayName = "#Tag26.03.1",
            };

            CustomMode customMode = new CustomMode()
            {
                CustomModeID = 0,
                CreatedBy_NTID = "JNK1COB",
                TagID = 0,
                tag = tag
            };

            var controller = base.GetCustomModeController();
            bool status = controller.RemoveFromCustomModeList(customMode).Result.ResultCode == 0;
            Assert.AreEqual(true, status);
        }
    }

    public class DataPoolControllerTest : TestController
    {
        [Test]
        public void GetDataPool()
        {
            var controller = base.GetDataPoolController();
            int ActualCount = controller.GetDataPool().Result.Count;
            int ExpectedCount = new ELPC.NUnitTest.TestScripts().GetDataPoolCount();
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void GetProcessConfirmationByID()
        {
            int dataPoolId = 1291;

            var controller = base.GetDataPoolController();
            int ActualCount = controller.GetProcessConfirmationByID(dataPoolId).Result.Count;
            int ExpectedCount = new ELPC.NUnitTest.TestScripts().GetProcessConfirmationByIDCount(dataPoolId);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void HintImagesByDeviationID()
        {
            int deviationId = 17;

            var controller = base.GetDataPoolController();
            int ActualCount = controller.HintImagesByDeviationID(deviationId).Result.Count;
            int ExpectedCount = new ELPC.NUnitTest.TestScripts().GetHintImagesByDeviationIDCount(deviationId);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void UpdateDataPool()
        {
            ProcessConfirmation processConfirmation = new ProcessConfirmation()
            {
                Answer = "Test1",
                AnswerType_AnswerTypeID = 1,
                AnsweredBy_NTID = "JNK1COB",
                AssessorID = 0,
                ChoiceID = 0,
                CreatedAt = new System.DateTime(),
                DataPoolID = 1288,
                Delimiter = "_",
                ModifiedAt = System.DateTime.Now,
                ModifiedBy_NTID = "JNK1COB",
                QuestionID = 43,
                QuestionText = "Q4.7.5",
                TagID = 0,
                UserName = "FIXED-TERM Janarthanan Krishnasamy (RBEI/BSA4)",
                ValueStreamCategoryName = "Department",
                ValueStreamData = "BS",
                ValueStreamID = 146,
                ValueStreamName = "P1_BS",
                ValueStreamTemplateName = "VS4.24",
                isDeviation = false,
                HintImages = ListHintimages,
            };

            var controller = base.GetDataPoolController();
            bool status = controller.UpdateDataPool(processConfirmation).Result.ResultCode == 0;
            Assert.AreEqual(true, status);
        }

        [Test]
        public void DeleteDataPool()
        {
            ProcessConfirmation processConfirmation = new ProcessConfirmation()
            {
                DataPoolID = 1101,
                ModifiedBy_NTID = "JNK1COB",
                ModifiedAt = System.DateTime.Now
            };
            var controller = base.GetDataPoolController();
            bool status = controller.DeleteDataPool(processConfirmation).Result.ResultCode == 0;
            Assert.AreEqual(true, status);
        }

        [Test]
        public void DeleteDataPool_Catch()
        {
            ProcessConfirmation processConfirmation = null;
            var controller = base.GetDataPoolController();
            bool status = controller.DeleteDataPool(processConfirmation).Result.ResultCode == 9;
            Assert.AreEqual(true, status);
        }

        [Test]
        public void GetDataPoolHistory()
        {
            int dataPoolId = 17;

            var controller = base.GetDataPoolController();
            int ActualCount = controller.GetDataPoolHistory(dataPoolId).Result.Count;
            int ExpectedCount = new ELPC.NUnitTest.TestScripts().GetDataPoolHistoryCount(dataPoolId);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void DataPoolRestoreByTemplateHistoryID()
        {
            int historyId = 1386;
            var controller = base.GetDataPoolController();
            bool status = controller.DataPoolRestoreByTemplateHistoryID(historyId).Result.ResultCode == 0;
            Assert.AreEqual(true, status);
        }

    }


    public class DownloadFileControllerTest : TestController
    {
        [Test]
        public async Task Upload()
        {
            var stream = new System.IO.MemoryStream(System.Text.Encoding.UTF8.GetBytes("This is a dummy file"));
            //Microsoft.AspNetCore.Http.Internal.FormFile file = new Microsoft.AspNetCore.Http.Internal.FormFile(stream, 0, stream.Length, "profile_pic", "test.txt");
            var file = new FormFile(stream, 0, stream.Length, "profile_pic", "test.txt");

            var controller = base.GetDownloadFileController();
            var result = await controller.Upload(file);
            if (result != null)
            {
                Assert.AreEqual(true, result != null);
            }
            else
            {
                Assert.AreEqual(true, result == null);
            }
        }


        [Test]
        public async Task DownloadFile()
        {
            var controller = base.GetDownloadFileController();
            var result = await controller.DownloadFile("02_07_2020 02_23_05_PM_Test Attachment.txt");
            if (result != null)
            {
                Assert.AreEqual(true, result != null);
            }
            else
            {
                Assert.AreEqual(true, result == null);
            }
        }

        [Test]
        public async Task DownloadFile_Fail()
        {
            var controller = base.GetDownloadFileController();
            var result = await controller.DownloadFile("02_07_2020 02_23_05_PM_Test Attachment.txt1");
            Assert.AreEqual(true, result == null);
        }

        [Test]
        public async Task DownloadQuestionAttachment()
        {
            var controller = base.GetDownloadFileController();
            var result = await controller.DownloadQuestionAttachment("02_07_2020 02_23_05_PM_Test Attachment.txt");
            if (result != null)
            {
                Assert.AreEqual(true, result != null);
            }
            else
            {
                Assert.AreEqual(true, result == null);
            }
        }

        [Test]
        public async Task DownloadQuestionAttachment_Fail()
        {
            var controller = base.GetDownloadFileController();
            var result = await controller.DownloadQuestionAttachment("02_07_2020 02_23_05_PM_Test Attachment.txt1");
            Assert.AreEqual(true, result == null);
        }


        [Test]
        public async Task UploadFile()
        {
            var stream = new System.IO.MemoryStream(System.Text.Encoding.UTF8.GetBytes("This is a dummy file"));
            //Microsoft.AspNetCore.Http.Internal.FormFile file = new Microsoft.AspNetCore.Http.Internal.FormFile(stream, 0, stream.Length, "profile_pic", "test.txt");
            var file = new FormFile(stream, 0, stream.Length, "profile_pic", "test.txt");
            var httpContext = new DefaultHttpContext();
            httpContext.Request.Headers.Add("Content-Type", "multipart/form-data");
            httpContext.Request.Form = new FormCollection(new Dictionary<string, StringValues>(), new FormFileCollection { file });

            var _HttpContext = new Mock<HttpContext>();
            _HttpContext.Setup(_ => _.Request).Returns(httpContext.Request);

            HttpContextAccessor = new HttpContextAccessor();
            HttpContextAccessor.HttpContext = _HttpContext.Object;

            var controllerContext = new ControllerContext()
            {
                HttpContext = httpContext,
            };

            var tmpHostingEnvironment = new Mock<Microsoft.AspNetCore.Hosting.IHostingEnvironment>();
            tmpHostingEnvironment.Setup(_ => _.WebRootPath).Returns(new Utility().GetConfigValue("PathName"));
            Microsoft.AspNetCore.Hosting.IHostingEnvironment HostingEnvironment = tmpHostingEnvironment.Object;
            IConfiguration _iconfiguration = null;

            var controller = new ELPC.API.Controllers.DownloadFileController(HostingEnvironment, _iconfiguration)
            {
                ControllerContext = controllerContext,
            };

            var result = await controller.UploadFile();
            if (result != null)
            {
                Assert.AreEqual(true, result != null);
            }
            else
            {
                Assert.AreEqual(true, result == null);
            }
        }

    }



    public class ProcessConfirmationControllerTest : TestController
    {

        [Test]
        public void GetProcessConfirmation_ShuffleCount()
        {
            ProcessConfirmation processConfirmation = new ProcessConfirmation();
            processConfirmation.ModeType = "shuffle";
            processConfirmation.ValueStreamID = 0;
            processConfirmation.AssessorID = 0;
            processConfirmation.TagID = 0;

            var controller = base.GetProcessConfirmationController();
            int ActualCount = controller.GetProcessConfirmation(processConfirmation).Result.Count;
            int ExpectedCount = new ELPC.NUnitTest.TestScripts().GetProcessConfirmationShuffleCount();
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void GetProcessConfirmation_CustomCount()
        {
            ProcessConfirmation processConfirmation = new ProcessConfirmation();
            processConfirmation.ModeType = "custom";
            processConfirmation.ValueStreamID = 0;
            processConfirmation.AssessorID = 0;
            processConfirmation.TagID = 0;

            var controller = base.GetProcessConfirmationController();
            int ActualCount = controller.GetProcessConfirmation(processConfirmation).Result.Count;
            int ExpectedCount = new ELPC.NUnitTest.TestScripts().GetProcessConfirmationCustomCount();
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void ProcessConfirmationTagCount()
        {
            ProcessConfirmation processConfirmation = new ProcessConfirmation();
            processConfirmation.ModeType = "tag";
            processConfirmation.ValueStreamID = 0;
            processConfirmation.AssessorID = 0;
            processConfirmation.TagID = 0;

            var controller = base.GetProcessConfirmationController();
            int ActualCount = controller.GetProcessConfirmation(processConfirmation).Result.Count;
            int ExpectedCount = new ELPC.NUnitTest.TestScripts().GetProcessConfirmationTagCount();
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void InsertProcessConfirmation()
        {
            ProcessConfirmation processConfirmation = new ProcessConfirmation()
            {
                ModeTypeID = 1,
                ValueStreamID = 146,
                AssessorID = 0,
                QuestionID = 43,
                Answer = "Unit Test Module",
                AnswerType_AnswerTypeID = 1,
                AnsweredBy_NTID = "JNK1COB",
                ChoiceID = 0,
                CreatedAt = System.DateTime.Now,
                DataPoolID = 1288,
                Delimiter = "_",
                ModifiedAt = System.DateTime.Now,
                ModifiedBy_NTID = "JNK1COB",
                QuestionText = "Q4.7.5",
                TagID = 36,
                UserName = "FIXED-TERM Janarthanan Krishnasamy (RBEI/BSA4)",
                ValueStreamCategoryName = "Department",
                ValueStreamData = "BS",
                ValueStreamName = "P1_BS",
                ValueStreamTemplateName = "VS4.24",
                isDeviation = false,
                HintImages = ListHintimages,
            };
            var controller = base.GetProcessConfirmationController();
            bool status = controller.InsertProcessConfirmation(processConfirmation).Result.ResultCode == 0;
            Assert.AreEqual(false, status);
        }

        [Test]
        public void AddToCustomMode()
        {
            ProcessConfirmation processConfirmation = new ProcessConfirmation()
            {
                QuestionID = 43,
                AnsweredBy_NTID = "JNK1COB",
            };
            var controller = base.GetProcessConfirmationController();
            bool status = controller.AddToCustomMode(processConfirmation).Result.ResultCode == 0;
            Assert.AreEqual(true, status);
        }

        [Test]
        public void DeleteFromCustomMode()
        {
            ProcessConfirmation processConfirmation = new ProcessConfirmation()
            {
                QuestionID = 45,
                AnsweredBy_NTID = "JNK1COB"
            };

            var controller = base.GetProcessConfirmationController();
            bool status = controller.DeleteFromCustomMode(processConfirmation).Result.ResultCode == 0;
            Assert.AreEqual(true, status);
        }

        [Test]
        public void DeleteFromCustomMode_Catch()
        {
            ProcessConfirmation processConfirmation = null;
            var controller = base.GetProcessConfirmationController();
            bool status = controller.DeleteFromCustomMode(processConfirmation).Exception.InnerExceptions.Count > 0;
            Assert.AreEqual(true, status);
        }

        [Test]
        public void GetValueStreamByQuestionID()
        {
            int questionID = 11;
            var controller = base.GetProcessConfirmationController();
            int ActualCount = controller.GetValueStreamByQuestionID(questionID).Result.Count;
            int ExpectedCount = new ELPC.NUnitTest.TestScripts().GetValueStreamByQuestionIDCount(questionID);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void GetAssessorsByQuestionIDCount()
        {
            int questionID = 11;
            var controller = base.GetProcessConfirmationController();
            int ActualCount = controller.GetAssessorsByQuestionID(questionID).Result.Count;
            int ExpectedCount = new ELPC.NUnitTest.TestScripts().GetAssessorsByQuestionIDCount(questionID);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

    }

    public class QuestionControllerTest : TestController
    {

        [Test]
        public void GetQuestions()
        {
            var controller = base.GetQuestionController();
            int ActualCount = controller.GetQuestions().Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetQuestionCount();
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void GetQuestionDetail()
        {
            var controller = base.GetQuestionController();
            int ActualCount = controller.GetQuestionDetail().Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetQuestionDetailCount();
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void GetQuestionDetailByID()
        {
            var controller = base.GetQuestionController();
            int ActualCount = controller.GetQuestionDetailByID(10).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetQuestionDetailCountByQuestionID(10);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void GetQuestionsHistory()
        {
            var controller = base.GetQuestionController();
            int ActualCount = controller.GetQuestionsHistory(10).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetQuestionHistoryCountByQuestionID(10);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void QuestionRestoreByHistoryID()
        {
            int historyId = 1085;
            var controller = base.GetQuestionController();
            bool status = controller.QuestionRestoreByHistoryID(historyId).Result.ResultCode == 0;
            Assert.AreEqual(true, status);
        }

        [Test]
        public void InsertQuestion()
        {
            Question question = new Question()
            {
                QuestionID = 23,
                ModifiedBy_NTID = "JNK1COB",
                HintImages = ListHintimages,
            };

            var controller = base.GetQuestionController();
            var result = controller.InsertQuestion(question);
            Assert.AreEqual(0, result.Result.ResultCode);
        }

        [Test]
        public void GetChoicesByQuestionID()
        {
            var controller = base.GetQuestionController();
            int ActualCount = controller.GetChoicesByQuestionID(10).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetChoiceCountByQuestionID(10);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void SingleLineTextByQuestionID()
        {
            //var controller = base.GetQuestionController();
            //int ActualCount = controller.SingleLineTextByQuestionID(10).Result;
            //ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            //int ExpectedCount = testScripts.GetSingleLineTextCountByQuestionID(10);
            //Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void MultipleLinesTextByQuestionID()
        {
            var controller = base.GetQuestionController();
            int ActualCount = controller.MultipleLinesTextByQuestionID(10).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetMultipleLinesTextountByQuestionID(10);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }


        [Test]
        public void CurrencySettingsByQuestionID()
        {
            int questionId = 10;
            var controller = base.GetQuestionController();
            int ActualCount = controller.CurrencySettingsByQuestionID(questionId).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetCurrencySettingsByQuestionID(questionId);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void NumberSettingsByQuestionID()
        {
            int questionId = 10;
            var controller = base.GetQuestionController();
            int ActualCount = controller.NumberSettingsByQuestionID(questionId).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetNumberSettingsByQuestionID(questionId);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }


        [Test]
        public void DateTimeSettingsByQuestionID()
        {
            int questionId = 10;
            var controller = base.GetQuestionController();
            int ActualCount = controller.DateTimeSettingsByQuestionID(questionId).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetDateTimeSettingsByQuestionID(questionId);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }


        [Test]
        public void HintImagesByQuestionID()
        {
            var controller = base.GetQuestionController();
            int ActualCount = controller.HintImagesByQuestionID(11).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetHintImageCountByQuestionID(11);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void HintHyperLinksByQuestionID()
        {
            var controller = base.GetQuestionController();
            int ActualCount = controller.HintHyperLinksByQuestionID(10).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetHintHyperlinkCountByQuestionID(10);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void RatingScaleByQuestionID()
        {
            int questionId = 10;
            var controller = base.GetQuestionController();
            int ActualCount = controller.RatingScaleByQuestionID(questionId).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetRatingScaleByQuestionID(questionId);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void ValueStreamsByQuestionID()
        {
            var controller = base.GetQuestionController();
            int ActualCount = controller.ValueStreamsByQuestionID(10).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetValuestreamCountByQuestionID(10);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void AssessorsByQuestionID()
        {
            int questionID = 11;
            var controller = base.GetQuestionController();
            int ActualCount = controller.AssessorsByQuestionID(questionID).Result.Count;
            int ExpectedCount = new ELPC.NUnitTest.TestScripts().GetAssessorsByQuestionIDCount(questionID);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }


        [Test]
        public void TagsByQuestionID()
        {
            var controller = base.GetQuestionController();
            int ActualCount = controller.TagsByQuestionID(10).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetTagCountByQuestionID(10);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }


        [Test]
        public void DeleteQuestion()
        {
            Question question = new Question();
            var controller = base.GetQuestionController();
            bool status = controller.DeleteQuestion(question).Result.ResultCode == 0;
            Assert.AreEqual(true, status);
        }

        [Test]
        public void DeleteQuestion_Catch()
        {
            Question question = null;
            var controller = base.GetQuestionController();
            bool status = controller.DeleteQuestion(question).Exception.InnerExceptions.Count > 0;
            Assert.AreEqual(true, status);
        }

        [Test]
        public void InsertQuestionProxy()
        {
            var controller = base.GetQuestionController();

            QuestionProxy questionProxy = new QuestionProxy()
            {
                QuestionID = 23,
                CreatedBy_NTID = "JNK1COB",
                ModifiedBy_NTID = "JNK1COB",
                Proxies = new List<User>()
               {
                   new User
                   {
                       UserName = "EXTERNAL Venkatesh Govindaraj (Nous, RBEI/BSA4)",
                       FirstName = "Govindaraj",
                       LastName = "Venkatesh",
                       EmailAddress="external.Govindaraj.Venkatesh@in.bosch.com",
                       NTID = "EGV1COB"

                   }

               }
            };

            var result = controller.InsertQuestionProxy(questionProxy);
            Assert.AreEqual(0, result.Result.ResultCode);
        }

        [Test]
        public void QuestionProxiesByQuestionID()
        {
            var controller = base.GetQuestionController();
            int ActualCount = controller.QuestionProxiesByQuestionID(10).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetQuestionProxiesCountByQuestionID(10);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }
    }

    public class TagControllerTest : TestController
    {

        [Test]
        public void GetTags()
        {
            //var controller = base.GetTagController();
            //int ActualCount = controller.GetTags().Result.Count;
            //ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            //int ExpectedCount = testScripts.GetTagCount();
            //Assert.AreEqual(ExpectedCount, ActualCount);
        }


        [Test]
        public void GetTagsByID()
        {
            int tagId = 10;
            var controller = base.GetTagController();
            int ActualCount = controller.GetTagsByID(tagId).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetTagCountByID(tagId);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void GetTagHistory()
        {
            var controller = base.GetTagController();
            int ActualCount = controller.GetTagHistory(10).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetTagHistoryCountByTagID(10);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void TagRestoreByTemplateHistoryID()
        {
            int historyId = 1172;
            var controller = base.GetTagController();
            bool status = controller.TagRestoreByTemplateHistoryID(historyId).Result.ResultCode == 0;
            Assert.AreEqual(true, status);
        }

        [Test]
        public void InsertTag()
        {
            Tag tag = new Tag()
            {
                TagID = 23,
                ModifiedBy_NTID = "JNK1COB",
                TagName = "Test Updated",
            };

            var controller = base.GetTagController();
            var result = controller.InsertTag(tag);
            Assert.AreEqual(0, result.Result.ResultCode);
        }

        [Test]
        public void DeleteTag()
        {
            Tag tag = new Tag();
            var controller = base.GetTagController();
            bool status = controller.DeleteTag(tag).Result.ResultCode == 0;
            Assert.AreEqual(true, status);
        }

        [Test]
        public void DeleteTagt_Catch()
        {
            Tag tag = null;
            var controller = base.GetTagController();
            bool status = controller.DeleteTag(tag).Exception.InnerExceptions.Count > 0;
            Assert.AreEqual(true, status);
        }

        [Test]
        public void GetQuestionsByTagID()
        {
            var controller = base.GetTagController();
            int ActualCount = controller.GetQuestionsByTagID(10).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetQuestionCountByTagID(10);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }


        [Test]
        public void GetTagsByTagID()
        {
            var controller = base.GetTagController();
            int ActualCount = controller.GetTagsByTagID(10).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetTagCountByTagID(10);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void GetAssessorsByTagIDs()
        {
            TagID tagIds = new TagID() { TagsIDs = "10" };

            string tagId = "10";
            var controller = base.GetTagController();
            int ActualCount = controller.GetAssessorsByTagIDs(tagIds).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetAssessorsByTagIDs(tagId);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void InsertUpdateTagProxy()
        {
            var controller = base.GetTagController();

            TagProxy tagProxy = new TagProxy()
            {
                TagID = 23,
                CreatedBy_NTID = "JNK1COB",
                ModifiedBy_NTID = "JNK1COB",
                Proxies = new List<User>()
               {
                   new User
                   {
                       UserName = "EXTERNAL Venkatesh Govindaraj (Nous, RBEI/BSA4)",
                       FirstName = "Govindaraj",
                       LastName = "Venkatesh",
                       EmailAddress="external.Govindaraj.Venkatesh@in.bosch.com",
                       NTID = "EGV1COB"

                   }

               }
            };

            var result = controller.InsertTagProxy(tagProxy);
            Assert.AreEqual(0, result.Result.ResultCode);
        }

        [Test]
        public void FetchQuestionsByAssessorsAndValuestreams()
        {
            AssessorValuestreamList assessorValuestreamList = new AssessorValuestreamList() { AssessorIDs = "1033", ValueStreamIDs = "115" };
            string assessorIDs = "1033";
            string valueStreamIDs = "115";

            var controller = base.GetTagController();
            int ActualCount = controller.FetchQuestionsByAssessorsAndValueStreams(assessorValuestreamList).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.FetchQuestionsByAssessorsAndValuestreams(assessorIDs, valueStreamIDs);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }


        [Test]
        public void FetchTagsByAssessorsAndValueStreams()
        {
            AssessorValuestreamList assessorValuestreamList = new AssessorValuestreamList() { AssessorIDs = "1033", ValueStreamIDs = "115" };
            string assessorIDs = "1033";
            string valueStreamIDs = "115";

            var controller = base.GetTagController();
            int ActualCount = controller.FetchTagsByAssessorsAndValueStreams(assessorValuestreamList).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.FetchTagsByAssessorsAndValuestreams(assessorIDs, valueStreamIDs);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void ValueStreamsByTagID()
        {
            var controller = base.GetTagController();
            int ActualCount = controller.ValueStreamsByTagID(10).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetValuestreamCountByTagID(10);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void AssessorsByTagID()
        {
            var controller = base.GetTagController();
            int ActualCount = controller.AssessorsByTagID(10).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetAssessorCountByTagID(10);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void TagProxiesByTagID()
        {
            var controller = base.GetTagController();
            int ActualCount = controller.TagProxiesByTagID(10).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetTagProxiesCountByTagID(10);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void FetchProcessConfirmationTags()
        {
            var controller = base.GetTagController();
            int ActualCount = controller.FetchProcessConfirmationTags().Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.FetchProcessConfirmationTags();
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void FetchTagDetailsByTagID()
        {
            int tagId = 10;
            var controller = base.GetTagController();
            int ActualCount = controller.FetchTagDetailsByTagID(tagId).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.FetchTagDetailsByTagID(tagId);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }
    }

    public class TagModeControllerTest : TestController
    {

        [Test]
        public void GetTagModeByNTID()
        {
            string NTID = "JNK1COB";

            var controller = base.GetTagModeController();
            int ActualCount = controller.GetTagModeByNTID(NTID).Result.Count;
            int ExpectedCount = new ELPC.NUnitTest.TestScripts().GetTagModeByNTIDCount();
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void InsertToTagMode()
        {
            List<Tag> tags = new List<Tag>();
            var tag = new Tag()
            {
                AnonymizeUserDataSettingID = 1,
                //Assigned_AssessorTemplateID = 1,
                //Assigned_ValueStreamCategoryID = 0,
                //Assigned_ValueStreamTemplateID = 1,
                CreatedBy = "FIXED-TERM Janarthanan Krishnasamy (RBEI/BSA4)",
                CreatedBy_NTID = "JNK1COB",
                CustomQuestionTagsID = 0,
                ModifiedBy = "D_Manish Karn (RBEI/BSA4)",
                ModifiedBy_NTID = "MIK1COB",
                TagID = 1,
                TagModeTagsID = 0,
                TagName = "Tag1",
                TagTypeID = 1,
                Tag_PriorityID = 4,
            };
            tags.Add(tag);

            TagMode tagMode = new TagMode()
            {
                TagModeID = 0,
                CreatedBy_UserID = 1,
                CreatedBy_NTID = "JNK1COB",
                tags = tags
            };

            var controller = base.GetTagModeController();
            bool status = controller.InsertToTagMode(tagMode).Result.ResultCode == 0;
            Assert.AreEqual(true, status);
        }

        [Test]
        public void GetTagModeTags()
        {
            var controller = base.GetTagModeController();
            int ActualCount = controller.GetTagModeTags().Result.Count;
            int ExpectedCount = new ELPC.NUnitTest.TestScripts().GetTagModeTagsCount();
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void GetTagModeTagsCalendar()
        {
            var controller = base.GetTagModeController();
            int ActualCount = controller.GetTagModeTagsCalendar().Result.Count;
            int ExpectedCount = new ELPC.NUnitTest.TestScripts().GetTagModeTagsCount();
            Assert.AreEqual(ExpectedCount, ActualCount);
        }


        [Test]
        public void DeleteTagMode_Catch()
        {
            TagMode tagMode = null;
            var controller = base.GetTagModeController();
            bool status = controller.DeleteTagMode(tagMode).Exception.InnerExceptions.Count > 0;
            Assert.AreEqual(true, status);
        }

        [Test]
        public void GetInfoQuestionsByTagID()
        {
            int tagId = 22;
            var controller = base.GetTagModeController();
            int ActualCount = controller.GetInfoQuestionsByTagID(tagId).Result.Count;
            int ExpectedCount = new ELPC.NUnitTest.TestScripts().GetInfoQuestionsByTagIDCount(tagId);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }
    }

    public class DAL_Test : TestController
    {

        [Test]
        public void TestHintImageCountByQuestionID()
        {
            QuestionRepository questionRepository = new QuestionRepository();
            int ActualCount = questionRepository.GetHintImagesByQuestionID(23).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetHintImageCountByQuestionID(23);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }


        [Test]
        public void TestInsertUpdateQuestionProxy()
        {
            AnswerType answerType = new AnswerType()
            {
                AnswerTypeID = 1,
                AnswerTypeName = "",
                IsDefault = true,
                IsDeleted = false
            };



            QuestionRepository questionRepository = new QuestionRepository();

            QuestionProxy questionProxy = new QuestionProxy()
            {
                QuestionID = 23,
                CreatedBy_NTID = "JNK1COB",
                ModifiedBy_NTID = "JNK1COB",
                Proxies = new List<User>()
               {
                   new User
                   {
                       UserName = "EXTERNAL Venkatesh Govindaraj (Nous, RBEI/BSA4)",
                       FirstName = "Govindaraj",
                       LastName = "Venkatesh",
                       EmailAddress="external.Govindaraj.Venkatesh@in.bosch.com",
                       NTID = "EGV1COB"

                   }

               }
            };

            var result = questionRepository.InsertQuestionProxy(questionProxy);
            Assert.AreEqual(0, result.Result.ResultCode);
        }

    }

    public class ValueStreamTemplateControllerTest : TestController
    {
        [Test]
        public void GetValueStreamTemplates()
        {
            var controller = base.GetValueStreamTemplateController();
            int ActualCount = controller.GetValueStreamTemplates().Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetValueStreamTemplateCount();
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void GetValueStreamCategories()
        {
            var controller = base.GetValueStreamTemplateController();
            int ActualCount = controller.GetValueStreamCategories().Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetValueStreamCategoryCount();
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void GetValueStreams()
        {
            var controller = base.GetValueStreamTemplateController();
            int ActualCount = controller.GetValueStreams().Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetValueStreamCount();
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void GetValueStreamsHistory()
        {
            var controller = base.GetValueStreamTemplateController();
            int ActualCount = controller.GetValueStreamsHistory(10).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetAssessorTemplateHistoryCountByAssessorTemplateID(10);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void ValueStreamRestoreByTemplateHistoryID()
        {
            int historyID = 117;
            var controller = base.GetValueStreamTemplateController();
            bool status = controller.ValueStreamRestoreByTemplateHistoryID(historyID).Result.ResultCode == 0;
            Assert.AreEqual(true, status);
        }


        [Test]
        public void InsertValueStreamTemplate()
        {
            ValueStreamTemplate valuestreamtemplate = new ValueStreamTemplate()
            {
                ValueStreamTemplateID = 23,
                ModifiedBy_NTID = "JNK1COB",
            };

            var controller = base.GetValueStreamTemplateController();
            var result = controller.InsertValueStreamTemplate(valuestreamtemplate);
            Assert.AreEqual(0, result.Result.ResultCode);
        }

        [Test]
        public void GetValueStreamCategoryByTemplateID()
        {
            int valueStreamTemplateID = 17;
            var controller = base.GetValueStreamTemplateController();
            int ActualCount = controller.GetValueStreamCategoryByTemplateID(valueStreamTemplateID).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetValueStreamCategoryByTemplateID(valueStreamTemplateID);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void GetValueStreamsByCategoryID()
        {
            int categoryID = 17;
            var controller = base.GetValueStreamTemplateController();
            int ActualCount = controller.GetValueStreamsByCategoryID(categoryID).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetValueStreamsByCategoryID(categoryID);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void GetShiftsByTemplateID()
        {
            int valueStreamTemplateID = 17;
            var controller = base.GetValueStreamTemplateController();
            int ActualCount = controller.GetShiftsByTemplateID(valueStreamTemplateID).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetShiftsByTemplateID(valueStreamTemplateID);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        // TODO : ImportExcel

        [Test]
        public async Task ImportExcel()
        {
            string sFileName = @"ValueStream.xlsx";

            var memory = new MemoryStream();
            using (var stream = new FileStream(Path.Combine(sWebRootFolder, sFileName), FileMode.Open))
            {
                await stream.CopyToAsync(memory);
            }
            memory.Position = 0;
            FormFile file = new FormFile(memory, 0, memory.Length, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", sFileName);

            var httpContext = new DefaultHttpContext();
            httpContext.Request.Headers.Add("Content-Type", "multipart/form-data");
            httpContext.Request.Form = new FormCollection(new Dictionary<string, StringValues>(), new FormFileCollection { file });

            var _HttpContext = new Mock<HttpContext>();
            _HttpContext.Setup(_ => _.Request).Returns(httpContext.Request);

            HttpContextAccessor = new HttpContextAccessor();
            HttpContextAccessor.HttpContext = _HttpContext.Object;



            var controller = base.GetValueStreamTemplateController(HttpContextAccessor);
            var result = await controller.ImportExcel();
            if (result != null)
            {
                Assert.AreEqual(true, result != null);
            }
            else
            {
                Assert.AreEqual(true, result == null);
            }
        }

        [Test]
        public void ExportExcel()
        {
            var controller = base.GetValueStreamTemplateController();
            var result = controller.ExportExcel();
            Assert.AreEqual("ValueStream.xlsx", ((Microsoft.AspNetCore.Mvc.FileResult)result).FileDownloadName.ToString());
        }

        [Test]
        public void TestInsertUpdateValuestreamProxy()
        {
            var controller = base.GetValueStreamTemplateController();

            ValueStreamProxy valueStreamProxy = new ValueStreamProxy()
            {
                ValueStreamTemplateID = 23,
                CreatedBy_NTID = "JNK1COB",
                ModifiedBy_NTID = "JNK1COB",
                IsLocked = true,
                Proxies = new List<User>()
               {
                   new User
                   {
                       UserName = "EXTERNAL Venkatesh Govindaraj (Nous, RBEI/BSA4)",
                       FirstName = "Govindaraj",
                       LastName = "Venkatesh",
                       EmailAddress="external.Govindaraj.Venkatesh@in.bosch.com",
                       NTID = "EGV1COB"

                   }

               }
            };

            var result = controller.InsertValueStreamProxy(valueStreamProxy);
            Assert.AreEqual(0, result.Result.ResultCode);
        }

        [Test]
        public void GetValueStreamTemplateCount()
        {
            var controller = base.GetValueStreamTemplateController();
            int ActualCount = controller.GetValueStreamTemplateTree().Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetValueStreamTemplateCount();
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void GetValueStreamTemplateTree()
        {
            var controller = base.GetValueStreamTemplateController();
            int ActualCount = controller.GetValueStreamTemplates().Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetValueStreamTemplateCount();
            Assert.AreEqual(ExpectedCount, ActualCount);
        }


        [Test]
        public void DeleteValueStreamTemplate()
        {
            ValueStreamTemplate valueStreamTemplate = new ValueStreamTemplate()
            {
                CreatedAt = System.DateTime.Now,
                CreatedBy = "FIXED-TERM Janarthanan Krishnasamy (RBEI/BSA4)",
                CreatedBy_NTID = "JNK1COB",
                CreatedBy_UserID = 0,
                Delimiter = "$$$",
                IsLocked = false,
                IsOperatedInShifts = false,
                ModifiedAt = System.DateTime.Now,
                ModifiedBy = "FIXED-TERM Janarthanan Krishnasamy (RBEI/BSA4)",
                ModifiedBy_NTID = "JNK1COB",
                ModifiedBy_UserID = 0,
                TempID = 0,
                ValueStreamCategories = null,
                ValueStreamTemplateID = 21,
                ValueStreamTemplateName = "testDte",
                ValueStreams = null,
                VisualizationViewModeID = 1
            };

            var controller = base.GetValueStreamTemplateController();
            bool status = controller.DeleteValueStreamTemplate(valueStreamTemplate).Result.ResultCode == 0;
            Assert.AreEqual(true, status);
            RestoreRecycleBin();
        }

        [Test]
        public void ValueStreamProxiesByTemplateID()
        {
            var controller = base.GetValueStreamTemplateController();
            int ActualCount = controller.ValueStreamProxiesByTemplateID(10).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetValueStreamProxiesCountByValueStreamTemplateID(10);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void GetRecycleBinTemplates()
        {
            var controller = base.GetValueStreamTemplateController();
            int ActualCount = controller.GetRecycleBinTemplates().Result.Count;
            int ExpectedCount = new ELPC.NUnitTest.TestScripts().GetRecycleBinTemplatesCount();
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void RestoreRecycleBin()
        {
            List<RecycleBinTemplate> recycleTemplate = new List<RecycleBinTemplate>();
            var item = new RecycleBinTemplate()
            {
                Deleted = System.DateTime.Now,
                DeletedBy = "JNK1COB",
                ID = 21,
                ItemName = "testDte",
                ItemType = "Value Stream Template",
                ModifiedBy = "FIXED-TERM Janarthanan Krishnasamy (RBEI/BSA4)",
                RowNumber = 24,
                Selected = false
            };

            recycleTemplate.Add(item);

            var controller = base.GetValueStreamTemplateController();
            bool status = controller.RestoreRecycleBin(recycleTemplate).Result != null;
            Assert.AreEqual(true, status);
        }


        [Test]
        public void GetValueStreamsByTemplateID()
        {
            int valueStreamTemplateID = 17;
            var controller = base.GetValueStreamTemplateController();
            int ActualCount = controller.GetValueStreamsByTemplateID(valueStreamTemplateID).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetValueStreamsByTemplateID(valueStreamTemplateID);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void ValueStreamByValueStreamID()
        {
            var controller = base.GetValueStreamTemplateController();
            int ActualCount = controller.ValueStreamByValueStreamID(10).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetValueStreamCountByValueStreamID(10);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }

        [Test]
        public void FetchValueStreamTemplateByTemplateID()
        {
            var controller = base.GetValueStreamTemplateController();
            int ActualCount = controller.FetchValueStreamTemplateByTemplateID(10).Result.Count;
            ELPC.NUnitTest.TestScripts testScripts = new ELPC.NUnitTest.TestScripts();
            int ExpectedCount = testScripts.GetValueStreamTemplateCountByTemplateID(10);
            Assert.AreEqual(ExpectedCount, ActualCount);
        }
    }
}
