﻿using ELPC.API.Controllers;
using ELPC.BAL.Implementation;
using ELPC.DAL.Implementation;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Moq;
using System.IO;

namespace ELPC.NUnitTest
{

    public class TestBase
    {
        public IConfiguration Configuration { get; set; }
        public IConfigurationBuilder ConfigBuilder { get; set; }

        public IHostingEnvironment HostingEnvironment { get; set; }

        public IHttpContextAccessor HttpContextAccessor { get; set; }

        public TestBase()
        {
            /*Hosting Environment*/
            var tmpHostingEnvironment = new Mock<IHostingEnvironment>();
            tmpHostingEnvironment.Setup(_ => _.WebRootPath).Returns(new Utility.Utility().GetConfigValue("PathName"));
            HostingEnvironment = tmpHostingEnvironment.Object;
        }

        protected ActiveDirectoryController GetActiveDirectoryController()
        {
            var controller = new ActiveDirectoryController(new CommonService(new CommonRepository()));
            return controller;
        }

        protected AssessorTemplateController GetAssessorTemplateController(IHttpContextAccessor httpContextAccessor = null) 
        {
            var controller = new AssessorTemplateController(new AssessorTemplateService(new AssessorTemplateRepository()), httpContextAccessor, HostingEnvironment);
            return controller;
        }

        protected AuditController GetAuditController()
        {
            var controller = new AuditController(new AuditService(new AuditRepository()), HostingEnvironment);
            return controller;
        }

        protected CommonController GetCommonController()
        {
            var controller = new CommonController(new CommonService(new CommonRepository()), Configuration, HostingEnvironment);
            return controller;
        }


        protected CustomModeController GetCustomModeController()
        {
            var controller = new CustomModeController(new CustomModeService(new CustomModeRepository()));
            return controller;
        }

        protected DataPoolController GetDataPoolController()
        {
            var controller = new DataPoolController(new DataPoolService(new DataPoolRepository()), Configuration);
            return controller;
        }

        protected DownloadFileController GetDownloadFileController()
        {
            var controller = new DownloadFileController(HostingEnvironment, Configuration);
            return controller;
        }

        protected ProcessConfirmationController GetProcessConfirmationController()
        {
            var controller = new ProcessConfirmationController(new SchedulerService(new SchedulerRepository()),   new ProcessConfirmationService(new ProcessConfirmationRepository()), Configuration);
            return controller;
        }

        protected QuestionController GetQuestionController()
        {
            var controller = new QuestionController(new QuestionService(new QuestionRepository()), HostingEnvironment, Configuration);
            return controller;
        }

        protected TagController GetTagController()
        {
            var controller = new TagController(new TagService(new TagRepository()));
            return controller;
        }

        protected TagModeController GetTagModeController()
        {
            var controller = new TagModeController(new TagModeService(new TagModeRepository()));
            return controller;
        }

        protected ValueStreamTemplateController GetValueStreamTemplateController(IHttpContextAccessor httpContextAccessor = null)
        {
            var controller = new ValueStreamTemplateController(new ValueStreamTemplateService(new ValueStreamTemplateRespository()), httpContextAccessor, new CommonService(new CommonRepository()), Configuration, HostingEnvironment);
            return controller;
        }
    }
}
