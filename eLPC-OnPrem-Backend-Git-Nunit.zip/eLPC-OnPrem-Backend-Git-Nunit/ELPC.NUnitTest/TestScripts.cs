﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using System.Data;
using System.Linq;
using ELPC.Core;

namespace ELPC.NUnitTest
{
    public class TestScripts
    {
        string strsql;
       
        #region Assessor
        public int GetAssessorTemplateCount()
        {
            strsql = "select Count(*) from T_TRN_AssessorTemplate where IsDeleted = 0";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetAssessorCount()
        {
            strsql = "select Count(*) from T_TRN_Assessor where IsDeleted = 0";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetAssessorProxiesCountByAssessorTemplateID(int assessorTemplateID)
        {
            strsql = "select Count(*) from T_LNK_Assessor_Proxy where AssessorTemplateID ="+ assessorTemplateID+" and IsDeleted =0";
            return new ADOHelper().GetRowCount(strsql);
        }
        public int GetAssessorTemplateHistoryCountByAssessorTemplateID(int assessorTemplateID)
        {
            strsql = "select count(*) from T_TRN_AssessorTemplateHistory where AssessorTemplateID=" + assessorTemplateID + " and IsDeleted =0";
            return new ADOHelper().GetRowCount(strsql);

        }
        public int GetAssessorTemplateCountByAssessorTemplateID(int assessorTemplateID)
        {
            strsql = "select count(*) from T_TRN_AssessorTemplate where AssessorTemplateID=" + assessorTemplateID + " and IsDeleted =0";
            return new ADOHelper().GetRowCount(strsql);

        }
        public int GetAssessorCountByAssessorTemplateID(int assessorTemplateID)
        {
            strsql = "select count(*) from T_TRN_Assessor where AssessorTemplateID=" + assessorTemplateID + " and IsDeleted =0";
            return new ADOHelper().GetRowCount(strsql);

        }
        public int GetAssessorTemplateNameCountByName(string assessorTemplateName)
        {
            strsql = "select count(*) from T_TRN_AssessorTemplate where AssessorTemplateName = " +"'" + assessorTemplateName + "'"+ "and IsDeleted = 0";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int AssessorExportExcel()
        {
            strsql = "select count(*) from  T_TRN_Assessor Where (IsDeleted = 0)";
            return new ADOHelper().GetRowCount(strsql);
        }

        #endregion

        #region ValueStream
        public int GetValueStreamTemplateCount()
        {
            strsql = "select Count(*) from T_TRN_ValueStreamTemplate where IsDeleted = 0";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetValueStreamCategoryCount()
        {
            strsql = "select Count(*) from T_TRN_ValueStreamCategory where IsDeleted = 0";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetValueStreamCount()
        {
            strsql = "select Count(*) from T_TRN_ValueStream VS where (VS.IsDeleted =0) and VS.Responsible_UserID is not null and valueStreamData <>''";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetValueStreamTemplateCountByTemplateID(int valueStreamTemplateID)
        {
            strsql = "select Count(*) from T_TRN_ValueStreamTemplate where ValueStreamTemplateID ="+ valueStreamTemplateID;
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetValueStreamCountByValueStreamID(int valueStreamID)
        {
            strsql = "select Count(*) from T_TRN_ValueStream where ValueStreamID ="+valueStreamID;
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetValueStreamProxiesCountByValueStreamTemplateID(int valueStreamTemplateID)
        {
            strsql = "select Count(*) from T_LNK_ValueStream_Proxy where ValueStreamTemplateID ="+ valueStreamTemplateID+" and IsDeleted =0";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetValuestreamTemplateHistoryCountByValueStreamTemplateID(int valueStreamTemplateID)
        {
            strsql = "select count(*) from T_HST_ValueStreamTemplateHistory where ValueStreamTemplateID=" + valueStreamTemplateID + " and IsDeleted =0";
            return new ADOHelper().GetRowCount(strsql);

        }

        public int GetValueStreamTemplateNameCountByName(string valueSreamTemplateName)
        {
            strsql = "select count(*) from T_TRN_ValueStreamTemplate where valueSreamTemplateName = " + "'" + valueSreamTemplateName + "'" + "and IsDeleted = 0";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetShiftsByTemplateID(int valueStreamTemplateID)
        {
            strsql = "select count(*) from T_LNK_ValueStream_Shift Where ValueStreamTemplateID = " + valueStreamTemplateID + "  and (IsDeleted = 0)";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetValueStreamCategoryByTemplateID(int valueStreamTemplateID)
        {
            strsql = "select count(*) from T_TRN_ValueStreamCategory Where ValueStreamTemplateID = " + valueStreamTemplateID + "  and (IsDeleted = 0)";
            return new ADOHelper().GetRowCount(strsql);
        }


        public int GetValueStreamsByCategoryID(int categoryID)
        {
            strsql = "select count(*) from T_TRN_ValueStream Where ValueStreamCategoryID = " + categoryID + "  and (IsDeleted = 0)";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetValueStreamsByTemplateID(int valueStreamTemplateID)
        {
            strsql = "select count(*) from T_TRN_ValueStream Where ValueStreamTemplateID = " + valueStreamTemplateID + "  and (IsDeleted = 0)";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int ValueStreamExportExcel()
        {
            strsql = "select count(*) from (select TOP 10 * from T_TRN_ValueStream Where (IsDeleted = 0)) as t";
            return new ADOHelper().GetRowCount(strsql);
        }
        
        
        #endregion

        #region Question
        public int GetQuestionCount()
        {
            strsql = "select Count(*) from T_TRN_Question where IsDeleted = 0";
            return new ADOHelper().GetRowCount(strsql);
        }

      

        public int GetQuestionProxiesCountByQuestionID(int questionID)
        {
            strsql = "select Count(*) from T_LNK_Question_Proxy where QuestionID =" + questionID  +"and IsDeleted =0";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetQuestionHistoryCountByQuestionID(int questionID)
        {
            strsql = "select count(*) from T_TRN_QuestionHistory where QuestionID=" + questionID + " and IsDeleted =0";
            return new ADOHelper().GetRowCount(strsql);

        }

        public int GetQuestionDetailCountByQuestionID(int questionID)
        {
            strsql = "select count(*) from T_TRN_Question where QuestionID=" + questionID + " and IsDeleted =0";
            return new ADOHelper().GetRowCount(strsql);

        }

        public int GetAssessorCountByQuestionID(int questionID)
        {
            strsql = "select count(*) from T_LNK_AssignedAssessors where QuestionID=" + questionID + " and IsDeleted =0";
            return new ADOHelper().GetRowCount(strsql);

        }

        public int GetValuestreamCountByQuestionID(int questionID)
        {
            strsql = "select count(*) from T_LNK_AssignedValueStreams where QuestionID=" + questionID + " and IsDeleted =0";
            return new ADOHelper().GetRowCount(strsql);

        }

        public int GetTagCountByQuestionID(int questionID)
        {
            strsql = "select count(*) from T_LNK_QN_AssignedTags where QuestionID=" + questionID + " and IsDeleted =0";
            return new ADOHelper().GetRowCount(strsql);

        }

        public int GetHintImageCountByQuestionID(int questionID)
        {
            strsql = "select count(*) from T_TRN_HintImage where QuestionID=" + questionID + " and IsDeleted =0";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetHintHyperlinkCountByQuestionID(int questionID)
        {
            strsql = "select count(*) from T_TRN_HintHyperLink where QuestionID=" + questionID + " and IsDeleted =0";
            return new ADOHelper().GetRowCount(strsql);

        }

        public int GetSingleLineTextCountByQuestionID(int questionID)
        {
            strsql = "select count(*) from T_TRN_SingleLineText where QuestionID=" + questionID + " and IsDeleted =0";
            return new ADOHelper().GetRowCount(strsql);

        }

        public int GetMultipleLinesTextountByQuestionID(int questionID)
        {
            strsql = "select count(*) from T_TRN_MultipleLinesText where QuestionID=" + questionID + " and IsDeleted =0";
            return new ADOHelper().GetRowCount(strsql);

        }

        public int GetChoiceCountByQuestionID(int questionID)
        {
            strsql = "select count(*) from T_TRN_Choice where QuestionID=" + questionID + " and IsDeleted =0";
            return new ADOHelper().GetRowCount(strsql);

        }

        public int GetQuestionDetailCount()
        {
            strsql = "select Count(*) from T_TRN_Question where IsDeleted =0";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetQuestionNameCountByName(string questionName)
        {
            strsql = "select count(*) from T_TRN_Question where QuestionText = " + "'" + questionName + "'" + "and IsDeleted = 0";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetCurrencySettingsByQuestionID(int questionID)
        {
            strsql = "select count(*) from T_TRN_AnswerTypeCurrency Where QuestionID = " + questionID +"  and (IsDeleted = 0)";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetDateTimeSettingsByQuestionID(int questionID)
        {
            strsql = "select count(*) from T_TRN_AnswerTypeDateTime Where QuestionID = " + questionID + "  and (IsDeleted = 0)";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetNumberSettingsByQuestionID(int questionID)
        {
            strsql = "select count(*) from T_TRN_AnswerTypeNumber Where QuestionID = " + questionID + "  and (IsDeleted = 0)";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetRatingScaleByQuestionID(int questionID)
        {
            strsql = "select count(*) from T_TRN_RatingScale Where QuestionID = " + questionID + "  and (IsDeleted = 0)";
            return new ADOHelper().GetRowCount(strsql);
        }

       
        



        #endregion

        #region Tag
        public int GetTagCount()
        {
            strsql = "select Count(*) from T_TRN_Tag where IsDeleted = 0";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetTagProxiesCountByTagID(int tagID)
        {
            strsql = "select Count(*) from T_LNK_Tag_Proxy where TagID =" + tagID +" and IsDeleted =0";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetTagHistoryCountByTagID(int tagID)
        {
            strsql = "select count(*) from T_TRN_TagHistory where TagID=" + tagID + " and IsDeleted =0";
            return new ADOHelper().GetRowCount(strsql);

        }
        public int GetAssessorCountByTagID(int tagID)
        {
            strsql = "select count(*) from T_LNK_Tag_AssignedAssessors where TagID=" + tagID + " and IsDeleted =0";
            return new ADOHelper().GetRowCount(strsql);

        }
        public int GetValuestreamCountByTagID(int tagID)
        {
            strsql = "select count(*) from T_LNK_Tag_AssignedValueStreams where TagID=" + tagID + " and IsDeleted =0";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetQuestionCountByTagID(int tagID)
        {
            strsql = "select count(*) from T_LNK_Tag_AssignedQuestionsTags LNK "
          +"where LNK.TagID ="+tagID +" AND LNK.QuestionID is NOT NULL and(IsDeleted = 0)";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetTagCountByTagID(int tagID)
        {
            strsql = "select count(*) from T_LNK_Tag_AssignedQuestionsTags LNK "
           +"where LNK.TagID ="+tagID +" AND LNK.LinkedTagID IS NOT NULL and IsDeleted = 0";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetTagCountByID(int tagID)
        {
            strsql = "select count(*) from T_TRN_Tag TT where TT.TagID =" + tagID + " AND IsDeleted = 0";
            return new ADOHelper().GetRowCount(strsql);
        }


        public int GetAssessorsByTagIDs(string tagID)
        {
            strsql = "select count(*) from T_TRN_Assessor where AssessorID in (select AssessorID from T_LNK_TagAssessors where TagID in ((SELECT * FROM[dbo].[fnSplit](" + tagID + ")))) and(IsDeleted = 0)";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int FetchQuestionsByAssessorsAndValuestreams(string assessorIDs, string valueStreamIDs)
        {
            strsql =  " Select count(*)  from T_TRN_Question where QuestionID in (select distinct(AR.QuestionID) from T_LNK_AssignedAssessors AR "
                    + " inner join T_LNK_AssignedValueStreams VS on AR.QuestionID = VS.QuestionID where AR.AssessorID in ((SELECT* FROM [dbo].[fnSplit](" + assessorIDs + "))) "
                    + " and VS.ValueStreamID in ((SELECT* FROM [dbo].[fnSplit](" + valueStreamIDs + "))) )";

            return new ADOHelper().GetRowCount(strsql);
        }

        public int FetchTagsByAssessorsAndValuestreams(string assessorIDs, string valueStreamIDs)
        {
            strsql = "  Select Count(*)  from T_TRN_Tag T where TagID in (select distinct(AR.TagID) from T_LNK_Tag_AssignedAssessors AR inner join T_LNK_Tag_AssignedValueStreams VS on AR.TagID = VS.TagID"
                    + " where AR.AssessorID in ((SELECT * FROM[dbo].[fnSplit](" + assessorIDs +"))) and VS.ValueStreamID in ((SELECT * FROM[dbo].[fnSplit](" + valueStreamIDs + ")))  and(AR.IsDeleted = 0) and(VS.IsDeleted = 0))";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int FetchProcessConfirmationTags()
        {
            strsql = "Select Count(*) from T_TRN_TAG WITH (NOLOCK) WHERE TagTypeID = 1 ";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int FetchTagDetailsByTagID(int tagId)
        {
            strsql = "select Count(*)  from T_TRN_Tag where TagID=" + tagId;
            return new ADOHelper().GetRowCount(strsql);
        }
        
        public int GetTagNameCountByName(string tagName)
        {
            strsql = "select count(*) from T_TRN_Tag where TagName = " + "'" + tagName + "'" + "and IsDeleted = 0";
            return new ADOHelper().GetRowCount(strsql);
        }
        #endregion 

        #region Calendar
        public int GetAuditCount()
        {
            strsql = "select Count(*) from T_TRN_Audit where IsDeleted = 0";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int AuditAssessorsByAuditAndTemplateID(int auditID, int templateID)
        {
            strsql = "Select Count(*) from T_LNK_AuditTemplate_AssessorDetail where AuditID =" + auditID + " and AuditTemplateID = " + templateID + " and IsDeleted = 0";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int AuditAssessorsByAuditID(int auditID)
        {
            strsql = "Select Count(*) from T_TRN_AuditAssessor where AuditID =" + auditID;
            return new ADOHelper().GetRowCount(strsql);
        }

        public int AuditByAuditID(int auditID)
        {
            strsql = "Select Count(*) from T_TRN_Audit where AuditID =" + auditID;
            return new ADOHelper().GetRowCount(strsql);
        }

        public int AuditQuestionsByAuditAndAssessorID(int auditID, string NTID)
        {
            strsql = "select count (*) from (Select distinct(AuditTemplateID) from T_LNK_Audit_AnsweredQuestions where AuditID =  " + auditID + "  and (IsAuditCompleted =0 or IsAuditCompleted is null) ) as t";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int AuditQuestionsByAuditAndTemplateID(int auditID, int templateID)
        {
            strsql = "Select Count(*) from T_LNK_Audit_AnsweredQuestions where AuditID =" + auditID + " and AuditTemplateID = " + templateID + " and (IsAuditCompleted = 0 or IsAuditCompleted is null)";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int AuditQuestionsByAuditID(int auditID)
        {
            strsql = "Select Count(*) from T_LNK_Audit_AssignedQuestions where AuditID =" + auditID + " and IsDeleted = 0";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int AuditQuestionsByCurrentAssessorAndTemplateID(int auditID, int templateID)
        {
            strsql = "select count (*) from T_LNK_Audit_AnsweredQuestions where AuditID =  " + auditID + " and (IsAuditCompleted =0 or IsAuditCompleted is null) and AuditTemplateID = " +templateID;
            return new ADOHelper().GetRowCount(strsql);
        }

        public int OptionalAttendeesByAuditID(int auditID)
        {
            strsql = "Select Count(*) from T_LNK_Audit_OptionalAttendees where AuditID =" + auditID + " and IsDeleted = 0";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int OtherAuditAssessorsByAuditAndTemplateID(int auditID, int templateID)
        {
            strsql = "Select Count(*) from T_LNK_AuditTemplate_OtherAssessorDetail where AuditID =" + auditID + " and AuditTemplateID =" + templateID + " and IsDeleted = 0";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int PendingAuditsByAuditID(int auditID)
        {
            strsql = "Select Count(*) from (Select distinct(AuditTemplateID) from T_LNK_Audit_AnsweredQuestions where AuditID =" + auditID + " and (IsAuditCompleted = 0 or IsAuditCompleted is null))as t";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int RequiredAttendeesByAuditID(int auditID)
        {
            strsql = "Select Count(*) from T_LNK_Audit_RequiredAttendees where AuditID =" + auditID + " and (IsDeleted = 0 or IsDeleted is null)";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int ValidateAssessorByAuditAndNTID(int auditID, string NTID)
        {
            strsql = "select count(*) from(select Top 1 * from T_LNK_Audit_RequiredAttendees where NTID = '" + NTID + "' and AuditID = " + auditID + " union select Top 1 * from T_LNK_Audit_OptionalAttendees where NTID = '" + NTID + "' and AuditID = " + auditID + ") as t";
            return new ADOHelper().GetRowCount(strsql);
        }



        #endregion


        #region Recycle Bin 
        public int GetRecycleBinTemplatesCount()
        {
            strsql = "select count(*) from T_TRN_AssessorTemplate VH inner join T_MST_User TU on VH.ModifiedBy_NTID = TU.NTID where IsDeleted = 1 "
            + "Union All select count(*) from T_TRN_ValueStreamTemplate VH inner join T_MST_User TU on VH.ModifiedBy_NTID = TU.NTID where IsDeleted = 1 "
            + "Union All select count(*) from T_TRN_Question VH inner join T_MST_User TU on VH.ModifiedBy_NTID = TU.NTID where IsDeleted = 1 "
            + "Union All select count(*) from T_TRN_Tag VH inner join T_MST_User TU on VH.ModifiedBy_NTID = TU.NTID where IsDeleted = 1 "
            + "Union All select count(*) from T_TRN_DataPool VH inner join T_MST_User TU on VH.ModifiedBy_NTID = TU.NTID where IsDeleted = 1 ";
            int count = 0;

            DataTable dataTable = new ADOHelper().GetValueAsDataTable(strsql);
            foreach (DataRow row in dataTable.Rows)
            {
                count += Convert.ToInt32(row.ItemArray[0].ToString());
            }

            return count ;
        }

        #endregion 

        #region Data Pool
        public int GetDataPoolCount()
        {
            //ToCheck ValueStreamID <> 0
            strsql = "select Count(*) from T_TRN_DataPool where IsDeleted = 0 and ValueStreamID <> 0";
            return new ADOHelper().GetRowCount(strsql);
        }


        public int GetProcessConfirmationByIDCount(int dataPoolId)
        {
            strsql = "select Count(*) from T_TRN_DataPool where IsDeleted = 0 and DataPoolID=" + dataPoolId;
            return new ADOHelper().GetRowCount(strsql);
        }


        public int GetHintImagesByDeviationIDCount(int deviationId)
        {
            strsql = "select Count(*) from T_TRN_DeviationAttachments where IsDeleted = 0 and DeviationID=" + deviationId;
            return new ADOHelper().GetRowCount(strsql);
        }

        
        public int GetDataPoolHistoryCount(int dataPoolId)
        {
            strsql = "select Count(*) from T_TRN_DataPoolHistory where IsDeleted = 0 and DataPoolID=" + dataPoolId;
            return new ADOHelper().GetRowCount(strsql);
        }

        public int DataPoolExportExcel()
        {
            strsql = "select Count(*) from T_TRN_DataPool where IsDeleted = 0 and valuestreamid > 0";
            return new ADOHelper().GetRowCount(strsql);
        }

        

        #endregion

        #region Process Confirmation
        public int GetProcessConfirmationShuffleCount()
        {
            strsql = "select Count(*) from T_TRN_Question where IsDeleted = 0";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetProcessConfirmationCustomCount()
        {
            strsql = "select Count(*) from T_TRN_Question where IsDeleted = 0  and QuestionID in (select QuestionID from [T_LNK_Custom_Questions] where CustomModeID=20 and IsCustomMode=1 and (IsDeleted =0))";
            return new ADOHelper().GetRowCount(strsql);
        }


        public int GetProcessConfirmationTagCount()
        {
            strsql = "select Count(*) from T_TRN_Question where QuestionID in(select Distinct(QuestionID) from T_LNK_TagMode_Questions where TagModeID =4 ) and(IsDeleted = 0)";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetValueStreamByQuestionIDCount(int questionId)
        {
            strsql = "select Count(*) from T_TRN_Question where IsDeleted = 0 and QuestionID=" + questionId;
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetAssessorsByQuestionIDCount(int questionId)
        {
            strsql = "select Count(*) from [T_LNK_AssignedAssessors] where IsDeleted = 0 and QuestionID=" + questionId;
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetTagModeByNTIDCount()
        {
            strsql = "select Count(*) from [T_LNK_TagMode_Tags] where IsDeleted = 0 and  TagModeID= 4 ";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetTagModeTagsCount()
        {
            strsql = "select Count(*) from T_TRN_Tag TT FULL OUTER JOIN[T_LNK_Custom_QuestionsTags] CQ on CQ.TagID = TT.TagID  and cq.IsDeleted = 0" +
            "where TT.TagID is not NULL and(TT.IsDeleted = 0)";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetInfoQuestionsByTagIDCount(int tagId)
        {
            strsql = "Select Count(*) from(select QuestionID from T_LNK_Tag_AssignedQuestionsTags where TagID = " + tagId + "  and IsDeleted = 0 Union select QuestionID from T_LNK_QN_AssignedTags where TagID = " + tagId + " and IsDeleted = 0) as t";
            return new ADOHelper().GetRowCount(strsql);
        }


        public int GetCustomModeByNTIDCount(int customModeID)
        {
            strsql = "select Count(*) from [T_TRN_Tag] TT inner join [T_LNK_Custom_QuestionsTags] CQ  on CQ.TagID=TT.TagID where CQ.TagID is not null and CQ.IsDeleted<>1 and CQ.CustomModeID =" + customModeID
            + " Union All "
            + "select Count(*) from T_TRN_Question TQ  inner join [T_LNK_Custom_QuestionsTags] CQ   on CQ.QuestionID=TQ.QuestionID  where CQ.QuestionID is not null and CQ.IsDeleted<>1 and CQ.CustomModeID =" + customModeID;

            int count = 0;
            DataTable dataTable = new ADOHelper().GetValueAsDataTable(strsql);
            foreach (DataRow row in dataTable.Rows)
            {
                count += Convert.ToInt32(row.ItemArray[0].ToString());
            }

            return count;
        }


        public int GetCustomModeCount()
        {
            strsql = "Select Count(*) from T_TRN_Tag TT FULL OUTER JOIN[T_LNK_Custom_QuestionsTags] CQ on CQ.TagID=TT.TagID and CQ.IsDeleted = 0 "
            +" where TT.TagID is not NULL and (TT.IsDeleted = 0) and TagTypeID = 1";
            return new ADOHelper().GetRowCount(strsql);
        }

        #endregion


        #region Common

        public int GetChoiceDisplayTypesCount()
        {
            strsql = "Select Count(*) from T_MST_ChoiceDisplayType where (IsDeleted = 0)";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetAnswerTypesCount()
        {
            strsql = "Select Count(*) from T_MST_AnswerType where (IsDeleted = 0)";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetUsers()
        {
            strsql = "Select Count(*) from T_MST_User";
            return new ADOHelper().GetRowCount(strsql);
        }

        public int GetUserByNTID(string NTID)
        {
            strsql = "Select Count(*) from T_MST_User where NTID = '" + NTID + "'";
            return new ADOHelper().GetRowCount(strsql);
        }

        
        #endregion

    }
}
