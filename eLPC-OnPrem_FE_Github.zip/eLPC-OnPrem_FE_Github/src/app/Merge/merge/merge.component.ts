import { DatePipe } from "@angular/common";
import { Component, OnInit, TemplateRef, ViewChild } from "@angular/core";
import { Router } from "@angular/router";
import { BsModalService } from "ngx-bootstrap/modal";
import { LanguageService } from "src/app/language.service";
import { AssessorTemplateService } from "src/app/service/assessor/assessortemplate.service";
import { CommonService } from "src/app/service/common/common.service";
import { ValuestreamTemplateService } from "src/app/service/common/valuestreamtemplate.service";
import { MergeService } from "src/app/service/merge.service";
import { QuestionService } from "src/app/service/question.service";
import { SharedService } from "src/app/service/shared.service";
import { TagService } from "src/app/service/tag.service";
import { environment } from "src/environments/environment";
import { Assessor, AssessorTemplate } from "src/app/Assessor/assessor/assessortemplate";
import { Question } from "src/app/Datapool/QuestionModule/questions/question";
import { User } from "src/app/main/body/shared/common";
import { AssessorValueStreamList, Tag } from "src/app/Tag/tag/tag";
import {
  ValueStream,
  ValueStreamCategory,
  ValueStreamTemplate,
} from "src/app/Valuestream/valuestreams/valuestreamtemplate";
import { Merge, MergeProxy } from "./merge";
import { es } from "date-fns/locale";

@Component({
  selector: "app-merge",
  templateUrl: "./merge.component.html",
  styleUrls: ["./merge.component.css"],
})
export class MergeComponent implements OnInit {
  dateTimeFormat = environment.dateTimeFormat;
  filterdateFormat = environment.dateTimeFormat.split(" ")[0];

  @ViewChild("successPopup") successModal: TemplateRef<any>;
  @ViewChild("alertPopup") warningModal: TemplateRef<any>;
  labels: any;
  _subscription: any;
  valueStreamTemplates: ValueStreamTemplate[] = [];
  valueStreamCategories: ValueStreamCategory[] = [];
  valueStreams: ValueStream[] = [];

  assessorTemplateList: AssessorTemplate[] = [];
  assessorTemplate: AssessorTemplate = new AssessorTemplate();
  assessors: Assessor[] = [];
  assessor: Assessor;
  question: Question = new Question();

  //for multiselect dropdown
  selectedValueStreams: ValueStream[] = [];
  selectedValueStreamIDs = [];
  valueStreamSettings = {};

  //for Assessor Multiselect dropdown
  selectedAssessors = [];
  selectedAssessorIDs = [];
  assessorSettings = {};
  assignedTargetFrequency = [];

  //For multi select dropdown - Value stream template
  dropdownSettingsValueStreamTemplate = {};
  selectedItemValueStreamTemplate: ValueStreamTemplate[] = [];

  //For multi select dropdown - Value stream Category
  dropdownSettingsValueStreamCategories = {};
  selectedItemValueStreamCategories: ValueStreamCategory[] = [];

  //For multi select dropdown - Assign tag to assessor template
  dropdownSettingsAssessorTemplate = {};
  selectedItemAssessorTemplate: AssessorTemplate[] = [];

  //Input filters
  selectedquestionorTags: number;
  selectedassignmentremovalorproxy: any;

  tagUnChecked: boolean;
  questionUnChecked: boolean;

  assignmentUnChecked: boolean;
  removalUnChecked: boolean;
  proxyUnChecked: boolean = false;

  questionassignmentselected: boolean = false;
  questionremovalselected: boolean = false;
  questionproxyselected: boolean = false;

  tagassignmentselected: boolean = false;
  tagremovalselected: boolean = false;
  tagproxyselected: boolean = false;

  //for Tags selection
  availableTags: Tag[] = [];
  allavailableTags: Tag[] = [];
  selectedTags: Tag[] = [];
  selectedTagIDs: string;
  tagList: Tag[] = [];
  tag: Tag = new Tag();

  questionOrders: { id: number }[];
  questionList: Question[];
  availableQuestions: Question[] = [];
  selectedQuestionIDs: any;
  quest: Question = new Question();
  isLoading:boolean=false;
  selectedQuestions: Question[] = [];
  orderSelectedQuestions: Question[] = [];

  assessorValueStreamList: AssessorValueStreamList =
    new AssessorValueStreamList();

  visulizationViewModeID: any;

  isAssignment: boolean = true;

  mergeQuestionAssignment: Merge;

  isDisabled: boolean = true;
  alertText: string;

  questionProxy: MergeProxy;
  tagProxy: MergeProxy;

  constructor(
    private modalService: BsModalService,
    private local_label: LanguageService,
    private sharedService: SharedService,
    private datePipe: DatePipe,
    private router: Router,
    private valueStreamService: ValuestreamTemplateService,
    private assessorTemplateService: AssessorTemplateService,
    private tagService: TagService,
    private questionService: QuestionService,
    private commonService: CommonService,
    private mergeService: MergeService
  ) {}

  ngOnInit() {
    if (this.sharedService.role !== "Designer") {
      this.router.navigate([environment.home + "/accessdenied"]);
    }

    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
    });

    this.sharedService.show();
    console.table(this.labels);
    this.getValueStreamList();
    this.getAssessorTemplateList();
    this.getavailabletags();
    this.getTagQuestionList();
    this.onAssessorSelect(null); //to load the default tags
    this.onLoadAssessorTemplate();
    //this.mergeassignment();

    this.tagUnChecked = true;
    this.assignmentUnChecked = true;

    this.valueStreamSettings = {
      singleSelection: false,
      idField: "valueStreamID",
      textField: "valueStreamName",
      selectAllText: "Select All",
      unSelectAllText: "UnSelect All",
      itemsShowLimit: 3,
      allowSearchFilter: true,
    };
    this.selectedValueStreams = [];
    this.selectedValueStreamIDs = [];

    //For multi select dropdown - Value stream template
    this.dropdownSettingsValueStreamTemplate = {
      singleSelection: false,
      idField: "valueStreamTemplateID",
      textField: "valueStreamTemplateName",
      selectAllText: "Select All",
      unSelectAllText: "UnSelect All",
      itemsShowLimit: 5,
      allowSearchFilter: true,
      closeDropDownOnSelection: true,
    };

    //For multi select dropdown - Value stream Category
    this.dropdownSettingsValueStreamCategories = {
      singleSelection: false,
      idField: "valueStreamCategoryID",
      textField: "valueStreamCategoryName",
      selectAllText: "Select All",
      unSelectAllText: "UnSelect All",
      itemsShowLimit: 5,
      allowSearchFilter: true,
      closeDropDownOnSelection: true,
    };

    //For multi select dropdown - Assign tag to assessor template
    this.dropdownSettingsAssessorTemplate = {
      singleSelection: false,
      idField: "assessorTemplateID",
      textField: "assessorTemplateName",
      selectAllText: "Select All",
      unSelectAllText: "UnSelect All",
      itemsShowLimit: 5,
      allowSearchFilter: true,
      closeDropDownOnSelection: true,
    };

    //for Assessor
    this.assessorSettings = {
      singleSelection: false,
      idField: "assessorID",
      textField: "assessorName",
      selectAllText: "Select All",
      unSelectAllText: "UnSelect All",
      itemsShowLimit: 3,
      allowSearchFilter: true,
    };
    this.selectedAssessors = [];
    this.valueStreams = [];
  }

  //template
  public getValueStreamList() {
    this.valueStreamTemplates = [];
    this.valueStreamService.getValueStreamTemplate().subscribe(
      (res) => {
        this.valueStreamTemplates = [];
        this.valueStreamTemplates = res;
        this.valueStreamTemplates = this.valueStreamTemplates.filter(
          (x) => x.isAccessible == true
        );
        console.log(this.valueStreamTemplates);
        // this.onLoadValueStreamTemplate();
        this.valueStreamService.getValueStreamCategory().subscribe(
          (res1) => {
            this.valueStreamCategories = res1;
            this.valueStreamCategories = this.valueStreamCategories.filter(
              (x) =>
                x.valueStreamCategoryName !== "VS Responsible Employee" &&
                x.valueStreamCategoryName !== "SHIFT"
            );

            this.valueStreamService.getValueStream().subscribe(
              (res2) => {
                //this.valueStreams = res2;
                //to make the list/tree view selection for value stream templates

                if (
                  this.selectedItemValueStreamTemplate.filter(
                    (x) => x.visualizationViewModeID == 2
                  ).length == 0
                ) {
                  this.question.assigned_ValueStreamCategoryID = undefined;
                  this.valueStreamCategories = [];
                }

                this.valueStreams = this.valueStreams.filter((r) =>
                  this.selectedItemValueStreamTemplate.find(
                    (x) => x.valueStreamTemplateID == r.valueStreamTemplateID
                  )
                );

                this.valueStreamCategories = this.valueStreamCategories.filter(
                  (r) =>
                    this.selectedItemValueStreamTemplate.find(
                      (x) =>
                        x.valueStreamTemplateID == r.valueStreamTemplateID &&
                        x.visualizationViewModeID == 2
                    )
                );

                this.assessors = this.assessors.filter((t) =>
                  this.selectedItemAssessorTemplate.find(
                    (x) => x.assessorTemplateID == t.assessorTemplateID
                  )
                );

                this.sharedService.hide();
              },
              (err) => {
                console.log(err);
              }
            );
          },
          (err) => {
            console.log(err);
          }
        );
      },
      (err) => {
        console.log(err);
      }
    );
  }

  public getAssessorTemplateList() {
    this.assessorTemplateList = [];
    this.assessorTemplateService.getAssessorTemplates().subscribe(
      (res) => {
        this.assessorTemplateList = res;
        console.log(res);
        this.assessorTemplateList = this.assessorTemplateList.filter(
          (x) => x.isAccessible == true
        );
        console.log(this.assessorTemplateList);
        this.onLoadAssessorTemplate();

        // console.log(this.assessorTemplateList);
        // this.assessorTemplateService.getAssessors().subscribe(res1 => {
        //   this.assessors = res1;
        //    // to limit the assessors based on Assesor ID
        // this.assessors = this.assessors.filter(x =>x.assessorTemplateID == this.question.assigned_AssessorTemplateID);
      },
      (err) => {
        console.log(err);
      }
    );
  }

  //For multi select dropdown - Value stream template
  onSelectValueStreamTemplate(item: ValueStreamTemplate) {
    //this.question.assigned_ValueStreamTemplateID=undefined; 
      this.valueStreamTemplateChange(item.valueStreamTemplateID);
   
    
  }

  onDeSelectValueStreamTemplate(item: ValueStreamTemplate) {
    //this.question.assigned_ValueStreamTemplateID  =  this.question.assigned_ValueStreamTemplateID .filter(r=> r != item.valueStreamTemplateID);

    var valueStreamsCategoryByTemplateID = this.valueStreamCategories
      .filter((x) => x.valueStreamTemplateID != item.valueStreamTemplateID)
      .map((y) => {
        return y.valueStreamCategoryID;
      });
    //Removing Value Streams from Original VS array on Unselecting the Template ID
    this.valueStreamCategories = this.valueStreamCategories.filter(
      (x) => x.valueStreamTemplateID != item.valueStreamTemplateID
    );
    //Removing Value Streams from selected Choice List
    this.selectedItemValueStreamCategories =
      this.selectedItemValueStreamCategories.filter((x) =>
        valueStreamsCategoryByTemplateID.includes(x.valueStreamCategoryID)
      );
    //Identifying the removed Template ValueStreams from ValueStream Array
    var valueStreamsByTemplateID = this.valueStreams
      .filter((x) => x.valueStreamTemplateID != item.valueStreamTemplateID)
      .map((y) => {
        return y.valueStreamID;
      });
    //Removing Value Streams from Original VS array on Unselecting the Template ID
    this.valueStreams = this.valueStreams.filter(
      (x) => x.valueStreamTemplateID != item.valueStreamTemplateID
    );
    //Removing Value Streams from selected Choice List
    this.selectedValueStreams = this.selectedValueStreams.filter((x) =>
      valueStreamsByTemplateID.includes(x.valueStreamID)
    );
  }

  onValueStreamTemplateSelectAll() {
    //this.question.assigned_ValueStreamTemplateID  =  this.valueStreamTemplates.map(r=> r.valueStreamTemplateID);

    var TreeViewModeVS = Object.values(
      Object.assign({}, this.valueStreamTemplates)
    )
      .filter((x) => x.visualizationViewModeID == 2)
      .map((y) => {
        return y.valueStreamTemplateID;
      });
    this.valueStreams = [];
    this.valueStreamCategories = [];
    this.valueStreamService.getValueStreamCategory().subscribe(
      (res) => {
        this.valueStreamCategories = res.filter(
          (x) =>
            TreeViewModeVS.includes(x.valueStreamTemplateID) &&
            x.valueStreamCategoryName.trim() != "VS Responsible Employee" &&
            x.valueStreamCategoryName.trim() != "SHIFT"
        );
        this.valueStreamService.getValueStream().subscribe(
          (res) => {
            this.valueStreams = res;

            //select all Vlaues Streams Based on Value Stream Templates
            //this.valueStreams = this.valueStreams.filter(x =>x.valueStreamCategoryName.trim() == "VS Responsible Employee");
          },
          (err) => {
            console.log(err);
          }
        );
      },
      (err) => {
        console.log(err);
      }
    );
  }

  onValueStreamTemplateDeSelectAll() {
    this.selectedItemValueStreamCategories = [];
    this.selectedItemValueStreamTemplate = [];
    this.selectedValueStreams = [];
    this.valueStreams = [];
    this.valueStreamCategories = [];
  }

  onLoadValueStreamTemplate() {
    this.selectedItemValueStreamTemplate = [];
    // if (!this.question.assigned_ValueStreamTemplateID || this.question.assigned_ValueStreamTemplateID === [])
    //   return;
    if (this.question.valueStreamTemplateNameArL == undefined) {
      return;
    } else {
      this.selectedItemValueStreamTemplate = this.valueStreamTemplates.filter(
        (x) =>
          this.question.valueStreamTemplateNameArL.find(
            (r) => r.vsTemplateID == x.valueStreamTemplateID
          )
      );
    }
  }

  // to load the value streams based on list/tree view in VS Template
  valueStreamTemplateChange(valueStreamTempID: any) {
    //this.valueStreams = [];
    //this.selectedValueStreams = [];

    this.visulizationViewModeID = this.valueStreamTemplates.filter(
      (x) => x.valueStreamTemplateID == valueStreamTempID
    )[0].visualizationViewModeID;

    if (this.visulizationViewModeID == 2) {
      const selectedItem = this.valueStreamCategories.find(
        (x) => x.valueStreamTemplateID == valueStreamTempID
      );

      if (selectedItem === undefined) {
        this.valueStreamService
          .getValueStreamCategoryByTemplateID(valueStreamTempID)
          .subscribe(
            (res) => {
              //this.valueStreamCategories = [];
              //this.valueStreamCategories = res;
              this.valueStreamCategories.push(...res);
              this.valueStreamCategories = this.valueStreamCategories.filter(
                (x) =>
                  x.valueStreamCategoryName !== "VS Responsible Employee" &&
                  x.valueStreamCategoryName !== "SHIFT"
              );
              this.onLoadValueStreamCategories();
            },
            (err) => {
              console.log(err);
            }
          );
      }

      if (selectedItem !== undefined) {
        this.valueStreamService
          .getValueStreamCategoryByTemplateID(valueStreamTempID)
          .subscribe(
            (res) => {
              this.valueStreamCategories = [];
              //this.valueStreamCategories = res;
              this.valueStreamCategories.push(...res);
              this.valueStreamCategories = this.valueStreamCategories.filter(
                (x) =>
                  x.valueStreamCategoryName !== "VS Responsible Employee" &&
                  x.valueStreamCategoryName !== "SHIFT"
              );
              this.onLoadValueStreamCategories();
            },
            (err) => {
              console.log(err);
            }
          );
      }

    } else {
      const selectedItem = this.valueStreams.find(
        (x) => x.valueStreamTemplateID == valueStreamTempID
      );

      if (selectedItem === undefined) {
        this.valueStreamService
          .getValueStreamsByTemplateID(valueStreamTempID)
          .subscribe(
            (res) => {
              //this.valueStreams = [];
              //this.valueStreams = res;
              this.valueStreams.push(...res);
              this.valueStreams = this.valueStreams.filter(
                (x) => x.valueStreamName && x.responsible_UserID
              );
            },
            (err) => {
              console.log(err);
            }
          );
      }

      if (selectedItem !== undefined) {
        this.valueStreamService
          .getValueStreamsByTemplateID(valueStreamTempID)
          .subscribe(
            (res) => {
              this.valueStreams = [];
              //this.valueStreams = res;
              this.valueStreams.push(...res);
              this.valueStreams = this.valueStreams.filter(
                (x) => x.valueStreamName && x.responsible_UserID
              );
            },
            (err) => {
              console.log(err);
            }
          );
      }
    }
  }

  onSelectValueStreamCategories(item: ValueStreamCategory) {
    this.tag.assigned_ValueStreamCategoryID = undefined;
     this.valueStreamCategoryChange(item.valueStreamCategoryID)
  }

  valueStreamCategoryChange(valueStreamCategoryID: any) {
    const selectedItem = this.valueStreams.find(x => x.valueStreamCategoryID == valueStreamCategoryID);

    if(selectedItem === undefined){
      this.valueStreamService.getValueStreamsByCategoryID(valueStreamCategoryID).subscribe(res => {
        this.valueStreams.push(...res);
        //this.valueStreams = res;
        this.valueStreams = this.valueStreams.filter(x =>x.valueStreamName && x.responsible_UserID);
      },
        err => {
          console.log(err);
        });
    }

    if(selectedItem !== undefined){
      this.valueStreamService.getValueStreamsByCategoryID(valueStreamCategoryID).subscribe(res => {
        this.valueStreams =[];
        this.valueStreams.push(...res);
        //this.valueStreams = res;
        this.valueStreams = this.valueStreams.filter(x =>x.valueStreamName && x.responsible_UserID);
      },
        err => {
          console.log(err);
        });
    }
  }


  onLoadValueStreamCategories() {
    this.selectedItemValueStreamCategories = [];

    if (
      !this.question.assigned_ValueStreamCategoryID ||
      this.question.assigned_ValueStreamCategoryID === []
    )
      return;
    for (
      let ind = 0;
      ind < this.question.assigned_ValueStreamCategoryID.length;
      ind++
    ) {
      const selectedItem = this.valueStreamCategories.find(
        (x) =>
          x.valueStreamCategoryID ===
          this.question.assigned_ValueStreamCategoryID[ind]
      );
      if (selectedItem)
        this.selectedItemValueStreamCategories.push(selectedItem);
    }

    // this.valueStreams=this.valueStreams.filter(r=>this.selectedItemValueStreamTemplate.find(x=>x.valueStreamTemplateID== r.valueStreamTemplateID ));
  }

  onSelectAllAssessorTemplate() {
    //this.question.assigned_AssessorTemplateID = this.assessorTemplateList.map(r => {return r.assessorTemplateID});
    this.assessors = [];
    this.assessorTemplateService.getAssessors().subscribe(
      (res) => {
        this.assessors = res;
      },
      (err) => {
        console.log(err);
      }
    );
  }
  onDeSelectAllAssessorTemplate() {
    this.question.assigned_AssessorTemplateID = undefined;
    this.assessors = [];
    this.selectedAssessors = [];
  }

  onItemSelect(item: any) {
    this.onAssessorSelect();
  }
  onSelectAll(items: any) {
    this.onAssessorSelect();
  }
  onassessorOpen () {
    console.log(this.assessors)
    this.isLoading=true;
    this.assessors=JSON.parse(JSON.stringify(this.assessors))
    this.isLoading=false;
  }
  onValuestreamOpen() {
    console.log(this.valueStreams)
    this.isLoading=true;
    this.valueStreams=JSON.parse(JSON.stringify(this.valueStreams))
    this.isLoading=false;
  }
  onValuestreamCategoryOpen(){
   this.isLoading=true;
  this.valueStreamCategories=JSON.parse(JSON.stringify(this.valueStreamCategories))
  this.isLoading=false;
  }
  assessorIDs: string;
  valueStreamIDs: string;
  onAssessorSelect(item?: any) {
    const valueStreamsIDArr = this.valueStreams.map((r) =>
      r.valueStreamID.toString()
    );
    const assessorIDArr = this.assessors.map((r) => r.assessorID.toString());
    if (this.isAssignment) {
      this.selectedValueStreams = this.selectedValueStreams.filter((t) =>
        this.valueStreams.find((x) => x.valueStreamID == t.valueStreamID)
      );

      this.selectedAssessors = this.selectedAssessors.filter((t1) =>
        this.assessors.find((x) => x.assessorID == t1.assessorID)
      );
    }

    this.assessorValueStreamList.assessorIDs = assessorIDArr.toString();
    this.assessorValueStreamList.valueStreamIDs = valueStreamsIDArr.toString();

    // console.log(this.selectedValueStreams);
    // console.log(this.selectedAssessors);
    // console.log(this.selectedTags);
    console.log(this.onAssessorSelectAll);
    //this.mergeassignment();

    this.mergeQuestionAssignment = new Merge();

    if (this.selectedValueStreams.length == 0 && this.onAssessorSelectAll) {
      this.mergeQuestionAssignment.valueStreams = this.valueStreams;
    } else {
      this.mergeQuestionAssignment.valueStreams = this.selectedValueStreams;
    }
    if (this.selectedAssessors.length == 0 && this.onAssessorSelectAll) {
      this.mergeQuestionAssignment.assessors = this.assessors;
    } else {
      this.mergeQuestionAssignment.assessors = this.selectedAssessors;
    }
    //this.mergeQuestionAssignment.assessors = this.selectedAssessors;
    this.mergeQuestionAssignment.tags = this.selectedTags;
    this.mergeQuestionAssignment.questions = this.selectedQuestions;
  }
  onAssessorSelectAll(items: any) {
    this.onAssessorSelect(undefined);
  }

  //For multi select dropdown - Assign tag to assessor template
  onSelectAssessorTemplate(item: AssessorTemplate) {
    if(this.assessors.length ==0) {
      this.assessorTemplateService.getAssessors().subscribe(
        (res) => {
          this.assessors = res;
          this.getAssessorsByTemplateID(item.assessorTemplateID);
        },
        (err) => {
          console.log(err);
        }
      );
    }else {
      this.getAssessorsByTemplateID(item.assessorTemplateID);
    }
    
  }

  onDeSelectAssessorTemplate(item: AssessorTemplate) {
    if (
      !this.selectedItemAssessorTemplate ||
      this.selectedItemAssessorTemplate.length === 0
    ) {
      this.question.assigned_AssessorTemplateID = undefined;
    }

    //this.question.assigned_AssessorTemplateID = this.question.assigned_AssessorTemplateID.filter(x => { x != item.assessorTemplateID });

    var assessorsByTemplateID = this.assessors
      .filter((x) => x.assessorTemplateID != item.assessorTemplateID)
      .map((y) => {
        return y.assessorID;
      });
    //Removing Value Streams from Original VS array on Unselecting the Template ID
    this.assessors = this.assessors.filter(
      (x) => x.assessorTemplateID != item.assessorTemplateID
    );
    //Removing Value Streams from selected Choice List
    this.selectedAssessors = this.selectedAssessors.filter((x) =>
      assessorsByTemplateID.includes(x.assessorID)
    );

    if (this.selectedItemAssessorTemplate.length < 1) {
      this.assessors = [];
      this.selectedAssessors = [];
    }
  }

  onLoadAssessorTemplate() {
    this.selectedItemAssessorTemplate = [];

    if (this.question.assessorTemplateNameArL == undefined) {
      return;
      //this.sharedService.hide();
    } else {
      this.selectedItemAssessorTemplate = this.assessorTemplateList.filter(
        (x) =>
          this.question.assessorTemplateNameArL.find(
            (r) => r.vsTemplateID == x.assessorTemplateID
          )
      );
    }
    this.sharedService.hide();
  }

  public getAssessorsByTemplateID(templateID: any) {
    let selectedItem = this.assessors.find(
      (x) => x.assessorTemplateID == templateID
    );
    this.assessors = this.assessors.filter((t) =>
      this.selectedItemAssessorTemplate.find(
        (x) => x.assessorTemplateID == t.assessorTemplateID
      )
    );
    if (selectedItem == undefined) {
      this.assessorTemplateService
        .getAssessorsByTemplateID(templateID)
        .subscribe(
          (res) => {
            let X = this.assessors;
            this.assessors = res;
            this.assessors.push(...X);
            console.log(this.assessors);
          },
          (err) => {
            console.log(err);
          }
        );
    }

    if (selectedItem !== undefined) {
      this.assessorTemplateService
        .getAssessorsByTemplateID(templateID)
        .subscribe(
          (res) => {
            this.assessors=[]
            this.assessors.push(...res);
            console.log(this.assessors);
          },
          (err) => {
            console.log(err);
          }
        );
    }


  }
  //to clear Unselected tag or question  bases on selection
  clearTagQuestion(value: any) {
    //this.reloadMerge();

    //
    if (value) {
      this.selectedquestionorTags = value;
      if (value == 1) {
        this.tagUnChecked = true;
        this.questionUnChecked = false;
      } else {
        this.questionUnChecked = true;
        this.tagUnChecked = false;
      }
    }
  }

  searchTag() {
    let text = this.tag.searchText.toLowerCase();
    if (text) {
      //if the value is there in the search tag field
      if (this.availableTags.length > 0) {
        text = text.toLowerCase();
        let filteredTags = this.availableTags.filter(
          (x) => x.tagName.toLowerCase().indexOf(text) > -1
        );
        this.availableTags = []; //claers the tags to update the taglist based on filter
        for (let tg of filteredTags) {
          let x = this.selectedTags.filter((x) => x.tagID == tg.tagID);
          if (x.length < 1) {
            this.availableTags.push(tg);
          }
        }
      }
      if (!text) {
        if (!this.availableTags || this.availableTags.length < 1) {
          this.onAssessorSelect(null);
          // this.getavailabletags();
          this.availableTags = this.allavailableTags;
        }
      }
    } else {
      //to load all the tags
      this.onAssessorSelect(null);
      // this.getavailabletags();
      this.availableTags = this.allavailableTags;
    }
  }

  searchTagOrQuestion() {
    let text = this.quest.searchText;
    if (text) {
      text = text.toLowerCase();
      //this.availableTags = this.availableTags.filter(x => x.tagName.toLowerCase().indexOf(text) > -1);
      this.availableQuestions = this.availableQuestions.filter(
        (x) => x.questionText.toLowerCase().indexOf(text) > -1
      );
    } else {
      //this.onAssessorSelect();
      this.getTagQuestionList();
    }
  }

  filterTagOrQuestion() {
    let text = this.tag.filterText;
  }

  removeTag(tag: Tag) {
    if (tag !== undefined && Object.keys(tag).length !== 0) {
      let id = tag.tagID;
      this.selectedTags = this.selectedTags.filter((x) => x.tagID !== id);
      this.availableTags.push(tag);
    }
  }

  removeQuestion(question: Question) {
    if (question !== undefined && Object.keys(question).length !== 0) {
      let id = question.questionID;
      this.selectedQuestions = this.selectedQuestions.filter(
        (x) => x.questionID !== id
      );
      this.orderSelectedQuestions = this.orderSelectedQuestions.filter(
        (x) => x.questionID !== id
      ); //to remove from questions order
      this.availableQuestions.push(question);
    }
  }

  //to clear Unselected Assignment or Tag or Proxy  bases on selection
  clearARP(value: any) {
    //this.reloadMerge();
    //
    if (value) {
      this.selectedassignmentremovalorproxy = value;
      if (value == 3) {
        this.assignmentUnChecked = true;
        this.removalUnChecked = false;
        this.proxyUnChecked = false;
      } else if (value == 4) {
        this.assignmentUnChecked = false;
        this.removalUnChecked = true;
        this.proxyUnChecked = false;
      } else {
        this.assignmentUnChecked = false;
        this.removalUnChecked = false;
        this.proxyUnChecked = true;
      }
    }

    console.log(
      this.selectedquestionorTags,
      this.selectedassignmentremovalorproxy,
      "Combination"
    );

    if (this.selectedassignmentremovalorproxy == 5) {
      this.questionproxyselected = true;
    } else {
      this.questionproxyselected = false;
    }
  }

  lockTag() {
    // this.tagService.tag = this.tag;
    this.router.navigate([environment.home + "/taglist/tag-lock"]);
  }

  public getTagQuestionList() {
    this.questionService.getQuestions().subscribe(
      (res) => {
        this.questionList = res;
        this.availableQuestions = this.questionList;
        this.availableQuestions = this.availableQuestions.filter(
          (x) => x.isAccessible == true
        );
        // if(this.tag.tagTypeID == 1){
        //  this.availableQuestions = this.questionList;
        // }
      },
      (err) => {
        console.log(err);
      }
    );
  }

  public questionSelected(question: Question) {
    if (this.selectedQuestions == undefined) {
      this.selectedQuestions = [];
    }
    var x = this.selectedQuestions.filter(
      (x) => x.questionID == question.questionID
    );
    if (x.length < 1) {
      this.selectedQuestions.push(question);
    }
    this.availableQuestions = this.availableQuestions.filter(
      (x) => x.questionID !== question.questionID
    );

    //to display the questions in branch order
    if (this.orderSelectedQuestions == undefined) {
      this.orderSelectedQuestions = [];
    }
    var x = this.orderSelectedQuestions.filter(
      (x) => x.questionID == question.questionID
    );
    if (x.length < 1) {
      this.orderSelectedQuestions.push(question);
    }
  }

  getavailabletags() {
    this.tagService.fetchProcessConfirmationTags().subscribe((res) => {
      if (res && res.length > 0) {
        if (this.availableTags && this.availableTags.length > 1) {
          for (let tag of res) {
            if (
              this.availableTags.filter((x) => x.tagID == tag.tagID).length < 1
            ) {
              this.availableTags.push(tag);
              this.availableTags = this.availableTags.filter(
                (x) => x.isAccessible == true
              );
              this.allavailableTags = JSON.parse(
                JSON.stringify(this.availableTags)
              );
            }
          }
        } else {
          this.availableTags = res;
          this.availableTags = this.availableTags.filter(
            (x) => x.isAccessible == true
          );
          this.allavailableTags = JSON.parse(
            JSON.stringify(this.availableTags)
          );
        }
        //to filter the available tags based on selected tags
        if (this.selectedTags && this.selectedTags.length > 0) {
          for (let tag of this.selectedTags) {
            if (this.availableTags && this.availableTags.length > 0) {
              this.availableTags = this.availableTags.filter(
                (x) => x.tagID !== tag.tagID
              );
              this.availableTags = this.availableTags.filter(
                (x) => x.isAccessible == true
              );
              this.allavailableTags = JSON.parse(
                JSON.stringify(this.availableTags)
              );
            }
          }
        }
      }
      //this.sharedService.hide();
    });
  }

  //for tag selection

  public getTagList() {
    this.tagService.getTags().subscribe(
      (res) => {
        this.tagList = res;
        this.tagList = this.tagList.filter((x) => x.isAccessible == true);
        //this.sharedService.hide();
      },
      (err) => {
        console.log(err);
      }
    );
  }

  public tagSelected(tag: Tag) {
    if (this.selectedTags == undefined) {
      this.selectedTags = [];
    }
    this.selectedTags.push(tag);
    this.availableTags = this.availableTags.filter(
      (x) => x.tagID !== tag.tagID
    );
    console.log(this.selectedTags);
  }

  //On Save Merge Setting
  saveMergettings() {
    this.isDisabled = false;

    //to validate mandatory valuestream ,assessors, Question and Tags  selections
    // if (!this.mergeQuestionAssignment.valueStreams || this.mergeQuestionAssignment.valueStreams.length < 1 && !this.proxyUnChecked) {
    //   this.alertText = this.labels.default.selectValueStream;
    //   this.modalService.show(this.warningModal);
    //   $("modal-container").removeClass("fade");
    //   $(".modal-dialog").addClass("modalSize");
    //   this.isDisabled = true;
    //   return;
    // }

    // if (!this.mergeQuestionAssignment.assessors || this.mergeQuestionAssignment.assessors.length < 1  && !this.proxyUnChecked) {
    //   this.alertText = this.labels.default.fillMandatoryAssessors;
    //   this.modalService.show(this.warningModal);
    //   $("modal-container").removeClass("fade");
    //   $(".modal-dialog").addClass("modalSize");
    //   this.isDisabled = true;

    //   return;

    // }

    if (this.assignmentUnChecked && this.tagUnChecked && !this.proxyUnChecked)
      if (
        !this.mergeQuestionAssignment.questions ||
        (this.mergeQuestionAssignment.questions.length < 1 &&
          !this.proxyUnChecked &&
          this.selectedQuestions.length < 1)
      ) {
        this.alertText = this.labels.default.selectAleastOneQuestion;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;
      } else if (
        this.mergeQuestionAssignment.valueStreams.length < 1 &&
        this.mergeQuestionAssignment.assessors.length < 1 &&
        this.mergeQuestionAssignment.tags.length < 1
      ) {
        this.alertText = this.labels.default.mergeoperation;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;

        return;
      } else {
        this.mergeService
          .mergeQuestionAssignment(this.mergeQuestionAssignment)
          .subscribe(
            (res) => {
              if (res.resultCode == 0) {
                this.sharedService.show();
                this.alertText = this.labels.default.saveSuccessfully;
                this.modalService.show(this.successModal);
                $("modal-container").removeClass("fade");
                $(".modal-dialog").addClass("modalSize");
                this.reloadMerge();
                this.sharedService.hide();
                return;
              }
            },
            (err) => {
              this.alertText = this.labels.default.insertOpertionFailed;
              this.modalService.show(this.warningModal);
              $("modal-container").removeClass("fade");
              $(".modal-dialog").addClass("modalSize");

              return;
            }
          );
      }

    if (
      this.assignmentUnChecked &&
      this.questionUnChecked &&
      !this.proxyUnChecked
    )
      if (
        !this.mergeQuestionAssignment.tags ||
        (this.mergeQuestionAssignment.tags.length < 1 &&
          !this.proxyUnChecked &&
          this.selectedTags.length < 1)
      ) {
        this.alertText = this.labels.default.selectAleastOneTag;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;
      } else if (
        this.mergeQuestionAssignment.valueStreams.length < 1 &&
        this.mergeQuestionAssignment.assessors.length < 1 &&
        this.mergeQuestionAssignment.questions.length < 1
      ) {
        this.alertText = this.labels.default.mergeoperation;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;

        return;
      } else {
        this.mergeService
          .mergeTagAssignment(this.mergeQuestionAssignment)
          .subscribe(
            (res) => {
              if (res.resultCode == 0) {
                this.sharedService.show();
                this.alertText = this.labels.default.saveSuccessfully;
                this.modalService.show(this.successModal);
                $("modal-container").removeClass("fade");
                $(".modal-dialog").addClass("modalSize");
                this.reloadMerge();
                this.sharedService.hide();

                return;
              }
            },
            (err) => {
              this.alertText = this.labels.default.insertOpertionFailed;
              this.modalService.show(this.warningModal);
              $("modal-container").removeClass("fade");
              $(".modal-dialog").addClass("modalSize");
              // this.sharedService.hide();
              return;
            }
          );
      }

    if (this.removalUnChecked && this.tagUnChecked && !this.proxyUnChecked)
      if (
        !this.mergeQuestionAssignment.questions ||
        (this.mergeQuestionAssignment.questions.length < 1 &&
          !this.proxyUnChecked &&
          this.selectedQuestions.length < 1)
      ) {
        this.alertText = this.labels.default.selectAleastOneQuestion;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;
      } else if (
        this.mergeQuestionAssignment.valueStreams.length < 1 &&
        this.mergeQuestionAssignment.assessors.length < 1 &&
        this.mergeQuestionAssignment.tags.length < 1
      ) {
        this.alertText = this.labels.default.mergeoperation;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;

        return;
      } else {
        this.mergeService
          .mergeQuestionRemoval(this.mergeQuestionAssignment)
          .subscribe(
            (res) => {
              if (res.resultCode == 0) {
                this.sharedService.show();
                this.alertText = this.labels.default.saveSuccessfully;
                this.modalService.show(this.successModal);
                $("modal-container").removeClass("fade");
                $(".modal-dialog").addClass("modalSize");
                this.reloadMerge();
                this.sharedService.hide();

                return;
              }
            },
            (err) => {
              this.alertText = this.labels.default.insertOpertionFailed;
              this.modalService.show(this.warningModal);
              $("modal-container").removeClass("fade");
              $(".modal-dialog").addClass("modalSize");
              // this.sharedService.hide();
              return;
            }
          );
      }

    if (this.removalUnChecked && this.questionUnChecked && !this.proxyUnChecked)
      if (
        !this.mergeQuestionAssignment.tags ||
        (this.mergeQuestionAssignment.tags.length < 1 &&
          !this.proxyUnChecked &&
          this.selectedTags.length < 1)
      ) {
        this.alertText = this.labels.default.selectAleastOneTag;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;
      } else if (
        this.mergeQuestionAssignment.valueStreams.length < 1 &&
        this.mergeQuestionAssignment.assessors.length < 1 &&
        this.mergeQuestionAssignment.questions.length < 1
      ) {
        this.alertText = this.labels.default.mergeoperation;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;

        return;
      } else {
        this.mergeService
          .mergeTagRemoval(this.mergeQuestionAssignment)
          .subscribe(
            (res) => {
              if (res.resultCode == 0) {
                this.sharedService.show();
                this.alertText = this.labels.default.saveSuccessfully;
                this.modalService.show(this.successModal);
                $("modal-container").removeClass("fade");
                $(".modal-dialog").addClass("modalSize");
                this.reloadMerge();
                this.sharedService.hide();

                return;
              }
            },
            (err) => {
              this.alertText = this.labels.default.insertOpertionFailed;
              this.modalService.show(this.warningModal);
              $("modal-container").removeClass("fade");
              $(".modal-dialog").addClass("modalSize");
              // this.sharedService.hide();
              return;
            }
          );
      }

    if (this.proxyUnChecked && this.tagUnChecked) {
      this.saveLockSettings();
    }

    if (this.proxyUnChecked && this.questionUnChecked) {
      this.saveLockSettings();
    }
    //
  }

  public closeAlertModal() {
    if (document.getElementsByTagName("modal-container").length > 1) {
      document
        .getElementsByTagName("modal-container")
        [
          document.getElementsByTagName("modal-container").length - 1
        ].parentNode.removeChild(
          document.getElementsByTagName("modal-container")[
            document.getElementsByTagName("modal-container").length - 1
          ]
        );
    } else {
      document
        .getElementsByTagName("modal-container")[0]
        .parentNode.removeChild(
          document.getElementsByTagName("modal-container")[0]
        );
      if (document.getElementsByTagName("bs-modal-backdrop").length > 0) {
        document
          .getElementsByTagName("bs-modal-backdrop")[0]
          .parentNode.removeChild(
            document.getElementsByTagName("bs-modal-backdrop")[0]
          );
      }
      document.querySelector("body").classList.remove("modal-open");
    }
  }

  /** for Proxy */

  removeProxy(event: any) {
    let ntid = event.target.id;
    this.proxies = this.proxies.filter((x) => x.ntid !== ntid);
  }

  //for new Active Directory Search
  user: any;
  proxies: any = [];
  activeDirectoryData: any[];

  onChangeSearch() {
    let user = new User();
    user.firstName = this.user;
    this.commonService.activeDirectoryByName(user).subscribe(
      (res) => {
        this.activeDirectoryData = [];
        this.activeDirectoryData = res;
      },
      (err) => console.error(err)
    );
  }

  selectUser(user: any) {
    if (user !== null) {
      let x = this.proxies.filter((x) => x.ntid == user.ntid);
      if (x.length == 0) this.proxies.push(user);
      console.log(this.proxies);
    }

    this.activeDirectoryData = [];
    this.user = undefined;
  }

  saveLockSettings() {
    if (
      this.selectedQuestions.length < 1 &&
      this.proxyUnChecked &&
      this.tagUnChecked
    ) {
      this.alertText = this.labels.default.selectAleastOneQuestion;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      this.isDisabled = true;

      return;
    }

    if (
      this.selectedTags.length < 1 &&
      this.proxyUnChecked &&
      this.questionUnChecked
    ) {
      this.alertText = this.labels.default.selectAleastOneTag;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      this.isDisabled = true;

      return;
    }
    if (this.tagUnChecked) {
      this.questionProxy = new MergeProxy();
      this.questionProxy.questions = this.selectedQuestions;
      this.questionProxy.proxies = this.proxies;

      this.mergeService.insertQuestionProxy(this.questionProxy).subscribe(
        (res) => {
          if (res.resultCode == 0) {
            this.sharedService.show();
            this.alertText = this.labels.default.saveSuccessfully;
            this.modalService.show(this.successModal);
            $("modal-container").removeClass("fade");
            $(".modal-dialog").addClass("modalSize");
            this.reloadMerge();
            this.sharedService.hide();
            return;
          }
        },
        (err) => {
          this.alertText = this.labels.default.insertOpertionFailed;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          // this.sharedService.hide();
          return;
        }
      );
    }

    if (this.questionUnChecked) {
      this.tagProxy = new MergeProxy();
      this.tagProxy.tags = this.selectedTags;
      this.tagProxy.proxies = this.proxies;

      this.mergeService.insertTagProxy(this.tagProxy).subscribe(
        (res) => {
          if (res.resultCode == 0) {
            this.sharedService.show();
            this.alertText = this.labels.default.saveSuccessfully;
            this.modalService.show(this.successModal);
            $("modal-container").removeClass("fade");
            $(".modal-dialog").addClass("modalSize");
            this.reloadMerge();
            this.sharedService.hide();
            return;
          }
        },
        (err) => {
          this.alertText = this.labels.default.insertOpertionFailed;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          // this.sharedService.hide();
          return;
        }
      );
    }
  }

  reloadMerge() {
    this.selectedItemValueStreamTemplate = [];
    this.selectedItemValueStreamCategories = [];
    this.selectedValueStreams = [];
    this.selectedItemAssessorTemplate = [];
    this.selectedAssessors = [];
    this.selectedQuestions = [];
    this.selectedTags = [];
    // this.mergeQuestionAssignment.tags = [];
    // this.mergeQuestionAssignment.questions = [];
    // this.mergeQuestionAssignment.assessors = [];
    // this.mergeQuestionAssignment.valueStreams = [];
    this.getTagQuestionList();
    this.availableTags = this.allavailableTags;
  }
}
