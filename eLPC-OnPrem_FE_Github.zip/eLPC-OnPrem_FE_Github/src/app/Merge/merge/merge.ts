import { ValueStream, ValueStreamCategory, ValueStreamTemplate } from 'src/app/Valuestream/valuestreams/valuestreamtemplate';
import { Assessor,AssessorTemplate } from 'src/app/Assessor/assessor/assessortemplate';
import { Tag } from 'src/app/Tag/tag/tag';
import { User } from 'src/app/main/body/shared/common';
import { AssessorLockComponent } from 'src/app/Assessor/assessor/assessor.lock.component';
import { Question } from 'src/app/Datapool/QuestionModule/questions/question';

export class Merge {
  questions?:Question[];
  valueStreams?: ValueStream[];
  assessors?: Assessor[];
  tags?: Tag[];
  resultCode: number;

}

export class MergeProxy {
  id?: number;
  questions?:Question[];
  tags?: Tag[];
  proxies: User[];
  createdBy_NTID?: string;
  modifiedBy_NTID?: string;
  resultCode: number;
  ntid?: string;
  userName?: string;
}