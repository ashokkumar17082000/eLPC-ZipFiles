import { NgModule ,CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CustomModeComponent } from './custom-mode/custom-mode.component';
const routes: Routes = [
  { path: '', component: CustomModeComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],

})
export class CustommodeRoutingModule { }
