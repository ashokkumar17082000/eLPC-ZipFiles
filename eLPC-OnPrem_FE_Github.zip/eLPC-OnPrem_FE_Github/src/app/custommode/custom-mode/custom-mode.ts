import { Tag } from "src/app/Tag/tag/tag";
import { Question } from "src/app/Datapool/QuestionModule/questions/question";

export class CustomMode {
    customModeID:number;
    createdBy_UserID:number;
    createdAt:Date;
    assignedTags :Tag[];
    assignedQuestions:Question[];
    isCompleted:boolean;
    isDeleted:boolean;
    questions:Question[];
    tags:Tag[];
    tagName:string;
    tagID:string;
    createdBy_NTID:string;
    
 tag?:Tag;
 question:Question;
    
}
