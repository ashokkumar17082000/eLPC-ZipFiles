import { Injectable } from "@angular/core";
// import * as english from "../assets/localize/eng.json";
// import * as german from "../assets/localize/de.json";
// import * as chinese from "../assets/localize/chinese.json";
// import * as romanian from "../assets/localize/romanian.json";
// import * as portuguese from "../assets/localize/portuguese.json";
// import * as french from "../assets/localize/french.json";
// import * as thai from "../assets/localize/thai.json";
// import * as polish from "../assets/localize/polish.json";
// import * as russian from "../assets/localize/russian.json";
// import * as spanish from "../assets/localize/spanish.json";
// import * as japanese from "../assets/localize/japanese.json";
// import * as malay from "../assets/localize/malay.json";
// import * as dutch from "../assets/localize/dutch.json";
// import * as hungarian from "../assets/localize/hungarian.json";
// import * as italian from "../assets/localize/italian.json";
import { HttpClient } from "@angular/common/http";
import { Subject } from "rxjs";
import { usercustomIcon } from "./UserProfile/userprofile-c/userProfile";

@Injectable({
  providedIn: "root",
})
export class LanguageService {
  languageFile: string = "eng";
  localizeLanguage: Object = "EN";
  LanguageChange: Subject<Object> = new Subject<Object>();
  public userCustomIconList: usercustomIcon[] = [];
  constructor(private http: HttpClient) {}

  public async changeLanguage(language) {
    if (language == "EN") {
      this.languageFile = "eng";
    } else if (language == "DE") {
      this.languageFile = "de";
    } else if (language == "ZH") {
      this.languageFile = "chinese";
    } else if (language == "RO") {
      this.languageFile = "romanian";
    } else if (language == "FR") {
      this.languageFile = "french";
    } else if (language == "PT") {
      this.languageFile = "portuguese";
    } else if (language == "TH") {
      this.languageFile = "thai";
    } else if (language == "RU") {
      this.languageFile = "russian";
    } else if (language == "PL") {
      this.languageFile = "polish";
    } else if (language == "ES") {
      this.languageFile = "spanish";
    } else if (language == "JA") {
      this.languageFile = "japanese";
    } else if (language == "MS") {
      this.languageFile = "malay";
    } else if (language == "NL") {
      this.languageFile = "dutch";
    } else if (language == "HU") {
      this.languageFile = "hungarian";
    } else if (language == "IT") {
      this.languageFile = "italian";
    } else if (language == "KO") {
      this.languageFile = "korean";
    } else if (language == "CS") {
      this.languageFile = "czech";
    } else if (language == "TR") {
      this.languageFile = "turkish";
    } else if (language == "ID") {
      this.languageFile = "indonesian";
    } else if (language == "SR") {
        this.languageFile = "serbian";
    }else if (language == "SK") {
      this.languageFile = "slovak";
  }
  else{
    this.languageFile = "eng";
  }
  try {
    var _this = this;
    var data = await this.getJSON(_this.languageFile);
    var obj: any = { default: data };
    _this.localizeLanguage = obj;
    _this.LanguageChange.next(_this.localizeLanguage);
    return _this.localizeLanguage;
  } catch (error)
  {
    console.error('Failed to load language file:', error);
    await this.retryChangeLanguage(language, 3); // Retry 3 times
  }
    // var _this = this;
    // var data = await this.getJSON(_this.languageFile);
    // var obj: any = { default: data };
    // _this.localizeLanguage = obj;
    // _this.LanguageChange.next(_this.localizeLanguage);
    // return _this.localizeLanguage;
  }

  public async getJSON(languageFile: string) {
    return await this.http
      .get(
        "assets/localize/" +
          languageFile +
          ".json"
          // ?_cache_buster=" +
          // new Date().getTime()
      )
      .toPromise();
  }

  private async retryChangeLanguage(language: string, retries: number): Promise<any> {
    for (let attempt = 1; attempt <= retries; attempt++) {
      try {
        console.log(`Retrying to load language file... Attempt ${attempt}`);
        const data = await this.getJSON(this.languageFile);
        const obj: any = data;
        console.log('Language Data:', obj); // Log for debugging
        this.localizeLanguage = obj;
        this.LanguageChange.next(this.localizeLanguage);
        return this.localizeLanguage;
      } catch (error) {
        console.error(`Retry attempt ${attempt} failed:`, error);
      }
    }
    console.error('All retry attempts failed. Falling back to default language.');
    // Optionally, load a default language file or show an error message
  }

  public getdropdownList(value: any) {
    this.userCustomIconList = [];
    // if (value && value.default)
      //{
      console.log('Localize Language:', value.default); // Log for debugging
    this.userCustomIconList.push(
    {
      customeIconID: 0,
      customIconName: "None",
      customIconEnable: false,
      customIconimgSRCEnable: false,
      customIconRoutePath: "",
      customIconLogo: "",
    },
    {
      customeIconID: 1,
      customIconName:  value!== undefined || value.default!== undefined ? value.default.shuffleMode:'shuffleMode',
      customIconEnable: true,
      customIconimgSRCEnable: true,
      customIconRoutePath: "../" + "processConfirmation",
      customIconLogo: "assets/image/Material.png",
    },
    {
      customeIconID: 2,
      customIconName: value!== undefined || value.default!== undefined ? value.default.customMode :'CustomMode',
      customIconEnable: true,
      customIconimgSRCEnable: false,
      customIconRoutePath: "../" + "customMode",
      customIconLogo: "user",
    },
    {
      customeIconID: 3,
      customIconName: value!== undefined || value.default!== undefined ? value.default.tagMode :'TagMode',
      customIconEnable: true,
      customIconimgSRCEnable: false,
      customIconRoutePath: "../" + "tagMode",
      customIconLogo: "wand",
    },
    {
      customeIconID: 4,
      customIconName: value!== undefined || value.default!== undefined ? value.default.menu_calendar:'Calendar',
      customIconEnable: true,
      customIconimgSRCEnable: false,
      customIconRoutePath: "../" + "calendar",
      customIconLogo: "calendar",
    },
    {
      customeIconID: 5,
      customIconName: value!== undefined || value.default!== undefined ? value.default.subMenuVS:'Valuestreams',
      customIconEnable: true,
      customIconimgSRCEnable: false,
      customIconRoutePath: "../" + "valuestreams",
      customIconLogo: "industry",
    },
    {
      customeIconID: 6,
      customIconName: "Assessors",//value!== undefined || value.default!== undefined ? value.default.subMenuAssessor:'Assessors',
      customIconEnable: true,
      customIconimgSRCEnable: true,
      customIconRoutePath: "../" + "assessors",
      customIconLogo: "assets/image/assessor.svg",
    },
    {
      customeIconID: 7,
      customIconName: value!== undefined || value.default!== undefined ? value.default.subMenuQuestion:'Questions',
      customIconEnable: true,
      customIconimgSRCEnable: false,
      customIconRoutePath: "../" + "datapool/questions",
      customIconLogo: "question",
    },
    {
      customeIconID: 8,
      customIconName: value!== undefined || value.default!== undefined ? value.default.subMenuTag:'Tag',
      customIconEnable: true,
      customIconimgSRCEnable: false,
      customIconRoutePath: "../" + "taglist",
      customIconLogo: "bookmark",
    },
    {
      customeIconID: 9,
      customIconName: value!== undefined || value.default!== undefined ? value.default.merge:'merge',
      customIconEnable: true,
      customIconimgSRCEnable: true,
      customIconRoutePath: "../" + "merge",
      customIconLogo: "assets/svg/shrinking-arrows-circle.svg",
    },
    {
      customeIconID: 10,
      customIconName: value!== undefined || value.default!== undefined ? value.default.subMenuRecycle:'RecycleBin',
      customIconEnable: true,
      customIconimgSRCEnable: true,
      customIconRoutePath: "../" + "recyclebin",
      customIconLogo: "assets/svg/shrinking-arrows-circle.svg",
    },
    {
      customeIconID: 11,
      customIconName: value!== undefined || value.default!== undefined ? value.default.subMenuDataPool + " - " + value.default.answers :'DataPool Question',
      customIconEnable: true,
      customIconimgSRCEnable: false,
      customIconRoutePath: "../" + "datapool",
      customIconLogo: "question",
    },
    {
      customeIconID: 12,
      customIconName: value!== undefined || value.default!== undefined ? value.default.subMenuDataPool + " - " + value.default.deviationName:'DataPool Deviation',
      customIconEnable: true,
      customIconimgSRCEnable: false,
      customIconRoutePath: "../" + "deviationpool",
      customIconLogo: "clipboard",
    },
    {
      customeIconID: 13,
      customIconName: value!== undefined || value.default!== undefined ? value.default.subMenuDataPool + " - " + value.default.menu_calendar :'Datapool Calendar',
      customIconEnable: true,
      customIconimgSRCEnable: false,
      customIconRoutePath: "../" + "calendarListing",
      customIconLogo: "calendar-clock",
    },
    {
      customeIconID: 14,
      customIconName: value!== undefined || value.default!== undefined ? value.default.menu_superOPL: 'SuperOpl',
      customIconEnable: true,
      customIconimgSRCEnable: false,
      customIconRoutePath: "../" + "superOPL",
      customIconLogo: "calendar-clock",
    },
    {
      customeIconID: 15,
      customIconName: value!== undefined || value.default!== undefined ? value.default.menu_reports_Admin :'Admin Report',
      customIconEnable: true,
      customIconimgSRCEnable: false,
      customIconRoutePath: "../" + "adminReport",
      customIconLogo: "clipboard-list",
    },
    {
      customeIconID: 16,
      customIconName:value!== undefined || value.default!== undefined ? value.default.export :'Export',
      customIconEnable: true,
      customIconimgSRCEnable: false,
      customIconRoutePath: "../" + "adminReport/powerBIExport",
      customIconLogo: "clipboard",
    },
        
    {
      customeIconID: 17,
      customIconName:  value!== undefined || value.default!== undefined ? value.default.launchpad : 'LaunchPad',
      customIconEnable: true,
      customIconimgSRCEnable: false,
      customIconRoutePath: "../" + "launchpad",
      customIconLogo: "clipboard",
    },
    {
      customeIconID: 18,
      customIconName:  value!== undefined || value.default!== undefined ? value.default.launchpadsetting : 'launchPadSetting',
      customIconEnable: true,
      customIconimgSRCEnable: false,
      customIconRoutePath: "../" + "launchpad/launchpadsettings",
      customIconLogo: "clipboard",
    },
    {
      customeIconID: 19,
      customIconName: value!== undefined || value.default!== undefined ? value.default.menu_UserProfile :'UserProfile',
      customIconEnable: true,
      customIconimgSRCEnable: false,
      customIconRoutePath: "../" + "userProfile",
      customIconLogo: "user",
    },
    {
      customeIconID: 20,
      customIconName: value!== undefined || value.default!== undefined ? value.default.infoAndHelp :'Info and Help',
      customIconEnable: true,
      customIconimgSRCEnable: false,
      customIconRoutePath: "../" + "infoAndHelp",
      customIconLogo: "welcome",
    }
   

       );
  //  } else
  //     {
  //       console.error('Invalid value provided to getdropdownList:', value);
  //     }
    
    return this.userCustomIconList;
  }
}
