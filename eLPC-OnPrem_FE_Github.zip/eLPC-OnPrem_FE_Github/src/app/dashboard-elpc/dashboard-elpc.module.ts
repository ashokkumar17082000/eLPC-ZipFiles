import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from 'src/app/dashboard-elpc/dashboard/dashboard.component';
import { DashboardElpcRoutingModule } from './dashboard-elpc-routing.module';


@NgModule({
  declarations: [DashboardComponent],
  imports: [
    CommonModule,
    DashboardElpcRoutingModule
  ],
  exports: [DashboardComponent], 
  schemas: [CUSTOM_ELEMENTS_SCHEMA] // Add this line
})
export class DashboardElpcModule { }
