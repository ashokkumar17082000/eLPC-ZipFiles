import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
//import { SharedService } from '../../../service/shared.service';
import { SharedService } from 'src/app/service/shared.service';
//import { LanguageService } from '../../../language.service';
import { LanguageService } from 'src/app/language.service';
import { UserProfileService } from 'src/app/service/user-profile.service';
//import { usercustomIcon } from '../user-profile/userProfile';
import { usercustomIcon } from 'src/app/UserProfile/userprofile-c/userProfile';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  role: any;
  displayName: any;
  labels: any;
  _subscription: any;
  firstCustomIcon:any;
  secondCustomIcon:any;
  constructor(private sharedService: SharedService, private local_label: LanguageService,
    private userProfileService: UserProfileService,
  ) {
    this.role = this.sharedService.role;
    this.displayName = this.sharedService.displayName;
    this.labels = local_label.localizeLanguage;
    this._subscription = local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
    });
  }

  /** Load the initial data for the dashboard to show the error message 'No matching records found for this filter criteria'
   *  if data does not exists */
  ngOnInit() {
    this.sharedService.setIconName("Shuffle Mode");
    this.sharedService.hide();
    this.getUserProfileVSAS();
  }

  ngAfterViewInit()
  {
    setTimeout(() => {
      this.sharedService.setIcon("assets/image/Material.svg");
    }, 100);
  }

  public getUserProfileVSAS() {
    this.userProfileService.getUserProfileVSAS().subscribe(res => {
      console.log(res)   
      if(res!==undefined && res.usercustomIcon!== undefined && res.usercustomIcon[0]!==undefined && res.usercustomIcon[0].customeIconID!==undefined &&res.usercustomIcon[0].customeIconID!==null){
        this.firstCustomIcon=res.usercustomIcon[0].customeIconID;
      }
      if(res!==undefined && res.usercustomIcon!== undefined && res.usercustomIcon[1]!==undefined &&res.usercustomIcon[1].customeIconID!==undefined &&res.usercustomIcon[1].customeIconID!==null){
        this.secondCustomIcon=res.usercustomIcon[1].customeIconID;
      }
      //debugger;
      console.log("first",this.firstCustomIcon)
      console.log("second",this.secondCustomIcon)
      this.sharedService.hide();

    }, err => {
      console.log(err);
      //this.getValueStreamList(); this.getAssessorTemplateList(); 
    });
  }


}
