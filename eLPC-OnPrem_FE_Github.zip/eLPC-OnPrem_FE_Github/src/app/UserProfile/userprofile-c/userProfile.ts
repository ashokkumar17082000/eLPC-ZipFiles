import { Assessor, AssessorTemplate } from "src/app/Assessor/assessor/assessortemplate";
import { ValueStream, ValueStreamCategory, ValueStreamTemplate } from "src/app/Valuestream/valuestreams/valuestreamtemplate";

export class UserProfileValueStreamAssessor {
  userProfileValueStream : UserProfileValueStream[] = [];
  userProfileAssessor: UserProfileAssessor[] = [];
  usercustomIcon: usercustomIcon[] = [];
}

export class usercustomIcon
{
  customeIconID: number;
  customIconName: string ;
  customIconEnable:boolean;
  customIconimgSRCEnable:boolean ;
  customIconRoutePath :string
  customIconLogo: string 
}

export class UserProfileUpdateVSAS {
  sessionID?: string;

  valueStreamTemplateID?: number
  valueStreamID?: number;
  isForgotValueStream?: boolean;
  
  assessorTemplateID?: number
  assessorID?: number;
  isForgotAssessor?: boolean;
}

export class UserProfileValueStream {
    userProfileValueStreamID?: number;
    plantID?: number;
    rowID?: number;

    valueStreamTemplateID?: number
    valueStreamTemplateArr?: ValueStreamTemplate[] = [];
    selectedItemValueStreamTemplate: ValueStreamTemplate[] = [];

    valueStreamCategoryID?: number;
    valueStreamCategoryArr?: ValueStreamCategory[] = [];
    selectedItemvalueStreamCategory: ValueStreamCategory[] = [];

    valueStreamID?: number;
    valueStreamArr?: ValueStream[] = [];
    selectedItemvalueStream: ValueStream[] = [];

    isForgotValueStream?: boolean;
    isDeleted?: boolean;
    isLastRow?: boolean;

    sessionID?: string;

    user_NTID?: string;
    modifiedAt?: Date;
    createdAt?: Date;

  }

  export class UserProfileAssessor {
    userProfileAssessorID?: number;
    plantID?: number;
    rowID?: number;

    assessorTemplateID?: number
    assessorTemplateArr?: AssessorTemplate[] = [];
    selectedItemAssessorTemplate: AssessorTemplate[] = [];

    assessorID?: number;
    assessorArr?: Assessor[] = []; 
    selectedItemAssessor: Assessor[] = [];

    isForgotAssessor?: boolean;
    isDeleted?: boolean;
    isLastRow?: boolean;

    sessionID?: string;

    user_NTID?: string;
    modifiedAt?: Date;
    createdAt?: Date;
    
  }
