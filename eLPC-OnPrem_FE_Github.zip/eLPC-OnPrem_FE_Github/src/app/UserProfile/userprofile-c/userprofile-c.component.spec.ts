import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserprofileCComponent } from './userprofile-c.component';

describe(' UserprofileCComponent', () => {
  let component:  UserprofileCComponent;
  let fixture: ComponentFixture< UserprofileCComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [  UserprofileCComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent( UserprofileCComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
