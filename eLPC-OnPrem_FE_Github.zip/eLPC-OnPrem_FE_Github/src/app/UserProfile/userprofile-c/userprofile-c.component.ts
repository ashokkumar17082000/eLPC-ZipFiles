import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { LanguageService } from 'src/app/language.service';
import { AssessorTemplateService } from 'src/app/service/assessor/assessortemplate.service';
import { ValuestreamTemplateService } from 'src/app/service/common/valuestreamtemplate.service';
import { SharedService } from 'src/app/service/shared.service';
import { UserProfileService } from 'src/app/service/user-profile.service';
import { environment } from 'src/environments/environment';
import { Assessor, AssessorTemplate } from 'src/app/Assessor/assessor/assessortemplate';
import { ValueStream, ValueStreamCategory, ValueStreamTemplate } from 'src/app/Valuestream/valuestreams/valuestreamtemplate';
import { UserProfileValueStream, UserProfileAssessor, UserProfileValueStreamAssessor, usercustomIcon } from './userProfile';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { FormsModule,ReactiveFormsModule  } from '@angular/forms';
import { ChangeDetectorRef } from '@angular/core';

@Component({
  selector: 'app-userprofile-c',
  templateUrl: './userprofile-c.component.html',
  styleUrls: ['./userprofile-c.component.css']
})
//UserprofileCComponent
export class UserprofileCComponent implements OnInit {

  labels: any;
  _subscription: any;

  dropdownSettingsValueStreamCategories = {};
  dropdownSettingsValueStreams = {};
  dropdownSettingsAssessorTemplate = {};
  dropdownSettingsAssessor = {};
  dropdownSettingsValueStreamTemplate = {};

  valueStreamTemplates: any[] = [];
  valueStreamCategories: any[] = [];
  valueStreams: any[] = [];
  assessorTemplates: any[] = [];
  assessors: any[] = [];

  selectedValueStreamTemplate: ValueStreamTemplate;
  selectedValueStreamCategory: ValueStreamCategory;
  selectedValueStream: ValueStream;
  selectedAssessorTemplate: AssessorTemplate;
  selectedAssessor: Assessor;
  isLoading :boolean=false;
  loadingIndex: number | null = null;

  valueStreamTableList: Array<UserProfileValueStream> = []; //[{ valueStreamTemplate: 0, valueStreamTemplateArr: this.valueStreamTemplates,  valueStreamCategory: -1 , valueStream: 0,  isDataToReset: false, isDeleted: false }];
  
  assessorTableList: Array<UserProfileAssessor> = [];  //[{ assessorTemplate: 0, assessor: 0,  isDataToReset: false, isDeleted: false }];
  dropdownList: Array<usercustomIcon> = []; 
  
  alertText: string;
  @ViewChild('alertPopup') warningModal: TemplateRef<any>;
  @ViewChild('successPopup') successModal: TemplateRef<any>;

  //dropdownList: {customeIconID :number , customeIconPath :string }[]=[];
  selected: usercustomIcon[] = [];

  dropdownSettings:NgMultiSelectDropDownModule={};
  customeIconID: number;
  customeIconPath:string;
  displayID: any;

  constructor(private local_label: LanguageService, private router: Router, private route: ActivatedRoute,
    private http: HttpClient, private datePipe: DatePipe, private modalService: BsModalService,
    private sharedService: SharedService,
    private valueStreamService: ValuestreamTemplateService,
    private userProfileService: UserProfileService,
    private assessorTemplateService: AssessorTemplateService,
    private cdr: ChangeDetectorRef) {

  }


  ngOnInit() {
    this.sharedService.show();

    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
      this.bindcustomIcondropdownList(this.labels);
    });

    //#region Assign Multiselect Drop Down Objects
    //For multi select dropdown - Value stream template
    this.dropdownSettingsValueStreamTemplate = {
      singleSelection: true,
      idField: 'valueStreamTemplateID',
      textField: 'valueStreamTemplateName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 5,
      allowSearchFilter: true,
      closeDropDownOnSelection: true
    };

    //For multi select dropdown - Value stream Category
    this.dropdownSettingsValueStreamCategories = {
      singleSelection: true,
      idField: 'valueStreamCategoryID',
      textField: 'valueStreamCategoryName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 5,
      allowSearchFilter: true,
      closeDropDownOnSelection: true
    };

    //For multi select dropdown - Valuestreams
    // this.dropdownSettingsValueStreams = {
    //   singleSelection: true,
    //   idField: 'valueStreamID',
    //   textField: 'valueStreamName',
    //   selectAllText: 'Select All',
    //   unSelectAllText: 'UnSelect All',
    //   itemsShowLimit: 5,
    //   allowSearchFilter: true,
    //   closeDropDownOnSelection: true
    // };
    this.dropdownSettingsValueStreams = { 
      singleSelection: true,
      idField: 'valueStreamID',  // Adjusts to the ID field used in your data
      textField: 'valueStreamName',  // Adjusts to the text field used in your data
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 5,
      allowSearchFilter: true,
      closeDropDownOnSelection: true
    };

    //For multi select dropdown - Assign tag to assessor template
    this.dropdownSettingsAssessorTemplate = {
      singleSelection: true,
      idField: 'assessorTemplateID',
      textField: 'assessorTemplateName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 5,
      allowSearchFilter: true,
      closeDropDownOnSelection: true
    };

    //For multi select dropdown - Assessor
    this.dropdownSettingsAssessor = {
      singleSelection: true,
      idField: 'assessorID',
      textField: 'assessorName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 5,
      allowSearchFilter: true,
      closeDropDownOnSelection: true
    };
    this.dropdownList=this.local_label.getdropdownList(this.labels);
    this.dropdownSettings = {
      
      idField: 'customeIconID',
      textField: 'customIconName',
      allowSearchFilter: true,
      singleSelection:false,
      itemsShowLimit: 5,
      closeDropDownOnSelection: true
    };
    //#endregion Assign Multi select Drop Down Objects

    this.getUserProfileVSAS();
    this.getValueStreamList();
    console.log(this.valueStreams)
    
    // debugger;
    // let indexx=this.valueStreamTableList?.length-2;
    // this.onValuestreamOpen(indexx);

  }
  // onclcikValuestreamTemplate()
  // {
  //   alert(1)
  //   this.valueStreamTemplates = [];
  //   this.valueStreamService.getValueStreamTemplate().subscribe(res => {
  //     this.valueStreamTemplates = res;
  //   })
  // }
  //#region Fetch Value Stream & Assessor Saved Data from Database
  public getUserProfileVSAS() {
    //debugger;
    this.userProfileService.getUserProfileVSAS().subscribe(res => {
      this.valueStreamTableList = res.userProfileValueStream;
      this.assessorTableList = res.userProfileAssessor;
      console.log("192",this.assessorTableList)
      if(res.usercustomIcon.length){
        sessionStorage.setItem("customICon", res.usercustomIcon[0].customeIconID.toString())
        }else {
          sessionStorage.setItem("customICon", '0')
        }
        this.selected=[this.dropdownList[0]];
      
      if(res.usercustomIcon.length==1)
      {
        this.selected=[]
        this.selected=[this.dropdownList[res.usercustomIcon[0].customeIconID]];
      }
      if(res.usercustomIcon.length==2)
      {
        this.selected=[]
        this.selected.push(this.dropdownList[res.usercustomIcon[0].customeIconID]);
        this.selected.push(this.dropdownList[res.usercustomIcon[1].customeIconID])
      }
      if(res.usercustomIcon.length==0){
        this.selected=[this.dropdownList[0]];
      }
      this.getValueStreamList();
    }, err => {
      console.log(err);
       
    });
    this.getValueStreamList(); //this.getAssessorTemplateList(); 
  }
  //#endregion Fetch Value Stream & Assessor Saved Data from Database

 
  //#region Value Stream Data Bind
  public getValueStreamList() {
    this.valueStreamTemplates = [];
    this.valueStreamService.getValueStreamTemplate().subscribe(res => {
      this.valueStreamTemplates = res;
      this.getValueStreamCategory();
    }, err => { console.log(err) });
  }

  public getValueStreamCategory() {
    this.valueStreamCategories = [];
    this.valueStreamService.getValueStreamCategory().subscribe(res => {
      this.valueStreamCategories = res;
      this.getValueStreams();
    }, err => { console.log(err) });
  }
  onValuestreamOpen(index?:number){
    if(index==this.valueStreamTableList.length-2){
      this.isLoading = true;
      this.loadingIndex = index;
      this.getValueStreamList()
      setTimeout(() => {
        this.isLoading = false;
      }, 3000); // Adjust time as needed
    }else {
      this.isLoading = true;
      this.loadingIndex = index;
      this.getValueStreamList()
      setTimeout(() => {
        this.isLoading = false;
      }, 3000); // Adjust time as needed
    }
  }
  onValuestreamCategoryOpen(index?:number)
  {
    if(index==this.valueStreamTableList.length-2){
      debugger;
      this.isLoading = true;
      this.loadingIndex = index;
      this.getValueStreamList()
      setTimeout(() => {
        this.isLoading = false;
      }, 3000); // Adjust time as needed
    }else{
      this.isLoading = true;
      this.loadingIndex = index;
      this.getValueStreamList()
      setTimeout(() => {
        this.isLoading = false;
      }, 3000); // Adjust time as needed
    }
  }
  onAssessorOpen(index:number){
    if(index==this.assessorTableList.length-2){
      this.isLoading = true;
      this.loadingIndex = index;
      this.getAssessorTemplateList()      
      setTimeout(() => {
        this.isLoading = false;
      }, 3000); // Adjust time as needed   
    }else {
      this.isLoading = true;
      this.loadingIndex = index;
      this.getAssessorTemplateList()      
      setTimeout(() => {
        this.isLoading = false;
      }, 3000); // Adjust time as needed
   
    }
  }

  public getValueStreams() {
    this.valueStreams = [];
    this.valueStreamService.getValueStream().subscribe(res => {
      this.valueStreams = res;
      this.isLoading=false;
      debugger;
      this.CreateValueStreamRow();

      this.getAssessorTemplateList();

    }, err => { console.log(err) });
  }

  //#endregion Value Stream Data Bind

  //#region Assessor Data Bind
  public getAssessorTemplateList() {
    this.assessorTemplates = [];
    this.assessorTemplateService.getAssessorTemplates().subscribe(res => {
      this.assessorTemplates = res;
      this.getAssessors();
    }, err => { console.log(err) });
  }

  public getAssessors() {
    this.assessors = [];
    this.assessorTemplateService.getAssessors().subscribe(res => {
      this.assessors = res;
      this.isLoading=false;
      this.CreateAssessorRow();
      this.sharedService.hide();
    }, err => { console.log(err) });
  }
  //#endregion Assessor Data Bind

  CreateValueStreamRow(index?:number) {
    debugger;
    if (this.valueStreamTableList != null && this.valueStreamTemplates != null
      && this.valueStreamTableList.length != this.valueStreamTemplates.length) {
        console.log("length",this.valueStreamTableList.length-1)
        console.log("value",this.valueStreamTableList[this.valueStreamTableList.length-1])
        if(this.valueStreamTableList[this.valueStreamTableList.length-1]!==undefined){
          if(this.valueStreamTableList[this.valueStreamTableList.length-1].valueStreamTemplateID!==undefined){
            //alert(1)
            var vsObj = new UserProfileValueStream();
            vsObj.isLastRow = true;
            this.valueStreamTableList.push(vsObj);
          }
         
        } else {
          var vsObj = new UserProfileValueStream();
          vsObj.isLastRow = true;
          this.valueStreamTableList.push(vsObj);
        }
       
      //   else{}
      // //Create new blank Row
      // var vsObj = new UserProfileValueStream();
      // vsObj.isLastRow = true;
      // this.valueStreamTableList.push(vsObj);
    }

    //Assign Value stream template list for each row
    let i = 0;
    let sessionID = this.sharedService.sessionID;
    this.valueStreamTableList.forEach(element => {
      let valueStreamTable = Object.values(Object.assign({}, this.valueStreamTableList)).map(itemY => { return itemY.valueStreamTemplateID; });
      let filtered_VSTemplates = Object.values(Object.assign({}, this.valueStreamTemplates)).filter(itemX => !valueStreamTable.includes(itemX.valueStreamTemplateID) || itemX.valueStreamTemplateID == element.valueStreamTemplateID);
      element.valueStreamTemplateArr = filtered_VSTemplates;
      element.rowID = i;
      i++;
      if (this.valueStreamTableList.length == i) {
        element.isLastRow = true;
      }

      if (element.isForgotValueStream && element.sessionID != null && element.sessionID != sessionID) {
        element.valueStreamID = 0;
      }

      //&& !element.isForgotValueStream
      if (element.valueStreamTemplateID > 0) {
        const selectedTemplate = this.valueStreamTemplates.find(x => x.valueStreamTemplateID == element.valueStreamTemplateID);
        element.selectedItemValueStreamTemplate = [];
        element.selectedItemValueStreamTemplate.push(selectedTemplate);
        if(!index){
          this.onSelectValueStreamTemplate(element.rowID, element);
        }
       
      }
    });
  }

  CreateAssessorRow(index?:number) {
    if (this.assessorTableList != null && this.assessorTemplates != null
      && this.assessorTableList.length != this.assessorTemplates.length) {
      //Create new blank assessor Row
      debugger;
      if(this.assessorTableList[this.assessorTableList.length-1]!==undefined){
        if(this.assessorTableList[this.assessorTableList.length-1].assessorTemplateID!==undefined){
          var assessorObj = new UserProfileAssessor();
          assessorObj.isLastRow = true;
          this.assessorTableList.push(assessorObj);
        }
       
      } else {
        var assessorObj = new UserProfileAssessor();
        assessorObj.isLastRow = true;
        this.assessorTableList.push(assessorObj);
      }
           
    }

    //Assign assessor template list for each row
    let i = 0;
    let sessionID = this.sharedService.sessionID;
    this.assessorTableList.forEach(element => {
      let assessorTable = Object.values(Object.assign({}, this.assessorTableList)).map(itemY => { return itemY.assessorTemplateID; });
      let filtered_ASTemplates = Object.values(Object.assign({}, this.assessorTemplates)).filter(itemX => !assessorTable.includes(itemX.assessorTemplateID) || itemX.assessorTemplateID == element.assessorTemplateID);
      element.assessorTemplateArr = filtered_ASTemplates;
      element.rowID = i;
      i++;
      if (this.assessorTableList.length == i) {
        element.isLastRow = true;
      }

      if (element.isForgotAssessor && element.sessionID != null && element.sessionID != sessionID) {
        element.assessorID = 0;
      }

      //&& !element.isForgotAssessor
      if (element.assessorTemplateID > 0) {
        const selectedTemplate = this.assessorTemplates.find(x => x.assessorTemplateID == element.assessorTemplateID);
        element.selectedItemAssessorTemplate = [];
        element.selectedItemAssessorTemplate.push(selectedTemplate);

        if(!index){
          this.onSelectAssessorTemplate(element.rowID, element);
        }
      }
    });
  }

  //#region ValueStream Combobox select & Deselect Events
  onSelectValueStreamTemplate(rowID: number, obj: UserProfileValueStream) {
    debugger;
    if (obj.selectedItemValueStreamTemplate[0] != null) {
      obj.valueStreamTemplateID = obj.selectedItemValueStreamTemplate[0].valueStreamTemplateID;
    }

    if (obj.selectedItemvalueStreamCategory != null && obj.selectedItemvalueStreamCategory[0] != null) {
      obj.valueStreamCategoryID = obj.selectedItemvalueStreamCategory[0].valueStreamCategoryID;
    }

    if (obj.selectedItemvalueStream != null && obj.selectedItemvalueStream[0] != null) {
      obj.valueStreamID = obj.selectedItemvalueStream[0].valueStreamID;
    }

    this.onDeSelectValueStreamTemplate(-1, obj);

    let visulizationViewModeID = this.valueStreamTemplates.filter(x => x.valueStreamTemplateID == obj.valueStreamTemplateID)[0].visualizationViewModeID;
    if (visulizationViewModeID == 2) {
      obj.valueStreamCategoryArr = [];
      obj.valueStreamCategoryArr = Object.values(Object.assign({}, this.valueStreamCategories)).filter(x => x.valueStreamTemplateID == obj.valueStreamTemplateID && x.valueStreamCategoryName !== "VS Responsible Employee" && x.valueStreamCategoryName !== "SHIFT")

      obj.selectedItemvalueStreamCategory = [];
      if (obj.valueStreamCategoryID > 0) {
        const selectedItem = this.valueStreamCategories.find(x => x.valueStreamTemplateID == obj.valueStreamTemplateID && x.valueStreamCategoryID === obj.valueStreamCategoryID);
        if (selectedItem) {
          obj.selectedItemvalueStreamCategory.push(selectedItem);
          obj.valueStreamCategoryID = selectedItem.valueStreamCategoryID;
          this.onSelectValueStreamCategory(rowID, obj);
        }
      }
    }
    else {
      obj.valueStreamCategoryArr = [];
      obj.selectedItemvalueStream = [];
      obj.valueStreamArr = [];
      obj.valueStreamArr = Object.values(Object.assign({}, this.valueStreams)).filter(x => (x.valueStreamTemplateID == obj.valueStreamTemplateID) && x.valueStreamName && x.responsible_UserID);
      if (obj.valueStreamID > 0) {
        const selectedItem = this.valueStreams.find(x => x.valueStreamTemplateID == obj.valueStreamTemplateID && x.valueStreamID === obj.valueStreamID);
        if (selectedItem) {
          obj.selectedItemvalueStream.push(selectedItem);
          obj.valueStreamID = selectedItem.valueStreamID;
        }
      }
    }
  }
  onSelectValueStreamTemplate1(rowID: number, obj: UserProfileValueStream) {
    debugger;
    if (obj.selectedItemValueStreamTemplate[0] != null) {
      obj.valueStreamTemplateID = obj.selectedItemValueStreamTemplate[0].valueStreamTemplateID;
    }

    if (obj.selectedItemvalueStreamCategory != null && obj.selectedItemvalueStreamCategory[0] != null) {
      obj.valueStreamCategoryID = obj.selectedItemvalueStreamCategory[0].valueStreamCategoryID;
    }

    if (obj.selectedItemvalueStream != null && obj.selectedItemvalueStream[0] != null) {
      obj.valueStreamID = obj.selectedItemvalueStream[0].valueStreamID;
    }

    this.onDeSelectValueStreamTemplate(-1, obj);
    

    let visulizationViewModeID = this.valueStreamTemplates.filter(x => x.valueStreamTemplateID == obj.valueStreamTemplateID)[0].visualizationViewModeID;
    if (visulizationViewModeID == 2) {
      obj.valueStreamCategoryArr = [];
      obj.valueStreamCategoryArr = Object.values(Object.assign({}, this.valueStreamCategories)).filter(x => x.valueStreamTemplateID == obj.valueStreamTemplateID && x.valueStreamCategoryName !== "VS Responsible Employee" && x.valueStreamCategoryName !== "SHIFT")

      obj.selectedItemvalueStreamCategory = [];
      if (obj.valueStreamCategoryID > 0) {
        const selectedItem = this.valueStreamCategories.find(x => x.valueStreamTemplateID == obj.valueStreamTemplateID && x.valueStreamCategoryID === obj.valueStreamCategoryID);
        if (selectedItem) {
          obj.selectedItemvalueStreamCategory.push(selectedItem);
          obj.valueStreamCategoryID = selectedItem.valueStreamCategoryID;
          this.onSelectValueStreamCategory(rowID, obj);
        }
      }
    }
    else {
      obj.valueStreamCategoryArr = [];
      obj.selectedItemvalueStream = [];
      obj.valueStreamArr = [];
      obj.valueStreamArr = Object.values(Object.assign({}, this.valueStreams)).filter(x => (x.valueStreamTemplateID == obj.valueStreamTemplateID) && x.valueStreamName && x.responsible_UserID);
      if (obj.valueStreamID > 0) {
        const selectedItem = this.valueStreams.find(x => x.valueStreamTemplateID == obj.valueStreamTemplateID && x.valueStreamID === obj.valueStreamID);
        if (selectedItem) {
          obj.selectedItemvalueStream.push(selectedItem);
          obj.valueStreamID = selectedItem.valueStreamID;
        }
      }
      // this.valueStreamTableList1 = JSON.parse(JSON.stringify( this.valueStreamTableList))
      // if(obj.valueStreamArr.length>0){
      //   obj.valueStreamArr= obj.valueStreamArr
      // }
    }

    this.CreateValueStreamRow(1)
  }

  onDeSelectValueStreamTemplate(rowID: number, obj: UserProfileValueStream) {
    debugger
    if (obj != null) {

      if (rowID != -1) {
        obj.valueStreamTemplateID = 0;
        obj.selectedItemValueStreamTemplate = [];
      }

      obj.selectedItemvalueStreamCategory = [];
      obj.valueStreamCategoryArr = [];

      obj.selectedItemvalueStream = [];
      obj.valueStreamArr = [];

    }

    let i = 0;
    this.valueStreamTableList.forEach(element => {
      let valueStreamTable = Object.values(Object.assign({}, this.valueStreamTableList)).map(itemY => { return itemY.valueStreamTemplateID; });
      let filtered_VSTemplates = Object.values(Object.assign({}, this.valueStreamTemplates)).filter(itemX => !valueStreamTable.includes(itemX.valueStreamTemplateID) || itemX.valueStreamTemplateID == element.valueStreamTemplateID);
      element.valueStreamTemplateArr = filtered_VSTemplates;
      element.rowID = i;
      i++;
      if (this.valueStreamTableList.length == i) {
        element.isLastRow = true;
      }
    });
  }


  onSelectValueStreamCategory(rowID: number, obj: UserProfileValueStream) {
    if (obj.selectedItemvalueStreamCategory != null && obj.selectedItemvalueStreamCategory[0] != null) {
      obj.valueStreamCategoryID = obj.selectedItemvalueStreamCategory[0].valueStreamCategoryID;
    }

    if (obj.selectedItemvalueStream != null && obj.selectedItemvalueStream[0] != null) {
      obj.valueStreamID = obj.selectedItemvalueStream[0].valueStreamID;
    }

    obj.selectedItemvalueStream = [];
    obj.valueStreamArr = [];
    obj.valueStreamArr = Object.values(Object.assign({}, this.valueStreams)).filter(x => (x.valueStreamTemplateID == obj.valueStreamTemplateID) && (x.valueStreamCategoryID == obj.valueStreamCategoryID) && x.valueStreamName && x.responsible_UserID);
    if (obj.valueStreamID > 0) {
      const selectedItem = this.valueStreams.find(x => x.valueStreamTemplateID == obj.valueStreamTemplateID && x.valueStreamCategoryID == obj.valueStreamCategoryID && x.valueStreamID === obj.valueStreamID);
      if (selectedItem) {
        obj.selectedItemvalueStream.push(selectedItem);
        obj.valueStreamID = selectedItem.valueStreamID;
      }
    }

  }

  onDeSelectValueStreamCategory(rowID: number, obj: UserProfileValueStream) {
    obj.valueStreamCategoryID = 0;
    obj.selectedItemvalueStreamCategory = [];

    obj.valueStreamID = 0;
    obj.selectedItemvalueStream = [];
    obj.valueStreamArr = [];
  }


  onSelectValueStream(rowID: number, obj: UserProfileValueStream) {


    if (obj.selectedItemvalueStream != null && obj.selectedItemvalueStream[0] != null) {
      obj.valueStreamID = obj.selectedItemvalueStream[0].valueStreamID;
    }

    if (obj.isLastRow) {
      this.CreateValueStreamRow();
      obj.isLastRow = false;
    }
  }


  onDeSelectValueStream(rowID: number, obj: UserProfileValueStream) {
    obj.valueStreamID = 0;
    obj.selectedItemvalueStream = [];
  }

  onremoveValueStreamRow(rowID: number) {
    const index = this.valueStreamTableList.findIndex(r => r.rowID === rowID);
    this.valueStreamTableList.splice(index, 1);
    this.onDeSelectValueStreamTemplate(rowID, null);

    var noNewRows = this.valueStreamTableList.find(r => r.valueStreamID == null)
    if (this.valueStreamTableList.length < this.valueStreamTemplates.length && !noNewRows) {
      this.CreateValueStreamRow();
    }
  }

  isVSCheckBoxChange(obj: UserProfileValueStream, checkedState: boolean) {
    obj.isForgotValueStream = checkedState;
  }


  onSelectAssessorTemplate(rowID: number, obj: UserProfileAssessor) {
    if (obj.selectedItemAssessorTemplate[0] != null) {
      obj.assessorTemplateID = obj.selectedItemAssessorTemplate[0].assessorTemplateID;
    }

    if (obj.selectedItemAssessor != null && obj.selectedItemAssessor[0] != null) {
      obj.assessorID = obj.selectedItemAssessor[0].assessorID;
    }

    this.onDeSelectAssessorTemplate(-1, obj);
    obj.selectedItemAssessor = [];
    obj.assessorArr = [];
    obj.assessorArr = Object.values(Object.assign({}, this.assessors)).filter(x => (x.assessorTemplateID == obj.assessorTemplateID));
    if (obj.assessorID > 0) {
      const selectedItem = this.assessors.find(x => x.assessorTemplateID == obj.assessorTemplateID && x.assessorID === obj.assessorID);
      if (selectedItem) {
        obj.selectedItemAssessor.push(selectedItem);
        obj.assessorID = selectedItem.assessorID;
      }
    }
  }

  onSelectAssessorTemplate1(rowID: number, obj: UserProfileAssessor) {
    if (obj.selectedItemAssessorTemplate[0] != null) {
      obj.assessorTemplateID = obj.selectedItemAssessorTemplate[0].assessorTemplateID;
    }

    if (obj.selectedItemAssessor != null && obj.selectedItemAssessor[0] != null) {
      obj.assessorID = obj.selectedItemAssessor[0].assessorID;
    }

    this.onDeSelectAssessorTemplate(-1, obj);
    obj.selectedItemAssessor = [];
    obj.assessorArr = [];
    obj.assessorArr = Object.values(Object.assign({}, this.assessors)).filter(x => (x.assessorTemplateID == obj.assessorTemplateID));
    if (obj.assessorID > 0) {
      const selectedItem = this.assessors.find(x => x.assessorTemplateID == obj.assessorTemplateID && x.assessorID === obj.assessorID);
      if (selectedItem) {
        obj.selectedItemAssessor.push(selectedItem);
        obj.assessorID = selectedItem.assessorID;
      }
    }
    this.CreateAssessorRow(1)
  }

  onDeSelectAssessorTemplate(rowID: number, obj: UserProfileAssessor) {
    if (obj != null) {
      if (rowID != -1) {
        obj.assessorTemplateID = 0;
        obj.selectedItemAssessorTemplate = [];
      }

      obj.selectedItemAssessor = [];
      obj.assessorArr = [];
    }

    let i = 0;
    this.assessorTableList.forEach(element => {
      let assessorTable = Object.values(Object.assign({}, this.assessorTableList)).map(itemY => { return itemY.assessorTemplateID; });
      let filtered_ASTemplates = Object.values(Object.assign({}, this.assessorTemplates)).filter(itemX => !assessorTable.includes(itemX.assessorTemplateID) || itemX.assessorTemplateID == element.assessorTemplateID);
      element.assessorTemplateArr = filtered_ASTemplates;
      element.rowID = i;
      i++;
      if (this.assessorTableList.length == i) {
        element.isLastRow = true;
      }
    });
  }

  onSelectAssessor(rowID: number, obj: UserProfileAssessor) {
    if (obj.selectedItemAssessor != null && obj.selectedItemAssessor[0] != null) {
      obj.assessorID = obj.selectedItemAssessor[0].assessorID;
    }

    if (obj.isLastRow) {
      this.CreateAssessorRow();
      obj.isLastRow = false;
    }
  }

  onDeSelectAssessor(rowID: number, obj: UserProfileAssessor) {
    obj.assessorID = 0;
    obj.selectedItemAssessor = [];
  }

  // onremoveAssessorRow(rowID: number) {
  //   const index = this.assessorTableList.findIndex(r => r.rowID === rowID);
  //   if (!this.assessorTableList[index].isLastRow) {
  //     this.assessorTableList.splice(index, 1);
  //     this.onDeSelectAssessorTemplate(rowID, null);
  //   }
  // }

  onremoveAssessorRow(rowID: number) {
    const index = this.assessorTableList.findIndex(r => r.rowID === rowID);
    this.assessorTableList.splice(index, 1);
    this.onDeSelectAssessorTemplate(rowID, null);

    var noNewRows = this.assessorTableList.find(r => r.assessorID == null)
    if (this.assessorTableList.length < this.assessorTemplates.length && !noNewRows) {
      this.CreateAssessorRow();
    }
  }

  isASCheckBoxChange(obj: UserProfileAssessor, checkedState: boolean) {
    obj.isForgotAssessor = checkedState;
  }

  onSelectCustomeIcon(item: any) {
    this.customeIconID=item.customeIconID;
    this.customeIconPath=item['path'];

}
  //#endregion ValueStream Combobox select & Deselect Events

  public cancelProfile()
  {
    this.router.navigate([environment.home +'/dashboard'])
  }

  public closeAlertModal() {
    if (document.getElementsByTagName("modal-container").length > 1) {
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1]);
    }
    else {
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if (document.getElementsByTagName("bs-modal-backdrop").length > 0) {
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }
  }


  onSubmit() {
    if (this.valueStreamTableList.length == 1) {
      if ((this.valueStreamTableList[0].valueStreamTemplateID == null || this.valueStreamTableList[0].valueStreamTemplateID == 0)
        && this.valueStreamTableList[0].valueStreamTemplateArr != null && this.valueStreamTableList[0].valueStreamTemplateArr.length > 0) {
        this.alertText = this.labels.default.selectVSTemplate;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        return;
      }

      if ((this.valueStreamTableList[0].valueStreamID == null || this.valueStreamTableList[0].valueStreamID == 0)
        && this.valueStreamTableList[0].valueStreamArr != null && this.valueStreamTableList[0].valueStreamArr.length > 0) {
        this.alertText = this.labels.default.selectVS;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        return;
      }
    }


    for (let i = 0; i < this.valueStreamTableList.length; i++) {
      if (!(this.valueStreamTableList[i].valueStreamTemplateID > 0) && !(this.valueStreamTableList[i].isLastRow)) {
        this.alertText = this.labels.default.selectVSTemplate + " " + this.labels.default.onRow + " " + (i + 1);
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        return;
      }
    }


    for (let i = 0; i < this.valueStreamTableList.length; i++) {
      if (!(this.valueStreamTableList[i].valueStreamID > 0) && this.valueStreamTableList[i].valueStreamTemplateID > 0) {
        this.alertText = this.labels.default.selectVS + " " + this.labels.default.onRow + " " + (i + 1);
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        return;
      }
    }



    if (this.assessorTableList.length == 1) {
      if ((this.assessorTableList[0].assessorTemplateID == null || this.assessorTableList[0].assessorTemplateID == 0)
        && this.assessorTableList[0].assessorTemplateArr != null && this.assessorTableList[0].assessorTemplateArr.length > 0) {
        this.alertText = this.labels.default.selectASTemplate;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        return;
      }

      if ((this.assessorTableList[0].assessorID == null || this.assessorTableList[0].assessorID == 0)
        && this.assessorTableList[0].assessorArr != null && this.assessorTableList[0].assessorArr.length > 0) {
        this.alertText = this.labels.default.selectAS;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        return;
      }

    }


    for (let i = 0; i < this.assessorTableList.length; i++) {
      if (!(this.assessorTableList[i].assessorTemplateID > 0) && !(this.assessorTableList[i].isLastRow)) {
        this.alertText = this.labels.default.selectASTemplate + " " + this.labels.default.onRow + " " + (i + 1);
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        return;
      }
    }


    for (let i = 0; i < this.assessorTableList.length; i++) {
      if (!(this.assessorTableList[i].assessorID > 0) && this.assessorTableList[i].assessorTemplateID > 0) {
        this.alertText = this.labels.default.selectAS + " " + this.labels.default.onRow + " " + (i + 1);
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        return;
      }
    }

    let userProfile = new UserProfileValueStreamAssessor();
    let sessionID = this.sharedService.sessionID;

    userProfile.userProfileValueStream = Object.values(Object.assign({}, this.valueStreamTableList)).map(r => {
      if (r.valueStreamID > 0 && r.valueStreamID > 0) {
        let vs = new UserProfileValueStream();
        vs.userProfileValueStreamID = r.userProfileValueStreamID;
        vs.rowID = r.rowID;
        vs.valueStreamTemplateID = r.valueStreamTemplateID;
        vs.valueStreamCategoryID = r.valueStreamCategoryID;
        vs.valueStreamID = r.valueStreamID;
        vs.isForgotValueStream = r.isForgotValueStream;
        vs.sessionID = (r.isForgotValueStream == true) ? sessionID : null;
        return vs;
      }
    });

    userProfile.userProfileAssessor = Object.values(Object.assign({}, this.assessorTableList)).map(r => {
      if (r.assessorTemplateID > 0 && r.assessorID > 0) {
        let AS = new UserProfileAssessor();
        AS.userProfileAssessorID = r.userProfileAssessorID;
        AS.rowID = r.rowID;
        AS.assessorTemplateID = r.assessorTemplateID;
        AS.assessorID = r.assessorID;
        AS.isForgotAssessor = r.isForgotAssessor;
        AS.sessionID = (r.isForgotAssessor == true) ? sessionID : null;
        return AS;
      }
    });
    if(this.selected.length>0)
    {
      userProfile.usercustomIcon = Object.values(Object.assign({}, this.selected)).map(r => {
        if (r.customeIconID > -1) {
          let UI = new usercustomIcon();
          UI.customeIconID = r.customeIconID;
  
          return UI;
        }
      });
    }
 
    userProfile.userProfileValueStream = userProfile.userProfileValueStream.filter(r => r != null);
    userProfile.userProfileAssessor = userProfile.userProfileAssessor.filter(r => r != null);
    userProfile.usercustomIcon=userProfile.usercustomIcon.filter(r => r != null);
    
    
    console.log(userProfile.usercustomIcon)
    if(userProfile.usercustomIcon.length < 3) {
      this.userProfileService.addEditUserProfile(userProfile).subscribe(res => {
        if (res.resultCode == 0) {
          this.sharedService.show();
          this.getUserProfileVSAS();
  
          this.alertText = this.labels.default.saveSuccessfully;
          this.modalService.show(this.successModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          return;
  
        }
        else {
          this.alertText = this.labels.default.updateFailed;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          return;
        }
      }, err => {
        console.log(err);
      });
  
    }else {
      this.alertText = this.labels.default.customIconLength ;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      return;
    }    
    
  }

  bindcustomIcondropdownList(label:any)
  {
    //debugger;
   // this.getUserProfileVSAS()
   if(this.selected.length==2){
    //this.getUserProfileVSAS()
   }else {
    this.dropdownList=this.local_label.getdropdownList(label);
    this.displayID=sessionStorage.getItem("customICon");
    this.selected=[this.dropdownList[0]];
    if(this.displayID>0)
    {
      this.selected=[this.dropdownList[sessionStorage.getItem("customICon")]];
    }
  
   }
    }

}
