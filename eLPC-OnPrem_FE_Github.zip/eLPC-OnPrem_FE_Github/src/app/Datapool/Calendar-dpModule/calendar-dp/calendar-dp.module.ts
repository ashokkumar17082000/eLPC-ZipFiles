import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import {CalenderListComponent} from '../calender-list/calender-list.component'
import { CalendarDPRoutingModule } from './calendar-dp-routing.module';
import { FormsModule } from '@angular/forms';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { NgxPaginationModule } from 'ngx-pagination';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { OrderModule } from 'ngx-order-pipe';
import { DatePipe } from '@angular/common';
import { SharedModule } from '../../../shared/shared.module'
import { PopoverModule } from 'ngx-bootstrap/popover';

@NgModule({
  declarations: [CalenderListComponent],
  imports: [
    CommonModule,
    CalendarDPRoutingModule,
    FormsModule,
    PaginationModule.forRoot(),
    BsDatepickerModule.forRoot(),
    OrderModule,
    SharedModule,
    NgxPaginationModule,
    PopoverModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class CalendarDPModule { }
