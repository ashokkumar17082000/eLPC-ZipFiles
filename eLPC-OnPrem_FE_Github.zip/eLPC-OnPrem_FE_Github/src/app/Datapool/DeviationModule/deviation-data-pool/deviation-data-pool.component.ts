import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { SharedService } from 'src/app/service/shared.service';
//import { ProcessConfirmation } from '../../../ProcessConfirmation/process-confirmationmode/process-confirmation/process-confirmation';
import { ProcessConfirmation } from 'src/app/pc/process-confirmation/process-confirmation';
import { DataPoolService } from 'src/app/service/data-pool.service';
import { Router } from '@angular/router';
import { ProcessConfirmationService } from 'src/app/service/common/process-confirmation.service';
import { LanguageService } from 'src/app/language.service';
import { environment } from 'src/environments/environment';
import { BsModalService } from 'ngx-bootstrap/modal';
import { FormGroup, FormControl } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { saveAs } from 'file-saver';
import { ExcelService } from 'src/app/service/excel.service';
import { ChangeDetectorRef } from '@angular/core';

declare var $;

@Component({
  selector: 'app-deviation-data-pool',
  templateUrl: './deviation-data-pool.component.html',
  styleUrls: ['./deviation-data-pool.component.css']
})

export class DeviationDataPoolComponent implements OnInit {
  @ViewChild("alertPopup") warningModal: TemplateRef<any>;
  @ViewChild('ResumeModal') public ResumeModal: TemplateRef<any>;
  dataTable: any;
  dataPoolList: ProcessConfirmation[] = [];
  totalList: ProcessConfirmation[];
  dateTimeFormat = environment.dateTimeFormat;
  filterdateFormat  = environment.dateTimeFormat.split(" ")[0];

  filterId = false;
  filterName = false;
  filterTimeStamp = false;
  filterUserName = false;
  filterQuestionID = false;
  filterresponsibleEmployee = false;
  filterAdditionalEmployee=false;
  filterValueStream = false;
  filterdeviationDescription = false;
  filterScore = false;
  filterTagName = false;
  filtertag=false;

  filtertext: string = '';
  filterType: string = "test";
  key: string = 'name';//for sorting
  reverse1: boolean = false;//for sorting
  headerFilterName: string = "";//for filtering

  public data = [];
  public dataCopy=[];
  public settings = {};
  public form: FormGroup;
  public loadContent: boolean = false;

  labels: any;
  _subscription: any;

  page: number = 1;
  resultPerPage: number = 10;
  startPage: number;
  endPage: number;
  alertText: any;
  str1: any;
  filterPopUp: any;
  config = {
    animated: false,
    keyboard: true,
    ignoreBackdropClick: true
  };

  constructor(private local_label: LanguageService, public sharedService: SharedService, private dataPoolService: DataPoolService,
    private router: Router, private processConfirmationService: ProcessConfirmationService, private modalService: BsModalService, 
    private datePipe: DatePipe, private excelService: ExcelService,private cdr: ChangeDetectorRef) {

  }

  ngOnInit() {
    // if(this.sharedService.role !=="Designer")
    // {
    //   this.router.navigate([environment.home +'/accessdenied']);
    // }

    this.sharedService.show();
    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
    });


    this.GetDataPool();
  }

  //#region Pagination, Sorting & filtering
  /** Method is responsible to move to first page of the pagination. */
  isFirstPage() {
    if (this.page == 1) {
      return;
    }
    else {
    }

    this.page = 1;
    this.startPage = (this.page - 1) * 4 + 1;
    this.endPage = this.page * this.resultPerPage;
  }

  /** Method is responsible to move to last page of the pagination. */
  isLastPage() {
    if (Math.ceil(this.dataPoolList.length / this.resultPerPage) <= this.page) {
      return;
    }
    else {

    }

    this.page = Math.ceil(this.dataPoolList.length / this.resultPerPage);
    this.startPage = (this.page - 1) * 4 + 1;
    this.endPage = this.page * this.resultPerPage;
  }

  /** Method is responsible to change page of the pagination. */
  pageChanged(event): void {

    if (event == 0) {
      return;
    }
    else if (Math.ceil(this.dataPoolList.length / this.resultPerPage) < event) {
      return;
    }
    else {
      this.page = event;
      this.startPage = (this.page - 1) * 4 + 1;
      this.endPage = this.page * this.resultPerPage;
    }
  }

 
  showFilter() {
    this.filterName = !this.filterName;
  }


  public openAlertModal(popUp: any) {
    this.filterPopUp = popUp;
  }

  public closeAlertModal() {
    this.filterPopUp.hide();
    if (this.dataPoolList.length == this.totalList.length) {
    //document.getElementsByTagName("popover-container")[0].parentNode.removeChild(document.getElementsByTagName("popover-container")[0]);
    this.filtertext = '';
    this.filterId = false;
    this.filterTimeStamp = false;
    this.filterUserName = false;
    this.filterQuestionID = false;
    this.filterresponsibleEmployee = false;
    this.filterAdditionalEmployee=false
    this.filterValueStream = false;
    this.filterdeviationDescription = false;
    this.filterScore = false;
    this.filterTagName = false;
    this.filtertag=false;
    //document.querySelector('body').classList.remove('-is-modal');
    }
  }

  //resetting all the filtering and sorting
  resetAll() {
    this.reverse1 = false;
    this.filtertext = "";
  }

  //*********************sorting*********
  sort(key) {
    this.key = this.headerFilterName;;
    this.reverse1 = !this.reverse1;
  }

  getButtonType(buttonname: any): any {
    this.filterType = buttonname;
  }
  // *********************************

  getColumnName(headername: any) {
    
    if (this.filteredItems == undefined) {
      this.filteredItems = []
    }

    this.dataPoolList = this.totalList;//newly added
    this.filtertext = '';
    this.filterId = false;
    this.filterTimeStamp = false;
    this.filterUserName = false;
    this.filterQuestionID = false;
    this.filterresponsibleEmployee = false;
    this.filterValueStream = false;
    this.filterdeviationDescription = false;
    this.filterScore = false;
  
   // this.filtertag=false;

    if (headername == 'deviationDisplayID') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].deviationDisplayID);
      }
      this.filterId = !this.filterId;
    }
    else if (headername == 'timeStamp') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.datePipe.transform(this.totalList[i].timeStamp,this.filterdateFormat));
      }
      this.filterTimeStamp = !this.filterTimeStamp;
    }
    else if (headername == 'userName') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].userName);
      }
      this.filterUserName = !this.filterUserName;
    }
    else if (headername == 'questionID') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].questionID);
      }
      this.filterQuestionID = !this.filterQuestionID;
    }
    else if (headername == 'responsibleEmployee') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].responsibleEmployee);
      }
      this.filterresponsibleEmployee = !this.filterresponsibleEmployee;
    }
    else if (headername == 'valueStreamName') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].valueStreamName);
      }
      this.filterValueStream = !this.filterValueStream;
    }
    
    else if (headername == 'deviationDescription') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].deviationDescription);
      }
      this.filterdeviationDescription = !this.filterdeviationDescription;
    }
    
    else if (headername == 'obtainedScore') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].obtainedScore);
      }
      this.filterScore = !this.filterScore;
    }
    this.headerFilterName = headername;
    this.searchFilter();
  }

  setForm() {
    this.form = new FormGroup({
      name: new FormControl(
        this.dataCopy
      )
    });
    this.loadContent = true;
  }

  searchFilter(num?:number) {
    debugger;
    if(num!=1){
      this.data = [];
    }
    // ********************************searching
    var prefix = 'Q';
    if (this.headerFilterName == "timeStamp") {
      for (var dataPoolDet of this.dataPoolList) {
        this.str1 = this.datePipe.transform(dataPoolDet.timeStamp, this.filterdateFormat);//converting the date format
        let newItem = {
          deviationID: dataPoolDet.deviationID,
          timeStamp: this.str1
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.timeStamp ===  this.str1 )) {//newly added
            this.data.push(newItem);
          }
        }
      }
    }
    else if (this.headerFilterName == "userName") {
      for (var dataPoolDet of this.dataPoolList) {
        let newItem = {
          deviationID: dataPoolDet.deviationID,
          userName: dataPoolDet.userName
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.userName === dataPoolDet.userName)) {//newly added
            this.data.push(newItem);
          }
        }
      }
    }
    else if (this.headerFilterName == "questionID") {
      for (var dataPoolDet of this.dataPoolList) {
        let newItem = {
          deviationID: dataPoolDet.deviationID,
          questionID: 'Q' + dataPoolDet.questionID.toString()
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.questionID ===  'Q' + dataPoolDet.questionID)) {//newly added
            this.data.push(newItem);
          }
        }
      }
    }
    else if (this.headerFilterName == "responsibleEmployee") {
      for (var dataPoolDet of this.dataPoolList) {
        let newItem = {
          deviationID: dataPoolDet.deviationID,
          responsibleEmployee: dataPoolDet.responsibleEmployee
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.responsibleEmployee === dataPoolDet.responsibleEmployee)) {
            this.data.push(newItem);
          }
        }
      }
    }
    

    else if (this.headerFilterName == "deviationDisplayID") {
      for (var dataPoolDet of this.dataPoolList) {
        let newItem = {
          deviationID: dataPoolDet.deviationID,
          deviationDisplayID: dataPoolDet.deviationDisplayID
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.deviationDisplayID === dataPoolDet.deviationDisplayID)) {
            this.data.push(newItem);
          }
        }
      }
    }

    else if (this.headerFilterName == "valueStreamName") {
      for (var dataPoolDet of this.dataPoolList) {
        let newItem = {
          deviationID: dataPoolDet.deviationID,
          valueStreamName: dataPoolDet.valueStreamName
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.valueStreamName === dataPoolDet.valueStreamName)) {
            this.data.push(newItem);
          }
        }
      }
    }
   
    else if (this.headerFilterName == "deviationDescription") {
      for (var dataPoolDet of this.dataPoolList) {
        let newItem = {
          deviationID: dataPoolDet.deviationID,
          deviationDescription: dataPoolDet.deviationDescription
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.deviationDescription === dataPoolDet.deviationDescription)) {
            this.data.push(newItem);
          }
        }
      }
    }
    else if (this.headerFilterName == "obtainedScore") {
      for (var dataPoolDet of this.dataPoolList) {
        let newItem = {
          deviationID: dataPoolDet.deviationID,
          obtainedScore: dataPoolDet.obtainedScore
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.obtainedScore === dataPoolDet.obtainedScore)) {
            this.data.push(newItem);
          }
        }
      }
    }
    this.dataCopy=JSON.parse(JSON.stringify(this.data))
    this.settings = {//setting for multiselect dropdown
      singleSelection: false,
      idField:'deviationID',
      textField: this.headerFilterName,


      enableCheckAll: true,
      selectAllText: 'Select All',
      unSelectAllText: 'Unselect All',
      allowSearchFilter: true,
      limitSelection: -1,
      clearSearchFilter: true,
      maxHeight: 197,
      itemsShowLimit: 0,
      searchPlaceholderText: 'Search',
      noDataAvailablePlaceholderText: 'No Data Available',
      closeDropDownOnSelection: false,
      showSelectedItemsAtTop: false,
      defaultOpen: false
    };
    this.setForm();
    // ************************************************
  }

  // ************************************filtering ends******************************************************
  // ***********************************Dropdown multiselect filtering**************************
  filteredItems: Array<any>;
  x: any;

  onItemSelect(item: any) {
    
    if (this.filteredItems == undefined) {
      this.filteredItems = [];
    }

    if (this.headerFilterName == 'timeStamp') {
      if (this.filteredItems.indexOf(item.timeStamp) < 0) {
        this.filteredItems.push(item.timeStamp);
      }
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(this.datePipe.transform(f.timeStamp, this.filterdateFormat)));
    }
    else if (this.headerFilterName == 'userName') {
      if (this.filteredItems.indexOf(item.userName) < 0) {
        this.filteredItems.push(item.userName);
      }
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.userName));
    }
    else if (this.headerFilterName == 'questionID') {
      item.questionID = item.questionID.replace("Q", "");
      if (this.filteredItems.indexOf(item.questionID) < 0) {
        this.filteredItems.push(item.questionID);
      }
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.questionID.toString()));
    }
    else if (this.headerFilterName == 'responsibleEmployee') {
      if (this.filteredItems.indexOf(item.responsibleEmployee) < 0) {
        this.filteredItems.push(item.responsibleEmployee);
      }
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.responsibleEmployee));
    }
    
    else if (this.headerFilterName == 'deviationDisplayID') {
      if (this.filteredItems.indexOf(item.deviationDisplayID) < 0) {
        this.filteredItems.push(item.deviationDisplayID);
      }
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.deviationDisplayID));
    }
    else if (this.headerFilterName == 'valueStreamName') {
      if (this.filteredItems.indexOf(item.valueStreamName) < 0) {
        this.filteredItems.push(item.valueStreamName);
      }
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.valueStreamName));
    }
    
    // else if (this.headerFilterName == 'Tag') {
    //   if (this.filteredItems.indexOf(item.tagName) < 0) {
    //     this.filteredItems.push(item.tagName);
    //   }
    //   this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.tag));
    // }
    
    else if (this.headerFilterName == 'deviationDescription') {
      if (this.filteredItems.indexOf(item.deviationDescription) < 0) {
        this.filteredItems.push(item.deviationDescription);
      }
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.deviationDescription));
    }
    else if (this.headerFilterName == 'obtainedScore') {
      if (this.filteredItems.indexOf(item.obtainedScore) < 0) {
        this.filteredItems.push(item.obtainedScore);
      }
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.obtainedScore));
    }
  }


  onOpenDropdown(){
    console.log("open ")
    console.log("datcopy",this.dataCopy)
    console.log(this.data)
    this.dataCopy = [...this.dataCopy];
    this.cdr.detectChanges();
  }
  public onDeSelect(item: any) {
    if (this.filteredItems == undefined) {
      this.filteredItems = [];
    }
    if (this.headerFilterName == 'timeStamp') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.timeStamp);
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(this.datePipe.transform(f.timeStamp, this.filterdateFormat)));
    }
    else if (this.headerFilterName == 'userName') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.userName);
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.userName));
    }
    else if (this.headerFilterName == 'questionID') {
      item.questionID = item.questionID.replace("Q", "");
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.questionID);
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.questionID.toString()));
    }
    else if (this.headerFilterName == 'responsibleEmployee') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.responsibleEmployee);
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.responsibleEmployee));
    }
    
    else if (this.headerFilterName == 'deviationDisplayID') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.deviationDisplayID);
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.deviationDisplayID));
    }

    else if (this.headerFilterName == 'valueStreamName') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.valueStreamName);
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.valueStreamName));
    }
   
    else if (this.headerFilterName == 'deviationDescription') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.deviationDescription);
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.deviationDescription));
    }
    else if (this.headerFilterName == 'obtainedScore') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.obtainedScore);
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.obtainedScore));
    }
  }

  onSelectAll(items: any) {
    if (this.filteredItems == undefined) {
      this.filteredItems = [];
    }
    for (var i = 0; i < items.length; i++) {
      if (this.headerFilterName == 'timeStamp') {
        this.filteredItems.push(items[i].timeStamp)
      }
      else if (this.headerFilterName == 'userName') {
        this.filteredItems.push(items[i].userName)
      }
      else if (this.headerFilterName == 'questionID') {
        this.filteredItems.push(items[i].questionID)
      }
      else if (this.headerFilterName == 'userName') {
        this.filteredItems.push(items[i].userName)
      }
      else if (this.headerFilterName == 'deviationDisplayID') {
        this.filteredItems.push(items[i].deviationDisplayID)
      }
      else if (this.headerFilterName == 'responsibleEmployee') {
        this.filteredItems.push(items[i].userName)
      }
     
      else if (this.headerFilterName == 'valueStreamName') {
        this.filteredItems.push(items[i].valueStreamName)
      }
      else if (this.headerFilterName == 'deviationDescription') {
        this.filteredItems.push(items[i].deviationDescription)
      }
      else if (this.headerFilterName == 'obtainedScore') {
        this.filteredItems.push(items[i].obtainedScore)
      }
    }
    this.dataPoolList = this.totalList;
  }

  public onDeSelectAll(items: any) {
    this.filteredItems = [];
    this.dataPoolList = this.totalList;
  }

  //  *******************************************************************************************Dropdown filtering ends here***************
  //#endregion ************************************filtering ends******************************************************


  public async GetDataPool() {
    this.sharedService.show();
    let IsDesigner=1
    if(this.sharedService.role !=="Designer")
    {
      this.sharedService.activeDateRange.IsDesigner=0
    }else {
      this.sharedService.activeDateRange.IsDesigner=1
    }
    await this.dataPoolService.GetDeviationDataPool(this.sharedService.activeDateRange).subscribe(res => {
      this.dataPoolList = res;
      this.totalList = this.dataPoolList;
      this.sharedService.hide();
    });
  }

  reDirectToQuestionID(questionID: any) {
    //Modified By EGV1COB
    //As Alberto insists when qustionid clicked it should redirected to edit qusetion page
    this.router.navigate([environment.home + '/datapool/questions', { qid: questionID }]);
  }

  reDirectToTagID(tagId: any) {
    //Modified By EGV1COB
    //As Alberto insists when question id clicked it should redirected to edit tag page
    this.router.navigate([environment.home + '/taglist', { tid: tagId }]);
  }
  base64toBlob(base64Data, contentType) {
    contentType = contentType || '';
    var sliceSize = 1024;
    var byteCharacters = atob(base64Data);
    var bytesLength = byteCharacters.length;
    var slicesCount = Math.ceil(bytesLength / sliceSize);
    var byteArrays = new Array(slicesCount);

    for (var sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {
      var begin = sliceIndex * sliceSize;
      var end = Math.min(begin + sliceSize, bytesLength);

      var bytes = new Array(end - begin);
      for (var offset = begin, i = 0; offset < end; ++i, ++offset) {
        bytes[i] = byteCharacters[offset].charCodeAt(0);
      }
      byteArrays[sliceIndex] = new Uint8Array(bytes);
    }
    return new Blob(byteArrays, { type: contentType });
  }



  GetDeviationFileByAttachmentID(attachmetID: any) {

    this.dataPoolService.GetDeviationFileByAttachmentID(attachmetID).subscribe(res => {
      if(res != null && res.length > 0)
      {
        //console.log("res",res)
        let fileName = res[0].displayFileName;
        let checkFileType = "." + fileName.split('.').pop();
        var fileType = this.sharedService.GetMIMETypeByExtenstion(checkFileType);
    
        let base64Str = res[0].fileContent.split(';base64,').pop();
        var blob = this.base64toBlob(base64Str, fileType)
        saveAs(blob, fileName);
      }
    },
      err => {
        console.log(err);
      });
  }
  closeAlertModal1(num?: number) {
    if (document.getElementsByTagName("modal-container").length > 1) {
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1]);
    }
    else {
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if (document.getElementsByTagName("bs-modal-backdrop").length > 0) {
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }
    if(num) {
      
      this.dataPoolExportExcel(1)
    }


  }

  //  *****************Export Import Assessor Excel*************
  dataPoolExportExcel(num? : number) {
    if(num) {
      this.dataPoolService.GetExcelFile("DeviationDataPool");
    }else {
      this.modalService.show(this.ResumeModal, this.config);
    $("modal-container").removeClass("fade");
    }
    //this.dataPoolService.GetExcelFile("DeviationDataPool");
  }
  async dataPoolExportExcelFiltered() {
    //debugger;
    var  fromDate=new Date(this.sharedService.activeDateRange.fromDate)
    var dateObject = new Date(this.sharedService.activeDateRange.fromDate);
    // Extract year, month, and day
    console.log()
    var fromyear = dateObject.getFullYear();
    var frommonth = ('0' + (dateObject.getMonth() + 1)).slice(-2); // Adding 1 because getMonth() returns zero-based month index
    var fromday = ('0' + dateObject.getDate()).slice(-2);
    //TODATE
    var  toDate=new Date(this.sharedService.activeDateRange.toDate)
    var dateObject = new Date(this.sharedService.activeDateRange.toDate);
    // Extract year, month, and day
    var toyear = dateObject.getFullYear();
    var tomonth = ('0' + (dateObject.getMonth() + 1)).slice(-2); // Adding 1 because getMonth() returns zero-based month index
    var today = ('0' + dateObject.getDate()).slice(-2);

    // Construct the desired date format
    var formattedfromDate = fromyear + '-' + frommonth + '-' + fromday;

    var formattedtoDate = toyear + '-' + tomonth + '-' + today;
    console.log(formattedfromDate);
    console.log(formattedtoDate); // Output: "2024-02-01"
    await this.dataPoolService.GetExcelFile("DeviationDataPool_Filtered",false,formattedfromDate,formattedtoDate);
      //this.dataPoolService.GetExcelFile("DeviationDataPool_Filtered");
   
    //this.dataPoolService.GetExcelFile("DeviationDataPool");
  }

  exportAsXLSX() {
    this.sharedService.show();

    var excelData = this.dataPoolList.map((d) => ({
      DeviationID: d.deviationID,
      DeviationDisplayID: d.deviationDisplayID,
      TIMESTAMP: d.timeStamp,
      UserName: d.userName,
      ValueStreamName: d.valueStreamName,
      DevaitionTag:d.tagList.map(item => item.tagName).join(";"),
      OPLURL: d.oplurl,
      QuestionID: d.questionID > 0 ? d.questionID : "" ,
      QuestionDisplayID: d.questionDisplayID > 0 ? 'Q' + d.questionDisplayID : "",
      QuestionText: d.questionText,
      DeviationDescription: d.deviationDescription,
      ResponsibleEmployee: d.responsibleEmployee,
      InformationTo:d.addEmpList.map(item =>item.myUserNmae).join(";"),
      Attachments: d.editTagList.map(item => item.myTagName).join(";"),
    
    }));

    this.excelService.exportAsExcelFile(excelData, 'DeviationDataPool_Filtered');
  }

  GetDataPoolBySelectedRange() {
    var monthDiff = this.sharedService.monthDiff(this.sharedService.activeDateRange.fromDate, this.sharedService.activeDateRange.toDate);
    if (monthDiff <= this.sharedService.activeDateRange.maxIntervalInMonths) {
      this.GetDataPool();
    } else {
      this.alertText = this.labels.monthValidationError.replace("((months))", this.sharedService.activeDateRange.maxIntervalInMonths.toString()) ;//this.labels.default.updateFailed;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");

      //this.sharedService.activeDateRange.fromDate = new Date(this.sharedService.activeDateRange.toDate);
      //this.sharedService.activeDateRange.fromDate.setMonth(this.sharedService.activeDateRange.fromDate.getMonth() - this.sharedService.activeDateRange.maxIntervalInMonths);
    }
  }

  searchGrid(value: string) {
    if (value.length > 0) {
      var searchText = value.trim().toLowerCase();
      this.dataPoolList = this.totalList;

      this.dataPoolList = this.dataPoolList.filter(x =>
        x.userName.trim().toLowerCase().includes(searchText)
       || (x.timeStamp != null && this.datePipe.transform(x.timeStamp,this.filterdateFormat).trim().toLowerCase().includes(searchText))

        || (x.valueStreamName != null && x.valueStreamName.trim().toLowerCase().includes(searchText))

        || (x.questionDisplayID != null && x.questionDisplayID.toString().trim().toLowerCase().includes(searchText.replace("q","")))

        || (x.oplurl != null && x.oplurl.trim().toLowerCase().includes(searchText))

        || (x.questionText != null && x.questionText.trim().toLowerCase().includes(searchText))

        || (x.deviationDescription != null && x.deviationDescription.trim().toLowerCase().includes(searchText))

        || (x.responsibleEmployee != null && x.responsibleEmployee.trim().toLowerCase().includes(searchText))

        || (x.editTagList != null && x.editTagList.map(item => item.myTagName).toString().toLowerCase().includes(searchText))

      );
      this.page = 1;
    }
    else {
      this.dataPoolList = this.totalList;
    }
  }

  //to fix scroll issue after pop up
  public closeValidationAlertModal(){
    if(document.getElementsByTagName("modal-container").length > 1){
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length-1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length-1]);
    }
    else{
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if(document.getElementsByTagName("bs-modal-backdrop").length > 0){
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }
  }
}


