import { Component, OnInit, ViewChild, ElementRef, TemplateRef } from '@angular/core';
import { SharedService } from 'src/app/service/shared.service';
import { SingleLineText, AnswerTypeNumber, AnswerTypeCurrency, AnswerTypeDateTime, MultipleLinesText, HintImage, HintHyperLink, Choice, SubQuestion, RatingScale, ChoiceDisplayType, Question, QuestionHistory, QuestionProxy, QuestionDetail, valueStreamTemplateData, assessorTemplateData, valueStreamCategoryData, vsasIDListData } from './question';
import { Assessor, AssessorTemplate } from 'src/app/Assessor/assessor/assessortemplate';
import { ValueStream, ValueStreamTemplate, ValueStreamCategory } from 'src/app/Valuestream/valuestreams/valuestreamtemplate';
import { AnswerType, User } from 'src/app/main/body/shared/common';
import { Tag, AssessorValueStreamList } from 'src/app/Tag/tag/tag';
import { AssessorTemplateService } from 'src/app/service/assessor/assessortemplate.service';
import { QuestionService } from 'src/app/service/question.service';
import { TagService } from 'src/app/service/tag.service';
import { HttpClient } from '@angular/common/http';
import { CommonService } from 'src/app/service/common/common.service';
import { ValuestreamTemplateService } from 'src/app/service/common/valuestreamtemplate.service';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import {ToastrService} from 'ngx-toastr';
import { ActivatedRoute, Router } from "@angular/router";
import { LanguageService } from 'src/app/language.service';
import { DatePipe, formatDate } from '@angular/common';
import { saveAs } from 'file-saver';
//import { debug, isUndefined } from 'util';
import { environment } from 'src/environments/environment';
import { FormGroup, FormControl } from '@angular/forms';
import { DataPoolService } from 'src/app/service/data-pool.service';
//import { forEach } from '@angular/router/src/utils/collection';
//import { element } from 'protractor';
import * as XLSX from 'xlsx';

declare var $;

@Component({
  selector: 'app-questions',
  templateUrl: './questions.component.html',
  styleUrls: ['./questions.component.css']
})
export class QuestionsComponent implements OnInit {
  @ViewChild('alertPopup') warningModal : TemplateRef<any>;
  @ViewChild('successPopup') successModal : TemplateRef<any>;
  @ViewChild('lockPopup') lockModal : TemplateRef<any>;
  dateTimeFormat = environment.dateTimeFormat;
  filterdateFormat  = environment.dateTimeFormat.split(" ")[0];

  isDisabled:boolean=true;

  alertText;
  filterId = false;
  filterName = false;
  filterLock = false;
  filterModified = false;
  filterModifiedBy = false;
  filterCreated = false;
  filterCreatedBy = false;
  filterValueStreams=false;
  filterAssessors= false;
  filterPriority = false;
  filterTags = false;
  filterActive = false;
  filterFrequency = false;


  dateValue: Date;
   questionList: Question[] = [];
   questionDetail: QuestionDetail[] = [];
   totalList: QuestionDetail[];
  question: Question = new Question();
  isLoading:boolean=false;

  isAdd: boolean = false;
  isEdit: boolean = false;
  choiceDisplayTypeList: any;
  answerTypeList: any;
  decimalPlaces: string[] = ['decimal', '0', '1', '2', '3', '4', '5'];
  currencyFormats: string[] = ['$123.45(United States)', 'R 123,456(South Africa)', '123,45 EUR']
  numberRange: string[] = ['1', '2', '3', '4', '5'];
  hyperLinkUrl: HintHyperLink = new HintHyperLink();
  hyperLinkUrls: HintHyperLink[] = [];
  url: HintImage = new HintImage();
  urls: HintImage[] = [];
  choice: Choice = new Choice();
  choices: Choice[] = [];
  subQuestion: SubQuestion = new SubQuestion();
  subQuestions: SubQuestion[] = [];
  ratingScale: RatingScale = new RatingScale();
  choiceDisplayType: ChoiceDisplayType = new ChoiceDisplayType();
  answerType: AnswerType = new AnswerType();
  valueStreamTemplate: ValueStreamTemplate = new ValueStreamTemplate();
  valueStreamTemplates: ValueStreamTemplate[] = [];
  valueStreamCategories: ValueStreamCategory[] = [];
  valueStreams: ValueStream[] = [];
  assessorTemplateList: AssessorTemplate[] = [];
  assessorTemplate: AssessorTemplate = new AssessorTemplate();
  assessors: Assessor[] = [];
  assessor: Assessor;
  valuestreamTemplateList:any;
  assesorTemplateList:any;
  valuestreamcategoryTemplateList:any;
  unload=false;



  page: number = 1;
  resultPerPage: number = 10;
  startPage: number;
  endPage: number;



  filtertext:string='';
  filterType:string="test";
  key: string = 'name';//for sorting
  reverse1: boolean = false;//for sorting
  headerFilterName:string="";//for filtering

  singleLineText: SingleLineText = new SingleLineText();
  multipleLinesText: MultipleLinesText = new MultipleLinesText();
  answerTypeNumber: AnswerTypeNumber = new AnswerTypeNumber();
  answerTypeCurrency: AnswerTypeCurrency = new AnswerTypeCurrency();
  answerTypeDateTime: AnswerTypeDateTime = new AnswerTypeDateTime();

  modalRef: BsModalRef;
  questionHistoryDetails: QuestionHistory[];

  config = {
    animated: false,
    keyboard: true,
    ignoreBackdropClick: true
  };

  //for file upload
  @ViewChild('fileInput') fileInputVariable: ElementRef;
  choiceDisplayTypeID: number;
  answerTypeID: number;
  fileToUpload: File;
  progress: number;
  message: string;
  formData: FormData;
  arrayBuffer:any;
  file:File;

  //for multiselect dropdown
  selectedValueStreams : ValueStream[]= [];
  selectedValueStreamIDs = [];
  valueStreamSettings = {};

  //for Assessor Multiselect dropdown
  selectedAssessors = [];
  selectedAssessorIDs = [];
  assessorSettings = {};
  assignedTargetFrequency = [];

  //for Tags selection
  availableTags: Tag[] = [];
  selectedTags: Tag[] = [];
  selectedTagIDs: string;
  tagList: Tag[] = [];
  tag: Tag = new Tag();
  dataTable: any;
  IDList: any;
  assessorValueStreamList: AssessorValueStreamList = new AssessorValueStreamList();


  labels: any;
  _subscription: any;
  isLock: boolean;
  questionProxy: QuestionProxy;
  droppedImageName: any;
  visulizationViewModeID: any;
  public data = [];
  public settings = {};
  public form: FormGroup;
  public loadContent: boolean = false;
  str1: string;
  filterPopUp: any;
  selectedmultiquestion: number;
  questionChecked: boolean;
  questionUnChecked: boolean;
  fromdatapoolQuestion:boolean = false;
  datapoolquestionid:number;
  vsasIdListData: vsasIDListData;
  //For multi select dropdown - Value stream template
  dropdownSettingsValueStreamTemplate = {};
  selectedItemValueStreamTemplate: ValueStreamTemplate[] = [];

  //For multi select dropdown - Value stream Category
  dropdownSettingsValueStreamCategories = {};
  selectedItemValueStreamCategories: ValueStreamCategory[] = [];

  //For multi select dropdown - Assign tag to assessor template
  dropdownSettingsAssessorTemplate = {};
  selectedItemAssessorTemplate: AssessorTemplate[] = [];
  totalvs: any;

  questionSearchText: string;

  constructor(private local_label: LanguageService, private router: Router, private modalService: BsModalService, private sharedService: SharedService, private questionService: QuestionService,
    private commonService: CommonService, private valueStreamService: ValuestreamTemplateService,
    private dataPoolService: DataPoolService,
    private assessorTemplateService: AssessorTemplateService, private tagService: TagService, private http: HttpClient,private toastr: ToastrService,
    private route: ActivatedRoute, private datePipe: DatePipe) {

    this.isDisabled = true;


  }

  ngOnInit() {
   
    if (this.sharedService.role !== "Designer") {
      this.router.navigate([environment.home + '/accessdenied']);
    }
    this.questionUnChecked = true;
    this.sharedService.show();

    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
    });
    debugger;
    //this.getValueStreamTemplates(); //for treeview
    this.getQuestionDetail(); //for Question Details
    this.getValueStreamList();
    this.getAssessorTemplateList();
    this.getQuestionList();


    //Modified By EGV1COB
    //As Alberto insists when qustionid clicked it should redirected to edit qusetion page
    this.route.params.subscribe(params => {
      let QuestionID = params["qid"];
      if (QuestionID != null) {
        //fix to load VS and AS for questions when it clicked from question datapool page
        this.fromdatapoolQuestion = true;
        this.datapoolquestionid =QuestionID;
        console.log("229",this.datapoolquestionid)
        this.getQuestionDetailByID(QuestionID);
      }
    });


    


    //this.assign();

    this.isAdd = false;
    this.isEdit = false;
    this.choices = [{ choiceName: "", choiceScore: undefined,answerCategory :"", isDeviationEntryRequired: false }];
    this.subQuestions = [{ name: "" }];
    this.choiceDisplayType.choiceDisplayTypeID = 1;
    this.answerTypeID = 3;
    this.choiceDisplayTypeID = 1;



    this.valueStreamSettings = {
      singleSelection: false,
      idField: 'valueStreamID',
      textField: 'valueStreamName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };
    this.selectedValueStreams = [];
    this.selectedValueStreamIDs = [];

    //for Assessor
    this.assessorSettings = {
      singleSelection: false,
      idField: 'assessorID',
      textField: 'assessorName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };
    this.selectedAssessors = [];
    this.getTagList();

    //For multi select dropdown - Value stream template
    this.dropdownSettingsValueStreamTemplate = {
      singleSelection: false,
      idField: 'valueStreamTemplateID',
      textField: 'valueStreamTemplateName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 5,
      allowSearchFilter: true,
      closeDropDownOnSelection: true
    };

    //For multi select dropdown - Value stream Category
    this.dropdownSettingsValueStreamCategories = {
      singleSelection: false,
      idField: 'valueStreamCategoryID',
      textField: 'valueStreamCategoryName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 5,
      allowSearchFilter: true,
      closeDropDownOnSelection: true
    };

    //For multi select dropdown - Assign tag to assessor template
    this.dropdownSettingsAssessorTemplate = {
      singleSelection: false,
      idField: 'assessorTemplateID',
      textField: 'assessorTemplateName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 5,
      allowSearchFilter: true,
      closeDropDownOnSelection: true
    };    
  }

  //For multi select dropdown - Value stream template
  onSelectValueStreamTemplate(item: ValueStreamTemplate) {
    debugger;
   
    //this.question.assigned_ValueStreamTemplateID=undefined;
    this.valueStreamTemplateChange(item.valueStreamTemplateID);
  }

  onDeSelectValueStreamTemplate(item: ValueStreamTemplate) {

    //this.question.assigned_ValueStreamTemplateID  =  this.question.assigned_ValueStreamTemplateID .filter(r=> r != item.valueStreamTemplateID);

    var valueStreamsCategoryByTemplateID = this.valueStreamCategories.filter(x => x.valueStreamTemplateID != item.valueStreamTemplateID).map(y => { return y.valueStreamCategoryID });
    //Removing Value Streams from Original VS array on Unselecting the Template ID
    this.valueStreamCategories = this.valueStreamCategories.filter(x => x.valueStreamTemplateID != item.valueStreamTemplateID);
    //Removing Value Streams from selected Choice List
    this.selectedItemValueStreamCategories = this.selectedItemValueStreamCategories.filter(x => valueStreamsCategoryByTemplateID.includes(x.valueStreamCategoryID));
    //Identifying the removed Template ValueStreams from ValueStream Array
    var valueStreamsByTemplateID = this.valueStreams.filter(x => x.valueStreamTemplateID != item.valueStreamTemplateID).map(y => { return y.valueStreamID });
    //Removing Value Streams from Original VS array on Unselecting the Template ID
    this.valueStreams = this.valueStreams.filter(x => x.valueStreamTemplateID != item.valueStreamTemplateID);
    //Removing Value Streams from selected Choice List
    this.selectedValueStreams = this.selectedValueStreams.filter(x => valueStreamsByTemplateID.includes(x.valueStreamID));
  }


  onValueStreamTemplateSelectAll() {
    //this.question.assigned_ValueStreamTemplateID  =  this.valueStreamTemplates.map(r=> r.valueStreamTemplateID);

    var TreeViewModeVS = Object.values(Object.assign({}, this.valueStreamTemplates)).filter(x => x.visualizationViewModeID == 2).map(y => { return y.valueStreamTemplateID });
    this.valueStreams = [];
    this.valueStreamCategories = [];
    this.valueStreamService.getValueStreamCategory().subscribe(res => {
      this.valueStreamCategories = res.filter(x => TreeViewModeVS.includes(x.valueStreamTemplateID) &&  ( x.valueStreamCategoryName.trim() != "VS Responsible Employee" && x.valueStreamCategoryName.trim() != "SHIFT"));
      this.valueStreamService.getValueStream().subscribe(res => {
        this.valueStreams = res;

        //select all Vlaues Streams Based on Value Stream Templates
        //this.valueStreams = this.valueStreams.filter(x =>x.valueStreamCategoryName.trim() == "VS Responsible Employee");
        
      }, err => { console.log(err) });
    }, err => { console.log(err) });

  }

  onValueStreamTemplateDeSelectAll(){
    //this.question.assigned_ValueStreamTemplateID  = [];
    //this.question.assigned_ValueStreamCategoryID  = [];



    this.selectedItemValueStreamCategories = [];
    this.selectedItemValueStreamTemplate = [];
    this.selectedValueStreams = [];
    this.valueStreams = [];
    this.valueStreamCategories = [];
  }

  onLoadValueStreamTemplate() {
  //debugger;
    this.selectedItemValueStreamTemplate = [];
    // if (!this.question.assigned_ValueStreamTemplateID || this.question.assigned_ValueStreamTemplateID === [])
    //   return;
    if(this.question.valueStreamTemplateNameArL== undefined)
    {
      return;
    }
    else
    {
      this.selectedItemValueStreamTemplate = this.valueStreamTemplates.filter(x => this.question.valueStreamTemplateNameArL.find(r=>r.vsTemplateID ==x.valueStreamTemplateID));

    //  for (let ind = 0; ind < this.question.valueStreamTemplateNameArL.length; ind++)
    //{
    //  const selectedItem = this.valueStreamTemplates.find(x => x.valueStreamTemplateID === this.question.valueStreamTemplateNameArL[ind].vsTemplateID);
    //  if (selectedItem)
    //    this.selectedItemValueStreamTemplate.push(selectedItem);
    //    //this.valueStreams=this.valueStreams.filter(r=>this.selectedItemValueStreamTemplate.find(x=>x.valueStreamTemplateID== r.valueStreamTemplateID));
    //}


    }
  }

  //For multi select dropdown - Value stream Categories
  onSelectValueStreamCategories(item: ValueStreamCategory) {
    this.question.assigned_ValueStreamCategoryID=undefined;
    this.valueStreamCategoryChange(item.valueStreamCategoryID);
  }

  onDeSelectValueStreamCategories(item:ValueStreamCategory) {
    if (!this.selectedItemValueStreamCategories || this.selectedItemValueStreamCategories.length === 0)
      this.question.assigned_ValueStreamCategoryID = undefined;;


      //this.question.assigned_ValueStreamCategoryID = this.question.assigned_ValueStreamCategoryID.filter(r => r != item.valueStreamCategoryID);

      var valueStreamsByCategoryID = this.valueStreams.filter(x => x.valueStreamCategoryID != item.valueStreamCategoryID).map( y => {return y.valueStreamID});

      this.valueStreams = this.valueStreams.filter(x => valueStreamsByCategoryID.includes(x.valueStreamID));
      this.selectedValueStreams = this.selectedValueStreams.filter(x => valueStreamsByCategoryID.includes(x.valueStreamID));
   

  }

  onValueStreamCategorySelectAll(item : ValueStreamCategory[]){

    //console.log(item);
    item.forEach( element => {
      const selectedItem = this.valueStreams.find(x => x.valueStreamCategoryID == element.valueStreamCategoryID);

      if(selectedItem === undefined){
        this.valueStreamService.getValueStreamsByCategoryID(element.valueStreamCategoryID).subscribe(res => {
          this.valueStreams.push(...res);
          //this.valueStreams = res;
          this.valueStreams = this.valueStreams.filter(x =>x.valueStreamName && x.responsible_UserID);
        },
          err => {
            console.log(err);
          });
      }
    })

  }

  onValueStreamCategoryDeSelectAll(item:ValueStreamCategory){
    this.question.assigned_ValueStreamCategoryID = undefined;;

    if(this.isEdit){
      this.valueStreams=this.valueStreams.filter(x => x.valueStreamCategoryName == "VS Responsible Employee");

      this.selectedValueStreams = this.selectedValueStreams.filter(x => x.valueStreamCategoryName == "VS Responsible Employee");
    }

    if(this.isAdd)
    {
      this.valueStreams = this.valueStreams.filter(x => x.valueStreamData == "");

      this.valueStreamCategories = [];

       var valueStreamsByCategoryID = this.valueStreams.filter(x => x.valueStreamCategoryID != item.valueStreamCategoryID).map( y => {return y.valueStreamID});

       this.unload=true;
       this.onAssessorSelect(undefined);

    }

  }

  onLoadValueStreamCategories() {
    this.selectedItemValueStreamCategories = [];

    if (!this.question.assigned_ValueStreamCategoryID || this.question.assigned_ValueStreamCategoryID === [])
      return;
      for(let ind=0; ind < this.question.assigned_ValueStreamCategoryID.length;ind++)
      {
        const selectedItem = this.valueStreamCategories.find(x => x.valueStreamCategoryID === this.question.assigned_ValueStreamCategoryID[ind]);
        if (selectedItem)
          this.selectedItemValueStreamCategories.push(selectedItem);
      }

  // this.valueStreams=this.valueStreams.filter(r=>this.selectedItemValueStreamTemplate.find(x=>x.valueStreamTemplateID== r.valueStreamTemplateID ));


  
  }

  //For multi select dropdown - Assign tag to assessor template
  onSelectAssessorTemplate(item: AssessorTemplate) {
    console.log(this.assessors)
    this.question.assigned_AssessorTemplateID =undefined;
    if(this.assessors.length===0){
      this.assessorTemplateService.getAssessors().subscribe(res3 => {
        this.assessors = res3;
        this.getAssessorsByTemplateID(item.assessorTemplateID);
      })
    }else {
      this.getAssessorsByTemplateID(item.assessorTemplateID);
    }
    }
   

  onDeSelectAssessorTemplate(item: AssessorTemplate) {
    if (!this.selectedItemAssessorTemplate || this.selectedItemAssessorTemplate.length === 0) {
      this.question.assigned_AssessorTemplateID = undefined;
    }

    //this.question.assigned_AssessorTemplateID = this.question.assigned_AssessorTemplateID.filter(x => { x != item.assessorTemplateID });

    var assessorsByTemplateID = this.assessors.filter(x => x.assessorTemplateID != item.assessorTemplateID).map(y => { return y.assessorID });
    //Removing Value Streams from Original VS array on Unselecting the Template ID
    this.assessors = this.assessors.filter(x => x.assessorTemplateID != item.assessorTemplateID);
    //Removing Value Streams from selected Choice List
    this.selectedAssessors = this.selectedAssessors.filter(x => assessorsByTemplateID.includes(x.assessorID));

    if(this.selectedItemAssessorTemplate.length < 1)
    {
      this.assessors = [];
      this.selectedAssessors = [];
    }
    
 
  }

  onLoadAssessorTemplate() {
   
    this.selectedItemAssessorTemplate = [];
    // if (!this.question.assigned_AssessorTemplateID || this.question.assigned_AssessorTemplateID == [])
    //   return;
    // if(this.question.assigned_AssessorTemplateID.length == 0)
    // {
    //   return;
    // }
    // for (let ind = 0; ind < this.question.assigned_AssessorTemplateID.length; ind++) {
    //   const selectedItem = this.assessorTemplateList.find(x => x.assessorTemplateID === this.question.assigned_AssessorTemplateID[ind]);
    //   if (selectedItem)
    //     this.selectedItemAssessorTemplate.push(selectedItem);
    // }

     if(this.question.assessorTemplateNameArL== undefined)
    {
      return;
      //this.sharedService.hide();
    }
    else{
    //   for(let j=0;j < this.question.assessorTemplateNameArL.length ; j++)
    // {
    //   const selectedassessorItem = this.assessorTemplateList.find(x => x.assessorTemplateID === this.question.assessorTemplateNameArL[j].vsTemplateID);
    //   if (selectedassessorItem)
    //     this.selectedItemAssessorTemplate.push(selectedassessorItem);
    
    // }

    this.selectedItemAssessorTemplate = this.assessorTemplateList.filter(x => this.question.assessorTemplateNameArL.find(r=>r.vsTemplateID ==x.assessorTemplateID));
    //console.log(this.selectedItemAssessorTemplate);

    //this.sharedService.hide();
    }
    
  }

  onSelectAllAssessorTemplate(){
    //this.question.assigned_AssessorTemplateID = this.assessorTemplateList.map(r => {return r.assessorTemplateID});
    this.assessors = [];
    this.assessorTemplateService.getAssessors().subscribe(res => {
      this.assessors = res;
    }, err => { console.log(err) });
  }
  onDeSelectAllAssessorTemplate(){
    this.question.assigned_AssessorTemplateID = undefined;
    this.assessors = [];
    this.selectedAssessors = [];
  }


/** Method is responsible to move to first page of the pagination. */
isFirstPage() {
  if (this.page == 1) {
    return;
  }
  else {
  }

  this.page = 1;
  this.startPage = (this.page - 1) * 4 + 1;
  this.endPage = this.page * this.resultPerPage;
}

/** Method is responsible to move to last page of the pagination. */
isLastPage() {
  if (Math.ceil(this.questionDetail.length / this.resultPerPage) <= this.page) {
    return;
  }
  else {

  }

  this.page = Math.ceil(this.questionDetail.length / this.resultPerPage);
  this.startPage = (this.page - 1) * 4 + 1;
  this.endPage = this.page * this.resultPerPage;
}

/** Method is responsible to change page of the pagination. */
pageChanged(event): void {

  if (event == 0) {
    return;
  }
  else if (Math.ceil(this.questionDetail.length / this.resultPerPage) < event) {
    return;
  }
  else {
    this.page = event;
    this.startPage = (this.page - 1) * 4 + 1;
    this.endPage = this.page * this.resultPerPage;
  }
}
// ***********************************Dropdown multiselect filtering**************************
filteredItems: Array<any>;
x:any;
onItemSelect(item: any) {

    if(this.filteredItems == undefined){
     this.filteredItems = [];
    }

    if(this.headerFilterName=='questionText'){
      if(this.filteredItems.indexOf(item.questionText)    <0)
      {
        this.filteredItems.push(item.questionText);
      }

      this.questionDetail=this.totalList.filter(f => this.filteredItems.includes((f.questionText.length>50) ? (f.questionText.slice(0,49))+'...':(f.questionText)));
    }
    else if(this.headerFilterName=='valueStreamTemplateName'){
      if(this.filteredItems.indexOf(item.valueStreamTemplateName)    <0)
      {
        this.filteredItems.push(item.valueStreamTemplateName);
      }
      this.questionDetail=this.totalList.filter(f => this.filteredItems.includes(f.valueStreamTemplateName));
    }
    else if(this.headerFilterName=='assessorTemplateName'){
      if(this.filteredItems.indexOf(item.assessorTemplateName)    <0)
      {
        this.filteredItems.push(item.assessorTemplateName);
      }
      this.questionDetail=this.totalList.filter(f => this.filteredItems.includes(f.assessorTemplateName));
    }
    else if(this.headerFilterName=='priorityName'){
      if(this.filteredItems.indexOf(item.priorityName)    <0)
      {
        this.filteredItems.push(item.priorityName);
      }
      this.questionDetail=this.totalList.filter(f => this.filteredItems.includes(f.priorityName));
    }
    else if(this.headerFilterName=='modifiedAt'){
      if(this.filteredItems.indexOf(item.modifiedAt)    <0)
      {
        this.filteredItems.push(item.modifiedAt);
      }
      this.questionDetail=this.totalList.filter(f => this.filteredItems.includes(this.datePipe.transform(f.modifiedAt,this.filterdateFormat)));

    }

    else if(this.headerFilterName=='modifiedBy'){
      if(this.filteredItems.indexOf(item.modifiedBy)    <0)
      {
        this.filteredItems.push(item.modifiedBy);
      }
      this.questionDetail=this.totalList.filter(f => this.filteredItems.includes(f.modifiedBy));
    }
    else if(this.headerFilterName=='createdAt'){
      if(this.filteredItems.indexOf(item.createdAt)    <0)
      {
        this.filteredItems.push(item.createdAt);
      }
      this.questionDetail=this.totalList.filter(f => this.filteredItems.includes(this.datePipe.transform(f.createdAt,this.filterdateFormat)));
    }
    else if(this.headerFilterName=='createdBy'){
      if(this.filteredItems.indexOf(item.createdBy)    <0)
      {
        this.filteredItems.push(item.createdBy);
      }
      this.questionDetail=this.totalList.filter(f => this.filteredItems.includes(f.createdBy));
    }

    else if (this.headerFilterName == 'questionDisplayID') {
    if (this.filteredItems.indexOf(item.questionDisplayID) < 0) {
      this.filteredItems.push(item.questionDisplayID);
    }
    this.questionDetail = this.totalList.filter(f => this.filteredItems.includes(f.questionDisplayID));
    }

    else if (this.headerFilterName == 'isLocked') {
      if (this.filteredItems.indexOf(item.isLocked) < 0) {
        this.filteredItems.push(item.isLocked);
      }
      this.questionDetail = this.totalList.filter(f => this.filteredItems.includes(f.isLocked));
    }
  }

  public onDeSelect(item: any) {

    if (this.filteredItems == undefined) {
      this.filteredItems = [];
    }

    if (this.headerFilterName == 'questionText') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.questionText);
      this.questionDetail = this.totalList.filter(f => this.filteredItems.includes(f.questionText));
    }
    else if (this.headerFilterName == 'valueStreamTemplateName') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.valueStreamTemplateName);
      this.questionDetail = this.totalList.filter(f => this.filteredItems.includes(f.valueStreamTemplateName));
    }
    else if (this.headerFilterName == 'assessorTemplateName') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.assessorTemplateName);
      this.questionDetail = this.totalList.filter(f => this.filteredItems.includes(f.assessorTemplateName));
    }
    else if (this.headerFilterName == 'priorityName') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.priorityName);
      this.questionDetail = this.totalList.filter(f => this.filteredItems.includes(f.priorityName));
    }
    else if (this.headerFilterName == 'modifiedAt') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.modifiedAt);
      // this.questionDetail = this.totalList.filter(f => this.filteredItems.includes(f.modifiedAt));
      this.questionDetail=this.totalList.filter(f => this.filteredItems.includes(this.datePipe.transform(f.modifiedAt,this.filterdateFormat)));
    }
    else if (this.headerFilterName == 'modifiedBy') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.modifiedBy);
      this.questionDetail = this.totalList.filter(f => this.filteredItems.includes(f.modifiedBy));
    }
    else if (this.headerFilterName == 'createdAt') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.createdAt);
      this.questionDetail=this.totalList.filter(f => this.filteredItems.includes(this.datePipe.transform(f.createdAt,this.filterdateFormat)));
    }
    else if (this.headerFilterName == 'createdBy') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.createdBy);
      this.questionDetail = this.totalList.filter(f => this.filteredItems.includes(f.createdBy));
    }
    else if (this.headerFilterName == 'questionDisplayID') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.questionDisplayID);
      this.questionDetail = this.totalList.filter(f => this.filteredItems.includes(f.questionDisplayID));
    }
    else if (this.headerFilterName == 'isLocked') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.isLocked);
      this.questionDetail = this.totalList.filter(f => this.filteredItems.includes(f.isLocked));
    }
  }
  onSelectAll(items: any) {

    if(this.filteredItems == undefined ){
      this.filteredItems = [];
     }
    for(var i=0;i<items.length;i++){
      if(this.headerFilterName=='questionText'){
        this.filteredItems.push(items[i].questionText)
      }
      else if(this.headerFilterName=='valueStreamTemplateName'){
        this.filteredItems.push(items[i].valueStreamTemplateName)
      }
      else if(this.headerFilterName=='assessorTemplateName'){
        this.filteredItems.push(items[i].assessorTemplateName)
      }
      else if(this.headerFilterName=='priorityName'){
        this.filteredItems.push(items[i].priorityName)
      }
      else if(this.headerFilterName=='modifiedAt'){
        this.filteredItems.push(items[i].modifiedAt)
      }
      else if(this.headerFilterName=='modifiedBy'){
        this.filteredItems.push(items[i].modifiedBy)
      }
      else if(this.headerFilterName=='createdAt'){
        this.filteredItems.push(items[i].createdAt)
      }
      else if(this.headerFilterName=='createdBy'){
        this.filteredItems.push(items[i].createdBy)
      }
      else if (this.headerFilterName == 'questionDisplayID') {
        this.filteredItems.push(items[i].questionDisplayID)
      }
      else if (this.headerFilterName == 'isLocked') {
        this.filteredItems.push(items[i].isLocked);
      }
    }
    this.questionDetail=this.totalList;
  }
  public onDeSelectAll(items: any) {
    this.filteredItems=[];
    this.questionDetail=this.totalList;
  }
//  *******************************************************************************************Dropdown filtering ends here***************

  assessorIDs: string;
  valueStreamIDs: string;
  onAssessorSelect(item: any) {

    const valueStreamsIDArr = this.valueStreams.map(r => r.valueStreamID.toString());

    if(this.isAdd && this.unload)
    {
      this.selectedValueStreams=this.selectedValueStreams.filter(t=>this.valueStreams.find(x=>x.valueStreamID==t.valueStreamID));

    }
    const assessorIDArr = this.assessors.map(r => r.assessorID.toString());
    this.assessorValueStreamList.assessorIDs = assessorIDArr.toString();
    this.assessorValueStreamList.valueStreamIDs = valueStreamsIDArr.toString();

    //Commented the below founction for to show the processconfirmation type alone for Phase1 Release

    //this.tagService.fetchTagsByAssessorsAndValueStreams(this.assessorValueStreamList).subscribe(data => {
    //  this.availableTags = data;
      this.tagService.fetchProcessConfirmationTags().subscribe(res =>{
        if(res && res.length >0)
        {
          if(this.availableTags && this.availableTags.length >1)
          {
            for(let tag of res)
            {
              if(this.availableTags.filter(x =>x.tagID == tag.tagID).length <1)
              {
                this.availableTags.push(tag);
              }
            }
          }
          else{
            this.availableTags = res;
          }
          //to filter the available tags based on selected tags
          if(this.selectedTags && this.selectedTags.length > 0){
            for(let tag of this.selectedTags){
              if(this.availableTags && this.availableTags.length >0){
                this.availableTags = this.availableTags.filter(x =>x.tagID !== tag.tagID);
              }
            }
          }
        }
        this.sharedService.hide();
      })



    //}, err => console.error(err));
  }
  onAssessorSelectAll(items: any) {
    this.onAssessorSelect(undefined);

  }

  public getAssessorTemplateList() {
   
    this.assessorTemplateList = [];
    this.assessorTemplateService.getAssessorTemplates().subscribe(res => {
      this.assessorTemplateList = res;
      this.onLoadAssessorTemplate();

     // console.log(this.assessorTemplateList);
      // this.assessorTemplateService.getAssessors().subscribe(res1 => {
      //   this.assessors = res1;
      //    // to limit the assessors based on Assesor ID
      // this.assessors = this.assessors.filter(x =>x.assessorTemplateID == this.question.assigned_AssessorTemplateID);

    },
      err => {
        console.log(err);
      }
    );
  }

  // to load the value streams based on list/tree view in VS Template
  valueStreamTemplateChange(valueStreamTempID: any) {
    //this.valueStreams = [];
    //this.selectedValueStreams = [];
    debugger;
    this.visulizationViewModeID = this.valueStreamTemplates.filter(x =>x.valueStreamTemplateID == valueStreamTempID)[0].visualizationViewModeID;

    if(this.visulizationViewModeID == 2){
      const selectedItem = this.valueStreamCategories.find(x => x.valueStreamTemplateID == valueStreamTempID);

      if(selectedItem === undefined){

        this.valueStreamService.getValueStreamCategoryByTemplateID(valueStreamTempID).subscribe(res => {
          //this.valueStreamCategories = [];
          //this.valueStreamCategories = res;          
          this.valueStreamCategories.push(...res);
          if(this.selectedItemValueStreamTemplate!==undefined && this.selectedItemValueStreamTemplate!== null && this.selectedItemValueStreamTemplate.length==1){
            this.valueStreams=this.valueStreamCategories.length >0 ?[]:this.valueStreams;
          }
           this.valueStreamCategories = this.valueStreamCategories.filter(x => x.valueStreamCategoryName !== "VS Responsible Employee" && x.valueStreamCategoryName !== "SHIFT")
          this.onLoadValueStreamCategories();
        },
          err => {
            console.log(err);
          });
      }

      if(selectedItem !== undefined){

        this.valueStreamService.getValueStreamCategoryByTemplateID(valueStreamTempID).subscribe(res => {
          console.log(this.valueStreamCategories)
          this.valueStreamCategories = [];
          //this.valueStreamCategories = res;
          this.valueStreamCategories.push(...res);
          if(this.selectedItemValueStreamTemplate!==undefined && this.selectedItemValueStreamTemplate!== null && this.selectedItemValueStreamTemplate.length==1 && this.visulizationViewModeID == 2){
            this.valueStreams=this.valueStreamCategories.length >0 ?[]:this.valueStreams;
          }
          this.valueStreamCategories = this.valueStreamCategories.filter(x => x.valueStreamCategoryName !== "VS Responsible Employee" && x.valueStreamCategoryName !== "SHIFT")
          this.onLoadValueStreamCategories();
        },
          err => {
            console.log(err);
          });
      }



    }
    else{

      const selectedItem = this.valueStreams.find(x => x.valueStreamTemplateID == valueStreamTempID);
 
      if(selectedItem === undefined){
        this.valueStreamService.getValueStreamsByTemplateID(valueStreamTempID).subscribe(res =>{
          //this.valueStreams = [];
         // this.valueStreams = res;
          this.valueStreams.push(...res);
          this.valueStreams = this.valueStreams.filter(x =>x.valueStreamName && x.responsible_UserID);
  
        },
        err =>{
          console.log(err);
        });
      }

      if(selectedItem !== undefined){
      this.valueStreamService.getValueStreamsByTemplateID(valueStreamTempID).subscribe(res =>{
        this.valueStreams = [];
       // this.valueStreams = res;
        this.valueStreams.push(...res);
        this.valueStreams = this.valueStreams.filter(x =>x.valueStreamName && x.responsible_UserID);

      },
      err =>{
        console.log(err);
      });
    }

    }
  }
  //to fix scroll issue after pop up
  public closeAlertModal(){
    //console.log(document.getElementsByTagName("modal-container"));
    if(document.getElementsByTagName("modal-container").length > 1){
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length-1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length-1]);
    }
    else{
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if(document.getElementsByTagName("bs-modal-backdrop").length > 0){
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }

  }

  onValuestreamOpen(){
    console.log(this.valueStreams)
    this.isLoading=true;
    this.valueStreams=JSON.parse(JSON.stringify(this.valueStreams))
    this.isLoading=false;
  }

  onassessorOpen() {
    console.log(this.assessors)
    this.isLoading=true;
    this.assessors=JSON.parse(JSON.stringify(this.assessors))
    this.isLoading=false;
  }

  valueStreamCategoryChange(valueStreamCategoryID: number) {
   //this.valueStreams = [];
    //this.selectedValueStreams = [];
    const selectedItem = this.valueStreams.find(x => x.valueStreamCategoryID == valueStreamCategoryID);

    if(selectedItem === undefined){
      this.valueStreamService.getValueStreamsByCategoryID(valueStreamCategoryID).subscribe(res => {
        this.valueStreams.push(...res);
        //this.valueStreams = res;
        this.valueStreams = this.valueStreams.filter(x =>x.valueStreamName && x.responsible_UserID);
      },
        err => {
          console.log(err);
        });
    }

    if(selectedItem !== undefined){
      this.valueStreamService.getValueStreamsByCategoryID(valueStreamCategoryID).subscribe(res => {
        this.valueStreams = [];
        this.valueStreams.push(...res);
        this.valueStreams = this.valueStreams.filter(x =>x.valueStreamName && x.responsible_UserID);
      },
        err => {
          console.log(err);
        });
    }
  }

  handleFileInput(files: any) {

    this.formData = new FormData();

    for (let file of files)
      this.formData.append(file.name, file);
    this.question.hintImage = this.formData;
    var reader = new FileReader();
    reader.onload = function () {

      var arrayBuffer = files[0],
        array = new Uint8Array(arrayBuffer),
        binaryString = String.fromCharCode.apply(null, array);
    };
    reader.readAsArrayBuffer(files[0]);

  }


  public getAssessorsByTemplateID(templateID: any) {
    console.log(this.assessors)
    let selectedItem = this.assessors.find(x => x.assessorTemplateID == templateID);
    this.assessors=this.assessors.filter(t=>this.selectedItemAssessorTemplate.find(x=>x.assessorTemplateID==t.assessorTemplateID));
    if(selectedItem == undefined ){
      this.assessorTemplateService.getAssessorsByTemplateID(templateID).subscribe(
        res => {
          let X = this.assessors;
          this.assessors = res;
          this.assessors.push(...X);
        },
        err => {
          console.log(err);
        }
      );
    }

    if(selectedItem !== undefined ){
      this.assessorTemplateService.getAssessorsByTemplateID(templateID).subscribe(
        res => {
          this.assessors = [];
          this.assessors.push(...res);
        },
        err => {
          console.log(err);
        }
      );
    }
  }


// ******************************GetQuestionDetails**************

  public async getQuestionDetail() {
  this.choiceDisplayTypeList = [];
  this.answerTypeList = [];

    //Get all Value Streams
    // await this.valueStreamService.getValueStream().subscribe(res2 => {

    //   this.valueStreams = res2;

    //    //Get all Value Stream cATEGORIES
    //   this.valueStreamService.getValueStreamCategory().subscribe(res4 => {
    //     this.valueStreamCategories = res4;

    //         this.valueStreams=this.valueStreams.filter(r=>this.selectedItemValueStreamTemplate.find(x=>x.valueStreamTemplateID== r.valueStreamTemplateID));

    //    //Get all Assesssors 
    //   this.assessorTemplateService.getAssessors().subscribe(res3 => {
    //     this.assessors = res3;

        //this.assessors=this.assessors.filter(r=>this.selectedItemAssessorTemplate.find(x=>x.assessorTemplateID== r.assessorTemplateID));

   //Get all Questions List 
   await this.questionService.getQuestionDetail().subscribe(res => {

    this.questionDetail = res;

  //   for(var k=0;k<this.questionDetail.length;k++)
  //   {
  //     if(this.questionDetail[k].valueStreamIDList != null && this.questionDetail[k].assessorIDList != null)
  //     {
  //   //Value Stream Template List - valuestreamTemplateList
  //   this.valuestreamTemplateList=this.getVSTemplate(this.questionDetail[k].valueStreamIDList,res2);
  //   //Assessor Stream Template List - assesorTemplateList
  //   this.assesorTemplateList=this.getASTemplate(this.questionDetail[k].assessorIDList,res3);
  //   //Value Stream Category Template List - valuestreamcategoryTemplateList
  //   this.valuestreamcategoryTemplateList=this.getVSCategoryTemplate(this.questionDetail[k].valueStreamIDList,res4);
 

  //   this.questionDetail[k].valueStreamTemplateNameArL = this.valuestreamTemplateList;

  //   this.questionDetail[k].assessorTemplateNameArL=this.assesorTemplateList;

  //   this.questionDetail[k].valueStreamCategoryNameArL=this.valuestreamcategoryTemplateList;
    
 

  //     }
  //  }
    this.totalList=this.questionDetail;//mk

    // console.log(this.totalList,"Template")
    if(this.questionDetail && this.fromdatapoolQuestion) {
      this.getQuestionDetailByID(this.datapoolquestionid);
    }

    this.sharedService.hide();
    if (this.sharedService.activeDateRange != null && this.sharedService.activeDateRange.questionSearchText != null 
      &&  this.sharedService.activeDateRange.questionSearchText.length > 0 ) {
      this.questionSearchText = this.sharedService.activeDateRange.questionSearchText;
      this.searchGrid(this.sharedService.activeDateRange.questionSearchText);
    }
  },
    err => {
      console.log(err);
      this.sharedService.hide();
    });
      
   // });
  //});
//});


}

public getQuestionDetailByID(questionID: number) {
  this.choiceDisplayTypeList = [];
  this.answerTypeList = [];
  this.questionService.getQuestionDetailByID(questionID).subscribe(res => {
    if(res !=null){
      console.log("1043",questionID)
      let res1:any;
      if(this.questionDetail && this.fromdatapoolQuestion) {
        for(let i=0;i<this.questionDetail.length;i++) {
          if(this.questionDetail[i].questionID ==res[0].questionID) {
            res1 = this.questionDetail[i];
          }
        }
      }
      this.editQuestion(res1);
    }
  },
    err => {
      console.log(err);
    }
  );
}

// ****************************************************************
  public getQuestionList() {

    this.choiceDisplayTypeList = [];
    this.answerTypeList = [];

    this.questionService.getQuestions().subscribe(res => {

      this.questionList = res;
    },
      err => {
        console.log(err);
      }
    );
  }
  

  public getValueStreamList() {
    debugger;
    this.valueStreamTemplates = [];
    this.valueStreamService.getValueStreamTemplate().subscribe(res => {
      debugger;
      this.valueStreamTemplates = [];
      this.valueStreamTemplates = res;
      this.onLoadValueStreamTemplate();
      this.valueStreamService.getValueStreamCategory().subscribe(res1 => {
        debugger;
        this.valueStreamCategories = res1;
        this.valueStreamCategories = this.valueStreamCategories.filter(x =>x.valueStreamCategoryName !=="VS Responsible Employee" && x.valueStreamCategoryName !=="SHIFT")

        this.valueStreamService.getValueStream().subscribe(res2 => {
          debugger
          this.valueStreams = res2;
          //console.log(res2[0], "INFO")

       
           // to limit the valuestreams based on VS template ID
      //this.valueStreamCategories = this. valueStreamCategories.filter(x =>  this.question.assigned_ValueStreamTemplateID.find(y=> y == x.valueStreamTemplateID));
      //this.valueStreams = this.valueStreams.filter(x =>this.question.assigned_ValueStreamTemplateID.find(y=> y == x.valueStreamTemplateID) && x.valueStreamName); //to fetch the last nodes

  
          if (this.isEdit) {
            //to make the list/tree view selection for value stream templates
            //let vsListType = this.valueStreamTemplates.filter(x =>x.valueStreamTemplateID == this.question.assigned_ValueStreamTemplateID)[0].visualizationViewModeID;

            // if(this.isEdit && vsListType == 1){
            //   this.question.assigned_ValueStreamCategoryID = undefined;
            //  this.valueStreamCategories =[];
            // }}

            //console.log(this.question, "IN");

          
            if (this.selectedItemValueStreamTemplate.filter(x => x.visualizationViewModeID == 2).length == 0) {
              this.question.assigned_ValueStreamCategoryID = undefined;
              this.valueStreamCategories = [];
            }
            
            // for(let ind=0; ind < this.valueStreamCategories.length;ind++)
            // {
            //   //this.valueStreams=this.valueStreams.filter(r=>this.selectedItemValueStreamTemplate.find(x=>x.valueStreamTemplateID== r.valueStreamTemplateID ));
            //   this.valueStreamCategories[ind].valueStreamCategoryID;
            //   for(let j=0;j<this.valueStreams.length;j++)
            //   {
            //     if(this.valueStreams[j].valueStreamCategoryID==this.valueStreamCategories[ind].valueStreamCategoryID)
            //     {
            //       const selectedItem = this.valueStreamCategories[ind];
            //       if (selectedItem)
            //         this.selectedItemValueStreamCategories.push(selectedItem);
            //     }
            //   }
            // }
       
            this.valueStreams=this.valueStreams.filter(r=>this.selectedItemValueStreamTemplate.find(x=>x.valueStreamTemplateID== r.valueStreamTemplateID ));
            


          
            this.valueStreamCategories=this.valueStreamCategories.filter(r=>this.selectedItemValueStreamTemplate.find(x=>x.valueStreamTemplateID== r.valueStreamTemplateID && x.visualizationViewModeID==2));

            this.assessors=this.assessors.filter(t=>this.selectedItemAssessorTemplate.find(x=>x.assessorTemplateID==t.assessorTemplateID));
          
            
  // let valueStreamsCategory=this.selectedValueStreams.filter(r=>r.valueStreamCategoryName.toLowerCase() !="VS Responsible Employee".toLowerCase());
             
  // let selectedCategory=this.valueStreamCategories.filter(r=>valueStreamsCategory.find(t=>t.valueStreamCategoryID==r.valueStreamCategoryID));
  // this.selectedItemValueStreamCategories=selectedCategory;


          }

          //this.sharedService.hide();

        

        }, err => { console.log(err) })
          ;
      }, err => { console.log(err) });


    },
      err => {
        console.log(err);
      }
    );
  
  }

  onValuestreamCategoryOpen(){
    debugger;
    this.isLoading=true;
    console.log(this.valueStreamTemplates)
    console.log(this.selectedItemValueStreamTemplate)
    let  filteredList = this.selectedItemValueStreamTemplate.filter(item =>
      this.valueStreamTemplates.some(template =>
          template.valueStreamTemplateID === item.valueStreamTemplateID &&
          template.visualizationViewModeID === 2
      )
    );
    this.valueStreamService.getValueStreamCategory().subscribe(res4 => {
      this.valueStreamCategories = res4;
      this.valueStreamCategories = this.valueStreamCategories.filter(category => 
        filteredList.some(template => 
            template.valueStreamTemplateID === category.valueStreamTemplateID 

        )
        && 
    category.valueStreamCategoryName.trim() !== "VS Responsible Employee" && 
    category.valueStreamCategoryName.trim() !== "SHIFT"
      )
      this.isLoading=false;
      //  this.valueStreamCategories = res4;
      //  this.valueStreamCategories = this.valueStreamCategories.filter(x =>x.valueStreamTemplateID ==this.selectedItemValueStreamTemplate[0].valueStreamTemplateID)
    });
    
  }

  public addQuestion() {
    
    console.log(this.valueStreamTemplates)
    console.log(this.valueStreams)
    console.log(this.valueStreamCategories)
    this.selectedItemValueStreamTemplate = [];
    this.selectedItemValueStreamCategories = [];
    this.selectedItemAssessorTemplate = [];
   // this.getValueStreamList()
    
    // console.log(this.valuestreamTemplateList)
    // console.log(this.selectedItemAssessorTemplate);
    // if(this.selectedItemAssessorTemplate.length < 1)
    // {

    //   this.valueStreams=[];
    //   this.selectedValueStreams=[];

    //  this.valueStreamCategories=[];
    //  this.selectedItemValueStreamCategories=[];

    //   this.assessors = [];
    //   this.selectedAssessors = [];
    // }

    this.isAdd = true;
    this.question = new Question();
    //this.question.assigned_AssessorTemplateID = [];
   // this.question.assigned_ValueStreamTemplateID = [];
    this.question.question_PriorityID = 4;
    this.question.answerType_AnswerTypeID = 3;
    this.question.isFilledInChoiceAllowed = false;
    this.question.isQuestionAlwaysActive = true;
    this.question.isUniqueAnswerRequired = false;
    this.question.isAnswerRequired = false;
    this.question.isDefaultAnswerRequired = false;
    this.question.isTargetFrequencyDefined = false;
    this.question.isDeleted = false;
    this.question.isLocked = false;
    this.answerTypeID = 3;
    this.question.choiceDisplayTypeID = 1;
    this.getChoiceDisplayTypes();
    this.getAnswerTypes();
    this.hyperLinkUrls = [];
    this.urls = [];
    this.choices = [];
    this.answerTypeNumber = new AnswerTypeNumber();
    this.answerTypeCurrency = new AnswerTypeCurrency();
    this.answerTypeDateTime = new AnswerTypeDateTime();
    this.ratingScale = new RatingScale();
    this.singleLineText = new SingleLineText();
    this.multipleLinesText = new MultipleLinesText();
    this.choice = new Choice();


    this.choices = [{ choiceName: "", choiceScore: undefined,answerCategory:"", isDeviationEntryRequired: false }];
    this.assignedTargetFrequency = [];
    var d = new Date();
    this.question.activeDateRangeFrom = new Date(d.getFullYear(),d.getMonth(),d.getDate());
    this.question.activeDateRangeTo = new Date(d.getFullYear(),d.getMonth(),d.getDate());

    this.onAssessorSelect(null); //to load the default tags
     this.getQuestionList();
    //this.getValueStreamList();
    this.valueStreamService.getValueStreamTemplate().subscribe(res => {
      //debugger;
      this.valueStreamTemplates = [];
      this.valueStreamTemplates = res;
      this.valueStreamCategories=[]
    });
    this.getAssessorTemplateList();
    
  //   this.valueStreamService.getValueStream().subscribe(res2 => {
  //     this.valueStreams = res2;
  //      //Get all Value Stream cATEGORIES
  //     this.valueStreamService.getValueStreamCategory().subscribe(res4 => {
     
  //       this.valueStreamCategories = res4;
  //      //Get all Assesssors 
  //     this.assessorTemplateService.getAssessors().subscribe(res3 => {
  //       this.assessors = res3;
  //     })
  //   })
  // })

  }



  redirect() {

    this.sharedService.show();
    this.isEdit = false;
    this.isAdd = false;
    this.question = new Question();
    this.selectedAssessors = [];
    this.selectedValueStreams = [];
    this.selectedTags = [];
    this.getQuestionDetail(); //for Question Details
    this.questionUnChecked = true;
    this.questionChecked = false;
  }

  options = ['OptionA', 'OptionB', 'OptionC'];
  optionsMap = {
    OptionA: false,
    OptionB: false,
    OptionC: false,
  };
  optionsChecked = [];

  updateCheckedOptions(option, event) {
    this.optionsMap[option] = event.target.checked;
  }

  public getChoiceDisplayTypes() {
    this.commonService.getChoiceDisplayTypes().subscribe(res => {
      this.choiceDisplayTypeList = res;
    },
      err => console.log(err));
  }

  public getHintImages(questionID: any) {

    this.questionService.hintImagesByQuestionID(questionID).subscribe(res => {
      this.urls = [];
      this.urls = res;
      this.questionService.hintHyperLinksByQuestionID(questionID).subscribe(res => {
        this.hyperLinkUrls = res;
        this.questionService.valueStreamsByQuestionID(this.question.questionID).subscribe(data => {
          this.selectedValueStreamIDs = [];
          this.selectedValueStreamIDs = data;

          this.selectedValueStreams = [];
         
          for (let obj of this.selectedValueStreamIDs) {
            let vs = this.valueStreams.filter(x => x.valueStreamID == obj.valueStreamID)[0];
            if (vs) { //to get the id of Assigned ValueStreams Table
              vs.id = obj.id;
              this.selectedValueStreams.push(vs);
            }

          }


          this.questionService.tagsByQuestionID(questionID).subscribe(data => {
            this.selectedTags = data;
            if(this.selectedTags && this.selectedTags.length > 0){
              for(let tag of this.selectedTags){
                if(this.availableTags && this.availableTags.length >0){
                  this.availableTags = this.availableTags.filter(x =>x.tagID !== tag.tagID);
                }
              }
            }
          }, err => console.log(err)
          );


          this.questionService.assessorsByQuestionID(this.question.questionID).subscribe(data1 => {
            this.selectedAssessorIDs = [];
            this.selectedAssessorIDs = data1;

            this.selectedAssessors = [];
            for (let asrObj of this.selectedAssessorIDs) {
              let asr = this.assessors.filter(x => x.assessorID == asrObj.assessorID)[0];
              if (asr) {
                asr.id = asrObj.id;
              this.selectedAssessors.push(asr);}
            }

            let valueStreamsCategory=this.selectedValueStreams.filter(r=>r.valueStreamCategoryName.toLowerCase() !="VS Responsible Employee".toLowerCase());
             
            let selectedCategory=this.valueStreamCategories.filter(r=>valueStreamsCategory.find(t=>t.valueStreamCategoryID==r.valueStreamCategoryID));
            this.selectedItemValueStreamCategories=selectedCategory;
            //to display the linked tags with question
            this.onAssessorSelect(undefined);


            if (this.question.answerType_AnswerTypeID == 4) {
              this.questionService.subQuestionsByQuestionID(this.question.questionID).subscribe(
                res1 => {
                  this.subQuestions = res1;
                }, err => { console.log(err) });
            }
          }, err => { console.log(err) });
        },
          err => { console.log(err) });

      },
        err => console.log(err));
    },
      err => console.log(err));
  }


  public getAnswerTypes() {
    this.commonService.getAnswerTypes().subscribe(res => {
      this.answerTypeList = res;
    },
      err => console.log(err));
  }
  generateHyperLink(url: any, title: any) {
    this.hyperLinkUrl = new HintHyperLink();
    if (url != undefined && url != null && title != undefined && title != null) {
      this.hyperLinkUrl.hyperLinkUrl = url;
      this.hyperLinkUrl.hyperLinkTitle = title;
      this.hyperLinkUrls.push(this.hyperLinkUrl);
      this.question.hyperLinkUrl = undefined;
      this.question.hyperLinkTitle = undefined;
    }
  }

  onSelectFile(event) {
  //validate the file if file size is more than 10MB
  for (var i = 0; i < event.target.files.length; i++) {
    var name = event.target.files[i].name;
    var type = event.target.files[i].type;
    var size = event.target.files[i].size;
    var modifiedDate = event.target.files[i].lastModifiedDate;

    if(size >environment.maxFileSize){
      this.alertText = this.labels.default.maximumFileSize;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      return;
    }

    console.log ('Name: ' + name + "\n" +
      'Type: ' + type + "\n" +
      'Last-Modified-Date: ' + modifiedDate + "\n" +
      'Size: ' + Math.round(size / 1024) + " KB");
  }
// *************************validation of file size ends here**************
 let now = new Date();

 var  jstoday;
 jstoday = formatDate(now, 'dd_MM_yyyy hh_mm_ss_a', 'en-US', '+0530').toString();



    let totalSize = 0;
    if (event.target.files && event.target.files[0]) {
      var filesAmount = event.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        let name = event.target.files[i].name;

  //  ************************ validation of file Type*********************************************************************************

  // if (!name.match(/.(jpg|jpeg|png|gif|txt|pdf|doc|docx|xls|xlsx|csv|mp4)$/i)){
        var fileTypes = environment.fileTypes.split(",").map(function (item) {
          return item.trim();
        });
        var extension = name.slice((Math.max(0, name.lastIndexOf(".")) || Infinity) + 1);
        let x = fileTypes.filter(x => x.toLocaleLowerCase() == extension.toLocaleLowerCase());

        if (x.length == 0) {
          this.alertText = name + this.labels.default.fileUploadError.replace("((FileTypes))", environment.fileTypes);
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          return;
        }

  //  *************************Validation Ends*****************************************************************************************

        let size = event.target.files[i].size;
        reader.onload = (event: any) => {

          this.url = new HintImage();
          // this.url.imageTitle = name;
          this.url.imageTitle =jstoday+"_"+ name;
          this.url.displayFileName=name; //adding displayname

          this.url.size = size;
          this.url.fileContent = event.target.result;

          if (extension == "jpg" || extension == "jpeg" || extension == "png") {
            var compressed = this.sharedService.compressImage(event.target.result, "image/jpeg", 0.5, 0.9);
            if (compressed != "data:,")
              this.url.fileContent = compressed;
          }
          
          for (let row of this.urls) {
            totalSize += row.size;
          }
          totalSize += size;
          if (totalSize > (environment.maxFileSize*environment.maxAttachments) || this.urls.length >= environment.maxAttachments) {
            this.alertText = this.labels.default.maximumFileSize;
            this.modalService.show(this.warningModal);
            $("modal-container").removeClass("fade");
            $(".modal-dialog").addClass("modalSize");
            return;
          }
          if (this.urls == undefined) {
            this.urls = [];
          }
          this.urls.push(this.url);
        }

        reader.readAsDataURL(event.target.files[i]);
      }

    }
    this.fileInputVariable.nativeElement.value = "";
  }

  onSelectQueFile(event) {
    //validate the file if file size is more than 10MB
    for (var i = 0; i < event.target.files.length; i++) {
      var name = event.target.files[i].name;
      var type = event.target.files[i].type;
      var size = event.target.files[i].size;
      var modifiedDate = event.target.files[i].lastModifiedDate;
  
      if(size >environment.maxFileSize){
        this.alertText = this.labels.default.maximumFileSize;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        return;
      }
  
      console.log ('Name: ' + name + "\n" +
        'Type: ' + type + "\n" +
        'Last-Modified-Date: ' + modifiedDate + "\n" +
        'Size: ' + Math.round(size / 1024) + " KB");
    }
  // *************************validation of file size ends here**************
   let now = new Date();
  
   var  jstoday;
   jstoday = formatDate(now, 'dd_MM_yyyy hh_mm_ss_a', 'en-US', '+0530').toString();
  
  
  
      let totalSize = 0;
      if (event.target.files && event.target.files[0]) {
        var filesAmount = event.target.files.length;
        for (let i = 0; i < filesAmount; i++) {
          var reader = new FileReader();
          let name = event.target.files[i].name;
  
    //  ************************ validation of file Type*********************************************************************************
  
    // if (!name.match(/.(jpg|jpeg|png|gif|txt|pdf|doc|docx|xls|xlsx|csv|mp4)$/i)){
          var fileTypes = environment.fileTypes.split(",").map(function (item) {
            return item.trim();
          });
          var extension = name.slice((Math.max(0, name.lastIndexOf(".")) || Infinity) + 1);
          let x = fileTypes.filter(x => x.toLocaleLowerCase() == extension.toLocaleLowerCase());
  
          if (x.length == 0) {
            this.alertText = name + this.labels.default.fileUploadError.replace("((FileTypes))", environment.fileTypes);
            this.modalService.show(this.warningModal);
            $("modal-container").removeClass("fade");
            $(".modal-dialog").addClass("modalSize");
            return;
          }
  
    //  *************************Validation Ends*****************************************************************************************
  
          // let size = event.target.files[i].size;
          // reader.onload = (event: any) => {
  
          //   this.url = new HintImage();
          //   // this.url.imageTitle = name;
          //   this.url.imageTitle =jstoday+"_"+ name;
          //   this.url.displayFileName=name; //adding displayname
  
          //   this.url.size = size;
          //   this.url.fileContent = event.target.result;
  
          //   if (extension == "jpg" || extension == "jpeg" || extension == "png") {
          //     var compressed = this.sharedService.compressImage(event.target.result, "image/jpeg", 0.5, 0.9);
          //     if (compressed != "data:,")
          //       this.url.fileContent = compressed;
          //   }
            
          //   for (let row of this.urls) {
          //     totalSize += row.size;
          //   }
           // totalSize += size;
           // if (totalSize > (environment.maxFileSize*environment.maxAttachments) || this.urls.length >= environment.maxAttachments) {
            
           if (extension != "xls" && extension != "xlsx") {  
           this.alertText = this.labels.default.fileTypeError;
              this.modalService.show(this.warningModal);
              $("modal-container").removeClass("fade");
              $(".modal-dialog").addClass("modalSize");
              return;
          }
        }
      }
      let fileReader = new FileReader();
      this.file= event.target.files[0]; 
      fileReader.onload = (e) => {
          this.arrayBuffer = fileReader.result;
          var data = new Uint8Array(this.arrayBuffer);
          var arr = new Array();
          for(var i = 0; i != data.length; ++i) arr[i] = String.fromCharCode(data[i]);
          var bstr = arr.join("");
          var workbook = XLSX.read(bstr, {type:"binary"});
          var first_sheet_name = workbook.SheetNames[0];
          var worksheet = workbook.Sheets[first_sheet_name];
          // var dataarray = XLSX.utils.sheet_to_json(worksheet,{raw:true});
          // console.log(XLSX.utils.sheet_to_json(worksheet,{raw:true}));
          var dataarray = XLSX.utils.sheet_to_json(worksheet,{ header: 1 });
          console.log(XLSX.utils.sheet_to_json(worksheet,{ header: 1 }));
          this.question.questionText = "";
          this.question.questionHintText = "";
          for(var n = 0; n < dataarray.length; n++){
            this.question.questionText += dataarray[n][0] + "!@#$%";  
            this.question.questionHintText += dataarray[n][1] + "!@#$%";
          }
          this.question.questionText = this.question.questionText.slice(0,-5);
          this.question.questionHintText = this.question.questionHintText.slice(0,-5);
          //this.question.questionText = (XLSX.utils.sheet_to_json(worksheet,{raw:true})["Question"]).toString();
      }
      fileReader.readAsArrayBuffer(this.file);
    }
          
  

  removeHintImage(name) {
    this.urls = this.urls.filter(x => x.imageTitle !== name);
  }

  removeHintHyperLink(name: any) {
    this.hyperLinkUrls = this.hyperLinkUrls.filter(x => x.hyperLinkTitle !== name);
  }

  addChoiceRow(i) {
    if (this.choices.length - 1 == i) {
      this.choice = new Choice();
      this.choices.push(this.choice);
    }
  }

  addQuestionRow(i) {
    if (this.subQuestions.length - 1 == i) {
      this.subQuestion = new SubQuestion();
      this.subQuestions.push(this.subQuestion);
    }
  }


  //tempStartDate: any[];
  //tempEndDate: any[];

  //startDate: Date;
  //endDate: Date;

  save(question: Question) {
    //debugger;
  //  this.tempStartDate = this.question.activeDateRangeFrom.toString().split('-');
  //  this.tempEndDate = this.question.activeDateRangeTo.toString().split('-');

  //  if(this.question.isQuestionAlwaysActive == false){
  //  if(this.tempStartDate.length == 1)
  //  {
  //    this.startDate = new Date(Date.UTC(this.question.activeDateRangeFrom.getFullYear(),this.question.activeDateRangeFrom.getMonth(),this.question.activeDateRangeFrom.getDate(),this.question.activeDateRangeFrom.getHours(),this.question.activeDateRangeFrom.getMinutes(),this.question.activeDateRangeFrom.getSeconds()));
  //    this.question.activeDateRangeFrom = this.startDate;
  //  }
  //  else{
  //    this.tempStartDate = this.question.activeDateRangeFrom.toString().split('-');
  //    this.startDate = new Date(Date.UTC(this.tempStartDate[2],this.tempStartDate[1]-1,this.tempStartDate[0]));
  //    this.question.activeDateRangeFrom = this.startDate;
  //  }
  //  if(this.tempEndDate.length == 1)
  //  {
  //    this.endDate = new Date(Date.UTC(this.question.activeDateRangeTo.getFullYear(),this.question.activeDateRangeTo.getMonth(),this.question.activeDateRangeTo.getDate(),this.question.activeDateRangeTo.getHours(),this.question.activeDateRangeTo.getMinutes(), this.question.activeDateRangeTo.getSeconds()));
  //    this.question.activeDateRangeTo = this.endDate;
  //  }
  //  else{
  //    this.tempEndDate = this.question.activeDateRangeTo.toString().split('-');
  //    this.endDate = new Date(Date.UTC(this.tempEndDate[2],this.tempEndDate[1]-1,this.tempEndDate[0]));
  //    this.question.activeDateRangeTo = this.endDate;

  //  }
  //}
    
    this.question.activeDateRangeFrom = new Date(Date.UTC(this.question.activeDateRangeFrom.getFullYear(), this.question.activeDateRangeFrom.getMonth(), this.question.activeDateRangeFrom.getDate(), 0, 0, 0));
    this.question.activeDateRangeTo =  new Date(Date.UTC(this.question.activeDateRangeTo.getFullYear(), this.question.activeDateRangeTo.getMonth(), this.question.activeDateRangeTo.getDate(), 23, 59, 59));

    this.isDisabled = false;
    var isvalid = true;
    if (this.isAdd) {
       //this.question.questionText.split('.,').forEach(element => {
        var ques = this.question.questionText.split('!@#$%');
        var quenames = "";
        for(var i=0; i<ques.length;i++){
        var que = ques[i].toLowerCase();
        var existingQuestions = this.questionList.filter(x => x.questionText.toLowerCase() === que);
        if (existingQuestions.length > 0) {
          quenames = quenames + que + ',';
          
         isvalid = false;
         //break;
        //return ;
        }        
      }
      if(!isvalid){
      this.alertText = this.labels.default.uniqueQName + "\n" + this.labels.default.alreadyQTaken + ": \n\n" + quenames.substring(0, quenames.length-1);
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          this.isDisabled = true;
      }
    }
    else if (this.isEdit) {
      var existingQuestions = this.questionList.filter(x => x.questionText.toLowerCase() === this.question.questionText.toLowerCase() && x.questionID !== this.question.questionID);
      if (existingQuestions.length > 0) {
        this.alertText = this.labels.default.uniqueQName + "\n" + this.labels.default.alreadyQTaken + ": \n\n" + question.questionText;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;

        return;
      }
    }

    if (this.question.answerType_AnswerTypeID == 1) {
      if (this.singleLineText.maxCharacters == undefined) {
        this.alertText = this.labels.default.singleLineText;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;

        return;
      }
      if (this.singleLineText.maxCharacters > 2000) {
        this.alertText = this.labels.default.singleLineMaximum2000;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;

        return;
      }
      if (this.singleLineText.maxCharacters < 1) {
        this.alertText = this.labels.default.singleLineMinimum1;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;

        return;
      }
    }
    else if (this.question.answerType_AnswerTypeID == 2) {
      if (this.multipleLinesText.maxLines == undefined) {
        this.alertText = this.labels.default.numberOfLine;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;

        return;
      }
      if (this.multipleLinesText.maxLines > 6) {
        this.alertText = this.labels.default.multiLineMaximum6;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;

        return;
      }
      if (this.multipleLinesText.maxLines < 1) {
        this.alertText = this.labels.default.multiLineMinimum1;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;

        return;
      }
    }
    else if (this.question.answerType_AnswerTypeID == 3) {

      for (let choice of this.choices) {
        choice.isDeviationEntryRequired = choice.isDeviationEntryRequired ? true : false;
      }
      this.question.choices = this.choices.filter(x => x.choiceName !== undefined && x.choiceName !== null && x.choiceName !== "");
      let error = false;
      this.question.choices.forEach((item, index) => {
        if (item.choiceName === undefined || item.choiceScore === undefined || item.answerCategory === undefined  || item.answerCategory === null || item.answerCategory === "" || item.deviationTypeID === 0) {
          error = true;
        }
      });
      if (this.question.choices.length < 2) {
        this.alertText = this.labels.default.atleastTwoChoices;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;

        return;
      }
      if (error) {
        this.alertText = this.labels.default.allEntriesChoice;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;

        return;
      }
    }

    if (this.question.answerType_AnswerTypeID == 1) {
      this.question.singleLineText = this.singleLineText;
    }
    else if (this.question.answerType_AnswerTypeID == 2) {
      this.question.multipleLinesText = this.multipleLinesText;
    }
    else if (this.question.answerType_AnswerTypeID == 4) {
      this.question.ratingScale = this.ratingScale;
      this.question.subQuestions = this.subQuestions;
    }
    else if (this.question.answerType_AnswerTypeID == 5) {
      this.question.answerTypeNumber = this.answerTypeNumber;
    }
    else if (this.question.answerType_AnswerTypeID == 6) {
      this.question.answerTypeCurrency = this.answerTypeCurrency;
    }
    else if (this.question.answerType_AnswerTypeID == 7) {
      this.question.answerTypeDateTime = this.answerTypeDateTime;
    }
    this.question.modifiedAt = new Date();
    this.question.hintHyperLinks = this.hyperLinkUrls;
    this.question.hintImages = this.urls;
    this.question.answerTypeNumber = this.answerTypeNumber;
    this.question.multipleLinesText = this.multipleLinesText;

    this.question.assessors = this.selectedAssessors;
    this.question.valueStreams = this.selectedValueStreams;
    this.question.tags = this.selectedTags;

    if (this.isAdd) {
      this.question.createdBy_NTID = this.sharedService.ntid;
      this.question.modifiedBy_NTID = this.sharedService.ntid;
      this.question.isLocked = false;
      this.question.createdAt = new Date();
      this.question.assigned_ValueStreamCategoryID=undefined;

    }
    if (this.isEdit) {
      this.question.modifiedBy_NTID = this.sharedService.ntid;
    }


    //to validate mandatory assessor and valuestream selections
    if (!this.question.assessors || this.question.assessors.length < 1) {
      this.alertText = this.labels.default.fillMandatoryAssessors;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      this.isDisabled = true;

      return;

    }

    if (!this.question.valueStreams || this.question.valueStreams.length < 1) {
      this.alertText = this.labels.default.selectValueStream;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      this.isDisabled = true;
      return;
    }
if(isvalid){
    this.sharedService.show();

    this.questionService.insertQuestion(this.question).subscribe(res => {

      if (res.resultCode === 0) {

        //this.sharedService.hide();
        this.alertText = this.labels.default.saveSuccessfully;
        this.tag.searchText=''
        this.modalService.show(this.successModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.questionList = [];
        this.getQuestionDetail(); //for Question Details
        this.isAdd = false;
        this.isEdit = false;
        this.selectedAssessors = [];
        this.selectedValueStreams = [];
        this.selectedTags = [];
        this.isDisabled = true;
      }
      else if (res.resultCode === 9) {
        this.sharedService.hide();
        this.alertText = this.labels.default.insertOpertionFailed;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;
        return;
      }

    }, err => {
      console.error(err);
      this.isDisabled = true;

    });
  }
  else
  return;
  }

  editQuestion(question: Question) {
    console.log(this.valueStreamTemplates)
    //this.getQuestionDetailByID(question.questionID);
    this.sharedService.show();
    this.selectedItemValueStreamTemplate = [];
    //this.selectedItemValueStreamCategories = [];
    this.selectedItemAssessorTemplate = [];
    this.isDisabled = true;
    //question.isLocked=false
    if (question.isLocked) {
      console.log("1836")
      this.questionService.questionProxiesByQuestionID(question.questionID).subscribe(res => {

        this.proxies1 = res;

        let ProxyCreatedBy = new QuestionProxy();
        ProxyCreatedBy.userName = question.createdBy;
        ProxyCreatedBy.ntid = question.createdBy_NTID;
        ProxyCreatedBy.createdBy_NTID = question.createdBy_NTID;
        ProxyCreatedBy.modifiedBy_NTID = question.modifiedBy_NTID;
        if (!this.proxies1.some(e => question.createdBy_NTID != null && e.ntid.toLowerCase() === question.createdBy_NTID.toLowerCase())) {
          this.proxies1.push(ProxyCreatedBy);
        }

        let ProxyModified = new QuestionProxy();
        ProxyModified.userName = question.modifiedBy;
        ProxyModified.ntid = question.modifiedBy_NTID;
        ProxyModified.createdBy_NTID = question.createdBy_NTID;
        ProxyModified.modifiedBy_NTID = question.modifiedBy_NTID;
        if (!this.proxies1.some(e => question.modifiedBy_NTID != null && e.ntid.toLowerCase() === question.modifiedBy_NTID.toLowerCase())) {
          this.proxies1.push(ProxyModified);
        }

        if (this.sharedService.ntid && this.proxies1 && this.proxies1.length > 0) {
          this.proxy = this.proxies1.filter(x => x.ntid == this.sharedService.ntid
            || (x.createdBy_NTID != null && x.createdBy_NTID.toLowerCase() == this.sharedService.ntid.toLowerCase())
            || (x.modifiedBy_NTID != null && x.modifiedBy_NTID.toLowerCase() == this.sharedService.ntid.toLowerCase()));
        }

        if (this.proxy && this.proxy.length > 0) {
          this.isEdit = true;
          this.updateQuestion(question); //only edit is allowed if it is not blocked
        }
        else {
          this.alertText = this.labels.default.notAuthorizedEditQuestion;
          this.modalService.show(this.lockModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          this.isDisabled = true;
          return false;
        }
      }, err => console.error(err));
    }
    else {
      console.log("1906")
      this.updateQuestion(question);
    }
  }
  // ***************************redirecting to the valuestreamTemplate***************
  public valueStreamTemplateDetailsByTemplateID:ValueStreamTemplate=new ValueStreamTemplate();
  updtVS(valueStreamTemplateID: any) {

    this.valueStreamService.fetchValueStreamsByTemplateID(valueStreamTemplateID).subscribe(res => {
      this.valueStreamTemplateDetailsByTemplateID = res[0];

      this.updateTemplate(this.valueStreamTemplateDetailsByTemplateID);
    }, err => console.log(err));
  }

  updateTemplate(valueStreamTemplate: any) {
        this.valueStreamService.valueStreamTemplate = valueStreamTemplate;
        if(valueStreamTemplate.isLocked){
          this.valueStreamService.valueStreamProxiesByTemplateID(valueStreamTemplate.valueStreamTemplateID).subscribe(res => {
            this.proxies1 = res;
            if (this.sharedService.ntid && this.proxies1 && this.proxies1.length > 0) {
              this.proxy = this.proxies1.filter(x => x.proxy == this.sharedService.ntid
                || x.createdBy_NTID == this.sharedService.ntid
                     || x.modifiedBy_NTID == this.sharedService.ntid); //checking for the proxy, designer, who locked the record

            }
            if ((this.proxy && this.proxy.length > 0) || this.sharedService.ntid == valueStreamTemplate.createdBy_NTID) {
              this.router.navigate([environment.home +'/valuestreams/valuestreams-edit']);
            }

              else {
                this.alertText = this.labels.default.notAuthorizedToEdit;
                this.modalService.show(this.lockModal);
                $("modal-container").removeClass("fade");
                $(".modal-dialog").addClass("modalSize");
                this.router.navigate([environment.home +'/valuestreams']);
              }
            }, err => console.error(err));
        }
       else{
        this.router.navigate([environment.home +'/valuestreams/valuestreams-edit']);
       }

      }
  // ********************************************************************************
  // **********************redirecting to the AssessorTemplate******************
  public assessorTemplateDetailsByTemplateID:AssessorTemplate=new AssessorTemplate();
  updtAS(assessorTemplateID:any){
  this.assessorTemplateService.fetchAssessorTemplateByTemplateID(assessorTemplateID).subscribe(res=>{
    this.assessorTemplateDetailsByTemplateID=res[0];
    this.editAsessor(this.assessorTemplateDetailsByTemplateID);
       },err=>console.log(err));
 }
  editAsessor(assessorTemplate: any) {
        this.assessorTemplateService.assessorTemplate = assessorTemplate;
        if(assessorTemplate.isLocked){
          this.assessorTemplateService.assessorProxiesByAssessorTemplateID(assessorTemplate.assessorTemplateID).subscribe(res => {
            this.proxies1 = res;
            if (this.sharedService.ntid && this.proxies1 && this.proxies1.length > 0) {
              this.proxy = this.proxies1.filter(x => x.proxy == this.sharedService.ntid
                    || x.createdBy_NTID == this.sharedService.ntid
                     || x.modifiedBy_NTID == this.sharedService.ntid);

            }
            if ((this.proxy && this.proxy.length > 0) || this.sharedService.ntid == assessorTemplate.createdBy_NTID) {
              this.router.navigate([environment.home +'/assessors/assessor-edit']);

            }

              else {
                this.alertText = this.labels.default.notAuthorizedToEdit;
                this.modalService.show(this.lockModal);
                $("modal-container").removeClass("fade");
                $(".modal-dialog").addClass("modalSize");
                this.router.navigate([environment.home +'/assessors']);
              }
            }, err => console.error(err));
        }
        else
        {
          this.router.navigate([environment.home +'/assessors/assessor-edit']);
         }

      }
  // ********************************************************************************
  // **************************************redirecting to the tag edit page*********************
  public tagDetailsByTagID:Tag=new Tag();
  updtTag(tagID:any){

    this.tagService.fetchTagDetailsByTagID(tagID).subscribe(res=>{
      
      this.tagDetailsByTagID=res[0];
      console.log("quescomp,2000",this.tagDetailsByTagID)
      this.editTag(this.tagDetailsByTagID);
         },err=>console.log(err));
  }

  public editTag(tag: Tag) {

    this.tagService.tag = tag;

    if(tag.isLocked){
      this.tagService.tagProxiesByTagID(tag.tagID).subscribe(res => {

        this.proxies1 = res;
        if (this.sharedService.ntid && this.proxies1 && this.proxies1.length > 0) {
          this.proxy = this.proxies1.filter(x => x.proxy == this.sharedService.ntid
            || (x.createdBy_NTID != null && x.createdBy_NTID.toLowerCase() == this.sharedService.ntid.toLowerCase())
            || (x.modifiedBy_NTID != null && x.modifiedBy_NTID.toLowerCase() == this.sharedService.ntid.toLowerCase())); //checking for the proxy, designer, who locked the record
        }
        if ((this.proxy && this.proxy.length > 0) || this.sharedService.ntid == tag.createdBy_NTID) {
          this.router.navigate([environment.home +'/taglist/tag-edit']);
        }

          else {
            this.alertText = this.labels.default.notAuthorizeEditTag;
            this.modalService.show(this.lockModal);
            $("modal-container").removeClass("fade");
            $(".modal-dialog").addClass("modalSize");
            this.router.navigate([environment.home +'/taglist']);

          }
        }, err => console.error(err));
    }
   else{
    this.router.navigate([environment.home +'/taglist/tag-edit']);
   }
  }
  // **********************************end tag edit***************************************

  proxies1: any;
  proxy: any;
  //Edit Question
  updateQuestion(question: Question) {
    //debugger; 
    this.isAdd = false;
    this.isEdit = true;
    this.questionList = [];
    this.urls = [];
    this.question = Object.assign(new Question(), question);

    this.question.activeDateRangeFrom = new Date(this.question.activeDateRangeFrom);
    this.question.activeDateRangeTo = new Date(this.question.activeDateRangeTo);

    this.valueStreamService.getValueStream().subscribe(res2 => {
      this.valueStreams = res2;
       //Get all Value Stream cATEGORIES
      this.valueStreamService.getValueStreamCategory().subscribe(res4 => {
     
        this.valueStreamCategories = res4;
       //Get all Assesssors 
      this.assessorTemplateService.getAssessors().subscribe(res3 => {
        this.assessors = res3;
      
  //Call API for VSID list

  this.questionService.fetchVSASListByID("Question","ValueStream",this.question.questionID,0).subscribe(res5 => {
    
     var vsIDList = res5[0].idList.toString();   
     this.valuestreamTemplateList=this.getVSTemplate(vsIDList,res2);
     this.question.valueStreamTemplateNameArL = this.valuestreamTemplateList;
     this.getValueStreamList();
     //this.valueStreams=this.valueStreams.filter(r=>this.selectedItemValueStreamTemplate.find(x=>x.valueStreamTemplateID== r.valueStreamTemplateID));
     this.valuestreamcategoryTemplateList=this.getVSCategoryTemplate(vsIDList,res4);
     //this.questionDetail.valueStreamCategoryNameArL=this.valuestreamcategoryTemplateList;
      });
      //Call API for AssessorIDlist
      
      this.questionService.fetchVSASListByID("Question","Assessor",this.question.questionID,0).subscribe(res6 => {
       var asIDList = res6[0].idList.toString();
     
        //this.question.assessorTemplateNameArL = asList;
        this.assesorTemplateList=this.getASTemplate(asIDList,res3);
        this.question.assessorTemplateNameArL=this.assesorTemplateList;
        this.getAssessorTemplateList();
         });         
     });
    });
   });

    this.getChoiceDisplayTypes();
    this.getAnswerTypes();   
   

    

  //this.valuestreamTemplateList=this.getVSTemplate(this.questionDetail[k].valueStreamIDList,res2);
  //   //Assessor Stream Template List - assesorTemplateList
  //   this.assesorTemplateList=this.getASTemplate(this.questionDetail[k].assessorIDList,res3);
  //   //Value Stream Category Template List - valuestreamcategoryTemplateList
  //   this.valuestreamcategoryTemplateList=this.getVSCategoryTemplate(this.questionDetail[k].valueStreamIDList,res4);
 


    if (this.question.answerType_AnswerTypeID == 1) {
      this.questionService.singleLineTextByQuestionID(this.question.questionID).subscribe(
        res => {
          this.singleLineText = res[0];
          this.getHintImages(this.question.questionID);

        },
        err => {
          console.log(err);
          this.isDisabled=true;

        });
    }
    if (this.question.answerType_AnswerTypeID == 2) {
      this.questionService.multipleLinesTextByQuestionID(this.question.questionID).subscribe(
        res => {
          this.multipleLinesText = res[0];
          this.getHintImages(this.question.questionID);

        },
        err => {
          console.log(err);
         this.isDisabled=true;

        });
    }
    if (this.question.answerType_AnswerTypeID == 3) {
      var QuestionID=this.question.questionID
      this.questionService.getChoicesByQuestionID(QuestionID).subscribe(
        res => {
          this.choices = res;
          for (var i = 0; i < this.choices.length; i++) {
            this.choices[i].choiceScore = Number(this.choices[i].choiceScore.toString().replace(/,/g, '.') );
          }
          this.addChoiceRow(this.choices.length -1);
          this.getHintImages(this.question.questionID);

        },
        err => {
          console.log(err);
          this.isDisabled=true;

        });
    }

    if (this.question.answerType_AnswerTypeID == 4) {
      this.questionService.ratingScaleByQuestionID(this.question.questionID).subscribe(
        res => {
          this.ratingScale = res[0];
          this.getHintImages(this.question.questionID);
        },
        err => {
          console.log(err);
          this.isDisabled=true;

        });
    }

    if (this.question.answerType_AnswerTypeID == 5) {
      this.questionService.numberSettingsByQuestionID(this.question.questionID).subscribe(
        res => {
          this.answerTypeNumber = res[0];
          this.getHintImages(this.question.questionID);

        },
        err => {
          console.log(err);
           this.isDisabled=true;

        });
    }
    if (this.question.answerType_AnswerTypeID == 6) {
      this.questionService.currencySettingsByQuestionID(this.question.questionID).subscribe(
        res => {
          this.answerTypeCurrency = res[0];
          this.getHintImages(this.question.questionID);

        },
        err => {
          console.log(err);
         this.isDisabled=true;

        });
    }
    if (this.question.answerType_AnswerTypeID == 7) {

      this.questionService.dateTimeSettingsByQuestionID(this.question.questionID).subscribe(
        res => {
          this.answerTypeDateTime = res[0];
          this.getHintImages(this.question.questionID);

        },
        err => {
          console.log(err);
         this.isDisabled=true;

        });
    }
    else {
      this.getHintImages(this.question.questionID);
    }
  }

   // *********************download files**********************
   DownloadQuestionAttachment(url){

    this.droppedImageName = url.imageTitle;

    let fileName = this.droppedImageName;
    //file type extension
    let checkFileType =  "."+fileName.split('.').pop();
    var fileType = this.sharedService.GetMIMETypeByExtenstion(checkFileType);

    this.questionService.DownloadQuestionAttachment(fileName, fileType)
    .subscribe(
              success => {
                saveAs(success, fileName);
              },
              err => {
                this.alertText = this.labels.default.serverErrorLoadingFile;
                this.modalService.show(this.warningModal);
                $("modal-container").removeClass("fade");
                $(".modal-dialog").addClass("modalSize");
                  console.log(err);
              }
          );
  }
  // *************************downlaods fields ends************

  delete(question: any) {

    if(this.sharedService.ntid){
      this.question.modifiedBy_NTID = this.sharedService.ntid;
      var d = new Date();
      this.question.modifiedAt = new Date(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate(),d.getHours(),d.getMinutes(),d.getSeconds()));
    }
    this.questionService.deleteQuestion(question).subscribe(
      res => {
        if (res.resultCode == 0) {
          this.getQuestionDetail(); //for Question Details
          this.alertText = this.labels.default.deleteSuccessfully;
          this.modalService.show(this.successModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          this.assessors = [];
          this.isAdd = false;
          this.isEdit = false;
        }
        else if(res.resultCode == 1){
          this.alertText = this.labels.default.questionLinked;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
        }
        else {
          this.alertText = this.labels.default.failedDeleteQuestion;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
        }

      },
      err => {
        console.log(err);
      });
  }


  public openAlertModal(popUp: any) {
    this.filterPopUp = popUp;
  }

  public closeModal() {
    this.filterPopUp.hide();
    if (this.questionDetail.length == this.totalList.length) {
      //document.getElementsByTagName("popover-container")[0].parentNode.removeChild(document.getElementsByTagName("popover-container")[0]);
      this.filtertext = '';
      this.filterId = false;
      this.filterName = false;
      this.filterLock = false;
      this.filterModified = false;
      this.filterModifiedBy = false;
      this.filterCreated = false;
      this.filterCreatedBy = false;

      this.filterValueStreams = false;
      this.filterAssessors = false;
      this.filterPriority = false;
      this.filterTags = false;
      this.filterActive = false;
      this.filterFrequency = false;
      //document.querySelector('body').classList.remove('-is-modal');
    }
  }

  //for tag selection


  public getTagList() {
    this.tagService.getTags().subscribe(res => {
      this.tagList = res;
      //this.sharedService.hide();
    },
      err => {
        console.log(err);
      }
    );
  }


  public tagSelected(tag: Tag) {

    if (this.selectedTags == undefined) {
      this.selectedTags = [];
    }
    this.selectedTags.push(tag);
    this.availableTags = this.availableTags.filter(x => x.tagID !== tag.tagID);

  }

  searchTag() {

    var text = this.tag.searchText.toLowerCase();
  if(text){ //if the value is there in the search tag field
    if (this.availableTags.length > 0) {
      let filteredTags = this.availableTags.filter(x => x.tagName.toLowerCase().indexOf(text) > -1);
      this.availableTags = []; //claers the tags to update the taglist based on filter
      for (let tg of filteredTags) {
        let x = this.selectedTags.filter(x => x.tagID == tg.tagID);
        if (x.length < 1) {
          this.availableTags.push(tg);
        }
      }
    }
    if(!text){
    if(!this.availableTags || this.availableTags.length <1){
      this.onAssessorSelect(null);
    }}
  }
  else{ //to load all the tags
    this.onAssessorSelect(null);
  }
  }

  filterTagOrQuestion() {

    let text = this.tag.filterText;
  }

  removeTag(tag: Tag) {

    if (tag !== undefined && Object.keys(tag).length !== 0) {
      let id = tag.tagID;
      this.selectedTags = this.selectedTags.filter(x => x.tagID !== id);
      if( this.availableTags && (this.availableTags.filter(x =>x.tagID == id).length <1))
      {
      this.availableTags.push(tag);
      }

    };

  }

  openQuestionHistory(questionHistory: TemplateRef<any>)
  {
    this.questionService.getQuestionTemplateHistory(this.question.questionID).subscribe(res => {
      this.questionHistoryDetails = res;
    });

    this.modalRef = this.modalService.show(questionHistory, this.config);
    this.modalRef.setClass('modal-lg');
    $('.isRestoreDisabled').prop('disabled', true);

    setTimeout(function(){
      $("#quesHisTab tbody tr").click(function(){
        $(".selected").removeClass('selected');
        $(this).addClass('selected');
        $('.isRestoreDisabled').prop('disabled', false);
     });
    },500);

  }

  questionID: number;

  restoreVersion()
  {
    this.questionID = $("#quesHisTab tbody tr.selected td:first").html();
    this.questionService.questionRestoreByTemplateHistoryID(this.questionID).subscribe(res => {
    this.sharedService.show();
    this.isEdit = false;
    this.isAdd = false;
    this.question = new Question();
    this.selectedAssessors = [];
    this.selectedValueStreams = [];
    this.selectedTags = [];
    this.getQuestionDetail(); //for Question Details
    setTimeout(() => {
      //this.sharedService.hide();
    }, 100);

    this.closeAlertModal();
    this.alertText = this.labels.default.restoreSuccessfully;
    this.modalService.show(this.successModal);
    $("modal-container").removeClass("fade");
    $(".modal-dialog").addClass("modalSize");

    },
    (err) => {
      console.log(err.message);
      this.closeAlertModal();
    });
  }




  //clearing the max char values in radio button selection of question type
  setAnswerTypeSelection(value:any){
    this.multipleLinesText=new MultipleLinesText();
    this.singleLineText = new SingleLineText();
    this.choice = new Choice();
    this.choices = [];
    this.choices = [{ choiceName: "", choiceScore: undefined, answerCategory:"", isDeviationEntryRequired: false }];
    this.question.choiceDisplayTypeID = 1;

    this.question.isAnswerRequired = false; //irrespective of answer type, defalut value is true

    if(value.answerTypeID==1)
    {
        this.singleLineText.isCalculated = false;
     }
     if(value.answerTypeID==2)
     {
         this.multipleLinesText.isPlainText = true;
      }

   }

  setTargetFrequency(value:any){
    if(value)
    {
      this.question.isTargetFrequencyDefined = true;
    }
    else{
     this.question.isTargetFrequencyDefined = false;
     this.question.targetFrequencyValue=undefined;
     this.question.targetFrequencyTypeID=undefined;
    }
   }

   setAnswerRequired(value:any){
    if(value)
    {
      this.question.isAnswerRequired = true;
    }
    else{
     this.question.isAnswerRequired = false;
    }
  }

    setUniqueAnswerRequired(value:any){
      if(value)
      {
        this.question.isUniqueAnswerRequired = true;
      }
      else{
       this.question.isUniqueAnswerRequired = false;
      }
   }
// ***********************************filtering************************************************************
 //resetting all the filtering and sorting
 resetAll(){
  this.reverse1=false;
  this.filtertext="";
}

showModal()
  {
    document.getElementById('deleteModal').style.display = "block";
  }

  closeDeleteModal()
  {
    document.getElementById('deleteModal').style.display = "none";
    document.querySelector('body').classList.remove('-is-modal');
  }

  deleteTemplate()
  {
    this.closeDeleteModal();
    this.delete(this.question);
  }


 //*********************sorting*********
 sort(key){

    this.key =  this.headerFilterName;;
   this.reverse1 = !this.reverse1;
 }
  getButtonType(buttonname:any):any{

   this.filterType=buttonname;
  }
  // *********************************

  getColumnName(headername:any){


if(this.filteredItems==undefined){
  this.filteredItems=[]
}

    this.questionDetail = this.totalList;//newly added

    this.filtertext = '';
    this.filterId = false;
    this.filterName = false;
    this.filterLock = false;
    this.filterModified = false;
    this.filterModifiedBy = false;
    this.filterCreated = false;
    this.filterCreatedBy = false;

    this.filterValueStreams = false;
    this.filterAssessors = false;
    this.filterPriority = false;
    this.filterTags = false;
    this.filterActive = false;
    this.filterFrequency = false;

    if (headername == 'questionDisplayID') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].questionDisplayID);
      }
      this.filterId = !this.filterId;
    }

    else if (headername == 'questionText') {
      for(var i=0;i<this.totalList.length;i++){
        this.filteredItems.push(this.totalList[i].questionText);
      }
      this.filterName = !this.filterName;
    }
    else if (headername == 'valueStreamTemplateName') {
      for(var i=0;i<this.totalList.length;i++){
        this.filteredItems.push(this.totalList[i].valueStreamTemplateName);
      }
      this.filterValueStreams=!this.filterValueStreams;
    }
    else if (headername == 'assessorTemplateName') {
      for(var i=0;i<this.totalList.length;i++){
        this.filteredItems.push(this.totalList[i].assessorTemplateName);
      }
      this.filterAssessors=!this.filterAssessors;
    }
    else if (headername == 'priorityName') {
      for(var i=0;i<this.totalList.length;i++){
        this.filteredItems.push(this.totalList[i].priorityName);
      }
      this.filterPriority=!this.filterPriority;
    }
    else if (headername == 'isLocked') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].isLocked);
      }
      this.filterLock = !this.filterLock;
    }
    else if (headername == 'modifiedAt') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.datePipe.transform(this.totalList[i].modifiedAt,this.filterdateFormat));
      }
      this.filterModified = !this.filterModified;
    }
    else if (headername == 'modifiedBy') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].modifiedBy);
      }
      this.filterModifiedBy = !this.filterModifiedBy;
    }
    else if (headername == 'createdAt') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.datePipe.transform(this.totalList[i].createdAt,this.filterdateFormat));
      }
      this.filterCreated = !this.filterCreated;
    }
    else if (headername == 'createdBy') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].createdBy);
      }
      this.filterCreatedBy = !this.filterCreatedBy;
    }
    this.headerFilterName = headername;
    this.searchFilter();
  }
  setForm() {
    this.form = new FormGroup({
      name: new FormControl(
        this.data
      )
    });
    this.loadContent = true;
  }
  searchFilter(){

    this.data=[];
     // ********************************searching
  if(this.headerFilterName=="questionText"){
    for(var questionDet of this.questionDetail){
      let newItem={
        questionID:questionDet.questionID,
        questionText:(questionDet.questionText.length>50) ? (questionDet.questionText.slice(0,49))+'...':(questionDet.questionText) //if text is bigge rthan 50 chars then put ... after that
      };
      if(!this.data.includes(newItem)){
        if (!this.data.some(e => e.questionText === questionDet.questionText)) {//newly added
          this.data.push(newItem);
        }
      }
    }
  }
  else if(this.headerFilterName=="valueStreamTemplateName"){
    for(var questionDet of this.questionDetail){
      let newItem={
        questionID:questionDet.questionID,
        valueStreamTemplateName:questionDet.valueStreamTemplateName
      };
      if(!this.data.includes(newItem)){
        if (!this.data.some(e => e.valueStreamTemplateName === questionDet.valueStreamTemplateName)) {//newly added
          this.data.push(newItem);
        }
      }
    }
  }
  else if(this.headerFilterName=="assessorTemplateName"){
    for(var questionDet of this.questionDetail){
      let newItem={
        questionID:questionDet.questionID,
        assessorTemplateName:questionDet.assessorTemplateName
      };
      if(!this.data.includes(newItem)){
        if (!this.data.some(e => e.assessorTemplateName === questionDet.assessorTemplateName)) {//newly added
          this.data.push(newItem);
        }
      }
    }
  }
  else if(this.headerFilterName=="priorityName"){
    for(var questionDet of this.questionDetail){
      let newItem={
        questionID:questionDet.questionID,
        priorityName:questionDet.priorityName
      };
      if(!this.data.includes(newItem)){
        if (!this.data.some(e => e.priorityName === questionDet.priorityName)) {//newly added
          this.data.push(newItem);
        }
      }
    }
  }
  else if(this.headerFilterName=="isLocked"){
    for(var questionDet of this.questionDetail){
    let newItem={
      questionID:questionDet.questionID,
      isLocked:questionDet.isLocked
    };
    if (!this.data.includes(newItem)) {
      if (!this.data.some(e => e.isLocked === questionDet.isLocked)) {
        this.data.push(newItem);
      }
    }
  }
}
  else if (this.headerFilterName == "modifiedAt") {
      for (var questionDet of this.questionDetail) {
        this.str1= this.datePipe.transform(questionDet.modifiedAt,this.filterdateFormat);//converting the date format
        let newItem = {
          questionID: questionDet.questionID,
          modifiedAt: this.str1
        };
        if (!this.data.includes(newItem)) {
            if (!this.data.some(e => e.modifiedAt === this.str1)) {
              this.data.push(newItem);
            }
        }
      }
    }
  else if (this.headerFilterName == "modifiedBy") {


      for (var questionDet of this.questionDetail) {
        let newItem = {
          questionID: questionDet.questionID,
          modifiedBy: questionDet.modifiedBy
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.modifiedBy === questionDet.modifiedBy)) {
            this.data.push(newItem);
          }
        }
      }
    }
  else if(this.headerFilterName=="createdAt"){
    for(var questionDet of this.questionDetail){
      this.str1= this.datePipe.transform(questionDet.createdAt,this.filterdateFormat);//converting the date format
      let newItem={
        questionID:questionDet.questionID,
        createdAt:this.str1
      };
      if(!this.data.includes(newItem)){
        if (!this.data.some(e => e.createdAt === this.str1)) {
          this.data.push(newItem);
        }
      }
    }
  }
  else if(this.headerFilterName=="createdBy"){
    for(var questionDet of this.questionDetail){
      let newItem={
        questionID:questionDet.questionID,
        createdBy:questionDet.createdBy
      };
      if(!this.data.includes(newItem)){
        if (!this.data.some(e => e.createdBy === questionDet.createdBy)) {
          this.data.push(newItem);
        }
      }
    }
  }
  else if (this.headerFilterName == "questionDisplayID") {
      for (var questionDet of this.questionDetail) {
        let newItem = {
          questionID: questionDet.questionID,
          questionDisplayID:questionDet.questionDisplayID

        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.questionDisplayID === questionDet.questionDisplayID)) {
            this.data.push(newItem);
          }
        }
      }
    }

     this.settings = {//setting for multiselect dropdown
       singleSelection: false,
       idField: 'questionID',
       textField: this.headerFilterName,


       enableCheckAll: true,
       selectAllText: 'Select All',
       unSelectAllText: 'Unselect All',
       allowSearchFilter: true,
       limitSelection: -1,
       clearSearchFilter: true,
       maxHeight: 197,
       itemsShowLimit: 0,
       searchPlaceholderText: 'Search',
       noDataAvailablePlaceholderText: 'No Data Available',
       closeDropDownOnSelection: false,
       showSelectedItemsAtTop: false,
       defaultOpen: false
     };
     this.setForm();
     // ************************************************
  }
// ************************************filtering ends******************************************************

/* for lock */
lockQuestion(){

  this.questionService.question = this.question;
  this.questionService.question.assessors = this.selectedAssessors;
  this.questionService.question.valueStreams = this.selectedValueStreams;
  this.questionService.question.singleLineText = this.singleLineText;
  this.questionService.question.multipleLinesText = this.multipleLinesText;
  this.questionService.question.tags = this.selectedTags;
  this.questionService.question.hintImages = this.urls;
  this.questionService.question.hintHyperLinks = this.hyperLinkUrls;
  this.questionService.question.choices = this.choices.filter(x => x.choiceName !== undefined && x.choiceName !== null && x.choiceName !== "");

  //this.router.navigate([environment.home +'/question-lock']);
  this.router.navigate([environment.home +'/datapool/question-lock']);
}


/** for Proxy */

  removeProxy(event: any) {
    let ntid = event.target.id;
    this.proxies = this.proxies.filter(x => x.ntid !== ntid);
  }

  //for new Active Directory Search
user: any;
proxies: any = [];
activeDirectoryData: any[];

onChangeSearch() {

  let user = new User();
  user.firstName = this.user;
  this.commonService.activeDirectoryByName(user).subscribe(res => {
    this.activeDirectoryData = [];
    this.activeDirectoryData = res;
  },
    err => console.error(err));
}

selectUser(user:any){

  if (user !== null) {
    let x = this.proxies.filter(x => x.ntid == user.ntid);
    if (x.length == 0)
    this.proxies.push(user);
  }


  this.activeDirectoryData = [];
  this.user = undefined;
}

saveLockSettings() {
  this.questionProxy = new QuestionProxy();
  this.questionProxy.questionID = this.question.questionID;
  this.questionProxy.proxies = this.proxies;
  this.questionService.insertQuestionProxy(this.questionProxy).subscribe(res => {
    if (res.resultCode == 0) {
      this.alertText = this.labels.default.saveSuccessfully;
      this.modalService.show(this.successModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      this.isLock = false;
      this.isEdit = true;
      return;
    }
  }, err => {
      this.alertText = this.labels.default.insertOpertionFailed;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      return;
}
  );
}

//-===============

//to set default value for choice type

setDefaultChoice(args) {
  var id = args.target.selectedOptions[0].id;
  this.question.defaultChoiceID = id;
}

copyToClipBoard(text){
  var plainText = {"plant": this.sharedService.plantID, "id":text};
  var encString = this.sharedService.encrypt(JSON.stringify(plainText));
  var url = environment.uiUrl + environment.home +'/processConfirmation;qid=' + encString ;
  var input = document.createElement('textarea');
  input.innerHTML = url;
  document.body.appendChild(input);
  input.select();
  input.setSelectionRange(0, 99999);
  document.execCommand('copy');
  document.body.removeChild(input);
  }

  removeChoice(index: number) {
    if (!this.choices || this.choices.length <= 1)
      return;
    this.choices.splice(index, 1);
  }

ExportExcelQuestions(){
  this.dataPoolService.GetExcelFile("Question");
}

//Function to get the Updated Values Streams Question List 
getVSTemplate(valueStreamIDList: string, valueStreams: ValueStream[]) {

  let result: valueStreamTemplateData[] = [];;
  let vsIDArr = valueStreamIDList.split(",").map(function (vsID) {
    return parseInt(vsID);
  });

  valueStreams.filter(r => vsIDArr.includes(r.valueStreamID))
    .map(item => item.valueStreamTemplateID)
    .filter((value, index, self) => self.indexOf(value) === index).forEach(element => {
      let vsData = new valueStreamTemplateData();
      let vsByTemplate = valueStreams.filter(x => x.valueStreamTemplateID == element);

      let vsBySelectedTemplate = vsByTemplate.filter(r => vsIDArr.includes(r.valueStreamID));
      //vsData.vsTemplate.push(vsByTemplate[0]);
      vsData.vsName = vsBySelectedTemplate.map(r => r.valueStreamName).join(",");
      vsData.vsTemplateID=vsByTemplate[0].valueStreamTemplateID;
      vsData.vsTemplateName=vsByTemplate[0].valueStreamTemplateName;
      
      result.push(vsData);
 
    });

  return result;
}

//Function to get the Updated Assessors  Question List 
getASTemplate(AssessorIDList: string, assessors: Assessor[]) {

  let result: assessorTemplateData[] = [];;
  let vsIDArr = AssessorIDList.split(",").map(function (vsID) {
    return parseInt(vsID);
  });

  assessors.filter(r => vsIDArr.includes(r.assessorID))
    .map(item => item.assessorTemplateID)
    .filter((value, index, self) => self.indexOf(value) === index).forEach(element => {
      let vsData = new assessorTemplateData();
      let vsByTemplate = assessors.filter(x => x.assessorTemplateID == element);

      let vsBySelectedTemplate = vsByTemplate.filter(r => vsIDArr.includes(r.assessorID));

      //vsData.vsTemplate.push(vsByTemplate[0]);
      vsData.vsName = vsBySelectedTemplate.map(r => r.assessorName).join(",");
      vsData.vsTemplateID=vsByTemplate[0].assessorTemplateID;
      vsData.vsTemplateName=vsByTemplate[0].assessorTemplateName;
      
      result.push(vsData);
 
    });

  return result;
}



//Function to get the Updated Values Streams Categories Question List 
getVSCategoryTemplate(valueStreamIDList: string, valueStreams: ValueStreamCategory[]) {

  let result: valueStreamCategoryData[] = [];;
  let vsIDArr = valueStreamIDList.split(",").map(function (vsID) {
    return parseInt(vsID);
  });

  valueStreams.filter(r => vsIDArr.includes(r.valueStreamCategoryID))
    .map(item => item.valueStreamCategoryID)
    .filter((value, index, self) => self.indexOf(value) === index).forEach(element => {
     
      let vsData = new valueStreamCategoryData();
      let vsByTemplate = valueStreams.filter(x => x.valueStreamCategoryID == element);
      //vsData.vsTemplate.push(vsByTemplate[0]);
      vsData.vsName = vsByTemplate.map(r => r.valueStreamCategoryName).join(",");
      vsData.vsTemplateID=vsByTemplate[0].valueStreamCategoryID;
      vsData.vsTemplateName=vsByTemplate[0].valueStreamCategoryName;
      
      result.push(vsData);
 
    });

  return result;
}

exportAsXLSX() {
  var IDs = this.questionDetail.map(r => {
    return r.questionID
  });
  this.dataPoolService.GetExcelFileByIDs("Question", IDs);
}

searchGrid(value: string) {
  if (value.length > 0) {
    var searchText = value.trim().toLowerCase();
    this.questionDetail = this.totalList;
    this.sharedService.activeDateRange.questionSearchText = value;

    this.questionDetail = this.questionDetail.filter(x =>
      (x.questionText != null && x.questionText.trim().toLowerCase().includes(searchText))
      || (x.isLocked != null && x.isLocked.toString().trim().toLowerCase().includes(searchText))
      || (x.questionDisplayID != null && x.questionDisplayID.toString().trim().toLowerCase().includes(searchText))
      || (x.valueStreamNameList != null && x.valueStreamNameList.toString().trim().toLowerCase().includes(searchText))
      || (x.valueStreamTemplateName != null && x.valueStreamTemplateName.toString().trim().toLowerCase().includes(searchText))
      || (x.assessorNameList != null && x.assessorNameList.toString().trim().toLowerCase().includes(searchText))
      || (x.assessorTemplateName != null && x.assessorTemplateName.toString().trim().toLowerCase().includes(searchText))
      || (x.tagNameList != null && x.tagNameList.toString().trim().toLowerCase().includes(searchText))
      || (x.activeDateRangeFrom != null && x.activeDateRangeFrom.toString().trim().toLowerCase().includes(searchText))
      || (x.activeDateRangeTo != null && x.activeDateRangeTo.toString().trim().toLowerCase().includes(searchText))
      || (x.questionDisplayID != null && x.questionDisplayID.toString().trim().toLowerCase().includes(searchText))
      || (x.priorityName != null && x.priorityName.toString().trim().toLowerCase().includes(searchText))
      || (x.targetFrequencyTypeName != null && x.targetFrequencyTypeName.toString().trim().toLowerCase().includes(searchText))
      || (x.modifiedAt != null && this.datePipe.transform(x.modifiedAt, this.filterdateFormat).trim().toLowerCase().includes(searchText))
      || (x.modifiedBy != null && x.modifiedBy.trim().toLowerCase().includes(searchText))
      || (x.createdAt != null && this.datePipe.transform(x.createdAt, this.filterdateFormat).trim().toLowerCase().includes(searchText))
      || (x.createdBy != null && x.createdBy.trim().toLowerCase().includes(searchText))
    );
    this.page = 1;
  }
  else {
    this.questionDetail = this.totalList;
    this.sharedService.activeDateRange.questionSearchText = "";
  }
  }
  clearMultiQuestion(value: any) {
    this.question.questionText = "";
    this.question.questionHintText = "";
    if (value) {
      this.selectedmultiquestion = value;
      if (value == 1) {
        this.questionChecked = true;
        this.questionUnChecked = false;
      } else {
        this.questionUnChecked = true;
        this.questionChecked = false;
      }
    }
  } 
}
