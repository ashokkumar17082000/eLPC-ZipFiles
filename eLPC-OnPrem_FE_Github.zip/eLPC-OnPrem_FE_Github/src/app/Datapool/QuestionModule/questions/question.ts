import { ValueStream, ValueStreamCategory, ValueStreamTemplate } from 'src/app/Valuestream/valuestreams/valuestreamtemplate';
import { Assessor,AssessorTemplate } from 'src/app/Assessor/assessor/assessortemplate';
//import { Assessor } from '../../../main/body/assessors/assessors.component';
import { Tag } from 'src/app/Tag/tag/tag';
import { User } from 'src/app/main/body/shared/common';
//import { AssessorLockComponent } from '../assessors/assessor.lock.component';

export class Question {
  questionID?: number;
  questionDisplayID?: number;
  questionText?: string;
  questionHintText: string;
  answerType_AnswerTypeID?: number;
  choiceDisplayTypeID?: number;
  isFilledInChoiceAllowed?: boolean;
  isUniqueAnswerRequired?: boolean;
  isAnswerRequired?: boolean;
  isDefaultAnswerRequired?: boolean;
  defaultChoiceID?: number;
  defaultChoice?: string; //since choice ID will be null before saving the choice
  isQuestionAlwaysActive?: boolean
  activeDateRangeFrom: Date;
  activeDateRangeTo: Date;
  isTargetFrequencyDefined?: boolean
  targetFrequencyTypeID?: number;
  targetFrequencyValue?: string;
  question_PriorityID?: number;
  isLocked?: boolean;
  createdBy?: string;
  modifiedBy?: string;
  assigned_ValueStreamTemplateID?: number[] = [];
  assigned_ValueStreamCategoryID?: number[] = [];
  assigned_AssessorTemplateID?: number[] = [];
  assigned_AssessorID?: number;
  isDeleted?: boolean;
  modifiedAt?: Date;
  createdAt?: Date;
  hintImage?: any;
  choices?: Choice[];
  hyperLinkUrl: any;
  hyperLinkTitle: any;
  hintHyperLinks?: HintHyperLink[];
  hintImages?: HintImage[];
  singleLineText?: SingleLineText;
  multipleLinesText?: MultipleLinesText;
  answerTypeNumber?: AnswerTypeNumber;
  answerTypeCurrency?: AnswerTypeCurrency;
  answerTypeDateTime?: AnswerTypeDateTime;
  ratingScale?: RatingScale;
  subQuestions?: SubQuestion[];
  valueStreams?: ValueStream[];
  assessors?: Assessor[];
  tags?: Tag[];
  assignedTargetFrequency: any;
 customQuestionTagsID: number;
  tagModeTagsID: number;
  createdBy_NTID?: string;
  modifiedBy_NTID?: string;
  resultCode: number;
  valueStreamNameList: string;

  valueStreamTemplateNameArL: valueStreamTemplateData[];
  responsibleEmployee?: string;
  assessorTemplateNameArL: assessorTemplateData[];
  searchText: any;
  isAccessible?: boolean;
  RandomQuestionOrder? : number;
  QuestionType:number;


}

export class QuestionHistory {
  QuestionHistoryID?: number;
  QuestionHistoryDisplayID?: number;
  QuestionID?: number;
  QuestionText?: string;
  ModifiedBy?: string;
  ModifiedBy_NTID: any;
  ModifiedAt: Date;
  CreatedAt: Date;
}

export class Choice {
  iD?: number;
  choiceID?: number;
  choiceName?: string;
  choiceScore?: number;
  isDeviationEntryRequired?: boolean = false;
  deviationTypeID?: number;
  answerCategory: string;
}



export class SubQuestion {
  iD?: number;
  name?: string;
}
export class RatingScale {
  iD?: number;
  name?: string;
  numberRange?: string;
  rangeText1?: string;
  rangeText2?: string;
  rangeText3?: string;
  showNA?: boolean;
  textNA?: string;

}

export class ChoiceDisplayType {
  choiceDisplayTypeID?: number;
  choiceDisplayTypeName?: string;
  isDeleted?: boolean;
}

export class HintImage {
  iD?: number;
  questionID?: number;
  imageTitle?: string;
  imagePath?: string;
  fileContent?: any;
  byteData?: any;
  size?: number;
  displayFileName?:string;
}

export class HintHyperLink {
  iD?: number;
  questionID?: number;
  hyperLinkTitle?: string;
  hyperLinkUrl?: string;
  hyperLinkURL?: string;
}

export class SingleLineText {
  iD?: number;
  maxCharacters?: number;
  isCalculated?: boolean;
  defaultValue?: string;
  questionID?: number;
}

export class MultipleLinesText {
  iD?: number;
  maxLines?: number;
  isPlainText?: boolean;
  questionID?: number;
}

export class AnswerTypeNumber {
  iD?: number;
  maxValue?: number;
  minValue?: number;
  numberOfDecimalPlaces?: string;
  isNumber?: boolean;
  defaultValue?: string;
  showPercentage?: boolean;
  questionID?: number;
}

export class AnswerTypeCurrency {
  iD?: number;
  maxValue?: number;
  minValue?: number;
  numberOfDecimalPlaces?: string;
  isCurrency?: boolean;
  defaultValue?: string;
  currencyFormat?: string;
  questionID?: number;
}

export class AnswerTypeDateTime {
  iD?: number;
  isDateOnly?: boolean;
  isStandard?: boolean;
  defaultDateType?: string;
  defaultValue?: string;
  questionID?: number;
}

export class QuestionProxy {
  id?: number;
  questionID?: number;
  proxies: User[];
  createdBy_NTID?: string;
  modifiedBy_NTID?: string;
  resultCode: number;
  ntid?: string;
  userName?: string;
}

export class QuestionDetail {
  questionID?: number;
  questionDisplayID?: number;
  questionText?: string;
  questionHintText: string;
  answerType_AnswerTypeID?: number;
  choiceDisplayTypeID?: number;
  isFilledInChoiceAllowed?: boolean;
  isUniqueAnswerRequired?: boolean;
  isAnswerRequired?: boolean;
  isDefaultAnswerRequired?: boolean;
  defaultChoiceID?: number;
  defaultChoice?: string; //since choice ID will be null before saving the choice
  isQuestionAlwaysActive?: boolean
  activeDateRangeFrom: Date;
  activeDateRangeTo: Date;
  isTargetFrequencyDefined?: boolean
  targetFrequencyTypeID?: number;
  targetFrequencyValue?: string;
  question_PriorityID?: number;
  isLocked?: boolean;
  createdBy?: string;
  modifiedBy?: string;
  assigned_ValueStreamTemplateID?: number[] = [];
  assigned_ValueStreamCategoryID?: number[] = [];
  assigned_AssessorTemplateID?: number[] = [];
  assigned_AssessorID?: number;
  isDeleted?: boolean;
  modifiedAt?: Date;
  createdAt?: Date;
  hintImage?: any;
  choices?: Choice[];
  hyperLinkUrl: any;
  hyperLinkTitle: any;
  hintHyperLinks?: HintHyperLink[];
  hintImages?: HintImage[];
  singleLineText?: SingleLineText;
  multipleLinesText?: MultipleLinesText;
  answerTypeNumber?: AnswerTypeNumber;
  answerTypeCurrency?: AnswerTypeCurrency;
  answerTypeDateTime?: AnswerTypeDateTime;
  ratingScale?: RatingScale;
  subQuestions?: SubQuestion[];
  valueStreams?: ValueStream[];
  assessors?: Assessor[];
  tags?: Tag[];
  assignedTargetFrequency: any;

  customQuestionTagsID: number;
  tagModeTagsID: number;
  createdBy_NTID?: string;
  modifiedBy_NTID?: string;
  resultCode: number;

  valueStreamNameList: string;
  priorityName: string;
  valueStreamTemplateName: string;


  assessorNameList: string
  assessorTemplateName: string;
  tagNameList: string;
  tagIDList: string

  targetFrequencyTypeName: string
  valueStreamIDList : string;
  assessorIDList : string;

  valueStreamTemplateNameArL: valueStreamTemplateData[];

  assessorTemplateNameArL: assessorTemplateData[];

  valueStreamCategoryNameArL :valueStreamCategoryData[];


}

export class valueStreamTemplateData
{

  vsName: string;
  vsTemplateName: string;
  vsTemplateID: number;
}

export class assessorTemplateData
{

  vsName: string;
  vsTemplateName: string;
  vsTemplateID: number;
}

export class valueStreamCategoryData
{

  vsName: string;
  vsTemplateName: string;
  vsTemplateID: number;
}
export class vsasIDListData
{
  type:string;
  mode: string;
  QuestionID: number;
  tagID: number;
  IDList : string;
}
