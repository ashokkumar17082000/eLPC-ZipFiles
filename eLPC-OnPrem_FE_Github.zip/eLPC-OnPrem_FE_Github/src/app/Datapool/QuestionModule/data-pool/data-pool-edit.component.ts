import { Component, OnInit, TemplateRef, ViewChild, ElementRef } from '@angular/core';
import { DataPoolService } from 'src/app/service/data-pool.service';
//import { ProcessConfirmation } from '../../../ProcessConfirmation/process-confirmationmode/process-confirmation/process-confirmation';
import { ProcessConfirmation } from 'src/app/pc/process-confirmation/process-confirmation';
import { ValuestreamTemplateService } from 'src/app/service/common/valuestreamtemplate.service';
import { Assessor } from 'src/app/Assessor/assessor/assessortemplate';
import { ValueStream } from 'src/app/Valuestream/valuestreams/valuestreamtemplate';
import { AssessorTemplateService } from 'src/app/service/assessor/assessortemplate.service';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { QuestionService } from 'src/app/service/question.service';
import { Choice, HintImage } from '../questions/question';
import { User } from 'src/app/main/body/shared/common';
import { SharedService } from 'src/app/service/shared.service';
import { CommonService } from 'src/app/service/common/common.service';
import { ProcessConfirmationService } from 'src/app/service/common/process-confirmation.service';
import { LanguageService } from 'src/app/language.service';
import { saveAs } from 'file-saver';
import { Router } from '@angular/router';
import * as $ from 'jquery';
import { DataPoolHistory } from './datapool';
import { formatDate } from '@angular/common';
import { environment } from 'src/environments/environment';
//import { AuditAssessor, AuditQuestion } from 'src/app/main/body/calendar/calendar';
import { AuditAssessor,AuditQuestion } from 'src/app/calendar/calendar/calendar';
import { CalendarService } from 'src/app/service/calendar.service';

@Component({
  selector: 'app-data-pool-edit',
  templateUrl: './data-pool-edit.component.html',
  styleUrls: ['./data-pool-edit.component.css']
})
export class DataPoolEditComponent implements OnInit {
  @ViewChild('fileInput') fileInputVariable: ElementRef;
  @ViewChild('alertPopup') warningModal : TemplateRef<any>;
  @ViewChild('successPopup') successModal : TemplateRef<any>;
  alertText: string;
  dataPoolList:ProcessConfirmation[]=[];
  dataPoolTemplateHistoryID: number;
  dataPoolHistoryDetails: DataPoolHistory[];
  
  dateTimeFormat = environment.dateTimeFormat;

  assessorList: Assessor[] = [];
  valueStreamList:ValueStream[]=[];
  bsModalRef: BsModalRef;
  modalRef: BsModalRef;
  choices: Choice[] = [];
  myAnswerID:number;
  data: any;
  user: User = new User();
  UserNTID:string;
  responsibleEmployee: string;
  isDeviationEntryRequired:boolean=true;
  url: HintImage = new HintImage();
  urls: HintImage[] = [];
  droppedImageName: any;
  config = {
    animated: false,
    keyboard: true,
    ignoreBackdropClick: true
  };
  dataPoolRoute: string = "['/'+environment.home +'/datapool']";
  processConfirmation:ProcessConfirmation=new ProcessConfirmation();
  processConfirmationList:ProcessConfirmation[]=[];
  buttonColor: string; //Default Color
  selectedChoiceID: number;
  newIndex: any;
  count: number = 0;

  auditAssessorList: AuditAssessor[] = [];
  currentRowSelection: any;
  auditList: AuditQuestion[] = [];
  auditAssessorNameList: string[] = [];
  leadAuditor: User = new User();
  others: AuditAssessor[] = [];

  constructor(private local_label: LanguageService, private dataPoolService:DataPoolService,private valuestreamService:ValuestreamTemplateService,
    private assessorService:AssessorTemplateService, private modalService: BsModalService,private questionService:QuestionService,
    private sharedService: SharedService,private commonService: CommonService,private processConfirmationService:ProcessConfirmationService,
    private router: Router, private auditService: CalendarService) { 
    this.UserNTID=this.sharedService.ntid;
    this.data = [];
    this.user = this.commonService.user;
    this.processConfirmation = this.dataPoolService.processConfirmation;
    this.templateId = this.processConfirmation.dataPoolID;

    this.dataPoolService.getDataPoolTemplateHistory(this.templateId).subscribe(res => {
      this.dataPoolHistoryDetails = res;
    });
    this.editDataPool(this.processConfirmation);
  }

  labels: any;
  _subscription: any;

  //For multi select dropdown - Value stream
  dropdownSettingsValueStream = {};
  selectedItemValueStream: ValueStream[] = [];

  //For multi select dropdown - Value stream
  dropdownSettingsAssessor = {};
  selectedItemAssessor: Assessor[] = [];

  ngOnInit() {
    if(this.sharedService.role !=="Designer")
    {
      this.router.navigate([environment.home +'/accessdenied']);
    }
    this.editDataPool(this.processConfirmation);
    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
    });

    this.getValueStreamAndAssessorList(this.processConfirmation.questionID);

    //For multi select dropdown - Assign tag to Value stream template
    this.dropdownSettingsValueStream = {
      singleSelection: true,
      idField: 'valueStreamID',
      textField: 'FormattedValueStream',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 5,
      allowSearchFilter: true,
      closeDropDownOnSelection: true
    };

    //For multi select dropdown - Assessor
    this.dropdownSettingsAssessor = {
      singleSelection: true,
      idField: 'assessorID',
      textField: 'assessorName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 5,
      allowSearchFilter: true,
      closeDropDownOnSelection: true
    };
  }

  //For multi select dropdown - Assign tag to Value stream template
  onSelectValueStream(item: ValueStream) {
    this.processConfirmation.valueStreamID = item.valueStreamID;
    const selectedItem = this.valueStreamList.find(x => x.valueStreamID === this.processConfirmation.valueStreamID);
    if (selectedItem) {
      this.processConfirmation.valueStreamTemplateName = selectedItem.valueStreamTemplateName;
      this.processConfirmation.delimiter = selectedItem.delimiter;
      this.processConfirmation.valueStreamName = selectedItem.valueStreamName;

      this.selectedItemValueStream = [];
      this.selectedItemValueStream.push(selectedItem);
    }
  }
  onDeSelectValueStream() {
    if (!this.selectedItemValueStream || this.selectedItemValueStream.length === 0)
      this.processConfirmation.valueStreamID = 0;
  }
  onLoadValueStream() {
    this.selectedItemValueStream = [];
    if (!this.processConfirmation.valueStreamID || this.processConfirmation.valueStreamID === 0)
      return;
    const selectedItem = this.valueStreamList.find(x => x.valueStreamID === this.processConfirmation.valueStreamID);
    if (selectedItem)
      this.selectedItemValueStream.push(selectedItem);
  }

  //For multi select dropdown - Assessor
  onSelectAssessor(item: Assessor) {
    this.processConfirmation.assessorID = item.assessorID;
    const selectedItem = this.assessorList.find(x => x.assessorID === this.processConfirmation.assessorID);
    if (selectedItem) {
      this.processConfirmation.assessorName = selectedItem.assessorName;

      this.selectedItemAssessor = [];
      this.selectedItemAssessor.push(selectedItem);
    }
  }
  onDeSelectAssessor() {
    if (!this.selectedItemAssessor || this.selectedItemAssessor.length === 0)
      this.processConfirmation.assessorID = 0;
  }
  onLoadAssessor() {
    this.selectedItemAssessor = [];
    if (!this.processConfirmation.assessorID || this.processConfirmation.assessorID === 0)
      return;
    const selectedItem = this.assessorList.find(x => x.assessorID === this.processConfirmation.assessorID);
    if (selectedItem)
      this.selectedItemAssessor.push(selectedItem);
  }

  //saving valuestream and assessor selection in Edit data Pool
  saveVSAndAssessor() {
    if (!this.processConfirmation.valueStreamID || !this.processConfirmation.assessorID) {
      if (!this.processConfirmation.valueStreamID && !this.processConfirmation.assessorID) {
        this.alertText = name + this.labels.default.vsNameRequired + this.labels.default.assessorNameRequired;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
      }
      else if (!this.processConfirmation.valueStreamID) {
        this.alertText = name + this.labels.default.vsNameRequired;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
      }
      else if (!this.processConfirmation.assessorID) {
        this.alertText = name + this.labels.default.assessorNameRequired;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
      }
      return false;
    }

    this.closeAlertModal();
  }


  editDataPool(dataPool: any) {

    this.processConfirmation = Object.assign(new ProcessConfirmation(), this.processConfirmation);


    this.dataPoolService.getProcessConfirmationByID(this.processConfirmation.dataPoolID).subscribe(
      res => {
        this.processConfirmation = res[0];

        if (this.processConfirmation.isCustomMode == true) {
          this.buttonColor = "yellow"; //desired Color
        }

        // this.getHintImages(this.processConfirmation.deviationID); //updated on sep
        // ***********choice type questions..options***************************
        if (this.processConfirmation.answerType_AnswerTypeID == 3) {
          var QuestionID=this.processConfirmation.questionID
          this.questionService.getChoicesByQuestionID(QuestionID).subscribe(
            res => {
              this.choices = res;
              this.getHintImages(this.processConfirmation.deviationID);
              this.choiceSelectionChange(this.processConfirmation.choiceID);
            },
            err => {
              console.log(err);
            });
        }
        this.pendingAuditsByAuditID(this.processConfirmation.auditID, this.processConfirmation.auditTemplateID);
        // *****************************************END Choice*************
      },
      err => {
        console.log(err);
      }
    );

  }

  closepopup(){
    this.router.navigate(['/'+ environment.home +'/datapool']);
  }

  // ********************************delete dataPool ********************
  deleteDataPool(processConfirmation: any) {
    if (this.sharedService.ntid) {
      this.processConfirmation.modifiedBy_NTID = this.sharedService.ntid;
      var d = new Date();
      this.processConfirmation.modifiedAt = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate(), d.getHours(), d.getMinutes(), d.getSeconds()));
    }
    this.dataPoolService.deleteDataPool(this.processConfirmation).subscribe(
      res => {
        if (res.resultCode == 0) {
          this.GetDataPool();
          this.alertText = this.labels.default.deleteSuccessfully;
          this.modalService.show(this.successModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          this.router.navigate([environment.home + '/datapool']);
        }
        else {
          this.alertText = this.labels.default.failedDeleteAssessor;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
        }
      },
      err => {
        console.log(err);
      });

  }

  GetDataPool() {
    this.dataPoolService.GetDataPool(this.sharedService.activeDateRange).subscribe(res => {
      this.dataPoolList = res;
      this.sharedService.hide();
    });
  }
 
  // ********************************************end delete*******************

  // *********************download files**********************
  DownLoadFiles(url) {

    this.droppedImageName = url.imageTitle;

    let fileName = this.droppedImageName;

    let checkFileType = "." + fileName.split('.').pop();
    var fileType = this.sharedService.GetMIMETypeByExtenstion(checkFileType);

    this.processConfirmationService.DownloadFile(fileName, fileType)
      .subscribe(
        success => {
          saveAs(success, fileName);
        },
        err => {
          this.alertText = this.labels.default.serverErrorLoadingFile;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          console.log(err);
        }
      );
  }
  // *************************downlaods fiels ends************


  // ******************************hintImage*******************
  public getHintImages(deviationID: any) {

    this.dataPoolService.hintImagesByDeviationID(deviationID).subscribe(res => {
      this.urls = [];
      this.urls = res;
      this.processConfirmation.hintImages
    },
      err => {
        console.log(err);
      });
  }

// **********************************end***********************
  getValueStreamAndAssessorList(QuestionID: number) {
    this.processConfirmationService.getValueStreamByQuestionID(QuestionID).subscribe(
      res => {
        this.valueStreamList = res;
        //this.valueStreamList = this.valueStreamList.filter(x => x.valueStreamData && x.responsible_UserID);
        this.valueStreamList.forEach(x => x.FormattedValueStream = x.valueStreamTemplateName + x.delimiter + x.valueStreamName );
        this.valueStreamList = this.valueStreamList.filter(x => x.FormattedValueStream);
        this.processConfirmationService.getAssessorsByQuestionID(QuestionID).subscribe(res => {
            this.assessorList = res;
            this.assessorList = this.assessorList.filter(x => x.assessorName);
          },
          err => console.error(err)
        );
      },
      err => console.error(err)
    );
  }

  updateAuditAssessorNameList(){
    this.auditAssessorNameList = [];
    if(this.auditAssessorList != null){
      this.auditAssessorList.map((a)=> {if(a.userName != null && a.userName.trim() != '' && this.auditAssessorNameList.indexOf(a.userName) < 0){ this.auditAssessorNameList.push(a.userName); }});
    }
    if(this.others != null){

      this.others.map((o)=>{ if(o.userName != null && o.userName.trim() != '' && this.auditAssessorNameList.indexOf(o.userName) < 0){ this.auditAssessorNameList.push(o.userName); } });
    }
  }

  pendingAuditsByAuditID(auditID, auditTemplateID) {
    this.valuestreamService.getValueStream().subscribe(res => {
      this.valueStreamList = res;
      if (auditID > 0) {
        this.valueStreamList = this.valueStreamList.filter(x => x.valueStreamID == this.processConfirmation.valueStreamID);
      }

      this.valueStreamList.forEach(x => x.FormattedValueStream = x.valueStreamTemplateName + x.delimiter + x.valueStreamName);

      this.auditService.auditAssessorsByAuditID(auditID).subscribe(res => {
        this.auditAssessorList = res;
        this.updateAuditAssessorNameList();
        let leadAuditor = this.auditAssessorList.filter(x => x.assessorName.toLowerCase() == 'leadauditor');
        if (leadAuditor && leadAuditor.length < 1) {
          let leadAuditorObj: AuditAssessor = new AuditAssessor();
          leadAuditorObj.assessorName = 'LeadAuditor';
          leadAuditorObj.isMandatoryAssessor = true;
          leadAuditorObj.auditID = auditID;

          this.auditAssessorList.push(leadAuditorObj);
        }
        this.auditService.auditAssessorsByAuditAndTemplateID(auditID, auditTemplateID).subscribe(res => {
          this.auditAssessorList = res;
          this.updateAuditAssessorNameList();
          this.auditService.otherAuditAssessorsByAuditAndTemplateID(auditID, auditTemplateID).subscribe(res => {
            this.others = res;
            this.updateAuditAssessorNameList();
          }, err => console.error(err));
        }, err => console.error(err));

      }, err => console.error(err));
    }, err => console.error(err));
  }

  selectAssessor(user: any, i: number) {
    this.currentRowSelection = i;
    if (user !== null) {
      let x = this.data.filter(x => x.ntid == user.ntid)[0];
      if (x) {
        //let asr = this.auditAssessorList.filter(x =>x.assessorName == assessorName)[0];
        this.auditAssessorList[i].userName = x.userName;
        this.auditAssessorList[i].ntid = x.ntid;
      }
    }
    this.data = [];
  }

  onAssessorSearch(val: any, i: number) {
    this.currentRowSelection = i;
    let user = new User();
    user.firstName = val;
    this.commonService.activeDirectoryByName(user).subscribe(res => {
      this.data = [];
      this.data = res;
    },
      err => console.error(err));
  }

  public insertAssessorDetail(template: any, temp: any) {
    
    let x = this.auditAssessorList.filter(x => x.ntid == '' || x.ntid == undefined || x.ntid == null);
    if (x && x.length > 0) {
      let y = x.filter(x => x.isMandatoryAssessor);
      if (y && y.length > 0) {
        this.alertText = this.labels.default.fillMandatoryAssessors;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        return;
      }
    }
    if (!this.processConfirmation.valueStreamID) {
      this.alertText = this.labels.default.selectValueStream;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      return;
    }

    this.updateAuditAssessorNameList();
    this.closeAlertModal();
  }

  auditorDetail(auditorDet) {
    this.open(auditorDet);
  }

  vsAndAssessor(processconfDet) {
    this.onLoadValueStream();
    this.onLoadAssessor();
    this.open(processconfDet);
  }

     /** Method is responsible to show View All Supplier pop up table */
  open(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, this.config);
    this.modalRef.setClass('modal-lg');
  }

  onChangeSearch() {
    let user = new User();
    user.firstName = this.processConfirmation.responsibleEmployee;
    this.commonService.activeDirectoryByName(user).subscribe(res => {
      this.data = [];
      this.data = res;
    },
      err => console.error(err));
  }

  selectUser(user: User) {
    this.processConfirmation.responsibleEmployee = user.userName;
    this.data = [];
    this.user = user;
  }

// *******************Image atatchment selection************************
  onSelectFile(event) {
    //validate the file if file size is more than 10MB
    for (var i = 0; i < event.target.files.length; i++) {
      var name = event.target.files[i].name;
      var type = event.target.files[i].type;
      var size = event.target.files[i].size;
      var modifiedDate = event.target.files[i].lastModifiedDate;

      if (size > environment.maxFileSize) {
        this.alertText = this.labels.default.maximumFileSize;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        return;
      }

    }
    // *************************validation of file size ends here**************

    let now = new Date();
    var jstoday;
    jstoday = formatDate(now, 'dd_MM_yyyy hh_mm_ss_a', 'en-US', '+0530').toString();
    let totalSize = 0;
    if (event.target.files && event.target.files[0]) {
      var filesAmount = event.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        let name = event.target.files[i].name;

        //  ************************ validation of file Type*********************************************************************************

        //if (!name.match(/.(jpg|jpeg|png|gif|txt|pdf|doc|docx|xls|xlsx|csv|mp4)$/i))
        var fileTypes = environment.fileTypes.split(",").map(function (item) {
          return item.trim();
        });
        var extension = name.slice((Math.max(0, name.lastIndexOf(".")) || Infinity) + 1);
        let x = fileTypes.filter(x => x.toLocaleLowerCase() == extension.toLocaleLowerCase());  
        
        if (x.length == 0) {
          this.alertText = name + this.labels.default.fileUploadError.replace("((FileTypes))", environment.fileTypes);
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          return;
        }

        //  *************************Validation Ends*****************************************************************************************
        let size = event.target.files[i].size;
        reader.onload = (event: any) => {

          this.url = new HintImage();
          this.url.imageTitle = jstoday + "_" + name;
          this.url.displayFileName = name;

          this.url.size = size;
          this.url.fileContent = event.target.result;

          if (extension == "jpg" || extension == "jpeg" || extension == "png") {
            var compressed = this.sharedService.compressImage(event.target.result, "image/jpeg", 0.5, 0.9);
            if (compressed != "data:,")
              this.url.fileContent = compressed;
          }
          
          for (let row of this.urls) {
            totalSize += row.size;
          }
          totalSize += size;
          if (totalSize > (environment.maxFileSize*environment.maxAttachments) || this.urls.length >= environment.maxAttachments) {
            this.alertText = this.labels.default.maximumFileSize;
            this.modalService.show(this.warningModal);
            $("modal-container").removeClass("fade");
            $(".modal-dialog").addClass("modalSize");
            return;
          }
          if (this.urls == undefined) {
            this.urls = [];
          }
          this.urls.push(this.url);
        }

        reader.readAsDataURL(event.target.files[i]);
      }

    }
    this.fileInputVariable.nativeElement.value = "";
  }

// *************************remove attachment******************
// removeHintImage(event: any) {

//   let name = event.target.id;
//   this.urls = this.urls.filter(x => x.imageTitle !== name);
// }


  showModal()
  {
    document.getElementById('deleteModal').style.display = "block";
    document.getElementById('deleteModalcustomMode').style.display = "block";
  }

  closeModal()
  {
    
    document.getElementById('deleteModal').style.display = "none"; 
    document.getElementById('deleteModalcustomMode').style.display = "none"; 
    document.querySelector('body').classList.remove('-is-modal');
  }


  deleteTemplate()
  {
    document.getElementById('deleteModal').style.display = "none"; 
    this.deleteDataPool(this.processConfirmation);
  }


removeDeviationImage(name) {
 
    if (confirm(this.labels.default.deleteImage)) {
      this.urls = this.urls.filter(x => x.imageTitle !== name);
      this.dataPoolService.removeDeviationImage(this.processConfirmation).subscribe(res => {
        this.alertText = this.labels.default.deleteSuccessfully;
        this.modalService.show(this.successModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
      },
        err => {
          console.log(err);
        });
    }
  }

  tempProcessConfirmation: ProcessConfirmation;

  showUpdateModal(processConfirmation: ProcessConfirmation)
  {
    this.tempProcessConfirmation = processConfirmation;
    document.getElementById('updatePool').style.display = "block";
  }

  closeUpdateModal()
  {
    document.getElementById('updatePool').style.display = "none";
    document.querySelector('body').classList.remove('-is-modal');
  }

  updateData()
  {
    this.closeUpdateModal();
    this.UpdateDataPool(this.tempProcessConfirmation);
  }


// ******************************************Image atatchemnt end***********************************************
  public UpdateDataPool(processConfirmation: ProcessConfirmation) {

    this.processConfirmation.modifiedBy_NTID = this.sharedService.ntid;
    this.myAnswerID = this.processConfirmation.answerType_AnswerTypeID;
    if (this.myAnswerID == 3) {

      // *************************************************testing devaiation balues validatiton in datapool edit*****************************************
      if (processConfirmation.deviationID) {
        // if isdeviation true then validate the mandatory fields
        if (!this.processConfirmation.deviationDescription || !this.processConfirmation.responsibleEmployee) {
          if (!this.processConfirmation.deviationDescription && !this.processConfirmation.responsibleEmployee) {
            this.alertText = name + this.labels.default.fillDescription;
            this.modalService.show(this.warningModal);
            $("modal-container").removeClass("fade");
            $(".modal-dialog").addClass("modalSize");
            return;
          }
          else if (!this.processConfirmation.deviationDescription) {
            this.alertText = name + this.labels.default.fillDeviationOnly;
            this.modalService.show(this.warningModal);
            $("modal-container").removeClass("fade");
            $(".modal-dialog").addClass("modalSize");
            return;
          }
          else if (!this.processConfirmation.responsibleEmployee) {
            this.alertText = name + this.labels.default.fillResponsibleEmployee;
            this.modalService.show(this.warningModal);
            $("modal-container").removeClass("fade");
            $(".modal-dialog").addClass("modalSize");
            return;
          }
          return false;
        }
      }
      this.processConfirmation.answer = this.choices.filter(x => x.choiceID == this.processConfirmation.choiceID)[0].choiceName;
      this.processConfirmation.obtainedScore = this.choices.filter(x => x.choiceID == this.processConfirmation.choiceID)[0].choiceScore;
      this.processConfirmation.hintImages = this.urls;

    }
    this.dataPoolService.UpdateDataPool(this.processConfirmation).subscribe(res => {
      if (res.resultCode == 0) {
        this.alertText = this.labels.default.updateSuccessfully;
        this.modalService.show(this.successModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.router.navigate(['/' + environment.home + '/datapool']);
      }
      else {
        this.alertText = this.labels.default.updateFailed;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
      }
    });


  }

  public closeAlertModal(){
    if(document.getElementsByTagName("modal-container").length > 1){
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length-1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length-1]);
    }
    else{
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if(document.getElementsByTagName("bs-modal-backdrop").length > 0){
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }
  }

  templateId: number;

  openDataPoolHistory(dpHistory: TemplateRef<any>) {
    this.modalRef = this.modalService.show(dpHistory, this.config);
    this.modalRef.setClass('modal-lg');
    $('.isRestoreDisabled').prop('disabled', true);

    setTimeout(function () {
      $("#dataPoolHistory tbody tr").click(function () {
        $(".selected").removeClass('selected');
        $(this).addClass('selected');
        $('.isRestoreDisabled').prop('disabled', false);
      });
    }, 100);
  }

  dataPoolHistoryID: any;

  restoreVersion() {
    this.dataPoolHistoryID = $("#dataPoolHistory tr.selected td:first").html();
    this.dataPoolService.dataPoolRestoreByTemplateHistoryID(this.dataPoolHistoryID).subscribe(res => {
      this.closeAlertModal();
      this.alertText = this.labels.default.restoreSuccessfully;
      this.modalService.show(this.successModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      this.router.navigate(['../'+environment.home +'/datapool']);
    },
      (err) => {
        console.log(err.message);
        this.closeAlertModal();
      });
  }

  // ******************newly added*****************
  setLabelMessage: string;
  messageSet(message: string)
  {
    this.showModal();
    if(message == 'nyellow')
    {
      this.setLabelMessage = this.labels.default.warningQuestion;
    }
    if(message == 'yellow')
    {
      this.setLabelMessage = this.labels.default.deleteQuestion;
    }
  }

  addToCustomMode(processConfirmation: ProcessConfirmation) {

    if (this.buttonColor == "yellow") {
      this.processConfirmationService
        .deleteFromCustomMode(this.processConfirmation)
        .subscribe(res => {
          this.closeModal();
          this.alertText = this.labels.default.deleteSuccessfully;
          this.modalService.show(this.successModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
        });
      this.buttonColor = "white";
    }
    else {
      this.count++;
      this.buttonColor = "yellow"; //desired Color
      this.processConfirmationService
        .addToCustomMode(processConfirmation)
        .subscribe(res => {
          this.closeModal();
          this.alertText = this.labels.default.insertedSuccessfully;
          this.modalService.show(this.successModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
        });
    }
  }

  selectOptionChange(args) {
    var id = JSON.parse(args.target.value);
    this.choiceSelectionChange(id);
  }

  choiceSelectionChange(id:number) {
    let deviationTypeID = this.choices.filter(
      x => x.choiceID == id
    )[0].deviationTypeID;
    if (deviationTypeID == 1) {
      this.isDeviationEntryRequired = false;
    }
    else {
      this.isDeviationEntryRequired = true;
    }
  }
}
