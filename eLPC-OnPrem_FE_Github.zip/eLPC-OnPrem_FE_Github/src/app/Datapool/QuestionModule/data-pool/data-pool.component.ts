import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { SharedService } from 'src/app/service/shared.service';
import { ProcessConfirmation } from '../../../pc/process-confirmation/process-confirmation';
import { DataPoolService } from 'src/app/service/data-pool.service';
import { Router } from '@angular/router';
import { ProcessConfirmationService } from 'src/app/service/common/process-confirmation.service';
import { LanguageService } from 'src/app/language.service';
import { environment } from 'src/environments/environment';
import { BsModalService } from 'ngx-bootstrap/modal';
import { FormGroup, FormControl } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ExcelService } from 'src/app/service/excel.service';
import { ChangeDetectorRef } from '@angular/core';


@Component({
  selector: 'app-data-pool',
  templateUrl: './data-pool.component.html',
  styleUrls: ['./data-pool.component.css']
})

export class DataPoolComponent implements OnInit {
  @ViewChild("alertPopup") warningModal: TemplateRef<any>;
  @ViewChild('ResumeModal') public ResumeModal: TemplateRef<any>;
  dataTable: any;
  dataPoolList: ProcessConfirmation[] = [];
  totalList: ProcessConfirmation[];
  dateTimeFormat = environment.dateTimeFormat;
  filterdateFormat  = environment.dateTimeFormat.split(" ")[0];

  filterId = false;
  filterName = false;
  filterTimeStamp = false;
  filterModifiedBy = false;
  filterQuestionID = false;
  filterAnswer = false;
  filterValueStream = false;
  filterAssessor = false;
  filterScore = false;
  filterTagName = false;

  filtertext: string = '';
  filterType: string = "test";
  key: string = 'name';//for sorting
  reverse1: boolean = false;//for sorting
  headerFilterName: string = "";//for filtering
  config = {
    animated: false,
    keyboard: true,
    ignoreBackdropClick: true
  };
  public data = [];
  public settings = {};
  public form: FormGroup;
  public loadContent: boolean = false;

  labels: any;
  _subscription: any;

  page: number = 1;
  resultPerPage: number = 10;
  startPage: number;
  endPage: number;
  alertText: any;
  str1: any;
  filterPopUp: any;
  filterQuestionText: boolean;
  dataCopy=[];

  constructor(private local_label: LanguageService, public sharedService: SharedService, private dataPoolService: DataPoolService,
    private router: Router, private processConfirmationService: ProcessConfirmationService, private modalService: BsModalService, private datePipe: DatePipe,
    private excelService: ExcelService,private cdr: ChangeDetectorRef) {
  }

  ngOnInit() {
    // if(this.sharedService.role !=="Designer")
    // {
    //   this.router.navigate([environment.home +'/accessdenied']);
    // }
    window.scrollTo(0, 0);
    this.sharedService.show();
    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
    });


    this.GetDataPool();
  }


  ngAfterViewInit() {
    setTimeout(() => {
        document.body.style.overflowY = "scroll";
    }, 0);
}


  //#region Pagination, Sorting & filtering
  /** Method is responsible to move to first page of the pagination. */
  isFirstPage() {
    if (this.page == 1) {
      return;
    }
    else {
    }

    this.page = 1;
    this.startPage = (this.page - 1) * 4 + 1;
    this.endPage = this.page * this.resultPerPage;
  }

  /** Method is responsible to move to last page of the pagination. */
  isLastPage() {
    if (Math.ceil(this.dataPoolList.length / this.resultPerPage) <= this.page) {
      return;
    }
    else {

    }

    this.page = Math.ceil(this.dataPoolList.length / this.resultPerPage);
    this.startPage = (this.page - 1) * 4 + 1;
    this.endPage = this.page * this.resultPerPage;
  }

  /** Method is responsible to change page of the pagination. */
  pageChanged(event): void {

    if (event == 0) {
      return;
    }
    else if (Math.ceil(this.dataPoolList.length / this.resultPerPage) < event) {
      return;
    }
    else {
      this.page = event;
      this.startPage = (this.page - 1) * 4 + 1;
      this.endPage = this.page * this.resultPerPage;
    }
  }


  showFilter() {
    this.filterName = !this.filterName;
  }


  public openAlertModal(popUp: any) {
    this.filterPopUp = popUp;
  }

  public closeAlertModal() {
    this.filterPopUp.hide();
    if (this.dataPoolList.length == this.totalList.length) {
    //document.getElementsByTagName("popover-container")[0].parentNode.removeChild(document.getElementsByTagName("popover-container")[0]);
    this.filtertext = '';
    this.filterId = false;
    this.filterTimeStamp = false;
    this.filterModifiedBy = false;
    this.filterQuestionID = false;
    this.filterAnswer = false;
    this.filterValueStream = false;
    this.filterAssessor = false;
    this.filterScore = false;
    this.filterTagName = false;
    //document.querySelector('body').classList.remove('-is-modal');
    }
  }

  //resetting all the filtering and sorting
  resetAll() {
    this.reverse1 = false;
    this.filtertext = "";
  }

  //*********************sorting*********
  sort(key) {
    this.key = this.headerFilterName;;
    this.reverse1 = !this.reverse1;
  }

  getButtonType(buttonname: any): any {
    this.filterType = buttonname;
  }
  // *********************************

  getColumnName(headername: any) {
   
    if (this.filteredItems == undefined) {
      this.filteredItems = []
    }

    this.dataPoolList = this.totalList;//newly added
    this.filtertext = '';
    this.filterId = false;
    this.filterTimeStamp = false;
    this.filterModifiedBy = false;
    this.filterQuestionID = false;
    this.filterAnswer = false;
    this.filterValueStream = false;
    this.filterAssessor = false;
    this.filterScore = false;
    this.filterTagName = false;
    this.filterQuestionText = false;

    if (headername == 'dataPoolDisplayID') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].dataPoolDisplayID);
      }
      this.filterId = !this.filterId;
    }
    else if (headername == 'timeStamp') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.datePipe.transform(this.totalList[i].timeStamp,this.filterdateFormat));
      }
      this.filterTimeStamp = !this.filterTimeStamp;
    }
    else if (headername == 'userName') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].userName);
      }
      this.filterModifiedBy = !this.filterModifiedBy;
    }
    else if (headername == 'questionDisplayID') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].questionDisplayID);
      }
      this.filterQuestionID = !this.filterQuestionID;
    }
    else if (headername == 'questionText') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].questionText);
      }
      this.filterQuestionText = !this.filterQuestionText;
    }
    else if (headername == 'answer') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].answer);
      }
      this.filterAnswer = !this.filterAnswer;
    }
    else if (headername == 'valueStreamName') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].valueStreamName);
      }
      this.filterValueStream = !this.filterValueStream;
    }
    else if (headername == 'assessorName') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].assessorName);
      }
      this.filterAssessor = !this.filterAssessor;
    }
    else if (headername == 'obtainedScore') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].obtainedScore);
      }
      this.filterScore = !this.filterScore;
    }
    this.headerFilterName = headername;
    this.searchFilter();
  }

  setForm() {
    this.form = new FormGroup({
      name: new FormControl(
        this.data
      )
    });
    this.loadContent = true;
  }

  searchFilter(num?:number) {
    debugger;
    if(num!=1){
      this.data = [];
    }// ********************************searching
    var prefix = 'Q';
    if (this.headerFilterName == "timeStamp") {
      for (var dataPoolDet of this.dataPoolList) {
        this.str1 = this.datePipe.transform(dataPoolDet.timeStamp, this.filterdateFormat);//converting the date format
        let newItem = {
          dataPoolID: dataPoolDet.dataPoolID,
          timeStamp: this.str1
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.timeStamp ===  this.str1 )) {//newly added
            this.data.push(newItem);
          }
        }
      }
    }
    else if (this.headerFilterName == "userName") {
      for (var dataPoolDet of this.dataPoolList) {
        let newItem = {
          dataPoolID: dataPoolDet.dataPoolID,
          userName: dataPoolDet.userName
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.userName === dataPoolDet.userName)) {//newly added
            this.data.push(newItem);
          }
        }
      }
    }
    else if (this.headerFilterName == "questionDisplayID") {
      for (var dataPoolDet of this.dataPoolList) {
        let newItem = {
          dataPoolID: dataPoolDet.dataPoolID,
          questionDisplayID: 'Q' + dataPoolDet.questionDisplayID.toString()
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.questionDisplayID ===  'Q' + dataPoolDet.questionDisplayID)) {//newly added
            this.data.push(newItem);
          }
        }
      }
    }
    else if (this.headerFilterName == "questionText") {
      for (var dataPoolDet of this.dataPoolList) {
        let newItem = {
          dataPoolID: dataPoolDet.dataPoolID,
          questionText: dataPoolDet.questionText
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.questionText === dataPoolDet.questionText)) {
            this.data.push(newItem);
          }
        }
      }
    }
    else if (this.headerFilterName == "answer") {
      for (var dataPoolDet of this.dataPoolList) {
        let newItem = {
          dataPoolID: dataPoolDet.dataPoolID,
          answer: dataPoolDet.answer
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.answer === dataPoolDet.answer)) {
            this.data.push(newItem);
          }
        }
      }
    }

    else if (this.headerFilterName == "dataPoolDisplayID") {
      for (var dataPoolDet of this.dataPoolList) {
        let newItem = {
          dataPoolID: dataPoolDet.dataPoolID,
          dataPoolDisplayID: dataPoolDet.dataPoolDisplayID
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.dataPoolDisplayID === dataPoolDet.dataPoolDisplayID)) {
            this.data.push(newItem);
          }
        }
      }
    }

    else if (this.headerFilterName == "valueStreamName") {
      for (var dataPoolDet of this.dataPoolList) {
        let newItem = {
          dataPoolID: dataPoolDet.dataPoolID,
          valueStreamName: dataPoolDet.valueStreamName
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.valueStreamName === dataPoolDet.valueStreamName)) {
            this.data.push(newItem);
          }
        }
      }
    }
    else if (this.headerFilterName == "assessorName") {
      for (var dataPoolDet of this.dataPoolList) {
        let newItem = {
          dataPoolID: dataPoolDet.dataPoolID,
          assessorName: dataPoolDet.assessorName
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.assessorName === dataPoolDet.assessorName)) {
            this.data.push(newItem);
          }
        }
      }
    }
    else if (this.headerFilterName == "obtainedScore") {
      for (var dataPoolDet of this.dataPoolList) {
        let newItem = {
          dataPoolID: dataPoolDet.dataPoolID,
          obtainedScore: dataPoolDet.obtainedScore
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.obtainedScore === dataPoolDet.obtainedScore)) {
            this.data.push(newItem);
          }
        }
      }
    }
    this.dataCopy=JSON.parse(JSON.stringify(this.data))
  
    this.settings = {//setting for multiselect dropdown
      singleSelection: false,
      idField: 'dataPoolID',
      textField: this.headerFilterName,


      enableCheckAll: true,
      selectAllText: 'Select All',
      unSelectAllText: 'Unselect All',
      allowSearchFilter: true,
      limitSelection: -1,
      clearSearchFilter: true,
      maxHeight: 197,
      itemsShowLimit: 0,
      searchPlaceholderText: 'Search',
      noDataAvailablePlaceholderText: 'No Data Available',
      closeDropDownOnSelection: false,
      showSelectedItemsAtTop: false,
      defaultOpen: false
    };
    this.setForm();
    // ************************************************
  }

  // ************************************filtering ends******************************************************
  // ***********************************Dropdown multiselect filtering**************************
  filteredItems: Array<any>;
  x: any;

  onItemSelect(item: any) {
    if (this.filteredItems == undefined) {
      this.filteredItems = [];
    }

    if (this.headerFilterName == 'timeStamp') {
      if (this.filteredItems.indexOf(item.timeStamp) < 0) {
        this.filteredItems.push(item.timeStamp);
      }
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(this.datePipe.transform(f.timeStamp, this.filterdateFormat)));
    }
    else if (this.headerFilterName == 'userName') {
      if (this.filteredItems.indexOf(item.userName) < 0) {
        this.filteredItems.push(item.userName);
      }
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.userName));
    }
    else if (this.headerFilterName == 'questionDisplayID') {
      item.questionDisplayID = item.questionDisplayID.replace("Q", "");
      if (this.filteredItems.indexOf(item.questionDisplayID) < 0) {
        this.filteredItems.push(item.questionDisplayID);
      }
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.questionDisplayID.toString()));
    }
    else if (this.headerFilterName == 'questionText') {
      if (this.filteredItems.indexOf(item.questionText) < 0) {
        this.filteredItems.push(item.questionText);
      }
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.questionText));
    }
    else if (this.headerFilterName == 'answer') {
      if (this.filteredItems.indexOf(item.answer) < 0) {
        this.filteredItems.push(item.answer);
      }
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.answer));
    }
    else if (this.headerFilterName == 'dataPoolDisplayID') {
      if (this.filteredItems.indexOf(item.dataPoolDisplayID) < 0) {
        this.filteredItems.push(item.dataPoolDisplayID);
      }
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.dataPoolDisplayID));
    }
    else if (this.headerFilterName == 'valueStreamName') {
      if (this.filteredItems.indexOf(item.valueStreamName) < 0) {
        this.filteredItems.push(item.valueStreamName);
      }
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.valueStreamName));
    }
    else if (this.headerFilterName == 'assessorName') {
      if (this.filteredItems.indexOf(item.assessorName) < 0) {
        this.filteredItems.push(item.assessorName);
      }
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.assessorName));
    }
    else if (this.headerFilterName == 'obtainedScore') {
      if (this.filteredItems.indexOf(item.obtainedScore) < 0) {
        this.filteredItems.push(item.obtainedScore);
      }
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.obtainedScore));
    }
  }

  public onDeSelect(item: any) {
    if (this.filteredItems == undefined) {
      this.filteredItems = [];
    }
    if (this.headerFilterName == 'timeStamp') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.timeStamp);
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(this.datePipe.transform(f.timeStamp, this.filterdateFormat)));
    }
    else if (this.headerFilterName == 'modifiedAt') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.modifiedAt);
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.modifiedAt));
    }
    else if (this.headerFilterName == 'questionDisplayID') {
      item.questionDisplayID = item.questionDisplayID.replace("Q", "");
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.questionDisplayID);
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.questionDisplayID.toString()));
    }
    else if (this.headerFilterName == 'questionText') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.questionText);
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.questionText));
    }
    else if (this.headerFilterName == 'answer') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.answer);
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.answer));
    }
    else if (this.headerFilterName == 'dataPoolDisplayID') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.dataPoolDisplayID);
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.dataPoolDisplayID));
    }

    else if (this.headerFilterName == 'valueStreamName') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.valueStreamName);
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.valueStreamName));
    }
    else if (this.headerFilterName == 'assessorName') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.assessorName);
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.assessorName));
    }
    else if (this.headerFilterName == 'obtainedScore') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.obtainedScore);
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.obtainedScore));
    }
  }


  onSelectAll(items: any) {
    if (this.filteredItems == undefined) {
      this.filteredItems = [];
    }
    for (var i = 0; i < items.length; i++) {
      if (this.headerFilterName == 'timeStamp') {
        this.filteredItems.push(items[i].timeStamp)
      }
      else if (this.headerFilterName == 'modifiedAt') {
        this.filteredItems.push(items[i].modifiedAt)
      }
      else if (this.headerFilterName == 'questionDisplayID') {
        this.filteredItems.push(items[i].questionDisplayID)
      }
      else if (this.headerFilterName == 'userName') {
        this.filteredItems.push(items[i].userName)
      }
      else if (this.headerFilterName == 'dataPoolDisplayID') {
        this.filteredItems.push(items[i].dataPoolDisplayID)
      }
      else if (this.headerFilterName == 'questionText') {
        this.filteredItems.push(items[i].questionText)
      }
      else if (this.headerFilterName == 'answer') {
        this.filteredItems.push(items[i].answer)
      }
      else if (this.headerFilterName == 'valueStreamName') {
        this.filteredItems.push(items[i].valueStreamName)
      }
      else if (this.headerFilterName == 'assessorName') {
        this.filteredItems.push(items[i].assessorName)
      }
      else if (this.headerFilterName == 'obtainedScore') {
        this.filteredItems.push(items[i].obtainedScore)
      }
    }
    this.dataPoolList = this.totalList;
  }

  public onDeSelectAll(items: any) {
    this.filteredItems = [];
    this.dataPoolList = this.totalList;
  }

  //  *******************************************************************************************Dropdown filtering ends here***************
  //#endregion ************************************filtering ends******************************************************


  public async GetDataPool() {
    this.sharedService.show();
     if(this.sharedService.role !=="Designer")
    {
      this.sharedService.activeDateRange.IsDesigner=0
    }
    console.log("579",this.sharedService.activeDateRange)
   await this.dataPoolService.GetDataPool(this.sharedService.activeDateRange).subscribe(res => {
      this.dataPoolList = res;
      this.totalList = this.dataPoolList;
      this.sharedService.hide();
    });
  }

  editDataPool(processConfirmation: any) {
    console.log("editdatpool")
    this.dataPoolService.processConfirmation = processConfirmation;
   // this.router.navigate([environment.home + '/dataPool-edit/']);
   this.router.navigate([`${environment.home}/datapool/dataPool-edit`] );
  }

  reDirectToPC(questionID: any) {

    this.router.navigate([environment.home + '/processConfirmation', { qid: questionID }]);

  }

  GetTagID(tagId: any) {

    this.router.navigate([environment.home + '/processConfirmation', { tid: tagId }]);

  }

  reDirectToQuestionID(questionID: any) {
    console.log("6087",questionID)
    //Modified By EGV1COB
    //As Alberto insists when question id clicked it should redirected to edit question page
    this.router.navigate([environment.home + '/datapool/questions', { qid: questionID }]);
  //  this.router.navigate([`${environment.home}/datapool/questions`], {queryParams: {qid: questionID } });
  }

  onOpenDropdown($event) {
    console.log("open ")
    console.log("datcopy",this.dataCopy)
    console.log(this.data)
    this.dataCopy = [...this.dataCopy];
    this.cdr.detectChanges();
  }

  reDirectToTagID(tagId: any) {
    //Modified By EGV1COB
    //As Alberto insists when question id clicked it should redirected to edit tag page
    this.router.navigate([environment.home + '/taglist', { tid: tagId }]);
  }

  
  //  *****************Export Import Assessor Excel*************
  public async dataPoolExportExcel(num? : number) {
    //debugger;
    
    if(num) {
      await this.dataPoolService.GetExcelFile("DataPool");
    }else {
      this.modalService.show(this.ResumeModal, this.config);
    $("modal-container").removeClass("fade");
    }
    
  }
  public async dataPoolExportExcelFiltered(num? : number) {
    //debugger;
    var  fromDate=new Date(this.sharedService.activeDateRange.fromDate)
    var dateObject = new Date(this.sharedService.activeDateRange.fromDate);
    // Extract year, month, and day
    console.log()
    var fromyear = dateObject.getFullYear();
    var frommonth = ('0' + (dateObject.getMonth() + 1)).slice(-2); // Adding 1 because getMonth() returns zero-based month index
    var fromday = ('0' + dateObject.getDate()).slice(-2);
    //TODATE
    var  toDate=new Date(this.sharedService.activeDateRange.toDate)
    var dateObject = new Date(this.sharedService.activeDateRange.toDate);
    // Extract year, month, and day
    var toyear = dateObject.getFullYear();
    var tomonth = ('0' + (dateObject.getMonth() + 1)).slice(-2); // Adding 1 because getMonth() returns zero-based month index
    var today = ('0' + dateObject.getDate()).slice(-2);

    // Construct the desired date format
    var formattedfromDate = fromyear + '-' + frommonth + '-' + fromday;

    var formattedtoDate = toyear + '-' + tomonth + '-' + today;
    console.log(formattedfromDate);
    console.log(formattedtoDate); // Output: "2024-02-01"
        await this.dataPoolService.GetExcelFile("DataPoolFiltered",false,formattedfromDate,formattedtoDate);
  }
  // dataPoolExportExcel() {
  //   this.dataPoolService.GetExcelFile("DataPool");
  // }

  searchGrid(value: string) {   
    if (value.length > 0) {
      var searchText = value.trim().toLowerCase();
      this.dataPoolList = this.totalList;

      this.dataPoolList = this.dataPoolList.filter(x =>
        (x.userName != null && x.userName.trim().toLowerCase().includes(searchText)) 
        || (x.timeStamp != null && this.datePipe.transform(x.timeStamp,this.filterdateFormat).trim().toLowerCase().includes(searchText)) 
        || (x.valueStreamName != null && x.valueStreamName.trim().toLowerCase().includes(searchText)) 
        || (x.assessorName != null && x.assessorName.trim().toLowerCase().includes(searchText))
        || (x.questionDisplayID != null && x.questionDisplayID.toString().trim().toLowerCase().includes(searchText.replace("q","")))
        || (x.questionText != null && x.questionText.trim().toLowerCase().includes(searchText))
        || (x.answer != null && x.answer.trim().toLowerCase().includes(searchText))
        || (x.obtainedScore != null && x.obtainedScore.toString().trim().toLowerCase().includes(searchText))
        || (x.editTagList != null && x.editTagList.map(item => item.myTagName).toString().toLowerCase().includes(searchText))
      );
      this.page = 1;
    }
    else {
      this.dataPoolList = this.totalList;
    }
  }

  exportAsXLSX() {
   // debugger;
    this.sharedService.show();

    var excelData = this.dataPoolList.map((d) => ({
      DataPoolID: d.dataPoolID,
      DataPoolDisplayID: d.dataPoolDisplayID,
      TIMESTAMP: d.timeStamp,
      UserName: d.userName,
      ValueStreamData: d.valueStreamName,
      DeviationTag:d.tagList.map(item => item.tagName).join(";"),
      AssessorName: d.assessorName,
      OriginTag: d.originTag,
      OPLURL: d.oplurl,
      QuestionDisplayID: 'Q' + d.questionDisplayID,
      QuestionText: d.questionText,
      Answer: d.answer,
      ObtainedScore: d.obtainedScore,
      InformationTo:d.addEmpList.map(item =>item.myUserNmae).join(";"),
      TagName: d.editTagList.map(item => item.myTagName).join(";"),
    }));

    this.excelService.exportAsExcelFile(excelData, 'DataPool_Filtered');
  }
  
 

  public async GetDataPoolBySelectedRange() {
    var monthDiff = this.sharedService.monthDiff(this.sharedService.activeDateRange.fromDate, this.sharedService.activeDateRange.toDate);
    if (monthDiff <= this.sharedService.activeDateRange.maxIntervalInMonths) {
     await  this.GetDataPool();
    } else {
      this.alertText = this.labels.monthValidationError.replace("((months))", this.sharedService.activeDateRange.maxIntervalInMonths.toString()) ;//this.labels.default.updateFailed;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");

      //this.sharedService.activeDateRange.fromDate = new Date(this.sharedService.activeDateRange.toDate);
      //this.sharedService.activeDateRange.fromDate.setMonth(this.sharedService.activeDateRange.fromDate.getMonth() - this.sharedService.activeDateRange.maxIntervalInMonths);
    }
  }
  
  closeAlertModal1( num?: number) {
    //debugger;
    if (document.getElementsByTagName("modal-container").length > 1) {
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1]);
    }
    else {
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if (document.getElementsByTagName("bs-modal-backdrop").length > 0) {
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }
    if(num) {
      
      this.dataPoolExportExcel(1)
    }

  }

  closeWarningAlertModal() {
    if (document.getElementsByTagName("modal-container").length > 1) {
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1]);
    }
    else {
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if (document.getElementsByTagName("bs-modal-backdrop").length > 0) {
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }
  }
}

