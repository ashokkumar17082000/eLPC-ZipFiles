export class DataPoolHistory {
    DataPoolHistoryID ?:number;
    DataPoolHistoryDisplayID ?:number;
    DataPoolID ?:number;
    ModifiedBy ?:string;
    ModifiedBy_NTID ?:any;
    ModifiedAt : Date;
    CreatedAt : Date;
  }