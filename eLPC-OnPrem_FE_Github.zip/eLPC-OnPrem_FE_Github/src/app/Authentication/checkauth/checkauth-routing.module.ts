import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CheckAuthComponent } from './check-auth/check-auth.component';
const routes: Routes = [
  { path: '', component: CheckAuthComponent },
  { path: ':plant', component: CheckAuthComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CheckauthRoutingModule { }
