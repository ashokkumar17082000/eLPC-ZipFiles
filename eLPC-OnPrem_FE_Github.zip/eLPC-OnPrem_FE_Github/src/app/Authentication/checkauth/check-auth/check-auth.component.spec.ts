import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CheckAuthComponent } from './check-auth.component';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from '../app-routing.module';
import { TestComponent } from '../test/test.component';
import { PlantComponent } from '../main/body/plant/plant.component';
import { MainComponent } from '../main/main.component';
import { DashboardComponent } from 'src/app/dashboard-elpc/dashboard/dashboard.component';
import { RoleComponent } from '../main/body/role/role.component';
import { AddEditRoleComponent } from '../main/body/role/role.addedit.component';
import { UserComponent } from '../main/body/user/user.component';
import { UserEditComponent } from '../main/body/user/user.addedit.component';
import { ValueStreamsLockComponent } from 'src/app/Valuestream/valuestreams/value-streams.lock.component';
import { ValueStreamsComponent } from 'src/app/Valuestream/valuestreams/value-streams.component';
import { ValueStreamsEditComponent } from 'src/app/Valuestream/valuestreams/value-streams.edit.component';
import { AssessorComponent } from 'src/app/Assessor/assessor/assessor.component';
import { AssessorEditComponent } from 'src/app/Assessor/assessor/assessors.edit.component';
import { AssessorLockComponent } from 'src/app/Assessor/assessor/assessor.lock.component';
import { QuestionsComponent } from 'src/app/Datapool/QuestionModule/questions/questions.component';
import { QuestionLockComponent } from 'src/app/Datapool/QuestionModule/questions/questions.lock.component';
import { TagListComponent } from 'src/app/Tag/tag/tag-list.component';
import { TagEditComponent } from 'src/app/Tag/tag/tag-edit.component';
import { TagLockComponent } from 'src/app/Tag/tag/tag.lock.component';
import { DataPoolComponent } from 'src/app/Datapool/QuestionModule/data-pool/data-pool.component';
import { RecycleBinComponent } from 'src/app/RecycleBin/recycle-bin/recycle-bin.component';
import { CalendarComponent } from '../main/body/calendar/calendar.component';
import { ProcessConfirmationComponent } from '../main/body/process-confirmation/process-confirmation.component';
import { DataPoolEditComponent } from 'src/app/Datapool/QuestionModule/data-pool/data-pool-edit.component';
import { CustomModeComponent } from '../main/body/custom-mode/custom-mode.component';
import { ShuffleModeComponent } from '../main/body/shuffle-mode/shuffle-mode.component';
import { TagModeComponent } from '../main/body/tag-mode/tag-mode.component';
import { DeviationComponent } from 'src/app/Deviation/deviation/deviation.component';
import { AuditComponent } from '../main/body/audit/audit.component';
import { AdminreportComponent } from '../main/body/reports/adminreport/adminreport.component';
import { SuperOPLComponent } from '../main/body/super-opl/super-opl.component';
import { UserreportComponent } from '../main/body/reports/userreport/userreport.component';
import { ErrorComponent } from '../error/error.component';
import { NgxPaginationModule } from 'ngx-pagination';
//import { ColumnFilterPipe } from '../service/common/column-filter.pipe';
import { SafeHtmlPipe } from '../service/common/safeHtml.pipe';
import { OrderPipe, OrderModule } from 'ngx-order-pipe';
import { PopoverModule, TimepickerModule, CollapseModule, AlertModule, ModalModule, BsDropdownModule, CarouselModule, TabsModule, ProgressbarModule, PaginationModule, TooltipModule } from 'ngx-bootstrap';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';

var $ = require('jquery');
import { CalendarDatePipe } from 'angular-calendar/modules/common/calendar-date.pipe';
import { CalendarDayModule, CalendarModule, DateAdapter } from 'angular-calendar';
import { MyFilterPipe } from '../my-filter.pipe';
import { EmployeeComponent } from '../main/body/employee/employee.component';
import { LeftnavComponent } from '../main/body/leftnav/leftnav.component';
import { BodyComponent } from '../main/body/body.component';
import { HeaderComponent } from '../main/header/header.component';
import { FooterComponent } from '../main/footer/footer.component';
import { AppComponent } from '../app.component';
import { BrowserModule } from '@angular/platform-browser';
import { AutocompleteLibModule } from 'angular-ng-autocomplete';
import { FlatpickrModule } from 'angularx-flatpickr';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
//import { HttpModule } from '@angular/http';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { CanActivateGuard } from '../service/auth.guard.service';
import { HttpInterceptorService } from '../service/interceptor/http-interceptor.service';
import { of } from 'rxjs';


describe('CheckAuthComponent', () => {
  let component: CheckAuthComponent;
  let fixture: ComponentFixture<CheckAuthComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
    AppComponent,
    ErrorComponent,
    CheckAuthComponent,
    MainComponent,
    HeaderComponent,
    FooterComponent,
    BodyComponent,
    LeftnavComponent,
    DashboardComponent,
    CalendarComponent,
    RoleComponent,
    UserComponent,
    ValueStreamsComponent,
    ValueStreamsEditComponent,
    ValueStreamsLockComponent,
    AssessorComponent,
    AssessorEditComponent,
    AssessorLockComponent,
    DataPoolComponent,
    RecycleBinComponent,
    TagListComponent,
    TagEditComponent,
    QuestionsComponent,
    QuestionLockComponent,
    UserEditComponent,
    ProcessConfirmationComponent,
    AddEditRoleComponent,
    EmployeeComponent,
    MyFilterPipe,
    ShuffleModeComponent,
    CustomModeComponent,
    TagModeComponent,
    AuditComponent,
    TagLockComponent,
    DeviationComponent,
    DataPoolEditComponent,
   // ColumnFilterPipe,
    SafeHtmlPipe,
    TestComponent,
    AdminreportComponent,
    UserreportComponent,
    PlantComponent,
    SuperOPLComponent
        
      ],

      imports : [
        BrowserModule,
        AutocompleteLibModule,
        FlatpickrModule.forRoot(),
        TimepickerModule.forRoot(),
        FormsModule,
        ReactiveFormsModule,
        OrderModule,
        AppRoutingModule,
        NgMultiSelectDropDownModule.forRoot(),
        CollapseModule.forRoot(),
        AlertModule.forRoot(),
        ModalModule.forRoot(),
        BsDatepickerModule.forRoot(),
        BsDropdownModule.forRoot(),
        FormsModule,
        //HttpModule,
        CarouselModule.forRoot(),
        TabsModule.forRoot(),
        ProgressbarModule.forRoot(),
        PaginationModule.forRoot(),
        ToastrModule.forRoot(),
        PopoverModule.forRoot(),
        TooltipModule.forRoot(),
        NgxPaginationModule,
        BrowserAnimationsModule,
        HttpClientModule,
        CalendarModule.forRoot({
        provide: DateAdapter,
          useFactory: adapterFactory
        }),
        BsDatepickerModule.forRoot(),
        FlatpickrModule.forRoot(),
          ScrollingModule
      ],
      
      providers: [
        DatePipe, CanActivateGuard, CanActivateGuard, QuestionsComponent,    
        { provide: HTTP_INTERCEPTORS, useClass: HttpInterceptorService, multi: true }
      ],
      
      // schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA], 
      
    
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckAuthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('Check-Auth Login Success', () => {
    component.user.ntid ="JNK1COB";
    component.login();
    fixture.detectChanges();
  });

  // it('Check-Auth Login Failed', () => {
  //   component.user.ntid ="EGV1COB";
  //   fixture.detectChanges();
  //   component.login();
  // });


});
