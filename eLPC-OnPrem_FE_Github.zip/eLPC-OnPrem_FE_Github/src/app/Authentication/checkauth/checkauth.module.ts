import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CheckAuthComponent } from './check-auth/check-auth.component';
import { CheckauthRoutingModule } from './checkauth-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [CheckAuthComponent],
  imports: [
    CommonModule,
    CheckauthRoutingModule,
    FormsModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  exports: [CheckAuthComponent], 
})
export class CheckauthModule { }
