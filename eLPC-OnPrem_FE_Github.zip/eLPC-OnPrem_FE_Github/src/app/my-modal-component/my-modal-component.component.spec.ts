import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyModalComponentComponent } from './my-modal-component.component';

describe('MyModalComponentComponent', () => {
  let component: MyModalComponentComponent;
  let fixture: ComponentFixture<MyModalComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MyModalComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MyModalComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
