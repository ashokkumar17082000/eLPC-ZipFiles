import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
//import { SharedService } from "../service/shared.service";
import { SharedService } from "src/app/service/shared.service";
//import { CommonService } from "../service/common/common.service";
import { CommonService } from "src/app/service/common/common.service";
import { HttpClient } from "@angular/common/http";
//import { User } from "../main/body/shared/common";
import { User } from "src/app/main/body/shared/common";
import { environment } from "src/environments/environment";

@Component({
  selector: "app-check-auth",
  templateUrl: "./check-auth.component.html",
  styleUrls: ["./check-auth.component.css"]
})

export class CheckAuthComponent implements OnInit {
  userName: string;
  role: any;
  ntid: any;
  displayName: any;
  user: User = new User();
  isProd: any = environment.production;

  constructor(
    private _router: Router,
    private sharedService: SharedService,
    private commonService: CommonService,
    private http: HttpClient
  ){}

  ngOnInit() {
    //alert(1)
    debugger
    this.sharedService.show();
    let ntid = "";
    //For WAM
    //debugger;
    if (this.isProd == true || localStorage.getItem('ntid') != '<%Response.Write(Request.ServerVariables("http_iv_user"))%>') {
      ntid = localStorage.getItem('ntid');
      if (ntid) {
        this.user.ntid = ntid;
        this.login();
      }
      else {
        this.sharedService.hide();
        if (this.isProd == true) {
          //debugger;
          this.sharedService.errorMessage = "<h3>You are not authorized to access eLPC application</h3>"
          this._router.navigate([environment.home + '/appinfo']);
        }
      }
    }
    //without WAM
    else {
      this.sharedService.hide();
      if (this.isProd == true) {
        //debugger
        this.sharedService.errorMessage = "<h3>You are not authorized to access eLPC application</h3>"
        this._router.navigate([environment.home + '/appinfo']);
      }
    }
  }

  login() {
    debugger;
    console.log(this.user.ntid)
    this.sharedService.show();
    // var result = this.sharedService.login(this.user.ntid, this._router, environment.home + '/dashboard');
    var resultLogin = this.sharedService.GetEnironmentConfigFromDBAndLogin(this.user.ntid, this._router, environment.home + '/dashboard');
    {
      
      localStorage.setItem('ntid', this.user.ntid.toString().toUpperCase());
    //  this._router.navigate([environment.home + '/dashboard'])
    }
  }
}
