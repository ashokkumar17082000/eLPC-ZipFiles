import { User } from 'src/app/main/body/shared/common';
export class Deviation {
  deviationId: number;
  deviationDisplayId: number;
  valueStreamID: number = 0;
  deviationDescription: string;
  responsibleEmployee: string;
  questionID: number;
  questionDisplayID: number;
  createdBy_NTID: string;
  CreatedByEmployee: string;
  modifiedBy_NTID: string;
  deviationAttachmentID: number;
  managerEmailAddress: string;
  responsibleEmployeeEmailAddress: string;
  valueStreamName: string;
  userEmailAddress: string;
  deviationTypeID: number;
  questionText: string;
  questionChoiceAnswer: string;
  questionLinkedTags: string;
  responsibleEmpNTID: any;
  deviationAttachedImage?: any;
  hintImages?: HintImage[];
  owner: string;
 AdditionalEmployee: User[];
 AddItionalEmployeeNTID:any[];
 emp:any[];
  ownerNTID: string;
  createdBy_Name: string;
  pathUrl: string;
  additionalInfoyes:boolean;
  startDate: Date;
  endDate: Date;
  duedatecount:Date;
  auditAnsweredQuestionID: number;
  auditID?: number;
  // tagID?:number[]=[];
  // tagName?:any[]=[];
  selectedTagData?:any;
  //selectedTag?:number[]=[];
  auditTemplateID?: number;
  languageCode: string;
  superOPLURL: string;
  superOPLNewTaskURL: string;
  selectedtag:string;
}
export class Duedate {
  iD?: number;
  datecount:any;
}
export class Tag1{
  TagID?:number;
  FormattedTag?:string;
}
export class HintImage {
  iD?: number;
  questionID?: number;
  imageTitle?: string;
  imagePath?: string;
  fileContent?: any;
  byteData?: any;
  size?: number;
  deviationAttachmentsID?: number;
  displayFileName?: string;
}
