import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TestComponent } from './test/test.component';
import { TestmoduleRoutingModule } from './testmodule-routing.module';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [TestComponent],
  imports: [
    CommonModule,
    TestmoduleRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  
  schemas: [CUSTOM_ELEMENTS_SCHEMA] // Add this line
})
export class TestmoduleModule { }
