import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { SharedService } from "../../service/shared.service";
import { CommonService } from "../../service/common/common.service";
import { HttpClient } from "@angular/common/http";
import { User } from "../../main/body/shared/common";
import { environment } from "src/environments/environment";

@Component({
  selector: "test",
  templateUrl: "./test.component.html",
  styleUrls: ["./test.component.css"]
})
export class TestComponent implements OnInit {
  userName: string;
  role: any;
  ntid: any;
  displayName: any;
  user: User = new User();

  constructor(
    private _router: Router,
    private sharedService: SharedService,
    private commonService: CommonService,
    private http: HttpClient
  ) {
    //debugger;
    //this.http.get('https://rb-wam.bosch.com/elpc_q/elpc_q/valuestreams', { observe: 'response' }).subscribe(res => {

    //  console.log(res.headers);
    //},
    //  error => { console.log(error) }
    //);
    //let requestDetail = interceptor;
    //console.log(requestDetail);
    //const url = 'https://rb-wam.bosch.com/elpc_q/default.aspx';

    //javascript: void window.open("https://rb-wam.bosch.com/elpc_q/default.aspx", '','', false);
    //javascript: void window.open("http://localhost:4200")

    //const url = 'http://localhost:4200';
    // this.http
    //    .post<any>(url, { observe: 'response' })
    //   .subscribe(resp => {
    //     console.log(resp);
    //      console.log(resp.headers.get('iv-user'));
    //    }, error => console.error(error));

  }

  //for without WAM
  ngOnInit() {
    //debugger;
    this.sharedService.show();
    let ntid = localStorage.getItem('ntid');
    if (ntid) {
      this.user.ntid = ntid;
    }
    console.log(ntid);
    //if (ntid) {
    //  this.login();
    //}
    //this.http.get(environment.uiUrl, {}).subscribe(res => {
    //  this.user.ntid = res;
    //  this.sharedService.hide();
    //  //this.login();//added newly
    //},
    //  err => {
    //    console.error(err);
    this.sharedService.hide();
    //});
  }

  //for WAM
  //ngOnInit() {
  //  this.http.get(this.sharedService.uiApiUrl, {}).subscribe(res => {
  //    this.user.ntid = res;
  //  this.sharedService.show();
  //  this.user.ntid = localStorage.getItem('ntid');
  //  this.sharedService.CheckApplicationAccessByUserId(this.user.ntid).subscribe(res => {
  //    if (res.roleName != '') {
  //      this.sharedService.role = res.roleName;
  //      this.sharedService.ntid = res.ntid;
  //      this.sharedService.displayName = res.firstName + " " + res.lastName;
  //      this.sharedService.emailAddress = res.emailAddress;
  //      if (this.sharedService.role) {
  //        this._router.navigate([environment.home + '/dashboard']);
  //      }
  //    }
  //    else {
  //      alert("You are not authorized to access this application");
  //    }
  //    this.sharedService.hide();
  //  },
  //    err => {
  //      alert("You are not authorized to access this application");
  //      this.sharedService.hide();
  //    }
  //    );
  //},
  //     err => {
  //       console.error(err);
  //      // this.sharedService.hide();
  //     });
  // }

  //without WAM
  login() {
    this.sharedService.show();
    this.sharedService.CheckApplicationAccessByUserId(this.user.ntid).subscribe(res => {
      console.log(res);
      if (res.roleName != '') {
        this.sharedService.role = res.roleName;
        this.sharedService.ntid = res.ntid;
        localStorage.setItem("role", this.sharedService.role);
        this.sharedService.displayName = res.firstName + " " + res.lastName;
        this.sharedService.emailAddress = res.emailAddress;
        if (this.sharedService.role) {
          this._router.navigate([environment.home + '/dashboard']);
        }
      }
      else {
        debugger;
        alert("You are not authorized to access this application");
      }
      this.sharedService.hide();
    },
      err => {
        debugger;
        alert("You are not authorized to access this application");
        this.sharedService.hide();
      });
  }
}
