import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
//import { ProcessConfirmationComponent } from './process-confirmation/process-confirmation.component';
import { TagModeComponent } from './tag-mode/tag-mode.component';
//import { EmptyProcessconfirmationComponent } from './empty-processconfirmation/empty-processconfirmation.component';
const routes: Routes = [
  //processConfirmation
  //{ path: 'processConfirmation', component: ProcessConfirmationComponent },
  { path: '', component:TagModeComponent  },
  //{path:'',redirectTo:'tagMode',pathMatch:'full'},
  //{ path: '', component:EmptyProcessconfirmationComponent  }
  
  
  //tagMode
];
// const routes : Routes = [   { path : '' , component : TagModeComponent , // Ensure that this is the default component for the module 
//   children : [       { path : 'processConfirmation' , component : ProcessConfirmationComponent } ] } ];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProcessConfirmationmodeRoutingModule { }
