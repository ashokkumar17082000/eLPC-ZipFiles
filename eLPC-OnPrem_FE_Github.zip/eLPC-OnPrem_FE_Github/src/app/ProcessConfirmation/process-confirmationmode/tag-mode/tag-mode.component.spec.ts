import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TagModeComponent } from './tag-mode.component';

describe('TagModeComponent', () => {
  let component: TagModeComponent;
  let fixture: ComponentFixture<TagModeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TagModeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TagModeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
