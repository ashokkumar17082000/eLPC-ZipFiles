import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmptyProcessconfirmationComponent } from './empty-processconfirmation.component';

describe('EmptyProcessconfirmationComponent', () => {
  let component: EmptyProcessconfirmationComponent;
  let fixture: ComponentFixture<EmptyProcessconfirmationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmptyProcessconfirmationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmptyProcessconfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
