import { Component, OnInit, ViewChild, TemplateRef, ChangeDetectorRef } from '@angular/core';
import { SharedService } from 'src/app/service/shared.service';
import { User,UserDetails } from 'src/app/main/body/shared/common';
import { Tag } from 'src/app/Tag/tag/tag';
import  { RRule,Frequency, Weekday } from 'rrule';
import { ViewPeriod } from 'calendar-utils';
import moment from 'moment-timezone';
import {
  CalendarEventAction,
  CalendarEventTimesChangedEvent,
  CalendarView,
  CalendarEvent,
  CalendarMonthViewBeforeRenderEvent,
  CalendarWeekViewBeforeRenderEvent,
  CalendarDayViewBeforeRenderEvent
} from 'angular-calendar';
import {
  startOfDay,
  endOfDay,
  subDays,
  addDays,
  endOfMonth,
  isSameDay,
  isSameMonth,
  addHours
} from 'date-fns';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { Subject } from 'rxjs';
import { Audit, DayOfWeek, RecurrencePattern } from './calendar';
import { ValueStream,ValueStreamCategory  } from 'src/app/Valuestream/valuestreams/valuestreamtemplate';
import { ValuestreamTemplateService } from 'src/app/service/common/valuestreamtemplate.service';
import { TagService } from 'src/app/service/tag.service';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/service/common/common.service';
import { CalendarService } from 'src/app/service/calendar.service';
import { LanguageService } from 'src/app/language.service';
import { DatePipe } from '@angular/common';
import { environment } from 'src/environments/environment';
import { Question } from 'src/app/Datapool/QuestionModule/questions/question';
//import { ProcessConfirmationService } from '../../../service/common/process-confirmation.service';
import { ProcessConfirmationService } from 'src/app/service/common/process-confirmation.service';
import { ProcessConfirmation } from 'src/app/pc/process-confirmation/process-confirmation';
//import { ProcessConfirmation } from '../../../pc/process-confirmation/process-confirmation';
// import { forEach } from '@angular/router/src/utils/collection';
// import { moduleDef } from '@angular/core/src/view';
declare let $: any;

moment.tz.setDefault('Utc');



@Component({
  selector: 'app-calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.css']
})
export class CalendarComponent implements OnInit {

  bsModalRef: BsModalRef;
  modalRef: BsModalRef;
  @ViewChild('modalContent', {}) modalContent: TemplateRef<any>;

  view: CalendarView = CalendarView.Month;
  modalOpen = false;
  CalendarView = CalendarView;
  selectedEvent: any;
  closeResult: string;
  modalData: {
    action: string;
    event: CalendarEvent;
  };

  colors: any = {
    red: {
      primary: '#AD2121',
      secondary: '#FAE3E3'
    },
    grey: {
      primary: '#808080',
      secondary: '#b9b9b9'
    },
    green: {
      primary: '#21AD21',
      secondary: '#E3FAE3'
    },
    blue: {
      primary: '#1e90ff',
      secondary: '#D1E8FF'
    },
    yellow: {
      primary: '#e3bc08',
      secondary: '#FDF1BA'
    }
  };

  refresh: Subject<any> = new Subject();

  currentMonth: string;
  currentYear:string;
  currentDate: string;
  //for Tags selection
  availableTags: Tag[] = [];
  selectedTags: Tag[] = [];
  selectedTagIDs: string;
  tagList: Tag[] = [];
  tag: Tag = new Tag();

  //for Audits
  auditList: Audit[] = [];
  auditAnswerStatusList: Audit[] = [];
  tempAuditList: Audit[] = [];
  audit: Audit = new Audit();
  startTime: Date;
  endTime: Date;
  valueStreamList: ValueStream[] = [];
   role: string;
  ntid: string;
  isEdit: boolean;
  //questions: Question[];
  questions: ProcessConfirmation[] = [];

  //For multi select dropdown - Value stream
  dropdownSettingsValueStream = {};
  selectedItemValueStream: ValueStream[] = [];
  auditStartTime: Date;
  auditEndTime: Date;
  xDayOfWeek: DayOfWeek;
  typeAndDayOfWeekStr: string;
  selectedItemValueStreamCategories: any;
  valueStreams: any;
  selectedValueStreams: any;
  isAdd: any;
  unload=false;
  valueStreamCategories: ValueStreamCategory[] = [];
  processConfirmation: any;
  multiselectVSIds: number[]=[];
  valueStreamID?: number[] = [];
  selectedValueStream: ValueStream[]=[];
  
  constructor(private local_label: LanguageService, private cdr: ChangeDetectorRef, private modalService: BsModalService, private sharedService: SharedService, private tagService: TagService, private commonService: CommonService, private auditService: CalendarService,
    private valueStreamService: ValuestreamTemplateService,
    private processConfirmationService: ProcessConfirmationService,
    private router: Router, private datePipe: DatePipe) {
    if (this.sharedService.role) {
      this.role = this.sharedService.role;
    }
    if (this.sharedService.ntid) {
      this.ntid = this.sharedService.ntid;
    }
    //this.getAudits(this.viewDate);
    setTimeout(() => {
      if (this.sharedService.audit != undefined && this.sharedService.audit.auditID > 0) {
        this.auditService.audit = this.sharedService.audit;
        var tmpEvent: CalendarEvent[] = [];
        tmpEvent.push({
          id: this.sharedService.audit.auditID,
          start: new Date(this.sharedService.audit.startDate),
          end: new Date(this.sharedService.audit.endDate),
          title: this.sharedService.audit.tagDisplayName,
          color: this.sharedService.audit.tagTypeID === 1 ? this.colors.yellow : this.sharedService.audit.tagTypeID == 2 ? this.colors.green : this.colors.blue,
          actions: this.actions,
          allDay: false,
          resizable: {
            beforeStart: true,
            afterEnd: true
          },
          draggable: false,

        });
        this.handleEvent('Edited', tmpEvent[0], this.auditingTempModal);
      }
    }, 0);

    //this.recurringEvents = this.recurringEvents;
  }

  ngOnInit() {
    //this.sharedService.hide();
    this.audit = new Audit();
    this.audit.isRecurring = false;
    this.audit.recurrence_TypeId = 11;
    this.xDayOfWeek = new DayOfWeek();
    console.log("viewdate",this.viewDate)
   
    this.getAudits(this.viewDate)

  // Wait for language file to load before assigning labels
      this.local_label.changeLanguage(this.sharedService.selectedLanguage).then((data) => {
        this.labels = data;
        console.log("Loaded labels", this.labels);  // Ensure it's loaded
      }).catch((error) => {
        console.error('Language loading failed:', error);
      });
      
    //this.labels = this.local_label.localizeLanguage;

    this._subscription = this.local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
      this.locale = this.sharedService.selectedLanguage;
    });
    if (this.sharedService.role) {
      this.role = this.sharedService.role;
    }
    if (this.sharedService.ntid) {
      this.ntid = this.sharedService.ntid;
    }

    //For multi select dropdown - Assign tag to Value stream template
    this.dropdownSettingsValueStream = {
      singleSelection: false,
      idField: 'valueStreamID',
      textField: 'valueStreamName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 5,
      allowSearchFilter: true,
      closeDropDownOnSelection: true
    };

    this.auditStartTime = new Date();
    this.auditEndTime = this.auditStartTime;
    this.auditEndTime.setMinutes(this.auditStartTime.getMinutes() + 15);
  }

  //For multi select dropdown - Assign tag to Value stream template
  onSelectValueStream(item: ValueStream) {
    console.log(item);
    //this.multiselectVSIds=[];
    this.multiselectVSIds.push(item.valueStreamID);
  

    //this.audit.valueStreamIDs=this.multiselectVSIds;
    //console.log("audit",this.audit.valueStreamIDs);
    this.audit.valueStreamID=item.valueStreamID;
  }
 
  onDeSelectValueStream(item:ValueStream) {
    
    if (!this.selectedItemValueStream || this.selectedItemValueStream.length === 0)
    
    this.selectedItemValueStream=this.selectedValueStream.filter(x=>x.valueStreamID !== item.valueStreamID)
      //this.audit.valueStreamIDs = [];
      //console.log("deselect",this.audit.valueStreamIDs);
  }

  onValueStreamCategorySelectAll(item :ValueStream[]){
    //console.log(this.selectedValueStreams);
    //this.audit.valueStreamIDs=[];
    this.multiselectVSIds=[];
   for(let each of item){
     this.multiselectVSIds.push(each.valueStreamID)
   }
   this.audit.valueStreamIDs=this.multiselectVSIds;
   this.audit.valueStreamID=this.audit.valueStreamIDs[0];
   //console.log(this.multiselectVSIds)

  }

  onValueStreamCategoryDeSelectAll(item:ValueStream ){
    //this.audit.valueStreamID = item.valueStreamID;;
    //console.log(this.audit.valueStreamID);
    //this.audit.valueStreamIDs=[];
    this.multiselectVSIds=[];
    
  }

  valueStreamCategoryChange(valueStreamID: number) {
    //this.valueStreams = [];
   // alert(1)
     this.selectedValueStreams = [];
     const selectedItem = this.valueStreams.find(x => x.valueStreamID == valueStreamID);
     if(selectedItem === undefined){
       this.valueStreamService.getValueStreamsByCategoryID(valueStreamID).subscribe(res => {
         this.valueStreams.push(...res);
         //this.valueStreams = res;
         this.valueStreams = this.valueStreams.filter(x =>x.valueStreamName && x.responsible_UserID);
       },
         err => {
         });
     }
   }
  //onLoadValueStream() {
  //  this.selectedItemValueStream = [];
  //  if (!this.processConfirmation.valueStreamID || this.processConfirmation.valueStreamID === 0)
  //    return;
  //  const selectedItem = this.valueStreamList.find(x => x.valueStreamID === this.processConfirmation.valueStreamID);
  //  if (selectedItem)
  //    this.selectedItemValueStream.push(selectedItem);
  //}

  public closeAlertModal(isAudits: any = true) {
    if (document.getElementsByTagName("modal-container").length > 1) {
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1]);
    }
    else {
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if (document.getElementsByTagName("bs-modal-backdrop").length > 0) {
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }
    if (isAudits) {
      //this.getAudits(this.viewDate);
      //this.ngOnInit();
    }
  }

  getParsedDate(dte, tme) {
    try  {
       var datePart = dte.split("T")[0];
       var parts = datePart.split('-');
       var hours = 0;
       var mins = 0;
       if (tme != null) {
         hours = +tme.split(':')[0];
         mins = +tme.split(':')[1];
       }
       var parsedDate = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2], hours, mins));
       var result = parsedDate.getTime() + (parsedDate.getTimezoneOffset()*60000);
      //console.log("result " + new Date(result));
      return new Date(result);
    }
    catch
    {
      new Date();
    }
  }

  // standardUserNTID: string;

 public async getAudits(viewdate:Date) {
    'use strict';
    this.sharedService.show();
    //this.auditService.getAudits().subscribe(res =>{
    // if (this.role.toLocaleLowerCase() !== "designer") {
    //   this.standardUserNTID = this.ntid;
    // }
    // else {
    //   this.standardUserNTID = "designer"; //this is made empty in controller
    // }
    if (this.ntid == null) {
      this.ntid = this.sharedService.ntid;
    }
   
    console.log("view date inside",viewdate)
    var date : string = JSON.stringify(this.viewDate)
    var curryear: string = date.slice(1,5)
    var currmonth:string= date.slice(6,8)
    var currdate:string= date.slice(9,11)
    var ntID = this.ntid;
    this.currentMonth = currmonth;
    this.currentYear = curryear;
    this.currentDate = currdate;
    
    //console.log(" near servicecurrmonth",this.currentMonth)
    //console.log("curryear",this.currentYear)
    //console.log("currdate",this.currentDate)
    //console.log("this.view",this.viewDate)
    //console.log("date",this.currentDate,this.currentMonth,this.currentYear)
    let IsDesigner=0;
   //await this.auditService.GetAuditStatusByType("Calendar",currmonth,curryear,IsDesigner,ntID).subscribe(resultStatus => {
      this.auditAnswerStatusList = [];
     this.auditService.getAuditsByNTID(this.ntid,currmonth,curryear).subscribe(res => {
        this.auditList = res;
        this.auditAnswerStatusList = JSON.parse(JSON.stringify(this.auditList))


        //console.log(res);
        // console.log("This is a Start Time : ");
        // console.log(this.audit.startTime);
        // console.log("This is a End Time : ");
        // console.log(this.audit.endTime);
        // console.log("This is Start-End-Time from control");
        // console.log(this.auditStartTime);
        // console.log(this.auditEndTime);

        //this.getRRule(this.audit);

         //this.sharedService.hide();
        //filtering logic
        if (this.tagTypes.length > 0) {
          this.tempAuditList = [];
          for (let i of this.tagTypes) {
            let x = this.auditList.filter(x => x.tagTypeID === i);
            if (x.length > 0) {
              if (this.tempAuditList.length > 0) {
                for (let audit of x) {
                  this.tempAuditList.push(audit);
                }
              }
              else {
                this.tempAuditList = x;
              }
            }
          }
          this.auditList = [];
          this.auditList = this.tempAuditList;
        }

        this.events = [];
        this.auditList.forEach(x => {
          if (x.isRecurring) {
            this.getRRule(x).forEach(i => {
              //console.log("start and end time" + x.startTime + x.endTime);

              // let s = new Date(i);
              // s.setHours(+x.startTime.split(':')[0],+x.startTime.split(':')[1]);
              // let e = new Date(i);
              // e.setHours(+x.endTime.split(':')[0],+x.endTime.split(':')[1]);

              let s = this.getParsedDate(i.toISOString(), x.startTime);
              let e = this.getParsedDate(i.toISOString(), x.endTime);

              let startTime = this.getParsedDate(i.toISOString(), "00:00");

              this.events.push({
                id: x.auditID,
                start: s,
                end: e,
                title: x.tagDisplayName,
                color: this.GetStatusColor(x.auditID, x.tagTypeID, startTime),
                actions: this.actions,
                allDay: x.isAllDay,
                resizable: {
                  beforeStart: true,
                  afterEnd: true
                },
                draggable: false,
              });
            })
          }
          else {
            // let s2 = new Date(x.startDate);
            // s2.setHours(+x.startTime.split(':')[0], +x.startTime.split(':')[1]);
            // let e2 = new Date(x.endDate);
            //   e2.setHours(+x.endTime.split(':')[0],+x.endTime.split(':')[1]);

            let s2 = this.getParsedDate(x.startDate, x.startTime);
            //x.startDate = s2;
            let e2 = this.getParsedDate(x.endDate, x.endTime);
            //x.endDate = e2;

            this.events.push({
              id: x.auditID,
              start: s2,
              end: e2,
              title: x.tagDisplayName,
              color: this.GetStatusColor(x.auditID, x.tagTypeID, x.startDate),
              actions: this.actions,
              allDay: x.isAllDay,
              resizable: {
                beforeStart: true,
                afterEnd: true
              },
              draggable: false,

            } as CalendarEvent);
          }


        });
        this.sharedService.hide();
       
        //   this.tagList = res;
        //   this.availableTags = this.tagList;
        //   if (this.selectedTags) {
        //     this.availableTags = this.availableTags.filter(x => x.tagID !== this.audit.tagID);
        //   }
        //   this.valueStreamService.getValueStream().subscribe(res => {
        //     this.valueStreamList = res;
        //     //this.valueStreamList = this.valueStreamList.filter(x => x.valueStreamData && x.responsible_UserID);
        //     this.valueStreamList = this.valueStreamList.filter(x => x.valueStreamName);
        //     this.sharedService.hide();

        //   }, err => console.error(err));

        // },
        //   err => {
        //     console.log(err);
        //   }
        // );
      },
        err => console.error(err));
        //this.sharedService.hide();
    //});
  }

  getRecurrence(audit: Audit): Date[] {
    if (!audit || audit.isAllDay || !audit.isRecurring)
      return [];
    //const r: RecurringEvent = [];
    const _byweekday: Weekday[] = [];
    let _freq: Frequency;
    //r.rrule = {};

    //console.log("this is in getRecurrence");
    //console.log(audit.recurrence_TypeId);

    if (audit.recurrence_TypeId >= 11 && audit.recurrence_TypeId <= 20)
      _freq = Frequency.DAILY;
    else if (audit.recurrence_TypeId >= 21 && audit.recurrence_TypeId <= 30)
      _freq = Frequency.WEEKLY;
    else if (audit.recurrence_TypeId >= 31 && audit.recurrence_TypeId <= 40)
      _freq = Frequency.MONTHLY;
    else if (audit.recurrence_TypeId >= 41 && audit.recurrence_TypeId <= 50)
      _freq = Frequency.YEARLY;

    //console.log(_freq);

    if (audit && audit.recurrence_DayOfWeek && audit.recurrence_DayOfWeek != "0,0,0,0,0,0,0") {
      const d = audit.recurrence_DayOfWeek.split(",");
      for (let i = 0; i < d.length; i++) {
        if (d[i] === "0")
          continue;
        switch (i) {
          case 0:
            _byweekday.push(RRule.SU);
            break;
          case 1:
            _byweekday.push(RRule.MO);
            break;
          case 2:
            _byweekday.push(RRule.TU);
            break;
          case 3:
            _byweekday.push(RRule.WE);
            break;
          case 4:
            _byweekday.push(RRule.TH);
            break;
          case 5:
            _byweekday.push(RRule.FR);
            break;
          case 6:
            _byweekday.push(RRule.SA);
            break;
        }
      }
    }

    //let rule = new RRule({
    //  freq: _freq,
    //  dtstart: new Date(audit.startDate),
    //  until: new Date(audit.endDate),
    //  interval: audit.recurrence_Interval,
    //  byweekday: audit.recurrence_DayOfWeek && audit.recurrence_DayOfWeek !== "0,0,0,0,0,0,0" ? _byweekday : null,
    //  bymonthday: audit.recurrence_DayOfMonth && audit.recurrence_DayOfMonth > 0 ? audit.recurrence_DayOfMonth : ((audit.recurrence_TypeId === 31 || audit.recurrence_TypeId === 32) && audit.recurrence_WeekOfMonth ? +audit.recurrence_WeekOfMonth : null),
    //  bysetpos: audit.recurrence_TypeId !== 31 && audit.recurrence_TypeId !== 32 && audit.recurrence_WeekOfMonth ? audit.recurrence_WeekOfMonth : null,
    //  bymonth: audit.recurrence_MonthOfYear ? audit.recurrence_MonthOfYear : null
    //});

    audit.recurrence_WeekOfMonth = +audit.recurrence_WeekOfMonth;
    audit.recurrence_MonthOfYear = +audit.recurrence_MonthOfYear;
    let rule = new RRule({
      freq: _freq,
      dtstart: new Date(audit.startDate),
      until: new Date(audit.endDate),
      interval: audit.recurrence_Interval,
      byweekday: audit.recurrence_DayOfWeek && audit.recurrence_DayOfWeek !== "0,0,0,0,0,0,0" ? _byweekday : null,
      bymonthday: audit.recurrence_DayOfMonth && audit.recurrence_DayOfMonth > 0 ? audit.recurrence_DayOfMonth : null,
      bysetpos: audit.recurrence_WeekOfMonth ? audit.recurrence_WeekOfMonth : null,
      bymonth: audit.recurrence_MonthOfYear ? audit.recurrence_MonthOfYear : null,
      wkst: RRule.SU // Weekday.fromStr("SU")
    });
    //let rule = new RRule({
    //  freq: RRule.MONTHLY,
    //  dtstart: new Date(Date.UTC(2021, 5, 2, 11, 15, 0)),
    //  until: new Date(Date.UTC(2021, 5, 30, 11, 15, 0)),
    //  count: 10,
    //  interval: 1,
    //  wkst: RRule.SU,
    //  byweekday: [RRule.MO, RRule.TU, RRule.WE, RRule.TH, RRule.FR, RRule.SA, RRule.SU],
    //  bysetpos: -1
    //})
    //console.log(`total occurances - ${rule.all().length}. start - ${rule.all().length > 0 ? rule.all()[0] : 'NA'}. End - ${rule.all().length > 0 ? rule.all()[rule.all().length - 1] : 'NA'}`);
    //console.log(`total occurances - ${rule.all().length}`)
    //rule.all().forEach(x => console.log(x));
    return rule.all();
  }

  getRRule(audit:Audit) : Date[] {
    if (!audit || audit.isAllDay || !audit.isRecurring)
      return [];

    // console.log("This is in RRule");
    // console.log(audit);
    //const r: RecurringEvent = [];
    const _byweekday: Weekday[] = [];
    let _freq: Frequency;
    //r.rrule = {};
    if (audit.recurrence_TypeId >= 11 && audit.recurrence_TypeId <= 20)
      _freq = Frequency.DAILY;
    else if (audit.recurrence_TypeId >= 21 && audit.recurrence_TypeId <= 30)
      _freq = Frequency.WEEKLY;
    else if (audit.recurrence_TypeId >= 31 && audit.recurrence_TypeId <= 40)
      _freq = Frequency.MONTHLY;
    else if (audit.recurrence_TypeId >= 41 && audit.recurrence_TypeId <= 50)
      _freq = Frequency.YEARLY;

    if (audit && audit.recurrence_DayOfWeek && audit.recurrence_DayOfWeek != "0,0,0,0,0,0,0") {
      const d = audit.recurrence_DayOfWeek.split(",");
      for (let i = 0; i < d.length; i++) {
        if (d[i] === "0")
          continue;
        switch (i) {
          case 0:
            _byweekday.push(RRule.SU);
            break;
          case 1:
            _byweekday.push(RRule.MO);
            break;
          case 2:
            _byweekday.push(RRule.TU);
            break;
          case 3:
            _byweekday.push(RRule.WE);
            break;
          case 4:
            _byweekday.push(RRule.TH);
            break;
          case 5:
            _byweekday.push(RRule.FR);
            break;
          case 6:
            _byweekday.push(RRule.SA);
            break;
        }
      }
    }
    audit.recurrence_WeekOfMonth = +audit.recurrence_WeekOfMonth;


    //console.log("Frequency : " +_freq+" auditID : " + audit.auditID);
    // console.log(audit.recurrence_TypeId);
    // console.log(audit);
    // console.log(audit.startDate);


    let s = new Date(audit.startDate);
    // console.log(s);
    // console.log(s.getMonth());

    s = new Date(Date.UTC(s.getFullYear(),s.getMonth(),s.getDate()));

    // console.log(s);


    let e = new Date(audit.endDate);
    // console.log(e);
    e = new Date(Date.UTC(e.getFullYear(),e.getMonth(),e.getDate()));
    // console.log(e);


    let rule = new RRule({
      freq: _freq,
      dtstart: s,
      until: e,
      interval: audit.recurrence_Interval,
      byweekday: audit.recurrence_DayOfWeek && audit.recurrence_DayOfWeek !== "0,0,0,0,0,0,0" ? _byweekday : null,
      bymonthday: audit.recurrence_DayOfMonth && audit.recurrence_DayOfMonth > 0 ? audit.recurrence_DayOfMonth : null,
      bysetpos: audit.recurrence_WeekOfMonth ? audit.recurrence_WeekOfMonth : null,
      bymonth: audit.recurrence_MonthOfYear ? audit.recurrence_MonthOfYear : null,
      wkst: Weekday.fromStr("SU")
    });

    //console.log(`total occurances - ${rule.all().length}. start - ${rule.all().length > 0 ? rule.all()[0] : 'NA'}. End - ${rule.all().length > 0 ? rule.all()[rule.all().length - 1] : 'NA'}`);
    //console.log(`total occurances - ${rule.all().length}`)
    //rule.all().forEach(x => console.log(x));
    // console.log('this is a rule....' + rule);
    //console.log(
    return rule.all();
  }


  actions: CalendarEventAction[] = [
    {
      label: '<i class="far fa-fw fa-copy"></i>',
      onClick: ({ event }: { event: CalendarEvent }): void => {

        this.copyToClipBoard(event.id.toString());
        //this.handleEvent('Edited', event, 'auditingTemp');
      }
    },
    {
      label: '<i class="fa fa-fw fa-times"></i>',
      onClick: ({ event }: { event: CalendarEvent }): void => {
        this.handleEvent('Deleted', event, 'auditingTemp');
      }
    }
  ];


  copyToClipBoard(text) {
    var plainText = { "plant": this.sharedService.plantID, "id": text };
    var encString = this.sharedService.encrypt(JSON.stringify(plainText));
    var url = environment.uiUrl + environment.home + '/calendar;auditid=' + encString;
    var input = document.createElement('textarea');
    input.innerHTML = url;
    document.body.appendChild(input);
    input.select();
    input.setSelectionRange(0, 99999);
    document.execCommand('copy');
    document.body.removeChild(input);
  }

  events: CalendarEvent[];
  activeDayIsOpen: boolean = true;


  dayClicked({ date, events }: { date: Date; events: CalendarEvent[] }): void {    
    
    if (isSameMonth(date, this.viewDate)) {
      if (
        (isSameDay(this.viewDate, date) && this.activeDayIsOpen === true) ||
        events.length === 0
      ) {
        this.activeDayIsOpen = false;
      } else {
        this.activeDayIsOpen = true;
      }
      this.viewDate = date;
    }
  }

  eventTimesChanged({
    event,
    newStart,
    newEnd
  }: CalendarEventTimesChangedEvent): void {
      this.events = this.events.map(iEvent => {
      if (iEvent === event) {
        return {
          ...event,
          start: newStart,
          end: newEnd
        };
      }
      return iEvent;
    });
    this.handleEvent('Dropped or resized', event, 'auditingTemp');
  }

  roundTimeQuarterHour = (minutes, d = new Date()) => {
    var timeToReturn = d;
    timeToReturn.setMilliseconds(Math.round(timeToReturn.getMilliseconds() / 1000) * 1000);
    timeToReturn.setSeconds(Math.round(timeToReturn.getSeconds() / 60) * 60);
    timeToReturn.setMinutes((timeToReturn.getMinutes() == 0) ? minutes : Math.ceil(timeToReturn.getMinutes() / minutes) * minutes);
    return timeToReturn;
  }

  // ---for audit start
  handleEvent(action: string, event: CalendarEvent, auditingTemp, date?: Date): void {
  
    //console.log("733",action)
    //console.log("734",event)
    //console.log("735",date)
    //console.log("736",auditingTemp)
    //console.log("742",this.viewDate)
    //console.log("744",event.start);
    this.modalData = { event, action };
    let auditID = event.id as number;

    this.auditService.auditByAuditID(auditID).subscribe(res => {
      this.audit = new Audit();
      this.audit = res;
      console.log("752",this.audit)
      this.getTagandValuestreamData()
      //console.log(this.audit);
      //console.log(this.audit.recurrence_TypeId);

      this.audit.startDate = this.getParsedDate(this.audit.startDate, null); //new Date(this.audit.startDate);
      this.audit.endDate = this.getParsedDate(this.audit.endDate, null);//new Date(this.audit.endDate);
      this.auditStartTime = this.convertTimeToDateTime(this.audit.startTime);
      this.auditEndTime = this.convertTimeToDateTime(this.audit.endTime);
      this.selectedEvent = event;

      this.setDayOfWeek(`${this.audit.recurrence_TypeId}-${this.audit.recurrence_DayOfWeek}`);

      if (action != 'Deleted') {
        this.open(auditingTemp);
      }
      else {
        this.showDeleteModal();
      }
    })
  }

  showDeleteModal(modalOpen = false) {
    this.modalOpen = modalOpen;

    if (modalOpen == true) {
      this.closeAlertModal();
    }
    this.alertText = this.labels.default.warningDelete;
    this.modalRef2 = this.modalService.show(this.deleteModal, { class: 'second' });
    $("modal-container").removeClass("fade");
    $(".modal-dialog").addClass("modalSize");
  }

  closeDeleteModal() {
    this.closeAlertModal();

    if (this.modalOpen == true) {
      this.open(this.auditingTempModal);
    }
  }

  closeAuditModal() {
    document.querySelector('body').classList.remove('modal-open');
  }

  deleteTemplate() {
    this.audit.modifiedBy_NTID = this.sharedService.ntid;
    this.DeleteTag(this.audit);
  }

  DeleteTag(audit) {
    var event = this.selectedEvent;
    this.auditService.DeleteAudit(audit).subscribe(res => {
      this.events = this.events.filter(iEvent => iEvent !== event);
      this.closeAlertModal();
    });

  }
  //addEvent(): void {

  //  this.events = [
  //    ...this.events,
  //    {
  //      title: 'New event',
  //      start: startOfDay(new Date()),
  //      end: endOfDay(new Date()),
  //      color: this.colors.red,
  //      draggable: false,
  //      resizable: {
  //        beforeStart: true,
  //        afterEnd: true
  //      }
  //    }
  //  ];
  //}

  //deleteEvent(eventToDelete: CalendarEvent) {
  //  this.events = this.events.filter(event => event !== eventToDelete);
  //}

  setView(view: CalendarView) {
    this.view = view;
    //console.log("830",this.view)
    this.getAudits(this.viewDate)
  }

  closeOpenMonthViewDay() {
    this.activeDayIsOpen = false;
    console.log("view",this.viewDate)
    this.getAudits(this.viewDate)
  }
  currrentViewDay() {
    this.activeDayIsOpen = false;
    this.viewDate = moment().toDate();
    console.log("view",this.viewDate)
    this.getAudits(this.viewDate)
  }

  //------------modal for Audit start
  auditingModal(auditingTemp, event) {
    this.open(auditingTemp);
  }

  cancelAudit() {
    this.audit = new Audit();
    this.requiredAttendees = [];
    this.optionalAttendees = [];
    this.closeAlertModal();
  }
    getTagandValuestreamData(){
      this.tagService.getTagModeTagsCalendar().subscribe(res => {
        this.tagList = res;
        this.availableTags = this.tagList;
        // if (this.selectedTags) {
        //   this.availableTags = this.availableTags.filter(x => x.tagID !== this.audit.tagID);
        // }
        this.valueStreamService.getValueStream().subscribe(res => {
          this.valueStreamList = res;
          //this.valueStreamList = this.valueStreamList.filter(x => x.valueStreamData && x.responsible_UserID);
          this.valueStreamList = this.valueStreamList.filter(x => x.valueStreamName);
          this.sharedService.hide();

        }, err => console.error(err));

      },
        err => {
          console.log(err);
        }
      );
    }
  //----------modal pop up for Audit Creation
  auditModal(auditTemplate) {
   // alert(1)
   this.getTagandValuestreamData()
    this.isEdit = false;
    if (!this.audit) {
      this.audit = new Audit();
      this.audit.isRecurring = false;
    }
    else {
      if (!this.isEdit) {

        this.audit = new Audit();
        this.selectedTags = [];
        this.selectedItemValueStream = [];
        this.requiredAttendees = [];
        this.optionalAttendees = [];

        var d = new Date();
        this.audit.startDate = new Date(d.getFullYear(), d.getMonth(), d.getDate());
       
        this.audit.endDate = new Date(d.getFullYear(), d.getMonth(), d.getDate());
        this.auditStartTime = this.roundTimeQuarterHour(15);
        this.auditEndTime = new Date(new Date(this.auditStartTime).setMinutes(this.auditStartTime.getMinutes() + 15));
        this.audit.isRecurring = false;
      }
      this.open(auditTemplate);
    }
  }
  
  resetRecurrence() {
    if (this.audit.isAllDay) {
      this.audit.isRecurring = false;
      this.audit.recurrence_TypeId = 11;
    }
    this.audit.recurrence_Interval = 0;
    this.audit.recurrence_DayOfWeek = '0,0,0,0,0,0,0';
    this.audit.recurrence_MonthOfYear = 0;
    this.audit.recurrence_DayOfMonth = 0;
    this.audit.recurrence_WeekOfMonth = 0;
    this.xDayOfWeek = new DayOfWeek();

  }
  resolveAuditRecurrenceValues() {
    if (this.audit.isAllDay) {
      this.audit.recurrence_Interval = 0;
      this.audit.recurrence_DayOfMonth = 0;
      this.audit.recurrence_WeekOfMonth = 0;
      this.audit.recurrence_MonthOfYear = 0;
      this.xDayOfWeek = new DayOfWeek();
    } else if (this.audit.recurrence_TypeId >= 11 && this.audit.recurrence_TypeId <= 20) {
      this.audit.recurrence_DayOfMonth = 0;
      this.audit.recurrence_WeekOfMonth = 0;
      this.audit.recurrence_MonthOfYear = 0;
      this.xDayOfWeek = new DayOfWeek();
    } else if (this.audit.recurrence_TypeId >= 21 && this.audit.recurrence_TypeId <= 30) {
      this.audit.recurrence_DayOfMonth = 0;
      this.audit.recurrence_WeekOfMonth = 0;
      this.audit.recurrence_MonthOfYear = 0;
    } else if (this.audit.recurrence_TypeId >= 31 && this.audit.recurrence_TypeId <= 40) {
      if (this.audit.recurrence_TypeId === 31) {
        this.xDayOfWeek = new DayOfWeek();
        this.audit.recurrence_WeekOfMonth = 0;
      }
      else {
        this.audit.recurrence_DayOfMonth = 0;
      }
      this.audit.recurrence_MonthOfYear = 0;

    } else if (this.audit.recurrence_TypeId >= 41 && this.audit.recurrence_TypeId <= 50) {
      if (this.audit.recurrence_TypeId === 41) {
        this.xDayOfWeek = new DayOfWeek();
        this.audit.recurrence_WeekOfMonth = 0;
      } else {
        this.audit.recurrence_DayOfMonth = 0;
      }
    }

    //this.auditStartTime = this.convertTimeToDateTime("00:00:00");
    //this.auditEndTime = this.convertTimeToDateTime("23:59:59");

    //this.resetRecurrence();
  }

  validateAuditRecurrenceValues(): string {
    if (!this.audit.isRecurring || this.audit.isAllDay)
      return "";
    if (isNaN(this.audit.recurrence_Interval) || +this.audit.recurrence_Interval < 1) {
      return this.labels.default.InvalidRecurrenceInterval;
    } else if (this.audit.recurrence_TypeId >= 21 && +this.audit.recurrence_TypeId <= 30 && this.dayOfWeekToString() === "0,0,0,0,0,0,0") {
      return this.labels.default.SelectAtLeastOneDay;
    } else if (this.audit.recurrence_TypeId === 31 && (+this.audit.recurrence_DayOfMonth < 1 || +this.audit.recurrence_DayOfMonth > 31)) {
      return this.labels.default.InvalidDayOfMonth;
    } else if (this.audit.recurrence_TypeId > 31 && this.audit.recurrence_TypeId <= 40) {
      if (![-1, 1, 2, 3, 4].some(x => x === +this.audit.recurrence_WeekOfMonth))
        return this.labels.default.InvalidDayOfWeek;
      else if (this.dayOfWeekToString() === "0,0,0,0,0,0,0")
        return this.labels.default.NoneSelectedInMonthDay;
    } else if (this.audit.recurrence_TypeId === 41) {
      if (!+this.audit.recurrence_MonthOfYear)
        return this.labels.default.MonthNotSelected;
      else if (+this.audit.recurrence_DayOfMonth < 1 || +this.audit.recurrence_DayOfMonth > 31)
        return this.labels.default.InvalidDayOfMonth;
    } else if (+this.audit.recurrence_TypeId > 41 && +this.audit.recurrence_TypeId <= 50) {
      if (![-1, 1, 2, 3, 4].some(x => x === +this.audit.recurrence_WeekOfMonth))
        return this.labels.default.InvalidDayOfWeek;
      else if(this.dayOfWeekToString() === "0,0,0,0,0,0,0")
        return this.labels.default.NoneSelectedInMonthDay;
      else if (!+this.audit.recurrence_MonthOfYear)
        return this.labels.default.MonthNotSelected;
    }

  }

  isAllDayClicked() {
    this.audit.isRecurring = !this.audit.isAllDay;
    this.audit.recurrence_TypeId = 11;
    //this.resetRecurrence();
  }

  editAudit(auditTemplate, event) {
    this.closeAlertModal();
    this.isEdit = true;
    this.selectedItemValueStream = [];
   for(let i=0;i<this.audit.valueStreamNames.length;i++){
    let vs = new ValueStream();
    vs.valueStreamName = this.audit.valueStreamNames[i];
    vs.valueStreamID = this.audit.valueStreamIDs[i];
    //this.selectedItemValueStream = [];
    this.selectedItemValueStream.push(vs);
  }

    this.audit.startDate = new Date(this.audit.startDate);
    this.audit.endDate = new Date(this.audit.endDate);

    this.auditStartTime = this.convertTimeToDateTime(this.audit.startTime);
    this.auditEndTime = this.convertTimeToDateTime(this.audit.endTime);

    // To display weekly Data in Audit Edit page

    //console.log(this.audit);
    //console.log(this.audit.recurrence_TypeId);

    if (this.audit.recurrence_DayOfWeek && this.audit.recurrence_DayOfWeek !== "0,0,0,0,0,0,0" && this.audit.recurrence_DayOfWeek.split(',').length === 7) {
      this.typeAndDayOfWeekStr = `${this.audit.recurrence_TypeId}-${this.audit.recurrence_DayOfWeek}`;
      this.setDayOfWeek(this.typeAndDayOfWeekStr);
      //let d = this.audit.recurrence_DayOfWeek.split(',');
      //this.xDayOfWeek = new DayOfWeek(d[0] === "1", d[1] === "1", d[2] === "1", d[3] === "1", d[4] === "1", d[5] === "1", d[6] === "1");
    }

    //for (let i = 0; i < d.length; i++) {
    //  if (d[i] === "1") {
    //    this.setDayOfWeek(`${this.audit.recurrence_TypeId},${i}`);
    //  }
    //}

    this.updateAudit(auditTemplate);
  }


  async updateAudit(auditTemplate: any) {
    if (this.audit.tagID && this.availableTags && this.availableTags.length > 0) {

      if (this.availableTags.filter(x => x.tagID == this.audit.tagID).length > 0) {
        this.selectedTags = [];
        this.selectedTags.push(this.availableTags.filter(x => x.tagID == this.audit.tagID)[0]!);
      }

      this.availableTags = this.availableTags.filter(x => x.tagID !== this.audit.tagID);

    }

    this.auditService.requiredAttendeesByAuditID(this.audit.auditID).subscribe(res => {
      this.requiredAttendees = res;

      for (let user of this.requiredAttendees) {
        if (user.emailAddress == null || user.emailAddress == "") {
          this.sharedService.GetApplicationAccessByUserId(user.ntid).subscribe(resAD => {
            if (resAD != null && resAD[0] != null) {
              user = this.BindUserDetails(user, resAD);
            }
          });
        }
      }
      
      this.auditService.optionalAttendeesByAuditID(this.audit.auditID).subscribe(res => {
        this.optionalAttendees = res;
        
        for (let user of this.optionalAttendees) {
          if (user.emailAddress == null || user.emailAddress == "") {
            this.sharedService.GetApplicationAccessByUserId(user.ntid).subscribe(resAD => {
              if (resAD != null && resAD[0] != null) {
                user = this.BindUserDetails(user, resAD);
              }
            });
          }
        }
        this.open(auditTemplate);
      },
        error => console.error(error));
    }, error => console.error(error));

    //this.auditService.requiredAttendeesByAuditID(this.audit.auditID).subscribe(res => {
    //  this.requiredAttendees = res;
    //  this.auditService.optionalAttendeesByAuditID(this.audit.auditID).subscribe(res => {
    //    this.optionalAttendees = res;
    //    this.open(auditTemplate);
    //  },
    //    error => console.error(error));
    //}, error => console.error(error));

  }

  BindUserDetails(user: User, resAD: UserDetails) {
    user.emailAddress = resAD[0].emailAddress;
    user.userName = resAD[0].userName;
    user.firstName = resAD[0].firstName;
    user.lastName = resAD[0].lastName;
    return user;
  }

  public getTagList() {
    this.tagService.getTagModeTags().subscribe(res => {
      this.tagList = res;
      this.availableTags = this.tagList;
      if (this.selectedTags) {
        this.availableTags = this.availableTags.filter(x => x.tagID !== this.audit.tagID);
      }
      this.valueStreamService.getValueStream().subscribe(res => {
        this.valueStreamList = res;
        //this.valueStreamList = this.valueStreamList.filter(x => x.valueStreamData && x.responsible_UserID);
        this.valueStreamList = this.valueStreamList.filter(x => x.valueStreamName);
        
      }, err => console.error(err));
      this.sharedService.hide();
    },
      err => {
        console.log(err);
        this.sharedService.hide();
      }
  
    );
  }


  public tagSelected(tag: Tag) {
    if (tag.tagID) { //to validate if any questions is linked with the tag && removes the old tag
      //this.tagService.getQuestionsByTagID(tag.tagID).subscribe(res => {
      this.processConfirmationService.getProcessConfirmation('tag', 0, 0, 'null', tag.tagID, 0, null).subscribe(res => {

        this.questions = res;
        if (!this.questions || (this.questions && this.questions.length < 1)) {
          this.alertText = this.labels.default.tagHasNoQuestions;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          return;
        }

        else {
          if (this.selectedTags == undefined) {
            this.selectedTags = [];
          }
          if (tag) {
            if (this.selectedTags.length > 0) {
              this.removeTag(this.selectedTags[0]);
            }

            this.selectedTags = [];
            this.selectedTags.push(tag);
            this.availableTags = this.availableTags.filter(x => x.tagID !== tag.tagID);

            this.auditService.valueStreamsByTagID(this.selectedTags[0].tagID).subscribe(res => {
              this.valueStreamList = res;
              this.audit.valueStreamID = 0;
              this.selectedItemValueStream = [];
            }, err => console.error(err));
          }
        }
      })
    }


  }

  searchTag() {

    let text = this.tag.searchText;
    this.availableTags = [];
    if (text) {
      text = text.toLowerCase();
    }
    if (this.tagList.length > 0) {
      let filteredTags = this.tagList.filter(x => x.tagName.toLowerCase().indexOf(text) > -1);
      for (let tg of filteredTags) {
        let x = this.selectedTags.filter(x => x.tagID == tg.tagID);
        if (x.length < 1) {
          this.availableTags.push(tg);
        }
      }
    }
  }

  filterTagOrQuestion() {

    let text = this.tag.filterText;
  }

  removeTag(tag: Tag) {

    if (tag !== undefined && Object.keys(tag).length !== 0) {
      let id = tag.tagID;
      this.selectedTags = this.selectedTags.filter(x => x.tagID !== id);
      this.availableTags.push(tag);
      this.valueStreamList = [];
    };

  }

  data: any;
  optionalAttendee: any;
  optionalAttendees: User[] = [];
  requiredAttendee: any;
  requiredAttendees: User[] = [];

  onOptionalAttendeeSearch() {

    let user = new User();
    user.firstName = this.optionalAttendee;
    user.isGroupNameRequired = true;
    this.commonService.activeDirectoryByName(user).subscribe(res => {
      this.data = [];
      this.data = res;
    },
      err => console.error(err));
  }

  selectOptionalAttendee(user: any) {
    if (user !== null) {
      let x = this.optionalAttendees.filter(x => x.ntid == user.ntid);
      if (x.length == 0)
        this.optionalAttendees.push(user);
    }


    this.data = [];
    this.optionalAttendee = undefined;
  }

  onRequiredAttendeeSearch(val: any) {
  
    let user = new User();
    user.firstName = this.requiredAttendee;
    user.isGroupNameRequired = true;
    this.commonService.activeDirectoryByName(user).subscribe(res => {
      this.data = [];
      this.data = res;
    },
      err => console.error(err));
  }

  selectRequiredAttendee(user: any) {

    if (user !== null) {
      let x = this.requiredAttendees.filter(x => x.ntid == user.ntid);
      if (x.length == 0)
        this.requiredAttendees.push(user);
    }


    this.data = [];
    this.requiredAttendee = undefined;
  }

  removeOptionalAttendee(user: any) {

    this.optionalAttendees = this.optionalAttendees.filter(x => x.ntid !== user.ntid);
  }
  removeRequiredAttendee(user: any) {

    this.requiredAttendees = this.requiredAttendees.filter(x => x.ntid !== user.ntid);
  }
  //-===============

  formatAMPM(date) {
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var ampm = hours >= 12 ? 'pm' : 'am';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? '0' + minutes : minutes;
    var strTime = hours + ':' + minutes + ' ' + ampm;
    return strTime;
  }

  //startDate: Date;
  //endDate: Date;
  displayStartDate: any;
  displayEndDate: any;

  labels: any;
  _subscription: any;

  //========for audit
  alertText;
  @ViewChild('alertPopup') warningModal: TemplateRef<any>;
  @ViewChild('successPopup') successModal: TemplateRef<any>;
  @ViewChild('popTemplate') filterModal: TemplateRef<any>;
  @ViewChild('deletePopup') deleteModal: TemplateRef<any>;
  @ViewChild('auditingTemp') auditingTempModal: TemplateRef<any>;

  modalRef2: BsModalRef;

  tempStartDate: any[];
  tempEndDate: any[];

  save(audit: Audit, template: any) {
    
    //this.tempStartDate = audit.startDate.toString().split('-');
    //this.tempEndDate = audit.endDate.toString().split('-');

    if (!audit.startDate) {
      this.alertText = this.labels.default.selectStartDate;
      this.modalRef2 = this.modalService.show(template, { class: 'second' });
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      return;
    }

    if (!audit.endDate) {
      this.alertText = this.labels.default.selectEndDate;
      this.modalRef2 = this.modalService.show(template, { class: 'second' });
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      return;
    }

    if (audit.startDate > audit.endDate) {
      this.alertText = "End date should be equal to or greater than start date";
      this.modalRef2 = this.modalService.show(template, { class: 'second' });
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      return;
    }

    if (!audit.isAllDay && this.auditEndTime <= this.auditStartTime && ((audit.startDate.getTime() === audit.endDate.getTime()) || (audit.startDate.getTime() < audit.endDate.getTime() && audit.isRecurring))) {
      this.alertText = "End time should be greater than start time";
      this.modalRef2 = this.modalService.show(template, { class: 'second' });
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      return;
    }

    var onlyFromTime = this.datePipe.transform(this.auditStartTime, "h:mm a");
    var onlyToTime = this.datePipe.transform(this.auditEndTime, "h:mm a");

    if (onlyFromTime == onlyToTime) {
      this.alertText = this.labels.default.timeNotSame;
      this.modalRef2 = this.modalService.show(template, { class: 'second' });
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      return;
    }

    if (this.selectedTags) {
      if (this.selectedTags.length < 1) {
        this.alertText = this.labels.default.selectAleastOneTag;
        this.modalRef2 = this.modalService.show(template, { class: 'second' });
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        return;
      }
    }
    else {
      this.alertText = this.labels.default.selectAleastOneTag;
      this.modalRef2 = this.modalService.show(template, { class: 'second' });
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      return;
    }
    //audit.valueStreamID=this.multiselectVSIds[this.multiselectVSIds.length-1];
    audit.ValueStreams=this.selectedItemValueStream;
   // audit.valueStreamID=this.selectedItemValueStream

    if (this.selectedItemValueStream.length < 1  ) {
      this.alertText = this.labels.default.selectValueStream;
      this.modalRef2 = this.modalService.show(template, { class: 'second' });
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      return;
    }

    if (this.role) {
      if (this.requiredAttendees) {
        if (this.requiredAttendees.length < 1) {
          this.alertText = this.labels.default.selectAtleastOneAttendee;
          this.modalRef2 = this.modalService.show(template, { class: 'second' });
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          return;
        }
      }
    }

    //if (this.tempStartDate.length == 1) {
    //  this.startDate = new Date(Date.UTC(audit.startDate.getFullYear(), audit.startDate.getMonth(), audit.startDate.getDate(), this.audit.startTime.getHours(), this.audit.startTime.getMinutes()));
    //}
    //else {
    //  this.tempStartDate = audit.startDate.toString().split('-');
    //  this.startDate = new Date(Date.UTC(this.tempStartDate[2], this.tempStartDate[1] - 1, this.tempStartDate[0], this.audit.startTime.getHours(), this.audit.startTime.getMinutes()));
    //}
    //if (this.tempEndDate.length == 1) {
    //  this.endDate = new Date(Date.UTC(audit.endDate.getFullYear(), audit.endDate.getMonth(), audit.endDate.getDate(), this.audit.endTime.getHours(), this.audit.endTime.getMinutes()));
    //}
    //else {
    //  this.tempEndDate = audit.endDate.toString().split('-');
    //  this.endDate = new Date(Date.UTC(this.tempEndDate[2], this.tempEndDate[1] - 1, this.tempEndDate[0], this.audit.endTime.getHours(), this.audit.endTime.getMinutes()));
    //}

    //this.audit.startDate = this.startDate;
    //this.audit.endDate = this.endDate;




    this.audit.startDate = new Date(Date.UTC(audit.startDate.getFullYear(), audit.startDate.getMonth(), audit.startDate.getDate()));
    this.audit.endDate = new Date(Date.UTC(audit.endDate.getFullYear(), audit.endDate.getMonth(), audit.endDate.getDate()));
    this.audit.startTime = this.convertDateTimeToTime(this.auditStartTime);
    this.audit.endTime = this.convertDateTimeToTime(this.auditEndTime);
    this.audit.isRecurring = audit.isRecurring;
    this.audit.remarks = audit.remarks;
    this.audit.isDeleted = false;
    this.audit.assignedTags = this.selectedTags;
    this.audit.RequiredAttendees = this.requiredAttendees;
    this.audit.OptionalAttendees = this.optionalAttendees;
    this.audit.tagID = this.audit.assignedTags[0]!.tagID!;
    this.audit.tagTypeID = this.audit.assignedTags[0]!.tagTypeID!;
    this.audit.valueStreamID = audit.valueStreamID;
    this.audit.organizer = this.sharedService.ADdisplayName == "" ? this.sharedService.ntid : this.sharedService.ADdisplayName;
    this.audit.languageCode = this.sharedService.plantLanguageCode;
    this.audit.recurrence_DayOfWeek = this.dayOfWeekToString();
    if (this.audit.tagTypeID == 1)
    {
      this.audit.tagTypeName = this.labels.default.vsProcessConfirmation;
    }
    else if (this.audit.tagTypeID == 2)
    {
      this.audit.tagTypeName = this.labels.default.vsAudit;
    }
    else if (this.audit.tagTypeID == 3)
    {
      this.audit.tagTypeName = this.labels.default.vsSurvey;
    }

    //if (this.auditStartTime > this.auditEndTime) {
    //  this.alertText = this.labels.default.startDateLesser;
    //  this.modalRef2 = this.modalService.show(template, { class: 'second' });
    //  $("modal-container").removeClass("fade");
    //  $(".modal-dialog").addClass("modalSize");
    //  return;
    //}

    if (!this.audit.createdBy_NTID) {
      this.audit.createdBy_NTID = this.sharedService.ntid;
    }
    this.audit.modifiedBy_NTID = this.sharedService.ntid;
    if (this.sharedService.emailAddress) {
      this.audit.emailAddress = this.sharedService.emailAddress;
    }
    this.audit.valueStreamName = this.valueStreamList.filter(x => x.valueStreamID == this.audit.ValueStreams[0].valueStreamID)[0].valueStreamName;
    //this.audit.valueStreamName +=" valuestream1"
    this.audit.ValueStreams=this.selectedItemValueStream;
    this.audit.tagName = this.tagList.filter(x => x.tagID == this.audit.tagID)[0].tagName;
   
    //console.log(this.audit);
    //this.sharedService.hide();
    //$("modal-container").removeClass("fade");
    //$(".modal-dialog").addClass("modalSize");
    //return;

    this.resolveAuditRecurrenceValues();

    if (this.audit.isRecurring) {

      const validationMsg = this.validateAuditRecurrenceValues();
      if (validationMsg) {
        this.alertText = validationMsg;
        this.modalRef2 = this.modalService.show(template, { class: 'second' });
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        return;

        //alert(validationMsg);

        //this.sharedService.hide();
        //$("modal-container").removeClass("fade");
        //$(".modal-dialog").addClass("modalSize");

        //return;
      }

      const totalRecurrance = this.getRecurrence(this.audit);
      if (!totalRecurrance || totalRecurrance.length === 0) {
        //alert("The recurrence pattern is invalid");
        //this.sharedService.hide();
        //$("modal-container").removeClass("fade");
        //$(".modal-dialog").addClass("modalSize");
        //return;
        this.alertText = this.labels.default.InvalidRecurrence;
        this.modalRef2 = this.modalService.show(template, { class: 'second' });
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        return;
      }
      this.audit.startDate = totalRecurrance[0];
      this.audit.endDate = totalRecurrance[totalRecurrance.length - 1];
    }
    // this.sharedService.hide();
    // $("modal-container").removeClass("fade");
    // $(".modal-dialog").addClass("modalSize");
    // return;
    this.sharedService.show();
    this.auditService.insertAudit(this.audit).subscribe(res => {
      this.audit.auditID = res.auditID;
      this.closeAlertModal();
      this.sharedService.hide();
      this.alertText = this.labels.default.saveSuccessfully;
      this.modalService.show(this.successModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      if (this.role) {
        this.auditService.emailToAttendees(this.audit).subscribe(res => {
        }, err => console.error(err));


      }
    },
      err => console.error(err));
  }

  navigate(location) {
    let url: string = '';
    if (location == undefined) {
      console.log("loaction is undefined")
    }
    else {
      if (!/^http[s]?:\/\//.test(location)) {
        url += 'http://';
      }
      url += location;
      console.log("url", url)
      window.open(url, '_blank');

    }




  }

  //for Redirect
  redirect() {
    this.auditService.audit = this.audit;
    this.closeAlertModal();
   // console.log("1518")
    if (this.auditService.audit.tagTypeID != 1) {
      //alert("1513")
      this.router.navigate([environment.home + '/audit']);
    }
    else {
      
      this.sharedService.show();
      // this.alertText = this.labels.default.profileSettingError;
      //       console.log("warning")
      //       this.modalService.show(this.warningModal);
      //       $("modal-container").removeClass("fade");
      //       $(".modal-dialog").addClass("modalSize");
           // this.router.navigate([environment.home + "/userProfile/"]);
          
      this.sharedService.GetTagModeQuestions(this.auditService.audit.auditID, this.auditService.audit.tagID, this.router);
    }
  }

  onClose() {
    this.bsModalRef.hide();
  }

  config = {
    animated: false,
    keyboard: true,
    ignoreBackdropClick: true
  };


  open(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, this.config);
    this.modalRef.setClass('modal-lg calendar-modal');
  }

  viewDate = moment().toDate();

  ruleTest = new RRule({
    freq: RRule.WEEKLY,
    interval: 5,
    byweekday: [RRule.MO, RRule.FR],
    dtstart: new Date(Date.UTC(2019, 9, 12)),
    until: new Date(Date.UTC(2019, 9, 15))
  })

  recurringEvents: RecurringEvent[] = [
    {
      title: 'Recurs on the 5th of each month',
      color: '#FF0000',
      rrule: {
        //freq: RRule.MONTHLY,
        //bymonthday: 5,
        freq: RRule.WEEKLY,
        //interval: 5,
        byweekday: [RRule.MO, RRule.FR],
        dtstart: new Date("2021-01-01"),
        until: new Date("2021-12-31")

      }
    }
  ];
  locale: string=this.sharedService.selectedLanguage;

  calendarEvents: CalendarEvent[] = [];
  viewPeriod: ViewPeriod;

  updateCalendarEvents(
    viewRender:
      | CalendarMonthViewBeforeRenderEvent
      | CalendarWeekViewBeforeRenderEvent
      | CalendarDayViewBeforeRenderEvent
  ): void {
    if (
      !this.viewPeriod ||
      !moment(this.viewPeriod.start).isSame(viewRender.period.start) ||
      !moment(this.viewPeriod.end).isSame(viewRender.period.end)
    ) {
      this.viewPeriod = viewRender.period;
      this.calendarEvents = [];
      this.recurringEvents.forEach(event => {
        const rule: RRule = new RRule({
          ...event.rrule,
          dtstart: moment("09-12-2019", "MM-DD-YYYY").startOf('day').toDate(),
          until: moment(viewRender.period.end).endOf('day').toDate()
        });
        const { title, color } = event;

        rule.all().forEach(date => {
          this.calendarEvents.push({
            title,
            color,
            start: moment(date).toDate(),
            actions: [{
              label: "Demo Test",
              onClick(event) {

              }
            }]
          });
        });
      });
      
     // console.log("1616",this.recurringEvents)
      
     // console.log("1615",this.calendarEvents)
      this.cdr.detectChanges();
    }
  }

  //for Calaendar Filtering
  filterProcessConfirmation: any;
  filterAudit: any;
  filterSurvey: any;
  filterCorrectiveMeasure: any;
  tagTypes: any[number] = [];
  setTagType(tagTypeID: number) {
    if (this.tagTypes.length > 0) {
      let x = this.tagTypes.filter(x => x === tagTypeID);
      if (x.length > 0) {
        this.tagTypes = this.tagTypes.filter(x => x !== tagTypeID);
      }
      else {

        this.tagTypes.push(tagTypeID);
      }
    }
    else {
      this.tagTypes = [];
      this.tagTypes.push(tagTypeID);

    }
    this.getAudits(this.viewDate);
  }

  convertTimeToDateTime(timeString: string) {
    if (!timeString || timeString.split(":").length !== 3)
      return new Date();
    const date = new Date();
    const time = timeString.split(":");
    date.setHours(+time[0]);
    date.setMinutes(+time[1]);
    date.setSeconds(0);
    return date;
  }
  convertDateTimeToTime(dateTimeString: Date) {
    if (!dateTimeString) return "";
    return dateTimeString.getHours() + ":" + dateTimeString.getMinutes() + ":00";
  }

  GetStatusColor(auditID: number, tagTypeID: number, dte: Date) {

    //return tagTypeID === 1 ? this.colors.yellow : tagTypeID === 2 ? this.colors.green : this.colors.blue;
    if (this.auditAnswerStatusList != null && this.auditAnswerStatusList.length > 0) {

      let status = this.auditAnswerStatusList.filter(r => r.auditID == auditID && r.startDate == dte);

      if (status[0] == null) {
        
        status = this.auditAnswerStatusList.filter(r => r.auditID == auditID && new Date(r.startDate).toLocaleDateString() == dte.toLocaleDateString());
      }

      if (status[0] != null) {
        try {
          if (status[0].answeredStatus == "Not yet due") {
            
            return this.colors.grey;
          }
          else if (status[0].answeredStatus == "Completed") {
            
            return this.colors.green;
          }
          else if (status[0].answeredStatus == "In Progress") {
            
            return this.colors.yellow;
          }
          else {
            return this.colors.red;
          }
        } catch (error) {
          
        }
      }
    }
    else
    {
      return this.colors.blue;
    }
  }

  setRecurrencePattern(recurrencePattern: RecurrencePattern) {
    this.audit.recurrence_TypeId = recurrencePattern;
    this.audit.recurrence_Interval = 1;
    this.audit.recurrence_DayOfWeek = undefined;
    this.audit.recurrence_DayOfMonth = 1;
    this.audit.recurrence_WeekOfMonth = 1;
    this.audit.recurrence_MonthOfYear = 1;
    this.xDayOfWeek = new DayOfWeek();
    this.typeAndDayOfWeekStr = "";

    if (recurrencePattern >= 31 && recurrencePattern <= 40) {
      this.typeAndDayOfWeekStr = "32-1,1,1,1,1,1,1";
      if (recurrencePattern > 31)
        this.setDayOfWeek(this.typeAndDayOfWeekStr);
    } else if (recurrencePattern >= 41) {
      this.typeAndDayOfWeekStr = "42-1,1,1,1,1,1,1";
      if (recurrencePattern > 41)
        this.setDayOfWeek(this.typeAndDayOfWeekStr);
      //if (recurrencePattern >= 42)
      //  this.audit.recurrence_DayOfMonth = 0;
    }
    //else {
    //  this.typeAndDayOfWeekStr = "";
    //}
    //if (recurrencePattern === 32)
    //  this.setDayOfWeek("32-1,1,1,1,1,1,1");
    //else if (recurrencePattern === 42)
    //  this.setDayOfWeek("42-1,1,1,1,1,1,1");

    //if (this.audit.Recurrence_TypeId >= 11 && this.audit.Recurrence_TypeId <= 20) {
    //  this.audit.Recurrence_DayOfWeek = undefined;
    //  this.audit.Recurrence_DayOfMonth = undefined;
    //  this.audit.Recurrence_WeekOfMonth = undefined;
    //  this.audit.Recurrence_MonthOfYear = undefined;
    //  this.xDayOfWeek = undefined;
    //}
    //else if (this.audit.Recurrence_TypeId >= 21 && this.audit.Recurrence_TypeId <= 30) {
    //  this.audit.Recurrence_DayOfWeek = undefined;
    //  this.audit.Recurrence_DayOfMonth = undefined;
    //  this.audit.Recurrence_WeekOfMonth = undefined;
    //  this.audit.Recurrence_MonthOfYear = undefined;
    //  this.xDayOfWeek = undefined;
    //}
    //else if (this.audit.Recurrence_TypeId >= 31 && this.audit.Recurrence_TypeId <= 40) {
    //  if (this.audit.Recurrence_TypeId === 31)
    //    this.audit.Recurrence_DayOfWeek = undefined;
    //  this.audit.Recurrence_DayOfMonth = undefined;
    //  this.audit.Recurrence_WeekOfMonth = undefined;
    //  this.audit.Recurrence_MonthOfYear = undefined;
    //}
    //else if (this.audit.Recurrence_TypeId >= 41 && this.audit.Recurrence_TypeId <= 50) {
    //  if (this.audit.Recurrence_TypeId === 41)
    //    this.audit.Recurrence_DayOfWeek = undefined;
    //  this.audit.Recurrence_DayOfMonth = undefined;
    //  this.audit.Recurrence_WeekOfMonth = undefined;
    //  this.audit.Recurrence_MonthOfYear = undefined;
    //}
  }

  setDayOfWeek(typeAndDayOfWeek: string) {
    if (!typeAndDayOfWeek)
      return;
    this.typeAndDayOfWeekStr = typeAndDayOfWeek;
    const _typeDayOfWeek = typeAndDayOfWeek.split("-");

    if ((+_typeDayOfWeek[0] > 31 && +_typeDayOfWeek[0] <= 40) || (+_typeDayOfWeek[0] > 41 && +_typeDayOfWeek[0] <= 50))
      this.audit.recurrence_TypeId = +_typeDayOfWeek[0];

    if (_typeDayOfWeek[1] && _typeDayOfWeek[1].split(',').length === 7) {
      const d = _typeDayOfWeek[1].split(',');
      this.xDayOfWeek = new DayOfWeek(d[0] === "1", d[1] === "1", d[2] === "1", d[3] === "1", d[4] === "1", d[5] === "1", d[6] === "1");
    }

    //this.xDayOfWeek = new DayOfWeek(); //reset all the existing value
    //switch (+_typeDayOfWeek[1]) {
    //  case 0:
    //    this.xDayOfWeek.Sunday = true;
    //    break;
    //  case 1:
    //    this.xDayOfWeek.Monday = true;
    //    break;
    //  case 2:
    //    this.xDayOfWeek.Tuesday = true;
    //    break;
    //  case 3:
    //    this.xDayOfWeek.Wednesday = true;
    //    break;
    //  case 4:
    //    this.xDayOfWeek.Thursday = true;
    //    break;
    //  case 5:
    //    this.xDayOfWeek.Friday = true;
    //    break;
    //  case 6:
    //    this.xDayOfWeek.Saturday = true;
    //    break;
    //  case 32:
    //    this.xDayOfWeek = new DayOfWeek(true, true, true, true, true, true, true);
    //    break;
    //  case 33:
    //    this.xDayOfWeek = new DayOfWeek(false, true, true, true, true, true, false);
    //    break;
    //  case 34:
    //    this.xDayOfWeek = new DayOfWeek(true, false, false, false, false, false, true);
    //    break;
    //}
  }
  dayOfWeekToString() {
    return `${+this.xDayOfWeek.Sunday},${+this.xDayOfWeek.Monday},${+this.xDayOfWeek.Tuesday},${+this.xDayOfWeek.Wednesday},${+this.xDayOfWeek.Thursday},${+this.xDayOfWeek.Friday},${+this.xDayOfWeek.Saturday}`;
  }
}

interface RecurringEvent {
  text?: string;
  title: string;
  color: any;
  rrule?: {
    freq: any;
    bymonth?: number;
    bymonthday?: number | number[];
    byweekday?: any;
    interval?: number;
    count?: number;
    bysetpos?: number;
    until?: Date;
    dtstart?:Date;
  };
}
