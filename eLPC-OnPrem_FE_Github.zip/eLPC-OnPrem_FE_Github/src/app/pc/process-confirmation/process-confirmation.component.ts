import { Component, OnInit, TemplateRef, ViewChild, ElementRef, Renderer2} from "@angular/core";
import { SharedService } from "src/app/service/shared.service";
import { ProcessConfirmation } from "./process-confirmation";
import { FormBuilder, FormGroup,Validators } from '@angular/forms';

import { Assessor } from "src/app/Assessor/assessor/assessortemplate";
import { ValueStream } from "src/app/Valuestream/valuestreams/valuestreamtemplate";
import { Choice, Question, HintImage, SingleLineText, MultipleLinesText} from "src/app/Datapool/QuestionModule/questions/question";
import { QuestionService } from "src/app/service/question.service";
import { ValuestreamTemplateService } from "src/app/service/common/valuestreamtemplate.service";
import { ProcessConfirmationService } from "src/app/service/common/process-confirmation.service";
import { BsModalService, BsModalRef } from "ngx-bootstrap/modal";
import { ActivatedRoute, Router } from "@angular/router";
import { CustomMode } from "src/app/custommode/custom-mode/custom-mode";
import { User } from "../../../app/main/body/shared/common";
import { CalendarService } from 'src/app/service/calendar.service';

import { CommonService } from "src/app/service/common/common.service";
import { LanguageService } from "src/app/language.service";
import { saveAs } from 'file-saver';
import {formatDate } from '@angular/common';
import { Deviation,Duedate } from "src/app/Deviation/deviation/deviation";
import { environment } from "src/environments/environment";
import { SuperOPLService } from "src/app/service/superopl.service";
import { UserProfileUpdateVSAS } from "src/app/UserProfile/userprofile-c/userProfile";
import { UserProfileService } from "src/app/service/user-profile.service";
import { TagModeService } from 'src/app/service/tag-mode.service';
import { Tag } from "src/app/Tag/tag/tag";
import { TagService } from "src/app/service/tag.service";
import { TagMode } from "../../ProcessConfirmation/process-confirmationmode/tag-mode/tag-mode";
@Component({
  selector: "app-process-confirmation",
  templateUrl: "./process-confirmation.component.html",
  styleUrls: ["./process-confirmation.component.css"]
})

export class ProcessConfirmationComponent implements OnInit {
  @ViewChild("fileInput") fileInputVariable: ElementRef;
  @ViewChild("alertPopup") warningModal: TemplateRef<any>;
  @ViewChild("alertPopup1") warningModal1: TemplateRef<any>;
  @ViewChild("successPopup") successModal: TemplateRef<any>;
  @ViewChild('questionOverView') public questionOverViewModal: TemplateRef<any>;
  @ViewChild('ResumeModal') public ResumeModal: TemplateRef<any>;
  @ViewChild('answerOverView') public answerOverViewModal: TemplateRef<any>;
  @ViewChild('answerOverView_inline') public answerOverViewModal_inline: TemplateRef<any>;
  @ViewChild('answerOverView1') public answerOverViewModal1: TemplateRef<any>;
  @ViewChild("skipdisable") skipdisable: TemplateRef<any>;
  @ViewChild('inlineoverviewanswertag') public inLineOverviewAnswerModal: TemplateRef<any>;
  @ViewChild('alertPopup_inline') warningModal_inline: TemplateRef<any>;
  @ViewChild("successPopup_Inline") successModal_Inline: TemplateRef<any>;
  @ViewChild('answerOverView1_inline') public answerOverViewModal1_inline: TemplateRef<any>;
  tagMode:TagMode=new TagMode();
  skipQuestionList: Array<any> = new Array();
  displayList: Array<any> = new Array();
  titleList: Array<any> = new Array();

  cancelAppendValueStreamWithOtherData: string;
  cancelSelectedValueStreamData: string;
  cancelSelectedAssessorName: string;
  singleTextmaxLength: number;
  modalRef_inline: BsModalRef;
  alertText;
  fileUrl;
  public progress: number;
  public message: string;
  IsSubmit: boolean = false;
  deviationTypeID: number;
  deviation: Deviation;
  managerEmailAddress: string;
  responsibleEmployeeID: any;
  imageArray: any;
  additionalInfoyes:boolean=false;
  isShowVsAs: boolean;
  isLoading: boolean = true;
  SkipProcess:any;
  formData1: FormData;
  checkboxSelected: boolean = false;
  newIndex: number;
  items: Array<any> = new Array();
  activeItem: any;
  selectedQuestionID: number;
  selectedQuestionDisplayID: number;
  myAnswerID: number;
  question: Question = new Question();
  url: HintImage = new HintImage();
  urls: HintImage[] = [];
  tagList: Tag[] = [];
  tagList1: Tag[] = [];
  droppedImage: any;
  droppedImageName: any;

  user: User = new User();
  users: User[] = [];

  labels: any;
  _subscription: any;

  data: any;
  selectedUser: string;
  data1:any;
  deviationDescription: string;
  responsibleEmployee: string;
  responsibleEmployeeNTID: string;
  isDeviationEntryRequired: boolean = false;
  count: number = 0;
  buttonColor: string; //Default Color
  customMode: CustomMode = new CustomMode();
  modeType: string = "shuffle";
  myQuestionID: number = 0;
  myTagID: number;
  UserNTID: string;
  selectedValueStreamID: number = 0;
  selectedAssessorID: number = 0;
  selectedChoiceID: number= 0;
  modalReference: any;
  processConfirmation: ProcessConfirmation = new ProcessConfirmation();

  answers: any[];
  requiredAttendee: any;
  requiredAttendees: User[] = [];
  optionalAttendee: any;
  optionalAttendees: User[] = [];
  requiredAttendeesNTID:String[]=[];
  value: string;
  duedate: Duedate = new Duedate();
  QuestionId: number;
  isMode: boolean = true;
  isAddVSAssessor: boolean = false;
  questionAndAnswerTypeList: ProcessConfirmation = new ProcessConfirmation();
  assessorList: Assessor[] = [];
  valueStreamList: ValueStream[] = [];
  choices: Choice[] = [];
  multiselectTagIDs:any[]=[];
  singleLineText: SingleLineText[] = [];
  multiLineText: MultipleLinesText[] = [];
  selectedValueStreamData: string = "";
  appendValueStreamWithOtherData: string;
  appendAssessorWithOtherData: string;
  selectedAssessorName: string;
  selectedAnswer: any;
  closeResult: string;
  vText: any;
  finalDate:any;
  PopulateVStreamAndAssessorDropdown: ProcessConfirmation = new ProcessConfirmation();
  processConfirmationList: ProcessConfirmation[] = [];
  bsModalRef: BsModalRef;
  modalRef: BsModalRef;
  processConfirmationForm: FormGroup;
  submitted = false;
  selectedTag = {
    TagDisplayName:'' ,
    TagID: 0,
  };
  globaltagQuesandAnsOverView =[];
  globaltagQuesandAnsOverViewResumeCheck=[]
  globaltagQuesandAnsOverProcess =[];
  eventID_Starttime:any;
  generatedEventID:any;
  AttemptNumber:number;
  ChildEventID:string;
  IsFirstinsertProcess:boolean;
  CustomSkip:boolean = false;
  orderMap:any=[];
  isshowLoadingchoice:boolean=false;
  //TargetPercentage:number=0

  IsInlineActivatedModel: false;
  IsInlineActivated: false;
  toggle_message: string = ''; // 'Inline Mode: Qs'+this.dynamicAnswerCount;
  dynamicAnswerCount: number = 0;
  name = 'ng-toggle-button';
  configchk = {
    value: true,
    name: '',
    disabled: false,
    height: 25,
    width: 190,
    margin: 3,
    fontSize: 10,
    speed: 300,
    border: 0,
    color: {
      // checked: '#56C128',
      checked: '#dcdcdc',
      unchecked: '#8c8c8c',
    },
    switchColor: {
      checked: '#005691',
      unchecked: '#005691',
    },
    labels: {
      unchecked: 'Inline Mode off',
      // checked: 'Inline Mode on we can answer 3 questions', Inline Mode: 3 Qs
      checked: '', //this.toggle_message,
    },
    checkedLabel: '',
    uncheckedLabel: '',
    fontColor: {
      // checked: '#fafafa',
      checked: '#1a1a1a',
      unchecked: '#ffffff',
    },
    textAlign: 'left',
  };
//inlineAnswerCount: number = 3;
  tooltipContent = '';
  tooltipOpen = false;
  isAnyCheckboxChecked=false;

 //inlineMode Answer variables

 responsibleEmployee_inline: string;
 valueStreamName_inline: string = '';
 tagId_Insert_inline: number = 0;
 selectedQuestionID_inline: number;
 selectedQuestionDisplayID_inline: number;
 processConfirmation_inline: ProcessConfirmation = new ProcessConfirmation();
 activeItem_inline: any;
 myAnswerID_inline: number;
 modeType_inline: string = "shuffle";
 selectedValueStreamID_inline: number = 0;
 appendValueStreamWithOtherData_inline: string;
 selectedAssessorName_inline: string;
 selectedAssessorID_inline: number = 0;
 appendAssessorWithOtherData_inline: string;
 choices_inline: Choice[] = [];
 isDeviationEntryRequired_inline: boolean = false;
 deviationDescription_inline: string;
 deviation_inline: Deviation;
 singleLineText_inline: SingleLineText[] = [];
 multiLineText_inline: MultipleLinesText[] = [];
 additionalInfoyes_inline:boolean=false;
 deviationTypeID_inline: number;
 ngMultiSelectSelectedTagItem_inline:Tag[];
 requiredAttendees_inline: User[] = [];
 IsSubmit_inline: boolean = false;
 isValuestreamChanged_inline: boolean;
 //end



  onToggleChange(value: boolean) {
   // debugger;

    this.tooltipOpen = value;
    if (value) {
      this.dynamicAnswerCount = this.dynamicAnswerCount > 0 ? this.dynamicAnswerCount : this.inlineAnswerCount;
      this.tooltipOpen = true;
      this.tooltipContent = this.labels.default.Answerable+' '+this.inlineAnswerCount+' '+ this.labels.default.Questonsinline+':)' ;
      this.updateToggleMessage();
    }
    else{
      this.tooltipContent = '';
      //this.dynamicAnswerCount = 0;
    }
  }


  config = {
    animated: false,
    keyboard: true,
    ignoreBackdropClick: true
  };

  IsMaxLimitReached: boolean = false;
  checkboxCheckedCount: number = 0;

  model: any = {};
  countries: any;
  vsUser: User;
  isValuestreamChanged: boolean;
  isDesktop: boolean = true;

  //For multi select dropdown - Value stream
  dropdownSettingsValueStream = {};
  selectedItemValueStream: ValueStream[] = [];

  ngMultiSelectDropdownTagSettings = {};
  ngMultiSelectSelectedTagItem:Tag[];

  //For multi select dropdown - Value stream
  dropdownSettingsAssessor = {};
  selectedItemAssessor: Assessor[] = [];

  calendarAuditID :number  = 0;
  tagModeTagID :number  = 0;
  flagQuestionLoaded: boolean = false;
  answeredPercentage :any =100;
  remainingQuestions:any;
  TagModePendingStatus: boolean = false; // variable
  showPendingModal:boolean = false // var to show the resume Modal when Tag is in pending state
  isResumeTagSelected :boolean = false; // var to hold the value when resume Tag in tag moed is clicked
  ResumeActivated:boolean=false;
  valueStreamName: string = '';
  tagId_Insert: number = 0;

  deviation1:Deviation=new Deviation();
  IsToggleDisabled: boolean = false;
  isResumeClicked:boolean=false;

  IsInlineModeEnabled: boolean = false;
  inlineAnswerCount: number = 0;
  selectedQuestionInline: any = '';
  fromnextQsoverviewResumeInline:boolean=false;
  isSubmitClicked: boolean = false;

  constructor(
    private local_label: LanguageService,
    private route: ActivatedRoute,
    private modalService: BsModalService,
    private sharedService: SharedService,
    private valuestreamService: ValuestreamTemplateService,
    private processConfirmationService: ProcessConfirmationService,
    private questionService: QuestionService,
    private formBuilder: FormBuilder,
    private commonService: CommonService,
    private router: Router,
    private superOPLService: SuperOPLService,
    private tagModeService:TagModeService,
    private tagService: TagService,
    private userProfileService: UserProfileService,
    private auditService: CalendarService,
    private renderer: Renderer2

  ) {
    //this.initializeProcessConfirmation(); // Initialize in the constructor
    this.UserNTID = this.sharedService.ntid;
    this.data = [];
    this.user = this.commonService.user;
    this.commonService.user = undefined;
    if (this.user == undefined) {
      this.user = new User();
    } else if (Object.keys(this.user).length == 0) {
      this.user = new User();
    } else {
      this.selectedUser = "";
      this.commonService.getUserByNTID(this.user.ntid).subscribe(
        res => {
          let usr = res;
          this.responsibleEmployee = usr.userName;
          this.user = usr;
        },
        err => console.error(err)
      );
    }

    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
      this.isDesktop = false;
    }

  }

  async ngOnInit() {


    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe(value => {
      this.labels = value;
      this.value = this.labels.default.tipValue;
    });
    //console.log("225",this.customMode)
    //To get the SelectedTag Details in tagmode while Giving Deviation
    await this.GetTagModeByNTID();
    //console.log("197",this.processConfirmation)

    this.route.params.subscribe(params => {
      this.modeType = params["mode"] || "shuffle";
      if (params["mode"] == "tag") {
        // console.log("231,procconfirm",this.sharedService)
         //if(this.sharedService.tagTypeID ==4) {
          //alert("inside process confirmation Globaltype")

        // }
        this.calendarAuditID = this.sharedService.calendar_auditID;
        this.tagModeTagID = this.sharedService.tagMode_tagID;

        this.sharedService.setIconName("Tag Mode");
        setTimeout(() => {
          this.sharedService.setIcon("assets/image/wand.png");
        }, 100);
      }
      this.sharedService.calendar_auditID = 0;
      this.sharedService.tagMode_tagID = 0;
    });

    //redirecting question ID from DataPool
    this.route.params.subscribe(params => {
      //
      this.myQuestionID = params["qid"];
    });

    // //redirecting to TagID QuestionList  from DataPool
    // this.route.params.subscribe(params => {
    //   this.myTagID = params["tid"];
    // });


    this.processConfirmationForm = this.formBuilder.group({
      vStream: [" ", Validators.required],
      assessor: [" ", Validators.required]
    });


    if (this.calendarAuditID > 0) {


      await this.getProcessConfirmation("calendarTag", this.calendarAuditID, 0, this.UserNTID, this.myTagID, this.myQuestionID, this.skipQuestionList)
      // .then(async () => {
      //   await this.pendingTagModeStatus()
      // });
    }
    else {
      //console.log("before pending",this.processConfirmation)

      if(this.modeType == "tag" || this.modeType == "custom") {
        await  this.getProcessConfirmation(this.modeType, this.selectedValueStreamID, this.selectedAssessorID, this.UserNTID, this.myTagID, this.myQuestionID, this.skipQuestionList,this.TagModePendingStatus)
        // .then(async () => {
        //   await this.pendingTagModeStatus()
        // });


      }
      if(this.modeType=="shuffle"){
        await  this.getProcessConfirmation(this.modeType, this.selectedValueStreamID, this.selectedAssessorID, this.UserNTID, this.myTagID, this.myQuestionID, this.skipQuestionList,this.TagModePendingStatus);
      }

     // console.log("281 Result")
     }
    // await this.getTagList(); //will use once it required
     await this.calculateDuration();
    this.ngMultiSelectDropdownTagSettings={
      singleSelection: false,
          idField: 'tagID',
         textField: 'FormattedTag',
        selectAllText: 'Select All',
       unSelectAllText: 'UnSelect All',
          itemsShowLimit: 5,
         allowSearchFilter: true,
        closeDropDownOnSelection: true
     };
    //For multi select dropdown - Assign tag to Value stream template
    this.dropdownSettingsValueStream = {
      singleSelection: true,
      idField: 'valueStreamID',
      textField: 'FormattedValueStream',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 5,
      allowSearchFilter: true,
      closeDropDownOnSelection: true
    };

    //For multi select dropdown - Assessor
    this.dropdownSettingsAssessor= {
      singleSelection: true,
      idField: 'assessorID',
      textField: 'assessorName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 5,
      allowSearchFilter: true,
      closeDropDownOnSelection: true
    };
    //console.log("309",this.sharedService)
    this.sharedService.hide();


    // if((this.sharedService.SharedServiceTags.isResultOverviewDefined && this.modeType == "tag") || ( this.sharedService.CustomModeAnswerOverView && this.modeType == "custom"  )){
    //   this.answerOverView()
    // }

    this.updateToggleMessage();
  }

  updateToggleMessage(): void {
    //this.toggle_message = `Inline Mode: Qs ${this.dynamicAnswerCount}`;
    this.toggle_message = `${this.labels.default.InlineModeOn} ${this.dynamicAnswerCount}`;
    this.configchk.labels.checked = this.toggle_message;
  }

  answerOverView(eventidstarttime?:string) {
    this.modalService.show(this.answerOverViewModal, this.config);
    $("modal-container").removeClass("fade");
  }
  answerOverView1(eventidstarttime?:string) {
    this.modalService.show(this.answerOverViewModal1, this.config);
    $("modal-container").removeClass("fade");
  }
  answerOverView_inline(eventidstarttime?:string) {
    this.modalService.show(this.answerOverViewModal_inline, this.config);
    $("modal-container").removeClass("fade");
  }
    answerOverView1_inline(eventidstarttime?:string) {
    this.modalService.show(this.answerOverViewModal1_inline, this.config);
    $("modal-container").removeClass("fade");
  }
  questionOverView() {
    this.modalService.show(this.questionOverViewModal, this.config);
    $("modal-container").removeClass("fade");
   // this.isQuestionOverviewed = true;

  }

  inLineModePopUpOverview()
  {
    this.modalRef_inline = this.modalService.show(this.inLineOverviewAnswerModal, this.config);
    //$("modal-container").removeClass("fade");
   // this.isQuestionOverviewed = true;

    //$(".modal-dialog").addClass("modalSize");
  }

  showSuccessAlert()
  {
    this.alertText = this.labels.default.success;
    this.modalService.show(this.successModal);
    $("modal-container").removeClass("fade");
   // $("modal-container").addClass("fade");
   const alertDialog = document.querySelector('.modal-dialog.Success-dialog');
   if (alertDialog) {
     $(".modal-content").addClass("modalSize121");
     // this.renderer.addClass(alertDialog, 'modalSize');
     this.renderer.setStyle(alertDialog, 'display', 'flex');
     this.renderer.setStyle(alertDialog, 'align-items', 'center');
     this.renderer.setStyle(alertDialog, 'justify-content', 'center');
     this.renderer.setStyle(alertDialog, 'height', '45vh');
     this.renderer.setStyle(alertDialog, 'margin', '0');
   }
  }

   async onCheckboxChange(event: any, question: Question) {
   // debugger;
    //this.clearvariable()
     //checkedQuestion: ProcessConfirmation = this.globaltagQuesandAnsOverView.filter(q => q.questionID == question.questionID && q.questionDisplayID == question.questionDisplayID);
     const checkedQuestion = this.globaltagQuesandAnsOverView.find(
      q => q.questionID == question.questionID && q.questionDisplayID == question.questionDisplayID
      );

     var checkquestionProcessConfi = this.processConfirmation;
    if (question != null)
      {
        this.responsibleEmployee_inline = question.responsibleEmployee;
        this.selectedQuestionDisplayID_inline = question.questionDisplayID;
        this.activeItem_inline = question.questionText;
        this.myAnswerID_inline = question.answerType_AnswerTypeID;
        this.processConfirmation_inline = { ...checkedQuestion };
        this.valueStreamName_inline = this.processConfirmation_inline.valueStreamName;
        this.tagId_Insert_inline = this.processConfirmation_inline.tagID;
        this.selectedQuestionID_inline = this.processConfirmation_inline.questionID;
        this.modeType_inline = this.processConfirmation_inline.modeType;
        this.selectedValueStreamID_inline = this.processConfirmation_inline.valueStreamID;
        this.appendValueStreamWithOtherData_inline = this.processConfirmation_inline.valueStreamTemplateName + this.processConfirmation_inline.delimiter + this.processConfirmation_inline.valueStreamName;
        this.selectedAssessorName_inline = this.processConfirmation_inline.assessorName;
        this.selectedAssessorID_inline = this.processConfirmation_inline.assessorID;
        this.appendAssessorWithOtherData_inline = this.processConfirmation_inline.assessortemplate;
        this.choices_inline=[];
        this.isDeviationEntryRequired_inline =false;
        this.deviationDescription_inline ='';
        this.deviation_inline = new Deviation();
        this.singleLineText_inline=[]
        this.multiLineText_inline=[]
        this.selectedQuestionInline = question.questionID;
        //this.deviationTypeID_iline = this.processConfirmation_inline.

      }
        if (this.processConfirmation_inline.answerType_AnswerTypeID == 3 || this.myAnswerID_inline == 3)
          {
            await this.getDropDownChoices_inline();
          }

          // ****************************** if answertype is SingleLineText******************************

          else if (this.processConfirmation_inline.answerType_AnswerTypeID == 1 || this.myAnswerID_inline == 1) {
            await this.getSingleLinetextdata_inline();
          }

          // ************************single line text ends********************

          // ****************************** if answertype is MultiLineTExt******************************

          else if (this.processConfirmation_inline.answerType_AnswerTypeID == 2 || this.myAnswerID_inline == 2) {
           await this.getMultiLineTextdata_inline();
          }
          // ************************Multi line etxt ends********************

    const checkedCount = this.globaltagQuesandAnsOverView.filter(q => q.checked).length;

    if (checkedCount > this.inlineAnswerCount) {
      event.target.checked = false; // Prevent exceeding max selections
    }

    // Enable all checkboxes if checked count is less than maxSelections
    if (checkedCount < this.inlineAnswerCount) {
      // this.dynamicAnswerCount--;
      // this.updateToggleMessage();
     // this.dynamicAnswerCount =  this.dynamicAnswerCount - checkedCount;

      // Find the selected question in globaltagQuesandAnsOverView
      const selectedQuestion = this.globaltagQuesandAnsOverView.find(
        q => q.questionID === question.questionID && q.questionDisplayID === question.questionDisplayID
      );
      // Show popup if checkbox is checked and within max selections
      if (event.target.checked) {
        // selectedQuestion.disabled = true;
        this.inLineModePopUpOverview();

      }
    } else {
      // this.dynamicAnswerCount--;
      // this.updateToggleMessage();
     // this.dynamicAnswerCount =  this.dynamicAnswerCount - checkedCount;
      // Disable unchecked checkboxes if checked count equals maxSelections
      //this.globaltagQuesandAnsOverView.forEach(q => q.disabled = !q.checked);
      // Disable all checkboxes if the checked count equals the max selection limit
      this.globaltagQuesandAnsOverView.forEach(q => q.disabled = true);
      this.IsToggleDisabled = true;
      if (this.IsToggleDisabled)
        {
        //   this.alertText = "";
        // this.alertText = "You have reached your limit please click next and answer your questions";
        // this.modalService.show(this.warningModal_inline);
        // $("modal-container").removeClass("fade");
        // //$(".modal-dialog").addClass("modalSize");
        // const alertDialog = document.querySelector('.modal-dialog.alert-dialog');
        //   if (alertDialog) {
        //     $(".modal-content").addClass("modalSize121");
        //     this.renderer.setStyle(alertDialog, 'display', 'flex');
        //     this.renderer.setStyle(alertDialog, 'align-items', 'center');
        //     this.renderer.setStyle(alertDialog, 'justify-content', 'center');
        //     this.renderer.setStyle(alertDialog, 'height', '45vh');
        //     this.renderer.setStyle(alertDialog, 'margin', '0');
        //   }
      }
      if (event.target.checked) {
        this.inLineModePopUpOverview();

      }

    }
  }


   calculatePercentage() {

    //console.log("331",this.globaltagQuesandAnsOverProcess.length)
    //console.log('332',this.remainingQuestions.length)
    let percentage = ((this.remainingQuestions.length/this.globaltagQuesandAnsOverProcess.length) *100) .toFixed(0);
    this.answeredPercentage =100 - Number(percentage)
    //console.log("percent", this.answeredPercentage)
   // console.log("368",this.globaltagQuesandAnsOverProcess)
    //console.log("368",this.globaltagQuesandAnsOverView)
    //to calculate the percentage

    // console.log("518",this.audit)
    // if(this.audit.tagTypeID ==1 && this.audit.isProgressPercentageDefined || this.audit.tagTypeID ==2 && this.audit.isProgressPercentageDefined ||  this.audit.tagTypeID ==3 && this.audit.isProgressPercentageDefined ||  (this.audit.tagTypeID ==4 && this.audit.isProgressPercentageDefined)) {
    //   let answeredQuestions = this.questionList.filter(x => x.answer);
    //   if (this.questionList.length == answeredQuestions.length) {
    //     this.answeredPercentage = 100;
    //   }
    //   else {
    //     this.answeredPercentage = ((answeredQuestions.length / this.questionList.length) * 100).toFixed(0);
    //   }
    // }else{
    //   console.log("529")
    // }


  }
  //For multi select dropdown - Assign tag to Value stream template
  onSelectValueStream(item: ValueStream) {
    this.selectedValueStreamID = item.valueStreamID;
  }
   onNgMultiSelectDropdownTagItemSelect(item:Tag){
   this.multiselectTagIDs.push(item.tagID);
  }
   onNgMultiSelectDropdownTagItemDeSelect(item:Tag){
    if(!this.ngMultiSelectSelectedTagItem||this.ngMultiSelectSelectedTagItem.length===0)
   this.ngMultiSelectSelectedTagItem=this.ngMultiSelectSelectedTagItem.filter(x=>x.tagID!==item.tagID)
  }
  onDeSelectValueStream() {
    if (!this.selectedItemValueStream || this.selectedItemValueStream.length === 0)
      this.selectedValueStreamID = 0;
  }
  onLoadValueStream() {
    this.selectedItemValueStream = [];
    if (!this.selectedValueStreamID || this.selectedValueStreamID === 0)
      return;
    const selectedItem = this.valueStreamList.find(x => x.valueStreamID === this.selectedValueStreamID);
    if (selectedItem)
      this.selectedItemValueStream.push(selectedItem);
  }
  calculateDuration(){
    this.finalDate=new Date(new Date().setDate(new Date().getDate()+environment.superoplEndDateCount));
     this.duedate.datecount=this.finalDate;
 }
   getTagList(){
    this.tagService.getTags_ProcessConfirmation().subscribe(res => {
      this.tagList = res;
      this.tagList.forEach(x=>x.FormattedTag=x.tagDisplayName)
     this.tagList=this.tagList.filter(x=>x.tagDisplayName);
   }, err =>console.error(err));
    // this.tagService.getTags().subscribe(res => {
    //    this.tagList = res;
    //    this.tagList.forEach(x=>x.FormattedTag=x.tagDisplayName)
    //   this.tagList=this.tagList.filter(x=>x.tagDisplayName);
    // }, err =>console.error(err));
   }
  //For multi select dropdown - Assessor
  onSelectAssessor(item: Assessor) {
    this.selectedAssessorID = item.assessorID;
  }
  onDeSelectAssessor() {
    if (!this.selectedItemAssessor || this.selectedItemAssessor.length === 0)
      this.selectedAssessorID = 0;
  }
  onLoadAssessor() {
    this.selectedItemAssessor = [];
    if (!this.selectedAssessorID || this.selectedAssessorID === 0)
      return;
    const selectedItem = this.assessorList.find(x => x.assessorID === this.selectedAssessorID);
    if (selectedItem)
      this.selectedItemAssessor.push(selectedItem);
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.processConfirmationForm.controls;
  }

   loadTag(tagID: number) { // on Tag Hyperlink selection corresponding tag gets loaded
    this.sharedService.show();
    //console.log("318",tagID)
   // this.sharedService.GetTagModeQuestions1(0, tagID, this.router)
    this.sharedService.GetTagModeQuestions(0, tagID, this.router)
    //.subscribe(res=>{}, err => console.log(err));)
    //console.log("319",tagname)
    //console.log("321",res)
    // this.GetTagModeByNTID();

    this.sharedService.fetchTagDetailsByTagID(tagID).subscribe(res => {

      //console.log("327",res)
      //console.log("375",res);
      this.selectedTag.TagDisplayName =res[0].tagName;
      if(res[0].tagTypeID==1){
        this.selectedTag.TagDisplayName ='#'+this.selectedTag.TagDisplayName;
      }
      if(res[0].tagTypeID==2){
        this.selectedTag.TagDisplayName ='@'+this.selectedTag.TagDisplayName;
      }
      if(res[0].tagTypeID==3){
        this.selectedTag.TagDisplayName ='$'+this.selectedTag.TagDisplayName;
      }
    //  this.selectedTag.TagID=res[0].tags[0].tagID;
     //  console.log("331",this.selectedTag);
    }, err => console.log(err));

  }

  tagMode1 = {
    name: '',
    email: ''
  };

// insertToTagMode(formData: any) {
//   event.preventDefault();
//     // Handle form submission, e.g., send data to backend
//   alert(formData.name)
//     console.log(formData); // This will log the tagMode object with the form data

//   }

// insertToTagMode(event: Event, tagModeForm: NgForm) {
//   event.preventDefault(); // Prevent the default form submission
//   if (tagModeForm.valid) {
//     // Handle the form submission logic here
//     console.log('Form submitted', this.tagMode1);
//   }
// }


  onRequiredAttendeeSearch() {
    let user = new User();
    user.firstName = this.requiredAttendee;
    user.isGroupNameRequired = true;
    this.commonService.activeDirectoryByName(user).subscribe(res => {
      this.data1 = [];
      this.data1 = res;

    },

      err => console.error(err));

  }
  selectRequiredAttendee(user: any) {
        if (user !== null) {
        //   if(this.user.userName==this.deviation.responsibleEmployee){

        //     this.alertText = "User already selected";
        //     this.modalService.show(this.warningModal);
        //     $("modal-container").removeClass("fade");
        //     $(".modal-dialog").addClass("modalSize");
        //     return;
        // }

         // let x = this.requiredAttendees.filter(x => x.ntid == user.ntid);

            if(user.userName==this.responsibleEmployee){
              this.alertText = this.labels.default.SelectedUser;
              this.modalService.show(this.warningModal);
              $("modal-container").removeClass("fade");
              $(".modal-dialog").addClass("modalSize");
              return;
            }
           this.requiredAttendees.push(user);
           this.requiredAttendeesNTID.push(user.ntid);
           this.deviation.AddItionalEmployeeNTID=this.requiredAttendeesNTID;

        }
    this.data = [];
    this.requiredAttendee = undefined;
      }
      onOptionalAttendeeSearch() {

        let user = new User();
        user.firstName = this.optionalAttendee;
        user.isGroupNameRequired = true;
        this.commonService.activeDirectoryByName(user).subscribe(res => {
          this.data = [];
          this.data = res;
        },
          err => console.error(err));
      }
  removeRequiredAttendee(user: any) {
   this.requiredAttendees = this.requiredAttendees.filter(x => x.ntid !== user.ntid);
  }
  onSubmit() { //from where we are calling this function
    this.submitted = true;
    if (this.processConfirmationForm.invalid) { // stop here if form is invalid
      return;
    }
    this.saveVSAndAssessor();
    this.alertText = this.labels.default.success;
    this.modalService.show(this.successModal);
    $("modal-container").removeClass("fade");
    $(".modal-dialog").addClass("modalSize");
  }

  // next() {
  //   const currentIndex = this.items.indexOf(this.activeItem);
  //   const newIndex =
  //     currentIndex === this.items.length - 1 ? 0 : currentIndex + 1;
  //   this.activeItem = this.items[newIndex];
  // }

  // previous() {
  //   const currentIndex = this.items.indexOf(this.activeItem);
  //   const newIndex =
  //     currentIndex === 0 ? this.items.length - 1 : currentIndex - 1;
  //   this.activeItem = this.items[newIndex];
  // }

  selectOptionChange(args) {
    //debugger;
    var id = JSON.parse(args.target.value);
    this.choiceSelectionChange(id);
  }

  choiceSelectionChange(id:number) {
    //debugger;
    this.deviationTypeID = this.choices.filter(
      x => x.choiceID == id
    )[0].deviationTypeID;
    if (this.deviationTypeID > 1) {
      this.isDeviationEntryRequired = true;
	 // this.isDeviationEntryRequired_inline = true;
      this.toGetTheValueStream();
    }
    else {
      this.isDeviationEntryRequired = false;
	  //this.isDeviationEntryRequired_inline = false;
      this.deviation = new Deviation();
	  this.deviation_inline = new Deviation();
      this.deviationDescription = undefined;
	  //this.deviationDescription_inline = undefined;
      this.responsibleEmployee = undefined;
	 // this.responsibleEmployee_inline = undefined;
    }
  }

selectOptionChange_inline(args) {
  console.log("inline drop down change")
   // debugger;
    var id = JSON.parse(args.target.value);
    this.choiceSelectionChange_inline(id);
  }

  choiceSelectionChange_inline(id:number) {
   // debugger;
    this.deviationTypeID_inline = this.choices_inline.filter(
      x => x.choiceID == id
    )[0].deviationTypeID;
    if (this.deviationTypeID_inline > 1) {
      // this.isDeviationEntryRequired = true;
      this.isDeviationEntryRequired_inline = true;
     // this.toGetTheValueStream();
     this.toGetTheValueStream_inline();
    }
    else {
      // this.isDeviationEntryRequired = false;
      this.isDeviationEntryRequired_inline = false;
      // this.deviation = new Deviation();
      this.deviation_inline = new Deviation();
      // this.deviationDescription = undefined;
      this.deviationDescription_inline = undefined;
      // this.responsibleEmployee = undefined;
      this.responsibleEmployee_inline = undefined;
    }
  }


  onChangeSearch() {
    let user = new User();
    user.firstName = this.responsibleEmployee;
    this.commonService.activeDirectoryByName(user).subscribe(
      res => {
        this.data = [];
        this.data = res;
      },
      err => console.error(err)
    );
  }

  selectUser(user: User) {
    //debugger;
    this.data = [];
    this.user = user;

    this.responsibleEmployee = user.userName;
    this.responsibleEmployeeNTID = user.ntid;
    this.managerEmailAddress = user.emailAddress;
  }

  //to fix scroll issue after pop up

  public async closeAlertModal(frominline: boolean = false,fromnextQsoverview:boolean=false, IsSubmitClicked: boolean = false) {
    debugger;
    //console.log(document.getElementsByTagName("modal-container"));
    if (document.getElementsByTagName("modal-container").length > 1) {
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1]);
    }
    else {
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if (document.getElementsByTagName("bs-modal-backdrop").length > 0) {
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }
// Iterate through each question and uncheck the checkbox

	if (frominline)
	{
   // debugger;
    this.globaltagQuesandAnsOverView.forEach(q => {
      if (q.questionID == this.selectedQuestionInline) {
        q.checked = false;
      }
    });
    this.IsToggleDisabled = false;
    this.globaltagQuesandAnsOverView.forEach(q => {
      q.disabled = q.checked; // Disable if checked, enable if unchecked
    });
	}
 // to remove the extra resume popup in reusmemode
  if(this.tooltipOpen!==undefined){
    if(this.tooltipOpen && fromnextQsoverview) {
      this.IsToggleDisabled = false; // to disable the inline warning popup in classic mode
      this.isAnyCheckboxChecked = this.globaltagQuesandAnsOverView.some(q => q.checked);
      if (this.isAnyCheckboxChecked)
         {
          this.isSubmitClicked = IsSubmitClicked;
          this.fromnextQsoverviewResumeInline=fromnextQsoverview;
          await this.pendingTagModeStatus('Resume','frominline')

          await this.processConfirmationService.updateEventEndTime(this.eventID_Starttime,this.processConfirmation).subscribe(res => {

            console.log(res)
        }, err => { });
           console.log("At least one checkbox is checked");
          }
      else {
        console.log("No checkboxes are checked");

      }
    }
  }
   // to remove the extra resume popup in reusmemode
  $(".modal-content").removeClass("modalSize121");

  }

  public closeAlertModalSkip(process:any,event?: Event) {

    this.SkipProcess.IsSkipMandatory=true;

    if(this.SkipProcess.answer !=null){
      this.insertProcessConfirmation(this.SkipProcess,event)
    }
    else {
     return
    }

    //alert(1)
    //console.log(document.getElementsByTagName("modal-container"));
    if (document.getElementsByTagName("modal-container").length > 1) {
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1]);
    }
    else {
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if (document.getElementsByTagName("bs-modal-backdrop").length > 0) {
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }

  }


  // *******************Image atatchment selection************************
  onSelectFile(event) {
    //validate the file if file size is more than 10MB
    for (var i = 0; i < event.target.files.length; i++) {
      var name = event.target.files[i].name;
      var type = event.target.files[i].type;
      var size = event.target.files[i].size;
      var modifiedDate = event.target.files[i].lastModifiedDate;

      if (size > environment.maxFileSize) {
        this.alertText = this.labels.default.maximumFileSize;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
       // $(".modal-dialog").addClass("modalSize"); //check the fix for inline mode
       const alertDialog = document.querySelector('.modal-dialog.alert-dialog');
       if (alertDialog) {
         this.renderer.addClass(alertDialog, 'modalSize');
       }
       //warningModal
        return;
      }

    }
    // *************************validation of file size ends here**************

    // let dateFormat = require('dateformat');
    let now = new Date();
    // dateFormat(now, "dddd, mmmm dS, yyyy, h:MM:ss TT");
    // alert(dateFormat(now, "dddd, mmmm dS, yyyy, h:MM:ss TT"));
    // alert(dateFormat(now, "ddd-mm-yyyy hh-mm-ss"));
    var jstoday;
    jstoday = formatDate(now, 'dd_MM_yyyy hh_mm_ss_a', 'en-US', '+0530').toString();

    let totalSize = 0;
    if (event.target.files && event.target.files[0]) {
      var filesAmount = event.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        let name = event.target.files[i].name;

        //  ************************ validation of file Type*********************************************************************************

        // if (!name.match(/.(jpg|jpeg|png|gif|txt|pdf|doc|docx|xls|xlsx|csv|mp4)$/i)) {
        var fileTypes = environment.fileTypes.split(",").map(function (item) {
          return item.trim();
        });
        var extension = name.slice((Math.max(0, name.lastIndexOf(".")) || Infinity) + 1);
        let x = fileTypes.filter(x => x.toLocaleLowerCase() == extension.toLocaleLowerCase());

        if (x.length == 0) {
          this.alertText = name + this.labels.default.fileUploadError.replace("((FileTypes))", environment.fileTypes);
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
         // $(".modal-dialog").addClass("modalSize");//check the fix for inline mode
         const alertDialog = document.querySelector('.modal-dialog.alert-dialog');
          if (alertDialog) {
            $(".modal-content").addClass("modalSize121");
            // this.renderer.addClass(alertDialog, 'modalSize');
            this.renderer.setStyle(alertDialog, 'display', 'flex');
            this.renderer.setStyle(alertDialog, 'align-items', 'center');
            this.renderer.setStyle(alertDialog, 'justify-content', 'center');
            this.renderer.setStyle(alertDialog, 'height', '45vh');
            this.renderer.setStyle(alertDialog, 'margin', '0');
          }
          return;
        }

        //  *************************Validation Ends*****************************************************************************************
        let size = event.target.files[i].size;
        reader.onload = (event: any) => {
          this.url = new HintImage();

          this.url.imageTitle = jstoday + "_" + name;
          this.url.displayFileName = name; //adding displayname
          //console.log("600",this.url)
          this.url.size = size;
          this.url.fileContent = event.target.result;

          this.url.imagePath = event.target.path;

          if (extension == "jpg" || extension == "jpeg" || extension == "png") {
            var compressed = this.sharedService.compressImage(event.target.result, "image/jpeg", 0.5, 0.9);
            if (compressed != "data:,")
              this.url.fileContent = compressed;
          }

          for (let row of this.urls) {
            totalSize += row.size;
          }
          totalSize += size;
          if (totalSize > (environment.maxFileSize*environment.maxAttachments) || this.urls.length >= environment.maxAttachments) {
            this.alertText = name + this.labels.default.maximumFileSize;
            this.modalService.show(this.warningModal);
            $("modal-container").removeClass("fade");
            //$(".modal-dialog").addClass("modalSize");//check the fix for inline mode
            const alertDialog = document.querySelector('.modal-dialog.alert-dialog');
            if (alertDialog) {
              this.renderer.addClass(alertDialog, 'modalSize');
            }
            return;
          }
          if (this.urls == undefined) {
            this.urls = [];
          }
          this.urls.push(this.url);

        //Upload file Code
        console.log(this.urls);
        console.log(this.deviation1);
        // this.deviation = new Deviation();
         this.deviation1.hintImages=this.urls;
        this.insertIntoDeviationAttachments(this.deviation1,i,filesAmount);
        };

        reader.readAsDataURL(event.target.files[i]);
      }
    }
    // this.fileInputVariable.nativeElement.value = ""; //mk
  }
  // *************************remove attachment******************

  removeHintImage(name) {

    // let name = event.target.id;
    this.urls = this.urls.filter(x => x.imageTitle !== name);
  }

  // ******************************************Image atatchemnt end***********************************************
  onChange(isChecked: boolean) {
    //
    this.isShowVsAs = isChecked;
  }



  cancelValuestreanAndAssessorSelection() {//NOT REQUIRED
    //
    this.cancelAppendValueStreamWithOtherData = this.items.filter(
      x => x.questionID == this.selectedQuestionID
    )[0].valueStreamTemplateName +
      this.items.filter(
        x => x.questionID == this.selectedQuestionID
      )[0].delimiter +
      this.items.filter(
        x => x.questionID == this.selectedQuestionID
      )[0].valueStreamCategoryName +
      this.items.filter(
        x => x.questionID == this.selectedQuestionID
      )[0].delimiter;


    this.cancelSelectedValueStreamData = this.items.filter(
      x => x.questionID == this.selectedQuestionID
    )[0].valueStreamData;
    this.cancelSelectedAssessorName = this.items.filter(
      x => x.questionID == this.selectedQuestionID
    )[0].assessorName;

    var dataPoolID = this.items.filter(
      x => x.questionID == this.selectedQuestionID
    )[0].dataPoolID;
    if (dataPoolID) {
      this.appendValueStreamWithOtherData = this.cancelAppendValueStreamWithOtherData;
      this.selectedValueStreamData = this.cancelSelectedValueStreamData;
      this.selectedAssessorName = this.cancelSelectedAssessorName;

    } else {
      this.appendValueStreamWithOtherData = undefined;
      this.selectedValueStreamData = undefined;
      this.selectedValueStreamID = 0;
      this.selectedAssessorName = undefined;
      this.selectedAssessorID = 0;
    }

    this.closeAlertModal();
  }

  //saving valuestream and assessor selection
  saveVSAndAssessor() {
    if(this.calendarAuditID > 0)
    {
      this.assessorOnChange(event);
      this.closeAlertModal();
      return;
    }

    //

    if (!this.selectedValueStreamID || !this.selectedAssessorID) {
      if (!this.selectedValueStreamID && !this.selectedAssessorID) {
        this.alertText = name + this.labels.default.vsNameRequired + ", " + this.labels.default.assessorNameRequired;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");

      }
      else if (!this.selectedValueStreamID) {
        this.alertText = name + this.labels.default.vsNameRequired;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");

      }
      else if (!this.selectedAssessorID) {
        this.alertText = name + this.labels.default.assessorNameRequired;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
      }
      return false;
    }

    {
      var valueStreamTemplateID = this.valueStreamList.filter(
        x => x.valueStreamID == this.selectedValueStreamID
      )[0].valueStreamTemplateID;

      //append the Assessor with AssessorTemplate

      var assessorTemplateID = this.assessorList.filter(
        x => x.assessorID == this.selectedAssessorID
      )[0].assessorTemplateID;

      var updateVSAS = new UserProfileUpdateVSAS();
      updateVSAS.valueStreamID = this.selectedValueStreamID;
      updateVSAS.assessorID = this.selectedAssessorID;
      updateVSAS.assessorTemplateID = assessorTemplateID;
      updateVSAS.valueStreamTemplateID = valueStreamTemplateID;
      updateVSAS.isForgotValueStream = this.processConfirmation.isForgotValueStream;
      updateVSAS.isForgotAssessor = this.processConfirmation.isForgotAssessor;
      updateVSAS.sessionID = this.sharedService.sessionID;

      this.userProfileService.updateUserProfileVSAS(updateVSAS).subscribe(res => {

      }, err => {
        console.log(err);
      });

    }

    this.closeAlertModal();

    this.toGetTheValueStream();
    this.assessorOnChange(event);
  }

  async vsAndAssessor(contentShift, event) {
    //debugger;
    await this.getValueStreamAndAssessorList(this.selectedQuestionID, 0);//to pass the Question ID to fetch ValueStream and Assessor according to the questionID


    this.open(contentShift);
  }


  getValueStreamAndAssessorList(QuestionID: number, indexPos:number) {
    //console.log("quesnum",QuestionID,indexPos)
    this.processConfirmationService.getValueStreamByQuestionID(QuestionID).subscribe(
      res => {
        this.valueStreamList = res;
        this.onLoadValueStream();
        this.valueStreamList.forEach(x => x.FormattedValueStream = x.valueStreamTemplateName + x.delimiter + x.valueStreamName );
        //this.valueStreamList = this.valueStreamList.filter(x => x.valueStreamData && x.responsible_UserID);
        this.valueStreamList = this.valueStreamList.filter(x => x.valueStreamName);
        this.processConfirmationService.getAssessorsByQuestionID(QuestionID).subscribe(
          res => {
            this.assessorList = res;
            this.onLoadAssessor();
            this.assessorList = this.assessorList.filter(x => x.assessorName);
            this.AssignValues(indexPos);
          },
          err => console.error(err)
        );
      },
      err => console.error(err)
    );

  }

  /* selectign the valuestream and  assessor */

  valueStreamOnChange(event) {
    this.isValuestreamChanged = true;
  }

  public toGetTheValueStream(): void {
    //
//debugger;
    if (this.valueStreamList.length > 0) {
      this.selectedValueStreamData = this.valueStreamList.filter(
        x => x.valueStreamID == this.selectedValueStreamID
      )[0].valueStreamData;
      this.responsibleEmployeeID = this.valueStreamList.filter(
        x => x.valueStreamID == this.selectedValueStreamID
      )[0].responsible_UserID;

      //according to list view changed
      this.appendValueStreamWithOtherData = this.valueStreamList.filter(
        x => x.valueStreamID == this.selectedValueStreamID
      )[0].valueStreamTemplateName +
        this.valueStreamList.filter(
          x => x.valueStreamID == this.selectedValueStreamID
        )[0].delimiter +
        this.valueStreamList.filter(
          x => x.valueStreamID == this.selectedValueStreamID
        )[0].valueStreamName;

      if (this.responsibleEmployeeID) {
        this.commonService.getUserByNTID(this.responsibleEmployeeID).subscribe(res => {
          this.vsUser = res;
          if (this.vsUser != null && this.vsUser.ntid.length > 0) {
            this.selectUser(this.vsUser);
          }
        });
      }
    }
    else{
      this.responsibleEmployee = this.sharedService.responsibleEmployee_tag;
      this.managerEmailAddress = '';

    }

  }

  public toGetTheValueStream_inline(): void {
    //
//debugger;
    if (this.valueStreamList.length > 0) {
      this.selectedValueStreamData = this.valueStreamList.filter(
        x => x.valueStreamID == this.selectedValueStreamID
      )[0].valueStreamData;
      this.responsibleEmployeeID = this.valueStreamList.filter(
        x => x.valueStreamID == this.selectedValueStreamID
      )[0].responsible_UserID;

      //according to list view changed
      this.appendValueStreamWithOtherData = this.valueStreamList.filter(
        x => x.valueStreamID == this.selectedValueStreamID
      )[0].valueStreamTemplateName +
        this.valueStreamList.filter(
          x => x.valueStreamID == this.selectedValueStreamID
        )[0].delimiter +
        this.valueStreamList.filter(
          x => x.valueStreamID == this.selectedValueStreamID
        )[0].valueStreamName;

      if (this.responsibleEmployeeID) {
        this.commonService.getUserByNTID(this.responsibleEmployeeID).subscribe(res => {
          this.vsUser = res;
          if (this.vsUser != null && this.vsUser.ntid.length > 0) {
            this.selectUser(this.vsUser);
          }
        });
      }
    }
    else{
      this.responsibleEmployee = this.sharedService.responsibleEmployee_tag;
      this.managerEmailAddress = '';

    }

  }

  public assessorOnChange(event): void {
    this.selectedAssessorName = this.assessorList.filter(
      x => x.assessorID == this.selectedAssessorID
    )[0].assessorName;

  }

  SingleTextMaxChar(contentShift) {

    //alertpro+"//"+contentShift)
  console.log(this.processConfirmation.answer)
    this.singleTextmaxLength = this.singleLineText.length?this.singleLineText[0].maxCharacters:50;
  }


  MultiPleLineText(contentShift, event, oField) {

    var textLines = oField.value.substr(0, oField.selectionStart).split("\n");
    var currentLineNumber = textLines.length;

    var text = this.processConfirmation.answer;
    if (this.processConfirmation.answer) {
      var lines = text.toString().split(/\r|\r\n|\n/);
      var count = lines.length;
    }

    if ((count >= this.multiLineText[0].maxLines)) {
      this.alertText = this.labels.default.cannotTypeMoreLinesForThisQuestion + " " + this.multiLineText[0].maxLines;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      event.preventDefault();
      return;
    }
    else if ((currentLineNumber <= this.multiLineText[0].maxLines && count > this.multiLineText[0].maxLines)) {
      event.preventDefault();
      return;
    }

  }
  GetTagModeByNTID(){

    var NTID= this.sharedService.ntid;
    this.selectedTag.TagDisplayName = this.sharedService.tagDisplayName;
    this.selectedTag.TagID = this.sharedService.tagmodetagID;
  //   this.tagModeService.GetTagModeByNTID(NTID).subscribe(res=>{
  //    //console.log("726",res);
  //     this.selectedTag.TagDisplayName =res[0].tags[0].tagDisplayName;
  //     this.selectedTag.TagID=res[0].tags[0].tagID;
  //     // console.log("732",this.selectedTag);
  //   },
  //  err=> console.error(err));
  }
  keyup(num:number){
}
  TagModeSubmit () {

    console.log(this.eventID_Starttime)
    console.log(this.generatedEventID)
    //console.log("tagmodeid",this.tagModeTagID)
    //console.log("plantid",this.sharedService.plantID)
    //console.log("tagid",this.sharedService.TagModeID)
    //console.log("ntid",this.sharedService.ntid)
    this.processConfirmation.tagID =this.tagModeTagID;
    this.processConfirmation.PlantID = this.sharedService.plantID;
    this.processConfirmation.TagModeID = this.sharedService.TagModeID;
    this.processConfirmation.answeredBy_NTID = this.sharedService.ntid;
    this.processConfirmation.TagName = this.sharedService.TagName;
    if(this.sharedService.tagTypeID ==1) {
      this.processConfirmation.TagTypeName = "ProcessConfirmation" +" "+this.modeType+" "+"Mode"
    }
    if(this.sharedService.tagTypeID ==2 ){
      this.processConfirmation.TagTypeName = "Audit"+" "+this.modeType+" "+"Mode"
    }
    if(this.sharedService.tagTypeID == 3) {
      this.processConfirmation.TagTypeName = "Survey"+" "+this.modeType+" "+"Mode"
    }
    if(this.sharedService.tagTypeID ==4) {
      this.processConfirmation.TagTypeName = "Global"+" "+this.modeType+" "+"Mode"
    }
    if(this.modeType=="custom") {
    this.processConfirmation.CustomModeID = this.sharedService.CustomModeID;
    }
    this.processConfirmation.LanguageCode =this.sharedService.plantLanguageCode;
  //  console.log(this.sharedService.plantLanguageCode)
   // console.log("931",this.processConfirmation)
    //SendAuditAnswerEmail

    if((this.sharedService.SharedServiceTags.isReportingEmailDefined && this.modeType == "tag") || (this.sharedService.CustomModeReportingEmail && this.modeType == "custom") ){
      if(this.modeType== 'custom') {
        this.processConfirmation.TagModeID=0;
      }
      this.auditService.SendTagModeAnswerEmail(this.processConfirmation).subscribe(res => {
        if (res.resultCode == 0) {
          this.alertText = this.labels.default.saveSuccessfully;
          this.modalService.show(this.successModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");

        }
      }, err => { });
      this.closeAlertModal()
    }else {

        this.alertText = this.labels.default.saveSuccessfully;
        this.modalService.show(this.successModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");


   // alert("email not defined")
    }

  }

  TagModeSubmit_inline () {
  debugger;
    console.log(this.eventID_Starttime)
    console.log(this.generatedEventID)
    //console.log("tagmodeid",this.tagModeTagID)
    //console.log("plantid",this.sharedService.plantID)
    //console.log("tagid",this.sharedService.TagModeID)
    //console.log("ntid",this.sharedService.ntid)
    this.processConfirmation_inline.tagID =this.tagModeTagID;
    this.processConfirmation_inline.PlantID = this.sharedService.plantID;
    this.processConfirmation_inline.TagModeID = this.sharedService.TagModeID;
    this.processConfirmation_inline.answeredBy_NTID = this.sharedService.ntid;
    this.processConfirmation_inline.TagName = this.sharedService.TagName;
    if(this.sharedService.tagTypeID ==1) {
      this.processConfirmation_inline.TagTypeName = "ProcessConfirmation" +" "+this.modeType+" "+"Mode"
    }
    if(this.sharedService.tagTypeID ==2 ){
      this.processConfirmation_inline.TagTypeName = "Audit"+" "+this.modeType+" "+"Mode"
    }
    if(this.sharedService.tagTypeID == 3) {
      this.processConfirmation_inline.TagTypeName = "Survey"+" "+this.modeType+" "+"Mode"
    }
    if(this.sharedService.tagTypeID ==4) {
      this.processConfirmation_inline.TagTypeName = "Global"+" "+this.modeType+" "+"Mode"
    }
    if(this.modeType=="custom") {
    this.processConfirmation_inline.CustomModeID = this.sharedService.CustomModeID;
    }
    this.processConfirmation_inline.LanguageCode =this.sharedService.plantLanguageCode;
  //  console.log(this.sharedService.plantLanguageCode)
   // console.log("931",this.processConfirmation)
    //SendAuditAnswerEmail

    if((this.sharedService.SharedServiceTags.isReportingEmailDefined && this.modeType == "tag") || (this.sharedService.CustomModeReportingEmail && this.modeType == "custom") ){
      if(this.modeType== 'custom') {
        this.processConfirmation_inline.TagModeID=0;
      }
      this.auditService.SendTagModeAnswerEmail(this.processConfirmation_inline).subscribe(res => {
        if (res.resultCode == 0) {
          this.alertText = this.labels.default.saveSuccessfully;
          this.modalService.show(this.successModal);
          $("modal-container").removeClass("fade");
         // $(".modal-dialog").addClass("modalSize");
         if (this.modalRef_inline) {
          this.modalRef_inline.hide(); // Hide the modal
        }
        }
      }, err => { });
      this.closeAlertModal();
      if (this.modalRef_inline) {
        this.modalRef_inline.hide(); // Hide the modal
      }
    }else {

        this.alertText = this.labels.default.saveSuccessfully;
        this.modalService.show(this.successModal);
        $("modal-container").removeClass("fade");
       // $(".modal-dialog").addClass("modalSize");
       if (this.modalRef_inline) {
        this.modalRef_inline.hide(); // Hide the modal
      }

   // alert("email not defined")
    }

  }


  public async pendingTagModeStatus(clickststus?:string,frominline?:string): Promise<void>{
    debugger;

    if(this.modeType=="tag") {

      this.processConfirmation.TagModeID = this.sharedService.TagModeID;
      this.processConfirmation.tagID = this.sharedService.tagmodetagID;
      if (this.calendarAuditID) {

        this.processConfirmation.TagModeID = this.sharedService.calTagmodeID;
        this.processConfirmation.tagID = this.sharedService.calTagModeTagID;
        this.processConfirmation.auditID=this.calendarAuditID;
      }
    }
    else {

      this.processConfirmation.TagModeID =0;

    this.processConfirmation.tagID = 0;
    }
    this.processConfirmation.PlantID= this.sharedService.plantID;
    this.processConfirmation.AnsweredBy_NTID= this.sharedService.ntid;
    if(this.modeType=="custom") {
    this.processConfirmation.CustomModeID= this.sharedService.CustomModeID;
    }else {
      this.processConfirmation.CustomModeID=0;
    }
    if(clickststus){
      this.showPendingModal =false;
     // alert(clickststus)
      var ResumeTagProcessConfirmation  = false;
      if(clickststus=='Resume'){
        this.isResumeClicked = true;
        if(frominline=='frominline'){
          this.ResumeActivated=false
        }else {
          this.ResumeActivated=true;
        }

        this.isResumeTagSelected = true;

        this.closeAlertModal()
        if(this.calendarAuditID>0) {
          debugger
          if(this.isResumeClicked==true){
            this.processConfirmation.isResumeActivated=true;
          }else {
            this.processConfirmation.isResumeActivated=this.ResumeActivated;
          }
         await  this.getProcessConfirmation("calendarTag", this.calendarAuditID, this.selectedAssessorID, this.UserNTID, this.myTagID, this.myQuestionID, this.skipQuestionList,this.isResumeTagSelected);

        }else {
          this.IsInlineModeEnabled = false;
          debugger;
          if(this.isResumeClicked==true){
            this.processConfirmation.isResumeActivated=true;
          }else {
            this.processConfirmation.isResumeActivated=this.ResumeActivated;
          }
         await  this.getProcessConfirmation(this.modeType, this.selectedValueStreamID, this.selectedAssessorID, this.UserNTID, this.myTagID, this.myQuestionID, this.skipQuestionList,this.isResumeTagSelected);

        }
      }
      else{
        this.isResumeTagSelected = false;
        //alert('startnew')
        this.closeAlertModal()
        if(this.calendarAuditID>0) {

          await this.getProcessConfirmation("calendarTag", this.calendarAuditID, this.selectedAssessorID, this.UserNTID, this.myTagID, this.myQuestionID, this.skipQuestionList,ResumeTagProcessConfirmation);

        }else {
          await this.getProcessConfirmation(this.modeType, this.selectedValueStreamID, this.selectedAssessorID, this.UserNTID, this.myTagID, this.myQuestionID, this.skipQuestionList,ResumeTagProcessConfirmation);

        }
          }

    }else{
      //alert("pending check")
      //
      //console.log("982",this.processConfirmation)
     // debugger;
      await this.processConfirmationService
        .pendingTagModeStatus(this.processConfirmation)
        .subscribe(result => {
          // console.log("pending result", result);
          //
          if (result > 0) {
            if ((this.sharedService.SharedServiceTags.isResumeTagDefined && this.modeType == 'tag') || (this.sharedService.CustomModeResumeTag && this.modeType == "custom")) {

              this.TagModePendingStatus = true;
              this.showPendingModal = true;
              // to remove the extra resume popup in reusmemode
              if(!this.fromnextQsoverviewResumeInline)
                // to remove the extra resume popup in reusmemode
                {
                this.modalService.show(this.ResumeModal, this.config);
                $("modal-container").removeClass("fade");
              }
              }
          }
          return result;
        });
    }
    return Promise.resolve();
  }

 public async getProcessConfirmation1(modeTypename: any, valueSID: number, aID: number, NTID: string, PCTagID: number, myQuestionID: number, skipQuestionList: any[], isResumeTagSelected?:boolean,fromNext1?:boolean)
  {

    this.isLoading = true;
    // console.log("880",modeTypename)
    if (this.myTagID == undefined) {
      PCTagID = 0;
    } else {
      PCTagID = this.myTagID;
    }

   // alert(1169)

    for( let each of this.skipQuestionList) {
      // if(eachprocess.questionID == each ) {
         this.globaltagQuesandAnsOverView = this.globaltagQuesandAnsOverView.filter(function(el){
           return el.questionID !==each ;
         });
      // }
       //this.remainingQuestions=this.remainingQuestions.filter(x=>x.questionID!=each)
     // }
    }
    var res = this.globaltagQuesandAnsOverView
    this.remainingQuestions = res

   // this.ngMultiSelectSelectedTagItem=this.ngMultiSelectSelectedTagItem.filter(x=>x.tagID!==item.tagID)
   //for(let eachprocess of this.remainingQuestions) {
  //   for( let each of this.skipQuestionList) {
  //    // if(eachprocess.questionID == each ) {
  //       this.remainingQuestions = this.remainingQuestions.filter(function(el){
  //         return el.questionID !==each ;
  //       });
  //    // }
  //     //this.remainingQuestions=this.remainingQuestions.filter(x=>x.questionID!=each)
  //   // }
  //  }
        // console.log("1170",skipQuestionList)
        // console.log("1175",this.remainingQuestions)
        // console.log("process res882",res)
        //this.TargetPercentage =res[0].targetPercentage
      //  console.log("930 target percent",this.TargetPercentage)
      // console.log("928",this.remainingQuestions.TargetPercentage)
        if(this.globaltagQuesandAnsOverView.length){

       //console.log("899")
        }else {
         // alert(936)
          this.globaltagQuesandAnsOverView = res
          this.globaltagQuesandAnsOverView =this.globaltagQuesandAnsOverView.filter((value, index, self) =>
                index === self.findIndex((t) => (
                  t.questionID === value.questionID
                ))
              )
              if(this.globaltagQuesandAnsOverView.length)
                    {
                      if((this.sharedService.SharedServiceTags.isQuestionOverviewDefined && this.modeType == "tag" ) ||( this.modeType == "custom" && this.sharedService.CustomModeQuestionOverview)){
                      this.questionOverView()
                      }
                    }
          //console.log("936", this.globaltagQuesandAnsOverView)
        }


          //this.questionOverView('temp','config')
        //  console.log("894",this.globaltagQuesandAnsOverView)
        //console.log(this.modeType)
        //console.log(this.processConfirmation.modeType)

        //console.log("type name",this.modeType)
        this.items = [];
        this.isLoading = false;

        if (res && res.length > 0)//checking whether Questions are in list or not.Or tag is linked with any questions or not
        {
          this.flagQuestionLoaded = true;

          if (res.length == 1 && res[0].questionID == -1)//checking whether user profile settings or not
          {
            this.alertText = this.labels.default.profileSettingError;
            this.modalService.show(this.warningModal);
            $("modal-container").removeClass("fade");
            $(".modal-dialog").addClass("modalSize");
            this.router.navigate([environment.home + "/userProfile/"]);
            return;
          }
        }
        else {
          alert("no ques")

          if ((this.modeType == "tag"||this.modeType == "custom")  && this.flagQuestionLoaded) {
           // console.log("929")

           if((this.modeType == "tag")) {
           
            this.processConfirmationService.updateEventEndTime
            (this.eventID_Starttime,this.processConfirmation).subscribe(res => {

              console.log(res)
          }, err => { });
           }

            if((this.sharedService.SharedServiceTags.isResultOverviewDefined && this.modeType == "tag") || ( this.sharedService.CustomModeAnswerOverView && this.modeType == "custom"  )) {
              console.log("1276")

              console.log(this.eventID_Starttime)
              console.log("endtime PC",this.processConfirmation)
            //   this.processConfirmationService.updateEventEndTime
            //   (this.eventID_Starttime,this.processConfirmation).subscribe(res => {

            //     console.log(res)
            // }, err => { });


              this.answerOverView(this.eventID_Starttime)
             }else if((this.sharedService.SharedServiceTags.isReportingEmailDefined && this.modeType == "tag") || (this.sharedService.CustomModeReportingEmail && this.modeType == "custom") )
              {
              //alert(1)

            //   this.alertText = this.labels.default.tagmodeansweOverViewDisable;

            //  this.modalService.show(this.successModal);
              this.answerOverView1(this.eventID_Starttime)
             }
              this.alertText = this.labels.default.EndOfTagModeQuestionList;

             this.modalService.show(this.successModal);
          }
          else if(this.flagQuestionLoaded)
          {
            //alert("1151")
            this.alertText = this.labels.default.allQuestionAnswered;
            this.modalService.show(this.successModal);
          }
          else {

           // alert("1156")
            //console.log("")
            //this.noqueslink= true;
            this.alertText = this.labels.default.allQuestionAnswered;
            this.modalService.show(this.warningModal);
            console.log(this.alertText)

          }
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          this.router.navigate([environment.home + "/dashboard/"]);
          return;
        }

        this.isValuestreamChanged = false; // to check whther valuestream chanegs or not while selecting from dropdown
        {
          for (var i = 0; i < res.length; i++) {
            if (this.skipQuestionList.indexOf(res[i].questionID) === -1) {
              this.items.push(res[i]);
            }
          }
          if (this.items == null || this.items.length == 0) {
            if (this.modeType == "tag") {
             // console.log("946",this.modeType)
              this.alertText = this.labels.default.EndOfTagModeQuestionList;
              this.modalService.show(this.successModal);
              $("modal-container").removeClass("fade");
              $(".modal-dialog").addClass("modalSize");
            }
            this.router.navigate([environment.home + "/dashboard/"]);
          }
          else  {
            this.processConfirmation = this.items[0];
            this.CustomSkip=false;
            //console.log("957",this.modeType)
          // console.log("954",this.CustomSkip)
            //console.log("787",this.processConfirmation.tagIDList)
            let tagarr=[]
            if(this.processConfirmation.tagIDList){
              tagarr = this.processConfirmation.tagIDList.split(',')
            }
            // console.log("955",tagarr)
            // console.log("962",this.sharedService)
            // console.log("963",this.modeType)
            if(this.modeType =='custom'){
              for(let i=0;i<tagarr.length;i++) {
                //console.log("958",tagarr[i])
                for(let j=0;j<this.sharedService.SkipDisabledCustomTags.length;j++) {
                 // console.log("960",this.sharedService.SkipDisabledCustomTags[j])
                  console.log(Number(tagarr[i]))
                  if(this.sharedService.SkipDisabledCustomTags[j]  == Number(tagarr[i]) )
                  this.CustomSkip=true
                  break;
                }
                if(this.CustomSkip) {
                  break;
                }
              }
            }
            // console.log("974",this.CustomSkip)
            // console.log("754",this.sharedService.SkipDisabledCustomTags)

          }
        }

        if (this.items[0] != null) {
          this.selectedQuestionID = this.items[0].questionID;
          this.selectedQuestionDisplayID = this.items[0].questionDisplayID;
          this.processConfirmation = this.items[0];

        //  console.log("796",this.processConfirmation)
         // await this.getValueStreamAndAssessorList(this.selectedQuestionID, 0);//to pass the Question ID to fetch ValueStream and Assessor according to the questionID
          this.activeItem = this.items[0].questionText;
          this.myAnswerID = this.items[0].answerType_AnswerTypeID;
          var dataPoolID = this.items[0].dataPoolID;


          // retaining the vs and assessor for first question in process confirmation
          if (dataPoolID && this.processConfirmation.isShowVsAs == false) {//if question is already answered
            this.selectedValueStreamID = this.items[0].valueStreamID;//to bind with vs drodown
            this.appendValueStreamWithOtherData = this.items[0].valueStreamTemplateName +
              this.items[0].delimiter +
              this.items[0].valueStreamName;

            this.selectedAssessorName = this.items[0].assessorName;
            this.selectedAssessorID = this.items[0].assessorID;
            this.appendAssessorWithOtherData = this.items[0].assessortemplate;
          }
          // ***************************************************************************


          if (this.processConfirmation.isCustomMode == true) {
            this.buttonColor = "yellow"; //desired Color
          }

          if (this.processConfirmation.answerType_AnswerTypeID == 3 || this.myAnswerID == 3) {
            var questionId=this.processConfirmation.questionID
            await this.questionService
              //.getChoicesByQuestionID(questionId)
              .getChoicesByQuestionID_new(questionId)
              .subscribe(
                res => {
                  //debugger;
                  this.choices = res;

                  if(this.processConfirmation.answer){
                    for(let i=0;i<this.choices.length;i++){
                    if(this.processConfirmation.choiceID == this.choices[i].choiceID || this.processConfirmation.defaultChoiceID == this.choices[i].choiceID) {
                      this.processConfirmation.choiceID = this.choices[i].choiceID
                      if (this.choices[i].deviationTypeID > 1) {
                        this.isDeviationEntryRequired = true;
                        this.deviationDescription= this.processConfirmation.deviationDescription;
                        this.toGetTheValueStream();
                      }
                      else {
                        this.isDeviationEntryRequired = false;
                        this.deviation = new Deviation();
                        this.deviationDescription = undefined;
                        this.responsibleEmployee = undefined;
                      }
                      return;
                    }
                  }
                  }else{
                    if (this.processConfirmation.isDefaultAnswerRequired) {
                      this.processConfirmation.choiceID = this.processConfirmation.defaultChoiceID;// for default asnwer
                      this.choiceSelectionChange(this.processConfirmation.choiceID);
                    }
                    if (this.choices) {
                      this.ImageSplit();
                    }
                   }

                },
                err => {
                  console.log(err);
                  //alert(499)
                 // this.sharedService.show();
                //  setTimeout(() => {
                //   this.fallbackgetchoice(questionId);
                // }, 300);
                }
              );
          }

          // ****************************** if answertype is SingleLineText******************************

          else if (this.processConfirmation.answerType_AnswerTypeID == 1 || this.myAnswerID == 1) {
            await this.questionService
              .singleLineTextByQuestionID(this.processConfirmation.questionID)
              .subscribe(
                res => {
                  this.singleLineText = res;

                  if(this.processConfirmation.answer){
                  console.log("1141")
                  }else{
                    this.processConfirmation.answer = this.singleLineText[0].defaultValue;// for default asnwer
                  if (this.singleLineText) {
                    this.ImageSplit();
                  }
                  }

                },
                err => {
                  console.log(err);
                }
              );
          }

          // ************************single line text ends********************

          // ****************************** if answertype is MultiLineTExt******************************

          else if (this.processConfirmation.answerType_AnswerTypeID == 2 || this.myAnswerID == 2) {
            await this.questionService
              .multipleLinesTextByQuestionID(this.processConfirmation.questionID)
              .subscribe(
                res => {
                  this.multiLineText = res;
                  if (this.multiLineText) {
                    this.ImageSplit();
                  }
                },
                err => {
                  console.log(err);
                }
              );
          }
          // ************************Multi line etxt ends********************

        }

        if((this.sharedService.SharedServiceTags.isProgressPercentageDefined && this.modeType == "tag") || (this.sharedService.CustomModeProgressPercentage && this.modeType == "custom")) {

           this.calculatePercentage()
        }



  }//end of GetProcessConfirmation

  async fallbackgetchoice(questionID) {

    await this.questionService
    .getChoicesByQuestionID(questionID)
    .subscribe(
      res => {
        this.choices = res;

        if(this.processConfirmation.answer){
          for(let i=0;i<this.choices.length;i++){
          if(this.processConfirmation.defaultChoiceID == this.choices[i].choiceID || this.processConfirmation.choiceID == this.choices[i].choiceID) {
            this.processConfirmation.choiceID = this.choices[i].choiceID
            if (this.choices[i].deviationTypeID > 1) {
              this.isDeviationEntryRequired = true;
              this.deviationDescription= this.processConfirmation.deviationDescription;
              this.toGetTheValueStream();
            }
            else {
              this.isDeviationEntryRequired = false;
              this.deviation = new Deviation();
              this.deviationDescription = undefined;
              this.responsibleEmployee = undefined;
            }
            return;
          }
        }
        }else{
          if (this.processConfirmation.isDefaultAnswerRequired) {
            this.processConfirmation.choiceID = this.processConfirmation.defaultChoiceID;// for default asnwer
            this.choiceSelectionChange(this.processConfirmation.choiceID);
          }
          if (this.choices) {
            this.ImageSplit();
          }
         }
         //this.sharedService.hide();
      },
      err => {
        console.log(err);
       // this.sharedService.hide();
      }

    );
  }

  public async getProcessConfirmation(modeTypename: any, valueSID: number, aID: number, NTID: string, PCTagID: number, myQuestionID: number, skipQuestionList: any[], isResumeTagSelected?:boolean): Promise<void> {
        this.isLoading = true;
       //// debugger;
    // console.log("880",modeTypename)
    if (this.myTagID == undefined) {
      PCTagID = 0;
    } else {
      PCTagID = this.myTagID;
    }

    await this.processConfirmationService
      .getProcessConfirmation(modeTypename, valueSID, aID, NTID, PCTagID, myQuestionID, skipQuestionList,isResumeTagSelected)
      .subscribe(async res => {
        debugger;
        this.IsFirstinsertProcess=true;
        this.selectedTag.TagDisplayName=this.sharedService.tagDisplayName
        console.log("1471",res)
        if(this.modeType!='shuffle'){
        await this.pendingTagModeStatus()
        }
        res =res.filter((value, index, self) =>
        index === self.findIndex((t) => (
          t.questionID === value.questionID
        ))
      )

      //UnAnswered Question
      if (this.isSubmitClicked)
        {
          console.log('UnAnswered Qs: Before',res);
          if (res != null)
            {
              res = res.filter(item =>
                !(item.answer || item.choiceID)
              );
              console.log('UnAnswered Qs: After',res);
            }
        }
       //End


      //for reordering the Questionovervew pop up when clcik next from question overvoew with inline mode answer
      if(this.tooltipOpen && this.isAnyCheckboxChecked) {
       // debugger;
        console.log("1976")
        // Sorting secondArray based on the order in firstArray
        res.sort((a, b) => this.orderMap[a.questionID] - this.orderMap[b.questionID]);
      }else {
        //to get the initial oreder of question to compare the original order
       // debugger;
        console.log("1979")
        this.orderMap = res.reduce((map, item, index) => {
          map[item.questionID] = index;
          return map;
        }, {});
      }

          if(this.globaltagQuesandAnsOverProcess.length && isResumeTagSelected){
            //alert("new assign")
            this.globaltagQuesandAnsOverView =res
            this.globaltagQuesandAnsOverViewResumeCheck= JSON.parse(JSON.stringify(res))

          }

          if (isResumeTagSelected && this.modeType == "tag" )
            {
              this.IsInlineModeEnabled = false;
            }
        console.log("process res882",res)
        this.remainingQuestions = res
        //this.TargetPercentage =res[0].targetPercentage
      //  console.log("930 target percent",this.TargetPercentage)
      // console.log("928",this.remainingQuestions.TargetPercentage)
        if(this.globaltagQuesandAnsOverView.length){

       //console.log("899")
        }else {
           //alert(936)

         // alert(936)
          this.globaltagQuesandAnsOverView = res
          this.globaltagQuesandAnsOverView =this.globaltagQuesandAnsOverView.filter((value, index, self) =>
                index === self.findIndex((t) => (
                  t.questionID === value.questionID
                ))
              )
             this.globaltagQuesandAnsOverProcess = JSON.parse(JSON.stringify(this.globaltagQuesandAnsOverView))
              if(this.globaltagQuesandAnsOverView.length)
                    {
                      if((this.sharedService.SharedServiceTags.isQuestionOverviewDefined && this.modeType == "tag" ) ||( this.modeType == "custom" && this.sharedService.CustomModeQuestionOverview)){
                      this.questionOverView()
                      }
                    }
          //console.log("936", this.globaltagQuesandAnsOverView)
        }


          //this.questionOverView('temp','config')
        //  console.log("894",this.globaltagQuesandAnsOverView)
        //console.log(this.modeType)
        //console.log(this.processConfirmation.modeType)

        //console.log("type name",this.modeType)
        this.items = [];
        this.isLoading = false;

        if (res && res.length > 0)//checking whether Questions are in list or not.Or tag is linked with any questions or not
        {
          //debugger;
          this.flagQuestionLoaded = true;

          if (res.length == 1 && res[0].questionID == -1)//checking whether user profile settings or not
          {
            this.alertText = this.labels.default.profileSettingError;
            this.modalService.show(this.warningModal);
            $("modal-container").removeClass("fade");
            $(".modal-dialog").addClass("modalSize");
            this.router.navigate([environment.home + "/userProfile/"]);
            return;
          }
        }
        else {
          //alert("no ques")

          if ((this.modeType == "tag"||this.modeType == "custom")  && this.flagQuestionLoaded) {
           // console.log("929")

            if((this.sharedService.SharedServiceTags.isResultOverviewDefined && this.modeType == "tag") || ( this.sharedService.CustomModeAnswerOverView && this.modeType == "custom"  )) {
             this.answerOverView()
             }else if((this.sharedService.SharedServiceTags.isReportingEmailDefined && this.modeType == "tag") || (this.sharedService.CustomModeReportingEmail && this.modeType == "custom") )
              {
              //alert(1)

            //   this.alertText = this.labels.default.tagmodeansweOverViewDisable;

            //  this.modalService.show(this.successModal);
              this.answerOverView1()
             }
              this.alertText = this.labels.default.EndOfTagModeQuestionList;

             this.modalService.show(this.successModal);
          }
          else if(this.flagQuestionLoaded)
          {
            //alert("1151")
            this.alertText = this.labels.default.allQuestionAnswered;
            this.modalService.show(this.successModal);
          }
          else {

           // alert("1156")
            //console.log("")
            //this.noqueslink= true;
            this.alertText = this.labels.default.allQuestionAnswered;
            this.modalService.show(this.warningModal);
            console.log(this.alertText)

          }
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          this.router.navigate([environment.home + "/dashboard/"]);
          return;
        }

        this.isValuestreamChanged = false; // to check whther valuestream chanegs or not while selecting from dropdown
        {
          for (var i = 0; i < res.length; i++) {
            if (this.skipQuestionList.indexOf(res[i].questionID) === -1) {
              this.items.push(res[i]);
            }
          }
          if (this.items == null || this.items.length == 0) {
            if (this.modeType == "tag") {

              this.alertText = this.labels.default.EndOfTagModeQuestionList;
              this.modalService.show(this.successModal);
              $("modal-container").removeClass("fade");
              $(".modal-dialog").addClass("modalSize");
            }
            this.router.navigate([environment.home + "/dashboard/"]);
          }
          else  {
            this.processConfirmation = this.items[0];
            this.CustomSkip=false;
            let tagarr=[]
            if(this.processConfirmation.tagIDList){
              tagarr = this.processConfirmation.tagIDList.split(',')
            }

            if(this.modeType =='custom'){
              for(let i=0;i<tagarr.length;i++) {
                //console.log("958",tagarr[i])
                for(let j=0;j<this.sharedService.SkipDisabledCustomTags.length;j++) {
                 // console.log("960",this.sharedService.SkipDisabledCustomTags[j])
                  console.log(Number(tagarr[i]))
                  if(this.sharedService.SkipDisabledCustomTags[j]  == Number(tagarr[i]) )
                  this.CustomSkip=true
                  break;
                }
                if(this.CustomSkip) {
                  break;
                }
              }
            }
            // console.log("974",this.CustomSkip)
            // console.log("754",this.sharedService.SkipDisabledCustomTags)

          }
        }

        if (this.items[0] != null) {
         // debugger;
          this.responsibleEmployee = this.items[0].responsibleEmployee;
          this.valueStreamName = this.items[0].valueStreamName;
          this.tagId_Insert = this.items[0].tagID;
          this.sharedService.responsibleEmployee_tag = this.items[0].responsibleEmployee;
          console.log(this.responsibleEmployee);
          this.selectedQuestionID = this.items[0].questionID;
          this.selectedQuestionDisplayID = this.items[0].questionDisplayID;
          this.processConfirmation = this.items[0];
          this.inlineAnswerCount = this.processConfirmation.inlinecount;
          this.IsInlineModeEnabled = this.processConfirmation.inLineActivated;
         // console.log("796",this.processConfirmation)
        // await this.getValueStreamAndAssessorList(this.selectedQuestionID, 0);//to pass the Question ID to fetch ValueStream and Assessor according to the questionID
          this.activeItem = this.items[0].questionText;
          this.myAnswerID = this.items[0].answerType_AnswerTypeID;
          var dataPoolID = this.items[0].dataPoolID;

          if (this.modeType =='custom' || this.modeType =='shuffle')
          {
            this.selectedValueStreamID = this.items[0].valueStreamID;//to bind with vs drodown
            this.appendValueStreamWithOtherData = this.items[0].valueStreamTemplateName +
              this.items[0].delimiter +
              this.items[0].valueStreamName;

            this.selectedAssessorName = this.items[0].assessorName;
            this.selectedAssessorID = this.items[0].assessorID;
            this.appendAssessorWithOtherData = this.items[0].assessortemplate;
          }

          // retaining the vs and assessor for first question in process confirmation
          if (dataPoolID && this.processConfirmation.isShowVsAs == false) {//if question is already answered
            this.selectedValueStreamID = this.items[0].valueStreamID;//to bind with vs drodown
            this.appendValueStreamWithOtherData = this.items[0].valueStreamTemplateName +
              this.items[0].delimiter +
              this.items[0].valueStreamName;

            this.selectedAssessorName = this.items[0].assessorName;
            this.selectedAssessorID = this.items[0].assessorID;
            this.appendAssessorWithOtherData = this.items[0].assessortemplate;
          }
          // ***************************************************************************


          if (this.processConfirmation.isCustomMode == true) {
            this.buttonColor = "yellow"; //desired Color
          }

          if (this.processConfirmation.answerType_AnswerTypeID == 3 || this.myAnswerID == 3) {
				await this.getDropDownChoices();
            // var questionID = this.processConfirmation.questionID
             // await this.questionService
              // // .getChoicesByQuestionID(questionID)
              // .getChoicesByQuestionID_new(questionID)
              // .subscribe(
                // res => {
                  // //debugger;
                  // this.choices = res;

                  // if(this.processConfirmation.answer){
                    // for(let i=0;i<this.choices.length;i++){
                    // if(this.processConfirmation.defaultChoiceID == this.choices[i].choiceID || this.processConfirmation.choiceID == this.choices[i].choiceID) {
                      // this.processConfirmation.choiceID = this.choices[i].choiceID
                      // if (this.choices[i].deviationTypeID > 1) {
                        // this.isDeviationEntryRequired = true;
                        // this.deviationDescription= this.processConfirmation.deviationDescription;
                        // this.toGetTheValueStream();
                      // }
                      // else {
                        // this.isDeviationEntryRequired = false;
                        // this.deviation = new Deviation();
                        // this.deviationDescription = undefined;
                        // this.responsibleEmployee = undefined;
                      // }
                      // return;
                    // }
                  // }
                  // }else{
                    // if (this.processConfirmation.isDefaultAnswerRequired) {
                      // this.processConfirmation.choiceID = this.processConfirmation.defaultChoiceID;// for default asnwer
                      // this.choiceSelectionChange(this.processConfirmation.choiceID);
                    // }
                    // if (this.choices) {
                      // this.ImageSplit();
                    // }
                   // }

                // },
                // err => {
                  // console.log(err);
                  // //alert(4992)
                  // //this.sharedService.show();
                  // // setTimeout(async () => {
                  // //   await this.fallbackgetchoice(questionID);
                  // // }, 300);

                     // }
              // );
          }

          // ****************************** if answertype is SingleLineText******************************

          else if (this.processConfirmation.answerType_AnswerTypeID == 1 || this.myAnswerID == 1) {
				await this.getSingleLinetextdata();
            // await this.questionService
              // .singleLineTextByQuestionID(this.processConfirmation.questionID)
              // .subscribe(
                // res => {
                  // this.singleLineText = res;

                  // if(this.processConfirmation.answer){
                  // console.log("1141")
                  // }else{
                    // this.processConfirmation.answer = this.singleLineText[0].defaultValue;// for default asnwer
                  // if (this.singleLineText) {
                    // this.ImageSplit();
                  // }
                  // }

                // },
                // err => {
                  // console.log(err);
                // }
              // );
          }

          // ************************single line text ends********************

          // ****************************** if answertype is MultiLineTExt******************************

          else if (this.processConfirmation.answerType_AnswerTypeID == 2 || this.myAnswerID == 2) {
			await this.getMultiLineTextdata();
           // await this.questionService
              // .multipleLinesTextByQuestionID(this.processConfirmation.questionID)
              // .subscribe(
                // res => {
                  // this.multiLineText = res;
                  // if (this.multiLineText) {
                    // this.ImageSplit();
                  // }
                // },
                // err => {
                  // console.log(err);
                // }
              // );
          }
          // ************************Multi line etxt ends********************

        }

        if((this.sharedService.SharedServiceTags.isProgressPercentageDefined && this.modeType == "tag") || (this.sharedService.CustomModeProgressPercentage && this.modeType == "custom")) {
          this.calculatePercentage()
        }
       // debugger;
        this.onToggleChange(true);

      },
      err => {
        this.isLoading = false;
      });

      $(".rb-core-back-to-top-button").click();

  }//end of GetProcessConfirmation

  private async getMultiLineTextdata() {
    await this.questionService
      .multipleLinesTextByQuestionID(this.processConfirmation.questionID)
      .subscribe(
        res => {
          this.multiLineText = res;
          if (this.multiLineText) {
            this.ImageSplit();
          }
        },
        err => {
          console.log(err);
        }
      );
  }

  private async getSingleLinetextdata() {
    await this.questionService
      .singleLineTextByQuestionID(this.processConfirmation.questionID)
      .subscribe(
        res => {
          this.singleLineText = res;

          if (this.processConfirmation.answer) {
            console.log("1141");
          } else {
            this.processConfirmation.answer = this.singleLineText[0].defaultValue; // for default asnwer
            if (this.singleLineText) {
              this.ImageSplit();
            }
          }

        },
        err => {
          console.log(err);
        }
      );
  }

  private async getDropDownChoices() {
    var questionID = this.processConfirmation.questionID;
    await this.questionService
      // .getChoicesByQuestionID(questionID)
      .getChoicesByQuestionID_new(questionID)
      .subscribe(
        res => {
          //debugger;
          this.choices = res;

          if (this.processConfirmation.answer) {
            for (let i = 0; i < this.choices.length; i++) {
              if (this.processConfirmation.defaultChoiceID == this.choices[i].choiceID || this.processConfirmation.choiceID == this.choices[i].choiceID) {
                this.processConfirmation.choiceID = this.choices[i].choiceID;
                if (this.choices[i].deviationTypeID > 1) {
                  this.isDeviationEntryRequired = true;
                  this.deviationDescription = this.processConfirmation.deviationDescription;
                  this.toGetTheValueStream();
                }
                else {
                  this.isDeviationEntryRequired = false;
                  this.deviation = new Deviation();
                  this.deviationDescription = undefined;
                  this.responsibleEmployee = undefined;
                }
                return;
              }
            }
          } else {
            if (this.processConfirmation.isDefaultAnswerRequired) {
              this.processConfirmation.choiceID = this.processConfirmation.defaultChoiceID; // for default asnwer
              this.choiceSelectionChange(this.processConfirmation.choiceID);
            }
            if (this.choices) {
              this.ImageSplit();
            }
          }

        },
        err => {
          console.log(err);
        }
      );
  }

  public async  selectOptionChange_inline1()
  {
    if(this.choices_inline == undefined || this.choices_inline == null || this.choices_inline.length == 0){
      this.isshowLoadingchoice = true;
    console.log("onclicking dropdown",this.choices_inline);
     await this.getDropDownChoices_inline();
    }
    if(this.choices_inline.length >0){
      this.isshowLoadingchoice = false;
    }

    console.log("onclicking dropdown",this.choices_inline);
    }
  private async getDropDownChoices_inline() {
    //debugger;

    //var questionID = this.processConfirmation.questionID;
    var questionID = this.processConfirmation_inline.questionID;
    await this.questionService
      // .getChoicesByQuestionID(questionID)
      .getChoicesByQuestionID_new(questionID)
      .subscribe(
        res => {
          //debugger;

          console.log(res,"choice res")

          if(res.length==0){
            console.log("no data in chcoe")
          }
         // this.choices = res;
          this.choices_inline = res;
          this.isshowLoadingchoice = false;
          if (this.processConfirmation_inline.answer) {
            for (let i = 0; i < this.choices_inline.length; i++) {
              if (this.processConfirmation_inline.defaultChoiceID == this.choices_inline[i].choiceID || this.processConfirmation_inline.choiceID == this.choices_inline[i].choiceID) {
                this.processConfirmation_inline.choiceID = this.choices_inline[i].choiceID;
                if (this.choices_inline[i].deviationTypeID > 1) {
                  this.isDeviationEntryRequired_inline = true;
                  this.deviationDescription_inline = this.processConfirmation_inline.deviationDescription;
                  this.toGetTheValueStream_inline();
                }
                else {
                  this.isDeviationEntryRequired_inline = false;
                  this.isshowLoadingchoice=false;
                  this.deviation_inline = new Deviation();
                  this.deviationDescription_inline = undefined;
                  this.responsibleEmployee_inline = undefined;
                }
                return;
              }
            }
          } else {
            this.isshowLoadingchoice=false;
            if (this.processConfirmation_inline.isDefaultAnswerRequired) {
              this.processConfirmation_inline.choiceID = this.processConfirmation_inline.defaultChoiceID; // for default asnwer
              this.choiceSelectionChange_inline(this.processConfirmation_inline.choiceID);
            }
            if (this.choices_inline) {
              this.ImageSplit_inline();
            }
          }

        },
        err => {
          console.log(err);
          //this.isshowLoadingchoice=false;
        }
      );
  }

  private async getSingleLinetextdata_inline() {
    await this.questionService
      .singleLineTextByQuestionID(this.processConfirmation.questionID)
      .subscribe(
        res => {
          this.singleLineText = res;

          if (this.processConfirmation.answer) {
            console.log("1141");
          } else {
            this.processConfirmation.answer = this.singleLineText[0].defaultValue; // for default asnwer
            if (this.singleLineText) {
              this.ImageSplit();
            }
          }

        },
        err => {
          console.log(err);
        }
      );
  }

  private async getMultiLineTextdata_inline() {
    await this.questionService
      .multipleLinesTextByQuestionID(this.processConfirmation.questionID)
      .subscribe(
        res => {
          this.multiLineText = res;
          if (this.multiLineText) {
            this.ImageSplit();
          }
        },
        err => {
          console.log(err);
        }
      );
  }


  //copied from Display Image part
  ImageSplit() {
    this.displayList = new Array();
    this.titleList = new Array();
    if (this.processConfirmation.displayFileName || this.processConfirmation.imageTitle) {
      this.displayList = this.processConfirmation.displayFileName.split(',');
      this.titleList = this.processConfirmation.imageTitle.split(',');
    }

    this.IsSubmit = false;
    $(".rb-core-back-to-top-button").click();
  }

 ImageSplit_inline() {
    this.displayList = new Array();
    this.titleList = new Array();
    if (this.processConfirmation.displayFileName || this.processConfirmation.imageTitle) {
      this.displayList = this.processConfirmation.displayFileName.split(',');
      this.titleList = this.processConfirmation.imageTitle.split(',');
    }

    this.IsSubmit = false;
    $(".rb-core-back-to-top-button").click();
  }

  setLabelMessage: string;

  messageSet(message: string) {
    this.showModal();
    if (message == 'nyellow') {
      this.setLabelMessage = this.labels.default.warningQuestion;
    }
    if (message == 'yellow') {
      this.setLabelMessage = this.labels.default.deleteQuestion;
    }
  }

  addToCustomMode(processConfirmation: ProcessConfirmation) {
    this.selectedChoiceID = processConfirmation.choiceID;
    this.processConfirmation.AnsweredBy_NTID = this.sharedService.ntid;
    if (this.newIndex == undefined) {
      this.processConfirmation = this.items[0];
     // console.log("923",this.processConfirmation)
    } else {
      this.processConfirmation = this.items[this.newIndex];
      //console.log("926",this.processConfirmation)
    }

    if (this.buttonColor == "yellow") {
      this.processConfirmationService
        .deleteFromCustomMode(this.processConfirmation)
        .subscribe(res => {
          this.closeModal();
          this.alertText = this.labels.default.deleteSuccessfully;
          this.modalService.show(this.successModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
        });
      this.buttonColor = "white";
    }
    else {
      this.count++;
      this.buttonColor = "yellow"; //desired Color
      this.processConfirmationService
        .addToCustomMode(processConfirmation)
        .subscribe(res => {
          this.closeModal();
          this.alertText = this.labels.default.insertedSuccessfully;
          this.modalService.show(this.successModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
        });
    }
  }

  // clear the previous selected deviation
  clearDeviation() {
    this.deviation = new Deviation();
    this.deviationDescription = undefined;
    this.responsibleEmployee = undefined;
    this.requiredAttendees=[];
    this.ngMultiSelectSelectedTagItem=undefined;
    this.duedate.datecount=this.finalDate;;
    this.urls = [];
    this.deviationTypeID = 0;
    this.choices = [];
    this.isDeviationEntryRequired = false;
    this.additionalInfoyes=false;
  }
  clearDeviation_inline() {
    this.deviation_inline = new Deviation();
    this.deviationDescription_inline = undefined;
    this.responsibleEmployee_inline = undefined;
    this.requiredAttendees_inline=[];
    this.ngMultiSelectSelectedTagItem_inline=undefined;
    this.duedate.datecount=this.finalDate;;
    this.urls = [];
    this.deviationTypeID_inline = 0;
    this.choices_inline = [];
    this.isDeviationEntryRequired_inline = false;
    this.additionalInfoyes_inline=false;
  }

  public  insertProcessConfirmation(processConfirmation: ProcessConfirmation, event?: Event) {
    event.preventDefault(); // Prevent the default form submission
    event.stopPropagation(); // Stop further event propagation if necessary
    console.log('Button clicked, method executed');
    // alert(1)
    // alert(processConfirmation.answer)
   // debugger;
    processConfirmation.process_eventID_Starttime=this.eventID_Starttime;
    processConfirmation.generatedEventID=this.generatedEventID;
    processConfirmation.IsFirstinsertProcessConfirmation = this.IsFirstinsertProcess;

      // if (this.selectedValueStreamData == undefined ||this.selectedValueStreamData == "" ) {
    if (this.selectedValueStreamID == undefined || this.selectedValueStreamID == 0) {
      this.alertText = this.labels.default.vsCannotEmpty;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      return;
    }
    if (this.selectedAssessorName == undefined || this.selectedAssessorName == "") {
      this.alertText = this.labels.default.assessorCannotEmpty;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      return;
    }

    //validation for empty answer field
    if (!processConfirmation.answer && !processConfirmation.choiceID) {
      //alert(2008)
      this.alertText = this.labels.default.requireAnswer;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      return;
    }

    this.selectedChoiceID = processConfirmation.choiceID;
    if (this.newIndex == undefined) {
      this.processConfirmation = this.items[0];
     // console.log("997",this.processConfirmation)
    } else {
      this.processConfirmation = this.items[this.newIndex];
     // console.log("1000",this.processConfirmation)
    }

    if (this.modeType == "shuffle") {
      this.processConfirmation.modeTypeID = 1;
    } else if (this.modeType == "custom") {
      this.processConfirmation.modeTypeID = 2;
    } else {
      this.processConfirmation.modeTypeID = 3;
      this.processConfirmation.tagID = 0;
      if (this.tagModeTagID > 0 ) {
        this.processConfirmation.tagID = this.tagModeTagID;
      }
      if(this.tagId_Insert > 0)
      {
        this.processConfirmation.tagID = this.tagId_Insert;
      }
    }

    this.processConfirmation.valueStreamID = this.selectedValueStreamID;
    this.processConfirmation.assessorID = this.selectedAssessorID;
    this.processConfirmation.AnsweredBy_NTID = this.sharedService.ntid;
    if(this.modeType=="custom") {
      this.processConfirmation.CustomModeID = this.sharedService.CustomModeID;

    }
    //this.processConfirmation.choiceID = this.selectedChoiceID;

    this.processConfirmation.hintImages = this.urls;

    //
    this.processConfirmation.isShowVsAs = this.isShowVsAs;

    // if (this.processConfirmation.answerType_AnswerTypeID == 3 || this.myAnswerID==3) {
    if (this.myAnswerID == 3) {
      //
      this.processConfirmation.answer = this.choices.filter(
        x => x.choiceID == this.processConfirmation.choiceID
      )[0].choiceName;
      this.processConfirmation.obtainedScore = this.choices.filter(
        x => x.choiceID == this.processConfirmation.choiceID
      )[0].choiceScore;
      if (this.isDeviationEntryRequired) {
        if ((!this.deviationDescription || !this.processConfirmation.valueStreamID) && (this.deviationTypeID == 2 || this.deviationTypeID == 3 || this.deviationTypeID==5)) {
          if (!this.processConfirmation.valueStreamID && !this.deviationDescription) {
            this.alertText = this.labels.default.devivationFieldMandatory;
            this.modalService.show(this.warningModal);
            $("modal-container").removeClass("fade");
            $(".modal-dialog").addClass("modalSize");
          }
          else if (!this.processConfirmation.valueStreamID) {
            this.alertText = this.labels.default.selectValueStream;
            this.modalService.show(this.warningModal);
            $("modal-container").removeClass("fade");
            $(".modal-dialog").addClass("modalSize");
          }
          else if (!this.deviationDescription) {
            this.alertText = this.labels.default.fillDeviationOnly;
            this.modalService.show(this.warningModal);
            $("modal-container").removeClass("fade");
            $(".modal-dialog").addClass("modalSize");
          }
          // else if (!this.responsibleEmployee) {
          //   this.alertText = this.labels.default.searchEmployee;
          //   this.modalService.show(this.warningModal);
          //   $("modal-container").removeClass("fade");
          //   $(".modal-dialog").addClass("modalSize");
          // }
          return false;
        }
        // if(this.modeType == "tag") {
        //   let text =  this.selectedTag.TagDisplayName
        //   this.deviation.selectedtag = text
        //  // this.deviationDescription = this.deviationDescription + text.
        // }

        //this.processConfirmation.deviationDescription = this.deviationDescription;

        this.processConfirmation.deviationDescription = this.deviationDescription;
        this.processConfirmation.responsibleEmployee = this.responsibleEmployee;
        this.processConfirmation.AdditionalEmployee=this.requiredAttendees;
        this.processConfirmation.selectedTagData=this.ngMultiSelectSelectedTagItem;
        this.duedate.datecount= new Date(this.duedate.datecount);
        this.duedate.datecount= new Date(Date.UTC( this.duedate.datecount.getFullYear(), this.duedate.datecount.getMonth(), this.duedate.datecount.getDate()));
        this.processConfirmation.duedatecount=this.duedate.datecount;


      }
    }
    //
    this.sharedService.show();
   //console.log("global before",this.globaltagQuesandAnsOverView)
    //console.log("1287",this.processConfirmation)
    for( let i=0 ;i< this.globaltagQuesandAnsOverProcess.length;i++) {
      if(this.globaltagQuesandAnsOverProcess[i].questionID == this.processConfirmation.questionID) {
          this.globaltagQuesandAnsOverProcess[i].answer = this.processConfirmation.answer;
      }
    }
    //if mmode is tag
    // var TagAnswerQuestion= {
    //   TagId:this.processConfirmation.tagID,
    //   QuestionId:this.processConfirmation.questionID,
    //   createdAt:this.processConfirmation.createdAt,
    //   ModifiedAt:this.processConfirmation.modifiedAt,
    //   AnswerTypeID:this.processConfirmation.answerType_AnswerTypeID,
    //   Answer: this.processConfirmation.answer,
    //   createdbyNTID:this.processConfirmation.AnsweredBy_NTID,
    //   modifiedbyNTID:this.processConfirmation.AnsweredBy_NTID,
    //   valuestreamid:this.processConfirmation.valueStreamID,
    //   TagModeID:this.sharedService.TagModeID,
    //   PlantID:this.sharedService.plantID,
    // }
    //alert("alert")


    this.processConfirmation.PlantID = this.sharedService.plantID;
    this.processConfirmation.TagModeID = this.sharedService.TagModeID;
    if (this.calendarAuditID) {

      this.processConfirmation.TagModeID = this.sharedService.calTagmodeID?this.sharedService.calTagmodeID:this.sharedService.TagModeID;
      this.processConfirmation.tagID = this.sharedService.calTagModeTagID?this.sharedService.calTagModeTagID:this.sharedService.SharedServiceTags.tagID;
      this.processConfirmation.auditID=this.calendarAuditID;
    }
   // console.log("before tag answered payload",this.processConfirmation)
    // this.processConfirmationService
    // .insertTagAnsweredQuestion(this.processConfirmation)
    // .subscribe(res => {
    //     console.log("1368",res)
    // })
    // if(processConfirmation.answer==null) {
    //   {
    //     processConfirmation.modeTypeID= 3,
    //     processConfirmation.valueStreamID= 1920,
    //     processConfirmation.assessorID= 61,
    //     processConfirmation.questionID= 726,
    //     processConfirmation.questionDisplayID= 36,
    //     processConfirmation.answer= "feaffae",
    //     processConfirmation.answerType_AnswerTypeID= 1,
    //     processConfirmation.answeredBy= null,
    //     //processConfirmation.createdAt= "2024-08-08T14:00:51.893",
    //     processConfirmation.modifiedBy= null,
    //    // processConfirmation.modifiedAt= "2024-08-08T14:00:51.893",
    //     processConfirmation.targetPercentage= 0,
    //     processConfirmation.TagModeID= 32,
    //     //processConfirmation.isBranchLogicToBeFollowed= 0,
    //     //processConfirmation.questionType= false,
    //     processConfirmation.PlantID= 1,
    //     processConfirmation.modifiedBy_NTID= "FSM1COB",
    //    // processConfirmation.isDeleted= true,
    //     processConfirmation.tagID= 35,
    //     processConfirmation.ResumeTagProcessConfirmation= false,
    //     processConfirmation.questionText= "What is the product name please?",
    //     processConfirmation.questionHintText= "ayurvedic",
    //     processConfirmation.hyperLinkURL= null,
    //     processConfirmation.imageTitle= null,
    //     processConfirmation.displayFileName= null,
    //     processConfirmation.processConfirmationID= 0,
    //    // processConfirmation.timeStamp= "0001-01-01T00:00:00",
    //     processConfirmation.valueStreamData= null,
    //     processConfirmation.valueStreamName= "vsas4cat",
    //     processConfirmation.assessorName= "VSAS4ass",
    //     processConfirmation.modeType= null,
    //     processConfirmation.answeredBy_NTID= null,
    //     processConfirmation.isCustomMode= false,
    //     processConfirmation.CustomModeID= 0,
    //     processConfirmation.isDeviation= false,
    //     processConfirmation.userName= null,
    //     processConfirmation.obtainedScore= 0,
    //     processConfirmation.choiceID= 0,
    //     processConfirmation.deviationDescription= null,
    //     processConfirmation.responsibleEmployee= "Kumar R B Ashok (SX/BSV-IF1)",
    //     processConfirmation.deviationID= 0,
    //     processConfirmation.dataPoolID= 1,
    //     processConfirmation.hintImages= [],
    //     processConfirmation.deviation= null,
    //     processConfirmation.tagIDList= "32,35,38",
    //     processConfirmation.tagNameList= "#caltagnew,#Newtaginsl3,#savebutton",
    //     // processConfirmation.empList= null,
    //     // processConfirmation.multiTagList= null,
    //     // processConfirmation.multiTagID= null,
    //     processConfirmation.editTagList= null,
    //     processConfirmation.addEmpList= null,
    //     processConfirmation.tagList= null,
    //     processConfirmation.valueStreamTemplateName= "VSAS4VS",
    //     processConfirmation.valueStreamCategoryName= "VS Responsible Employee",
    //     processConfirmation.assessorTemplateName= "VSAS4ASS",
    //     processConfirmation.delimiter= "_",
    //     processConfirmation.onMyformData= null,
    //     processConfirmation.isForgotAssessor= false,
    //     processConfirmation.isForgotValueStream= false,
    //     processConfirmation.vsSessionID= null,
    //     processConfirmation.asSessionID= null,
    //     //processConfirmation.assessorList= null,
    //     processConfirmation.selectedTagData= null,
    //     processConfirmation.additionalEmployee= null,
    //     // processConfirmation.assessorIDList= null,
    //     // processConfirmation.assessorNameList= null,
    //     processConfirmation.isDefaultAnswerRequired= false,

    //     processConfirmation.defaultChoiceID= 0,
    //     processConfirmation.sessionID= "1723178468222",
    //     processConfirmation.auditID= 0,
    //     processConfirmation.auditTemplateID= 0,
    //     processConfirmation.answeredAndSkippedQuestionID= null,
    //     processConfirmation.taskID= 0,
    //     processConfirmation.originTag= null,
    //     processConfirmation.oplurl= null,

    //     processConfirmation.anonymizeUserDataSettingID= 0,
    //     processConfirmation.AnsweredBy_NTID= "FSM1COB",
    //     processConfirmation.PlantID= 1,
    //     processConfirmation.TagModeID= 32
    // }
    // }
    //console.log("TagAnswerQuestion",TagAnswerQuestion)
    // alert(2)
    this.processConfirmation.ResumeTagProcessConfirmation= this.isResumeTagSelected;
    if(this.tooltipOpen) {
      this.processConfirmation.ResumeTagProcessConfirmation=false
    }
    this.processConfirmation.attemptNumber=this.AttemptNumber;
    this.processConfirmation.childEventID=this.ChildEventID;
    debugger;
    if(this.isResumeClicked==true){
      this.processConfirmation.isResumeActivated=true;
    }else {
      this.processConfirmation.isResumeActivated=this.ResumeActivated;
    }
    
     console.log(processConfirmation.process_eventID_Starttime)

     this.processConfirmationService
      .insertProcessConfirmation(this.processConfirmation)
      .subscribe( res => {
        this.IsFirstinsertProcess=false;
        console.log("2141",res.eventStartTime)
        console.log("2141",res.eventID)
        this.eventID_Starttime=res.eventStartTime;
        this.generatedEventID =res.eventID;
        this.AttemptNumber=res.attemptNumber;
        this.ChildEventID=res.childEventID;
        this.IsSubmit = true;
        this.isValuestreamChanged = true;


        //to send the deviation email based on deviation type
        this.deviation = new Deviation();
        //
       //// debugger;
        if (this.deviationTypeID > 1) {
          if(this.deviationTypeID == 3 || this.deviationTypeID == 5 )
          {
            this.deviation.deviationId = res.insertedID;
          }
          this.deviation.deviationDescription = this.deviationDescription;
          this.deviation.responsibleEmployee = this.responsibleEmployee;
          this.deviation.deviationTypeID = this.deviationTypeID;
          this.deviation.selectedTagData=this.ngMultiSelectSelectedTagItem;
          this.duedate.datecount= new Date(this.duedate.datecount);
          this.duedate.datecount= new Date(Date.UTC( this.duedate.datecount.getFullYear(), this.duedate.datecount.getMonth(), this.duedate.datecount.getDate()));
           this.deviation.duedatecount=this.duedate.datecount;
          if (this.sharedService.emailAddress) {
            this.deviation.userEmailAddress = this.sharedService.emailAddress;
          }
          this.deviation.AdditionalEmployee=this.requiredAttendees
          this.deviation.managerEmailAddress = this.managerEmailAddress;
          this.deviation.questionID = this.processConfirmation.questionID;
          this.deviation.questionDisplayID = this.processConfirmation.questionDisplayID;
          this.deviation.questionText = this.processConfirmation.questionText;
          this.deviation.questionChoiceAnswer = this.processConfirmation.answer;
             //  this.deviation.questionLinkedTags = this.processConfirmation.tagNameList.replace(',', ';');
             if (this.modeType=="tag"){
              console.log("tag",this.selectedTag.TagDisplayName);
              this.deviation.questionLinkedTags =this.selectedTag.TagDisplayName;
            }
            else{
              if (this.processConfirmation.tagNameList != null) {
                this.deviation.questionLinkedTags = this.processConfirmation.tagNameList.replace(',', ';');
              }
            }

          this.deviation.valueStreamID = this.processConfirmation.valueStreamID;
          // this.deviation.valueStreamName = this.valueStreamList.filter(x => x.valueStreamID == this.processConfirmation.valueStreamID)[0].valueStreamName;
          this.deviation.valueStreamName = this.valueStreamName;
          this.deviation.responsibleEmpNTID = this.responsibleEmployeeNTID;
          this.deviation.hintImages = this.processConfirmation.hintImages;
          if (this.sharedService.ntid) {
            this.deviation.createdBy_NTID = this.sharedService.ntid;
            this.deviation.modifiedBy_NTID = this.sharedService.ntid;
          }

          if (this.vsUser) {
             this.processAndSendEmail();
          }
          else {
            //
            if (this.valueStreamList && this.valueStreamList.length > 0) {
              this.responsibleEmployeeID = this.valueStreamList.filter(x => x.valueStreamID == this.deviation.valueStreamID)[0]!.responsible_UserID;
               this.commonService.getUserByNTID(this.responsibleEmployeeID).subscribe( res => {
                this.vsUser = res;
                 this.processAndSendEmail();
              });
            }
            else {
              this.valuestreamService.valueStreamByValueStreamID(this.deviation.valueStreamID).subscribe(
                 res => {
                  this.responsibleEmployeeID = res[0].responsible_UserID;
                   this.commonService.getUserByNTID(this.responsibleEmployeeID).subscribe( res => {
                    this.vsUser = res;
                      this.processAndSendEmail();
                  });
                 }
              )
            }
          }
          //this.sharedService.hide();
        }
        else {
          this.next1();
          this.sharedService.hide();
          this.deviationDescription = undefined;
          this.urls = [];
          this.responsibleEmployee = undefined;
          $(".rb-core-back-to-top-button").click();
        }
      });
      //this.sharedService.hide();
     //console.log("1371",this.globaltagQuesandAnsOverView)
  }

   // Getter to check if all questions are answered
   get isAllAnswered(): boolean {
    return this.globaltagQuesandAnsOverView.every(item => item.answer !== null);
  }

  get isAtleastOneAnswered(): boolean
  {
    //debugger;
    let result = false;
    result = this.globaltagQuesandAnsOverView.some(q => q.checked);
    return result;

  }


  public  insertProcessConfirmation_inline(processConfirmation: ProcessConfirmation) {
   // debugger;
    processConfirmation.process_eventID_Starttime=this.eventID_Starttime;
    processConfirmation.generatedEventID=this.generatedEventID;
    processConfirmation.IsFirstinsertProcessConfirmation = this.IsFirstinsertProcess;

    // if (this.selectedValueStreamData == undefined ||this.selectedValueStreamData == "" ) {
    if (this.selectedValueStreamID_inline == undefined || this.selectedValueStreamID_inline == 0) {
      this.alertText = this.labels.default.vsCannotEmpty;
      this.modalService.show(this.warningModal_inline);
      $("modal-container").removeClass("fade");
      //$(".modal-dialog").addClass("modalSize");
      const alertDialog = document.querySelector('.modal-dialog.alert-dialog');
          if (alertDialog) {
            this.InlineWarningPopUpStyle(alertDialog);
          }
      return;
    }
    if (this.selectedAssessorName_inline == undefined || this.selectedAssessorName_inline == "") {
      this.alertText = this.labels.default.assessorCannotEmpty;
      this.modalService.show(this.warningModal_inline);
      $("modal-container").removeClass("fade");
      // $(".modal-dialog").addClass("modalSize");
     const alertDialog = document.querySelector('.modal-dialog.alert-dialog');
     if (alertDialog) {
       this.InlineWarningPopUpStyle(alertDialog);
     }
      return;
    }

    //validation for empty answer field
    if (!processConfirmation.answer && !processConfirmation.choiceID) {
      this.alertText = this.labels.default.requireAnswer;
      this.modalService.show(this.warningModal_inline);
      $("modal-container").removeClass("fade");
      // $(".modal-dialog").addClass("modalSize");
     const alertDialog = document.querySelector('.modal-dialog.alert-dialog');
     if (alertDialog) {
       this.InlineWarningPopUpStyle(alertDialog);
     }
      return;
    }

    //this.selectedChoiceID = processConfirmation.choiceID; // 27th Nov commented this line

    // if (this.newIndex == undefined) {
    //   this.processConfirmation = this.items[0];
    //  // console.log("997",this.processConfirmation)
    // } else {
    //   this.processConfirmation = this.items[this.newIndex];
    //  // console.log("1000",this.processConfirmation)[]
    // }



    if (this.modeType_inline == "shuffle") {
      this.processConfirmation_inline.modeTypeID = 1;
    } else if (this.modeType_inline == "custom") {
      this.processConfirmation_inline.modeTypeID = 2;
    } else {
      this.processConfirmation_inline.modeTypeID = 3;
      this.processConfirmation_inline.tagID = 0;
      if (this.tagModeTagID > 0 ) {
        this.processConfirmation_inline.tagID = this.tagModeTagID;
      }
      if(this.tagId_Insert_inline > 0)
      {
        this.processConfirmation_inline.tagID = this.tagId_Insert_inline;
      }
    }

    this.processConfirmation_inline.valueStreamID = this.selectedValueStreamID_inline;
    this.processConfirmation_inline.assessorID = this.selectedAssessorID_inline;
    this.processConfirmation_inline.AnsweredBy_NTID = this.sharedService.ntid;
    if(this.modeType=="custom") {
      this.processConfirmation_inline.CustomModeID = this.sharedService.CustomModeID;

    }
    //this.processConfirmation.choiceID = this.selectedChoiceID;

    this.processConfirmation_inline.hintImages = this.urls;

    //
    this.processConfirmation_inline.isShowVsAs = this.isShowVsAs;

    // if (this.processConfirmation.answerType_AnswerTypeID == 3 || this.myAnswerID==3) {
    if (this.processConfirmation_inline.answerType_AnswerTypeID == 3 || this.myAnswerID == 3) { // added 27th Nov
      //
      this.processConfirmation_inline.answer = this.processConfirmation_inline.choiceID != 0 ? this.choices_inline.filter(
        x => x.choiceID == this.processConfirmation_inline.choiceID
      )[0].choiceName : this.processConfirmation_inline.answer;

      this.processConfirmation_inline.obtainedScore = this.processConfirmation_inline.choiceID != 0 ? this.choices_inline.filter(
        x => x.choiceID == this.processConfirmation_inline.choiceID
      )[0].choiceScore : this.processConfirmation_inline.obtainedScore;

      if (this.isDeviationEntryRequired_inline) {
        if ((!this.deviationDescription_inline || !this.processConfirmation_inline.valueStreamID) && (this.deviationTypeID_inline == 2 || this.deviationTypeID_inline == 3 || this.deviationTypeID_inline==5)) {
          if (!this.processConfirmation_inline.valueStreamID && !this.deviationDescription_inline) {
            this.alertText = this.labels.default.devivationFieldMandatory;
            this.modalService.show(this.warningModal_inline);
            $("modal-container").removeClass("fade");
            // $(".modal-dialog").addClass("modalSize");
            const alertDialog = document.querySelector('.modal-dialog.alert-dialog');
            if (alertDialog) {
              this.InlineWarningPopUpStyle(alertDialog);
            }
          }
          else if (!this.processConfirmation_inline.valueStreamID) {
            this.alertText = this.labels.default.selectValueStream;
            this.modalService.show(this.warningModal_inline);
            $("modal-container").removeClass("fade");
            // $(".modal-dialog").addClass("modalSize");
            const alertDialog = document.querySelector('.modal-dialog.alert-dialog');
            if (alertDialog) {
              this.InlineWarningPopUpStyle(alertDialog);
            }
          }
          else if (!this.deviationDescription_inline) {
            this.alertText = this.labels.default.fillDeviationOnly;
            this.modalService.show(this.warningModal_inline);
            $("modal-container").removeClass("fade");
            // $(".modal-dialog").addClass("modalSize");
            const alertDialog = document.querySelector('.modal-dialog.alert-dialog');
            if (alertDialog) {
              this.InlineWarningPopUpStyle(alertDialog);
            }
          }

          return false;
        }

        this.processConfirmation_inline.deviationDescription = this.deviationDescription_inline;
        this.processConfirmation_inline.responsibleEmployee = this.responsibleEmployee_inline;
        this.processConfirmation_inline.AdditionalEmployee=this.requiredAttendees;
        this.processConfirmation_inline.selectedTagData=this.ngMultiSelectSelectedTagItem_inline;
        this.duedate.datecount= new Date(this.duedate.datecount);
        this.duedate.datecount= new Date(Date.UTC( this.duedate.datecount.getFullYear(), this.duedate.datecount.getMonth(), this.duedate.datecount.getDate()));
        this.processConfirmation_inline.duedatecount=this.duedate.datecount;


      }
    }
    //ashok
    this.sharedService.show();

    // for( let i=0 ;i< this.globaltagQuesandAnsOverProcess.length;i++) {
    //   if(this.globaltagQuesandAnsOverProcess[i].questionID == this.processConfirmation.questionID) {
    //       this.globaltagQuesandAnsOverProcess[i].answer = this.processConfirmation.answer;
    //   }
    // }

    this.processConfirmation_inline.PlantID = this.sharedService.plantID;
    this.processConfirmation_inline.TagModeID = this.sharedService.TagModeID;
    if (this.calendarAuditID) {

      this.processConfirmation_inline.TagModeID = this.sharedService.calTagmodeID?this.sharedService.calTagmodeID:this.sharedService.TagModeID;
      this.processConfirmation_inline.tagID = this.sharedService.calTagModeTagID?this.sharedService.calTagModeTagID:this.sharedService.SharedServiceTags.tagID;
      this.processConfirmation_inline.auditID=this.calendarAuditID;
    }
    // alert(1)
    //to made teh resume to work for inlinemode
    this.processConfirmation_inline.isInlineInsertProcess = false;// this false is to enabke resume entry in resume table , if its true resume entry will not come in resume table
    this.processConfirmation_inline.frominline=true;
    debugger;
    if(this.isResumeClicked==true){
      this.processConfirmation_inline.isResumeActivated=true;
    }else {
      this.processConfirmation_inline.isResumeActivated=this.ResumeActivated;
    }
    //this.processConfirmation.ResumeTagProcessConfirmation=this.isResumeTagSelected;
    this.processConfirmation.attemptNumber=this.AttemptNumber;
    this.processConfirmation.childEventID=this.ChildEventID;
     console.log(processConfirmation.process_eventID_Starttime)
    // this.processConfirmation_inline.isResumeActivated=true;
     this.processConfirmationService
     .insertProcessConfirmation(this.processConfirmation_inline)
     .subscribe(
       async (res) => {
         try {
          console.log("2139",res)
          this.IsFirstinsertProcess=false;
          console.log("2141",res.eventStartTime)
          console.log("2141",res.eventID)
          this.eventID_Starttime=res.eventStartTime;
          this.generatedEventID =res.eventID;
          this.AttemptNumber=res.attemptNumber;
          this.ChildEventID=res.childEventID;
           this.IsSubmit_inline = true;
           this.isValuestreamChanged_inline = true;

           if (this.deviationTypeID_inline > 1) {
             this.deviation_inline = new Deviation();

             if (this.deviationTypeID_inline === 3 || this.deviationTypeID_inline === 5) {
               this.deviation_inline.deviationId = res.insertedID;
             }

             this.deviation_inline.deviationDescription = this.deviationDescription_inline;
             this.deviation_inline.responsibleEmployee = this.responsibleEmployee_inline;
             this.deviation_inline.deviationTypeID = this.deviationTypeID_inline;
             this.deviation_inline.selectedTagData = this.ngMultiSelectSelectedTagItem_inline;

             this.duedate.datecount = new Date(
               Date.UTC(
                 this.duedate.datecount.getFullYear(),
                 this.duedate.datecount.getMonth(),
                 this.duedate.datecount.getDate()
               )
             );
             this.deviation_inline.duedatecount = this.duedate.datecount;

             if (this.sharedService.emailAddress) {
               this.deviation_inline.userEmailAddress = this.sharedService.emailAddress;
             }

             this.deviation_inline.AdditionalEmployee = this.requiredAttendees_inline;
             this.deviation_inline.managerEmailAddress = this.managerEmailAddress;
             this.deviation_inline.questionID = this.processConfirmation_inline.questionID;
             this.deviation_inline.questionDisplayID = this.processConfirmation_inline.questionDisplayID;
             this.deviation_inline.questionText = this.processConfirmation_inline.questionText;
             this.deviation_inline.questionChoiceAnswer = this.processConfirmation_inline.answer;

             if (this.processConfirmation_inline.tagNameList != null) {
              if (this.modeType=="tag"){
                console.log("tag",this.selectedTag.TagDisplayName);
                if(this.deviation_inline!==null && this.deviation_inline!==undefined ){
                  this.deviation_inline.questionLinkedTags = this.selectedTag?.TagDisplayName;
                }

              }
              else{

                if (this.processConfirmation_inline.tagNameList != null) {
                  if(this.deviation_inline!==null && this.deviation_inline!==undefined ){
                  this.deviation_inline.questionLinkedTags = this.processConfirmation_inline?.tagNameList.replace(',', ';');
                  }
                }
              }
             }

             this.deviation_inline.valueStreamID = this.processConfirmation_inline.valueStreamID;
             this.deviation_inline.valueStreamName = this.valueStreamName_inline;
             this.deviation_inline.responsibleEmpNTID = this.responsibleEmployeeNTID;
             this.deviation_inline.hintImages = this.processConfirmation_inline.hintImages;

             if (this.sharedService.ntid) {
               this.deviation_inline.createdBy_NTID = this.sharedService.ntid;
               this.deviation_inline.modifiedBy_NTID = this.sharedService.ntid;
             }

             if (this.vsUser) {
               await this.processAndSendEmail_inline();
             } else {
               if (this.valueStreamList && this.valueStreamList.length > 0) {
                 const responsibleUser = this.valueStreamList.find(
                   (x) => x.valueStreamID === this.deviation_inline.valueStreamID
                 );

                 if (responsibleUser) {
                   this.responsibleEmployeeID = responsibleUser.responsible_UserID;
                   this.vsUser = await this.commonService
                     .getUserByNTID(this.responsibleEmployeeID)
                     .toPromise();
                   await this.processAndSendEmail_inline();
                 }
               } else {
                 const valueStream = await this.valuestreamService
                   .valueStreamByValueStreamID(this.deviation_inline.valueStreamID)
                   .toPromise();

                 if (valueStream != null && valueStream != undefined) {
                   this.responsibleEmployeeID = valueStream[0].responsible_UserID;
                   this.vsUser = await this.commonService
                     .getUserByNTID(this.responsibleEmployeeID)
                     .toPromise();
                     await this.processAndSendEmail_inline();
                 }
               }
             }
           } else {
             this.deviationDescription_inline = undefined;
             this.urls = [];
             this.responsibleEmployee_inline = undefined;
           }

           // Update answers and disable current question
           for (let index = 0; index < this.globaltagQuesandAnsOverView.length; index++) {
             if (
               this.globaltagQuesandAnsOverView[index].questionID === this.processConfirmation_inline.questionID &&
               this.globaltagQuesandAnsOverView[index].questionDisplayID === this.processConfirmation_inline.questionDisplayID
             ) {
               this.globaltagQuesandAnsOverView[index].answer = this.processConfirmation_inline.answer;
               this.globaltagQuesandAnsOverView[index].choiceAnswer = this.processConfirmation_inline.choiceID;
             }
           }

           this.globaltagQuesandAnsOverView.forEach((q) => {
             if (q.questionID === this.selectedQuestionInline) {
               q.disabled = true;
             }
           });

           this.dynamicAnswerCount--;
           this.updateToggleMessage();
           this.sharedService.hide();

           if (this.modalRef_inline) {
             this.modalRef_inline.hide(); // Hide the modal
           }


           if (this.IsToggleDisabled)
            {
       this.alertText = "";
        this.alertText = "You have reached your limit please click next and answer your questions";
        this.modalService.show(this.warningModal_inline);
        $("modal-container").removeClass("fade");
        //$(".modal-dialog").addClass("modalSize");
        const alertDialog = document.querySelector('.modal-dialog.alert-dialog');
          if (alertDialog) {
            $(".modal-content").addClass("modalSize121");
            this.renderer.setStyle(alertDialog, 'display', 'flex');
            this.renderer.setStyle(alertDialog, 'align-items', 'center');
            this.renderer.setStyle(alertDialog, 'justify-content', 'center');
            this.renderer.setStyle(alertDialog, 'height', '45vh');
            this.renderer.setStyle(alertDialog, 'margin', '0');
          }
        }


           //this.showSuccessAlert();
         } catch (error) {
           console.error("Error handling process confirmation:", error);
           this.sharedService.hide();
         }
       },
       (error) => {
         console.error("Error inserting process confirmation:", error);
         this.sharedService.hide();
       }
     );

  }

  public submitFromInline()
  {
    debugger;
    console.log(this.globaltagQuesandAnsOverProcess);
    console.log(this.globaltagQuesandAnsOverView);
    //this.answerOverView_inline(this.eventID_Starttime);
  
    this.closeAlertModal();
  
    if ((this.modeType == "tag"||this.modeType == "custom")  && this.flagQuestionLoaded) {
      // console.log("929")
  
       if((this.sharedService.SharedServiceTags.isResultOverviewDefined && this.modeType == "tag") || ( this.sharedService.CustomModeAnswerOverView && this.modeType == "custom"  )) {
         console.log("1276")
  
         console.log(this.eventID_Starttime)
         console.log("endtime PC",this.processConfirmation)
         this.processConfirmationService.updateEventEndTime(this.eventID_Starttime,this.processConfirmation).subscribe(res => {
  
           console.log(res)
       }, err => { });
  
  
        // this.answerOverView(this.eventID_Starttime);
         this.answerOverView_inline(this.eventID_Starttime);
        }else if((this.sharedService.SharedServiceTags.isReportingEmailDefined && this.modeType == "tag") || (this.sharedService.CustomModeReportingEmail && this.modeType == "custom") )
         {
         //alert(1)
  
       //   this.alertText = this.labels.default.tagmodeansweOverViewDisable;
  
       //  this.modalService.show(this.successModal);
         this.answerOverView1_inline(this.eventID_Starttime);
        }
         this.alertText = this.labels.default.EndOfTagModeQuestionList;
  
        this.modalService.show(this.successModal);
     }
     else if(this.flagQuestionLoaded)
     {
       //alert("1151")
       this.alertText = this.labels.default.allQuestionAnswered;
       this.modalService.show(this.successModal);
     }
     else {
  
      // alert("1156")
       //console.log("")
       //this.noqueslink= true;
       this.alertText = this.labels.default.allQuestionAnswered;
       this.modalService.show(this.warningModal);
       console.log(this.alertText)
  
     }
     $("modal-container").removeClass("fade");
     $(".modal-dialog").addClass("modalSize");
     this.router.navigate([environment.home + "/dashboard/"]);
     return;
  
  }

  private InlineWarningPopUpStyle(alertDialog: Element) {
    $(".modal-content").addClass("modalSize121");
    // this.renderer.addClass(alertDialog, 'modalSize');
    this.renderer.setStyle(alertDialog, 'display', 'flex');
    this.renderer.setStyle(alertDialog, 'align-items', 'center');
    this.renderer.setStyle(alertDialog, 'justify-content', 'center');
    this.renderer.setStyle(alertDialog, 'height', '45vh');
    this.renderer.setStyle(alertDialog, 'margin', '0');
  }
     processAndSendEmail()
  {
    if (!this.deviation.responsibleEmployee) {
      if (this.vsUser) {
        this.deviation.responsibleEmployee = this.vsUser.userName;
        this.deviation.managerEmailAddress = this.vsUser.emailAddress;
      }
    }
    this.deviation.AdditionalEmployee=this.requiredAttendees
    if (this.vsUser) {
      this.deviation.owner = this.vsUser.userName;
      this.deviation.ownerNTID = this.vsUser.ntid;
      this.deviation.responsibleEmployeeEmailAddress = this.vsUser.emailAddress;
      this.deviation.createdBy_Name =this.sharedService.displayName;
      this.deviation.CreatedByEmployee = this.sharedService.ADdisplayName;
    }
    if (this.deviationTypeID == 3) {
      var request =  this.superOPLService.CreateDeviationSuperOPL(this.deviation);
      if(this.requiredAttendeesNTID!=null){

        for(let each of this.requiredAttendeesNTID){

               // infoEmp+=","+each+",";
               request.informationTo.push(each);

        }

      }
      var superOPLList: any = environment.superopl != undefined ? Object.values(JSON.parse(environment.superopl)) : [];
      var result = superOPLList;
      if (result != null && result.length > 0) {
        if(this.modeType == "tag"){
          request.description = request.description +" "+'<br/>'+this.labels.default.subMenuTag+": "+ this.selectedTag.TagDisplayName;
        }
           this.superOPLService.createOPLTask(request, result[0].oplID, result[0].apiKey, this.deviation).subscribe( res => {
          //
          if (res != "") {

              this.SendEmail(this.deviation, res);
          }
          else {
             this.SendEmail(this.deviation, null);
          }
        },
           err => {
            this.SendEmail(this.deviation, null);
            console.log(err);
          });
      }
    }

    else if (this.deviationTypeID == 2) {
       this.SendEmail(this.deviation, null);
    }
   else if(this.deviationTypeID == 5) {
     var request =  this.superOPLService.CreateDeviationSuperOPL(this.deviation);
     if(this.requiredAttendeesNTID!=null){

      for(let each of this.requiredAttendeesNTID){
             // infoEmp+=","+each+",";
             request.informationTo.push(each);
      }
    }
    var superOPLList: any = environment.superopl != undefined ? Object.values(JSON.parse(environment.superopl)) : [];
     var result = superOPLList;
     if (result != null && result.length > 0) {
       if(this.modeType == "tag"){
         request.description = request.description +" "+'<br/>'+this.labels.default.subMenuTag+": "+ this.selectedTag.TagDisplayName;
       }
          this.superOPLService.createOPLTask(request, result[0].oplID, result[0].apiKey, this.deviation).subscribe( res => {
          if (res != "") {
             this.SendEmail(this.deviation, res);
          }
             else {
               this.SendEmail(this.deviation, null); } },
              err => { this.SendEmail(this.deviation, null);
                 console.log(err);
                 });
                }
              }

 else {
      this.clearDeviationDetails();
    }
  }

  async processAndSendEmail_inline(): Promise<void>
  {

    return new Promise<void>(async (resolve, reject) => {
      try {

    if (!this.deviation_inline.responsibleEmployee) {
      if (this.vsUser) {
        this.deviation_inline.responsibleEmployee = this.vsUser.userName;
        this.deviation_inline.managerEmailAddress = this.vsUser.emailAddress;
      }
    }
    this.deviation_inline.AdditionalEmployee=this.requiredAttendees_inline
    if (this.vsUser) {
      this.deviation_inline.owner = this.vsUser.userName;
      this.deviation_inline.ownerNTID = this.vsUser.ntid;
      this.deviation_inline.responsibleEmployeeEmailAddress = this.vsUser.emailAddress;
      this.deviation_inline.createdBy_Name =this.sharedService.displayName;
      this.deviation_inline.CreatedByEmployee = this.sharedService.ADdisplayName;
    }
    if (this.deviationTypeID_inline == 3) {
      var request =  this.superOPLService.CreateDeviationSuperOPL(this.deviation_inline);
      if(this.requiredAttendeesNTID!=null){

        for(let each of this.requiredAttendeesNTID){

               // infoEmp+=","+each+",";
               request.informationTo.push(each);

        }

      }
      var superOPLList: any = environment.superopl != undefined ? Object.values(JSON.parse(environment.superopl)) : [];
      var result = superOPLList;
      if (result != null && result.length > 0) {
        if(this.modeType_inline == "tag"){
          request.description = request.description +" "+'<br/>'+this.labels.default.subMenuTag+": "+ this.selectedTag.TagDisplayName;
        }

        try {
          const response = await this.superOPLService
            .createOPLTask(request, superOPLList[0].oplID, superOPLList[0].apiKey, this.deviation_inline)
            .toPromise(); // Ensure this resolves before proceeding.

          await this.SendEmail_inline(this.deviation_inline, response || null); // Await email operation.
        } catch (error) {
          console.error("Error in createOPLTask or SendEmail_inline:", error);
        }


        //     this.superOPLService.createOPLTask
        //     (request, result[0].oplID, result[0].apiKey, this.deviation_inline).subscribe( res => {
        //   //
        //   if (res != "") {

        //       this.SendEmail_inline(this.deviation_inline, res);
        //   }
        //   else {
        //      this.SendEmail_inline(this.deviation_inline, null);
        //   }
        // },
        //    err => {
        //     this.SendEmail_inline(this.deviation_inline, null);
        //     console.log(err);
        //   });
      }
    }

    else if (this.deviationTypeID_inline == 2) {
       await this.SendEmail_inline(this.deviation_inline, null);
    }
   else if(this.deviationTypeID_inline == 5) {
     var request =  this.superOPLService.CreateDeviationSuperOPL(this.deviation_inline);
     if(this.requiredAttendeesNTID!=null){

      for(let each of this.requiredAttendeesNTID){
             // infoEmp+=","+each+",";
             request.informationTo.push(each);
      }
    }
    var superOPLList: any = environment.superopl != undefined ? Object.values(JSON.parse(environment.superopl)) : [];
     var result = superOPLList;
     if (result != null && result.length > 0) {
       if(this.modeType_inline == "tag"){
         request.description = request.description +" "+'<br/>'+this.labels.default.subMenuTag+": "+ this.selectedTag.TagDisplayName;
       }

       try {
        const response = await this.superOPLService
          .createOPLTask(request, superOPLList[0].oplID, superOPLList[0].apiKey, this.deviation_inline)
          .toPromise(); // Ensure this resolves before proceeding.

        await this.SendEmail_inline(this.deviation_inline, response || null); // Await email operation.
      } catch (error) {
        console.error("Error in createOPLTask or SendEmail_inline:", error);
      }

          // this.superOPLService.createOPLTask(request, result[0].oplID, result[0].apiKey, this.deviation_inline)
          // .subscribe( res => {
          // if (res != "") {
          //   await this.SendEmail_inline(this.deviation_inline, res);
          // }
          //    else {
          //      this.SendEmail_inline(this.deviation_inline, null); } },
          //     err => { this.SendEmail_inline(this.deviation_inline, null);
          //        console.log(err);
          //        });
                 }
             }

 else {
      this.clearDeviationDetails_inline();
    }
        resolve();
      }
      catch (error) {
        reject(error); // Rejects the promise if there’s an error.
      }
    });
  }

  private  SendEmail(deviation, OPLTaskID) {
    if(OPLTaskID != null)
    {
      deviation.superOPLURL = environment.superOPLTaskURL + OPLTaskID.toString();
    }
    else
    {
      if (deviation.superOPLURL == environment.superOPLTaskURL) {
        deviation.superOPLURL = "";
      }

      var superOPLList: any = environment.superopl != undefined ? Object.values(JSON.parse(environment.superopl)) : [];
      if (superOPLList != null && superOPLList.length > 0) {
        deviation.superOPLNewTaskURL = environment.superOPLPortalURL + superOPLList[0].oplID;
      }
    }
    if (this.modeType == "tag") {
    this.deviation.selectedtag =this.selectedTag.TagDisplayName
    }
    //console.log("1259",this.deviation)
    //this.deviation.languageCode='EN';
    //console.log("1272",this.labels)
     this.commonService.sendDeviationEmail(deviation).subscribe(res => {
      this.clearDeviationDetails();
      },
      err => {
        this.clearDeviationDetails();
      });
  }

   private  SendEmail_inline_old(deviation, OPLTaskID) {
    if(OPLTaskID != null)
    {
      deviation.superOPLURL = environment.superOPLTaskURL + OPLTaskID.toString();
    }
    else
    {
      if (deviation.superOPLURL == environment.superOPLTaskURL) {
        deviation.superOPLURL = "";
      }

      var superOPLList: any = environment.superopl != undefined ? Object.values(JSON.parse(environment.superopl)) : [];
      if (superOPLList != null && superOPLList.length > 0) {
        deviation.superOPLNewTaskURL = environment.superOPLPortalURL + superOPLList[0].oplID;
      }
    }
    if (this.modeType == "tag") {
    this.deviation_inline.selectedtag =this.selectedTag.TagDisplayName??null;
    }
    //console.log("1259",this.deviation)
    //this.deviation.languageCode='EN';
    //console.log("1272",this.labels)
     this.commonService.sendDeviationEmail(deviation).subscribe(res => {
      this.clearDeviationDetails_inline();
      },
      err => {
        this.clearDeviationDetails_inline();
      });
  }



  async SendEmail_inline(deviation, OPLTaskID): Promise<void> {
    return new Promise<void>((resolve, reject) => {
      try {
        if (OPLTaskID != null) {
          deviation.superOPLURL = environment.superOPLTaskURL + OPLTaskID.toString();
        } else {
          if (deviation.superOPLURL === environment.superOPLTaskURL) {
            deviation.superOPLURL = "";
          }

          const superOPLList: any = environment.superopl ? Object.values(JSON.parse(environment.superopl)) : [];
          if (superOPLList.length > 0) {
            deviation.superOPLNewTaskURL = environment.superOPLPortalURL + superOPLList[0].oplID;
          }
        }

        if (this.modeType === "tag") {
          this.deviation_inline.selectedtag = this.selectedTag.TagDisplayName ?? null;
        }

        this.commonService.sendDeviationEmail(deviation).subscribe(
          () => {
            this.clearDeviationDetails_inline();
            resolve(); // Resolves once the email is sent successfully.
          },
          (error) => {
            this.clearDeviationDetails_inline();
            console.error("Error in sendDeviationEmail:", error);
            reject(error); // Rejects in case of an error.
          }
        );
      } catch (error) {
        console.error("Error in SendEmail_inline:", error);
        reject(error); // Catch any synchronous errors.
      }
    });
  }



  clearDeviationDetails() {
    this.clearDeviation();
    this.next1();
    this.sharedService.hide();
  }

    clearDeviationDetails_inline() {
   // debugger;
    this.clearDeviation_inline();

    const checkedQuestion = this.globaltagQuesandAnsOverView.find(
      q => q.questionID == this.processConfirmation_inline.questionID && q.questionDisplayID == this.processConfirmation_inline.questionDisplayID
      );

      for (let index = 0; index < this.globaltagQuesandAnsOverView.length; index++) {

        if (this.globaltagQuesandAnsOverView[index].questionID == this.processConfirmation_inline.questionID && this.globaltagQuesandAnsOverView[index].questionDisplayID == this.processConfirmation_inline.questionDisplayID) {
          this.globaltagQuesandAnsOverView[index].answer = this.processConfirmation_inline.answer;
          this.globaltagQuesandAnsOverView[index].choiceAnswer = this.processConfirmation_inline.choiceID;
        }

      }
    //this.sharedService.hide();
    // if (this.modalRef_inline) {
    //   this.modalRef_inline.hide();  // Hide the modal using the BsModalRef
    //   this.modalService.show(this.successModal);
    // }
  }

  closeModal() {
    document.getElementById('deleteModal').style.display = "none";
    document.querySelector('body').classList.remove('-is-modal');
  }

  showModal() {
    document.getElementById('deleteModal').style.display = "block";
  }

  onClose() {
    this.bsModalRef.hide();
  }


  /** Method is responsible to show View All Supplier pop up table */
  open(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, this.config);
    this.modalRef.setClass("modal-lg");
  }

  // ***************test***********************
  getDroppedImage(url) {
    this.droppedImage = url.fileContent;
    this.droppedImageName = url.imageTitle;
    this.alertText = name + this.labels.default.droppedImageName;
    // this.modalService.show(this.warningModal);
    // $("modal-container").removeClass("fade");
    // $(".modal-dialog").addClass("modalSize");
    return;
  }

  DownLoadFiles() {

    let fileName = this.droppedImageName;
    //file type extension
    // let checkFileType =  fileName.split('.').pop();
    let checkFileType = "." + fileName.split('.').pop();
    var fileType = this.sharedService.GetMIMETypeByExtenstion(checkFileType);

    this.processConfirmationService.DownloadFile(fileName, fileType)
      .subscribe(
        success => {
          saveAs(success, fileName);
        },
        err => {
          console.log(err.message);
        }
      );
  }

  skipQuestion(processConfirmation)
  {
    // console.log("1509",this.modeType)
    // console.log("1508",this.sharedService)
    // console.log("1535",this.modeType)

   // debugger;
    console.log(this.deviationDescription)
     if(this.isResumeTagSelected == true && processConfirmation.isAnswerRequired ==true && processConfirmation.isskipmandatoryAnswer) {
       this.SkipProcess=processConfirmation
       console.log(this.globaltagQuesandAnsOverViewResumeCheck)
       console.log(processConfirmation)
       let CurrentQuestionLastAnswer=this.globaltagQuesandAnsOverViewResumeCheck.filter(x => x.questionID == processConfirmation.questionID);
       console.log(CurrentQuestionLastAnswer)
       // if answer is og coice type
       if(processConfirmation.answerType_AnswerTypeID==3 ) {
         // checking any chouice is recenltly chnaged
         if(processConfirmation.choiceID==CurrentQuestionLastAnswer[0].choiceID)
         {
           if(processConfirmation.deviationDescription!==undefined && this.deviationDescription!==null){
             if(processConfirmation.deviationDescription == this.deviationDescription) {
              // alert("nothing changed");
               this.alertText = this.labels.default.SkipMandatory;
               this.modalService.show(this.warningModal1);
               $("modal-container").removeClass("fade");
               $(".modal-dialog").addClass("modalSize");
               return false;
             }else {
              this.alertText = this.labels.default.SkipMandatoryAnswerChange;
              this.modalService.show(this.warningModal);
              $("modal-container").removeClass("fade");
              $(".modal-dialog").addClass("modalSize");
              return false;
              // alert("changes happened");
             }
           }else {
            this.alertText = this.labels.default.SkipMandatory;
            this.modalService.show(this.warningModal1);
            $("modal-container").removeClass("fade");
            $(".modal-dialog").addClass("modalSize");
            return false;
             //alert("no chnage choice without desc")
           }

         }else {
           //alert("choice id changes")
           this.alertText = this.labels.default.SkipMandatoryAnswerChange;
           this.modalService.show(this.warningModal);
           $("modal-container").removeClass("fade");
           $(".modal-dialog").addClass("modalSize");
           return false;
         }
       }else {
         if(processConfirmation.answer==CurrentQuestionLastAnswer[0].answer) {
           //alert("No changes")
           this.alertText = this.labels.default.SkipMandatory;
           this.modalService.show(this.warningModal1);
           $("modal-container").removeClass("fade");
           $(".modal-dialog").addClass("modalSize");
           return false;
         }else {
           //alert("changes done")
           this.alertText = this.labels.default.SkipMandatoryAnswerChange;
           this.modalService.show(this.warningModal);
           $("modal-container").removeClass("fade");
           $(".modal-dialog").addClass("modalSize");
           return false;
         }
       }
      //  this.alertText = this.labels.default.SkipMandatory;
      //  this.modalService.show(this.warningModal1);
      //  $("modal-container").removeClass("fade");
      //  $(".modal-dialog").addClass("modalSize");
      //  return false;
     }
    // console.log(this.globaltagQuesandAnsOverViewResumeCheck)
    // console.log(processConfirmation)
    // let CurrentQuestionLastAnswer=this.globaltagQuesandAnsOverViewResumeCheck.filter(x => x.questionID == processConfirmation.questionID);
    // console.log(CurrentQuestionLastAnswer)
    // // if answer is og coice type
    // if(processConfirmation.answerType_AnswerTypeID==3 ) {
    //   // checking any chouice is recenltly chnaged
    //   if(processConfirmation.choiceID==CurrentQuestionLastAnswer[0].choiceID)
    //   {
    //     if(processConfirmation.deviationDescription!==undefined && CurrentQuestionLastAnswer[0].deviationDescription){
    //       if(processConfirmation.deviationDescription == CurrentQuestionLastAnswer[0].deviationDescription) {
    //         alert("nothing changed");
    //       }else {
    //         alert("changes happened");
    //       }
    //     }else {
    //       alert("no chnage choice without desc")
    //     }

    //   }else {
    //     alert("choice id changes")
    //   }
    // }else {
    //   if(processConfirmation.answer==CurrentQuestionLastAnswer[0].answer) {
    //     alert("No changes")
    //   }else {
    //     alert("changes done")
    //   }
    // }
    if(processConfirmation.isAnswerRequired== true){
      this.alertText = this.labels.default.calendarSkip;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      return false;
      }
      if(this.modeType=='shuffle') {
        //alert("shuffle skip")
        this.IsSubmit = false;
        this.next1();
      }

    if(this.modeType=='tag'){
      if(this.sharedService.tagTypeID  ==1 && this.sharedService.SharedServiceTags.isSkipQuestionDefined || this.sharedService.tagTypeID  ==2 && this.sharedService.SharedServiceTags.isSkipQuestionDefined ||  this.sharedService.tagTypeID  ==3 && this.sharedService.SharedServiceTags.isSkipQuestionDefined ||  (this.sharedService.tagTypeID  == 4 && this.sharedService.SharedServiceTags.isSkipQuestionDefined)){
        //alert("Tag skip nabled")
        this.IsSubmit = false;
        this.next1();
      }
      // else {
      //   console.log("1539",this.sharedService.IsSkipEnabled)

      //   this.open(this.skipdisable);
      // }
    }else{
      if( this.sharedService.tagTypeID  ==0  &&  this.sharedService.CustomModeSkip || this.sharedService.tagTypeID  ==1  &&  this.sharedService.CustomModeSkip || this.sharedService.tagTypeID  ==2  && this.sharedService.CustomModeSkip||  this.sharedService.tagTypeID  ==3  && this.sharedService.CustomModeSkip ||  (this.sharedService.tagTypeID  ==4 && this.sharedService.CustomModeSkip)) {
      // alert("custom skip enabled")
        this.IsSubmit = false;
        this.next1();
    }
    // else {
    //   console.log("1514",this.sharedService.IsSkipEnabled)
    //   //if(this.sharedService.IsSkipEnabled && this.sharedService.tagTypeID == 4  ) {
    //     this.open(this.skipdisable);
    //   //}
    //    }
    }

    //this.sharedService.hide();
  }

  async next1() {
   // debugger;
    //alert("next1")
    this.clearDeviation();

    //console.log("before skip",this.skipQuestionList)
    //console.log("sel quesId",this.selectedQuestionID)
    //if(this.modeType)
    if(this.skipQuestionList.indexOf(this.selectedQuestionID) === -1 )
    {
      console.log("inside if")
      this.skipQuestionList.push(this.selectedQuestionID)

    }

    //console.log("skipques",this.skipQuestionList)
    //console.log("1278",this.modeType)

    // to show the questions according to the assessor and value stream combination selected
    if(this.calendarAuditID > 0)
    {

      //alert("1866")


     await  this.getProcessConfirmation1("calendarTag", this.calendarAuditID, this.selectedAssessorID, this.UserNTID, this.myTagID, this.myQuestionID, this.skipQuestionList,this.isResumeTagSelected);
    }
    else
    {
     // console.log("1756")
    //  console.log("isResumeTagSelected",this.isResumeTagSelected)
   // alert("1873")
      await this.getProcessConfirmation1(this.modeType, this.selectedValueStreamID, this.selectedAssessorID, this.UserNTID, this.myTagID, this.myQuestionID, this.skipQuestionList,this.isResumeTagSelected);

    }
   // this.sharedService.hide();
  }

  ///end

  // *********************download files**********************
  DownloadProcessConfirmationHintImages(titlename: string) {
    //
    //  var name =this.items.filter(x => x.questionID == ID)[0].imageTitle;

    var name = titlename;

    let fileName = name;

    //file type extension
    let checkFileType = "." + fileName.split('.').pop();
    var fileType = this.sharedService.GetMIMETypeByExtenstion(checkFileType);

    this.questionService.DownloadQuestionAttachment(fileName, fileType).subscribe(success => {
      saveAs(success, fileName);
    },
      err => {
        this.alertText = this.labels.default.serverErrorLoadingFile;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        console.log(err);
      }
    );
  }



  AssignValues(index: number) {
    if (this.items[index] != null) {
      this.selectedValueStreamID = this.items[index].valueStreamID;
      this.selectedAssessorID = this.items[index].assessorID;

      this.appendValueStreamWithOtherData = "";
      this.selectedValueStreamData = "";
      this.appendAssessorWithOtherData = "";
      this.selectedAssessorName = "";

      if (this.valueStreamList.filter(x => x.valueStreamID == this.selectedValueStreamID).length > 0) {
        //to bind with vs drodown when clicking next
        this.appendValueStreamWithOtherData =
          this.items[index].valueStreamTemplateName +
          this.items[index].delimiter +
          this.items[index].valueStreamName;
      }

      if (this.assessorList.filter(x => x.assessorID == this.selectedAssessorID).length > 0) {
        //to bind with assessor drodown when clicking next
        this.selectedAssessorName = this.items[index].assessorName;
        this.appendAssessorWithOtherData = this.items[index].assessortemplate;
      }

      if (this.processConfirmation.isForgotValueStream && this.processConfirmation.vsSessionID != null && this.sharedService.sessionID != this.processConfirmation.vsSessionID) {//if checkbox is selected (isShowVsAs is true )then do not show the previous selected values.
        this.appendValueStreamWithOtherData = "";
        this.selectedValueStreamData = "";
        this.appendValueStreamWithOtherData = undefined;
        this.selectedValueStreamData = undefined;
        this.selectedValueStreamID = 0;
      }

      if (this.processConfirmation.isForgotAssessor && this.processConfirmation.asSessionID != null && this.sharedService.sessionID != this.processConfirmation.asSessionID) {//if checkbox is selected (isShowVsAs is true )then do not show the previous selected values.
        this.selectedAssessorName = "";
        this.selectedAssessorName = undefined;
        this.selectedAssessorID = 0;
      }
    }
  }
  // *************************downloads fields ends************

  goToLink(url: string) {

    if (url.toLocaleLowerCase().includes('https://') || url.toLocaleLowerCase().includes('http://')) {
      window.open(url, "_blank");
    }
    else {
      window.open('//' + url, "_blank");
    }
  }

    //to Upload Files on Click of Select File
    public  insertIntoDeviationAttachments(deviation1:Deviation,i: number,filesAmount)
    {

      console.log(i,"TOTAL FILES");
      console.log(filesAmount,"TOTAL FILES");
      if((i+1)==filesAmount)

      {
      this.deviation1.createdBy_NTID=this.sharedService.ntid;

      this.deviation1.hintImages = this.urls; //mk

      if(this.deviation1.hintImages.length >0)
      {
        console.log("Working Code ");
        this.commonService.insertIntoDeviationAttachments(deviation1).subscribe( res => {
        deviation1.auditID = res.resultCode;  });
      }

      }
      // this.alertText = this.labels.default.insertedSuccessfully;
      // this.modalService.show(this.successModal);
      // $("modal-container").removeClass("fade");
      // $(".modal-dialog").addClass("modalSize");
      //this.router.navigate([environment.home +'/dashboard'])

      else
      {
        console.log("IGNORE");
      }

    }
}
