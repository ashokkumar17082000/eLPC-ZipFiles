import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProcessConfirmationComponent } from './process-confirmation.component';

describe('ProcessConfirmationComponent', () => {
  let component: ProcessConfirmationComponent;
  let fixture: ComponentFixture<ProcessConfirmationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProcessConfirmationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProcessConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
