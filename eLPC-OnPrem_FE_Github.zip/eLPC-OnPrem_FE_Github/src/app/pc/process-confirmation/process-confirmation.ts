//import { HintImage, Deviation } from "../deviation/deviation";
//import {  Deviation } from "../../../app/main/body/deviation/deviation";
import { Deviation } from "src/app/Deviation/deviation/deviation";
//import { ValueStream } from "../../../app/main/body/value-streams/valuestreamtemplate";
import { ValueStream } from "src/app/Valuestream/valuestreams/valuestreamtemplate";
import { HintImage } from "src/app/Datapool/QuestionModule/questions/question";
import { User } from "../../../app/main/body/shared/common";

export class ProcessConfirmation {
  modeTypeID: number;
  valueStreamID: number;
  assessorID: number;
  questionID: number;
  questionDisplayID: number;
  answer: string;
  targetPercentage:number;
  answerType_AnswerTypeID: number;
  answeredBy: string;
  createdAt: Date;
  modifiedBy: string;
  modifiedAt: Date;
  createdBy_UserID: number;
  modifiedBy_UserID: number;
  tagID: number;
  questionText: string = "";
  questionHintText:string = "";
  hyperLinkURL:string="";
  imageTitle:string;
  displayFileName?:string;
  TagModeID?:Number;
  TagName:string;
  TagTypeName:string;
  LanguageCode:string;
  PlantID?:Number;
  ResumeTagProcessConfirmation:boolean;
  isResumeActivated:boolean;
  valueStreamData: string;
  valueStreamName: string;//added for list view
  timeStamp: Date;
  processConfirmationID: number;
  assessorName: string;
  AnsweredBy_NTID: string;
  isCustomMode: boolean;
  CustomModeID:number;
  isDeviation: boolean;
  obtainedScore: number;
  choiceID: number = 0;

  deviationDescription: string;
  responsibleEmployee: string;
  deviationID: number;
  additionalEmployee:string;
  deviationDisplayID: number;
  dataPoolID: number;
  dataPoolDisplayID: number;

  hintImages?: HintImage[];

  // **************edit datapool***
  answeredBy_NTID: string;
  modifiedBy_NTID: string;
  deviation?: Deviation[];

  valueStreamTemplateName?:string;
  valueStreamCategoryName:string;
  delimiter:string;
  assessorTemplateName:string;

  onMyformData:FormData;//not required
  isShowVsAs:boolean;
  resultCode: number;

  isForgotValueStream :boolean;
  isForgotAssessor :boolean;
  vsSessionID:string;
  asSessionID:string;

  userName:string;
  
  isDefaultAnswerRequired: boolean = false;
  defaultChoiceID:number = 0;
  sessionID:string;
  tagIDList:any;
  tagNameList:any;
  auditID:number = 0;
  auditTemplateID:number = 0;
  selectedTagData?:any;
  AdditionalEmployee: User[];
  modeType:string;
  answeredAndSkippedQuestionID:any;
  editTagList: any;
  tagList:any;
  duedatecount:any;
 addEmpList:any;
  taskID:number = 0;
  superOPLURL: string;
  originTag: string;
  oplurl : string;
  anonymizeUserDataSettingID : number;
  assessortemplate: string;
  isAnswerRequired: boolean = false;
  inLineActivated: boolean = false;
  inlinecount: number = 0;
  isInlineInsertProcess: boolean = false;
  frominline:boolean=false;
  isskipmandatoryAnswer:number;
  IsSkipMandatory:boolean=false;
  attemptNumber :number;
  childEventID :string; 
  process_eventID_Starttime:string;
  generatedEventID:string;
  IsFirstinsertProcessConfirmation:boolean;
}
