import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProcessConfirmationComponent } from './process-confirmation/process-confirmation.component';
const routes: Routes = [
  { path: '', component: ProcessConfirmationComponent }
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
 
})
export class PCRoutingModule { }
