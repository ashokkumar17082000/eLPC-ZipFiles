import { NgModule ,CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProcessConfirmationComponent } from './process-confirmation/process-confirmation.component';
import { PCRoutingModule } from './pc-routing.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { PaginationModule } from 'ngx-bootstrap/pagination';
import { NgxPaginationModule } from 'ngx-pagination';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { SharedModule } from 'src/app/shared/shared.module';
import { OrderModule } from 'ngx-order-pipe';
import { ModalModule } from 'ngx-bootstrap/modal';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { NgToggleModule } from 'ng-toggle-button';

@NgModule({
  declarations: [ProcessConfirmationComponent],
  imports: [
    CommonModule,
    PCRoutingModule,
    FormsModule,
    FormsModule,
    ReactiveFormsModule,
    NgxPaginationModule,
    PaginationModule.forRoot(),
    NgMultiSelectDropDownModule.forRoot(),
    SharedModule,
    OrderModule,
    ModalModule.forRoot(),
    TooltipModule.forRoot(),
    BsDatepickerModule.forRoot(),    
    NgToggleModule.forRoot()
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA] 
})
export class PCModule { }
