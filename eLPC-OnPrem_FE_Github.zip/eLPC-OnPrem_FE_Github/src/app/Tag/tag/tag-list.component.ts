import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { SharedService } from 'src/app/service/shared.service';
import { Tag, TagProxy } from 'src/app/Tag/tag/tag';
import { ActivatedRoute, Router } from "@angular/router";
import { TagService } from 'src/app/service/tag.service';
import { LanguageService } from 'src/app/language.service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { environment } from 'src/environments/environment';
import { Assessor, AssessorTemplate } from 'src/app/Assessor/assessor/assessortemplate';
import { AssessorTemplateService } from 'src/app/service/assessor/assessortemplate.service';
import { ValuestreamTemplateService } from 'src/app/service/common/valuestreamtemplate.service';
import { ValueStream, ValueStreamTemplate } from 'src/app/Valuestream/valuestreams/valuestreamtemplate';
import { FormGroup, FormControl } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { DataPoolService } from 'src/app/service/data-pool.service';
//import { assessorTemplateData, valueStreamTemplateData } from 'src/app/Datapool/QuestionModule/questions/question';

declare var $;

@Component({
  selector: 'app-tag-list',
  templateUrl: './tag-list.component.html',
  styleUrls: ['./tag-list.component.css']
})
export class TagListComponent implements OnInit {
  dateTimeFormat = environment.dateTimeFormat;
  filterdateFormat  = environment.dateTimeFormat.split(" ")[0];

  @ViewChild('alertPopup') lockModal : TemplateRef<any>;

  tagList: Tag[] = [];
  totalList: Tag[];
  dataTable: any;

  valuestreamTemplateList:any;
  assesorTemplateList:any;

  filterId = false;
  filterName = false;
  filterLock = false;
  filterModified = false;
  filterModifiedBy = false;
  filterCreated = false;
  filterCreatedBy = false;
  filterValueStreams=false;
  filterAssessors= false;
  fromdatapooltagid:boolean = false;
  selectedtagfromdatapool:any;
  slectedtagidfromdatapool:any;
  filtertext:string='';
  filterType:string="test";
  key: string = 'name';//for sorting
reverse1: boolean = false;//for sorting
headerFilterName:string="";//for filtering

public data = [];
public settings = {};
public form: FormGroup;
public loadContent: boolean = false;
valueStreams: ValueStream[] = [];
assessors: Assessor[] = [];

  page: number = 1;
  resultPerPage: number = 10;
  startPage: number;
  endPage: number;


  labels: any;
  _subscription: any;
  str1: any;
  filterPopUp: any;
  tagSearchText: string;

  constructor(private local_label: LanguageService, private tagService: TagService, private router:Router, private sharedService: SharedService,
    private modalService: BsModalService,private assessorTemplateService: AssessorTemplateService,private valuestreamService:ValuestreamTemplateService,
    private dataPoolService: DataPoolService,private valueStreamService: ValuestreamTemplateService,
    private route: ActivatedRoute, private datePipe: DatePipe) { }

  ngOnInit() {
    if(this.sharedService.role !=="Designer")
    {
      this.router.navigate([environment.home +'/accessdenied']);
    }
    this.sharedService.show();

    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
    });

    //Modified By EGV1COB
    //As Alberto insists when qustionid clicked it should redirected to edit qusetion page
    this.route.params.subscribe(params => {
      let tagID = params["tid"];
      if(tagID != null )
      {
        this.fromdatapooltagid = true;
        this.slectedtagidfromdatapool =tagID;
        this.getTagsByID(tagID);
      }
    });


    this.getTagList();

  }

  public closeAlertModal(){
    if(document.getElementsByTagName("modal-container").length > 1){
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length-1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length-1]);
    }
    else{
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if(document.getElementsByTagName("bs-modal-backdrop").length > 0){
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }

  }

  public openAlertModal(popUp: any) {
    this.filterPopUp = popUp;
  }

    public closeModal(){
      this.filterPopUp.hide();
      if(this.tagList.length == this.totalList.length)
      {
      //document.getElementsByTagName("popover-container")[0].parentNode.removeChild(document.getElementsByTagName("popover-container")[0]);
      this.filtertext = '';
      this.filterId = false;
      this.filterName = false;
      this.filterLock = false;
      this.filterModified = false;
      this.filterModifiedBy = false;
      this.filterCreated = false;
      this.filterCreatedBy = false;

      this.filterValueStreams = false;
      this.filterAssessors = false;
      //document.querySelector('body').classList.remove('-is-modal');
      }
  }

  /** Method is responsible to move to first page of the pagination. */
  isFirstPage() {
    if (this.page == 1) {
      return;
    }
    else {
    }

    this.page = 1;
    this.startPage = (this.page - 1) * 4 + 1;
    this.endPage = this.page * this.resultPerPage;
  }

  /** Method is responsible to move to last page of the pagination. */
  isLastPage() {
    if (Math.ceil(this.tagList.length / this.resultPerPage) <= this.page) {
      return;
    }
    else {

    }

    this.page = Math.ceil(this.tagList.length / this.resultPerPage);
    this.startPage = (this.page - 1) * 4 + 1;
    this.endPage = this.page * this.resultPerPage;
  }

  /** Method is responsible to change page of the pagination. */
  pageChanged(event): void {

    if (event == 0) {
      return;
    }
    else if (Math.ceil(this.tagList.length / this.resultPerPage) < event) {
      return;
    }
    else {
      this.page = event;
      this.startPage = (this.page - 1) * 4 + 1;
      this.endPage = this.page * this.resultPerPage;
    }
  }

  public getTagList() {
//Get all Tags List 

    this.tagService.getTags().subscribe(res => {

      this.tagList = res;

      this.totalList=this.tagList;

      this.sharedService.hide();
      if (this.sharedService.activeDateRange != null && this.sharedService.activeDateRange.tagSearchText != null 
        &&  this.sharedService.activeDateRange.tagSearchText.length > 0 ) {
        this.tagSearchText = this.sharedService.activeDateRange.tagSearchText;
        this.searchGrid(this.sharedService.activeDateRange.tagSearchText);
      }

      if(this.fromdatapooltagid && this.tagList) {
        console.log("236",this.fromdatapooltagid ,this.tagList)
        for(let i=0;i<this.tagList.length;i++) {
        if(this.tagList[i].tagID == this.slectedtagidfromdatapool) {
        this.selectedtagfromdatapool = this.tagList[i];
        console.log("244",this.selectedtagfromdatapool);
        this.getTagsByID(this.slectedtagidfromdatapool)
       }
      }
        
       }
    },
      err => {
        console.log(err);
        this.sharedService.hide();
      });
  }

  public getTagsByID(tagID:number) {

    this.tagService.getTagsByID(tagID).subscribe(
      res => {
        if(res != null)
        {
          if(this.selectedtagfromdatapool) {
            this.editTag(this.selectedtagfromdatapool)
          }
          // else{
          //   this.editTag(res[0]);
          // }
          
        }
      },
      err => console.log(err)
    );
  }

  proxies1: any;
  proxy: any;
  alertText;
  public async editTag(tag: Tag) {

    if (tag.isLocked) {
      this.tagService.tagProxiesByTagID(tag.tagID).subscribe(res => {

        this.proxies1 = res;

        let ProxyCreatedBy = new TagProxy();
        ProxyCreatedBy.userName = tag.createdBy;
        ProxyCreatedBy.ntid = tag.createdBy_NTID;
        ProxyCreatedBy.createdBy_NTID = tag.createdBy_NTID;
        ProxyCreatedBy.modifiedBy_NTID = tag.modifiedBy_NTID;
        if (!this.proxies1.some(e =>  tag.createdBy_NTID != null && e.ntid.toLowerCase() === tag.createdBy_NTID.toLowerCase())) {
          this.proxies1.push(ProxyCreatedBy);
        }

        let ProxyModified = new TagProxy();
        ProxyModified.userName = tag.modifiedBy;
        ProxyModified.ntid = tag.modifiedBy_NTID;
        ProxyModified.createdBy_NTID = tag.createdBy_NTID;
        ProxyModified.modifiedBy_NTID = tag.modifiedBy_NTID;
        if (!this.proxies1.some(e => tag.modifiedBy_NTID != null && e.ntid.toLowerCase() === tag.modifiedBy_NTID.toLowerCase())) {
          this.proxies1.push(ProxyModified);
        }

        if (this.sharedService.ntid && this.proxies1 && this.proxies1.length > 0) {
          this.proxy = this.proxies1.filter(x => x.ntid == this.sharedService.ntid
            || (x.createdBy_NTID != null && x.createdBy_NTID.toLowerCase() == this.sharedService.ntid.toLowerCase())
            || (x.modifiedBy_NTID != null && x.modifiedBy_NTID.toLowerCase() == this.sharedService.ntid.toLowerCase()));
        }

        if (this.proxy && this.proxy.length > 0) {
          this.tagService.tag = tag;
          this.router.navigate([environment.home + '/taglist/tag-edit']);
        }
        else {
          this.alertText = this.labels.default.notAuthorizeEditTag;
          this.modalService.show(this.lockModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          this.router.navigate([environment.home + '/taglist']);

        }
      }, err => console.error(err));
    }
    else {
      this.tagService.tag = tag;
      if (this.selectedtagfromdatapool ) {
        this.tagService.tag = this.selectedtagfromdatapool;
        
      }       
        this.router.navigate([environment.home + '/taglist/tag-edit']);
      
      
     
      
    }
  }

    /** Method is responsible to Reinitialize Resourcing Table. */
    reInitializeDataTable() {
      if (this.dataTable) {
        this.dataTable.destroy();
        this.dataTable = null;
      }
      this.initializeDataTable();
    }

    /** Method is responsible to Initialize Resourcing Data Table. */
  initializeDataTable() {
    setTimeout(() => {
      this.dataTable = $('#taglist').DataTable({
        "bPaginate": true,
        "bLengthChange": false,
        "bFilter": true,
        "bInfo": false,
        "bAutoWidth": false,
        "ordering": false,
        "pagingType": "full_numbers",
        destroy: true,
        "pageLength": 10,
        language: {
          paginate: {
            next: `<svg class="DP-next" version="1.1" id="Icon_x5F_contour_1_2" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"   viewBox="0 0 192 192"   style="enable-background:new 0 0 192 192;" xml:space="preserve" width="35" height="35"> <g> <polygon points="70.8,158.8 65.2,153.2 122.3,96 65.2,38.8 70.8,33.2 133.7,96 " /> </g> </svg>`,
            previous: `<svg class="DP-prev" version="1.1" id="Icon_x5F_contour_1_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 192 192" style="enable-background:new 0 0 192 192;" xml:space="preserve" width="35" height="35"> <g> <polygon points="121.2,158.8 58.3,96 121.2,33.2 126.8,38.8 69.7,96 126.8,153.2" /> </g> </svg>`,
            first: `<svg version="1.1" id="Icon_x5F_contour" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 192 192" enable-background="new 0 0 192 192" xml:space="preserve" width="18" height="18"><g><polygon points="145.3,158.9 78.3,96.1 141.2,33.2 146.8,38.8 89.7,95.9 150.7,153.1" /></g><g><polygon points="105.3,158.9 38.3,96.1 101.2,33.2 106.8,38.8 49.7,95.9 110.7,153.1" /></g></svg>`,
            last: `<svg version="1.1" id="Icon_x5F_contour" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 192 192" enable-background="new 0 0 192 192" xml:space="preserve" width="18" height="18"><g><polygon points="50.8,158.8 45.2,153.2 102.3,96 45.2,38.8 50.8,33.2 113.7,96 	" /></g><g><polygon points="90.8,158.8 85.2,153.2 142.3,96 85.2,38.8 90.8,33.2 153.7,96 	" /></g></svg>`
          }
        }
      });
    }, 1000);
  }


// ***********************************filtering************************************************************
 //resetting all the filtering and sorting
 resetAll(){
  this.reverse1=false;
  this.filtertext="";
}
 //*********************sorting*********
 sort(key){

    this.key =  this.headerFilterName;;
   this.reverse1 = !this.reverse1;
 }
  getButtonType(buttonname:any):any{

   this.filterType=buttonname;
  }
  // *********************************

  getColumnName(headername:any){

    if(this.filteredItems==undefined){
      this.filteredItems=[]
    }

    this.tagList = this.totalList;//newly added
    this.filtertext = '';
    this.filterId = false;
    this.filterName = false;
    this.filterLock = false;
    this.filterModified = false;
    this.filterModifiedBy = false;
    this.filterCreated = false;
    this.filterCreatedBy = false;

    this.filterValueStreams = false;
    this.filterAssessors = false;

    if (headername == 'tagDisplayID') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].tagDisplayID);
      }
      this.filterId = !this.filterId;
    }

    else if (headername == 'tagName') {
      for(var i=0;i<this.totalList.length;i++){
        this.filteredItems.push(this.totalList[i].tagName);
      }
      this.filterName = !this.filterName;
    }


    else if (headername == 'valueStreamTemplateName') {
      for(var i=0;i<this.totalList.length;i++){
        this.filteredItems.push(this.totalList[i].valueStreamTemplateName);
      }
      this.filterValueStreams=!this.filterValueStreams;
    }
    else if (headername == 'assessorTemplateName') {
      for(var i=0;i<this.totalList.length;i++){
        this.filteredItems.push(this.totalList[i].assessorTemplateName);
      }
      this.filterAssessors=!this.filterAssessors;
    }
    else if (headername == 'isLocked') {
      for(var i=0;i<this.totalList.length;i++){
        this.filteredItems.push(this.totalList[i].isLocked);
      }
      this.filterLock = !this.filterLock;
    }
    else if (headername == 'modifiedAt') {
      for(var i=0;i<this.totalList.length;i++){
        this.filteredItems.push(this.datePipe.transform(this.totalList[i].modifiedAt,this.filterdateFormat));
      }
      this.filterModified = !this.filterModified;
    }
    else if (headername == 'modifiedBy') {
      for(var i=0;i<this.totalList.length;i++){
        this.filteredItems.push(this.totalList[i].modifiedBy);
      }
      this.filterModifiedBy = !this.filterModifiedBy;
    }
    else if (headername == 'createdAt') {
      for(var i=0;i<this.totalList.length;i++){
        this.filteredItems.push(this.datePipe.transform(this.totalList[i].createdAt,this.filterdateFormat));
      }
      this.filterCreated = !this.filterCreated;
    }
    else if (headername == 'createdBy') {
      for(var i=0;i<this.totalList.length;i++){
        this.filteredItems.push(this.totalList[i].createdBy);
      }
      this.filterCreatedBy = !this.filterCreatedBy;
    }
    this.headerFilterName = headername;
    this.searchFilter();
  }
  setForm() {
    this.form = new FormGroup({
      name: new FormControl(
        this.data
      )
    });
    this.loadContent = true;
  }
  searchFilter(){

    this.data=[];
     // ********************************searching
  if(this.headerFilterName=="tagName"){
    for(var tagDet of this.tagList){
      let newItem={
        tagID:tagDet.tagID,
        tagName:tagDet.tagName
      };
      if(!this.data.includes(newItem)){
        if (!this.data.some(e => e.tagName === tagDet.tagName)) {//newly added
          this.data.push(newItem);
        }
      }
    }
  }
  else if(this.headerFilterName=="valueStreamTemplateName"){
    for(var tagDet of this.tagList){
      let newItem={
        tagID:tagDet.tagID,
        valueStreamTemplateName:tagDet.valueStreamTemplateName
      };
      if(!this.data.includes(newItem)){
        if (!this.data.some(e => e.valueStreamTemplateName === tagDet.valueStreamTemplateName)) {//newly added
          this.data.push(newItem);
        }
      }
    }
  }
  else if(this.headerFilterName=="assessorTemplateName"){
    for(var tagDet of this.tagList){
      let newItem={
        tagID:tagDet.tagID,
        assessorTemplateName:tagDet.assessorTemplateName
      };
      if(!this.data.includes(newItem)){
        if (!this.data.some(e => e.assessorTemplateName === tagDet.assessorTemplateName)) {//newly added
          this.data.push(newItem);
        }
      }
    }
  }
  else if(this.headerFilterName=="isLocked"){
    for(var tagDet of this.tagList){
      let newItem={
        tagID:tagDet.tagID,
        isLocked:tagDet.isLocked
      };
      if(!this.data.includes(newItem)){
        if (!this.data.some(e => e.isLocked === tagDet.isLocked)) {//newly added
          this.data.push(newItem);
        }
      }
    }
  }

  else if (this.headerFilterName == "modifiedAt") {
      for (var tagDet of this.tagList) {
        this.str1= this.datePipe.transform(tagDet.modifiedAt,this.filterdateFormat);//converting the date format
        let newItem = {
          tagID: tagDet.tagID,
          modifiedAt: this.str1
        };
        if (!this.data.includes(newItem)) {
            if (!this.data.some(e => e.modifiedAt === this.str1)) {
              this.data.push(newItem);
            }
        }
      }
    }
  else if (this.headerFilterName == "modifiedBy") {


      for (var tagDet of this.tagList) {
        let newItem = {
          tagID: tagDet.tagID,
          modifiedBy: tagDet.modifiedBy
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.modifiedBy === tagDet.modifiedBy)) {
            this.data.push(newItem);
          }
        }
      }
    }
  else if(this.headerFilterName=="createdAt"){
    for(var tagDet of this.tagList){
      this.str1= this.datePipe.transform(tagDet.createdAt,this.filterdateFormat);//converting the date format
      let newItem={
        tagID:tagDet.tagID,
        createdAt:this.str1
      };
      if(!this.data.includes(newItem)){
        if (!this.data.some(e => e.createdAt === this.str1)) {
          this.data.push(newItem);
        }
      }
    }
  }
  else if(this.headerFilterName=="createdBy"){
    for(var tagDet of this.tagList){
      let newItem={
        tagID:tagDet.tagID,
        createdBy:tagDet.createdBy
      };
      if(!this.data.includes(newItem)){
        if (!this.data.some(e => e.createdBy === tagDet.createdBy)) {
          this.data.push(newItem);
        }
      }
    }
  }

  else if (this.headerFilterName == "tagDisplayID") {
      for (var tagDet of this.tagList) {
        let newItem = {
          tagID: tagDet.tagID,
          tagDisplayID:tagDet.tagDisplayID
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.tagDisplayID === tagDet.tagDisplayID)) {
            this.data.push(newItem);
          }
        }
      }
    }

     this.settings = {//setting for multiselect dropdown
       singleSelection: false,
       idField: 'tagID',
       textField: this.headerFilterName,


       enableCheckAll: true,
       selectAllText: 'Select All',
       unSelectAllText: 'Unselect All',
       allowSearchFilter: true,
       limitSelection: -1,
       clearSearchFilter: true,
       maxHeight: 197,
       itemsShowLimit: 0,
       searchPlaceholderText: 'Search',
       noDataAvailablePlaceholderText: 'No Data Available',
       closeDropDownOnSelection: false,
       showSelectedItemsAtTop: false,
       defaultOpen: false
     };
     this.setForm();
     // ************************************************
  }
// ************************************filtering ends******************************************************
// ***********************************Dropdown multiselect filtering**************************
filteredItems: Array<any>;
x:any;
onItemSelect(item: any) {

    if(this.filteredItems == undefined){
     this.filteredItems = [];
    }

    if(this.headerFilterName=='tagName'){
      if(this.filteredItems.indexOf(item.tagName)    <0)
      {
        this.filteredItems.push(item.tagName);
      }
      this.tagList=this.totalList.filter(f => this.filteredItems.includes(f.tagName));
    }
    else if(this.headerFilterName=='valueStreamTemplateName'){
      if(this.filteredItems.indexOf(item.valueStreamTemplateName)    <0)
      {
        this.filteredItems.push(item.valueStreamTemplateName);
      }
      this.tagList=this.totalList.filter(f => this.filteredItems.includes(f.valueStreamTemplateName));
    }
    else if(this.headerFilterName=='assessorTemplateName'){
      if(this.filteredItems.indexOf(item.assessorTemplateName)    <0)
      {
        this.filteredItems.push(item.assessorTemplateName);
      }
      this.tagList=this.totalList.filter(f => this.filteredItems.includes(f.assessorTemplateName));
    }
    else if(this.headerFilterName=='isLocked'){
      if(this.filteredItems.indexOf(item.isLocked)    <0)
      {
        this.filteredItems.push(item.isLocked);
      }
      this.tagList=this.totalList.filter(f => this.filteredItems.includes(f.isLocked));
    }
    else if(this.headerFilterName=='modifiedAt'){
      if(this.filteredItems.indexOf(item.modifiedAt)    <0)
      {
        this.filteredItems.push(item.modifiedAt);
      }
        this.tagList=this.totalList.filter(f => this.filteredItems.includes(this.datePipe.transform(f.modifiedAt,this.filterdateFormat)))
    }

    else if(this.headerFilterName=='modifiedBy'){
      if(this.filteredItems.indexOf(item.modifiedBy)    <0)
      {
        this.filteredItems.push(item.modifiedBy);
      }
      this.tagList=this.totalList.filter(f => this.filteredItems.includes(f.modifiedBy));
    }
    else if(this.headerFilterName=='createdAt'){
      if(this.filteredItems.indexOf(item.createdAt)    <0)
      {
        this.filteredItems.push(item.createdAt);
      }
      this.tagList=this.totalList.filter(f => this.filteredItems.includes(this.datePipe.transform(f.createdAt,this.filterdateFormat)))
    }
    else if(this.headerFilterName=='createdBy'){
      if(this.filteredItems.indexOf(item.createdBy)    <0)
      {
        this.filteredItems.push(item.createdBy);
      }
      this.tagList=this.totalList.filter(f => this.filteredItems.includes(f.createdBy));
    }

    else if (this.headerFilterName == 'tagDisplayID') {
    if (this.filteredItems.indexOf(item.tagDisplayID) < 0) {
      this.filteredItems.push(item.tagDisplayID);
    }
    this.tagList = this.totalList.filter(f => this.filteredItems.includes(f.tagDisplayID));
  }
  }

  public onDeSelect(item: any) {

    if (this.filteredItems == undefined) {
      this.filteredItems = [];
    }

    if (this.headerFilterName == 'tagName') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.tagName);
      this.tagList = this.totalList.filter(f => this.filteredItems.includes(f.tagName));
    }
    else if (this.headerFilterName == 'valueStreamTemplateName') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.valueStreamTemplateName);
      this.tagList = this.totalList.filter(f => this.filteredItems.includes(f.valueStreamTemplateName));
    }
    else if (this.headerFilterName == 'assessorTemplateName') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.assessorTemplateName);
      this.tagList = this.totalList.filter(f => this.filteredItems.includes(f.assessorTemplateName));
    }
    else if (this.headerFilterName == 'isLocked') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.isLocked);
      this.tagList = this.totalList.filter(f => this.filteredItems.includes(f.isLocked));
    }
    else if (this.headerFilterName == 'modifiedAt') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.modifiedAt);
      this.tagList=this.totalList.filter(f => this.filteredItems.includes(this.datePipe.transform(f.modifiedAt,this.filterdateFormat)));
    }
    else if (this.headerFilterName == 'modifiedBy') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.modifiedBy);
      this.tagList = this.totalList.filter(f => this.filteredItems.includes(f.modifiedBy));
    }
    else if (this.headerFilterName == 'createdAt') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.createdAt);
      this.tagList=this.totalList.filter(f => this.filteredItems.includes(this.datePipe.transform(f.createdAt,this.filterdateFormat)));
    }
    else if (this.headerFilterName == 'createdBy') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.createdBy);
      this.tagList = this.totalList.filter(f => this.filteredItems.includes(f.createdBy));
    }
    else if (this.headerFilterName == 'tagDisplayID') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.tagDisplayID);
      this.tagList = this.totalList.filter(f => this.filteredItems.includes(f.tagDisplayID));
    }
  }
  onSelectAll(items: any) {

    if(this.filteredItems == undefined ){
      this.filteredItems = [];
     }
    for(var i=0;i<items.length;i++){
      if(this.headerFilterName=='tagName'){
        this.filteredItems.push(items[i].tagName)
      }
      else if(this.headerFilterName=='valueStreamTemplateName'){
        this.filteredItems.push(items[i].valueStreamTemplateName)
      }
      else if(this.headerFilterName=='assessorTemplateName'){
        this.filteredItems.push(items[i].assessorTemplateName)
      }
      else if(this.headerFilterName=='isLocked'){
        this.filteredItems.push(items[i].isLocked)
      }
      else if(this.headerFilterName=='modifiedAt'){
        this.filteredItems.push(items[i].modifiedAt)
      }
      else if(this.headerFilterName=='modifiedBy'){
        this.filteredItems.push(items[i].modifiedBy)
      }

      else if(this.headerFilterName=='createdAt'){
        this.filteredItems.push(items[i].createdAt)
      }
      else if(this.headerFilterName=='createdBy'){
        this.filteredItems.push(items[i].createdBy)
      }
      else if (this.headerFilterName == 'tagDisplayID') {
        this.filteredItems.push(items[i].tagDisplayID)
      }
    }
    this.tagList=this.totalList;
  }
  public onDeSelectAll(items: any) {
    this.filteredItems=[];
    this.tagList=this.totalList;
  }
//  *******************************************************************************************Dropdown filtering ends here***************

 // ***************************redirecting to the valuestreamTemplate***************
 public valueStreamTemplateDetailsByTemplateID:ValueStreamTemplate=new ValueStreamTemplate();
 updtVS(valueStreamTemplateID:any){

 this.valuestreamService.fetchValueStreamsByTemplateID(valueStreamTemplateID).subscribe(res=>{
   this.valueStreamTemplateDetailsByTemplateID=res[0];

   this.updateTemplate(this.valueStreamTemplateDetailsByTemplateID);
      },err=>console.log(err));
}

 updateTemplate(valueStreamTemplate: any) {

        this.valuestreamService.valueStreamTemplate = valueStreamTemplate;

       if(valueStreamTemplate.isLocked){
         this.valuestreamService.valueStreamProxiesByTemplateID(valueStreamTemplate.valueStreamTemplateID).subscribe(res => {
           this.proxies1 = res;
           if (this.sharedService.ntid && this.proxies1 && this.proxies1.length > 0) {
             this.proxy = this.proxies1.filter(x => x.proxy == this.sharedService.ntid
               || x.createdBy_NTID == this.sharedService.ntid
                    || x.modifiedBy_NTID == this.sharedService.ntid); //checking for the proxy, designer, who locked the record

           }
           if ((this.proxy && this.proxy.length > 0) || this.sharedService.ntid == valueStreamTemplate.createdBy_NTID) {
             this.router.navigate([environment.home +'/valuestreams/valuestreams-edit']);
           }

             else {
               this.alertText = this.labels.default.notAuthorizedToEdit;
               this.modalService.show(this.lockModal);
               $("modal-container").removeClass("fade");
               $(".modal-dialog").addClass("modalSize");
               this.router.navigate([environment.home +'/valuestreams']);
             }
           }, err => console.error(err));
       }
      else{
       this.router.navigate([environment.home +'/valuestreams/valuestreams-edit']);
      }

     }
 // ********************************************************************************
 // **********************redirecting to the AssessorTemplate******************
 public assessorTemplateDetailsByTemplateID:AssessorTemplate=new AssessorTemplate();
 updtAS(assessorTemplateID:any){

 this.assessorTemplateService.fetchAssessorTemplateByTemplateID(assessorTemplateID).subscribe(res=>{
   this.assessorTemplateDetailsByTemplateID=res[0];

   this.editAsessor(this.assessorTemplateDetailsByTemplateID);
      },err=>console.log(err));
}
 editAsessor(assessorTemplate: any) {

       this.assessorTemplateService.assessorTemplate = assessorTemplate;
       if(assessorTemplate.isLocked){
         this.assessorTemplateService.assessorProxiesByAssessorTemplateID(assessorTemplate.assessorTemplateID).subscribe(res => {
           this.proxies1 = res;
           if (this.sharedService.ntid && this.proxies1 && this.proxies1.length > 0) {
             this.proxy = this.proxies1.filter(x => x.proxy == this.sharedService.ntid
                   || x.createdBy_NTID == this.sharedService.ntid
                    || x.modifiedBy_NTID == this.sharedService.ntid);

           }
           if ((this.proxy && this.proxy.length > 0) || this.sharedService.ntid == assessorTemplate.createdBy_NTID) {
             this.router.navigate([environment.home +'/assessors/assessor-edit']);

           }

             else {
               this.alertText = this.labels.default.notAuthorizedToEdit;
               this.modalService.show(this.lockModal);
               $("modal-container").removeClass("fade");
               $(".modal-dialog").addClass("modalSize");
               this.router.navigate([environment.home +'/assessors']);
             }
           }, err => console.error(err));
       }
       else{
         this.router.navigate([environment.home +'/assessors/assessor-edit']);
        }

     }
 // ********************************************************************************


  copyToClipBoard(text){
    var plainText = {"plant": this.sharedService.plantID, "id":text};
    var encString = this.sharedService.encrypt(JSON.stringify(plainText));
    var url = environment.uiUrl + environment.home +'/processConfirmation;tid=' + encString ;
    var input = document.createElement('textarea');
    input.innerHTML = url;
    document.body.appendChild(input);
    input.select();
    input.setSelectionRange(0, 99999);
    document.execCommand('copy');
    document.body.removeChild(input);
  }

  ExportExcelTags(){
    this.dataPoolService.GetExcelFile("Tag");
  }

  
exportAsXLSX() {
  var IDs = this.tagList.map(r => {
    return r.tagID
  });
  this.dataPoolService.GetExcelFileByIDs("Tag", IDs);
}

searchGrid(value: string) {
  if (value.length > 0) {
    var searchText = value.trim().toLowerCase();
    this.tagList = this.totalList;
    this.sharedService.activeDateRange.tagSearchText = value;

    this.tagList = this.tagList.filter(x =>
      (x.tagName != null && x.tagName.trim().toLowerCase().includes(searchText))
      || (x.tagDisplayName != null && x.tagDisplayName.trim().toLowerCase().includes(searchText))
      || (x.isLocked != null && x.isLocked.toString().trim().toLowerCase().includes(searchText))
      || (x.tagDisplayID != null && x.tagDisplayID.toString().trim().toLowerCase().includes(searchText))
      || (x.valueStreamNameList != null && x.valueStreamNameList.toString().trim().toLowerCase().includes(searchText))
      || (x.valueStreamTemplateName != null && x.valueStreamTemplateName.toString().trim().toLowerCase().includes(searchText))
      || (x.assessorNameList != null && x.assessorNameList.toString().trim().toLowerCase().includes(searchText))
      || (x.assessorTemplateName != null && x.assessorTemplateName.toString().trim().toLowerCase().includes(searchText))
      || (x.modifiedAt != null && this.datePipe.transform(x.modifiedAt, this.filterdateFormat).trim().toLowerCase().includes(searchText))
      || (x.modifiedBy != null && x.modifiedBy.trim().toLowerCase().includes(searchText))
      || (x.createdAt != null && this.datePipe.transform(x.createdAt, this.filterdateFormat).trim().toLowerCase().includes(searchText))
      || (x.createdBy != null && x.createdBy.trim().toLowerCase().includes(searchText))
    );
    this.page = 1;
  }
  else {
    this.tagList = this.totalList;
    this.sharedService.activeDateRange.tagSearchText = "";
  }
}
}
