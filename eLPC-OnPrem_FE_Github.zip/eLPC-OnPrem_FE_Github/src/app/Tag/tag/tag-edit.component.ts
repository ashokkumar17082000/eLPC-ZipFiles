
import { Component, ElementRef, QueryList,OnInit,TemplateRef ,ViewChild, ViewChildren,} from '@angular/core';
import { SharedService } from 'src/app/service/shared.service';
import { TagService } from 'src/app/service/tag.service';
import { Router } from '@angular/router';
import { QuestionService } from 'src/app/service/question.service';
import { Tag, TagStreamHistory, AssessorValueStreamList } from 'src/app/Tag/tag/tag';
import { Question, assessorTemplateData, valueStreamTemplateData } from 'src/app/Datapool/QuestionModule/questions/question';
import { Assessor, AssessorTemplate } from 'src/app/Assessor/assessor/assessortemplate';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ValueStreamTemplate, ValueStreamCategory, ValueStream } from 'src/app/Valuestream/valuestreams/valuestreamtemplate';
import { ValuestreamTemplateService } from 'src/app/service/common/valuestreamtemplate.service';
import { AssessorTemplateService } from 'src/app/service/assessor/assessortemplate.service';
import { CustomModeService } from "src/app/service/custom-mode.service";
import { LanguageService } from 'src/app/language.service';
import { environment } from 'src/environments/environment';
import { isThisQuarter } from 'date-fns';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { DatePipe, formatDate } from '@angular/common';
import * as XLSX from 'xlsx';
import { ProcessConfirmationService } from 'src/app/service/common/process-confirmation.service';
import { Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
//import { DebugRenderer2 } from '@angular/core/src/view/services';

@Component({
  selector: 'app-tag-edit',
  templateUrl: './tag-edit.component.html',
  styleUrls: ['./tag-edit.component.css']
})
export class TagEditComponent implements OnInit {
  @ViewChild('alertPopup') warningModal : TemplateRef<any>;
  @ViewChild('successPopup') successModal : TemplateRef<any>;
  alertText;
  model: any = {};
  tagList: Tag[] = [];
  RandomTagList: Tag[] =[];
  randomQuestions : Question[] = [];
  availableTags: Tag[] = [];
  // availableRandomTags : Tag[] =[];
  selectedTags: Tag[] = [];
  selectedQuestions: Question[] = [];
  selectedQuestionsNew:Question[]=[];
  orderSelectedQuestions: Question[] = [];
  tag: Tag = new Tag();
  isEdit: boolean = false;
  isAdd: boolean = false;
  dateTimeFrom = new Date();
  dateTimeTo = new Date();
  bsValue = new Date();
  dateTimeFormat = environment.dateTimeFormat;
  questionOrders: { id: number }[];
  questionList: Question[];
  availableQuestions: Question[] = [];
  availableRandomQuestions : Question [] =[];
  addedRandomQuestions : Question[] =[];
  selectedTagIDs: string;
  selectedQuestionIDs: any;
  closeResult: string;
  headeFilterName: any;
  selectedmultitag: number;
  tagChecked: boolean;
  tagUnChecked: boolean;
  arrayBuffer: any;
  file: File;
   modalRef: BsModalRef;
  tagStreamHistoryDetails: TagStreamHistory[];
  QuestionOrderList:any=[];
  IsRandomQuestion: boolean = false;
  SelectedrandomQuestionLimit: number;
  finalRandomQuestionsOnly
  finalQuestionOrder:any [] = [];
  qnorder:number[]=[];
  isSaveTag:number=0;
  config = {
    animated: false,
    keyboard: true,
    ignoreBackdropClick: true
  };

  templateId: number;
  isDisabled :boolean = true;
  visulizationViewModeID: any;
  unload=false;
  resultQuestionOrder: any = [];
  randomQuestionOrder:any = [];

  valuestreamTemplateList:any;
  assesorTemplateList:any;

  inlineCountToText: number = 0;
  actiavteinlinewarning: boolean = false;
  IsInlineModeActivate: boolean = false;
  errorMessage: string = '';
  hintmessage: string = '';
  hintInLineCount: number = 0;
  isLoading: boolean = false;
  isLoadingVs: boolean = false;
  fromonInitdata: boolean = false;
  loadingMessage = 'Loading...';
  linkedTagSelectedCount: number = 0;
  inLineQuestionCount_NewTag: number = 0;
  inLineLinkedTag_QuestionCount_NewTag: number = 0;
  questionSelectedCount_NewTag: number = 0;
  addNew_FinalQuestionAndTagCount: number = 0;
inLineQuestionCount_EditedTag: number = 0;
  inLineLinkedTag_QuestionCount_EditedTag: number = 0;
  questionSelectedCount_EditedTag: number = 0;
  EditedTag_FinalQuestionAndTagCount: number = 0;
  constructor(private local_label: LanguageService, private processConfirmationService: ProcessConfirmationService, private modalService: BsModalService, private sharedService: SharedService, private tagService: TagService, private router: Router,
    private questionService: QuestionService, private valueStreamService: ValuestreamTemplateService, private assessorTemplateService: AssessorTemplateService,private customModeService: CustomModeService) {
    this.dateTimeFrom = new Date();
    this.dateTimeTo = new Date();


    this.tag = this.tagService.tag;
    this.tagService.tag = undefined;
    var d = new Date();

    if (this.tag == undefined || this.tag.tagID == undefined) {
      this.isAdd = true;
      this.isEdit = false;
      this.tag = new Tag();
      this.tag.suppressedDateRangeFrom = new Date(d.getFullYear(),d.getMonth(),d.getDate());
      this.tag.suppressedDateRangeTo = new Date(d.getFullYear(),d.getMonth(),d.getDate());
    }
    else if (Object.keys(this.tag).length == 0) {
      this.isAdd = true;
      this.isEdit = false;
      this.tag = new Tag();
      this.tag.suppressedDateRangeFrom = new Date(d.getFullYear(),d.getMonth(),d.getDate());
      this.tag.suppressedDateRangeTo = new Date(d.getFullYear(),d.getMonth(),d.getDate());
    }
    else {
      this.isAdd = false;
      this.isEdit = true;
    }

    if (this.isEdit) {
      this.templateId = this.tag.tagID;
      this.tag.suppressedDateRangeFrom = new Date(this.tag.suppressedDateRangeFrom);
      this.tag.suppressedDateRangeTo = new Date(this.tag.suppressedDateRangeTo);

    }

    if (this.isAdd) {
      if (this.tag == undefined) {
        this.tag = Object.assign(new Tag());
      }

      this.selectedItemTagStream = [];
    this.selectedItemValueStreamCategory = [];
    this.selectedItemAssessorTemplate = [];


    if(this.selectedItemAssessorTemplate.length < 1)
    {

      this.valueStreams=[];
      this.selectedValueStreams=[];

     this.valueStreamCategories=[];
     this.selectedItemValueStreamCategory=[];

      this.assessors = [];
      this.selectedAssessors = [];
    }

    //   this.tag.assigned_AssessorTemplateID = [];
    //   this.tag.assigned_ValueStreamTemplateID = [];

    //  this.tag.assigned_ValueStreamTemplateID = [] ;
    // this.tag.assigned_ValueStreamCategoryID = undefined;
     this.selectedItemValueStreamCategory = [];

      this.tag.tagTypeID = 1;
      this.tag.isBranchLogicToBeFollowed = false;
      this.tag.anonymizeUserDataSettingID = 3;
      //this.tag.isBranchLogicToBeFollowed = false;
      this.tag.isSingleQuestionSuppressed = true;
      this.tag.tag_PriorityID = 4;
      this.tag.isDeleted = false;
      this.tag.isLocked = false;
      this.tag.isMandatoryAssessorsDefined = false;
      this.tag.isRandomQuestion= false;
      this.tag.isTargetFrequencyDefined = false;
      this.tag.createdAt = new Date();
      this.tag.modifiedAt = new Date();
      this.tag.createdBy = null;
      this.tag.modifiedBy = null;
      this.tag.suppressedDateRangeFrom = new Date(d.getFullYear(),d.getMonth(),d.getDate());
      this.tag.suppressedDateRangeTo =  new Date(d.getFullYear(),d.getMonth(),d.getDate());
      this.tag.tagID = 0;
      this.tag.tagName = undefined;
      this.tag.targetFrequencyTypeID = undefined;
      this.tag.targetFrequencyValue = undefined;
      this.tag.isSearchableTag = true;
      this.tag.isSkipQuestionDefined = true;
      this.tag.isQuestionOverviewDefined = false;
      this.tag.isProgressPercentageDefined = false;
      this.tag.isResultOverviewDefined = false;
      this.tag.isResumeTagDefined = false;
      this.tag.isReportingEmailDefined = false;
    }
    this.availableTags = [];
    this.selectedTags = [];
    this.selectedQuestions = [];
    this.selectedQuestionsNew=[];
    this.orderSelectedQuestions = [];
    this.QuestionOrderList=[];
  }

  labels: any;
  _subscription: any;


  //For multi select dropdown - Assign tag to Value stream template
  dropdownSettingsTagStream = {};
  selectedItemTagStream: ValueStreamTemplate[] = [];

  //For multi select dropdown - Assign tag to Value Stream Category
  dropdownSettingsValueStreamCategory = {};
  selectedItemValueStreamCategory: ValueStreamCategory[] = [];

  //For multi select dropdown - Assign tag to assessor template
  dropdownSettingsAssessorTemplate = {};
  selectedItemAssessorTemplate: AssessorTemplate[] = [];

   async ngOnInit() {


    if(this.sharedService.role !=="Designer")
    {
      this.router.navigate([environment.home +'/accessdenied']);
    }
    this.tagUnChecked = true;
    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
    });

      await this.valueStreamService.getValueStream().subscribe(async res2 => {
      this.valueStreams = res2;
           //Get all Assesssors
            await this.assessorTemplateService.getAssessors().subscribe(async res3 => {
            this.assessors = res3;
           await  this.questionService.fetchVSASListByID("Tag","ValueStream",0,this.tag.tagID).subscribe(res5 => {
            if(res5[0].idList != null){
              var vsIDList = res5[0].idList.toString();
              this.valuestreamTemplateList=this.getVSTemplate(vsIDList,res2);
              this.tag.valueStreamTemplateNameArL = this.valuestreamTemplateList;
            }
              this.getValueStreamList();
              //this.valueStreams=this.valueStreams.filter(r=>this.selectedItemValueStreamTemplate.find(x=>x.valueStreamTemplateID== r.valueStreamTemplateID));
             // this.valuestreamcategoryTemplateList=this.getVSCategoryTemplate(vsIDList,res4);
              //this.questionDetail.valueStreamCategoryNameArL=this.valuestreamcategoryTemplateList;
               });
               //Call API for AssessorIDlist

              this.questionService.fetchVSASListByID("Tag","Assessor",0,this.tag.tagID).subscribe(res6 => {
                if(res6[0].idList != null){
                var asIDList = res6[0].idList.toString();
                 //this.question.assessorTemplateNameArL = asList;
                 this.assesorTemplateList=this.getASTemplate(asIDList,res3);
                 this.tag.assessorTemplateNameArL=this.assesorTemplateList;
                }
                 this.getAssessorTemplateList();
                  });
              });
           });
    this.getTagQuestionList();
    this.onAssessorSelect();
   // this.getValueStreamList();
   // this.getAssessorTemplateList();
    this.valueStreamSettings = {
      singleSelection: false,
      idField: 'valueStreamID',
      textField: 'valueStreamName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 5,
      allowSearchFilter: true,
      closeDropDownOnSelection: true
    };
    this.selectedValueStreams = [];
    this.selectedValueStreamIDs = [];

    //for Assessor
    this.assessorSettings = {
      singleSelection: false,
      idField: 'assessorID',
      textField: 'assessorName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 5,
      allowSearchFilter: true
    };
    this.selectedAssessors = [];
    //this.sharedService.hide();

    //For multi select dropdown - Assign tag to Value stream template
    this.dropdownSettingsTagStream = {
      singleSelection: false,
      idField: 'valueStreamTemplateID',
      textField: 'valueStreamTemplateName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 5,
      allowSearchFilter: true,
      closeDropDownOnSelection: true
    };

      //For multi select dropdown - Assign tag to Value Stream Category
    this.dropdownSettingsValueStreamCategory = {
      singleSelection: false,
      idField: 'valueStreamCategoryID',
      textField: 'valueStreamCategoryName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 5,
      allowSearchFilter: true,
      closeDropDownOnSelection: true
    };

    //For multi select dropdown - Assign tag to assessor template
    this.dropdownSettingsAssessorTemplate = {
      singleSelection: false,
      idField: 'assessorTemplateID',
      textField: 'assessorTemplateName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 5,
      allowSearchFilter: true,
      closeDropDownOnSelection: true
    };
    //debugger;
    if (this.tag.tagTypeID == 1)
      {
        this.IsInlineModeActivate = true;
    }

    if (this.tag.isInlineModeOn) {
   // this.getInlineCountFromTagEdit(this.tag.tagID);
     this.GetCurrentSelectionQsAndtagCount(this.tag.tagID).subscribe(
      res => {
        if (res != null) {
          debugger;
          this.selectedQuestionsNew?.length;
          this.selectedTags;
          //this.inLineLinkedTag_QuestionCount_EditedTag = res;
          //this.hintInLineCount = res >= 20 ? res : Math.round(res / 2);
          if (res == 1000)
            {
              this.hintInLineCount = 20;
            }
            else if(res >= 40 )
            {
              this.hintInLineCount = 20;
            }
            else
            {
              this.hintInLineCount = Math.round(res / 2);
              //this.hintInLineCount = res
            }
          this.inlineCountToText =  this.hintInLineCount;
          this.setinLineCount();
          this.isLoading = false;

          //for bring main table question count and minus the res
          this.GetCurrentSelectionQsAndtagCount(this.tag.tagID, true).subscribe(
            res1 => {
              debugger;
              if (res1 != null) {
                this.inLineQuestionCount_EditedTag = res1;
                if (res1 > res)
                   {
                    this.inLineLinkedTag_QuestionCount_EditedTag = res1 - res;
                   }
                   else{
                    this.inLineLinkedTag_QuestionCount_EditedTag = res -res1;
                   }
              }
            },
            err => {
              console.error('Error occurred:', err);
            }
          );

          let selectedQuestionCount_EditedTagCreation =  this.selectedQuestionsNew?.length;
          this.questionSelectedCount_EditedTag = selectedQuestionCount_EditedTagCreation;
          let scltdTagId = this.selectedTagIDs;

          this.startLoading();
        }
      },
      err => {
        console.error('Error occurred:', err);
      }
    );
      this.tag.inlineCount = this.tag.inlineCount;

    }
    }




  //Function to get the Updated Question List
getVSTemplate(valueStreamIDList: string, valueStreams: ValueStream[]) {

  let result: valueStreamTemplateData[] = [];;
  let vsIDArr = valueStreamIDList.split(",").map(function (vsID) {
    return parseInt(vsID);
  });

  valueStreams.filter(r => vsIDArr.includes(r.valueStreamID))
    .map(item => item.valueStreamTemplateID)
    .filter((value, index, self) => self.indexOf(value) === index).forEach(element => {
      let vsData = new valueStreamTemplateData();
      let vsByTemplate = valueStreams.filter(x => x.valueStreamTemplateID == element);

      let vsBySelectedTemplate = vsByTemplate.filter(r => vsIDArr.includes(r.valueStreamID));
      //vsData.vsTemplate.push(vsByTemplate[0]);
      vsData.vsName = vsBySelectedTemplate.map(r => r.valueStreamName).join(",");
      vsData.vsTemplateID=vsByTemplate[0].valueStreamTemplateID;
      vsData.vsTemplateName=vsByTemplate[0].valueStreamTemplateName;

      result.push(vsData);

    });

  return result;
}

//Function to get the Updated Assessors  Question List
getASTemplate(AssessorIDList: string, assessors: Assessor[]) {

  let result: assessorTemplateData[] = [];;
  let vsIDArr = AssessorIDList.split(",").map(function (vsID) {
    return parseInt(vsID);
  });

  assessors.filter(r => vsIDArr.includes(r.assessorID))
    .map(item => item.assessorTemplateID)
    .filter((value, index, self) => self.indexOf(value) === index).forEach(element => {
      let vsData = new assessorTemplateData();
      let vsByTemplate = assessors.filter(x => x.assessorTemplateID == element);
      let vsBySelectedTemplate = vsByTemplate.filter(r => vsIDArr.includes(r.assessorID));
      //vsData.vsTemplate.push(vsByTemplate[0]);
      vsData.vsName = vsBySelectedTemplate.map(r => r.assessorName).join(",");
      vsData.vsTemplateID=vsByTemplate[0].assessorTemplateID;
      vsData.vsTemplateName=vsByTemplate[0].assessorTemplateName;

      result.push(vsData);

    });

  return result;
}

  //For multi select dropdown - Assign tag to Value stream template
  onSelectTagStream(item: ValueStreamTemplate)
  {
    console.log(this.valueStreams)
    if(this.valueStreams.length == 0) {
      this.valueStreamService.getValueStream().subscribe(res => {
        this.valueStreams = res;
        this.valueStreamTemplateChange(item.valueStreamTemplateID);
      })

      if(this.visulizationViewModeID == 2){
        this.valueStreamService.getValueStreamCategory().subscribe((res) => {
          this.valueStreamCategories = res;
          this.valueStreamTemplateChange(item.valueStreamTemplateID);
        });
      }

    }else{
      this.valueStreamTemplateChange(item.valueStreamTemplateID);
    }
   // this.tag.assigned_ValueStreamTemplateID = undefined;

  }
  //OnDragDropListItem
  OnDragDropListItem(event?: CdkDragDrop<string[]>) {
    if(event){
      //console.log("event")
      moveItemInArray(this.QuestionOrderList, event.previousIndex, event.currentIndex);
    }

    // console.log("order",this.QuestionOrderList)
   //console.log("orderSelectedQuestions",this.orderSelectedQuestions)
    this.OnDragDropCompleted();
  }
  //OnDragDropCompleted
  OnDragDropCompleted() {
    this.resultQuestionOrder =[]

  //   for(let each of this.addedRandomQuestions) {
  //     let q='Q'+each.questionDisplayID+' '+each.questionText;
  //     const index = this.QuestionOrderList.indexOf(q);
  //     console.log(index); //

  //     if (index !== -1) {
  //       this.QuestionOrderList.splice(index, 1);
  //     }
  // }
    for(let i=0; i<this.orderSelectedQuestions.length;i++) {
      for(let j=0;j<this.QuestionOrderList.length;j++){
        if(this.orderSelectedQuestions[i].questionText == this.QuestionOrderList[j]){
          let k = j;
          //resultQuestionOrder
          this.resultQuestionOrder.push( {
            QuestionText : this.orderSelectedQuestions[i].questionText,
            QuestionID : this.orderSelectedQuestions[i].questionID,
            QuestionIndex: k+1,
            QuestionType:1,
          })
        }
      }
    }

    for(let each of this.randomQuestionOrder) {
      this.resultQuestionOrder = this.resultQuestionOrder.filter(x => x.QuestionID !== each.QuestionID);
    }

    //for()
    console.log("284",this.orderSelectedQuestions)
    console.log("285",this.QuestionOrderList)
    console.log("305",this.resultQuestionOrder)
    console.log("306",this.randomQuestionOrder)
    this.arrangeCurrentAndRandomQuestionOrder();
    //console.log("The Newly Formed Order",this.resultQuestionOrder)
  }



  public arrangeCurrentAndRandomQuestionOrder() {
    //console.log("inside rearranging")

    //console.log("ranodmOrder",this.randomQuestionOrder)

    // if(this.randomQuestionOrder.length) {
    //   this.resultQuestionOrder.push(this.randomQuestionOrder)
    // }

    console.log("313", this.resultQuestionOrder)
    console.log("314",this.randomQuestionOrder)

    this.finalQuestionOrder=[];

    for(let eachQues of this.resultQuestionOrder) {
      this.finalQuestionOrder.push(eachQues)
    }

    for(let eachRandom of this.randomQuestionOrder)
    {
      eachRandom.QuestionIndex = this.finalQuestionOrder.length + 1;
      this.finalQuestionOrder.push(eachRandom)
    }




      console.log("340",this.tag.isBranchLogicToBeFollowed)
      if(this.tag.isBranchLogicToBeFollowed==false) {

        for(let each of this.finalQuestionOrder) {
          each.QuestionIndex = 1;
          each.QuestionType=0;
        }
      }
      console.log("FinalQuestionOrrder",this.finalQuestionOrder);

      if (this.finalQuestionOrder != null && this.finalQuestionOrder != undefined)
        {
        if (this.finalQuestionOrder.length > 0)
        {
        //this.inlineCountToText =   this.finalQuestionOrder.length;
        console.log("inlineCountToText",this.finalQuestionOrder.length);
        }
        }
  }

  OnCheckRandomQuestion() {

    this.IsRandomQuestion = true;
    this.getRandomTagQuestionList()

  }

  OnUnCheckRandomQuestion() {

    this.IsRandomQuestion = false;

  }

  getRandomTagQuestionList() {
    // this.customModeService.getCustomTags().subscribe(
    //   res => {
    //     this.RandomTagList = res;
    //     this.availableRandomTags = JSON.parse(JSON.stringify(res))
    //     console.log("RandomTags",this.availableRandomTags)
        // this.questionService.getCustomQuestions().subscribe(
        //   res => {
        //     res = res.filter((value, index, self) =>
        //         index === self.findIndex((t) => (
        //           t.questionDisplayID === value.questionDisplayID
        //         ))
        //       )
           // console.log("arrayuniq",res);
            this.randomQuestions = this.selectedQuestions;
            this.availableRandomQuestions=[];
            this.availableRandomQuestions = JSON.parse(JSON.stringify(this.selectedQuestions))
            //console.log("available Ques",this.availableQuestions)
            //console.log("selected ques",this.selectedQuestions)
            // for(let each of this.availableQuestions) {
            //   this.availableRandomQuestions = this.availableRandomQuestions.filter(x => x.questionID !== each.questionID);
            // }
            // for(let each of this.selectedQuestions) {
            //   this.availableRandomQuestions = this.availableRandomQuestions.filter(x => x.questionID !== each.questionID);
            // }
            //console.log("available random",this.availableRandomQuestions)
//            this.orderSelectedQuestions = this.orderSelectedQuestions.filter(x => x.questionID !== id);//to remove from questions order
           // console.log("RandomQues",this.availableRandomQuestions)
          //   this.qnorder=[]
          //  // console.log("availablerandomQuestion", this.availableRandomQuestions.length)
          //   for( let i=1;i<=this.availableRandomQuestions.length;i++) {
          //     this.qnorder.push(i)
          //   }
            //console.log("qnorder",this.qnorder)
        //   },
        //   err => {
        //     console.log(err);
        //   }
        // );
    }



  onDeSelectTagStream(item : ValueStreamTemplate) {

    if (!this.selectedItemTagStream || this.selectedItemTagStream.length === 0)
    {
      // this.tag.assigned_ValueStreamTemplateID = [] ;
     // this.tag.assigned_ValueStreamCategoryID = undefined;
      this.selectedItemValueStreamCategory = [];
    }

    //this.tag.assigned_ValueStreamTemplateID = this.tag.assigned_ValueStreamTemplateID.filter( r => r != item.valueStreamTemplateID);

    var valueStreamsCategoryByTemplateID = this.valueStreamCategories.filter(x => x.valueStreamTemplateID != item.valueStreamTemplateID).map(y => { return y.valueStreamCategoryID });
    //Removing Value Streams from Original VS array on Unselecting the Template ID
    this.valueStreamCategories = this.valueStreamCategories.filter(x => x.valueStreamTemplateID != item.valueStreamTemplateID);
    //Removing Value Streams from selected Choice List
    this.selectedItemValueStreamCategory = this.selectedItemValueStreamCategory.filter(x => valueStreamsCategoryByTemplateID.includes(x.valueStreamCategoryID));

    //Identifying the removed Template ValueStreams from ValueStream Array
    var valueStreamsByTemplateID = this.valueStreams.filter(x => x.valueStreamTemplateID != item.valueStreamTemplateID).map(y => { return y.valueStreamID });
    //Removing Value Streams from Original VS array on Unselecting the Template ID
    this.valueStreams = this.valueStreams.filter(x => x.valueStreamTemplateID != item.valueStreamTemplateID);
    //Removing Value Streams from selected Choice List
    this.selectedValueStreams = this.selectedValueStreams.filter(x => valueStreamsByTemplateID.includes(x.valueStreamID));

  }

  onValueStreamTemplateSelectAll(item : ValueStreamTemplate) {
    //this.tag.assigned_ValueStreamTemplateID  =  this.valueStreamTemplates.map(r=> r.valueStreamTemplateID);

    var TreeViewModeVS = Object.values(Object.assign({}, this.valueStreamTemplates)).filter(x => x.visualizationViewModeID == 2).map(y => { return y.valueStreamTemplateID });
    this.valueStreams = [];
    this.valueStreamCategories = [];
    this.valueStreamService.getValueStreamCategory().subscribe(res => {
      this.valueStreamCategories = res.filter(x => TreeViewModeVS.includes(x.valueStreamTemplateID) &&  ( x.valueStreamCategoryName.trim() != "VS Responsible Employee" && x.valueStreamCategoryName.trim() != "SHIFT"));
      this.valueStreamService.getValueStream().subscribe(res => {
        this.valueStreams = res;

         //select all Vlaues Streams Based on Value Stream Templates
         this.valueStreams = this.valueStreams.filter(x =>x.valueStreamCategoryName.trim() == "VS Responsible Employee");
      }, err => { console.log(err) });
    }, err => { console.log(err) });

  }

  onValueStreamTemplateDeSelectAll(item : ValueStreamTemplate){
    // this.tag.assigned_ValueStreamTemplateID  = [];
    //this.tag.assigned_ValueStreamCategoryID  = undefined;



    this.selectedItemValueStreamCategory = [];
    this.selectedItemTagStream = [];
    this.selectedValueStreams = [];
    this.valueStreams = [];
    this.valueStreamCategories = [];
  }

  onLoadTagStream() {
    this.selectedItemTagStream = [];
    if(this.tag.valueStreamTemplateNameArL== undefined)
    {
      return;
    }
    else
    {
      this.selectedItemTagStream = this.valueStreamTemplates.filter(x => this.tag.valueStreamTemplateNameArL.find(r=>r.vsTemplateID ==x.valueStreamTemplateID));

      // for(let ind=0;ind < this.tag.valueStreamTemplateNameArL.length ; ind++)
      // {
      //   const selectedItem = this.valueStreamTemplates.find(x => x.valueStreamTemplateID === this.tag.valueStreamTemplateNameArL[ind].vsTemplateID);
      //   if (selectedItem)
      //     this.selectedItemTagStream.push(selectedItem);
      //     this.valueStreams=this.valueStreams.filter(r=>this.selectedItemTagStream.find(x=>x.valueStreamTemplateID== r.valueStreamTemplateID));
      // }

    }



  }

  //For multi select dropdown - Assign tag to Value Stream Category
  onSelectValueStreamCategory(item: ValueStreamCategory) {
    this.tag.assigned_ValueStreamCategoryID = undefined;
     this.valueStreamCategoryChange(item.valueStreamCategoryID)
  }

  onDeSelectValueStreamCategory(item : ValueStreamCategory) {
    if (!this.selectedItemValueStreamCategory || this.selectedItemValueStreamCategory.length === 0)
      //this.tag.assigned_ValueStreamCategoryID = undefined;

     // this.tag.assigned_ValueStreamCategoryID = this.tag.assigned_ValueStreamCategoryID.filter(r => r != item.valueStreamCategoryID);

      var valueStreamsByCategoryID = this.valueStreams.filter(x => x.valueStreamCategoryID != item.valueStreamCategoryID).map( y => {return y.valueStreamID});

      this.valueStreams = this.valueStreams.filter(x => valueStreamsByCategoryID.includes(x.valueStreamID));
      this.selectedValueStreams = this.selectedValueStreams.filter(x => valueStreamsByCategoryID.includes(x.valueStreamID));
  }

  onValueStreamCategorySelectAll(item : ValueStreamCategory[]){

    item.forEach( element => {
      const selectedItem = this.valueStreams.find(x => x.valueStreamCategoryID == element.valueStreamCategoryID);

      if(selectedItem === undefined){
        this.valueStreamService.getValueStreamsByCategoryID(element.valueStreamCategoryID).subscribe(res => {
          this.valueStreams.push(...res);
          //this.valueStreams = res;
          this.valueStreams = this.valueStreams.filter(x =>x.valueStreamName && x.responsible_UserID);
        },
          err => {
            console.log(err);
          });
      }
    })

  }
  onValueStreamCategoryDeSelectAll(item:ValueStreamCategory){
    // this.tag.assigned_ValueStreamCategoryID = [];
    // for(let ind = 0;ind < this.valueStreamCategories.length ; ind++)
    // {
    //   this.valueStreams = this.valueStreams.filter(x => {x.valueStreamTemplateID !== this.valueStreamCategories[ind].valueStreamTemplateID});
    // }

    //this.tag.assigned_ValueStreamCategoryID = undefined;

    if(this.isEdit){
      this.valueStreams=this.valueStreams.filter(x => x.valueStreamCategoryName == "VS Responsible Employee");

      this.selectedValueStreams = this.selectedValueStreams.filter(x => x.valueStreamCategoryName == "VS Responsible Employee");
    }

    if(this.isAdd)
    {
      this.valueStreams = this.valueStreams.filter(x => x.valueStreamData == "");

      this.valueStreamCategories = [];

      var valueStreamsByCategoryID = this.valueStreams.filter(x => x.valueStreamCategoryID != item.valueStreamCategoryID).map( y => {return y.valueStreamID});

      console.log(this.valueStreams,"insdie");
      this.unload=true;
      this.onAssessorSelect(undefined);
      //this.selectedValueStreams = this.selectedValueStreams.filter(x => x.valueStreamCategoryName == "VS Responsible Employee");
    }
  }

  onLoadValueStreamCategory() {
    //this.selectedItemValueStreamCategory = [];
    if (!this.tag.assigned_ValueStreamCategoryID || this.tag.assigned_ValueStreamCategoryID === [])
      return;
    for(let ind = 0; ind < this.tag.assigned_ValueStreamCategoryID.length;ind++)
    {
      const selectedItem = this.valueStreamCategories.find(x => x.valueStreamCategoryID === this.tag.assigned_ValueStreamCategoryID[ind]);
       if (selectedItem) {
        this.selectedItemValueStreamCategory.push(selectedItem);
      //this.valueStreamCategoryChange(this.tag.assigned_ValueStreamCategoryID);
    }
    }
  }

  //For multi select dropdown - Assign tag to assessor template
  onSelectAssessorTemplate(item: AssessorTemplate) {
     //this.tag.assigned_AssessorTemplateID = undefined;
     if(this.assessors.length==0) {
      this.assessorTemplateService.getAssessors().subscribe(res3 => {
        this.assessors = res3;
        this.getAssessorsByTemplateID(item.assessorTemplateID);
      });
     }else {
      this.getAssessorsByTemplateID(item.assessorTemplateID);
    }
     }


  onDeSelectAssessorTemplate(item : AssessorTemplate) {
    if (!this.selectedItemAssessorTemplate || this.selectedItemAssessorTemplate.length === 0)
     // this.tag.assigned_AssessorTemplateID = undefined;

      //this.tag.assigned_AssessorTemplateID = this.tag.assigned_AssessorTemplateID.filter(x => { x != item.assessorTemplateID });

      var assessorsByTemplateID = this.assessors.filter(x => x.assessorTemplateID != item.assessorTemplateID).map(y => { return y.assessorID });
      //Removing Value Streams from Original VS array on Unselecting the Template ID
      this.assessors = this.assessors.filter(x => x.assessorTemplateID != item.assessorTemplateID);
      //Removing Value Streams from selected Choice List
      this.selectedAssessors = this.selectedAssessors.filter(x => assessorsByTemplateID.includes(x.assessorID));


      if(this.selectedItemAssessorTemplate.length < 1)
      {
        this.assessors = [];
        this.selectedAssessors = [];
      }
    }

  onSelectAllAssessorTemplate(item : AssessorTemplate){
    //this.tag.assigned_AssessorTemplateID = this.assessorTemplateList.map(r => {return r.assessorTemplateID});
    this.assessors = [];
    this.assessorTemplateService.getAssessors().subscribe(res => {
      this.assessors = res;
    }, err => { console.log(err) });
  }

  onDeSelectAllAssessorTemplate(item : AssessorTemplate){
   // this.tag.assigned_AssessorTemplateID = undefined;
    this.assessors = [];
    this.selectedAssessors = [];
  }

  onLoadAssessorTemplate() {
    this.selectedItemAssessorTemplate = [];
    // if ( this.tag.assigned_AssessorTemplateID.length == 0)
    //   return;
    // for(let ind =0; ind < this.tag.assigned_AssessorTemplateID.length ; ind++){
    //   const selectedItem = this.assessorTemplateList.find(x => x.assessorTemplateID === this.tag.assigned_AssessorTemplateID[ind]);
    // if (selectedItem)
    //   this.selectedItemAssessorTemplate.push(selectedItem);
    // }

    if(this.tag.assessorTemplateNameArL== undefined)
    {
      //this.sharedService.hide();
      return;

    }
    else{

    //   for(let j=0;j < this.tag.assessorTemplateNameArL.length ; j++)
    // {
    //   const selectedassessorItem = this.assessorTemplateList.find(x => x.assessorTemplateID === this.tag.assessorTemplateNameArL[j].vsTemplateID);
    //   if (selectedassessorItem)
    //     this.selectedItemAssessorTemplate.push(selectedassessorItem);

    // }

    this.selectedItemAssessorTemplate = this.assessorTemplateList.filter(x => this.tag.assessorTemplateNameArL.find(r=>r.vsTemplateID ==x.assessorTemplateID));
    //console.log(this.selectedItemAssessorTemplate);
    //this.sharedService.hide();

    }
  }

  showModal()
  {
    document.getElementById('deleteModal').style.display = "block";
  }

  closeModal()
  {
    document.getElementById('deleteModal').style.display = "none";
    document.querySelector('body').classList.remove('-is-modal');
  }

  deleteTemplate()
  {
    this.closeModal();
    this.delete(this.tag);
  }

  public getTagQuestionList() {

    this.sharedService.show();
    this.tagService.getTags().subscribe(res => {
      this.tagList = res;
      if (this.tag.tagTypeID == 1) {
        this.availableTags = this.tagList.filter(x => x.tagID !== this.tag.tagID);
      }
      this.questionService.getQuestions().subscribe(res => {
        this.questionList = res;
        if(this.tag.tagTypeID == 1){
         this.availableQuestions = this.questionList;
        }
      }, err => { console.log(err) });
    },
      err => {
        console.log(err);
      }
    );
  }

  fetchTagsAndQuestions() {

    this.tagService.getTagsByTagID(this.tag.tagID).subscribe(res => {
      this.selectedTags = [];
      this.selectedTags = res;
     // console.log("660",this.selectedTags)
      if(this.selectedTags && this.selectedTags.length > 0){
        for(let tag of this.selectedTags){
          if (this.availableTags && this.availableTags.length > 0) {
            //to remove the current tag and selected tags from tag list
            this.availableTags = this.availableTags.filter(x => x.tagID !== tag.tagID && x.tagID !== this.tag.tagID);
          }
        }
      }
     console.log("706",this.addedRandomQuestions)
      this.tagService.getQuestionsByTagID(this.tag.tagID).subscribe(res => {
        this.selectedQuestions = [];
        this.selectedQuestionsNew=[];
        console.log("719",res);
        res = res.filter((value, index, self) =>
                index === self.findIndex((t) => (
                  t.questionDisplayID === value.questionDisplayID
                ))
              )
              //this.selectedQuestionsNew= res;
              //this.selectedQuestions = res;
              // if(this.tag.isBranchLogicToBeFollowed == false){
              //   this.addedRandomQuestions=[];
              //   this.resultQuestionOrder=[];
              //   this.randomQuestionOrder=[];
              //   this.finalQuestionOrder=[];
              //   this.orderSelectedQuestions=[];
              //   this.selectedQuestionsNew= res;
              //   this.selectedQuestions = res;
              //   console.log("707",this.selectedQuestions)
              //   for(let ques of this.selectedQuestions){
              //     this.questionSelected(ques);
              //   }

              //   //this.orderSelectedQuestions=this.selectedQuestions;

              //  //this.OnDragDropCompleted();
              // }else{
              //   this.selectedQuestionsNew=res;
              //   this.selectedQuestions=[];
              //   this.resultQuestionOrder=[];
              //   this.randomQuestionOrder=[];
              //   this.finalQuestionOrder=[];
              //   this.orderSelectedQuestions=[];
              //   this.addedRandomQuestions=[];
              //   this.OnAddRandomQuestion(res);
              // }
       //

      // this.addedRandomQuestions= res;
        this.QuestionOrderList = [];
       // this.orderSelectedQuestions = JSON.parse(JSON.stringify(res)) ;
        // for( let each of this.orderSelectedQuestions ){
        //   //console.log("each",each)
        //   each.questionText = 'Q'+ each.questionDisplayID+' ' + each.questionText;
        //   this.QuestionOrderList.push(each.questionText)
        // }
        //console.log("selected questions",this.selectedQuestions)

        // if(this.selectedQuestions.length) {
        //   for(let each of this.selectedQuestions) {
        //     this.resultQuestionOrder.push( {
        //       QuestionText : each.questionText,
        //       QuestionID : each.questionID,
        //       QuestionIndex: this.resultQuestionOrder.length+1 ,
        //       QuestionType:1,
        //     });
        //   }
        // this.arrangeCurrentAndRandomQuestionOrder();
        // }
        if(this.selectedQuestions && this.selectedQuestions.length > 0){
          for(let question of this.selectedQuestions){
            if(this.availableQuestions && this.availableQuestions.length >0){
              this.availableQuestions = this.availableQuestions.filter(x =>x.questionID !== question.questionID);
            }
          }
        }
        console.log("773",res)
        let res1 = JSON.parse(JSON.stringify(res))
        for(let each of res1) {
          //console.log("775",each.QuestionType)
          console.log("777",each)
          console.log("776",each.questionType)
          if(each.questionType == 1){
            this.selectedQuestionsNew=res;
           // this.selectedQuestions = res;
            this.questionSelected(each, true);
          } else{
            this.selectedQuestionsNew=res;
           // this.selectedQuestions = res;
            this.OnAddRandomQuestion(each);
          }

        }
            //Get all Assesssors
      this.assessorTemplateService.getAssessors().subscribe(res3 => {
        this.assessors = res3;

        this.assessors=this.assessors.filter(r=>this.selectedItemAssessorTemplate.find(x=>x.assessorTemplateID== r.assessorTemplateID));

        this.tagService.assessorsByTagID(this.tag.tagID).subscribe(res =>{
          this.selectedAssessors =[];
          this.selectedAssessorIDs = [];
          this.selectedAssessorIDs = res;
          for (let asrObj of this.selectedAssessorIDs) {
            let asr = this.assessors.filter(x => x.assessorID == asrObj.assessorID)[0];
            if (asr) {
              asr.id = asrObj.id; //for updating assigned assessors for a Tag
            asr.isMandatoryAssessor = asrObj.isMandatoryAssessor;
            this.selectedAssessors.push(asr);}
          }
        }, err => console.log(err));
      });


          this.tagService.valueStreamsByTagID(this.tag.tagID).subscribe(res =>{
            this.selectedValueStreamIDs = [];
          this.selectedValueStreamIDs = res;

          this.selectedValueStreams = [];
          for (let obj of this.selectedValueStreamIDs) {
            let vs = this.valueStreams.filter(x => x.valueStreamID == obj.valueStreamID)[0];
            if (vs) {
              vs.id = obj.id; //for updating assigned valuestreams for a Tag
            this.selectedValueStreams.push(vs);
          }}

          // to limit the valuestreams and assessors based on Assesor and VS template ID
          // if(this.assessors && this.assessors.length >0 &&  this.tag.assigned_AssessorTemplateID){
          // this.assessors = this.assessors.filter(x =>this.tag.assigned_AssessorTemplateID.find(y => y == x.assessorTemplateID));
          // }
          // if(this.valueStreamCategories && this.valueStreamCategories.length >0 &&  this.tag.assigned_ValueStreamTemplateID){

          // this.valueStreamCategories = this. valueStreamCategories.filter(x => this.tag.assigned_ValueStreamTemplateID.find(y => y == x.valueStreamTemplateID));
          // }
          // if(this.valueStreams && this.valueStreams.length >0 &&  this.tag.assigned_ValueStreamTemplateID){

          // //this.valueStreams = this.valueStreams.filter(x => this.tag.assigned_ValueStreamTemplateID.find(y => y == x.valueStreamTemplateID) && x.valueStreamName && x.responsible_UserID  );
          // }

            this.valueStreamCategories=this.valueStreamCategories.filter(r=>this.selectedItemTagStream.find(x=>x.valueStreamTemplateID== r.valueStreamTemplateID && x.visualizationViewModeID==2));

            let valueStreamsCategory=this.selectedValueStreams.filter(r=>r.valueStreamCategoryName.toLowerCase() !="VS Responsible Employee".toLowerCase());

            let selectedCategory=this.valueStreamCategories.filter(r=>valueStreamsCategory.find(t=>t.valueStreamCategoryID==r.valueStreamCategoryID));
            this.selectedItemValueStreamCategory=selectedCategory;

          this.onAssessorSelect();
          },err => console.log(err));



        },err => console.log(err));

    }, err => console.log(err));


  }

  redirect() {
    this.tag = undefined;
    this.router.navigate([environment.home +'/taglist']);
  }

  onSubmit(data: any) {

  }

  onClose() {
  }

  lockTag() {
    this.tagService.tag = this.tag;
    this.router.navigate([environment.home +'/taglist/tag-lock']);

  }

  public tagSelected(tag: Tag) {

    if (this.selectedTags == undefined) {
      this.selectedTags = [];
    }
    this.selectedTags.push(tag);
    if (this.selectedTagIDs == null) {
      this.selectedTagIDs = String(tag.tagID);
    }
    else {
      this.selectedTagIDs += "," + tag.tagID;
    }
    this.availableTags = this.availableTags.filter(x => x.tagID !== tag.tagID);
    this.tagService.getQuestionsByTagID(tag.tagID).subscribe(res => {
      console.log("867 order",res);

      //if (this.orderSelectedQuestions.length == 0) {
      //  this.orderSelectedQuestions = res;
      //}
      //else {
      //  if (res.length > 0) {
      //    for (let qn of res) {
      //      let x = this.orderSelectedQuestions.filter(x => x.questionID == qn.questionID);
      //      if (x.length < 1) {
      //        this.orderSelectedQuestions.push(qn);
      //      }
      //    }
      //  }
      //}


    });

    if (!this.isEdit) {
    this.Addnewtag_InlineCountLogic_linkedTag(tag.tagID);
   }
   else{
    // this.OnLineModeTaginsertion(tag.tagID);
    // this.getInlineCountFromTagEdit(this.tag.tagID);
    this.Editedtag_InlineCountLogic_linkedTag(tag.tagID);
   }
  }

  public questionSelected(question: Question, fromDelete: boolean) {

    console.log("849",question)
    if (this.selectedQuestions == undefined) {
      this.selectedQuestions = [];
    }

    var x = this.selectedQuestionsNew.filter(x => x.questionID == question.questionID);
    if (x.length < 1) {
      this.selectedQuestionsNew.push(question);
      //this.selectedQuestions.push(question);
    }
    var x = this.selectedQuestions.filter(x => x.questionID == question.questionID);
    if (x.length < 1) {
      this.selectedQuestions.push(question);
    }
    this.availableQuestions = this.availableQuestions.filter(x => x.questionID !== question.questionID);

    console.log("859",this.selectedQuestions)
    //console.log("avail after selected",this.availableQuestions)
    // this.qnorder=[]
    // console.log("----750 avaliablequestion", this.availableQuestions.length)
    // for( let i=1;i<=this.availableQuestions.length;i++) {
    //   this.qnorder.push(i)
    // }
    //to display the questions in branch order
    if (this.orderSelectedQuestions == undefined) {
      this.orderSelectedQuestions = [];
    }
    var x = this.orderSelectedQuestions.filter(x => x.questionID == question.questionID);
    if (x.length < 1) {
     // console.log("add ques",question)
      let Ques:Question = JSON.parse(JSON.stringify(question))
      Ques.questionText ='Q'+ Ques.questionDisplayID+' ' + Ques.questionText;
      this.orderSelectedQuestions.push(Ques);
    }

    //console.log("880",this.ordersel)
    console.log("864",this.selectedQuestions)
    console.log("865",this.orderSelectedQuestions)
    //console.log("after add",this.orderSelectedQuestions)
    this.QuestionOrderList =[]
    for( let each of this.orderSelectedQuestions) {
      let ques =  each.questionText;
      this.QuestionOrderList.push(ques)
    }
    //console.log("911", this.questionList);
    for(let each of this.addedRandomQuestions) {
      let q='Q'+each.questionDisplayID+' '+each.questionText;
      const index = this.QuestionOrderList.indexOf(q);
      console.log(index); //

      if (index !== -1) {
        this.QuestionOrderList.splice(index, 1);
      }
  }

    this.OnDragDropCompleted();
    //ashok
    // for(let each of this.addedRandomQuestions) {
    //   let q='Q'+each.questionDisplayID+' '+each.questionText;
    //   const index = this.QuestionOrderList.indexOf(q);
    //   console.log(index); //

    //   if (index !== -1) {
    //     this.QuestionOrderList.splice(index, 1);
    //   }

    //   this.OnDragDropCompleted()
    // }

    // //console.log("after add ordered question",this.QuestionOrderList)
    // console.log("865", this.resultQuestionOrder)
    // console.log("866",this.randomQuestionOrder)
    //this.OnDragDropListItem();

      //debugger;
  if (!fromDelete) {
   // this.OnLineModeQuestionInsertion(question.questionID);
   // this.getInlineCountFromTagEdit(this.tag.tagID);
   this.EditedTag_InLineCountLogic_QuestionSelection();

  }

  }

  public OnLineModeQuestionInsertion(questionId: any, requestFrom: number = 0)
{
  //debugger;
  this.tagService.insertQuestionIntoTagAssignedInlineMode(this.tag.tagID, questionId, 0, false, requestFrom).subscribe(res => {
    console.log("Success Insert",res);
  });
}

public OnLineModeTaginsertion(linkedtagId: any, requestFrom: number = 0)
{
  //debugger;
  this.tagService.insertQuestionIntoTagAssignedInlineMode(this.tag.tagID, 0, linkedtagId, false, requestFrom).subscribe(res => {
    console.log("Success Insert",res);

  });
}

public OnLineModeTagDeletion(linkedtagId: any)
{
  //debugger;
  this.tagService.insertQuestionIntoTagAssignedInlineMode(this.tag.tagID, 0, linkedtagId, true).subscribe(res => {
    console.log("Success Insert",res);

  });
}

public OnLineModeQuestionDeletion(questionID: any)
{
  //debugger;
  this.tagService.insertQuestionIntoTagAssignedInlineMode(this.tag.tagID, questionID, 0, true).subscribe(res => {
    console.log("Success Insert",res);

  });
}

  public OnAddRandomQuestion_New(question:Question){

    var x = this.selectedQuestionsNew.filter(x => x.questionID == question.questionID);
    if (x.length < 1) {
      let ques: any =JSON.parse(JSON.stringify(question))
      this.selectedQuestionsNew.push(ques)
    //  this.selectedQuestions.push(ques)
    }
     console.log("989",this.selectedQuestionsNew)
    this.OnAddRandomQuestion(question);
    this.AddNewtag_InLineCountLogic_QuestionSelection();
  }

 Addnewtag_InlineCountLogic_linkedTag(tagID: number)
  {

    let selectedTagCount_NewtagCreation = this.selectedTagIDs;
    let selectedtagArray_Newtagcreation = this.selectedTags.length;

    if (selectedtagArray_Newtagcreation > 0 && selectedTagCount_NewtagCreation != null)
    {
       //tagind: Number = this.selectedTags.tagID
      this.getCurrentSelectionLinkedTagQuestionCount(tagID).subscribe(
        res => {
          if (res != null) {
            this.linkedTagSelectedCount = res;
            this.inLineLinkedTag_QuestionCount_NewTag += this.linkedTagSelectedCount;
            this.InlineModeSelected();
          }
          // Use the response to update the UI
          // this.hintInLineCount = res;
          // this.setinLineCount(); // Update the label with the new count
          // console.log('Updated count:', res);
          // alert(`Count received: ${res}`);

        },
        err => {
          console.error('Error occurred:', err);
        }
      );
    }

  }

  Editedtag_InlineCountLogic_linkedTag(tagID: number)
  {

    let selectedTagCount_EditedtagCreation = this.selectedTagIDs;
    let selectedtagArray_Editedtagcreation = this.selectedTags.length;

    if (selectedtagArray_Editedtagcreation > 0 && selectedTagCount_EditedtagCreation != null)
    {
       //tagind: Number = this.selectedTags.tagID
      this.getCurrentSelectionLinkedTagQuestionCount(tagID).subscribe(
        res => {
          if (res != null) {
            this.linkedTagSelectedCount = res;
            this.inLineLinkedTag_QuestionCount_EditedTag += this.linkedTagSelectedCount;
            this.InlineModeSelected();
          }
          // Use the response to update the UI
          // this.hintInLineCount = res;
          // this.setinLineCount(); // Update the label with the new count
          // console.log('Updated count:', res);
          // alert(`Count received: ${res}`);

        },
        err => {
          console.error('Error occurred:', err);
        }
      );
    }

  }

  AddNewtag_InLineCountLogic_QuestionSelection()
  {
    let selectedQuestionCount_NewTagCreation =  this.selectedQuestionsNew?.length;
    this.questionSelectedCount_NewTag = selectedQuestionCount_NewTagCreation;
    this.inLineQuestionCount_NewTag = this.questionSelectedCount_NewTag;
    this.InlineModeSelected();
  }

  EditedTag_InLineCountLogic_QuestionSelection()
  {
    let selectedQuestionCount_EditedTagCreation =  this.selectedQuestionsNew?.length;
    this.questionSelectedCount_EditedTag = selectedQuestionCount_EditedTagCreation;
    this.inLineQuestionCount_EditedTag = this.questionSelectedCount_EditedTag;
    this.InlineModeSelected();
  }

  NewTag_ConsolidatedQuestionCount(IsQuestionRemove: boolean = false, reducedCountFromTag: number = 0, reducedCountFromQuestion: number = 0)
  {
    debugger;
    if (IsQuestionRemove)
    {
      this.addNew_FinalQuestionAndTagCount = reducedCountFromQuestion + reducedCountFromTag;
      this.inLineQuestionCount_NewTag = reducedCountFromQuestion;
      this.inLineLinkedTag_QuestionCount_NewTag =reducedCountFromTag;
      this.hintInLineCount = this.addNew_FinalQuestionAndTagCount >= 40 ? 20 : Math.round(this.addNew_FinalQuestionAndTagCount / 2);
      this.inlineCountToText =  this.hintInLineCount;
      this.setinLineCount();
      this.InlineModeFieldValidation(); //For input validation
    }
    else
    {
      this.inLineQuestionCount_NewTag;
      this.inLineLinkedTag_QuestionCount_NewTag;
      if (this.inLineQuestionCount_NewTag!=null && this.inLineQuestionCount_NewTag!=undefined && this.inLineLinkedTag_QuestionCount_NewTag!=null && this.inLineLinkedTag_QuestionCount_NewTag!=undefined )
      {
        this.addNew_FinalQuestionAndTagCount = this.inLineQuestionCount_NewTag + this.inLineLinkedTag_QuestionCount_NewTag;
        this.hintInLineCount = this.addNew_FinalQuestionAndTagCount >= 40 ? 20 : Math.round(this.addNew_FinalQuestionAndTagCount / 2);
        this.inlineCountToText =  this.hintInLineCount;
      }
    }

  }

  Edited_ConsolidatedQuestionCount(IsQuestionRemove: boolean = false, reducedCountFromTag: number = 0, reducedCountFromQuestion: number = 0)
  {
    debugger;
    if (IsQuestionRemove)
    {
      this.EditedTag_FinalQuestionAndTagCount = reducedCountFromQuestion + reducedCountFromTag;
      this.inLineQuestionCount_EditedTag = reducedCountFromQuestion;
      this.inLineLinkedTag_QuestionCount_EditedTag =reducedCountFromTag;
      this.hintInLineCount = this.EditedTag_FinalQuestionAndTagCount >= 40 ? 20 : Math.round(this.EditedTag_FinalQuestionAndTagCount / 2);
      this.inlineCountToText =  this.hintInLineCount;
      this.setinLineCount();
      this.InlineModeFieldValidation(); //For input validation
    }
    else
    {
      this.inLineQuestionCount_EditedTag;
      this.inLineLinkedTag_QuestionCount_EditedTag;
      if (this.inLineQuestionCount_EditedTag!=null && this.inLineQuestionCount_EditedTag!=undefined && this.inLineLinkedTag_QuestionCount_EditedTag!=null && this.inLineLinkedTag_QuestionCount_EditedTag!=undefined )
      {
        this.EditedTag_FinalQuestionAndTagCount = this.inLineQuestionCount_EditedTag + this.inLineLinkedTag_QuestionCount_EditedTag;
        this.hintInLineCount = this.EditedTag_FinalQuestionAndTagCount >= 40 ? 20 : Math.round(this.EditedTag_FinalQuestionAndTagCount / 2);
        this.inlineCountToText =  this.hintInLineCount;
      }
    }

  }

  public OnAddRandomQuestion(question:Question) {

    console.log("908",question)
    // let questionAlreadyAvailable: boolean = true;
    // for(let each of this.selectedQuestions) {
    //   if(each.questionID == question.questionID) {
    //     questionAlreadyAvailable = false;
    //   }
    // }

    // for(let ques of this.availableQuestions) {
    //   if(ques.questionID == question.questionID) {
    //     questionAlreadyAvailable = false
    //   }
    // }

   // console.log("quesalreadyavailable",questionAlreadyAvailable)

    // if(questionAlreadyAvailable) {

      //let difference:boolean = this.SelectedrandomQuestionLimit - this.addedRandomQuestions.length  >0 ? true :false;
      //if(difference) {
           // console.log("randomquestion",question)

           // this.availableRandomQuestions = this.availableRandomQuestions.filter(x => x.questionID !== question.questionID);


            var x = this.addedRandomQuestions.filter(x => x.questionID == question.questionID);
           if (x.length < 1) {
             let ques: any =JSON.parse(JSON.stringify(question))
            this.addedRandomQuestions.push(ques)
           }



            console.log("added random ques",this.addedRandomQuestions);

           //console.log("RandomQuesOrder",this.randomQuestionOrder)

           for(let each of this.addedRandomQuestions){
            this.selectedQuestions = this.selectedQuestions.filter(x =>x.questionID !== each.questionID);

          }
          for(let each of this.addedRandomQuestions){
            this.availableQuestions = this.availableQuestions.filter(x =>x.questionID !== each.questionID);

          }
          console.log("951",this.availableQuestions)
          for(let each of this.addedRandomQuestions){
            this.resultQuestionOrder = this.resultQuestionOrder.filter(x =>x.QuestionID !== each.questionID);

          }

          for(let each of this.addedRandomQuestions) {
                let q='Q'+each.questionDisplayID+' '+each.questionText;
                const index = this.QuestionOrderList.indexOf(q);
                console.log(index); //

                if (index !== -1) {
                  this.QuestionOrderList.splice(index, 1);
                }
            }

            console.log("916",this.randomQuestionOrder)
            console.log("917",this.resultQuestionOrder)
            this.randomQuestionOrder=[]
            for(let each of this.addedRandomQuestions ) {
              //  console.log("each added",each)
                this.randomQuestionOrder.push( {
                    QuestionText :'Q'+each.questionDisplayID+' '+each.questionText,
                    QuestionID : each.questionID,
                    QuestionIndex: this.randomQuestionOrder.length +1,
                    QuestionType:0,
                  } )
             }

             console.log("979",this.randomQuestionOrder)
              //console.log("this.newformarray",this.randomQuestionOrder)
              this.qnorder=[0]
              // console.log("availablerandomQuestion", this.availableRandomQuestions.length)
               for( let i=1;i<=this.randomQuestionOrder.length;i++) {
                 this.qnorder.push(i)
               }

           this.OnDragDropCompleted();

          // } else {
          //   this.alertText = this.labels.default.randomQuestionLimit;

          //   this.modalService.show(this.warningModal);

          //   $("modal-container").removeClass("fade");

          //   $(".modal-dialog").addClass("modalSize");

          //   return;
          //   }
    //   } else {
    //     this.alertText = this.labels.default.randomQuestionAvailable;

    //     this.modalService.show(this.warningModal);

    //     $("modal-container").removeClass("fade");

    //     $(".modal-dialog").addClass("modalSize");

    //     return;
    // }


  }
  public OnAddRandomQuestionfromQuestionOrder(question:Question){
    console.log("908",question)
    // let questionAlreadyAvailable: boolean = true;
    // for(let each of this.selectedQuestions) {
    //   if(each.questionID == question.questionID) {
    //     questionAlreadyAvailable = false;
    //   }
    // }

    // for(let ques of this.availableQuestions) {
    //   if(ques.questionID == question.questionID) {
    //     questionAlreadyAvailable = false
    //   }
    // }

   // console.log("quesalreadyavailable",questionAlreadyAvailable)

    // if(questionAlreadyAvailable) {

      //let difference:boolean = this.SelectedrandomQuestionLimit - this.addedRandomQuestions.length  >0 ? true :false;
      //if(difference) {
           // console.log("randomquestion",question)

           // this.availableRandomQuestions = this.availableRandomQuestions.filter(x => x.questionID !== question.questionID);

            var x = this.addedRandomQuestions.filter(x => x.questionID == question.questionID);
           if (x.length < 1) {
             let ques: any =JSON.parse(JSON.stringify(question))
            this.addedRandomQuestions.push(ques)
           }



            // let ques: any =JSON.parse(JSON.stringify(question))
            // this.addedRandomQuestions.push(ques)

            console.log("added random ques",this.addedRandomQuestions);

           //console.log("RandomQuesOrder",this.randomQuestionOrder)

           for(let each of this.addedRandomQuestions){
            this.selectedQuestions = this.selectedQuestions.filter(x =>x.questionID !== each.questionID);

          }
          for(let each of this.addedRandomQuestions){
            this.availableQuestions = this.availableQuestions.filter(x =>x.questionID !== each.questionID);

          }
          console.log("951",this.availableQuestions)
          for(let each of this.addedRandomQuestions){
            this.resultQuestionOrder = this.resultQuestionOrder.filter(x =>x.QuestionID !== each.questionID);

          }

          for(let each of this.addedRandomQuestions) {
                let q='Q'+each.questionDisplayID+' '+each.questionText;
                const index = this.QuestionOrderList.indexOf(q);
                console.log(index); //

                if (index !== -1) {
                  this.QuestionOrderList.splice(index, 1);
                }
            }
            this.OnDragDropCompleted();
            console.log("916",this.randomQuestionOrder)
            console.log("917",this.resultQuestionOrder)
            this.randomQuestionOrder=[]
            for(let each of this.addedRandomQuestions ) {
              //  console.log("each added",each)
                this.randomQuestionOrder.push( {
                    QuestionText :'Q'+each.questionDisplayID+' '+each.questionText,
                    QuestionID : each.questionID,
                    QuestionIndex: this.randomQuestionOrder.length +1,
                    QuestionType:0,
                  } )
             }

             console.log("979",this.randomQuestionOrder)
              //console.log("this.newformarray",this.randomQuestionOrder)
              this.qnorder=[0]
              // console.log("availablerandomQuestion", this.availableRandomQuestions.length)
               for( let i=1;i<=this.randomQuestionOrder.length;i++) {
                 this.qnorder.push(i)
               }

           this.OnDragDropCompleted();

          // } else {
          //   this.alertText = this.labels.default.randomQuestionLimit;

          //   this.modalService.show(this.warningModal);

          //   $("modal-container").removeClass("fade");

          //   $(".modal-dialog").addClass("modalSize");

          //   return;
          //   }
    //   } else {
    //     this.alertText = this.labels.default.randomQuestionAvailable;

    //     this.modalService.show(this.warningModal);

    //     $("modal-container").removeClass("fade");

    //     $(".modal-dialog").addClass("modalSize");

    //     return;
    // }


  }
  public removeQuestionOrder(ques:String) {
    console.log("remove question oder",ques)
    console.log("1051",this.selectedQuestions);
    for( let each of this.selectedQuestions) {
      let que='Q'+each.questionDisplayID+' '+each.questionText;
      if(que == ques){
        console.log(each);
        this.OnAddRandomQuestionfromQuestionOrder(each);
      }
    }
    for(let each of this.addedRandomQuestions) {
      let q='Q'+each.questionDisplayID+' '+each.questionText;
      const index = this.QuestionOrderList.indexOf(q);
      console.log(index); //

      if (index !== -1) {
        this.QuestionOrderList.splice(index, 1);
      }
  }
      this.OnDragDropCompleted();

  }

  public OnremoveRandomQuestion(question : Question) {
   // console.log("removed random ques",question)

   //console.log("1019",this.SelectedrandomQuestionLimit)
   //let difference:boolean = this.addedRandomQuestions.length - this.SelectedrandomQuestionLimit    >0 ? true :false;
   console.log("1055",question)
  // if(difference){


    this.addedRandomQuestions = this.addedRandomQuestions.filter(x => x.questionID !== question.questionID);

    console.log("1019",this.addedRandomQuestions)
    this.availableRandomQuestions.push(question)
    //this.availableQuestions.push(question)
    this.selectedQuestions.push(question)
    console.log("1006",this.selectedQuestions)

    //console.log("randomList",this.addedRandomQuestions)
    //console.log("available Random ques after remove",this.availableRandomQuestions)

    this.randomQuestionOrder=[]

    // this.result
    // for(let each of this.selectedQuestions) {
    //   this.resultQuestionOrder.push( {
    //     QuestionText : each.questionText,
    //     QuestionID : each.questionID,
    //     QuestionIndex: this.resultQuestionOrder.length+1 ,
    //     QuestionType:1,
    //   });
    // }
    // this.QuestionOrderList=[];
    //   for( let each of this.selectedQuestions) {
    //     let ques= each.questionText;
    //     this.QuestionOrderList.push(ques)
    //   }

    for(let each of this.addedRandomQuestions) {
      // console.log("each added",each)
       this.randomQuestionOrder.push( {
         QuestionText : 'Q'+each.questionDisplayID+' '+each.questionText,
         QuestionID : each.questionID,
         QuestionIndex: this.randomQuestionOrder.length +1,
         QuestionType:0,
         } )
         this.questionSelected(question, true);
    }
    if(this.addedRandomQuestions.length==0){
      this.questionSelected(question, true)
    }
    for(let each of this.addedRandomQuestions) {
      let q='Q'+each.questionDisplayID+' '+each.questionText;
      const index = this.QuestionOrderList.indexOf(q);
      console.log(index); //

      if (index !== -1) {
        this.QuestionOrderList.splice(index, 1);
      }
  }
    this.OnDragDropCompleted();
  // }
  //  else {
  //     this.alertText = this.labels.default.randomQuestionLimit;

  //     this.modalService.show(this.warningModal);

  //     $("modal-container").removeClass("fade");

  //     $(".modal-dialog").addClass("modalSize");

  //     return;
  //     }
    //this.OnDragDropCompleted();
    //this.arrangeCurrentAndRandomQuestionOrder();
  }
  searchTagOrQuestion() {


    let text = this.tag.searchText;
    if (text) {
      text = text.toLowerCase();
    this.availableTags = this.availableTags.filter(x => x.tagName.toLowerCase().indexOf(text) > -1);
    this.availableQuestions = this.availableQuestions.filter(x => x.questionText.toLowerCase().indexOf(text) > -1);

    }

    else
    {
      this.onAssessorSelect();
    }

  }

  //tempStartDate: any[];
  //tempEndDate: any[];
  modalRef2: BsModalRef;

  //startDate: Date;
  //endDate: Date;

  save() {
    //this.tempStartDate = this.tag.suppressedDateRangeFrom.toString().split('-');
    //this.tempEndDate = this.tag.suppressedDateRangeTo.toString().split('-');

    //if(this.tag.isSingleQuestionSuppressed == false){
    //if(this.tempStartDate.length == 1)
    //{
    //  this.startDate = new Date(Date.UTC(this.tag.suppressedDateRangeFrom.getFullYear(),this.tag.suppressedDateRangeFrom.getMonth(),this.tag.suppressedDateRangeFrom.getDate(),this.tag.suppressedDateRangeFrom.getHours(),this.tag.suppressedDateRangeFrom.getMinutes(),this.tag.suppressedDateRangeFrom.getSeconds()));
    //  this.tag.suppressedDateRangeFrom = this.startDate;
    //}
    //else{
    //  this.tempStartDate = this.tag.suppressedDateRangeFrom.toString().split('-');
    //  this.startDate = new Date(Date.UTC(this.tempStartDate[2],this.tempStartDate[1]-1,this.tempStartDate[0]));
    //  this.tag.suppressedDateRangeFrom = this.startDate;
    //}
    //if(this.tempEndDate.length == 1)
    //{
    //  this.endDate = new Date(Date.UTC(this.tag.suppressedDateRangeTo.getFullYear(),this.tag.suppressedDateRangeTo.getMonth(),this.tag.suppressedDateRangeTo.getDate(),this.tag.suppressedDateRangeTo.getHours(),this.tag.suppressedDateRangeTo.getMinutes(), this.tag.suppressedDateRangeTo.getSeconds()));
    //  this.tag.suppressedDateRangeTo = this.endDate;
    //}
    //else{
    //  this.tempEndDate = this.tag.suppressedDateRangeTo.toString().split('-');
    //  this.endDate = new Date(Date.UTC(this.tempEndDate[2],this.tempEndDate[1]-1,this.tempEndDate[0]));
    //  this.tag.suppressedDateRangeTo = this.endDate;

    //}
  //}
  if(this.tag.isBranchLogicToBeFollowed==false) {

    for(let each of this.finalQuestionOrder) {
      each.QuestionIndex = 1;
    }
  }

  console.log("final save",this.finalQuestionOrder)

  this.tag.suppressedDateRangeFrom = new Date(Date.UTC(this.tag.suppressedDateRangeFrom.getFullYear(), this.tag.suppressedDateRangeFrom.getMonth(), this.tag.suppressedDateRangeFrom.getDate(), 0, 0, 0));
  this.tag.suppressedDateRangeTo =  new Date(Date.UTC(this.tag.suppressedDateRangeTo.getFullYear(), this.tag.suppressedDateRangeTo.getMonth(), this.tag.suppressedDateRangeTo.getDate(), 23, 59, 59));

  this.isDisabled = false;
  var isvalid = true;
  if(this.isAdd){
    var tags = this.tag.tagName.split('!@#$%');
    var tagnames = "";
    for(var i=0; i<tags.length;i++){
    var tagtext = tags[i].toLowerCase();
    var existingTags = this.tagList.filter(x =>x.tagName.toLowerCase() === tagtext);
    if(existingTags.length>0){
      tagnames = tagnames + tagtext + ',';

      isvalid = false;
      //break;
     //return;
    }
   }
   if(!isvalid){
   this.alertText = this.labels.default.uniqueName + "\n"+ this.labels.default.alreadyTaken +":\n\n" + tagnames.substring(0,tagnames.length-1);
   this.modalService.show(this.warningModal);
   $("modal-container").removeClass("fade");
   $(".modal-dialog").addClass("modalSize");
   this.isDisabled = true;
   }
  }
else if(this.isEdit)
    {
      var existingTags = this.tagList.filter(x =>x.tagName.toLowerCase() === this.tag.tagName.toLowerCase() && x.tagID !== this.tag.tagID);
      if(existingTags.length >0){
        this.alertText =  this.labels.default.uniqueName + "\n"+ this.labels.default.alreadyTaken +":\n\n" + this.tag.tagName;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
      this.isDisabled = true;

        return;
      }
    }
    this.isSaveTag = 1;
    console.log("1187", this.tag);
    this.tag.tags = this.selectedTags;
    console.log("1415",this.selectedQuestions)
    console.log("1416",this.selectedQuestionsNew)
    this.tag.questions = this.selectedQuestionsNew;
    this.tag.assessors = this.selectedAssessors;
    this.tag.valueStreams = this.selectedValueStreams;

    if (this.isAdd) {
      this.tag.createdBy_NTID = this.sharedService.ntid;
      this.tag.modifiedBy_NTID = this.sharedService.ntid;
      this.tag.isLocked = false;
    }
    if (this.isEdit) {
      this.tag.modifiedBy_NTID = this.sharedService.ntid;
    }
     //to validate mandatory assessor and valuestream selections
     if(this.tag.tagTypeID !== 1)
     {
      if(this.tag.tagTypeID !== 3 && this.tag.anonymizeUserDataSettingID !== 1)
      {
            if(!this.tag.assessors || this.tag.assessors.length <1){
              this.alertText = this.labels.default.fillMandatoryAssessors;
              this.modalService.show(this.warningModal);
              $("modal-container").removeClass("fade");
              $(".modal-dialog").addClass("modalSize");
              this.isDisabled=true;
              return;
          }

          if(!this.tag.valueStreams || this.tag.valueStreams.length < 1){
            this.alertText = this.labels.default.selectValueStream;
            this.modalService.show(this.warningModal);
            $("modal-container").removeClass("fade");
            $(".modal-dialog").addClass("modalSize");
            this.isDisabled=true;
            return;
        }
      }
    else if(this.tag.tagTypeID == 3 && this.tag.anonymizeUserDataSettingID !== 1)
    {
      if(!this.tag.assessors || this.tag.assessors.length <1){
        this.alertText = this.labels.default.fillMandatoryAssessors;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled=true;
        return;
    }

    if(!this.tag.valueStreams || this.tag.valueStreams.length < 1){
      this.alertText = this.labels.default.selectValueStream;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      this.isDisabled=true;
      return;
      }
    }
   else if(this.tag.tagTypeID == 2)
   {
      if(!this.tag.assessors || this.tag.assessors.length <1){
        this.alertText = this.labels.default.fillMandatoryAssessors;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled=true;
        return;
        }

      if(!this.tag.valueStreams || this.tag.valueStreams.length < 1){
        this.alertText = this.labels.default.selectValueStream;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled=true;
        return;
        }
    }
  }
   // console.log("this.tag",this.tag)
    this.finalRandomQuestionsOnly =[]
    for(let each of this.finalQuestionOrder) {
      if(each.QuestionType==0){
        this.finalRandomQuestionsOnly.push(each)
      }
    }
    this.tag.isSaveTag=this.isSaveTag;
    this.tag.RandomQuestionsOnly =this.finalRandomQuestionsOnly
    this.tag.FinalQuestionOrder=this.finalQuestionOrder;
    if(isvalid){
    this.tagService.insertTag(this.tag).subscribe(res => {
      if (res.resultCode === 0) {
        this.alertText = this.labels.default.saveSuccessfully;
        this.modalService.show(this.successModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.router.navigate([environment.home + '/taglist']);
        this.tagService.updateAuditByTagID(this.tag.tagID).subscribe(res => {
          if (res) {

          }
          else {

          }
        });
      }
      else if (res.resultCode === 9) {
        this.sharedService.hide();
        this.alertText = this.labels.default.insertOpertionFailed;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
      }


    },
      err =>{
      this.isDisabled = true;
      console.log(err);
      });
    }
    else{
      return;
    }
  }
  public branchSelected(){

  }

  public branchUnselected() {

  }

  InlineModeSelected1() {
    //debugger;
    this.tag.IsTagModeSelected = true;

    this.inlineCountToText = 0;
    let tag = this.tag.tagID;

    let successfactor = this.InsertQuestionAndTagSelectedOnClickInlineMode();

    if (successfactor) {
      this.getInlineCountFromTagEdit(tag);
    }

    this.tag.isInlineModeOn = true;
  }

 InlineModeSelected(IsUserSelected: boolean = false) {
  debugger;
  this.isLoading = true;
  this.tag.IsTagModeSelected = true;
  this.inlineCountToText = 0;

  if (!this.isEdit)
  {
    this.NewTag_ConsolidatedQuestionCount();
   // this.hintInLineCount = this.inLineQuestionCount_NewTag;
    this.setinLineCount();
    this.tag.isInlineModeOn = true;
    this.isLoading = false;
    this.startLoading();
  }
  else
  {
    // let tag = this.tag.tagID;

    // // Wait for InsertQuestionAndTagSelectedOnClickInlineMode to complete
    // this.InsertQuestionAndTagSelectedOnClickInlineMode()
    //   .then(successfactor => {
    //     if (successfactor) {
    //       this.getInlineCountFromTagEdit(tag);
    //     }
    //     this.isLoading = false;
    //   })
    //   .catch(error => {
    //     console.error('Error during insertion:', error);
    //     this.isLoading = false;
    //   });
    //   this.tag.isInlineModeOn = true;
    //   this.startLoading();

    if (IsUserSelected)
    {
      debugger;
      let selectedQuestionCount_EditedTagCreation = this.selectedQuestionsNew?.length;
      this.inLineQuestionCount_EditedTag = selectedQuestionCount_EditedTagCreation!=undefined?selectedQuestionCount_EditedTagCreation:0;
      let selectedTagCount_NewtagCreation = this.selectedTagIDs;
      let selectedTagsdata = '';  // Initialize as an empty string

      this.selectedTags.forEach(tagId => selectedTagsdata += tagId.tagID + ',');

      // Remove the trailing comma if necessary
      selectedTagsdata = selectedTagsdata ? selectedTagsdata.slice(0, -1) : '0'; //fix for TG_ST_005

      this.getCurrentSelectionQuestionsAndTag(selectedTagsdata, selectedQuestionCount_EditedTagCreation).subscribe(
        res => {
          if (res != null) {
            debugger;
            this.hintInLineCount = res;
            this.inlineCountToText =  this.hintInLineCount;

            if (res != undefined && res != null)
            {
              this.inLineLinkedTag_QuestionCount_EditedTag = res;
            }
            this.Edited_ConsolidatedQuestionCount();
            this.setinLineCount();
            this.isLoading = false;
            this.startLoading();
          }
        },
        err => {
          console.error('Error occurred:', err);
        }
      );
      // let tag = this.tag.tagID;
      // this.GetCurrentSelectionQsAndtagCount(tag).subscribe(
      //   res => {
      //     if (res != null) {
      //       debugger;
      //      // this.hintInLineCount = res >= 20 ? res : Math.round(res / 2);
      //       if (res == 1000)
      //       {
      //         this.hintInLineCount = 20;
      //       }
      //       else if(res >= 40 )
      //       {
      //         this.hintInLineCount = 20;
      //       }
      //       else
      //       {
      //         this.hintInLineCount = Math.round(res / 2);
      //         //this.hintInLineCount = res
      //       }
      //       this.inlineCountToText =  this.hintInLineCount;
      //       this.setinLineCount();
      //       this.isLoading = false;
      //       this.startLoading();
      //     }
      //   },
      //   err => {
      //     console.error('Error occurred:', err);
      //   }
      // );

    }
    else
    {
      this.Edited_ConsolidatedQuestionCount();
      // this.hintInLineCount = this.inLineQuestionCount_NewTag;
       this.setinLineCount();
       this.tag.isInlineModeOn = true;
       this.isLoading = false;
       this.startLoading();
    }

  }


}

  startLoading() {
    this.loadingMessage = 'Loading...';
    setTimeout(() => {
      this.loadingMessage = 'Working on the logic...';
    }, 3000); // Change text after 4 seconds
    // Change the loading message after some time
    setTimeout(() => {
      this.loadingMessage = 'Fetching the linked tag question...';
    }, 2500); // Change text after 2 seconds
    setTimeout(() => {
      this.loadingMessage = 'Fetching the current selection question...';
    }, 2500); // Change text after 4 seconds

    // Simulate a loading completion after 6 seconds
    setTimeout(() => {

    }, 6000);
  }

  private getInlineCountFromTagEdit(tag: number) {
    this.getCurrentSelectionUpdatedCount1(tag).subscribe(
      res => {
        // Use the response to update the UI
        this.hintInLineCount = res;
        this.setinLineCount(); // Update the label with the new count
        console.log('Updated count:', res);
        // alert(`Count received: ${res}`);
      },
      err => {
        console.error('Error occurred:', err);
      }
    );
  }


  private setinLineCount() {
    //debugger;
    this.hintmessage = 'Max value: ' + this.hintInLineCount + ' or less';
  }

  private getCurrentSelectionUpdatedCount1(tag: number): Observable<number> {
    return this.getCurrentSelectionUpdatedCountObersvable(tag);
   }
  private getCurrentSelectionUpdatedCountObersvable(tag: number): Observable<number> {
    return this.processConfirmationService.getTagInlineSelectedQuestionCount(tag).pipe(
      tap(res => {
        // Handle the response here if needed
        this.inlineCountToText = res;
        this.hintInLineCount = res;
       // this.tag.inlineCount = 1;
      }),
      catchError(err => {
        console.error(err);
        return throwError(err);
      })
    );
  }
  private getCurrentSelectionLinkedTagQuestionCount(tag: number): Observable<number> {
    return this.processConfirmationService.getSelectedLinkedTagQuestionCount(tag).pipe(
      tap(res => {
        // Handle the response here if needed
       this.linkedTagSelectedCount = res;
      }),
      catchError(err => {
        console.error(err);
        return throwError(err);
      })
    );
  }

  private GetCurrentSelectionQsAndtagCount(tag: number, maintablequestioncount: boolean = false): Observable<number>
  {
    return this.processConfirmationService.getSelectedLinkedTagQuestionCount(tag, maintablequestioncount).pipe(
      tap(res => {
        // Handle the response here if needed
       //this.linkedTagSelectedCount = res;

      }),
      catchError(err => {
        console.error(err);
        this.isLoading = false;
        this.startLoading();
        return throwError(err);
      })
    );
  }


   //New method for curret selection
   private getCurrentSelectionQuestionsAndTag(TagId: string, QuestionCount: number): Observable<number>
   {
     return this.processConfirmationService.getCurrentSelectionQuestionsAndTag(TagId,QuestionCount).pipe(
       tap(res => {
         // Handle the response here if needed
        //this.linkedTagSelectedCount = res;
 
       }),
       catchError(err => {
         console.error(err);
         this.isLoading = false;
         this.startLoading();
         return throwError(err);
       })
     );
   }

  private InlineModeFieldValidation()
  {
    this.tag.inlineCount;
    this.hintInLineCount;

    if (this.hintInLineCount != undefined && this.tag?.inlineCount)
      {
      if(this.tag?.inlineCount > this.hintInLineCount)
        {
          this.tag.inlineCount = 0;
        }
    }
  }

  InlineModeUnselected()
{
  this.tag.IsTagModeSelected = false;
  this.tag.isInlineModeOn = false;
}

async InsertQuestionAndTagSelectedOnClickInlineMode()
{
this.selectedQuestionsNew;
this.selectedTags;
let totaldeleteOperationInit = 1;

//Question Insert
for (let index = 0; index < this.selectedQuestionsNew.length; index++) {
  let question: Question = this.selectedQuestionsNew[index];

  await this.OnLineModeQuestionInsertion_inlineClick(question.questionID, totaldeleteOperationInit);
totaldeleteOperationInit++;
}
//Tag Insert
for (let index = 0; index < this.selectedTags.length; index++) {
  let tag: Tag = this.selectedTags[index];

  await this.OnLineModeTaginsertion_inlineClick(tag.tagID, totaldeleteOperationInit);
totaldeleteOperationInit++;
}
//this.getCurrentSelectionUpdatedCount(this.tag.tagID);
return true;
}

public OnLineModeQuestionInsertion_inlineClick(questionId: any, requestFrom: number = 0): Promise<any> {
  return new Promise((resolve, reject) => {
    this.tagService.insertQuestionIntoTagAssignedInlineMode(this.tag.tagID, questionId, 0, false, requestFrom).subscribe({
      next: (res) => {
        console.log("Success Insert", res);
        resolve(res);  // Resolve the promise when successful
      },
      error: (err) => {
        console.error("Error Insert", err);
        reject(err);  // Reject the promise in case of error
      }
    });
  });
}

public OnLineModeTaginsertion_inlineClick(linkedtagId: any, requestFrom: number = 0): Promise<any> {
  return new Promise((resolve, reject) => {
    this.tagService.insertQuestionIntoTagAssignedInlineMode(this.tag.tagID, 0, linkedtagId, false, requestFrom).subscribe({
      next: (res) => {
        console.log("Success Insert", res);
        resolve(res);  // Resolve the promise when successful
      },
      error: (err) => {
        console.error("Error Insert", err);
        reject(err);  // Reject the promise in case of error
      }
    });
  });
}

onInput(event: Event): void {
  //debugger;
  const input = event.target as HTMLInputElement;
  if (input.valueAsNumber > this.inlineCountToText) {
    let minimumvalue = 1;
    let enteredNumber = input.valueAsNumber!=null && input.valueAsNumber!=undefined ? input.valueAsNumber : 0;
    input.value = minimumvalue.toString(); //this.inlineCountToText.toString();
    this.tag.inlineCount = minimumvalue; //this.inlineCountToText;
    this.actiavteinlinewarning = true;
    this.errorMessage =  this.labels.default.Selectioncountexceedinfo1+' ' + +enteredNumber+' ' + this.labels.default.Selectioncountexceedinfo2 +' ' +this.inlineCountToText;

  } else {
    this.tag.inlineCount = input.valueAsNumber;
    this.actiavteinlinewarning = false;
    this.errorMessage = '';
  }
}

  branchLogicselected(){
    console.log("branch logic selected 1")
    this.tag.isBranchLogicToBeFollowed = true;
   // this.fetchTagsAndQuestions();

    this.OnDragDropCompleted();
    this.arrangeCurrentAndRandomQuestionOrder();
  }
  branchLogicunselected() {
    console.log("branch logic unselected 1")
    this.tag.isBranchLogicToBeFollowed = false;
    //this.fetchTagsAndQuestions();
    this.arrangeCurrentAndRandomQuestionOrder();
  }
 //to fix scroll issue after pop up
 public closeAlertModal(){
  //
  if(document.getElementsByTagName("modal-container").length > 1){
    document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length-1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length-1]);
  }
  else{
    document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
    if(document.getElementsByTagName("bs-modal-backdrop").length > 0){
      document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
    }
    document.querySelector('body').classList.remove('modal-open');
  }

}

  delete(tag: any) {
    if(this.sharedService.ntid){
      this.tag.modifiedBy_NTID = this.sharedService.ntid;
      var d = new Date();
      this.tag.modifiedAt = new Date(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate(),d.getHours(),d.getMinutes(),d.getSeconds()));
    }
    this.tagService.deleteTag(tag).subscribe(
      res => {

        if (res.resultCode == 0) {
          this.alertText = this.labels.default.deleteSuccessfully;
          this.modalService.show(this.successModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          this.router.navigate([environment.home +'/taglist']);

        }
        else if(res.resultCode == 1){
          this.alertText = this.labels.default.tagLinked;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
        }
        else {
          this.alertText = this.labels.default.failedDeleteQuestion;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
        }

      },
      err => {
        console.log(err);
      });
  }


 removeTag(tag: Tag) {
    debugger;
    if (tag !== undefined && Object.keys(tag).length !== 0) {
      let id = tag.tagID;
      this.selectedTags = this.selectedTags.filter(x => x.tagID !== id);
      this.availableTags.push(tag);
    };

      if (!this.isEdit)
      {
        this.getCurrentSelectionLinkedTagQuestionCount(tag?.tagID).subscribe(
          res => {
            debugger;
            if (res != null) {
              let linkedTagReducedCount = this.inLineLinkedTag_QuestionCount_NewTag - res;
              this.NewTag_ConsolidatedQuestionCount(true,linkedTagReducedCount,this.inLineQuestionCount_NewTag);
            }

          },
          err => {
            console.error('Error occurred:', err);
          }
        );

       }
       else{
        // this.OnLineModeTagDeletion(tag.tagID);
        // this.getInlineCountFromTagEdit(this.tag.tagID);

        this.getCurrentSelectionLinkedTagQuestionCount(tag?.tagID).subscribe(
          res => {
            debugger;
            if (res != null) {
              let linkedTagReducedCountEditedTag = this.inLineLinkedTag_QuestionCount_EditedTag - res;
              let tagArray = this.selectedTagIDs?.split(',');  // Split the string into an array

              // Find the index of the tag ID in the array
              const index = tagArray?.indexOf(tag?.tagID.toString());

              if (index != undefined && index !== -1) {
                // Tag ID exists, so remove it
                tagArray.splice(index, 1);

                // Join the array back into a comma-separated string
                this.selectedTagIDs = tagArray.join(',');
              }
              this.Edited_ConsolidatedQuestionCount(true,linkedTagReducedCountEditedTag,this.inLineQuestionCount_EditedTag);
            }

          },
          err => {
            console.error('Error occurred:', err);
          }
        );

       }


  }

  removeQuestion(question: Question) {

    if (question !== undefined && Object.keys(question).length !== 0) {
      let id = question.questionID;
      console.log("1284",id);
      this.OnremoveRandomQuestion(question);
      this.selectedQuestions = this.selectedQuestions.filter(x => x.questionID !== id);
      this.selectedQuestionsNew = this.selectedQuestionsNew.filter(x => x.questionID !== id);
      this.orderSelectedQuestions = this.orderSelectedQuestions.filter(x => x.questionID !== id);//to remove from questions order
      this.availableRandomQuestions = this.availableRandomQuestions.filter(x => x.questionID !== id);
     // this.addedRandomQuestions =this.addedRandomQuestions.filter(x => x.questionID !== id);
      this.availableQuestions.push(question);
      this.inLineQuestionCount_EditedTag = this.selectedQuestionsNew?.length + 1;
      console.log("12591",this.availableRandomQuestions)
      //let flag=1
      // for(let each of this.availableRandomQuestions) {
      //   console.log("1262")
      //   if(each.questionID==question.questionID){
      //     flag=0
      //   }
      //  }
      //  if(flag) {
      //   this.availableRandomQuestions.push(question)
      //  }


      for(let each of this.addedRandomQuestions) {

      this.orderSelectedQuestions = this.orderSelectedQuestions.filter(x => x.questionID !== each.questionID);
      }

      console.log("1259",this.addedRandomQuestions)
      console.log("1260",this.orderSelectedQuestions)
      console.log("1261",this.availableQuestions)
      // for(let each of this.randomQuestionOrder) {
      //   let q='Q'++' '+each.questionText;
      //   const index = this.QuestionOrderList.indexOf(q);
      //   console.log(index); //

      //   if (index !== -1) {
      //     this.QuestionOrderList.splice(index, 1);
      //   }
      // }


      this.QuestionOrderList=[];
      for( let each of this.orderSelectedQuestions) {
        let ques= each.questionText;
        this.QuestionOrderList.push(ques)
      }
        this.OnDragDropListItem();
    };
    if (!this.isEdit)
   {
    let questionCountReduced = this.inLineQuestionCount_NewTag > 0 ? --this.inLineQuestionCount_NewTag:this.inLineQuestionCount_NewTag;
    this.NewTag_ConsolidatedQuestionCount(true,this.inLineLinkedTag_QuestionCount_NewTag,questionCountReduced);
   }
   else{
   // this.OnLineModeQuestionDeletion(question.questionID);
   // this.getInlineCountFromTagEdit(this.tag.tagID);
   let questionCountReducedEditedTag = this.inLineQuestionCount_EditedTag > 0 ? --this.inLineQuestionCount_EditedTag:this.inLineQuestionCount_EditedTag;
   this.Edited_ConsolidatedQuestionCount(true,this.inLineLinkedTag_QuestionCount_EditedTag,questionCountReducedEditedTag);
   }
  }

  openTagStreamHistory(tagStreamHistory: TemplateRef<any>) {

    this.tagService.getTagStreamTemplateHistory(this.templateId).subscribe(res => {
      this.tagStreamHistoryDetails = res;
    });

    this.modalRef = this.modalService.show(tagStreamHistory, this.config);
    this.modalRef.setClass('modal-lg');
    $('.isRestoreDisabled').prop('disabled', true);

    setTimeout(function () {
      $("#tagHisTab tbody tr").click(function () {
        $(".selected").removeClass('selected');
        $(this).addClass('selected');
        $('.isRestoreDisabled').prop('disabled', false);
      });
    }, 500);
  }


  tagStreamTemplateHistoryID: number;

  restoreVersion() {
    document.querySelector('body').classList.remove('modal-open');
    this.tagStreamTemplateHistoryID = Number($("#tagHisTab tbody tr.selected td:first").html());
    this.tagService.tagRestoreByTemplateHistoryID(this.tagStreamTemplateHistoryID).subscribe(res => {
      this.closeAlertModal();
      this.alertText = this.labels.default.restoreSuccessfully;
      this.modalService.show(this.successModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      this.router.navigate(['../'+ environment.home +'/taglist']);
    },
      (err) => {
        console.log(err.message);
        this.closeAlertModal();
      });
  }

  setTargetFrequency(value: any) {
    if (value) {
      this.tag.isTargetFrequencyDefined = true;
    }
    else {
      this.tag.isTargetFrequencyDefined = false;
       this.tag.targetFrequencyValue=undefined;
       this.tag.targetFrequencyTypeID=undefined;

    }
  }

  //for valuestream and assessor template selection
  valueStreamTemplate: ValueStreamTemplate = new ValueStreamTemplate();
  valueStreamTemplates: ValueStreamTemplate[] = [];
  valueStreamCategories: ValueStreamCategory[] = [];
  //valueStreamCategoriesNew: ValueStreamCategory[] = [];
  valueStreams: ValueStream[] = [];
  assessorTemplateList: AssessorTemplate[] = [];
  assessorTemplate: AssessorTemplate = new AssessorTemplate();
  assessors: Assessor[] = [];
  assessor: Assessor;

  //for multiselect dropdown
  selectedValueStreams = [];
  selectedValueStreamIDs = [];
  valueStreamSettings = {};

  //for Assessor Multiselect dropdown
  selectedAssessors = [];
  selectedAssessorIDs = [];
  assessorSettings = {};
  assignedTargetFrequency = [];

  assessorIDs: string;
  valueStreamIDs: string;

  // public getValueStreamList() {

  //   this.valueStreamTemplates = [];
  //   this.valueStreamService.getValueStreamTemplate().subscribe(res => {
  //     this.valueStreamTemplates = res;
  //     this.onLoadTagStream();
  //     this.valueStreamService.getValueStreamCategory().subscribe(res1 => {
  //       this.valueStreamCategories = res1;
  //       this.valueStreamCategories = this.valueStreamCategories.filter(x => x.valueStreamCategoryName !== "VS Responsible Employee" && x.valueStreamCategoryName !== "SHIFT")
  //       this.onLoadValueStreamCategory();
  //       this.valueStreamService.getValueStream().subscribe(res2 => {
  //         this.valueStreams = res2;

  //         //to make the list/tree view selection for value stream templates
  //         if(this.isEdit && this.tag.assigned_ValueStreamTemplateID){

  //           // let vsListType = this.valueStreamTemplates.filter(x =>x.valueStreamTemplateID == this.tag.assigned_ValueStreamTemplateID)[0].visualizationViewModeID;

  //           // if(this.isEdit && vsListType == 1){
  //           //   this.tag.assigned_ValueStreamCategoryID = undefined;
  //           // this.valueStreamCategories =[];
  //           // }

  //           if (this.valueStreamTemplates.filter(x => this.tag.assigned_ValueStreamTemplateID.find(y => y == x.valueStreamTemplateID) && x.visualizationViewModeID == 2).length == 0) {
  //             this.tag.assigned_ValueStreamCategoryID = [];
  //             this.valueStreamCategories = [];
  //           }
  //        }
  //         //for Assessor List
  //         this.assessorTemplateList = [];
  //     this.assessorTemplateService.getAssessorTemplates().subscribe(res => {
  //     this.assessorTemplateList = res;
  //       this.onLoadAssessorTemplate();
  //     this.assessorTemplateService.getAssessors().subscribe(res1 => {
  //       this.assessors = res1;
  //       if(this.isEdit){
  //         if (this.tag.tagID != undefined && this.tag.tagID != null && this.tag.tagID > 0) {
  //           this.fetchTagsAndQuestions();
  //         }
  //     }
  //     },
  //       err => { console.log(err); }
  //     )
  //   },
  //     err => {
  //       console.log(err);
  //     }
  //   );
  //       }, err => { console.log(err) })
  //         ;
  //     }, err => { console.log(err) });
  //   },
  //     err => {
  //       console.log(err);
  //     }
  //   );
  // }

  public getValueStreamList() {

  this.valueStreamTemplates = [];
    this.valueStreamService.getValueStreamTemplate().subscribe(res => {
      this.valueStreamTemplates = [];
      this.valueStreamTemplates = res;
      this.onLoadTagStream();
      this.valueStreamService.getValueStreamCategory().subscribe(res1 => {
        this.valueStreamCategories = res1;
        this.valueStreamCategories = this.valueStreamCategories.filter(x =>x.valueStreamCategoryName !=="VS Responsible Employee" && x.valueStreamCategoryName !=="SHIFT")

        this.valueStreamService.getValueStream().subscribe(res2 => {

          this.valueStreams = res2;

           // to limit the valuestreams based on VS template ID
     // this.valueStreamCategories = this. valueStreamCategories.filter(x =>  this.tag.assigned_ValueStreamTemplateID.find(y=> y == x.valueStreamTemplateID));
      //this.valueStreams = this.valueStreams.filter(x =>this.tag.assigned_ValueStreamTemplateID.find(y=> y == x.valueStreamTemplateID) && x.valueStreamName); //to fetch the last nodes

          if (this.isEdit) {
            //to make the list/tree view selection for value stream templates
            //let vsListType = this.valueStreamTemplates.filter(x =>x.valueStreamTemplateID == this.question.assigned_ValueStreamTemplateID)[0].visualizationViewModeID;

            // if(this.isEdit && vsListType == 1){
            //   this.question.assigned_ValueStreamCategoryID = undefined;
            //  this.valueStreamCategories =[];
            // }}

            // if (this.valueStreamTemplates.filter(x => this.tag.assigned_ValueStreamTemplateID.find(y => y == x.valueStreamTemplateID) && x.visualizationViewModeID == 2).length == 0) {
            //   this.tag.assigned_ValueStreamCategoryID = [];
            //   this.valueStreamCategories = [];
            // }

            if (this.selectedItemTagStream.filter(x => x.visualizationViewModeID == 2).length == 0) {
              this.tag.assigned_ValueStreamCategoryID = undefined;
              this.valueStreamCategories =[];
            }



            this.valueStreams=this.valueStreams.filter(r=>this.selectedItemTagStream.find(x=>x.valueStreamTemplateID== r.valueStreamTemplateID));

            this.assessors=this.assessors.filter(t=>this.selectedItemAssessorTemplate.find(x=>x.assessorTemplateID==t.assessorTemplateID));

            this.fetchTagsAndQuestions();
          }
          if(this.isAdd)
          {
            this.selectedItemTagStream = [];
            this.selectedItemValueStreamCategory = [];
            this.selectedItemAssessorTemplate = [];


            if(this.selectedItemAssessorTemplate.length < 1)
            {

              this.valueStreams=[];
              this.selectedValueStreams=[];

             this.valueStreamCategories=[];
             this.selectedItemValueStreamCategory=[];

              this.assessors = [];
              this.selectedAssessors = [];
            }

              // this.tag.assigned_AssessorTemplateID = [];
              // this.tag.assigned_ValueStreamTemplateID = [];

             //this.tag.assigned_ValueStreamCategoryID = undefined;
             this.selectedItemValueStreamCategory = [];

          }

        }, err => { console.log(err) })
          ;
      }, err => { console.log(err) });
    },
      err => {
        console.log(err);
      }
    );
  }

  public getAssessorTemplateList() {
    this.assessorTemplateList = [];
    this.assessorTemplateService.getAssessorTemplates().subscribe(res => {
      this.assessorTemplateList = res;
      this.onLoadAssessorTemplate();
      // this.assessorTemplateService.getAssessors().subscribe(res1 => {
      //   this.assessors = res1;
      //    // to limit the assessors based on Assesor ID
      // this.assessors = this.assessors.filter(x =>x.assessorTemplateID == this.question.assigned_AssessorTemplateID);


      // },
      //   err => { console.log(err); }
      // )
    },
      err => {
        console.log(err);
      }
    );
  }
  public getAssessorsByTemplateID(templateID: any) {
    let selectedItem = this.assessors.find(x => x.assessorTemplateID == templateID);
    if(selectedItem == undefined ){
      this.assessorTemplateService.getAssessorsByTemplateID(templateID).subscribe(
        res => {
          let X = this.assessors;
          this.assessors = res;
          this.assessors.push(...X);
        },
        err => {
          console.log(err);
        }
      );
    }

    if(selectedItem !== undefined ){
      this.assessorTemplateService.getAssessorsByTemplateID(templateID).subscribe(
        res => {
          this.assessors = []
          //this.assessors = res;
          this.assessors.push(...res);
        },
        err => {
          console.log(err);
        }
      );
    }
  }


  // to load the value streams based on list/tree view in VS Template
  valueStreamTemplateChange(valueStreamTempID: any) {
    console.log(this.valueStreams)
    //this.valueStreams = [];
    //this.selectedValueStreams = [];
    this.visulizationViewModeID = this.valueStreamTemplates.filter(x =>x.valueStreamTemplateID == valueStreamTempID)[0].visualizationViewModeID;

    if(this.visulizationViewModeID == 2){
      debugger;

      const selectedItem = this.valueStreamCategories.find(x => x.valueStreamTemplateID == valueStreamTempID);

      if(selectedItem === undefined){
        this.valueStreamService.getValueStreamCategoryByTemplateID(valueStreamTempID).subscribe(res => {
          //this.valueStreamCategories = [];
          //this.valueStreamCategories = res;
          this.valueStreamCategories.push(...res);
          this.valueStreamCategories = this.valueStreamCategories.filter(x =>x.valueStreamCategoryName !=="VS Responsible Employee" && x.valueStreamCategoryName !=="SHIFT")
          //this.valueStreamCategoriesNew=JSON.parse(JSON.stringify(this.valueStreamCategories))
          this.onLoadValueStreamCategory();
          //this.onAssessorSelect();
        },
          err => {
            console.log(err);
          });
      }

      if(selectedItem !== undefined){
        this.valueStreamService.getValueStreamCategoryByTemplateID(valueStreamTempID).subscribe(res => {
          this.valueStreamCategories = [];
          //this.valueStreamCategories = res;
          this.valueStreamCategories.push(...res);
          this.valueStreamCategories = this.valueStreamCategories.filter(x =>x.valueStreamCategoryName !=="VS Responsible Employee" && x.valueStreamCategoryName !=="SHIFT")
          //this.valueStreamCategoriesNew=JSON.parse(JSON.stringify(this.valueStreamCategories))
          this.onLoadValueStreamCategory();
          //this.onAssessorSelect();
        },
          err => {
            console.log(err);
          });
      }

    }
    else{
      //this.valueStreamCategories = [];
      const selectedItem = this.valueStreams.find(x => x.valueStreamTemplateID == valueStreamTempID);

     if(selectedItem === undefined){
      this.valueStreamService.getValueStreamsByTemplateID(valueStreamTempID).subscribe(res =>{
        //this.valueStreams = [];
        //this.valueStreams = res;
        this.valueStreams.push(...res);
        this.valueStreams = this.valueStreams.filter(x =>x.valueStreamName && x.responsible_UserID); // fix for listview duplicates
        //this.onAssessorSelect();
      },
      err =>{
        console.log(err);
      });
     }

     if(selectedItem !== undefined){
      this.valueStreamService.getValueStreamsByTemplateID(valueStreamTempID).subscribe(res =>{
        this.valueStreams = [];
        //this.valueStreams = res;
        this.valueStreams.push(...res);
        this.valueStreams = this.valueStreams.filter(x =>x.valueStreamName && x.responsible_UserID); // fix for listview duplicates
        //this.onAssessorSelect();
      },
      err =>{
        console.log(err);
      });
     }



    }
  }

onValuestreamCategoryOpen(){
  this.isLoadingVs=true;
  this.valueStreamCategories=JSON.parse(JSON.stringify(this.valueStreamCategories))
  this.isLoadingVs=false;
}

onValuestreamOpen() {
  console.log(this.valueStreams)
  this.isLoadingVs=true;
  this.valueStreams=JSON.parse(JSON.stringify(this.valueStreams))
  this.isLoadingVs=false;
}


onassessorOpen() {
  console.log(this.assessors)
  this.isLoadingVs=true;
  this.assessors=JSON.parse(JSON.stringify(this.assessors))
  this.isLoadingVs=false;
}

  valueStreamCategoryChange(valueStreamCategoryID: any) {
    const selectedItem = this.valueStreams.find(x => x.valueStreamCategoryID == valueStreamCategoryID);

    if(selectedItem === undefined){
      this.valueStreamService.getValueStreamsByCategoryID(valueStreamCategoryID).subscribe(res => {
        this.valueStreams.push(...res);
        //this.valueStreams = res;
        this.valueStreams = this.valueStreams.filter(x =>x.valueStreamName && x.responsible_UserID);
      },

        err => {
          console.log(err);
        });
    }

    if(selectedItem !== undefined){
      this.valueStreamService.getValueStreamsByCategoryID(valueStreamCategoryID).subscribe(res => {
        this.valueStreams =[];
        this.valueStreams.push(...res);
        //this.valueStreams = res;
        this.valueStreams = this.valueStreams.filter(x =>x.valueStreamName && x.responsible_UserID);
      },
        err => {
          console.log(err);
        });
    }
  }

  onItemSelect(item: any) {
    this.onAssessorSelect();
  }
  onSelectAll(items: any) {

    this.onAssessorSelect();
  }

  assessorValueStreamList : AssessorValueStreamList = new AssessorValueStreamList();
  onAssessorSelect(item?: any) {

    const valueStreamsIDStr = this.valueStreams.map(r => r.valueStreamID.toString());
    if(this.isAdd && this.unload)
    {
      this.selectedValueStreams=this.selectedValueStreams.filter(t=>this.valueStreams.find(x=>x.valueStreamID==t.valueStreamID));
    }
    const assessorIDStr = this.assessors.map(r => r.assessorID.toString());
    this.assessorValueStreamList.valueStreamIDs = valueStreamsIDStr.toString();
    this.assessorValueStreamList.assessorIDs = assessorIDStr.toString();

    if (this.tag.tagTypeID == 1) //if tag type is process confirmation, it should not filter the VS and Assessor
    {
      this.assessorValueStreamList.assessorIDs = "0";
    }

    this.tagService.fetchQuestionsByAssessorsAndValueStreams(this.assessorValueStreamList).subscribe(res => {
      this.availableQuestions = res;

      if(this.selectedQuestions && this.selectedQuestions.length > 0){
        for(let question of this.selectedQuestions){
          if(this.availableQuestions && this.availableQuestions.length >0){
            this.availableQuestions = this.availableQuestions.filter(x =>x.questionID !== question.questionID);
          }
        }
      }
      console.log("1744",this.addedRandomQuestions)
      if(this.addedRandomQuestions && this.addedRandomQuestions.length > 0){
        for(let question of this.addedRandomQuestions){
          if(this.availableQuestions && this.availableQuestions.length >0){
            this.availableQuestions = this.availableQuestions.filter(x =>x.questionID !== question.questionID);
          }
        }

      }
      this.tagService.fetchTagsByAssessorsAndValueStreams(this.assessorValueStreamList).subscribe(data =>{

        this.availableTags = data;
        this.availableTags = this.availableTags.filter(x => x.tagID !== this.tag.tagID); // to remove the own tag from the list


      if(this.selectedTags && this.selectedTags.length > 0){
        for(let tag of this.selectedTags){
          if(this.availableTags && this.availableTags.length >0){
            this.availableTags = this.availableTags.filter(x =>x.tagID !== tag.tagID);
          }

        }

      }
      this.sharedService.hide();
      }, err =>console.error(err));
    }, err =>console.error(err));



  }

  onAssessorSelectAll(items: any) {

    this.onAssessorSelect(); //to list the available tags and questions
  }
  //end of Valuestream and Assessor Template selection


//to clear tag and question selection bases on tag type
 clearTagQuestion(value:any){
  //
  console.log("2098",value)
  if (value) {
    this.tag.tagTypeID = value;
  }
  // this.selectedQuestionsNew=[];
  // this.addedRandomQuestions=[];
  // this.availableQuestions = [];
  // this.availableTags = [];
  // this.selectedTags = [];
  // this.selectedQuestions = [];
  // this.orderSelectedQuestions = [];
  // this.QuestionOrderList = [];

  // this.resultQuestionOrder=[];
  // this.randomQuestionOrder=[];
  // this.finalQuestionOrder=[];


  // this.onAssessorSelect();

  //this.fetchTagsAndQuestions();
      if(this.tag.tagTypeID == 1){
        this.tag.isSearchableTag = true;
        this.tag.isSkipQuestionDefined = true;
        this.tag.isQuestionOverviewDefined = false;
        this.tag.isProgressPercentageDefined = false;
        this.tag.isResultOverviewDefined = false;
        this.tag.isResumeTagDefined = false;
        this.tag.isReportingEmailDefined = false;
        if(!this.tag.isBranchLogicToBeFollowed){
        this.tag.isBranchLogicToBeFollowed = false;
        }
        this.tag.isMandatoryAssessorsDefined = false;
        this.tag.anonymizeUserDataSettingID = 3;
        this.IsInlineModeActivate = true;
      }
      if(this.tag.tagTypeID == 2){
        this.tag.isSearchableTag = true;
        this.tag.isSkipQuestionDefined = false;
        this.tag.isQuestionOverviewDefined = true;
        this.tag.isProgressPercentageDefined = true;
        this.tag.isResultOverviewDefined = true;
        this.tag.isResumeTagDefined = true;
        this.tag.isReportingEmailDefined = true;
        if(!this.tag.isBranchLogicToBeFollowed){
        this.tag.isBranchLogicToBeFollowed = false;
        }
        this.tag.isMandatoryAssessorsDefined = false;
        this.tag.anonymizeUserDataSettingID = 3;
        this.IsInlineModeActivate = false;
      }
      if(this.tag.tagTypeID == 3){
        this.tag.isSearchableTag = true;
        this.tag.isSkipQuestionDefined = false;
        this.tag.isQuestionOverviewDefined = true;
        this.tag.isProgressPercentageDefined = true;
        this.tag.isResultOverviewDefined = true;
        this.tag.isResumeTagDefined = true;
        this.tag.isReportingEmailDefined = true;
        if(!this.tag.isBranchLogicToBeFollowed){
        this.tag.isBranchLogicToBeFollowed = false;
        }
        this.tag.isMandatoryAssessorsDefined = false;
        this.tag.anonymizeUserDataSettingID = 1;
        this.IsInlineModeActivate = false;
      }
      if(this.tag.tagTypeID == 4){
        this.tag.isSearchableTag = false;
        this.tag.isSkipQuestionDefined = false;
        this.tag.isQuestionOverviewDefined = false;
        this.tag.isProgressPercentageDefined = false;
        this.tag.isResultOverviewDefined = false;
        this.tag.isResumeTagDefined = false;
        this.tag.isReportingEmailDefined = false;
        if(!this.tag.isBranchLogicToBeFollowed){
        this.tag.isBranchLogicToBeFollowed = false;
        }
        this.tag.isMandatoryAssessorsDefined = false;
        this.tag.anonymizeUserDataSettingID = 3;
        this.IsInlineModeActivate = false;
      }
  }
  clearMultiTag(value: any) {
    this.tag.tagName = "";
    if (value) {
      this.selectedmultitag = value;
      if (value == 11) {
        this.tagChecked = true;
        this.tagUnChecked = false;
      } else {
        this.tagUnChecked = true;
        this.tagChecked = false;
      }
    }
  }
  onSelectTagFile(event) {
    //validate the file if file size is more than 10MB
    for (var i = 0; i < event.target.files.length; i++) {
      var name = event.target.files[i].name;
      var type = event.target.files[i].type;
      var size = event.target.files[i].size;
      var modifiedDate = event.target.files[i].lastModifiedDate;

      if (size > environment.maxFileSize) {
        this.alertText = this.labels.default.maximumFileSize;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        return;
      }

      console.log('Name: ' + name + "\n" +
        'Type: ' + type + "\n" +
        'Last-Modified-Date: ' + modifiedDate + "\n" +
        'Size: ' + Math.round(size / 1024) + " KB");
    }
    // *************************validation of file size ends here**************
    let now = new Date();

    var jstoday;
    jstoday = formatDate(now, 'dd_MM_yyyy hh_mm_ss_a', 'en-US', '+0530').toString();

    let totalSize = 0;
    if (event.target.files && event.target.files[0]) {
      var filesAmount = event.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        let name = event.target.files[i].name;
        var fileTypes = environment.fileTypes.split(",").map(function (item) {
          return item.trim();
        });
        var extension = name.slice((Math.max(0, name.lastIndexOf(".")) || Infinity) + 1);
        let x = fileTypes.filter(x => x.toLocaleLowerCase() == extension.toLocaleLowerCase());

        if (x.length == 0) {
          this.alertText = name + this.labels.default.fileUploadError.replace("((FileTypes))", environment.fileTypes);
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          return;
        }

        if (extension != "xls" && extension != "xlsx") {
          this.alertText = this.labels.default.fileTypeError;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          return;
        }
      }
    }
    let fileReader = new FileReader();
    this.file = event.target.files[0];
    fileReader.onload = (e) => {
      this.arrayBuffer = fileReader.result;
      var data = new Uint8Array(this.arrayBuffer);
      var arr = new Array();
      for (var i = 0; i != data.length; ++i) arr[i] = String.fromCharCode(data[i]);
      var bstr = arr.join("");
      var workbook = XLSX.read(bstr, { type: "binary" });
      var first_sheet_name = workbook.SheetNames[0];
      var worksheet = workbook.Sheets[first_sheet_name];
      var dataarray = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
      console.log(XLSX.utils.sheet_to_json(worksheet, { header: 1 }));
      this.tag.tagName = "";
      for (var n = 0; n < dataarray.length; n++) {
        this.tag.tagName += dataarray[n][0] + "!@#$%";
      }
      this.tag.tagName = this.tag.tagName.slice(0, -5);
    }
    fileReader.readAsArrayBuffer(this.file);
  }

}


