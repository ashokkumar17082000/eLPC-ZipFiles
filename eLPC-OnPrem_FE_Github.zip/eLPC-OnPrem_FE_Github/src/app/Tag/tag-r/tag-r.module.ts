import { NgModule,CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TagRRoutingModule } from './tag-r-routing.module';
import { TagEditComponent } from '../tag/tag-edit.component';
import { TagListComponent } from '../tag/tag-list.component';
import { TagLockComponent } from '../tag/tag.lock.component';
import { FormsModule,ReactiveFormsModule  } from '@angular/forms';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { NgxPaginationModule } from 'ngx-pagination';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { OrderModule } from 'ngx-order-pipe';
import { DatePipe } from '@angular/common';
import { SharedModule } from 'src/app/shared/shared.module'
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { DragDropModule } from '@angular/cdk/drag-drop';



@NgModule({
  declarations: [TagEditComponent,TagListComponent,TagLockComponent],
  imports: [
    CommonModule,
    TagRRoutingModule,
    FormsModule,
    PaginationModule.forRoot(),
    BsDatepickerModule.forRoot(),
    NgMultiSelectDropDownModule.forRoot(),
    OrderModule,
    SharedModule,
    ReactiveFormsModule,
    NgxPaginationModule,
    DragDropModule
  ],
  exports: [TagEditComponent,TagListComponent,TagLockComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
  
})
export class TagRModule { }
