import { Component, OnInit } from '@angular/core';
import { SharedService } from '../service/shared.service';
//import {HeaderComponent} from '../main/header/header.component';
import { HeaderComponent } from './header/header.component';
@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})

export class MainComponent implements OnInit {

  constructor(private sharedService: SharedService) { }

  /** Method to set default values to the entire application.  */
  ngOnInit() {
    this.sharedService.setIconName("Shuffle Mode");
    setTimeout(() => {
      this.sharedService.setIcon("assets/image/Material.svg");
    }, 100);
    this.sharedService.sessionID = new Date().valueOf().toString();
  }
}
