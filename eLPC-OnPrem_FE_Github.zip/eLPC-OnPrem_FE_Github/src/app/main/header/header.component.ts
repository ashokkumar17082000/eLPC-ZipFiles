import { Component, OnInit, ViewChild, TemplateRef} from '@angular/core';
declare var $;
import { Router, NavigationEnd } from '@angular/router';
import { CommonService } from 'src/app/service/common/common.service';
import { SharedService } from 'src/app/service/shared.service';
import {LanguageService} from '../../language.service';
import { environment } from '../../../environments/environment';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { AdditionalData, User, UserAdditionalData } from '../body/shared/common';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})


export class HeaderComponent implements OnInit {

  plantName: string;
  routername: any[];
  pageName: string;
  name: string;
  isCollapsed = true;
  isCollapsedLeftNav = false;
  username: string;
  role: string;
  toggleiconname: string = "fa fa-times";
  selectedIcon: string;
  displayName :string;
  selectedLanguage : string = "EN";
  labels:any;
  showMenu: boolean = true;
  languageArr: any[];
  modalRef: BsModalRef;
  dataTable: any;
  headerFilterName:string="";//for filtering

  UserPlantDetails: any;
  originalPlantID : number;
  key: string = 'name';//for sorting
  reverse1: boolean = false;//for sorting
  searchTerm:string="";//for filtering
  page: number = 1;
  resultPerPage: number = 5;
  startPage: number;
  endPage: number;
  defaultPlantID: any;
  defaultPlantName: string;
  currentPlantName: string;
  slectedPlantDescription: string;
  alertText: any;
  isSetAsDefault: boolean;
  currentPlantOnLoad: any;
  marqueeAlert:any ="";
  toggleMenu() {
    this.showMenu = !this.showMenu;
    this.commonService.toggleMenuLeftNav("");

    // if (this.isCollapsed == true) {
    //   this.isCollapsed = false;
    //   $("#page-wrapper").css({ "margin": "0 0 0 170px" });
    //   $("#sidebar").show(400);
    // } else if (this.isCollapsed == false) {
    //   this.isCollapsed = true;
    //   $("#page-wrapper").css({ "margin": "0 0 0 0px" });
    //   $("#sidebar").hide();
    // }
  }

  @ViewChild('plantTemplate') plantTemplateModal: TemplateRef<any>;
  @ViewChild('alertPopup') warningModal: TemplateRef<any>;
  @ViewChild('qAwardPopup') qAwardModal: TemplateRef<any>;

  constructor(private router: Router, private commonService: CommonService, private sharedService:SharedService,private local_label:LanguageService, private modalService: BsModalService) {
    $(document).ready(function () {
      $('.asdf').on('click', function (e) {
        e.preventDefault();
      });
    });

    if (this.sharedService.role != null && this.sharedService.role != undefined && this.sharedService.role != "") {
      this.role = this.sharedService.role;
    }
    if (this.sharedService.displayName != null && this.sharedService.displayName != undefined && this.sharedService.displayName != "") {
      this.displayName = this.sharedService.displayName;
    }

  /** Responsible for setting header label based on current page. */
    this.router.events.subscribe((ev) => {
      if (ev instanceof NavigationEnd) {
        this.routername = ev.url.split('/');

        this.name = this.routername[this.routername.length - 1];


        if (this.name == 'home') {
          this.pageName = "Dashboard";
        }
        else if (this.name == 'dashboard') {
          this.pageName = "Dashboard";
        }
        else if (this.name == 'role') {
          this.pageName = "Role";
        }
        else if (this.name == 'user') {
          this.pageName = "User";
        }
        else if (this.name == 'valuestreams') {
          this.pageName = "Value Streams";
        }
        else if (this.name == 'assessors') {
          this.pageName = "Assessors";
        }
        else if (this.name == 'questions') {
          this.pageName = "Questions";
        }
        else if (this.name == 'taglist') {
          this.pageName = "Tag";
        }
        else if (this.name == 'datapool') {
          this.pageName = "Data Pool";
        }
        else if (this.name == 'recyclebin') {
          this.pageName = "Recycle Bin";
        }
        else if (this.name == 'calendar') {
          this.pageName = "Calendar";
        }
        else if (this.name == 'tag-edit') {
          this.pageName = "Tag Edit";
        }
        else{
          this.pageName = "";
        }
      }
      this.getDefaultPlant();
    });


    this.sharedService._selectedIconName.subscribe(res => {
      this.titleText = res;
    });

    this.sharedService._selectedPlant.subscribe(res => {
      this.setLanguage();
      this.getDefaultPlant();
    });

    this.getDefaultPlant();
  }

  getDefaultPlant()
  {
    if (this.sharedService.sharedUserDetails != null && this.sharedService.sharedUserDetails.avaliablePlants != null && this.sharedService.sharedUserDetails.avaliablePlants.length > 0) {
      this.UserPlantDetails = JSON.parse(JSON.stringify(this.sharedService.sharedUserDetails.avaliablePlants)).sort(this.fieldSorter(['-isDefault', 'plantCode']));

      let defaultPlant = JSON.parse(JSON.stringify(this.UserPlantDetails)).filter(item => item.isDefault == true);
      if (defaultPlant.length > 0) {
        this.defaultPlantID = defaultPlant[0].plantID;
        this.defaultPlantName = defaultPlant[0].plantCode + '-' + defaultPlant[0].plantName;
        if(defaultPlant[0].marqueeAlert != null && defaultPlant[0].marqueeAlert.length > 0)
        {
          this.marqueeAlert = defaultPlant[0].marqueeAlert;
        }
      }

      let currentSelectedPlant = JSON.parse(JSON.stringify(this.UserPlantDetails)).filter(item => item.plantID == this.sharedService.plantID);
      if (currentSelectedPlant.length > 0) {
        this.currentPlantName = currentSelectedPlant[0].plantCode + '-' + currentSelectedPlant[0].plantName;
        this.sharedService.PlantNameSelected = this.currentPlantName;
        if(currentSelectedPlant[0].marqueeAlert != null && currentSelectedPlant[0].marqueeAlert.length > 0)
        {
          this.marqueeAlert = currentSelectedPlant[0].marqueeAlert;
        }
      }
    }
  }

  fieldSorter = (fields) => (a, b) => fields.map(o => {
    let dir = 1;
    if (o[0] === '-') { dir = -1; o=o.substring(1); }
    return a[o] > b[o] ? dir : a[o] < b[o] ? -(dir) : 0;
  }).reduce((p, n) => p ? p : n, 0);

  config = {
    animated: false,
    keyboard: true,
    ignoreBackdropClick: true
  };

  qAwardConfig = {
    keyboard: false,
    ignoreBackdropClick: true,
    class: 'modal-lg'
  };

  open(template: TemplateRef<any>) {
    this.isSetAsDefault = false;
    this.currentPlantOnLoad = JSON.parse(JSON.stringify(this.UserPlantDetails)).filter(item => item.plantID == this.sharedService.plantID);
    if(this.currentPlantOnLoad != null && this.currentPlantOnLoad.length > 0)
    {
      this.currentPlantOnLoad = this.currentPlantOnLoad[0];
    }

    this.onPlantSelectionChange(this.sharedService.plantID);
    this.UserPlantDetails = this.UserPlantDetails.sort(this.fieldSorter(['-isDefault', 'plantCode']));

    this.modalRef = this.modalService.show(template, this.config);
    this.modalRef.setClass('modal-lg calendar-modal');
  }

  onPlantDescriptionChange(plantID: Number) {
    let selectedPlant = this.UserPlantDetails.filter(item => item.plantID == plantID);
    if (selectedPlant.length > 0) {
      this.slectedPlantDescription = selectedPlant[0].generalMessage;
    }
  }

  onPlantSelectionChange(plantID: Number) {
    this.UserPlantDetails.forEach(item => {
      item.isDefault = false;
      if (item.plantID == plantID) {
        item.isDefault = true;
      }
    });
  }

  public doFilter = (value: string) => {
    this.UserPlantDetails = JSON.parse(JSON.stringify(this.sharedService.sharedUserDetails.avaliablePlants)).sort(this.fieldSorter(['-isDefault', 'plantCode']));

    if (value.length > 0) {
      this.UserPlantDetails = this.UserPlantDetails.filter(x =>
        x.plantCode.trim().toLowerCase().includes(value.trim().toLowerCase()) ||
        x.plantName.trim().toLowerCase().includes(value.trim().toLowerCase()) ||
        x.currentDisplayRole.trim().toLowerCase().includes(value.trim().toLowerCase())
      );
      this.page = 1;
    }
  }

  save()
  {
    this.page = 1;
    let selectedPlant = this.UserPlantDetails.filter(item => item.isDefault == true);
    if (selectedPlant.length > 0) {
      if(!selectedPlant[0].isActive || selectedPlant[0].isUnderMaintenance)
        return;

      if(this.currentPlantOnLoad.plantID == selectedPlant[0].plantID)
      {
        this.closeAlertModal(true);
      }
      else
      {
        this.closeAlertModal(false);
        this.sharedService.show();
        this.sharedService.apiURL ="";
        this.sharedService.plantID = selectedPlant[0].plantID;
        this.sharedService.currentUserInfo = selectedPlant[0];
        //this.sharedService.currentRole = selectedPlant[0].currentRole;
        if (this.isSetAsDefault) {

          var user = new User();
          user.emailAddress = this.sharedService.sharedUserDetails.emailAddress;
          user.firstName = this.sharedService.sharedUserDetails.firstName;
          user.lastName = this.sharedService.sharedUserDetails.lastName;
          user.ntid  = this.sharedService.sharedUserDetails.ntid;
          user.plantID = selectedPlant[0].plantID;
          user.userName = this.sharedService.sharedUserDetails.userName;

          this.sharedService.SetDefaultPlant(user).subscribe(res => {

          });
        }

        this.sharedService.GetEnironmentConfigFromDBAndLogin(this.sharedService.ntid, this.router, "/dashboard");
      }
    }
    else
    {
      this.alertText = this.labels.default.selectChoice;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
    }
  }


  public closeAlertInfo() {
    if (document.getElementsByTagName("modal-container").length > 1) {
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1]);
    }
    else {
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if (document.getElementsByTagName("bs-modal-backdrop").length > 0) {
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }
  }

  public closeAlertModal(isCancel:boolean = true) {
    this.page = 1;
    if(isCancel)
    {
      this.UserPlantDetails = JSON.parse(JSON.stringify(this.sharedService.sharedUserDetails.avaliablePlants)).sort(this.fieldSorter(['-isDefault', 'plantCode']));
    }
    if (document.getElementsByTagName("modal-container").length > 1) {
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1]);
    }
    else {
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if (document.getElementsByTagName("bs-modal-backdrop").length > 0) {
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
      document.querySelector('body').style.paddingRight ="0";
    }
  }

  initializeDataTable() {
    setTimeout(() => {
      this.dataTable = $('#listOfPlants').DataTable({
        "serverSide": true,
        "ordering": false,
        "searching": false,
        "bPaginate": true,
        "bLengthChange": false,
        "bFilter": true,
        "bInfo": false,
        "bAutoWidth": false,
        "pagingType": "full_numbers",
        destroy: true,
        "pageLength": 10,
        language: {
          paginate: {
            next: `<svg class="DP-next" version="1.1" id="Icon_x5F_contour_1_2" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"   viewBox="0 0 192 192"   style="enable-background:new 0 0 192 192;" xml:space="preserve" width="35" height="35"> <g> <polygon points="70.8,158.8 65.2,153.2 122.3,96 65.2,38.8 70.8,33.2 133.7,96 " /> </g> </svg>`,
            previous: `<svg class="DP-prev" version="1.1" id="Icon_x5F_contour_1_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 192 192" style="enable-background:new 0 0 192 192;" xml:space="preserve" width="35" height="35"> <g> <polygon points="121.2,158.8 58.3,96 121.2,33.2 126.8,38.8 69.7,96 126.8,153.2" /> </g> </svg>`,
            first: `<svg version="1.1" id="Icon_x5F_contour" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 192 192" enable-background="new 0 0 192 192" xml:space="preserve" width="18" height="18"><g><polygon points="145.3,158.9 78.3,96.1 141.2,33.2 146.8,38.8 89.7,95.9 150.7,153.1" /></g><g><polygon points="105.3,158.9 38.3,96.1 101.2,33.2 106.8,38.8 49.7,95.9 110.7,153.1" /></g></svg>`,
            last: `<svg version="1.1" id="Icon_x5F_contour" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 192 192" enable-background="new 0 0 192 192" xml:space="preserve" width="18" height="18"><g><polygon points="50.8,158.8 45.2,153.2 102.3,96 45.2,38.8 50.8,33.2 113.7,96 	" /></g><g><polygon points="90.8,158.8 85.2,153.2 142.3,96 85.2,38.8 90.8,33.2 153.7,96 	" /></g></svg>`
          }
        },

        ajax: (dataTablesParameters: any, callback) => {
          // this.valuestreamtemplateService.getValueStreamTemplate()
          //   .subscribe(resp => {
          //     this.valueStreamTemplateList = resp;
          //     var out = [];

          //     for (var i = 0; i < this.valueStreamTemplateList.length; i++) {
          //       out.push([
          //         this.valueStreamTemplateList[i].valueStreamTemplateID,
          //         this.valueStreamTemplateList[i].valueStreamTemplateName,
          //         this.valueStreamTemplateList[i].isLocked,
          //         this.valueStreamTemplateList[i].modifiedAt,
          //         this.valueStreamTemplateList[i].createdAt,
          //       ]);
          //     }

          //     setTimeout(function () {
          //       callback({
          //         data: out,
          //         recordsTotal: this.valueStreamTemplateList.length,
          //         recordsFiltered: this.valueStreamTemplateList.length
          //       });
          //     }, 50);
          //   });
        },

        scrollY: "200",
        scroller: {
          loadingIndicator: true
        },
      });
    }, 1000);


    this.plantName = environment.plantName;
    let userName = this.displayName;
    let userRole = this.role;
    let userPlantName = this.plantName;

    setTimeout(function(){
      if(userName != undefined && userName != null && userName !="")
      {
        document.getElementsByClassName('rb-core-profile-access__user-name')[0].innerHTML = userName;
        document.getElementsByClassName('rb-core-profile-access__user-name-button')[0].innerHTML = userName;
        document.getElementsByClassName('rb-core-profile-access__user-monogram')[0].innerHTML = userName.slice(0,1);
        document.getElementsByClassName('rb-core-profile-access__user-email')[0].innerHTML = userRole;
        document.getElementsByClassName('rb-core-profile-access__links-headline')[0].innerHTML = userPlantName;
      }
    },2000);

  }

  ngOnInit() {
    this.setLanguage();
    this.showQAwardPopupIfEnabled();
    $('body').click(function(e) {
        if ($(e.target).closest('.dropdown').length === 0) {
          $('.dropdown-content').css("background-color","#ddd").css("display","none");
        }
    });


    this.sharedService._selectedIcon.subscribe(res => {
      this.selectedIcon = res;
    });

    

    if(window.location.href.includes("customMode")){
      this.selectedIcon = "assets/image/user.png";
    }
    else if(window.location.href.includes("tagMode")){
      this.selectedIcon = "assets/image/wand.png";
    }
    else{
      this.selectedIcon = "assets/image/Material.svg";
    }
  }

  async setLanguage()
  {
    this.languageArr = environment.language.split(",").map(function(item) {
      return item.trim();
    });
    this.sharedService.plantLanguageCode = environment.defaultLanguage;
    await this.selectLanguage(this.sharedService.plantLanguageCode);
  }

  /** Method is responsible to move to first page of the pagination. */
  isFirstPage() {
    if (this.page == 1) {
      return;
    }
    else {
    }

    this.page = 1;
    this.startPage = (this.page - 1) * 4 + 1;
    this.endPage = this.page * this.resultPerPage;
  }

  /** Method is responsible to move to last page of the pagination. */
  isLastPage() {
    if (Math.ceil(this.UserPlantDetails.length / this.resultPerPage) <= this.page) {
      return;
    }
    else {

    }

    this.page = Math.ceil(this.UserPlantDetails.length / this.resultPerPage);
    this.startPage = (this.page - 1) * 4 + 1;
    this.endPage = this.page * this.resultPerPage;
  }

  /** Method is responsible to change page of the pagination. */
  pageChanged(event): void {

    if (event == 0) {
      return;
    }
    else if (Math.ceil(this.UserPlantDetails.length / this.resultPerPage) < event) {
      return;
    }
    else {
      this.page = event;
      this.startPage = (this.page - 1) * 4 + 1;
      this.endPage = this.page * this.resultPerPage;
    }
  }

  setFirstImage()
  {

  }

  async selectLanguage(language:any,onclcick?:boolean) {
    if(onclcick){
      this.sharedService.languageDropDownOnlclick=true;
     // alert(1)
    }else{
      //alert(2)
    }
    
    this.sharedService.selectedLanguage = language;
    this.selectedLanguage = language;
    await this.updateLanguage(language);

    var current = document.getElementsByClassName("rb-core-language-selector");
    if (current[0] != undefined) {
      current[0].className = current[0].className.replace("rb-core-language-selector--active", "");
    }
  }

  async updateLanguage(languageCode) {
    this.labels = await this.local_label.changeLanguage(languageCode);
  }

  showSideNav() {
    $('.dropdown-content').css("display", "block");
  }

  titleText: string;
  first()
  {
    $('.dropdown-content').css("background-color","#ddd").css("display","none");
    this.sharedService.setIcon("assets/image/Material.svg");
    this.sharedService.setIconName("Shuffle Mode");
    //this.selectedIcon = "../../../assets/image/Material.svg";
    //this.router.navigate([environment.home +'/shufflemode']);
    this.router.navigate([environment.home +'/processConfirmation']);
  }

  second()
  {
    $('.dropdown-content').css("background-color","#ddd").css("display","none");
    //this.selectedIcon = "../../../assets/image/user.png";
    this.sharedService.setIcon("assets/image/user.png");
    this.sharedService.setIconName("Custom Mode");
    this.router.navigate([environment.home +'/customMode']);
  }

  third()
  {    $('.dropdown-content').css("background-color","#ddd").css("display","none");
    //this.selectedIcon = "../../../assets/image/wand.png";
    this.sharedService.setIcon("assets/image/wand.png");
    this.sharedService.setIconName("Tag Mode");
    this.router.navigate([environment.home +'/tagMode']);
  }

  showQAwardPopupIfEnabled() {
    if (!this.sharedService.appSettings.QAwardPopup.Show)
      return;
    const additionalData: AdditionalData = JSON.parse(this.sharedService.sharedUserDetails.additionalData);
    if (additionalData && (additionalData.QAwardResponded == true || additionalData.QAwardResponded == false))
      return;
    this.modalRef = this.modalService.show(this.qAwardModal, this.qAwardConfig);
    $("modal-container").removeClass("fade");
    //$(".modal-dialog").addClass("modalSize");
  }
  RespondToQAward(vote: boolean) {
    this.modalRef.hide();
    let additionalData: AdditionalData = JSON.parse(this.sharedService.sharedUserDetails.additionalData);
    if (!additionalData) {
      additionalData = new AdditionalData();
    }
    additionalData.QAwardResponded = vote;
    const qAwardResponse: UserAdditionalData = {
      userNTID: this.sharedService.sharedUserDetails.ntid.toString(),
      additionalData: JSON.stringify(additionalData)
    };
    this.sharedService.SetUserAdditionalData(qAwardResponse).subscribe();
    if (vote && this.sharedService.appSettings.QAwardPopup.VotingUrl)
      window.open(this.sharedService.appSettings.QAwardPopup.VotingUrl, "_blank");
  }
}
export class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}

