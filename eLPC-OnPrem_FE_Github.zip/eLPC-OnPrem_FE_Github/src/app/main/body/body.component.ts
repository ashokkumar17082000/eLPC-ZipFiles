import { Component, OnInit, HostListener } from '@angular/core';
import { SharedService } from '../../service/shared.service';
import { LanguageService } from 'src/app/language.service';
import { CommonService } from 'src/app/service/common/common.service';
import * as $ from 'jquery';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-body',
  templateUrl: './body.component.html',
  styleUrls: ['./body.component.css']
})
export class BodyComponent implements OnInit {

  applicationVersion: any;
  labels: any;
  _subscription: any;
  @HostListener('window:resize') onResize() {
    // guard against resize before view is rendered
    if($( window ).width() > 768){
      if(this.commonService.isCollapsedLeftNav){
        this.commonService.toggleMenuLeftNav("");
      }
      
    }
    else{
      
    }
  }
  constructor(private sharedService: SharedService, private local_label: LanguageService, private commonService: CommonService) { 
    
  }

  ngOnInit() {
    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
    });
    this.applicationVersion =environment.applicationVersion;
  }
}
