import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import { CommonService } from 'src/app/service/common/common.service';
import { SharedService } from 'src/app/service/shared.service';
import { environment } from 'src/environments/environment';
import {LanguageService} from '../../../language.service';

@Component({
  selector: 'app-leftnav',
  templateUrl: './leftnav.component.html',
  styleUrls: ['./leftnav.component.css']
})
export class LeftnavComponent implements OnInit{
  toggleiconname: string = "fa fa-times";
  isCollapsedLeftNav = false;
  hideMenuName :boolean;
  role:string;
  labels:any;
  _subscription: any;
  showMenuTitle: boolean;
  isDesktop: boolean = true;
  collapsedNav: any;
  urlSrc: any;
  superOPLList :any =  environment.superopl != undefined ?  Object.values(JSON.parse(environment.superopl)) : [];;

  constructor( private commonService: CommonService, private sharedService: SharedService, private local_label:LanguageService) {
    this.hideMenuName = this.commonService.hideMenuName
    this.role = this.sharedService.role;
    this.labels = local_label.localizeLanguage;
    this._subscription = local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
    });

    this.sharedService._selectedRoleName.subscribe(res => {
      this.role = res;
    });

    this.isDesktop = true;
  }
  ngOnInit() {
    let _this = this;
    if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
      this.isDesktop = false;
    }

    $(window).on("orientationchange", function (event) {
      $('#sidebar').css("display", "none");
      _this.isCollapsedLeftNav = true;
    });



    $('.dropdown-menu').click(function(e) {
      e.stopPropagation();
    });

    if($( window ).width() < 768){
      this.showMenuTitle = true;
    }

    else{
      this.showMenuTitle = true;
    }

  }

  toggleMenuLeftNav(from)
  {
    //this.linkToSopl();
    this.commonService.toggleMenuLeftNav(from);
    this.isCollapsedLeftNav = this.commonService.isCollapsedLeftNav;
    this.toggleiconname = this.commonService.toggleiconname;
    this.hideMenuName = this.commonService.hideMenuName;
  }
  linkToSopl(){
    this.superOPLList =  environment.superopl != undefined ?  Object.values(JSON.parse(environment.superopl)) : [];
    this.urlSrc = environment.superOPLPortalURL + this.superOPLList[0].oplID;
    window.open(this.urlSrc, "_blank");
  }

 linkTonewPage(){
  //this.superOPLList =  environment.superopl != undefined ?  Object.values(JSON.parse(environment.superopl)) : [];
  this.urlSrc = "https://connect.bosch.com/blogs/f5da04e3-5797-4a8d-ab1b-6a78f6c11727/entry/Update_new_version_3_3_release?lang=en_us";
  window.open(this.urlSrc, "_blank");
}

}
