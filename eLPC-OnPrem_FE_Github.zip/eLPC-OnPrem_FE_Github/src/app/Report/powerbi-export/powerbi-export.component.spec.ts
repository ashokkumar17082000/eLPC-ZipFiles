import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PowerBIExportComponent } from './powerbi-export.component';


describe('PowerbiExportComponent', () => {
  let component: PowerBIExportComponent;
  let fixture: ComponentFixture<PowerBIExportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PowerBIExportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PowerBIExportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
