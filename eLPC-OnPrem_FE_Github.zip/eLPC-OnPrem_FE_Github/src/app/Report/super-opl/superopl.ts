export class SuperOPL_CreateTask {
   owner:string;
   type: number;
   subject:string;
   description:string;
   taskStart:string; //'YYYY-MM-DD'
   endDate:string; //'YYYY-MM-DD'
   responsible:string;
   informationTo: string[];
   source:string;
   category:string;
   prio:string;
   parentTaskId:number;
   tags: string[];

}

export class SuperOPL_UpdateTask {
  subject?: string;
  description?: string;
  responsible?: string;
  dueDate?:string;
  loginUser?: string;
}

export class SuperOPL_GetAll {
  taskId?: string;
  opl?: number;
  owner?: string;
  description?: string;
  startDate?: Date;
  endDateWill?: Date;
  endDateIs?: boolean;
  endDateActual?: Date;
  responsible?: string;
  responsibleExternal?: string;
  subject?: string;
  type?: number;
  result?:string;
  source?:string;
  status?: number;
  parent?: number;
  category?: string;
  isNote?: number;
  lastChangeTime?: Date;
  lastChangeLogin?:string;
  prio?: string;
  fromMeeting?: Date;
  topTask?: number;
  taskStart?: Date;
  isConfidential?: number;
  endDateSuggested?: Date;
  flow?: number;
  dateChanges?:Date;
  ownerFistName?: string;
  ownerLastName?: string;
  ownerDepartment?: string;
  responsibleFistName?: string;
  responsibleLastName?: string;
  responsibleDepartment?: string;
  lastChangeLoginFistName?: string;
  lastChangeLoginLastName?: string;
  lastChangeLoginDepartment?: string;
}
