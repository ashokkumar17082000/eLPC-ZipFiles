import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { SharedService } from 'src/app/service/shared.service';
import { SuperOPL_CreateTask, SuperOPL_GetAll, SuperOPL_UpdateTask} from '../super-opl/superopl';
import { ActivatedRoute, Router } from "@angular/router";
import { SuperOPLService } from 'src/app/service/superopl.service';
import { LanguageService } from 'src/app/language.service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { environment } from 'src/environments/environment';
import { AssessorTemplateService } from 'src/app/service/assessor/assessortemplate.service';
import { ValuestreamTemplateService } from 'src/app/service/common/valuestreamtemplate.service';
import { FormGroup, FormControl } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { DomSanitizer } from '@angular/platform-browser';
declare var $;

@Component({
  selector: 'app-super-opl',
  templateUrl: './super-opl.component.html',
  styleUrls: ['./super-opl.component.css']
})

export class SuperOPLComponent implements OnInit {
  dateTimeFormat = environment.dateTimeFormat;
  @ViewChild('alertPopup') lockModal : TemplateRef<any>;

  bsModalRef: BsModalRef;
  modalRef: BsModalRef;
  @ViewChild('modalContent', { }) modalContent: TemplateRef<any>;

  config = {
    animated: false,
    keyboard: true,
    ignoreBackdropClick: true
  };

  selectedTask: any;
  superoplTaskList: any = [];
  totalList: any;
  dataTable: any;
  assigned_OPLID?: number;

  public data = [];
  public settings = {};
  public form: FormGroup;
  public loadContent: boolean = false;

  page: number = 1;
  resultPerPage: number = 10;
  startPage: number;
  endPage: number;

  superOPLList :any =  environment.superopl != undefined ?  Object.values(JSON.parse(environment.superopl)) : [];


  labels: any;
  _subscription: any;
  str1: any;


  iframe : any;
  urlSrc :any;


  constructor(private sanitizer: DomSanitizer, private local_label: LanguageService, private superOPLService: SuperOPLService, private router:Router, private sharedService: SharedService,
    private modalService: BsModalService,private assessorTemplateService: AssessorTemplateService,private valuestreamService:ValuestreamTemplateService,
    private route: ActivatedRoute, private datePipe: DatePipe) {
      this.urlSrc = environment.superOPLPortalURL + this.superOPLList[0].oplID;
      //this.iframe = sanitizer.bypassSecurityTrustResourceUrl(this.urlSrc);

     // window.open(this.urlSrc, "_blank");
      //this.router.navigate([environment.home +'./dashboard']);


    }

  ngOnInit() {
    // if(this.sharedService.role !=="Designer")
    // {
    //   this.router.navigate([environment.home +'/accessdenied']);
    // }
  }
}
