//import { Component, OnInit } from '@angular/core';
import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { Assessor, AssessorStreamHistory, AssessorTemplate } from 'src/app/Assessor/assessor/assessortemplate';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { environment } from 'src/environments/environment';
import { LanguageService } from 'src/app/language.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AssessorTemplateService } from 'src/app/service/assessor/assessortemplate.service';
import { SharedService } from 'src/app/service/shared.service';
import { reportText, reportrestore, reports } from 'src/app/Report/launch-pad-c/launchpadsetting';
import { LaunchpadsettingService } from 'src/app/service/launchpadsetting.service';



@Component({
  selector: 'app-launch-pad-c',
  templateUrl:'./launch-pad-c.component.html',
  styleUrls:['./launch-pad-c.component.css']
})
export class LaunchPadCComponent implements OnInit {

  @ViewChild('fileInput') fileInput;
  @ViewChild('alertPopup') warningModal : TemplateRef<any>;
  @ViewChild('successPopup') successModal : TemplateRef<any>;
  isDisabled:boolean=true;
  alertText: string;
  apiUrl: any;
  assessorTemplateList: AssessorTemplate[] = [];
 
  assessorTemplate: AssessorTemplate = new AssessorTemplate();
  reportText: reportText = new reportText();
  reportTextList: reportText[] = [];
  reports: reports[] = [];
  isAdd: boolean = false;
  isEdit: boolean = false;
  isTargetFrequencyDefined: boolean = false;
  assessors: Assessor[] = [];
reportrestore:Assessor[]=[];
  assessor: Assessor;
  dataTable: any;
  modalRef: BsModalRef | null;
  assessorStreamHistoryDetails: AssessorStreamHistory[];
  assessorTemplateHistoryID: number;
  templateId: number;
  dateTimeFormat = environment.dateTimeFormat;

  filterPopUp:any;

  config = {
    animated: false,
    keyboard: true,
    ignoreBackdropClick: true
  };


  constructor(private local_label: LanguageService ,route: ActivatedRoute, private modalService: BsModalService, private launchpadsettingService: LaunchpadsettingService, private sharedService: SharedService, private router: Router) {
    
    if (this.assessorTemplate == undefined) {
      this.isAdd = true;
      this.isEdit = false;
      this.assessorTemplate = new AssessorTemplate();
    }
    else if (Object.keys(this.assessorTemplate).length == 0) {
      this.isAdd = true;
      this.isEdit = false;
      this.assessorTemplate = new AssessorTemplate();
    }
    else {
      this.isAdd = false;
      this.isEdit = true;
    }

    if (this.isEdit) {
      this.templateId = this.assessorTemplate.assessorTemplateID;
      //this.editAsessor(this.assessorTemplate);
    }

  }

  labels: any;
  _subscription: any;


  ngOnInit() {
    // if(this.sharedService.role !=="Designer")
    // {
    //   this.router.navigate([environment.home +'/accessdenied']);
    // }

    this.getLaunchpadSettingList();
    this.sharedService.hide();



    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
    });
    

    this.assessors = [{ assessorName: "",category: "", targetFrequencyLowLimit: "", targetFrequencyValue: undefined }];
   
    if(this.isAdd){
    this.assessorTemplate.isTargetFrequencyDefined = false;
    }
  }



  redirect() {
    this.isEdit = false;
    this.isAdd = false;
    this.assessorTemplate = new AssessorTemplate();
    this.assessors = [{ assessorName: "",category: "", targetFrequencyLowLimit: "", targetFrequencyValue: undefined }];
    this.router.navigate([environment.home +'/assessors']);
  }
    //to fix scroll issue after pop up
    public closeAlertModal(){
      if(document.getElementsByTagName("modal-container").length > 1){
        document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length-1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length-1]);
      }
      else{
        document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
        if(document.getElementsByTagName("bs-modal-backdrop").length > 0){
          document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
        }
        document.querySelector('body').classList.remove('modal-open');
      }
      
    }

    goToLink(url: string) {
      console.log("132",url)
      if (url.toLocaleLowerCase().includes('https://') || url.toLocaleLowerCase().includes('http://')) {
        window.open(url, "_blank");
      }
      else {
        window.open('//' + url, "_blank");
      }
    }
  public getLaunchpadSettingList() {
    this.launchpadsettingService.getLaunchpadSetting().subscribe(res => {
      this.reportTextList = res;   
      console.log("135",this.reportTextList)
      this.addAssessorRow(this.reportTextList.length -1);
    },
      err => {
        console.log(err);
      }
    );
  }

  editAsessor(assessorTemplate: any) {
      this.isAdd = false;
      this.isEdit = true;
      this.assessors = [];
      this.assessorTemplate = Object.assign(new AssessorTemplate(), assessorTemplate);

      // this.assessorTemplateService.getAssessorsByTemplateID(this.assessorTemplate.assessorTemplateID).subscribe(
      //   res => {
      //     this.assessors = res;
      //     this.addAssessorRow(this.assessors.length -1);
      //   },
      //   err => {
      //     console.log(err);
      //   }
      // );
    

  }

  showModal()
  {
    document.getElementById('deleteModal').style.display = "block";
  }

  closeModal()
  {
    document.getElementById('deleteModal').style.display = "none"; 
    document.querySelector('body').classList.remove('-is-modal');
  }

  deleteTemplate()
  {
    this.closeModal();
    this.delete(this.assessorTemplate);
  }

  delete(assessorTemplate: any) {
    if(this.sharedService.ntid){
      this.assessorTemplate.modifiedBy_NTID = this.sharedService.ntid;
      var d = new Date();
      this.assessorTemplate.modifiedAt = new Date(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate(),d.getHours(),d.getMinutes(),d.getSeconds()));
    }
    // this.assessorTemplateService.deleteAssessorTemplate(this.assessorTemplate).subscribe(
    //   res => {
    //     if (res.resultCode == 0) {

    //       this.getAssessorTemplateList();
    //       this.alertText = this.labels.default.deleteSuccessfully;
    //       this.modalService.show(this.successModal);
    //       $("modal-container").removeClass("fade");
    //       $(".modal-dialog").addClass("modalSize");
          
    //       this.assessors = [];
    //       this.isAdd = false;
    //       this.isEdit = false;
    //       this.router.navigate([environment.home +'/assessors']);
    //     }
    //     else if(res.resultCode == 1){
    //       this.alertText = this.labels.default.assessorLinked;
    //       this.modalService.show(this.warningModal);
    //       $("modal-container").removeClass("fade");
    //       $(".modal-dialog").addClass("modalSize");
    //     }
    //     else {
    //       this.alertText = this.labels.default.failedDeleteAssessor;
    //       this.modalService.show(this.warningModal);
    //       $("modal-container").removeClass("fade");
    //       $(".modal-dialog").addClass("modalSize");
    //     }
    //   },
    //   err => {
    //     console.log(err);
    //   });
  }

  assessorObj: AssessorTemplate = new AssessorTemplate();
  onSubmit(assessorTemplate: any) {
    this.isDisabled=false;
    let error= false;
    if(this.assessors.length == 1){
      this.alertText = this.labels.default.assessorPopUpWarning;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      this.isDisabled=true;
      return;
    }
    if(assessorTemplate.isTargetFrequencyDefined){
      
      this.assessors.forEach((item, index) => {
        if(index != this.assessors.length-1){
          if(item.assessorName == undefined || item.assessorName == ''  ||  item.targetFrequencyTypeID == undefined || item.targetFrequencyValue == undefined){
            error = true;
          }
        }
        
      });
    }
    else{
      this.assessors.forEach((item, index) => {
        if(index != this.assessors.length-1){
          if(item.assessorName == undefined || item.assessorName == '' ){
            error = true;
          }
        }
      });
    }
    if (error) {
      this.alertText = this.labels.default.assessorEnterAllFields;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
     this.isDisabled=true;

      return;
    }
    if (assessorTemplate.isTargetFrequencyDefined) {
      this.assessorTemplate.assessors = this.assessors.filter(x => x.assessorName != undefined && x.targetFrequencyTypeID != undefined && x.targetFrequencyValue != undefined);
    }
    assessorTemplate.modifiedAt = new Date();
    if (this.isEdit) {
      if (this.assessorObj = this.assessorTemplateList.filter(x => x.assessorTemplateID == assessorTemplate.assessorTemplateID)[0]) {
        let existingObj = this.assessorTemplateList.filter(x => x.assessorTemplateName == assessorTemplate.assessorTemplateName)[0];
        if (existingObj != undefined && existingObj.assessorTemplateID !== this.assessorObj.assessorTemplateID) {
          this.alertText = this.labels.default.assessorAlreadyExists;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          this.isDisabled=true;

          return;
        }
      }
    }
    if (this.isAdd) {
      assessorTemplate.createdAt = new Date();
      if (this.assessorTemplateList != null && this.assessorTemplateList.filter(x => x.assessorTemplateName == assessorTemplate.assessorTemplateName)[0]) {
        this.alertText = this.labels.default.assessorNameExists;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          this.isDisabled=true;

        return;
      }
    }
    this.assessorTemplate = assessorTemplate;
    this.assessorTemplate.assessors = this.assessors.filter(x => x.assessorName != undefined,y => y.category != undefined );
    if(this.isAdd){
      this.assessorTemplate.createdBy_NTID = this.sharedService.ntid;
      this.assessorTemplate.modifiedBy_NTID = this.sharedService.ntid;
      this.assessorTemplate.isLocked = false;
    }
    if(this.isEdit){
      this.assessorTemplate.modifiedBy_NTID = this.sharedService.ntid;
    }

    for(let asr of this.assessors){
      if(asr.assessorName){
        let asrCount = this.assessors.filter(x =>x.assessorName == asr.assessorName).length;
        if(asrCount && asrCount >1){
          this.alertText = this.labels.default.assessorExists;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          this.isDisabled=true;
          return;
        }
      }
    }

          // this.assessorTemplateService.insertAssessorTemplate(this.assessorTemplate).subscribe(
          //   res => {

          //     if (res.resultCode == 0) {
      
          //       //this.getAssessorTemplateList();
          //       this.alertText = this.labels.default.saveSuccessfully;
          //       this.modalService.show(this.successModal);
          //       $("modal-container").removeClass("fade");
          //       $(".modal-dialog").addClass("modalSize");
          //       this.assessors = [];
          //       this.isAdd = false;
          //       this.isEdit = false;
          //       this.router.navigate([environment.home +'/assessors'])
          //     }
          //     else {
          //       this.alertText = this.labels.default.failedAssessor;
          //       this.modalService.show(this.warningModal);
          //       $("modal-container").removeClass("fade");
          //       $(".modal-dialog").addClass("modalSize");
          //    this.isDisabled=false;

          //     }
      
          //   },
          //   err => {
          //     console.log(err);
          //   });

  }

  onSubmitlaunchpad(reportText :any)
  {
    console.log ("Enter" , reportText);

    reportText.createdAt = new Date();


    this.assessors.forEach((item, index) => {
      if(index != this.assessors.length-1){
        if(item.assessorName == undefined || item.assessorName == ''  ||  item.targetFrequencyTypeID == undefined || item.targetFrequencyValue == undefined){
    
          reportText.reportText=item.assessorName;
          reportText.reportTextURL=item.category;
        }
      }

      this.reportText.reports = this.assessors.filter(x => x.assessorName != undefined,y => y.category != undefined );

      console.log ("Enter" , reportText);
    });

    console.log ("Enter" , reportText);

    this.launchpadsettingService.insertLaunchpadURL(this.reportText).subscribe(
      res => {

        if (res.resultCode == 0) {

         // this.getAssessorTemplateList();
          this.alertText = this.labels.default.saveSuccessfully;
          // this.modalService.show(this.successModal);
          // $("modal-container").removeClass("fade");
          // $(".modal-dialog").addClass("modalSize");
          this.assessors = [];
          this.isAdd = false;
          this.isEdit = false;
          this.router.navigate([environment.home +'/assessors'])
        }
        else {
          this.alertText = this.labels.default.failedAssessor;
          // this.modalService.show(this.warningModal);
          // $("modal-container").removeClass("fade");
          // $(".modal-dialog").addClass("modalSize");
       this.isDisabled=false;

        }

      },
      err => {
        console.log(err);
      });


  }

  letterOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;

    if ((charCode <= 93 && charCode >= 65) || (charCode <= 122 && charCode >= 97)) {
      return true;
    }
    return false;;


  }


  columnsData: Array<any> = [{ assessorCategoryName: 'Assessor', inputType: 'text', isDataRequiredToFitSpecLength: false, minimumNoOfCharacters: 1, maximumNoOfCharacters: 3, isDataRequired: true }]

  order: string = "displayName";
  reverse: boolean = false;
  setOrder(value: string) {
    if (this.order === value) {
      this.reverse = !this.reverse;
    }

    this.order = value
                  }

  idvalue = 0;
  myvalue = "";
  rows: any[] = [{

  }];
  // ************************************************
  //This function is called on keyup and checks the checkbox on that row and adds new row if the action was on the last row  
  checkAndAddRow(i) {
    this.idvalue++;
    this.myvalue = "first";

    if (this.rows.length - 1 == i) {//insert new empty row, incase this keyup event was on the last row, you might want to enhance this logic... 
      this.rows.push({
        key: '',
      })

    }
  }

  addAssessorRow(i) {
    if (this.assessors.length - 1 == i) {
      this.assessor = new Assessor();
      this.assessors.push(this.assessor);
    }
  }


  removeAssessor(index: number) {
    if (!this.assessors || this.assessors.length <= 1)
      return;
    this.assessors.splice(index, 1);
  }

  closeAlert()
  {
    if(document.getElementsByTagName("modal-container").length > 1){
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length-1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length-1]);
    }
    else{
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if(document.getElementsByTagName("bs-modal-backdrop").length > 0){
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }
  }

  public openAlertModal(popUp:any) {
    this.filterPopUp = popUp;
  }

}
