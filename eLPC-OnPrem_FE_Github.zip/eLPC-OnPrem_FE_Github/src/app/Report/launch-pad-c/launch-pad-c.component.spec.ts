import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LaunchPadCComponent } from './launch-pad-c.component';

describe('LaunchPadComponent', () => {
  let component: LaunchPadCComponent;
  let fixture: ComponentFixture<LaunchPadCComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LaunchPadCComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LaunchPadCComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
