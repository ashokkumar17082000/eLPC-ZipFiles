import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LaunchPadSettingsCComponent } from './launch-pad-settings-c.component'; 

describe(' LaunchPadSettingsCComponent', () => {
  let component:  LaunchPadSettingsCComponent;
  let fixture: ComponentFixture< LaunchPadSettingsCComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [  LaunchPadSettingsCComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent( LaunchPadSettingsCComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
