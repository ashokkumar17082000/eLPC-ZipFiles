import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminreportComponent } from './adminreport/adminreport.component';
import { PowerBIExportComponent } from './powerbi-export/powerbi-export.component';
import { SuperOPLComponent } from './super-opl/super-opl.component';
const routes: Routes = [
  { path: '', component: AdminreportComponent },
  { path: 'powerBIExport', component: PowerBIExportComponent },
  { path: 'superOPL', component: SuperOPLComponent }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportRoutingModule { }
