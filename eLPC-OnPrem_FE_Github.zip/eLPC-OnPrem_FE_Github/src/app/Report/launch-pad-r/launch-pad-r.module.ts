import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { NgxPaginationModule } from 'ngx-pagination';
import { FormsModule,ReactiveFormsModule  } from '@angular/forms';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { SharedModule } from 'src/app/shared/shared.module'
import { ModalModule } from 'ngx-bootstrap/modal';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { LaunchPadRRoutingModule } from './launch-pad-r-routing.module';
import { LaunchPadCComponent } from '../launch-pad-c/launch-pad-c.component';
import { LaunchPadSettingsCComponent } from '../launch-pad-c/launch-pad-settings-c.component';



@NgModule({
  declarations: [LaunchPadCComponent,
    LaunchPadSettingsCComponent],
  imports: [
    CommonModule,
    LaunchPadRRoutingModule,
    NgxPaginationModule,
    PaginationModule.forRoot(),
    ReactiveFormsModule,
    FormsModule,
    SharedModule,
    ModalModule.forRoot(),
    TooltipModule.forRoot(),
    NgMultiSelectDropDownModule.forRoot(),
    PaginationModule.forRoot(),
  ],
  exports: [LaunchPadCComponent,LaunchPadSettingsCComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]

})
export class LaunchPadRModule { }
