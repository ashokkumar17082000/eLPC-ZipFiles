import { TestBed } from '@angular/core/testing';

import { DeviationService } from './deviation.service';
import { HttpClientModule } from '@angular/common/http';

describe('DeviationService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientModule,]
  }));

  it('should be created', () => {
    const service: DeviationService = TestBed.get(DeviationService);
    expect(service).toBeTruthy();
  });
});
