import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { SharedService } from './shared.service';

@Injectable({
  providedIn: 'root'
})

export class infoAndHelpService{
  getUsers() {
    throw new Error('Method not implemented.');
  }

  private headers: HttpHeaders;
  apiURL: string;

  constructor(private http: HttpClient, private sharedService: SharedService) {
    this.headers = new HttpHeaders();
    this.headers.append("Content-Type", "application/json");
    this.headers.append("Access-Control-Allow-Methods", "GET, POST, DELETE, PUT");
    this.headers.append("'Access-Control-Allow-Origin", "*");
    this.apiURL = this.sharedService.apiURL;
  }



}
