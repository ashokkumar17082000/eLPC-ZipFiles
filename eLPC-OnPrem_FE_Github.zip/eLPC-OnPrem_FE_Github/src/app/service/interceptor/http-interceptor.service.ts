import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpEvent, HttpHandler } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SharedService } from '../shared.service';
import { Plant } from 'src/app/main/body/shared/common';

@Injectable({
  providedIn: 'root'
})
export class HttpInterceptorService implements HttpInterceptor  {

  plant: any;
  currentUserInfo: any;

  constructor(private sharedService: SharedService)
  {

  }

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {

    if (this.sharedService.plantID > 0) {
      this.plant = this.sharedService.plantID.toString();

      let currentPlantInfo = new Plant();
      if(this.sharedService.currentUserInfo != null)
      {
        currentPlantInfo.plantID = this.sharedService.currentUserInfo.plantID;
        currentPlantInfo.plantCode = this.sharedService.currentUserInfo.plantCode;
        currentPlantInfo.idMStandardRole = this.sharedService.currentUserInfo.idMStandardRole;
        currentPlantInfo.idMDesignerRole = this.sharedService.currentUserInfo.idMDesignerRole;
        currentPlantInfo.currentRole = this.sharedService.currentUserInfo.currentRole;
      }
      this.currentUserInfo = JSON.stringify(currentPlantInfo);
    }
    else {
      this.plant = "0";
      this.currentUserInfo ="";
    }

    const modified = req.clone({
      setHeaders: { "Plant": this.plant, "CurrentUserInfo": this.currentUserInfo }
    });
    ////debugger;
    return next.handle(modified);
  }

}
