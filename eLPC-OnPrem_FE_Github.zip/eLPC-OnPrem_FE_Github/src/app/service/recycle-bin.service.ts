import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { ValueStreamTemplate } from 'src/app/Valuestream/valuestreams/valuestreamtemplate';
import { SharedService } from './shared.service';
import { RecycleBinTemplate } from 'src/app/RecycleBin/recycle-bin/recyclebintemplate';

@Injectable({
  providedIn: 'root'
})
export class RecycleBinService {

  private headers: HttpHeaders;
  apiURL: string;
  valueStreamTemplate: ValueStreamTemplate = new ValueStreamTemplate();

  constructor(private http: HttpClient, private sharedService: SharedService) {
    this.headers = new HttpHeaders();
    this.headers.append("Content-Type", "application/json");
    this.headers.append("Access-Control-Allow-Methods", "GET, POST, DELETE, PUT");
    this.headers.append("'Access-Control-Allow-Origin", "*");
    this.apiURL = this.sharedService.apiURL;
  }

  public getRecycBinTemplate() {
    return this.http.get<RecycleBinTemplate[]>(this.apiURL + "ValueStreamTemplate/GetRecycleBinTemplates", { headers: this.headers, withCredentials: true });
   }
   public recyclebinHistory() {
    return this.http.get(this.apiURL + "ValueStreamTemplate/RecycleBinHistory",  {withCredentials: true} );
  }
  public restoreTemplate(recyclebin: RecycleBinTemplate[]) {
    return this.http.post(this.apiURL + "ValueStreamTemplate/RestoreRecycleBin", recyclebin, {withCredentials: true} );
  }

  public deleteTemplate(recyclebin: RecycleBinTemplate[]) {
    return this.http.post(this.apiURL + "ValueStreamTemplate/DeleteRecycleBin", recyclebin, {withCredentials: true} );
  }
}
