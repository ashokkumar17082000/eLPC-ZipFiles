import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot, CanActivateChild } from '@angular/router';
import { User } from '../main/body/shared/common';
import { SharedService } from './shared.service';
import { CommonService } from './common/common.service';
import { HttpHeaders } from '@angular/common/http';

@Injectable({
    providedIn: 'root',
  })
  
export class CanActivateGuard implements CanActivate,CanActivateChild {
  private isValidUser: boolean = false;
  private user: User;
  private role: string;
  private headers: HttpHeaders;
  pathName :any ;
  constructor(
    private commonService: CommonService,
    private router: Router, private sharedService:SharedService
  ) {

    this.headers = new HttpHeaders();
    this.headers.append("Content-Type", "application/json");
  }

  canActivateChild(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): any {
    return this.canActivate(next, state);
  }
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): any {
    // return this.sharedService.CheckApplicationAccess().map(res => {
    this.pathName = location.pathname;

    if (!this.sharedService.role && (sessionStorage.getItem("ntid") != null && sessionStorage.getItem("ntid") !="")) {
      this.sharedService.role = sessionStorage.getItem("role");
      this.sharedService.ntid = sessionStorage.getItem("ntid");
      this.sharedService.displayName = sessionStorage.getItem("displayName");
      this.sharedService.emailAddress = sessionStorage.getItem("emailAddress");
      this.sharedService.ADdisplayName = sessionStorage.getItem("ADdisplayName");
      this.sharedService.plantID = parseInt( sessionStorage.getItem("plantID"));
      //this.sharedService.apiURL= sessionStorage.getItem("apiURL");
    }
    
    return this.checkLogin();
  }


  checkLogin()
  {
      if(this.sharedService.apiURL == "") 
      {
        var NTID = this.sharedService.ntid ;

        if(NTID == null || NTID == undefined || NTID == "" )
        {
          NTID = localStorage.getItem('ntid');
        } 
        this.sharedService.GetEnironmentConfigFromDBAndLogin(NTID, this.router, this.pathName);
      }
      else if(this.sharedService != null && this.sharedService.role != null)
      {
        if (this.sharedService.role == "Standard") {
          return true;
        }
        else if (this.sharedService.role == "Designer") {
          return true;
        }
        else
        {
          var NTID = this.sharedService.ntid ;

          if(NTID == null || NTID == undefined || NTID == "" )
          {
            NTID = localStorage.getItem('ntid');
          } 
          this.sharedService.GetEnironmentConfigFromDBAndLogin(NTID, this.router, this.pathName);
        }
      }
      else
      {
        if(window.location.pathname =="/" || window.location.pathname.includes("appinfo"))
        {
          return true;
        }
        else
        {
          return false;
        }
      }
  }
}
