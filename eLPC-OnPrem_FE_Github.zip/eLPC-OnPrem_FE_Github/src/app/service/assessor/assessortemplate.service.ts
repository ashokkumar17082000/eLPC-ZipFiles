/// <reference path="../shared.service.ts" />
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';  
import 'rxjs/add/operator/map';
import { HttpHeaders } from '@angular/common/http'; 
import { SharedService } from '../shared.service';
import { AssessorTemplate, Assessor, AssessorProxy, AssessorStreamHistory } from 'src/app/Assessor/assessor/assessortemplate';

@Injectable({
  providedIn: 'root',
})

export class AssessorTemplateService {

  private headers: HttpHeaders;
  apiURL: string;
  assessorTemplate: AssessorTemplate = new AssessorTemplate();

  private httpHeaders = new HttpHeaders().set('Content-Type', 'application/json').
                        set('Accept', 'application/json');

  optionsStatic = {
  headers: this.httpHeaders,
  params: new HttpParams(),
  withCredentials: true
  };

  constructor(private http: HttpClient, private sharedService: SharedService) {
    this.headers = new HttpHeaders();
    //this.headers.append("Content-Type", "application/json");
    this.headers.append("Access-Control-Allow-Methods", "GET, POST, DELETE, PATCH, PUT, OPTIONS");
    this.headers.append("Access-Control-Allow-Origin", "*");
    this.headers.append("Access-Control-Allow-Credentials", "true");
    this.apiURL = this.sharedService.apiURL;
  }

  public getAssessorTemplates() {

    return this.http.get<AssessorTemplate[]>(this.sharedService.apiURL + "AssessorTemplate/GetAssessorTemplates", { headers: this.headers , withCredentials: true });
  }
  public validateAssessorTemplateName(name:string) {

    return this.http.get<AssessorTemplate[]>(this.sharedService.apiURL + "AssessorTemplate/ValidateAssessorTemplateName"+ '/' + name, {withCredentials: true});
  }

  public getAssessors() {

    return this.http.get<Assessor[]>(this.apiURL + "AssessorTemplate/GetAssessors", {});
  }

  public getAssessorStreamTemplateHistory(templateID: number) {
    return this.http.get<AssessorStreamHistory[]>(this.apiURL + "AssessorTemplate/GetAssessorTemplatesHistory"+ '/' + templateID, { headers: this.headers, withCredentials: true });
   }

  public getAssessorsByTemplateID(templateID: number) {

    return this.http.get<Assessor[]>(this.apiURL + "AssessorTemplate/GetAssessorsByTemplateID" + '/' + templateID, {withCredentials: true});
  }
  
  public fetchAssessorTemplateByTemplateID(templateID: number) {
    return this.http.get<AssessorTemplate[]>(this.apiURL + "AssessorTemplate/FetchAssessorTemplateByTemplateID" + '/' + templateID, {withCredentials: true});
  }

  public assessorsRestoreByTemplateHistoryID(historyID: number) {
    return this.http.get(this.apiURL + "AssessorTemplate/AssessorsRestoreByTemplateHistoryID" + '/' + historyID, {withCredentials: true});
  }

  public insertAssessorTemplate(assessorTemplate: AssessorTemplate) {
    return this.http.post<AssessorTemplate>(this.apiURL + "AssessorTemplate/InsertAssessorTemplate", assessorTemplate, {withCredentials: true} );
  }

  public insertAssessorProxy(assessorProxy: AssessorProxy) {
    return this.http.post<AssessorProxy>(this.apiURL + "AssessorTemplate/InsertAssessorProxy", assessorProxy, {withCredentials: true});
  }


  // ****Import*****
  // ImportExcel(formData: FormData) {
    AssessorImportExcel(formData: FormData) {
      let headers = new HttpHeaders();
  
      headers.append('Content-Type', 'multipart/form-data');
      headers.append('Accept', 'application/json');
  
      const httpOptions = { headers: headers };
      return this.http.post(this.apiURL + 'AssessorTemplate/AssessorImportExcel', formData, httpOptions)
      
    }
    // ****end**
  
    // ***export****
    AssessorExportExcel() {
      return this.http.get(this.apiURL + 'AssessorTemplate/AssessorExportExcel', {withCredentials: true});
    }
    
    // ****end*****
  public deleteAssessorTemplate(assessorTemplate: AssessorTemplate) {
    return this.http.post<AssessorTemplate>(this.apiURL + "AssessorTemplate/DeleteAssessorTemplate", assessorTemplate, {withCredentials: true});

  }

  public assessorProxiesByAssessorTemplateID(assessorTemplateID: number) {
    return this.http.get(this.apiURL + "AssessorTemplate/AssessorProxiesByAssessorTemplateID" + '/' + assessorTemplateID, { withCredentials: true });
  }

}
