import { Injectable } from "@angular/core";
import { HttpClient } from '@angular/common/http';
import { Observable, Subscriber } from 'rxjs';  
import 'rxjs/add/operator/map';
import { HttpHeaders } from '@angular/common/http'; 
import { ChoiceDisplayType, AnswerType, User, Result } from '../../main/body/shared/common';
import { SharedService } from '../shared.service';
import { SuperOPLService } from '../superopl.service';
import { environment } from 'src/environments/environment';
import { Deviation, HintImage } from "src/app/Deviation/deviation/deviation";
import { DatePipe } from '@angular/common';
import $ from 'jquery';
import { LanguageService } from "src/app/language.service";

@Injectable({
    providedIn: 'root',
})

export class CommonService{
  apiURL: string;
  user: User;
  toggleiconname: string = "fa fa-times";
  isCollapsedLeftNav = false;
  hideMenuName = false;
  width = $( window ).width() < 768;
  labels: any;
  _subscription: any;
  value: any;
  labe: any;

  
  constructor(private http: HttpClient, private local_label: LanguageService,
    private sharedService: SharedService) {
    if($( window ).width() < 768){
      this.isCollapsedLeftNav = true;
    }
    else{
      this.isCollapsedLeftNav = false;
    }

    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe(value => {
      this.labels = value;
      this.value = this.labels.default.tipValue;
      this.apiURL = this.sharedService.apiURL;
    });
  }

    public getChoiceDisplayTypes(){
      return  this.http.get<ChoiceDisplayType[]>(this.apiURL +'Common/GetChoiceDisplayTypes',{withCredentials: true});
    }

    public getAnswerTypes(){
        return this.http.get<AnswerType[]>(this.apiURL +'Common/GetAnswerTypes',{withCredentials: true});
    }
    public getUsers(){
        return this.http.get<User[]>(this.apiURL +'Common/GetUsers',{withCredentials: true});
  }
  public activeDirectoryByName(user: User) {
    return this.http.post<User[]>(this.apiURL+"ActiveDirectory/ActiveDirectoryListByName", user, {withCredentials: true});
  }

  public insertUser(user:User) {
    return this.http.post<User>(this.apiURL + 'Common/InsertUser', user, {withCredentials: true});
  }

  public getUserByNTID(ntid: any) {
    return this.http.get<User>(this.apiURL + 'Common/GetUserByNTID' +'/'+ ntid, { withCredentials: true });
  }
  public  insertIntoDeviation(deviation:Deviation){
    return this.http.post<Result>(this.apiURL +"Common/InsertIntoDeviation", deviation, {withCredentials: true});
  }

  public  deletetempAttachments(deviation:Deviation){
    return this.http.post<Result>(this.apiURL +"Common/DeletetempAttachments", deviation, {withCredentials: true});
  }

  public  insertIntoDeviationAttachments(deviation:Deviation){
    return this.http.post<Result>(this.apiURL +"Common/InsertIntoDeviationAttachments", deviation, {withCredentials: true});
  }

  public  insertIntoAuditDeviation(deviation:Deviation){
    return this.http.post<Result>(this.apiURL +"Common/InsertIntoAuditDeviation", deviation, {withCredentials: true});
  }

  public sendDeviationEmail(deviation:Deviation){
    deviation.pathUrl = environment.uiUrl;
    deviation.startDate = new Date();
    
    if(deviation.duedatecount!=undefined){
      deviation.endDate = deviation.duedatecount; 
      }
      else{
        deviation.endDate = new Date(new Date().setDate(new Date().getDate() + environment.superoplEndDateCount));
      }
    deviation.languageCode = this.sharedService.plantLanguageCode;
    return this.http.post<Deviation>(this.apiURL + "Common/SendDeviationEmail", deviation, {withCredentials: true});
  }

  toggleMenuLeftNav(from)
  {
     if (this.isCollapsedLeftNav) {
       this.toggleiconname = "fa fa-times";
       this.hideMenuName = false;
       $("#page-wrapper").css({ "margin": "0 0 0 325px" });
       $('.navbar-static-side').css({"width":"325px"});
       $('.navbar-static-side').removeClass("collapsed");
       $("#sidebar").show(400);
     } else {
       $('.navbar-static-side').addClass("collapsed");
       this.toggleiconname = "fa fa-bars";
       if($( window ).width() <= 768){
         this.toggleiconname = "fa fa-times";
         $("#sidebar").hide();
         $("#page-wrapper").css({ "margin": "0 0 0 0" });
         this.hideMenuName = false;
       }
       else{
         if(from == ''){
           $('.navbar-static-side').css({"width":"70px"});
           $("#page-wrapper").css({ "margin": "0 0 0 70px" });
           this.hideMenuName = true;
         }
         else{
           return;
         }
       }
       // $("#sidebar").hide();
     }
     this.isCollapsedLeftNav = !this.isCollapsedLeftNav;
  }

  isAuthUser(): Boolean {

    if(this.sharedService.role == "Designer"){
        return true;
    }
    else if (this.sharedService.role == "Standard User"){
      return true;
    }
    else
    {
      return false;
    }
  }

}
