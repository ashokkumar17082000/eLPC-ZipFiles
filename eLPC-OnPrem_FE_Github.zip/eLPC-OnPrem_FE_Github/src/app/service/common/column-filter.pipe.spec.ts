import { ColumnFilterPipe } from './column-filter.pipe';

describe('ColumnFilterPipe', () => {
   it('create an instance', () => {
     const pipe = new ColumnFilterPipe();
     expect(pipe).toBeTruthy();
   });
});
