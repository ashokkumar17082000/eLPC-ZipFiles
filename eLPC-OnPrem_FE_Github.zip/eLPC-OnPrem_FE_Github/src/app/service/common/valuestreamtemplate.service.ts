//<reference path="../../main/body/employee/employee.ts" />
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';  
import 'rxjs/add/operator/map';
import { HttpHeaders } from '@angular/common/http';
import { SharedService } from '../shared.service';
import { ValueStreamTemplate, ValueStreamCategory, ValueStream, ValueStreamProxy, Shift, ValueStreamHistory } from 'src/app/Valuestream/valuestreams/valuestreamtemplate';

@Injectable({
  providedIn: 'root',
})

export class ValuestreamTemplateService {

  private headers: HttpHeaders;
  apiURL: string;
  valueStreamTemplate: ValueStreamTemplate = new ValueStreamTemplate();
  constructor(private http: HttpClient, private sharedService: SharedService) {
    this.headers = new HttpHeaders();
    this.headers.append("Content-Type", "application/json");
    this.headers.append("Access-Control-Allow-Methods", "GET, POST, DELETE, PUT");

    this.headers.append("'Access-Control-Allow-Origin", "*");
    this.apiURL = this.sharedService.apiURL;
  }

  public insertValueStreamTemplate(valuestreamtemplate:ValueStreamTemplate){
    let json=JSON.stringify(valuestreamtemplate);
    return this.http.post<ValueStreamTemplate>(this.apiURL + "ValueStreamTemplate/InsertValueStreamTemplate", valuestreamtemplate, {withCredentials: true});
  }
  
  public getValueStreamCategory() {
    return this.http.get<ValueStreamCategory[]>(this.apiURL + "ValueStreamTemplate/GetValueStreamCategories", {withCredentials: true});
  }
  public getValueStream() {
    return this.http.get<ValueStream[]>(this.apiURL + "ValueStreamTemplate/GetValueStreams", {withCredentials: true});
  }

  public insertValueStreamCategory(valuestreamcategory: Array<ValueStreamCategory>) {
    return this.http.post<ValueStreamCategory>(this.apiURL + "ValueStreamTemplate/InsertValueStreamTemplate", valuestreamcategory, {withCredentials: true});
  }


 public getValueStreamTemplate() {
   return this.http.get<ValueStreamTemplate[]>(this.apiURL + "ValueStreamTemplate/GetValueStreamTemplates", { headers: this.headers, withCredentials: true });
  }

  public getValueStreamTemplateHistory(templateID: number) {
    
   return this.http.get<ValueStreamHistory[]>(this.apiURL + "ValueStreamTemplate/GetValueStreamsHistory"+ '/' + templateID, { headers: this.headers, withCredentials: true });
  }

  public valueStreamRestoreByTemplateHistoryID(historyID: number) {
    return this.http.get(this.apiURL + "ValueStreamTemplate/ValueStreamRestoreByTemplateHistoryID" + '/' + historyID, {withCredentials: true});
  }

  public getValueStreamCategoryByTemplateID(templateID: number) {
    return this.http.get<ValueStreamCategory[]>(this.apiURL + "ValueStreamTemplate/GetValueStreamCategoryByTemplateID" + '/' + templateID, {withCredentials: true});
  }

  // ****Import*****
  // ImportExcel(formData: FormData) {
    ImportExcel(formData: FormData) {
    let headers = new HttpHeaders();

    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Accept', 'application/json');

    const httpOptions = { headers: headers };
    return this.http.post(this.apiURL + 'ValueStreamTemplate/ImportExcel', formData, httpOptions)
    
  }
  // ****end**

  // ***export****
  ExportExcel() {
    return this.http.get(this.apiURL + 'ValueStreamTemplate/ExportExcel', {withCredentials: true});
  }

  public getValueStreamsByCategoryID(categoryID: number) {
    return this.http.get<ValueStream[]>(this.apiURL + "ValueStreamTemplate/GetValueStreamsByCategoryID" + '/' + categoryID, {withCredentials: true});
  }

  public getValueStreamsByTemplateID(templateID: number) {
    return this.http.get<ValueStream[]>(this.apiURL + "ValueStreamTemplate/GetValueStreamsByTemplateID" + '/' + templateID, {withCredentials: true});
  }

  public fetchValueStreamsByTemplateID(templateID: number) {
   
    return this.http.get<ValueStreamTemplate[]>(this.apiURL + "ValueStreamTemplate/FetchValueStreamTemplateByTemplateID" + '/' + templateID, {withCredentials: true});
  }

  public getShiftsByTemplateID(templateID: number) {
    return this.http.get<Shift[]>(this.apiURL + "ValueStreamTemplate/GetShiftsByTemplateID" + '/' + templateID, {withCredentials: true});
  }

  public insertValueStreamProxy(valueStreamProxy: ValueStreamProxy) {
    return this.http.post<ValueStreamProxy>(this.apiURL + "ValueStreamTemplate/InsertValueStreamProxy", valueStreamProxy, {withCredentials: true});
  }

  //for treeview loading
  public getValueStreamTemplateTree() {
   //return this.http.get<TreeviewItem[]>(this.apiURL + "ValueStreamTemplate/GetValueStreamTemplateTree", { headers: this.headers, withCredentials: true });
  }
  public deleteValueStreamTemplate(valueStreamTemplate: ValueStreamTemplate) {
    return this.http.post<ValueStreamTemplate>(this.apiURL + "ValueStreamTemplate/DeleteValueStreamTemplate", valueStreamTemplate, {withCredentials: true});

  }

  public valueStreamProxiesByTemplateID(valueStreamTemplateID: number) {
    return this.http.get(this.apiURL + "ValueStreamTemplate/ValueStreamProxiesByTemplateID" + '/' + valueStreamTemplateID, { withCredentials: true });
  }

  public valueStreamByValueStreamID(valueStreamID: number){
    return this.http.get(this.apiURL + "ValueStreamTemplate/ValueStreamByValueStreamID" + '/' + valueStreamID, { withCredentials: true });
  }
}
