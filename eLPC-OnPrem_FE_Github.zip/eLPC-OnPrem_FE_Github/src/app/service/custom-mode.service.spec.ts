import { TestBed } from '@angular/core/testing';

import { CustomModeService } from './custom-mode.service';
import { HttpClientModule } from '@angular/common/http';

describe('CustomModeService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientModule,]
  }));

  it('should be created', () => {
    const service: CustomModeService = TestBed.get(CustomModeService);
    expect(service).toBeTruthy();
  });
});
