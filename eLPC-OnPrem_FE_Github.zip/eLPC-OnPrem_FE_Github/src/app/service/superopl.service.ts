import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import 'rxjs/add/operator/map';
import { HttpHeaders } from '@angular/common/http';
import { SharedService } from '../service/shared.service';
import { environment } from 'src/environments/environment';
import { LanguageService } from '../language.service';
import { DatePipe } from '@angular/common';
import { Deviation } from 'src/app/Deviation/deviation/deviation';


@Injectable({
  providedIn: 'root',
})

export class SuperOPLService {
  private headers: HttpHeaders;
  apiURL: string;
  superOPLapiURL: string;
  
  labels: any;
  _subscription: any;
  value: any;
  
  constructor(private http: HttpClient,private local_label: LanguageService, private sharedService: SharedService, private datePipe: DatePipe) {
    this.apiURL = sharedService.apiURL;
    this.headers = new HttpHeaders();
    this.headers.append("Content-Type", "application/json");
    this.superOPLapiURL = environment.superOPLapiURL;

    this.sharedService._selectedPlant.subscribe(res => {
      this.apiURL = this.sharedService.apiURL;
      this.superOPLapiURL = environment.superOPLapiURL;
    });

    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe(value => {
      this.apiURL = this.sharedService.apiURL;
      this.superOPLapiURL = environment.superOPLapiURL;
    });

  }

  
  public getAllTasks(oplID:any, apiKey:any) {
    var url =this.superOPLapiURL + "/" + oplID+ "/tasks?key="+ apiKey;
    var JSONObject = {url:url.toString(), task: JSON.stringify({})};
    return this.http.post<any>(this.apiURL + "SuperOPL/GetOPLTasks", JSONObject, {withCredentials: true});
  }

  public  createOPLTask(task:any, oplID:any, apiKey:any, deviationObj: any) {
    deviationObj.pathUrl = environment.uiUrl;
    deviationObj.startDate = new Date();
    if(deviationObj.duedatecount!=undefined){
      deviationObj.endDate = deviationObj.duedatecount; 
      }
      else{
        deviationObj.endDate = new Date(new Date().setDate(new Date().getDate() + environment.superoplEndDateCount));
      }
    deviationObj.languageCode = this.sharedService.plantLanguageCode;
    deviationObj.superOPLURL = environment.superOPLTaskURL;

    var url =this.superOPLapiURL + "/" + oplID+ "/tasks?key="+ apiKey;
    var JSONObject = {url:url.toString(), task: JSON.stringify(task), deviation: JSON.stringify(deviationObj)};
      return this.http.post<any>(this.apiURL + "SuperOPL/CreateOPLTask", JSONObject, {withCredentials: true});
  }

  public  updateOPLTask(task:any, oplID:any, taskID:any, apiKey:any) {
    var url =(this.superOPLapiURL + "/" + oplID+ "/tasks/"+ taskID +"?key="+ apiKey);
    var JSONObject = {url:url.toString(), task: JSON.stringify(task)};
    return this.http.post<any>(this.apiURL + "SuperOPL/UpdateOPLTask", JSONObject, {withCredentials: true});
  }


  public CreateDeviationSuperOPL(deviation:Deviation)
  {
    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
    });

    var ufT1Value_ChoiceAnswer = "";                    //   T1 = Answer - Text of choice answer
    var ufT2Value_DetectedBy = deviation.createdBy_NTID;//   T2 = Detected by - NT-ID of user that detected the deviation
    var ufLT2Value_QuestionText = "";                   //   LT2 = Question Text - Text of question with which the deviation was detected
    var ufLT3Value_DetectionDescription = deviation.deviationDescription;    //   LT3 = Text of  deviation description
    var ufLT4Value_Tags = "";                           //   LT4 = Title of linked tags (with prefix and separated by '; ') 
    var ufLT5Value = "";                                //   LT5 = URLs of the attached files
    var OPLType = 1                                     //   Task;

    var startDate = new Date();
    if(deviation.duedatecount!=undefined){
      var endDate = deviation.duedatecount; 
      }
      else{
        var endDate = new Date(new Date().setDate(new Date().getDate() + environment.superoplEndDateCount));
    }


      var description = this.labels.default.superOPL_DescriptionTemplate.toString()
      .replace("((DeviationDescription))", deviation.deviationDescription)
      .replace("((CreatedBy_Name))", deviation.createdBy_Name)
      .replace("((CreatedBy_NTID))", deviation.createdBy_NTID);      
        if(deviation.selectedTagData!=null){
        var alltags:string='';
        for(let each of  deviation.selectedTagData) {
        alltags+= each.FormattedTag+",";
        }
        alltags=alltags.slice(0,alltags.length-1);
        var  ufLT4Value_Tags_dev=alltags;
        ufLT4Value_Tags = ufLT4Value_Tags_dev;
        }
     
     
    if(deviation.questionID != null && deviation.questionID > 0)
    {
      description = description+ "\n" + deviation.questionText;
      
      ufT1Value_ChoiceAnswer = deviation.questionChoiceAnswer;
      ufLT2Value_QuestionText = deviation.questionText;
   if(ufLT4Value_Tags_dev!=null){
    
  ufLT4Value_Tags = deviation.questionLinkedTags+","+ufLT4Value_Tags_dev;
 }
 else
 ufLT4Value_Tags = deviation.questionLinkedTags;      
    }          
  var OPLSubject =this.labels.default.superOPL_SubjectTemplate +": " + deviation.deviationDescription;
    if(OPLSubject.length > 95)
    {
      OPLSubject = OPLSubject.substr(0, 95).trim() + "...";
    }

    if(ufT1Value_ChoiceAnswer.length > 95)
    {
      ufT1Value_ChoiceAnswer = ufT1Value_ChoiceAnswer.substr(0, 95).trim() + "...";
    }
   
    var request = {
      "owner": deviation.ownerNTID,
      "type" : OPLType,
      "prio":"A",
      "subject": OPLSubject,
      "taskStart": this.datePipe.transform(startDate,"yyyy-MM-dd").toString(), //"2020-05-25",
      "endDate": this.datePipe.transform(endDate,"yyyy-MM-dd").toString(),
      "responsible": (deviation.responsibleEmpNTID != null && deviation.responsibleEmpNTID != "") ?  deviation.responsibleEmpNTID :  deviation.ownerNTID, 
      "description": description,
      "informationTo": (deviation.responsibleEmpNTID != null && deviation.responsibleEmpNTID != "") ?[deviation.responsibleEmpNTID,deviation.ownerNTID,this.sharedService.ntid] :[deviation.ownerNTID,this.sharedService.ntid],
      "loginUser": this.sharedService.ntid,
      "category": (deviation.questionID != null && deviation.questionID > 0) ? "Q" +deviation.questionDisplayID.toString(): "",
      "source": deviation.valueStreamName,
      "ufT1Value": ufT1Value_ChoiceAnswer,
      "ufT2Value": ufT2Value_DetectedBy,
      "ufLT2Value": ufLT2Value_QuestionText,
      "ufLT3Value": ufLT3Value_DetectionDescription,
      "ufLT4Value": ufLT4Value_Tags,
      //"ufLT5Value": ufLT5Value,
    }
    
    return request;
  }
}
