import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders,  HttpParameterCodec } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable, Subject } from 'rxjs';
import { UserDetails, User, Result, UserAdditionalData, AppSettings, Plant } from '../main/body/shared/common';
import $ from 'jquery';
//import { Audit } from '../main/body/calendar/calendar';
import { Audit } from '../calendar/calendar/calendar';
import { TagMode } from '../ProcessConfirmation/process-confirmationmode/tag-mode/tag-mode';
import { Tag } from 'src/app/Tag/tag/tag';
import * as CryptoJS from 'crypto-js';
import moment from 'moment-timezone';
moment.tz.setDefault('Utc');

//import * as AppSettingsJson from '../../assets/appsettings.json'

@Injectable({
  providedIn: 'root'
})

/** This service is responsible for using shared data to the entire application. */
export class SharedService {

  private _teacherMessageSource = new Subject<string>();
  teacherMessage$ = this._teacherMessageSource.asObservable();

  _selectedIcon = new Subject<string>();
  selectedIcon = this._selectedIcon.asObservable();

  _selectedIconName = new Subject<string>();
  selectedIconName = this._selectedIconName.asObservable();

  _selectedRoleName = new Subject<string>();
  selectedRoleName = this._selectedRoleName.asObservable();

  _selectedPlant = new Subject<number>();
  selectedPlant = this._selectedPlant.asObservable();
  
  SharedServiceTags = new Tag();
  languageDropDownOnlclick:boolean=false;
  //private headers: HttpHeaders;
  public commonApiURL: any;
  public apiURL: any;
  private headers: HttpHeaders;
  public sharedUserDetails : UserDetails;

  public sharedDesignerUser : User[] = [];

  role: string;
  ntid: any;
  ADdisplayName: string;
  displayName: string;
  emailAddress: string;
  sessionID: string;

  selectedLanguage: string;
  audit: Audit;
  secretKey = "eLPCEncKey";

  plantID: number = 0;
  plantLanguageCode: string;
  errorMessage: string;
  showPlantSelectionPopup: boolean = false;
  currentUserInfo: any;
  appSettings: AppSettings;
  calendar_auditID: number;
  tagMode_tagID: number;
  TagModeID:Number;
  tagTypeID:number;
  IsSkipEnabled:boolean;
  SkipDisabledCustomTags=[];
  PlantNameSelected:string;
  customIConID:number;
  CustomModeSkip:boolean;
  CustomModeQuestionOverview:boolean ;
  CustomModeAnswerOverView : boolean ;
  CustomModeProgressPercentage :boolean;
  CustomModeResumeTag:boolean ;
  CustomModeReportingEmail: boolean ;
  CustomModeID:number;
  TagName:string;
  TagTypeID:number;
  tagmodetagID:number;
  calTagModeTagID:number;
  calTagmodeID:number;
  tagMode:TagMode;
  tagDisplayName: string;
  responsibleEmployee_tag: string;

  public activeDateRange: SearchFilter = new SearchFilter();

  constructor(private http: HttpClient) {
    this.headers = new HttpHeaders();
    this.headers.append("Content-Type", "application/json");
    this.headers.append("Access-Control-Allow-Methods", "GET, POST, DELETE, PUT");
    this.headers.append("'Access-Control-Allow-Origin", "*");

    this.commonApiURL = environment.commonApiURL;
    this.apiURL = environment.baseUrl;
    //this.appSettings = (AppSettingsJson as any).default;
    //if (!this.appSettings) {
    //  this.readAppSettings();
    //}
  }
  readAppSettings() {
    this.http.get("assets/appsettings.json?_cache_buster=" + new Date().getTime()).subscribe(data => {
      this.appSettings = data as AppSettings;
    });
  }

  setIcon(icon: string) {
    this._selectedIcon.next(icon);
  }

  setIconName(iconName: string) {
    this._selectedIconName.next(iconName);
  }


  sendMessage(message: string) {
    this._teacherMessageSource.next(message);
  }
  /** Method to show loader. */
  show() {
    $("#nb-global-spinner").css("display", "block");
    $("#loading").css("display", "block");
  }

  /** Method to hide loader. */
  hide() {
    $("#nb-global-spinner").css("display", "none");
    $("#loading").css("display", "none");
  }


  public CheckApplicationAccess() {
    return this.http.get(this.apiURL + "Auth/CheckApplicationAccess", { headers: this.headers, withCredentials: true });
  }

  public GetApplicationAccessByUserId(userId: any) {
    return this.http.get<UserDetails>(this.apiURL + "ActiveDirectory/GetUserListByNTID?userId=" + userId, { headers: this.headers, withCredentials: true });
  }

  public CheckApplicationAccessByUserId(user: any) {
    return this.http.post<UserDetails>(this.apiURL + 'ActiveDirectory/SaveActiveDirectoryList', user[0], { withCredentials: true });
  }

  public getADUsersByGroupName(groupName:string) {
    return this.http.get<any>(this.apiURL + "ActiveDirectory/GetADUsersByGroupName" + '/' +  groupName.replace('/','_'), { withCredentials: true });
  }

  public auditByAuditID(auditID: number) {
    return this.http.get<Audit>(this.apiURL + "Audit/AuditByAuditID" + "/" + auditID, { withCredentials: true });
  }

  public validateAssessorByAuditAndNTID(auditID: number, ntid: string) {
    return this.http.get<User>(this.apiURL + "Audit/ValidateAssessorByAuditAndNTID" + "/" + auditID + "/" + ntid);
  }

  downloadServiceMailboxFile(): Observable<Blob> {
    const fileUrl = `${this.apiURL}Files/servicemailbox`;
    return this.http.get(fileUrl, { responseType: 'blob' });
  }

  public GetTagModeByNTID(NTID: string) {
    return this.http.get<TagMode[]>(this.apiURL + "TagMode/GetTagModeByNTID" + "/" + NTID, { headers: this.headers, withCredentials: true });
  }

  public fetchTagDetailsByTagID(tagID: number) {
    return this.http.get<Tag[]>(this.apiURL + "Tag/FetchTagDetailsByTagID" + '/' + tagID, { withCredentials: true });
  }

  public insertToTagMode(tagMode: TagMode) {
    return this.http.post<TagMode>(this.apiURL + "TagMode/insertToTagMode", tagMode, { withCredentials: true });
  }

  public getTagModeTags() {
    return this.http.get<Tag[]>(this.apiURL + "TagMode/GetTagModeTags", { headers: this.headers, withCredentials: true });
  }

  public encrypt(plaintText: string): string {
    var ciphertext = CryptoJS.AES.encrypt(plaintText, this.secretKey.trim()).toString();
    ciphertext = ciphertext.replace(/\+/g, 'p1L2u3S').replace(/\//g, 's1L2a3S4h').replace(/=/g, 'e1Q2u3A4l');
    return ciphertext;
  }

  public decrypt(textToDecrypt: string) {
    textToDecrypt = textToDecrypt.replace(/p1L2u3S/g, '+').replace(/s1L2a3S4h/g, '/').replace(/e1Q2u3A4l/g, '=');
    return CryptoJS.AES.decrypt(textToDecrypt, this.secretKey.trim()).toString(CryptoJS.enc.Utf8);
  }

  public FetchUserAccessDetails(ntid: string, plantID:number)
  {
    return this.http.get<UserDetails>(this.commonApiURL + "Common/FetchUserAccessDetails/"+ ntid +"/" + plantID, { withCredentials: true });
  }

  public GetConfigByPlantIDAndConfigType(plantID:number, configType:string)
  {
    return this.http.get<Result>(this.commonApiURL + "Common/GetConfigByPlantIDAndConfigType/"+plantID +"/" + configType, { withCredentials: true });
  }

  public SetDefaultPlant(user: User)
  {
    return this.http.post<any>(this.commonApiURL + "Common/SetDefaultPlant", user, { withCredentials: true });
  }

  public SetUserAdditionalData(user: UserAdditionalData) {
    return this.http.post<any>(this.commonApiURL + "Common/SetUserAdditionalData", user, { withCredentials: true });
  }

  public async GetEnironmentConfigFromDBAndLogin(ntid: any, router: any, pathName: any)
  {
     if (!this.appSettings) {
      this.readAppSettings();
    }
    if (this.apiURL == "") {

      if (this.plantID == 0) {
        let sessionPlantID = sessionStorage.getItem("plantID");
        if (sessionPlantID != null && sessionPlantID != "") {
          this.plantID = parseInt(sessionPlantID);
        }
      }

      this.FetchUserAccessDetails(ntid, this.plantID).subscribe(userDetails => {
     
        this.sharedUserDetails = userDetails;

        if (userDetails != null && userDetails.avaliablePlants != null && userDetails.avaliablePlants.length > 0) {
          userDetails.avaliablePlants.forEach(element => {
            var role = element["currentRole"].split("-");
            if (role.length > 1) {
              element["currentDisplayRole"] = role[role.length - 1];
            }
            else {
              var role = element["currentRole"].split("_");
              element["currentDisplayRole"] = role[role.length - 1];
            }
          });

          this.sharedUserDetails = userDetails;
        }

        //Invaild NTID
        if (userDetails.ntid == null && userDetails.plant == null && userDetails.avaliablePlants == null) {
          //debugger;
          this.showAppInfoMessage(router, "<h3>You are not authorized to access eLPC application</h3>");
        }

        //Vaild NTID But not having eLPC application access / roles
        else if (userDetails.ntid != null && userDetails.plant == null && userDetails.avaliablePlants.length == 0) {
          //debugger;
          this.showAppInfoMessage(router, "<h3>You are not authorized to access eLPC application</h3>");
        }

        //User having either one plant access or Default plant access
        if (userDetails != null && userDetails.plant != null && userDetails.plant.plantID > 0 && userDetails.avaliablePlants.length > 0) {
          if (this.ValidateIsUnderMaintanence(router, userDetails) && this.ValidateIsPlantActive(router, userDetails)) {
            this.currentUserInfo = userDetails.plant;
            this.GetSelectedPlantDetails(userDetails, userDetails.plant.plantID, ntid, router, pathName);
          }
        }

        //User having multiple plant access but no default plant assigned then show plant selection popup
        if (userDetails != null && userDetails.plant == null && userDetails.avaliablePlants.length > 0) {
          this.DisplayPlantSelectionPopup(router, "");
        }

      });
    }
    else {
      this.login(ntid, router, pathName);
    }
  }

  DisplayPlantSelectionPopup(router: any, message: string)
  {
      //Display Plant Selection Popup
      this.showPlantSelectionPopup = true;
      this.showAppInfoMessage(router, message);
  }

  GetSelectedPlantDetails(userDetails: any, plantID: number, ntid: any, router: any, pathName: any)
  {
    this.GetConfigByPlantIDAndConfigType(plantID, 'UI').subscribe(res => {
      var result = JSON.parse(res.resultMessage);
      this.AssignEnvironmentData(result, userDetails);
      this.plantID = plantID;
      this._selectedPlant.next(this.plantID);
      var user = new User();
      user.emailAddress = this.sharedUserDetails.emailAddress;
      user.firstName = this.sharedUserDetails.firstName;
      user.lastName = this.sharedUserDetails.lastName;
      user.ntid  = this.sharedUserDetails.ntid;
      user.plantID = plantID;
      user.userName = this.sharedUserDetails.userName;

      if (userDetails.avaliablePlants != null && userDetails.avaliablePlants.length == 1) {
        this.SetDefaultPlant(user).subscribe(res => {
        });
      }

      this.login(ntid, router, pathName);
    });
  }

  ValidateIsUnderMaintanence(router: any, userDetails: any) {
    if (userDetails.plant.isUnderMaintenance) {
      this.DisplayPlantSelectionPopup(router, userDetails.plant.underMaintenanceMessage);
      return false;
    }
    return true;
  }

  ValidateIsPlantActive(router: any, userDetails: any) {
    if (!userDetails.plant.isActive) {
      this.DisplayPlantSelectionPopup(router, userDetails.plant.plantAvaliablityMessage);
      return false;
    }
    return true;
  }

  showAppInfoMessage(router: any, strMsg: string) {
    this.errorMessage = strMsg
    //this.valueStreamLists!==undefined && this.valueStreamLists!==null && this.valueStreamLists.length>0
 
    if(this.sharedUserDetails.avaliablePlants == null ||this.sharedUserDetails.avaliablePlants ==undefined || this.sharedUserDetails.avaliablePlants.length==0){
      router.navigate(['appinfo']);     
    }else {
      router.navigate(['my-modal']);
    }
    //router.navigate(['appinfo']);
 // router.navigate(['my-modal']);  // Navigate to MyModalComponent route
  }

  AssignEnvironmentData(result: any, userDetails: any) {
    environment.plantName = result.plantDisplayName;
    environment.language = result.applicableLanguages;
    environment.dateTimeFormat = result.dateTimeDisplyFormat;
    environment.home = result.home;
    environment.uiUrl = result.uiUrl;
    environment.baseUrl = result.baseUrl;
    environment.fileTypes = result.uploadFileTypes;
    environment.maxFileSize = Number(result.maxFileSize);
    environment.maxAttachments = Number(result.maxAttachments);
    environment.powerBIURL = result.powerBIURL;
    environment.superopl = result.superOPLConfigDetails;
    environment.superoplEndDateCount = Number(result.superOPLDueDateCount);
    environment.superOPLapiURL = result.superOPLapiURL;
    environment.superOPLPortalURL = result.superOPLPortalURL;
    environment.superOPLTaskURL = result.superOPLTaskURL;
    environment.defaultLanguage = userDetails.plant.defaultLanguage;
    this.apiURL = environment.baseUrl;

    this.activeDateRange = new SearchFilter();
    if (!isNaN(result.dataLoadInteravlInDays) && Number(result.dataLoadInteravlInDays) > 0) {
      this.activeDateRange.dataLoadInteravlInDays = Number(result.dataLoadInteravlInDays);
    }
    if (!isNaN(result.maxIntervalInMonths) && Number(result.maxIntervalInMonths) > 0) {
      this.activeDateRange.maxIntervalInMonths = Number(result.maxIntervalInMonths);
    }

    var startDate = new Date();
    var endDate = new Date();
    startDate.setDate(startDate.getDate() - this.activeDateRange.dataLoadInteravlInDays);

    this.activeDateRange.fromDate = startDate;
    this.activeDateRange.toDate = endDate;
    this.activeDateRange.maxDate = endDate;

  }

  public login(ntid: any, router: any, pathName: any) {
    this.show();
   // alert(367+'shared')
    this.GetApplicationAccessByUserId(ntid).subscribe(resAD => {
      if (resAD != null && resAD) {
        this.CheckApplicationAccessByUserId(resAD).subscribe(res => {
          debugger;
          if (res.roleName != '') {
            this.role = res.roleName;
            this.ntid = res.ntid;
            this.ADdisplayName = res.displayName;
            this.displayName = res.firstName + " " + res.lastName;
            this.emailAddress = res.emailAddress;
            var userName = res.firstName + " " + res.lastName;
            this.customIConID=res.customIConID;
            
            //to clear the session during the initial login
            //sessionStorage.clear();

            //for reloading purpose
            sessionStorage.setItem("role", this.role);
            sessionStorage.setItem("ntid", this.ntid);
            sessionStorage.setItem("displayName", this.displayName);
            sessionStorage.setItem("emailAddress", this.emailAddress);
            sessionStorage.setItem("ADdisplayName", this.ADdisplayName);
            sessionStorage.setItem("plantID", this.plantID.toString());
            sessionStorage.setItem("customICon", this.customIConID.toString());
            //sessionStorage.setItem("apiURL", this.apiURL);

            setTimeout(function () {
              if (userName != undefined && userName != null && userName != "") {
                if(document.getElementsByClassName('rb-core-profile-access__user-name')[0] != undefined)
                document.getElementsByClassName('rb-core-profile-access__user-name')[0].innerHTML = userName;
               
                if(document.getElementsByClassName('rb-core-profile-access__user-name-button')[0] != undefined)
                document.getElementsByClassName('rb-core-profile-access__user-name-button')[0].innerHTML = userName;
               
                if(document.getElementsByClassName('rb-core-profile-access__user-monogram')[0] != undefined)
                document.getElementsByClassName('rb-core-profile-access__user-monogram')[0].innerHTML = userName.slice(0, 1);
               
                if(document.getElementsByClassName('rb-core-profile-access__user-email')[0] != undefined)
                document.getElementsByClassName('rb-core-profile-access__user-email')[0].innerHTML = res.roleName;
               
                if(document.getElementsByClassName('rb-core-profile-access__links-headline')[0] != undefined)
                document.getElementsByClassName('rb-core-profile-access__links-headline')[0].innerHTML = environment.plantName;
              }
            }, 2000);

            if (this.role) {
              this._selectedRoleName.next(this.role);

              this.hide();
              if (pathName.toString().toLowerCase().includes("processconfirmation;tid")) {
                var paramID = sessionStorage.getItem("paramid")
                if (paramID != null && paramID != "") {
                  sessionStorage.removeItem("paramid");
                  this.GetTagModeQuestions(0, Number(paramID), router);
                }
                else {
                  var obj = this.GetIDFromURL(pathName);
                  if (obj.plant == this.plantID) {
                    this.GetTagModeQuestions(0, obj.id, router);
                  }
                  else {
                    var paramid =  obj.id.toString();
                    var plantID = obj.plant.toString();
                    sessionStorage.setItem("plantID", plantID);
                    sessionStorage.setItem("paramid", paramid);
                    if (obj.plant.toString() != this.plantID.toString()) {
                      this.plantID = 0;
                      this.apiURL = "";
                    }
                    this.GetEnironmentConfigFromDBAndLogin(this.ntid, router, pathName);
                  }
                }
                //http://localhost:4200/eLPC_Quality/processConfirmation;tid=26 // #-Process Confirmation
                //http://localhost:4200/eLPC_Quality/processConfirmation;tid=23 // @-Audit
                //http://localhost:4200/eLPC_Quality/processConfirmation;tid=21 // $-Survey
              }
              else if (pathName.toString().toLowerCase().includes("processconfirmation;qid")) {
                var paramID = sessionStorage.getItem("paramid");
                if (paramID != null && paramID != "") {
                  sessionStorage.removeItem("paramid");
                  router.navigate([environment.home + '/processConfirmation', { qid: Number(paramID) }]);
                }
                else {
                  var obj = this.GetIDFromURL(pathName);
                  var paramid =  obj.id.toString();
                  if (obj.plant == this.plantID) {
                    router.navigate([environment.home + '/processConfirmation', { qid: Number(paramid) }]);
                  }
                  else {
                    var paramid =  obj.id.toString();
                    var plantID = obj.plant.toString();
                    sessionStorage.setItem("plantID", plantID);
                    sessionStorage.setItem("paramid", paramid);
                    if (obj.plant.toString() != this.plantID.toString()) {
                      this.plantID = 0;
                      this.apiURL = "";
                    }
                    this.GetEnironmentConfigFromDBAndLogin(this.ntid, router, pathName);
                  }
                }
                //http://localhost:4200/eLPC_Quality/processConfirmation;qid=12   // Single Line
                //http://localhost:4200/eLPC_Quality/processConfirmation;qid=2029 // Mutli Line
                //http://localhost:4200/eLPC_Quality/processConfirmation;qid=2017 // Choice
              }
              else if (pathName.toString().toLowerCase().includes("calendar;auditid")) {
                var paramID = sessionStorage.getItem("paramid")
                if (paramID != null && paramID != "") {
                  sessionStorage.removeItem("paramid");
                  this.GetAuidtModeQuestions(Number(paramID), router);
                }
                else {
                  var obj = this.GetIDFromURL(pathName);
                  if (obj.plant == this.plantID) {
                    this.GetAuidtModeQuestions(Number(obj.id), router);
                  }
                  else {
                    var paramid =  obj.id.toString();
                    var plantID = obj.plant.toString();
                    sessionStorage.setItem("plantID", plantID);
                    sessionStorage.setItem("paramid", paramid);
                    if (obj.plant.toString() != this.plantID.toString()) {
                      this.plantID = 0;
                      this.apiURL = "";
                    }
                    this.GetEnironmentConfigFromDBAndLogin(this.ntid, router, pathName);
                  }
                }
                //http://localhost:4200/eLPC_Quality/calendar;auditid=37  // #-Process Confirmation
                //http://localhost:4200/eLPC_Quality/calendar;auditid=20  // @-Audit
                //http://localhost:4200/eLPC_Quality/calendar;auditid=38  // $-Survey
              }
              else if (pathName.toString().toLowerCase().includes("dashboard")) {
                debugger;
                var _this = this;
                _this.show();
              //  router.navigateByUrl('/dashboard', {skipLocationChange: false}).then(() =>
              //           router.navigate([environment.home + '/dashboard']));
                
               //router.navigate([environment.home +'/dashboard'],{skipLocationChange: false});
                 setTimeout(() => {
                  
                  router.navigateByUrl('/dashboard', {skipLocationChange: false}).then(() =>
                        router.navigate([environment.home + '/dashboard']));
                        // _this.hide();
                  }, 0)
              
                
                //router.navigate([environment.home + '/dashboard'],this.customIConID);
              }
              else if (pathName.toString().toLowerCase().includes("processconfirmation;mode=tag")) {
                // alert("shared")
                router.navigate([environment.home + '/processConfirmation', { mode: "tag" }]);
              }
              else {
                if(environment.production)
                {
                  router.navigate([pathName.replace(environment.basehref,"/")]);
                }
                else
                {
                  router.navigate([pathName]);
                }
              }
              return true;
            }
          }
          else {
            this.AuthenticationError(router);
          }
        },
          err => {
            this.AuthenticationError(router);
          });
      }
      else {
        this.AuthenticationError(router);
      }
    },
    err => {
      this.AuthenticationError(router);
    });
  }

  public AuthenticationError(router)
  {
    this.hide();
    //debugger;
    this.errorMessage = "<h3>You are not authorized to access eLPC application</h3>"
    router.navigate([environment.home + '/appinfo']);
    return false;
  }

  public GetIDFromURL(pathName)
  {
    var param = pathName.toString().split("id=")[1];
    //var paramID = isNaN(Number(param)) ? this.decrypt(param) : Number(param);
    var params = this.decrypt(param);
    var obj = JSON.parse(params);
    return obj;
  }

  public GetTagModeQuestions_Optimized(auditID, tagID, router)
  {
    this.calendar_auditID = auditID;
    this.tagMode_tagID = tagID;
    this.show();
    var NTID = this.ntid;
    var tagMode: any;
    var selectedTags = [];
    
    if(this.tagmodetagID)
    {
      tagMode = this.tagMode;
      this.calTagModeTagID=tagMode.tags[0].tagID;
      this.calTagmodeID = tagMode.tags[0].tagModeTagsID;
      if(tagMode.tagID)
      {
        console.log("546",tagMode);
        console.log("557",this.SharedServiceTags);
        this.fetchtagDetailsByTabID_optimize(tagID, tagMode, router, true);
      }
      else
      {
        this.fetchtagDetailsByTabID_optimize(tagID, tagMode, router, false);
      }
    }
   
  }

  private fetchtagDetailsByTabID_optimize(tagID: any, tagMode: any, router: any, IstagExist:  boolean)
  {
    //debugger;
    var tagsPayload :Tag[];
    var tagMode1:TagMode=new TagMode();
    this.fetchTagDetailsByTagID(tagID).subscribe(res => {
      console.log("shared 531",tagID)
      var selectedTags = [];
      selectedTags = res;
      console.log("534",res)
      this.SharedServiceTags.isSkipQuestionDefined = res[0].isSkipQuestionDefined
    this.SharedServiceTags.isQuestionOverviewDefined = res[0].isQuestionOverviewDefined
    this.SharedServiceTags.isProgressPercentageDefined = res[0].isProgressPercentageDefined
    this.SharedServiceTags.isResultOverviewDefined =res[0].isResultOverviewDefined
    this.SharedServiceTags.isResumeTagDefined=res[0].isResumeTagDefined
    this.SharedServiceTags.isReportingEmailDefined=res[0].isReportingEmailDefined
      this.IsSkipEnabled = res[0].isSkipQuestionDefined;

   if (IstagExist)
    {
       //1st If case
       console.log("539",this.IsSkipEnabled)
       if (selectedTags.length <= 0) {
         this.hide();
         return;
       }
       if (!tagMode.tags) {
         this.hide();
         return;
       }
       tagMode.tags = selectedTags;
       tagMode.createdBy_NTID = this.ntid;
       console.log("550",selectedTags)
       console.log("551",this.tagTypeID)
       var _this = this;
       console.log("587",tagMode)
       console.log("606",this.SharedServiceTags)
 
   }
   else
   {
      //2nd else case
      //alert("payload")
      tagsPayload = this.tagIdNonExistsExecutions(tagsPayload, res, tagMode1);

   }
    this.redirectToProcessConfirmation_TagMode(router, _this);
      
      selectedTags = [];
    }, err => console.log(err));
  }

  private tagIdNonExistsExecutions(tagsPayload: Tag[], res: Tag[], tagMode1: TagMode) {
    //debugger;
    tagsPayload = res;
    tagMode1.createdAt = null;
    //tagMode1.createdBy= null
    tagMode1.createdBy_NTID = this.ntid;
    tagMode1.createdBy_UserID = null;
    // tagMode1.customModeID= 0
    tagMode1.isCompleted = false;
    tagMode1.isDeleted = null;
    //tagMode1.modifiedAt= null
    //tagMode1.modifiedBy= null
    //tagMode1.modifiedBy_UserID= null
    tagMode1.question = null;
    tagMode1.questions = [];
    tagMode1.tag = null;
    //tagMode1.tagID= 0
    //tagMode1.tagMode1ID= 0
    tagMode1.tagName = null;
    tagMode1.tags = tagsPayload;
    this.tagTypeID = res[0].tagTypeID;
    console.log("empty tagmode1", tagMode1);
    console.log("969", tagMode1);
    // this.insertToTagMode(tagMode1).subscribe(res => {
    //   this.GetTagModeByNTID(NTID).subscribe(res => {
    //     alert(656)
    //     debugger
    //     //this.calTagmodeID = res1[0].tagModeTagsID;
    //     this.calTagmodeID = res[0].tags[0].tagModeTagsID;
    //     console.log("656",res)
    //   })
    console.log("587", tagMode1);
    return tagsPayload;
  }

  private redirectToProcessConfirmation_TagMode(router: any, _this: this) {
    setTimeout(function () {
      //alert("shared 677",)
     // router.navigate(['processConfirmation', { mode: 'tag' }], { relativeTo: this.route });
      //router.navigate([`${environment.home}/tagMode/processConfirmation`, { mode: 'tag' }]);
      router.navigate([environment.home + '/processConfirmation', { mode: "tag" }]);
      _this?.hide();
    }, 0);
  }

  public GetTagModeQuestions(auditID, tagID, router) {
//    debugger;
    this.calendar_auditID = auditID;
    this.tagMode_tagID = tagID;

    this.show();
    var NTID = this.ntid;
    var tagMode: any;
    var selectedTags = [];
    var tagMode1:TagMode=new TagMode();
    
    // tagMode :TagMode[]=[];
    var tagsPayload :Tag[];
    this.GetTagModeByNTID(NTID).subscribe(res => {
      //alert(553)
      if(res.length>0 && res != null  && res[0].tagID) {

        this.calTagModeTagID=res[0].tags[0].tagID;
        this.calTagmodeID = res[0].tags[0].tagModeTagsID;
      }
      if(res.length>0 && res != null  && res[0].tagID) {
      tagMode = res[0];
      this.calTagModeTagID=tagMode.tags[0].tagID;
      this.calTagmodeID = tagMode.tags[0].tagModeTagsID;
      if(res.length>0 && res != null  && res[0].tagID) {
     
      console.log("546",tagMode)
      
      console.log("557",this.SharedServiceTags)
      this.fetchTagDetailsByTagID(tagID).subscribe(res => {
        console.log("shared 531",tagID)
        selectedTags = [];
        selectedTags = res;
        console.log("534",res)
        this.SharedServiceTags.isSkipQuestionDefined = res[0].isSkipQuestionDefined
      this.SharedServiceTags.isQuestionOverviewDefined = res[0].isQuestionOverviewDefined
      this.SharedServiceTags.isProgressPercentageDefined = res[0].isProgressPercentageDefined
      this.SharedServiceTags.isResultOverviewDefined =res[0].isResultOverviewDefined
      this.SharedServiceTags.isResumeTagDefined=res[0].isResumeTagDefined
      this.SharedServiceTags.isReportingEmailDefined=res[0].isReportingEmailDefined
        this.IsSkipEnabled = res[0].isSkipQuestionDefined;
        console.log("539",this.IsSkipEnabled)

        if (selectedTags.length <= 0) {
          this.hide();
          return;
        }

        if (!tagMode.tags) {
          this.hide();
          return;
        }

        tagMode.tags = selectedTags;
        tagMode.createdBy_NTID = this.ntid;
        console.log("550",selectedTags)
        console.log("551",this.tagTypeID)
        this.insertToTagMode(tagMode).subscribe(res => {
          var _this = this;
          console.log("587",tagMode)
          console.log("606",this.SharedServiceTags)
          setTimeout(function () {
            router.navigate([environment.home + '/processConfirmation', { mode: "tag" }]);
            _this.hide();
          }, 0);
        });
        selectedTags = [];
      }, err => console.log(err));
      }
      }
      else{
        
          var tagID1 = this.tagMode_tagID 
          // alert(943616)
          this.fetchTagDetailsByTagID(tagID1).subscribe(res1 => {
            tagsPayload=res1
            
           // debugger;
            //console.log("327",res)
            //alert(949620)
            console.log("349",res1);
            this.calTagModeTagID=res1[0].tagID;
             
            this.SharedServiceTags.isSkipQuestionDefined = res1[0].isSkipQuestionDefined
            this.SharedServiceTags.isQuestionOverviewDefined = res1[0].isQuestionOverviewDefined
            this.SharedServiceTags.isProgressPercentageDefined = res1[0].isProgressPercentageDefined
            this.SharedServiceTags.isResultOverviewDefined =res1[0].isResultOverviewDefined
            this.SharedServiceTags.isResumeTagDefined=res1[0].isResumeTagDefined
            this.SharedServiceTags.isReportingEmailDefined=res1[0].isReportingEmailDefined
              this.IsSkipEnabled = res1[0].isSkipQuestionDefined;
            //alert("payload")
            tagMode1.createdAt= null
            //tagMode1.createdBy= null
              tagMode1.createdBy_NTID= this.ntid
              tagMode1.createdBy_UserID= null
            // tagMode1.customModeID= 0
              tagMode1.isCompleted= false
              tagMode1.isDeleted= null
              //tagMode1.modifiedAt= null
              //tagMode1.modifiedBy= null
              //tagMode1.modifiedBy_UserID= null
              tagMode1.question= null
              tagMode1.questions= []
              tagMode1.tag= null
              //tagMode1.tagID= 0
              //tagMode1.tagMode1ID= 0
              tagMode1.tagName= null
              tagMode1.tags=tagsPayload;
              this.tagTypeID = res1[0].tagTypeID
            console.log("empty tagmode1",tagMode1)
            console.log("969",tagMode1)
            this.insertToTagMode(tagMode1).subscribe(res => {
              this.GetTagModeByNTID(NTID).subscribe(res => {
                //alert(656)
                //this.calTagmodeID = res1[0].tagModeTagsID;
                this.calTagmodeID = res[0].tags[0].tagModeTagsID;
                this.tagDisplayName=res[0].tags[0].tagDisplayName;
                console.log("656",res)
              })
              var _this = this;
              
              console.log("587",tagMode1)
              
              setTimeout(function () {
                router.navigate([environment.home + '/processConfirmation', { mode: "tag" }]);
                _this.hide();
              }, 0);
            });
            
          }, err => console.log(err));
          
          //this.tagMode =
        
        
        }
      err => console.error(err)
      });
  }


    public GetAuidtModeQuestions(auditID, router)
  {
    this.auditByAuditID(auditID).subscribe(res => {
      var audit = new Audit();
      audit = res;
      audit.startDate = new Date(audit.startDate);
      audit.endDate = new Date(audit.endDate);
      //audit.startTime = new Date(audit.startDate);
      //audit.endTime = new Date(audit.endDate);
      this.audit = audit;
      router.navigate([environment.home + '/calendar']);
    });
  }

  public GetMIMETypeByExtenstion(extension:any)
  {
    var fileType ="";

    if (extension == ".txt") {
      fileType = "text/plain";
    }
    else if (extension == ".pdf") {
      fileType = "application/pdf";
    }
    else if (extension == ".doc") {
      fileType = "application/vnd.ms-word";
    }
    else if (extension == ".docx") {
      fileType = "application/vnd.ms-word";
    }
    else if (extension == ".xls") {
      fileType = "application/vnd.ms-excel";
    }
    else if (extension == ".xlsx") {
      fileType = "application/vnd.ms-excel";
    }
    else if (extension == ".png") {
      fileType = "image/png";
    }
    else if (extension == ".jpg") {
      fileType = "image/jpeg";
    }
    else if (extension == ".jpeg") {
      fileType = "image/jpeg";
    }
    else if (extension == ".gif") {
      fileType = "image/gif";
    }
    else if (extension == ".csv") {
      fileType = "text/csv";
    }
    else if (extension == ".mp4") //for video files
    {
      fileType = "text/mp4";//check this line for mp4 video
    }

    return fileType;
  }

  dayDiff(d1, d2) {
    var a = moment([d1.getUTCFullYear(), d1.getUTCMonth(), d1.getUTCDate()]);
    var b = moment([d2.getUTCFullYear(), d2.getUTCMonth(), d2.getUTCDate()])
    var days = b.diff(a, 'days', true);
    return days;
  } 

 monthDiff(d1, d2) {
   var a = moment([d1.getUTCFullYear(),  d1.getUTCMonth(),   d1.getUTCDate()]);
   var b = moment([d2.getUTCFullYear(),  d2.getUTCMonth(),   d2.getUTCDate()])
   var months= b.diff(a, 'month', true);
   return months;
 } 

  getParsedDate(dte, tme) {
    try {
      var datePart = dte.split("T")[0];
      var parts = datePart.split('-');
      var hours = 0;
      var mins = 0;
      if (tme != null) {
        hours = +tme.split(':')[0];
        mins = +tme.split(':')[1];
      }
      var parsedDate = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2], hours, mins));
      //var result = parsedDate.getTime() + (parsedDate.getTimezoneOffset() * 60000);
      //console.log("result " + new Date(result));
      return parsedDate;
    }
    catch
    {
      new Date();
    }
  }


  compressImage(base64Img, imgType, resizingFactor, quality) {
    const imgToCompress = new Image();
    imgToCompress.src = base64Img;

    // showing the compressed image
    const canvas = document.createElement("canvas");
    const context = canvas.getContext("2d");

    const originalWidth = imgToCompress.width;
    const originalHeight = imgToCompress.height;

    const canvasWidth =  parseInt((originalWidth * resizingFactor).toString());
    const canvasHeight = parseInt((originalHeight * resizingFactor).toString());

    canvas.width = canvasWidth;
    canvas.height = canvasHeight;

    context.drawImage(imgToCompress, 0, 0, canvasWidth, canvasHeight);

    try {
      var base64Content = context.canvas.toDataURL(imgType, quality);
      return base64Content;
    } catch (error) {
      return base64Img;
    }       
  }
}

export class SearchFilter {
  fromDate: Date;
  toDate: Date;
  maxDate: Date;
  dataLoadInteravlInDays: number = 1;
  maxIntervalInMonths: number = 1;
  IsDesigner?:Number=1;
  moduleName: string;
  uSPName: string;
  ids : number[] = [];

  public vsSearchText: string;
  public asSearchText: string;
  public questionSearchText: string;
  public tagSearchText: string;
}
