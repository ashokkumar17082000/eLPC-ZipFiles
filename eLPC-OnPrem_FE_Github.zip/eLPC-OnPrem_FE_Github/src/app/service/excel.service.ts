import { Injectable } from '@angular/core';
import * as FileSaver from 'file-saver';
//import * as XLSX from 'sheetjs-style';
import * as XLSX from 'xlsx';
import { SharedService } from '../service/shared.service';


const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';

@Injectable()
export class ExcelService {

  constructor(private sharedService :SharedService) { }

  public exportAsExcelFile(json: any[], excelFileName: string): void {
    debugger;
    const myworksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(json);

    myworksheet['!cols'] = this.fitToColumn(json);

    var headerColumnCount = Object.keys(json[0]).length;
    for (var i = 0; i < headerColumnCount; i++) {
      let cellName = this.getSpreadSheetCellNumber(0, i); // Starts from first row 
      if (myworksheet[cellName] != undefined) {
        myworksheet[cellName].s = {             // set the style for target cell
          fill: {
            patternType: "solid",
            fgColor: { rgb: "FFFFA500" },       //00dce6f1
            bgColor: { rgb: "FFFFA500" }
          },
          font: {
            bold: true,
            color: { rgb: "00000000" }
          },
        };
      }
    }
    try {
      const myworkbook: XLSX.WorkBook = { Sheets: { 'Data': myworksheet }, SheetNames: ['Data'] };
      const excelBuffer: any = XLSX.write(myworkbook, { bookType: 'xlsx', type: 'array' });
      this.saveAsExcelFile(excelBuffer, excelFileName);
    } catch (error) {    }
    finally {
      // const myworkbook: XLSX.WorkBook = { Sheets: { 'Data': myworksheet }, SheetNames: ['Data'] };
      // const excelBuffer: any = XLSX.write(myworkbook, { bookType: 'xlsx', type: 'array' });
      // this.saveAsExcelFile(excelBuffer, excelFileName);
      this.sharedService.hide();
    }

  }


  private getSpreadSheetCellNumber(row, column) {
    let result = '';
    // Get spreadsheet column letter
    let n = column;
    while (n >= 0) {
      result = String.fromCharCode(n % 26 + 65) + result;
      n = Math.floor(n / 26) - 1;
    }
    // Get spreadsheet row number
    result += (row + 1);

    return result;
  };


  private fitToColumn(json) {
    const header = Object.keys(json[0]); // columns name
    // get maximum character of each column
    var wscols = [];
    for (var i = 0; i < header.length; i++) {  // columns length added
      wscols.push({ wch: (Math.max(Math.max(...json.map(r => r[header[i]] ? r[header[i]].toString().length : 0)), header.length) + 5) })
    }
    
    return wscols;
  }

  private saveAsExcelFile(buffer: any, fileName: string): void {
    debugger;
    const data: Blob = new Blob([buffer], {
      type: EXCEL_TYPE
    });
    
    FileSaver.saveAs(data, fileName + EXCEL_EXTENSION);
  }

}