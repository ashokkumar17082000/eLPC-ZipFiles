import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import { HttpHeaders } from '@angular/common/http';
import { QuestionDetail, Question, Choice, SingleLineText, MultipleLinesText, AnswerTypeNumber, AnswerTypeCurrency, AnswerTypeDateTime, HintImage, HintHyperLink, RatingScale, SubQuestion, QuestionHistory, QuestionProxy, vsasIDListData } from 'src/app/Datapool/QuestionModule/questions/question';
import { ValueStreamCategory, ValueStream } from 'src/app/Valuestream/valuestreams/valuestreamtemplate';
import { Assessor } from 'src/app/Assessor/assessor/assessortemplate';
import { SharedService } from '../service/shared.service';
import { Tag } from 'src/app/Tag/tag/tag';
import { map } from 'rxjs/operators';
import { throwError, timer } from 'rxjs';
import { catchError, retryWhen, delayWhen, mergeMap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})

export class QuestionService {

  private headers: HttpHeaders;
  apiURL: string;
  question: Question = new Question();

  constructor(private http: HttpClient, private sharedService: SharedService) {
    this.headers = new HttpHeaders();
    this.headers.append("Content-Type", "application/json");
    this.headers.append("Access-Control-Allow-Methods", "GET, POST, DELETE, PUT");

    this.headers.append("'Access-Control-Allow-Origin", "*");
    this.apiURL = this.sharedService.apiURL;
  }

  public getQuestions() {
    return this.http.get<Question[]>(this.apiURL + "Question/GetQuestions", { headers: this.headers, withCredentials: true });
  }

  public getCustomQuestions() {
    return this.http.get<Question[]>(this.apiURL + "Question/GetCustomQuestions", { headers: this.headers, withCredentials: true });
  }

  public getQuestionDetail() {
    return this.http.get<QuestionDetail[]>(this.apiURL + "Question/GetQuestionDetail", { headers: this.headers, withCredentials: true });
  }

  public getQuestionDetailByID(questionID: number) {
    return this.http.get<QuestionDetail>(this.apiURL + "Question/GetQuestionDetailByID" + '/' + questionID, { headers: this.headers, withCredentials: true });
  }

  public insertQuestion(question: Question) {
    return this.http.post<Question>(this.apiURL + "Question/InsertQuestion", question, { withCredentials: true });
  }

  public hintImagesByQuestionID(questionID: number) {
    return this.http.get<HintImage[]>(this.apiURL + "Question/HintImagesByQuestionID" + '/' + questionID, { withCredentials: true });
  }

  public hintHyperLinksByQuestionID(questionID: number) {
    return this.http.get<HintHyperLink[]>(this.apiURL + "Question/HintHyperLinksByQuestionID" + '/' + questionID, { withCredentials: true });
  }

  public getChoicesByQuestionID(questionID: number) {
    return this.http.get<Choice[]>(this.apiURL + "Question/GetChoicesByQuestionID" + '/' + questionID, { withCredentials: true });
  }

  private handleError(error: HttpErrorResponse): Observable<never> {
    console.error('API request failed:', error);
    return throwError('An error occurred while fetching choices. Please try again.'); // Return a user-friendly error message
  }

  getChoicesByQuestionID_new(questionID: number): Observable<Choice[]> {
    const url = `${this.apiURL}Question/GetChoicesByQuestionID/${questionID}`;

    return this.http.get<Choice[]>(url, { withCredentials: true })
      .pipe(
        retryWhen(errors =>
          errors.pipe(
            mergeMap((error: HttpErrorResponse, retryCount: number) => {
              if ((error.status === 0 || error.status === 499) && retryCount < 3){
                console.log(`HTTP 499 error occurred (retry attempt ${retryCount + 1})`);
                return timer(200); // Delay before retrying
              }
              return throwError(error); // Propagate the error if not a 499 or max retries reached
            })
          )
        ),
        catchError(this.handleError) // Handle any other errors
      );
  }

  public singleLineTextByQuestionID(questionID: number) {
    return this.http.get<SingleLineText[]>(this.apiURL + "Question/SingleLineTextByQuestionID" + '/' + questionID, { withCredentials: true });
  }

  public multipleLinesTextByQuestionID(questionID: number) {
    return this.http.get<MultipleLinesText[]>(this.apiURL + "Question/MultipleLinesTextByQuestionID" + '/' + questionID, { withCredentials: true });
  }

  public numberSettingsByQuestionID(questionID: number) {
    return this.http.get<AnswerTypeNumber>(this.apiURL + "Question/NumberSettingsByQuestionID" + '/' + questionID, { withCredentials: true });
  }

  public currencySettingsByQuestionID(questionID: number) {

    return this.http.get<AnswerTypeCurrency>(this.apiURL + "Question/CurrencySettingsByQuestionID" + '/' + questionID, { withCredentials: true });
  }

  public dateTimeSettingsByQuestionID(questionID: number) {

    return this.http.get<AnswerTypeDateTime>(this.apiURL + "Question/DateTimeSettingsByQuestionID" + '/' + questionID, { withCredentials: true });
  }

  public ratingScaleByQuestionID(questionID: number) {

    return this.http.get<RatingScale>(this.apiURL + "Question/RatingScaleByQuestionID" + '/' + questionID, { withCredentials: true });
  }

  public subQuestionsByQuestionID(questionID: number) {
    return this.http.get<SubQuestion[]>(this.apiURL + "Question/SubQuestionsByQuestionID" + '/' + questionID, { withCredentials: true });
  }

  public valueStreamTempChange(valueStreamTempID: number) {
    return this.http.get<ValueStreamCategory[]>(this.apiURL + "ValueStreamTemplate/GetValueStreamCategoryByTemplateID" + '/' + valueStreamTempID, { withCredentials: true });

  }

  public valueStreamCategoryChange(valueStreamCategoryID: number) {
    return this.http.get<ValueStream[]>(this.apiURL + "ValueStreamTemplate/GetValueStreamsByCategoryID" + '/' + valueStreamCategoryID, { withCredentials: true });
  }

  public valueStreamsByQuestionID(questionID: number) {
    return this.http.get<ValueStream[]>(this.apiURL + "Question/ValueStreamsByQuestionID" + '/' + questionID, { withCredentials: true });
  }

  public assessorsByQuestionID(questionID: number) {
    return this.http.get<Assessor[]>(this.apiURL + "Question/AssessorsByQuestionID" + '/' + questionID, { withCredentials: true });
  }

  public tagsByQuestionID(questionID: number) {
    return this.http.get<Tag[]>(this.apiURL + "Question/TagsByQuestionID" + '/' + questionID, { withCredentials: true });
  }

  public deleteQuestion(question: Question) {
    return this.http.post<Question>(this.apiURL + "Question/DeleteQuestion", question, { withCredentials: true });
  }

  public getQuestionTemplateHistory(templateID: number) {
    return this.http.get<QuestionHistory[]>(this.apiURL + "Question/GetQuestionHistory" + '/' + templateID, { headers: this.headers, withCredentials: true });
  }

  public questionRestoreByTemplateHistoryID(historyID: number) {
    return this.http.get(this.apiURL + "Question/QuestionRestoreByHistoryID" + '/' + historyID, { withCredentials: true });
  }

  public questionProxiesByQuestionID(questionID: number) {
    return this.http.get(this.apiURL + "Question/QuestionProxiesByQuestionID" + '/' + questionID, { withCredentials: true });
  }

  public insertQuestionProxy(questionProxy: QuestionProxy) {
    return this.http.post<QuestionProxy>(this.apiURL + "Question/InsertQuestionProxy", questionProxy, { withCredentials: true });
  }

  DownloadQuestionAttachment(filePath: string, fileType: string): Observable<any> {
    let fileExtension = fileType;
    let input = filePath;
    return this.http.post(this.apiURL + "DownloadFile/DownloadQuestionAttachment" + "/" + input, '', { responseType: 'blob' })
      .pipe(
        map((res: any) => {
          return new Blob([res], { type: fileExtension });
          // return new Blob([res], { type : "text/plain;charset=utf-8" });
          // return new Blob([res], { type: 'application/pdf' });
        })
      );
  }
  public fetchVSASListByID(type: string, mode:string, questionId:number, tagId:number) {
    return this.http.get(this.apiURL + "Question/FetchVSASListByID" + '/' + type + '/' + mode + '/' + questionId + '/' + tagId, { withCredentials: true });
  }
}
