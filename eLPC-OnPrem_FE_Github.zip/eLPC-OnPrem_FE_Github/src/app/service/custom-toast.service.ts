import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})
export class CustomToastService {
  constructor(public toastrService: ToastrService) { }

  /** Method is responsible to show success message. */
  public showSuccess(text : any) {
    this.toastrService.error(text.friendlyMessage, text.errorNumber + ' ' + text.message, {
      positionClass: 'toast-bottom-right',
      tapToDismiss: true,
      disableTimeOut: true
    });
  }
  
  /** Method is responsible to show error message. */
  public showError(text : any) {
    this.toastrService.error(text.friendlyMessage,'', {
      positionClass: 'toast-bottom-right',
      tapToDismiss: true,
      disableTimeOut: true
    });
  }
  
    /** Method is responsible to show warning message. */
  public showWarning(text : any) {
    this.toastrService.error(text.friendlyMessage, '', {
      positionClass: 'toast-bottom-right',
      tapToDismiss: true,
      disableTimeOut: true
    });
  }
  
  /** Method is responsible to show info message. */
  public showInfo(text : any) {
    this.toastrService.error(text.friendlyMessage, text.errorNumber + ' ' + text.message, {
      positionClass: 'toast-bottom-right',
      tapToDismiss: true,
      disableTimeOut: true
    });
  } 
}