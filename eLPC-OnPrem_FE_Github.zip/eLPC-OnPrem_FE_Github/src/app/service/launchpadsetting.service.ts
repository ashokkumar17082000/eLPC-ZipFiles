
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';  
import 'rxjs/add/operator/map';
import { HttpHeaders } from '@angular/common/http'; 
import { AssessorTemplate, Assessor, AssessorProxy, AssessorStreamHistory } from 'src/app/Assessor/assessor/assessortemplate';
import { reportText } from 'src/app/Report/launch-pad-c/launchpadsetting';
import { SharedService } from './shared.service';
import { reportrestore } from 'src/app/Report/launch-pad-c/launchpadsetting';

@Injectable({
  providedIn: 'root',
})

export class LaunchpadsettingService {

  private headers: HttpHeaders;
  apiURL: string;
  assessorTemplate: AssessorTemplate = new AssessorTemplate();

  private httpHeaders = new HttpHeaders().set('Content-Type', 'application/json').
                        set('Accept', 'application/json');

  optionsStatic = {
  headers: this.httpHeaders,
  params: new HttpParams(),
  withCredentials: true
  };

  constructor(private http: HttpClient, private sharedService: SharedService) {
    this.headers = new HttpHeaders();
    //this.headers.append("Content-Type", "application/json");
    this.headers.append("Access-Control-Allow-Methods", "GET, POST, DELETE, PATCH, PUT, OPTIONS");
    this.headers.append("Access-Control-Allow-Origin", "*");
    this.headers.append("Access-Control-Allow-Credentials", "true");
    this.apiURL = this.sharedService.apiURL;
  }


  public getLaunchpadSetting() {

    return this.http.get<reportText[]>(this.sharedService.apiURL + "Launchpadsetting/GetLaunchpad", { headers: this.headers , withCredentials: true });
  }
  

  public insertLaunchpadURL(reportText: reportText) {
    return this.http.post<reportText>(this.apiURL + "Launchpadsetting/insertLaunchpadURL", reportText, {withCredentials: true} );
  }

  public LaunchPadrestore(historyID: number) {
    return this.http.get(this.apiURL + "Launchpadsetting/LaunchpadHistoryID" + '/' + historyID, {withCredentials: true});
  }
  public getrestoredata() {

    return this.http.get<reportrestore[]>(this.sharedService.apiURL + "Launchpadsetting/GetRestoredata", { headers: this.headers , withCredentials: true });
  }
  
}
