import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { SharedService } from './shared.service';
import { UserProfileUpdateVSAS, UserProfileValueStreamAssessor } from 'src/app/UserProfile/userprofile-c/userProfile';
import { Result } from '../main/body/shared/common';

@Injectable({
  providedIn: 'root'
})

export class UserProfileService {

  private headers: HttpHeaders;
  apiURL: string;

  constructor(private http: HttpClient, private sharedService: SharedService) {
    this.headers = new HttpHeaders();
    this.headers.append("Content-Type", "application/json");
    this.headers.append("Access-Control-Allow-Methods", "GET, POST, DELETE, PUT");
    this.headers.append("'Access-Control-Allow-Origin", "*");
    this.apiURL = this.sharedService.apiURL;
  }

  public getUserProfileVSAS() {
    return this.http.get<UserProfileValueStreamAssessor>(this.apiURL + "Common/GetUserProfileVSAS", { headers: this.headers, withCredentials: true });
  }

  public addEditUserProfile(userProfile: UserProfileValueStreamAssessor) {
    return this.http.post<Result>(this.apiURL + "Common/AddEditUserProfileVSAS", userProfile, {withCredentials: true} );
  }

  public updateUserProfileVSAS(updateVSAS: UserProfileUpdateVSAS) {
    return this.http.post<Result>(this.apiURL + "Common/UpdateUserProfileVSAS", updateVSAS, {withCredentials: true} );
  }

}
