import { TestBed } from '@angular/core/testing';

import { CustomToastService } from './custom-toast.service';
import { ToastrModule } from 'ngx-toastr';

describe('CustomToastService', () => {
  beforeEach(() => TestBed.configureTestingModule({

   imports:[ToastrModule.forRoot()]
  }));

  it('should be created', () => {
    const service: CustomToastService = TestBed.get(CustomToastService);
    expect(service).toBeTruthy();
  });
});
