import { TestBed } from '@angular/core/testing';

import { TagModeService } from './tag-mode.service';
import { HttpClientModule } from '@angular/common/http';

describe('TagModeService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientModule,]

  }));

  it('should be created', () => {
    const service: TagModeService = TestBed.get(TagModeService);
    expect(service).toBeTruthy();
  });
});
