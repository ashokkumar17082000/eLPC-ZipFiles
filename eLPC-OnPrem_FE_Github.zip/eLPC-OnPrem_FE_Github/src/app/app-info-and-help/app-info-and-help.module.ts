import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AppInfoAndHelpRoutingModule } from './app-info-and-help-routing.module';
import {InfoAndHelpComponent} from './info-and-help/info-and-help.component'
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
  declarations: [InfoAndHelpComponent],
  imports: [
    CommonModule,
    AppInfoAndHelpRoutingModule,
    NgxPaginationModule,
    PaginationModule.forRoot()
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class AppInfoAndHelpModule { }
