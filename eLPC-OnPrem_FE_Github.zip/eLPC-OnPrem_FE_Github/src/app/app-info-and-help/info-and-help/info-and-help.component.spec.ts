import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InfoAndHelpComponent } from './info-and-help.component';

describe('InfoAndHelpComponent', () => {
  let component: InfoAndHelpComponent;
  let fixture: ComponentFixture<InfoAndHelpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InfoAndHelpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InfoAndHelpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
