import { Component, OnInit } from '@angular/core';
import { LanguageService } from 'src/app/language.service';
import { infoAndHelpService } from 'src/app/service/infoAndHelp.service';
import { SharedService } from 'src/app/service/shared.service';
import { User } from 'src/app/main/body/shared/common';



@Component({
  selector: 'app-info-and-help',
  templateUrl: './info-and-help.component.html',
  styleUrls: ['./info-and-help.component.css']
})
export class InfoAndHelpComponent implements OnInit {

  labels:any;
  _subscription:any;

  PlantName:string;

  designerUserList:User[] = [];
  morUserList:User[] = [];
  page: number = 1;
  resultPerPage: number = 10;
  startPage: number;
  endPage: number;
  masterOfRole:string = "";
  UserDetails: any;
  displayName: string | null = "";
  // Define the email properties
   toAddress = 'eLPC Service Mailbox (CC/QMM) <ServiceMailbox.eLPC@de.bosch.com>';
   subject = 'eLPC Support / Service Mailbox';
  
  constructor(private sharedService: SharedService, private infoAndHelpService: infoAndHelpService
              ,private local_label:LanguageService
              ) {this.PlantName = this.sharedService.PlantNameSelected; }

  ngOnInit() {
    console.log("info and help")
    this.displayName = sessionStorage.getItem('displayName');
    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe((value)=>{
      this.labels = value;
    })

    this.getMorUser();
    //this.sharedService.hide();
  }

  public getMorUser(){
    this.sharedService.show();
    //debugger;
    this.masterOfRole = this.sharedService.currentUserInfo.idmMor;
    this.sharedService.getADUsersByGroupName(this.masterOfRole).subscribe(res => {
      //this.sharedService.hide();
      this.morUserList = res;
      this.getDesignerUser();

    })
  }

  public getDesignerUser(){
    //this.sharedService.show();
    let groupName = this.sharedService.currentUserInfo.idMDesignerRole;
    this.sharedService.getADUsersByGroupName(groupName).subscribe(res => {
      //debugger;
      //console.log(res);
      this.sharedService.hide();
      this.sharedService.sharedDesignerUser = res.sort((a,b)=> a.ntid.localeCompare(b.ntid));
      this.designerUserList = res.sort((a,b)=> a.ntid.localeCompare(b.ntid));
      //this.designerUserList.sort((a,b)=>{return b.ntid - a.ntid;});

    })
  }

  public doFilter = (value: string) => {
    //this.UserDetails = JSON.parse(JSON.stringify(this.designerUserList)).sort();
    this.designerUserList = JSON.parse(JSON.stringify(this.sharedService.sharedDesignerUser)).sort();

    if (value.length > 0) {
      this.designerUserList = this.designerUserList.filter(x =>
        x.ntid.trim().toLowerCase().includes(value.trim().toLowerCase()) ||
        x.userName.trim().toLowerCase().includes(value.trim().toLowerCase()) ||
        x.emailAddress.trim().toLowerCase().includes(value.trim().toLowerCase())
      );
      this.page = 1;
    }
  }

  isFirstPage() {
    if (this.page == 1) {
      return;
    }
    else {
    }

    this.page = 1;
    this.startPage = (this.page - 1) * 4 + 1;
    this.endPage = this.page * this.resultPerPage;
  }

  isLastPage() {
    if (Math.ceil(this.designerUserList.length / this.resultPerPage) <= this.page) {
      return;
    }
    else {

    }

    this.page = Math.ceil(this.designerUserList.length / this.resultPerPage);
    this.startPage = (this.page - 1) * 4 + 1;
    this.endPage = this.page * this.resultPerPage;
  }

  pageChanged(event): void {

    if (event == 0) {
      return;
    }
    else if (Math.ceil(this.designerUserList.length / this.resultPerPage) < event) {
      return;
    }
    else {
      this.page = event;
      this.startPage = (this.page - 1) * 4 + 1;
      this.endPage = this.page * this.resultPerPage;
    }
  }

  eLPC_Service_MailboxClick() {

    let body = `Hello eLPC Support,
    
    I am contacting you because of:
    
    Suggestions for improvement ()
    Occurrence of a bug ()
    Grant access to the tool for Standard / Designer users ()
    Power BI topics ()
    Super OPL topics ()
    Other topics ()
    
    My plant/instance:
    
    Detailed description of the problem:
    
Mit freundlichen Grüßen / Best regards
${this.displayName}
  `;
     // Construct the mailto URL
     const mailtoUrl = `mailto:${this.toAddress}?subject=${encodeURIComponent(this.subject)}&body=${encodeURIComponent(body)}`;

     window.location.href = mailtoUrl;

  }

  Bosch_Connect_eLPC_communityClick() {
    const Bosch_Connect_eLPC_community_url = 'https://connect.bosch.com/communities/service/html/communitystart?communityUuid=f5da04e3-5797-4a8d-ab1b-6a78f6c11727';
    window.open(Bosch_Connect_eLPC_community_url, '_blank');
  }

  eLPC_FAQClick() {
    const eLPC_FAQ_url = 'https://connect.bosch.com/wikis/home?lang=de-de#!/wiki/W3f3fd23546aa_471b_9a42_29a5917fb5fa/page/eLPC%20FAQ';
    window.open(eLPC_FAQ_url, '_blank');
  }

  downloadFile(): void {
    //debugger;
    this.sharedService.downloadServiceMailboxFile().subscribe(
      (response: Blob) => {
       // debugger;
        const blob = new Blob([response], { type: 'application/octet-stream' });
 
        // Create a temporary URL for the blob
        const url = window.URL.createObjectURL(blob);
 
        // Create a link element and trigger the download
        const anchor = document.createElement('a');
        anchor.download = 'eLPC_Support_Service_Mailbox.oft';
        anchor.href = url;
        anchor.style.display = 'none';
        document.body.appendChild(anchor);
 
        anchor.click();
 
        // Clean up after the download
        document.body.removeChild(anchor);
        window.URL.revokeObjectURL(url);
      },
      (error) => {
        console.error('File download error:', error);
        // Handle error gracefully, e.g., display an error message to the user
      }
    );
  }


}
