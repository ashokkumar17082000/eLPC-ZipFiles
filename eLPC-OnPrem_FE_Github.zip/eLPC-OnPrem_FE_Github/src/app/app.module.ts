import 'flatpickr/dist/flatpickr.css';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { NO_ERRORS_SCHEMA } from '@angular/core';

import { CUSTOM_ELEMENTS_SCHEMA,NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ErrorComponent } from './error/error.component';
//import { HttpModule } from '@angular/http';
//import { CheckAuthComponent } from './check-auth/check-auth.component';
import { CheckAuthComponent } from './check-auth/check-auth.component';
import { MainComponent } from './main/main.component';
import { HeaderComponent } from './main/header/header.component';
import { FooterComponent } from './main/footer/footer.component';
import { BodyComponent } from './main/body/body.component';
import { LeftnavComponent } from './main/body/leftnav/leftnav.component';
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { AlertModule } from 'ngx-bootstrap/alert';
import { ModalModule } from 'ngx-bootstrap/modal';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
//import { BsDatepickerModule } from 'ngx-bootstrap';
//import { DashboardComponent } from './main/body/dashboard/dashboard.component';
import { CarouselModule } from 'ngx-bootstrap/carousel';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { ProgressbarModule } from 'ngx-bootstrap/progressbar';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { NgxPaginationModule } from 'ngx-pagination';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
//import { CalendarComponent } from './main/body/calendar/calendar.component';
//import { RoleComponent } from './main/body/role/role.component';
//import { UserComponent } from './main/body/user/user.component';
// import { ValueStreamsComponent } from './main/body/value-streams/value-streams.component';
// import { ValueStreamsEditComponent } from './main/body/value-streams/value-streams.edit.component';
// import { ValueStreamsLockComponent } from './main/body/value-streams/value-streams.lock.component';
//import { AssessorsComponent } from './main/body/assessors/assessors.component';
//import { AssessorEditComponent } from './main/body/assessors/assessors.edit.component';
//import { AssessorsComponent } from './main/body/assessors/assessors.component';
//import { QuestionsComponent } from './main/body/questions/questions.component';
//import { DataPoolComponent } from './main/body/data-pool/data-pool.component';
//import { RecycleBinComponent } from './main/body/recycle-bin/recycle-bin.component';
// import { TagListComponent } from './main/body/tag/tag-list/tag-list.component';
// import { TagEditComponent } from './main/body/tag/tag-edit/tag-edit.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
//import { UserEditComponent } from './main/body/user/user.addedit.component';
//import { ProcessConfirmationComponent } from './main/body/process-confirmation/process-confirmation.component';
//import { AddEditRoleComponent } from './main/body/role/role.addedit.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
//import { EmployeeComponent } from './main/body/employee/employee.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';
import { MyFilterPipe } from './my-filter.pipe';
import { OrderModule } from 'ngx-order-pipe';
import { AutocompleteLibModule } from 'angular-ng-autocomplete';
import { DatePipe } from '@angular/common';
//import { ShuffleModeComponent } from './main/body/shuffle-mode/shuffle-mode.component';
//import { CustomModeComponent } from './main/body/custom-mode/custom-mode.component';
//import { AuditComponent } from './main/body/audit/audit.component';
import { CalendarModule, DateAdapter } from 'angular-calendar';
import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';
//import { TagLockComponent } from './main/body/tag/tag-edit/tag.lock.component';
//import { AssessorLockComponent } from './main/body/assessors/assessor.lock.component';
import { CanActivateGuard } from './service/auth.guard.service';
import { CanActivateUser } from './service/authguard.standarduser.service';
//import { DeviationComponent } from './main/body/deviation/deviation.component';
//import { TagModeComponent } from './main/body/tag-mode/tag-mode.component';

//import { TagModeComponent } from './main/body/tag-mode/tag-mode.component';
//import { DataPoolEditComponent } from './main/body/data-pool/data-pool-edit.component';
//import { ColumnFilterPipe } from './service/common/column-filter.pipe';
import { SafeHtmlPipe } from './service/common/safeHtml.pipe';
import { SharedModule } from './shared/shared.module';
//import { QuestionLockComponent } from './main/body/questions/questions.lock.component';
import { FlatpickrModule } from 'angularx-flatpickr';

import { ScrollingModule } from '@angular/cdk/scrolling';
import { TestComponent } from './test/test.component';
//import { AdminreportComponent } from './main/body/reports/adminreport/adminreport.component';
//import { UserreportComponent } from './main/body/reports/userreport/userreport.component';
import { HttpInterceptorService } from './service/interceptor/http-interceptor.service';
import { PlantComponent } from './main/body/plant/plant.component';
//import { SuperOPLComponent } from './main/body/super-opl/super-opl.component';
import { AuthErrorComponent } from './auth-error/auth-error.component';
//import { DeviationDataPoolComponent } from './main/body/deviation-data-pool/deviation-data-pool.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
//import { UserProfileComponent } from './main/body/user-profile/user-profile.component';
// import { SelectComponent } from './main/body/select/select.component';

import { registerLocaleData } from '@angular/common';
import localeFr from '@angular/common/locales/fr';
import localeDe from '@angular/common/locales/de';
import localeZh from '@angular/common/locales/zh';
import localeRo from '@angular/common/locales/ro';
import localePt from '@angular/common/locales/Pt';
import localeTh from '@angular/common/locales/th';
import localeRu from '@angular/common/locales/ru';
import localePl from '@angular/common/locales/pl';
import localeEs from '@angular/common/locales/es';
import localeMs from '@angular/common/locales/ms';
import localeJa from '@angular/common/locales/ja';
import localeNl from '@angular/common/locales/nl';
import localeHu from '@angular/common/locales/hu';
import localeIt from '@angular/common/locales/it';
import localeCs from '@angular/common/locales/cs';
import localeKo from '@angular/common/locales/ko';
import localeTr from '@angular/common/locales/tr';
import localeId from '@angular/common/locales/id';
import localeSk from '@angular/common/locales/sk';
//import { InfoAndHelpComponent } from './main/body/info-and-help/info-and-help.component';
//import { PowerBIExportComponent } from './main/body/powerbi-export/powerbi-export.component';
import { ExcelService } from './service/excel.service';
//import { CalenderListComponent } from './main/body/calender-list/calender-list.component';
//import { MergeComponent } from './main/body/merge/merge.component';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { MyModalComponentComponent } from './my-modal-component/my-modal-component.component';
//import { LaunchpadsettingsComponent } from './main/body/reports/launchpadsettings/launchpadsettings.component';

registerLocaleData(localeFr);
registerLocaleData(localeDe);
registerLocaleData(localeZh);
registerLocaleData(localeRo);
registerLocaleData(localePt);
registerLocaleData(localeTh);
registerLocaleData(localeRu);
registerLocaleData(localePl);
registerLocaleData(localeEs);
registerLocaleData(localeMs);
registerLocaleData(localeJa);
registerLocaleData(localeNl);
registerLocaleData(localeHu);
registerLocaleData(localeIt);
registerLocaleData(localeCs);
registerLocaleData(localeKo);
registerLocaleData(localeTr);
registerLocaleData(localeId);
registerLocaleData(localeSk);

@NgModule({
  declarations: [
    AppComponent,    
    ErrorComponent,
    CheckAuthComponent,
   MainComponent,
    HeaderComponent,
    FooterComponent,
    BodyComponent,
    LeftnavComponent,
   // DashboardComponent,
    //CalendarComponent,
   // RoleComponent,
   // UserComponent,    
    // ValueStreamsComponent,
    // ValueStreamsEditComponent,
    // ValueStreamsLockComponent,
    // AssessorsComponent,
    // AssessorEditComponent,
    // AssessorLockComponent,
  //  DataPoolComponent,
   // RecycleBinComponent,
    // TagListComponent,
    // TagEditComponent,
   // QuestionsComponent,
   // QuestionLockComponent,
   // UserEditComponent,
    //ProcessConfirmationComponent,
   // AddEditRoleComponent,
   // EmployeeComponent,
    MyFilterPipe,
    //ShuffleModeComponent,
   // CustomModeComponent,
    //TagModeComponent,
   // AuditComponent,
    //TagLockComponent,
   // DeviationComponent,
   // DataPoolEditComponent,
    //ColumnFilterPipe,
    SafeHtmlPipe,
    TestComponent,
    //AdminreportComponent,
   // UserreportComponent,
    PlantComponent,
   // SuperOPLComponent,
   AuthErrorComponent,
   MyModalComponentComponent,
   // DeviationDataPoolComponent,
   // InfoAndHelpComponent,
   // PowerBIExportComponent,
    //CalenderListComponent,
    //MergeComponent,
    //UserprofileComponent,
    //LaunchPadSettingsCComponent
    
    // SelectComponent
  ],
  exports: [
    MyFilterPipe  // Export the pipe here
  ],
  entryComponents: [
    AuthErrorComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AutocompleteLibModule,
    FlatpickrModule.forRoot(),
    TimepickerModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    OrderModule,
    SharedModule,
    AppRoutingModule,
    DragDropModule,
    NgMultiSelectDropDownModule.forRoot(),
    CollapseModule.forRoot(),
    AlertModule.forRoot(),
    ModalModule.forRoot(),
    BsDatepickerModule.forRoot(),
    BsDropdownModule.forRoot(),
    CarouselModule.forRoot(),
    TabsModule.forRoot(),
    ProgressbarModule.forRoot(),
    PaginationModule.forRoot(),
    ToastrModule.forRoot(),
    PopoverModule.forRoot(),
    TooltipModule.forRoot(),
    NgxPaginationModule,
    BrowserAnimationsModule,
    HttpClientModule,
    CalendarModule.forRoot({
      provide: DateAdapter,
      useFactory: adapterFactory
    }),
    ScrollingModule
  ],
  providers: [
    DatePipe, CanActivateGuard, CanActivateUser,  ExcelService,
    { provide: HTTP_INTERCEPTORS, useClass: HttpInterceptorService, multi: true }
  ],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA,NO_ERRORS_SCHEMA],
  
})
export class AppModule {
  
 }
