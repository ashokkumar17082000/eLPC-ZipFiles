import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AssessorRRoutingModule } from './assessor-r-routing.module';
import { AssessorEditComponent } from '../assessor/assessors.edit.component';
import { AssessorComponent } from '../assessor/assessor.component';
import { AssessorLockComponent } from '../assessor/assessor.lock.component';
import { FormsModule,ReactiveFormsModule  } from '@angular/forms';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { NgxPaginationModule } from 'ngx-pagination';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { OrderModule } from 'ngx-order-pipe';
import { DatePipe } from '@angular/common';
import { SharedModule } from 'src/app/shared/shared.module'
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';

@NgModule({
  declarations: [AssessorComponent,AssessorEditComponent,AssessorLockComponent],
  imports: [
    CommonModule,
    AssessorRRoutingModule,
    FormsModule,
    PaginationModule.forRoot(),
    BsDatepickerModule.forRoot(),
    NgMultiSelectDropDownModule.forRoot(),
    OrderModule,
    SharedModule,
    ReactiveFormsModule,
    NgxPaginationModule
  ],
  exports: [AssessorComponent,AssessorEditComponent,AssessorLockComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AssessorRModule { }
