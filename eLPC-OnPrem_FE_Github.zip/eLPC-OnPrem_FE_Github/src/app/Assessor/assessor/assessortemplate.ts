import { User } from "src/app/main/body/shared/common";

export class AssessorTemplate
{
  assessorTemplateID: number;
  assessorTemplateDisplayID: number;
  assessorTemplateName: string;
  isLocked?: boolean;
  modifiedAt: Date;
  createdAt: Date;
  isTargetFrequencyDefined?: boolean;
  createdBy?: string;
  modifiedBy?: string;
  assessorCategories: AssessorCategory[];
  assessors: Assessor[];
  resultCode: number;
  createdBy_NTID?: string;
  modifiedBy_NTID?: string;
  isAccessible?: boolean;
}

export class AssessorCategory {
  assessorCategoryID?: number;
  assessorCategoryName?: string;
  isDataRequiredToFitSpecLength?: boolean;
  minimumNoOfCharacters?:number;
  maximumNoOfCharacters?: number;
  isDataRequired?:boolean;
}

export class AssessorStreamHistory {
  assessorTemplateHistoryID ?:number;
  assessorTemplateHistoryDisplayID ?:number;
  assessorTemplateID ?:number;
  assessorTemplateName ?:string;
  ModifiedBy_NTID ?:any;
  ModifiedBy ?:string;
  modifiedAt : Date;
  createdAt : Date;
}

export class Assessor {
  id?: number; //for assigned Assessors in questions table
  assessorID?: number;
  assessorDisplayID?: number;
  assessorName?: string;
  category?: string;
  CreatedBy?:string;
  Isdeleted?:boolean=false;
  assessorCategoryName?: string;
  targetFrequencyValue?: number;
  targetFrequencyLowLimit?: string;
  targetFrequencyTypeID?:number;
  isMandatoryAssessor?:boolean; //for tag
  // assessorTemplateName: string; // for dispalying in process confirmation part...without 1 is not working in name
  assessorCategoryID?: number;
  assessorTemplateID?: number;
  assessorTemplateName?: string;
}

export class AssessorProxy {
  id?: number;
  assessorTemplateID?: number;
  proxies: User[];
  createdBy_NTID?: string;
  modifiedBy_NTID?: string;
  resultCode: number;
  proxy: string; //for fetching purpose
  ntid:string;
  userName:string;
  isLocked: boolean;
}
