import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ValuesreamRRoutingModule } from './valuesream-r-routing.module';
import {ValueStreamsComponent} from '../valuestreams/value-streams.component';
import { ValueStreamsEditComponent } from '../valuestreams/value-streams.edit.component';
import { ValueStreamsLockComponent } from '../valuestreams/value-streams.lock.component';
import { FormsModule,ReactiveFormsModule  } from '@angular/forms';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { NgxPaginationModule } from 'ngx-pagination';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { OrderModule } from 'ngx-order-pipe';
import { DatePipe } from '@angular/common';
import { SharedModule } from 'src/app/shared/shared.module'
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';

@NgModule({
  declarations: [ValueStreamsComponent,
    ValueStreamsEditComponent,
    ValueStreamsLockComponent,],

  imports: [
    CommonModule,
    ValuesreamRRoutingModule,
    FormsModule,
    PaginationModule.forRoot(),
    BsDatepickerModule.forRoot(),
    NgMultiSelectDropDownModule.forRoot(),
    TimepickerModule.forRoot(),
    OrderModule,
    SharedModule,
    ReactiveFormsModule,
    NgxPaginationModule
  ],
  exports: [ValueStreamsEditComponent,ValueStreamsLockComponent,ValueStreamsComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class ValuesreamRModule { }
