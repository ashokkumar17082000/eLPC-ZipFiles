import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { SharedService } from 'src/app/service/shared.service';
import { ValueStreamTemplate, ValueStreamCategory, ValueStream, Shift, ValueStreamHistory } from './valuestreamtemplate';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ValuestreamTemplateService } from 'src/app/service/common/valuestreamtemplate.service';
import { OrderPipe } from 'ngx-order-pipe';
import { DatePipe, formatDate } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { User } from 'src/app/main/body/shared/common';
import { CommonService } from 'src/app/service/common/common.service';
import { Router } from '@angular/router';
import { LanguageService } from 'src/app/language.service';
import { environment } from 'src/environments/environment';

declare var $;


@Component({
  selector: 'app-value-streams',
  templateUrl: './value-streams.edit.component.html',
  styleUrls: ['./value-streams.component.css'],
  providers: [DatePipe]
})

export class ValueStreamsEditComponent implements OnInit {

  @ViewChild('fileInput') fileInput;
  @ViewChild('alertPopup') warningModal: TemplateRef<any>;
  @ViewChild('successPopup') successModal: TemplateRef<any>;
  @ViewChild('deletePopup') deleteModal: TemplateRef<any>;

  dateTimeFormat = environment.dateTimeFormat;
  isDisabled: boolean = true;
  EditableCol: any
  ValueStreamName: string
  currentrow: number;
  currentcol: number
  SelectedIndex : number =0
  valueStreamCategory: ValueStreamCategory = new ValueStreamCategory();
  valueStreamHistoryDetails: ValueStreamHistory[];
  shift: Shift = new Shift();
  
  actualShift: Shift = null;
  actualRowPostion: number = -1;
  actualCategory: ValueStreamCategory = null;

  page: number = 1;
  resultPerPage: number = 10;
  startPage: number;
  endPage: number;

  modalRef: BsModalRef | null;
  modalRef2: BsModalRef;

  dataTable: any;
  weekList: any[];
  lastcol: number
  massage = null;

  valueStreamTemplate: ValueStreamTemplate = new ValueStreamTemplate();
  valueStreamCategoryList: ValueStreamCategory[] = [];
  valueStream: ValueStream = new ValueStream();
  valueStreams: ValueStream[] = [];
  isAdd: boolean = false;
  isEdit: boolean = false;
  onchange : boolean = false;
  onselect : boolean = false;

  filterType: string = "test";
  headeFilterName: string = "";


  templateId: number;

  // ***************************************for multiselext drodown******
  myForm: FormGroup;
  ShowFilter = true;
  showAll = true;
  limitSelection = false;
  cities: Array<any> = [];
  lockFilters: Array<any> = [];
  selectedItems: Array<any> = [];
  dropdownSettings: any;
  // *******************************end multiselect**************

  // *************for valuestreambinding*************
  obj: { [k: string]: any } = {};
  obj1: any[] = [];
  obj11: any[] = [];
  // *********end binding ****************

  rows: Array<any> = [

  ];

  vstream: any = [
    { VS: "" },
  ]

  config = {
    animated: false,
    keyboard: true,
    ignoreBackdropClick: true
  };

  category: boolean = true;

  valueStreamTemplateHistoryID: number;
  activeDirectoryData: any[];
  tempRows: any[];
  alertText;
  data: User[];

  constructor(private local_label: LanguageService, private modalService: BsModalService, private sharedService: SharedService, private valuestreamtemplateService: ValuestreamTemplateService, private orderPipe: OrderPipe,
    private fb: FormBuilder, private datePipe: DatePipe, private http: HttpClient, private commonService: CommonService, private router: Router) {
    this.valueStreamTemplate = this.valuestreamtemplateService.valueStreamTemplate;

    this.valuestreamtemplateService.valueStreamTemplate = undefined;

    this.valueStreamCategory.isDataRequired = true;

    if (this.valueStreamTemplate == undefined) {
      this.isAdd = true;
      this.isEdit = false;
      this.valueStreamTemplate = new ValueStreamTemplate();
    }
    else if (Object.keys(this.valueStreamTemplate).length == 0) {
      this.isAdd = true;
      this.isEdit = false;
      this.valueStreamTemplate = new ValueStreamTemplate();
    }
    else {
      this.isAdd = false;
      this.isEdit = true;
    }

    if (this.isEdit) {
      this.templateId = this.valueStreamTemplate.valueStreamTemplateID;
      this.valuestreamtemplateService.getValueStreamTemplateHistory(this.templateId).subscribe(res => {
        this.valueStreamHistoryDetails = res;
      });
      this.updateTemplate(this.valueStreamTemplate);
    }

    if (this.isAdd) {
      if (this.valueStreamTemplate == undefined) {
        this.valueStreamTemplate = new ValueStreamTemplate();
      }

      this.valueStreamTemplate.isOperatedInShifts = false;
      this.valueStreamTemplate.visualizationViewModeID = 1;
      this.createRows();
      this.shift = new Shift();
      this.actualShift = null;
    }
  }

  labels: any;
  _subscription: any;

  ngOnInit() {
    if (this.sharedService.role !== "Designer") {
      this.router.navigate([environment.home + '/accessdenied']);
    }

    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
    });


    this.valueStreamCategory.isDataRequired = true;
    this.weekList = [{ id: 1, days: 'Mo', checked: false }, { id: 2, days: 'Tu', checked: false }, { id: 3, days: 'We', checked: false }, { id: 4, days: 'Th', checked: false },
    { id: 5, days: 'Fr', checked: false }, { id: 6, days: 'Sa', checked: false }, { id: 7, days: 'Su', checked: false }];



    // *****************************multiselect drodown search****************
    // *************for lockfilter dropdown menu***********


    this.dropdownSettings = {
      singleSelection: false,
      defaultOpen: false,
      idField: 'valueStreamTemplateID',
      textField: 'valueStreamTemplateName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableCheckAll: this.showAll,
      itemsShowLimit: 3,
      allowSearchFilter: this.ShowFilter
    };
    this.myForm = this.fb.group({
      lockFilter: [this.selectedItems]
    });
    // **********************end******************************

    this.selectedItems = [];
    this.dropdownSettings = {
      singleSelection: false,
      defaultOpen: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableCheckAll: this.showAll,
      itemsShowLimit: 3,
      allowSearchFilter: this.ShowFilter
    };
    this.myForm = this.fb.group({
      city: [this.selectedItems]
    });
    // *****************************end multiselect drodwn*************************


    this.valueStreams = [];
    updateOn: 'blur';

    this.getValueStreamTemplateList();

    this.valueStreams = [{ valueStreamData: "" }];
  }


  setVisulizationDesign(value: number) {
    this.valueStreamTemplate.visualizationViewModeID = value;
  }

  tmpCheckedVal :any = true;
  tmpCheckedValue : any;
  //setVisulizationDesign(value: number) {
  //  //debugger;
  //  this.tmpCheckedValue =value;
  //  if(this.valueStreamTemplate.visualizationViewModeID  != 0 && this.valueStreamTemplate.visualizationViewModeID != value && this.tmpCheckedVal == true)
  //  {
  //    this.alertText = this.labels.default.warningDelete;
  //    this.modalRef2 = this.modalService.show(this.deleteModal, { class: 'second' });
  //    $("modal-container").removeClass("fade");
  //    $(".modal-dialog").addClass("modalSize");
  //    this.tmpCheckedVal =false;
  //  }
  //  else
  //  {
  //    //this.valueStreamTemplate.visualizationViewModeID = value;
  //  }
  //}


  deleteValuesteams() {
    this.closeAlertModal();
    this.rows = [];
    this.shifts = [];
    this.valueStreamTemplate.valueStreams = [];
    this.valueStreamTemplate.shifts = [];
    this.InsertTempRow(0);
    this.tmpCheckedVal =true;
    this.valueStreamTemplate.visualizationViewModeID  = this.tmpCheckedValue;
  }
  
  canceldeleteValuesteams()
  {
    
    this.valueStreamTemplate.visualizationViewModeID  = this.tmpCheckedValue == 1 ? 2: 1;
    this.tmpCheckedVal =true;
    this.closeAlertModal();
  }

  setValueStreamCategory(val: boolean) {
    this.category = val;
  }

  addValueStream() {
    this.valueStreamTemplate = new ValueStreamTemplate();
    this.isAdd = true;
    this.isEdit = false;
    this.rows = this.vstream;
  }


  //input box takes only letters without special characters in valuestream 
  letterOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;

    if ((charCode <= 93 && charCode >= 65) || (charCode <= 122 && charCode >= 97)) {
      return true;
    }
    return false;
  }

  numberOnly(event, value) {
    var maxcount = value;
    if (event.target.value.length == maxcount) return false;
    const charCode = (event.which) ? event.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || (charCode > 57 && charCode != 190 && charCode != 110))) // 110 is decimal point, 190 is period
      return false;

    return true;
  }


  
  daysValue?: string;



  sendToShiftTextbox(template: TemplateRef<any>) {

    var onlyFromTime = this.datePipe.transform(this.shift.fromTime, "h:mm a");
    var onlyToTime = this.datePipe.transform(this.shift.toTime, "h:mm a");
    var result = this.weekList.filter(x => x.checked).map(x => x.days).toString().replace(/,/g, '');

    // #region From & To Date Validation
    // if (this.shift.fromTime > this.shift.toTime) {
    //   this.alertText = this.labels.default.startDateLesser;
    //   this.modalRef2 = this.modalService.show(template, { class: 'second' });
    //   $("modal-container").removeClass("fade");
    //   $(".modal-dialog").addClass("modalSize");
    //   return;
    // }

    if (onlyFromTime == onlyToTime) {
      this.alertText = this.labels.default.timeNotSame;
      this.modalRef2 = this.modalService.show(template, { class: 'second' });
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      return;
    }

    //#endregion

    // #region Days calculation
    this.daysValue = " ";
    if (this.shift.isMonday) {
      this.daysValue = this.daysValue + "Mo";
    }

    if (this.shift.isTuesday) {
      if (!this.daysValue) {
        this.daysValue = "Tu";
      }
      else {
        this.daysValue = this.daysValue + "Tu";

      }
    }
    if (this.shift.isWednesday) {
      if (!this.daysValue) {
        this.daysValue = "We";
      }
      else {
        this.daysValue = this.daysValue + "We";

      }
    }
    if (this.shift.isThursday) {
      if (!this.daysValue) {
        this.daysValue = "Th";
      }
      else {
        this.daysValue = this.daysValue + "Th";

      }
    }
    if (this.shift.isFriday) {
      if (!this.daysValue) {
        this.daysValue = "Fr";
      }
      else {
        this.daysValue = this.daysValue + "Fr";

      }
    }
    if (this.shift.isSaturday) {
      if (!this.daysValue) {
        this.daysValue = "Sa";
      }
      else {
        this.daysValue = this.daysValue + "Sa";

      }

    }
    if (this.shift.isSunday) {
      if (!this.daysValue) {
        this.daysValue = "Su";
      }
      else {
        this.daysValue = this.daysValue + "Su";
      }

    }

    if (this.daysValue == '' || this.daysValue == ' ') {
      this.alertText = this.labels.default.atleastOneday;
      this.modalRef2 = this.modalService.show(template, { class: 'second' });
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      return;
    }

    //#endregion

    var displayName = this.shift.shiftName + "," + onlyFromTime + "-" + onlyToTime + "," + this.daysValue;

    this.shift.rowID = this.currentRow;
    this.shift.displayName = displayName;
    let errorShiftName = false;
    let errorShiftTime = false;
    let errorFromTo = false;
    if (this.rows[this.currentRow][1].shifts) {
      if (this.rows[this.currentRow][1].shifts.length == 0) {
        this.shift.rowPosition = 0;
        this.rows[this.currentRow][1].shifts[0] = this.shift;
      }
      else {
        this.rows[this.currentRow][1].shifts.forEach((item, index) => {

          if (item.rowPosition != this.shift.rowPosition && item.shiftName == this.shift.shiftName) {
            errorShiftName = true;
          }

          var itemDispNameArr = item.displayName.split(',');
          var thisDispNameArr = this.shift.displayName.split(',');
          //Find Duplicate Shift Time multiple combination

          if (itemDispNameArr[1].split('-')[0] == itemDispNameArr[1].split('-')[1]) {
            errorFromTo = true;
          }

          if (item.rowPosition != this.shift.rowPosition && itemDispNameArr[1] === thisDispNameArr[1]) {
            errorShiftTime = true;
          }

        });
        if (errorShiftName) {
          this.alertText = this.labels.default.duplicateShiftName;
          this.modalRef2 = this.modalService.show(template, { class: 'second' });
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          return;
        }
        if (errorFromTo) {
          this.alertText = this.labels.default.timeNotSame;
          this.modalRef2 = this.modalService.show(template, { class: 'second' });
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          return;
        }
        if (errorShiftTime) {
          this.alertText = this.labels.default.duplicateShiftTime;
          this.modalRef2 = this.modalService.show(template, { class: 'second' });
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          return;
        }
        if (!errorShiftName && !errorShiftTime && !errorFromTo) {
          if (this.shift.rowPosition == undefined || this.shift.rowPosition == -1) {
            this.shift.rowPosition = this.rows[this.currentRow][1].shifts.length + 1;
            this.rows[this.currentRow][1].shifts.push(this.shift);
          }
        }
      }
    }
    else {
      if (this.shift.displayName.split(',')[1].split('-')[0] == this.shift.displayName.split(',')[1].split('-')[1]) {
        this.alertText = this.labels.default.timeNotSame;
        this.modalRef2 = this.modalService.show(template, { class: 'second' });
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        return;
      }
      this.shift.rowPosition = 0;
      this.rows[this.currentRow][1].shifts = new Array(this.shift);
    }

    this.shift = new Shift();
    this.actualShift = null;

    if (this.daysValue == " ") {
      this.weekdays = true;
      return;
    }


    this.closeAlertModal();
  }


  weekdays: boolean;
  // ****************export***************


  public CancelPopUp() {
    let colindex: number = -1;
    this.shifts.forEach((item, index) => {
      if (this.actualShift != undefined && item.rowPosition == this.actualShift.rowPosition) {
        colindex = index;
      }
    });


    if (colindex >= 0) {
      this.rows[this.actualRowPostion][1]['shifts'][colindex] = this.actualShift;
      this.shifts[colindex] = this.actualShift;
    }
    this.closeAlertModal();
    this.shift = new Shift();
    this.actualShift = null;
  }

  public closeAlertModal() {
    if (document.getElementsByTagName("modal-container").length > 1) {
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1]);
    }
    else {
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if (document.getElementsByTagName("bs-modal-backdrop").length > 0) {
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }
  }

  showModal() {
    document.getElementById('deleteModal').style.display = "block";
  }

  closeModal() {
    document.getElementById('deleteModal').style.display = "none";
    document.querySelector('body').classList.remove('-is-modal');
  }

  deleteTemplate() {
    this.closeModal();
    this.deleteValueStreamTemplate(this.valueStreamTemplate);
  }


  // **********************end****************

  columnsData: Array<ValueStreamCategory> = [{ valueStreamCategoryName: 'VS Responsible Employee', inputType: 'text', isDataRequiredToFitSpecLength: false, minimumNoOfCharacters: 1, maximumNoOfCharacters: 100, isDataRequired: true, nodeID: 0, isColumnRequired: true },
  { valueStreamCategoryName: 'SHIFT', inputType: '', isDataRequiredToFitSpecLength: false, minimumNoOfCharacters: 1, maximumNoOfCharacters: 500, isDataRequired: true, nodeID: 0, isColumnRequired: false },
  ];


  order: string = "displayName";
  reverse: boolean = false;
  setOrder(value: string) {
    if (this.order === value) {
      this.reverse = !this.reverse;
    }
    this.order = value;
  }


  getButtonType(buttonname: any): any {
    this.filterType = buttonname;
  }

  checkAndAddRow(i) {
    if (this.valueStreamTemplate.visualizationViewModeID == 1) {
      if (this.rows.length - 1 == i) {
        this.rowCount++;
      }
      this.createRows();
    }
  }

  saveValueStreamCategory(valueStreamCategory: any) {

    //if more than 25 valuestreamcategories added
    if (this.columnsData.length > 26) {
      this.alertText = this.labels.default.maxValueStreamCategory;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      return;
    }

    var nodeID = this.columnsData.length - 1;


    for (var i = 0; i < this.columnsData.length; i++) {
      if (this.columnsData[i].nodeID != valueStreamCategory.nodeID && this.columnsData[i].valueStreamCategoryName.toLowerCase().trim() == valueStreamCategory.valueStreamCategoryName.toLowerCase().trim()) {
        this.alertText = this.labels.default.uniqueName + "\n" + this.labels.default.alreadyTaken + ":\n" + valueStreamCategory.valueStreamCategoryName;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        return;
      }
    }

    if (valueStreamCategory.valueStreamCategoryName.toLowerCase().trim() == "shift" || valueStreamCategory.valueStreamCategoryName.toLowerCase().trim() == "vs responsible employee") {
      this.alertText = this.labels.default.uniqueName + "\n" + this.labels.default.alreadyTaken + ":\n" + valueStreamCategory.valueStreamCategoryName;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      return;
    }

    if (valueStreamCategory.isDataRequiredToFitSpecLength) {

      if ((!valueStreamCategory.maximumNoOfCharacters || valueStreamCategory.maximumNoOfCharacters <= 0) && (!valueStreamCategory.minimumNoOfCharacters || valueStreamCategory.minimumNoOfCharacters <= 0)) {
        this.alertText = this.labels.default.maxOrMinNumberCharacters;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        return;
      }

      if ((valueStreamCategory.maximumNoOfCharacters != null && valueStreamCategory.maximumNoOfCharacters > 0) && (valueStreamCategory.minimumNoOfCharacters != null && valueStreamCategory.minimumNoOfCharacters > 0)) {
        if (valueStreamCategory.minimumNoOfCharacters > valueStreamCategory.maximumNoOfCharacters) {
          this.alertText = this.labels.default.specifyMinimumValue;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          return;
        }
      }
    }

    if ((valueStreamCategory.valueStreamCategoryID == null || valueStreamCategory.valueStreamCategoryID == 0)) {
      if ((valueStreamCategory.nodeID == null || valueStreamCategory.nodeID == undefined)) {
        this.columnsData.push({
          valueStreamCategoryName: valueStreamCategory.valueStreamCategoryName,
          inputType: valueStreamCategory.inputType,
          isDataRequired: this.category,
          isDataRequiredToFitSpecLength: valueStreamCategory.isDataRequiredToFitSpecLength,
          minimumNoOfCharacters: valueStreamCategory.minimumNoOfCharacters,
          maximumNoOfCharacters: valueStreamCategory.maximumNoOfCharacters,
          nodeID: nodeID,
          isColumnRequired: true
        });
      }
      else
      {
        this.columnsData.forEach(function (ele, i) {
          if (valueStreamCategory.nodeID == ele.nodeID) {
            ele = valueStreamCategory;
          }
        });
      }
    }
    else {
      let selectedCategory = this.actualCategory;
      let newValue = valueStreamCategory.valueStreamCategoryName;

      if ((this.actualCategory != undefined || this.actualCategory != null) && this.actualCategory.valueStreamCategoryName.toLowerCase().trim() !== newValue.toLowerCase().trim()) {

        if (this.columnsData.length > 0) {
          this.columnsData.forEach(function (ele, i) {
            if (selectedCategory != null && selectedCategory.valueStreamCategoryID == ele.valueStreamCategoryID) {
              ele.valueStreamCategoryName = newValue;
            }
          });
        }

        if (this.rows.length > 0) {
          this.rows.forEach(function (ele, i) {
            if (selectedCategory != null) {
              for (let valueStream of ele) {
                if (valueStream.valueStreamCategoryID == selectedCategory.valueStreamCategoryID) {
                  valueStream[newValue] = valueStream[selectedCategory.valueStreamCategoryName];
                  delete valueStream[selectedCategory.valueStreamCategoryName];
                }
              }
            }
          });
        }
        this.actualCategory.valueStreamCategoryName = newValue;
      }
    }



    this.closeAlertModal();
    this.createRows();
    //this.InsertTempRow();
  }

  checkAndInserRow(row, column) {
    this.ValueStreamName = this.rows[row].ParentId
    this.EditableCol = this.rows[row][column].ParentId != undefined && this.rows[row][column].ParentId != 'null' ? this.rows[row][column].ParentId : this.newGuid(3);

    this.rows[row][column].ParentId = this.rows[row][column].ParentId != undefined && this.rows[row][column].ParentId != 'null' ? this.rows[row][column].ParentId : this.EditableCol
    this.EditableCol = this.rows[row][column].ParentId;



    if (row == this.rows.length - 1) {
      if (this.rows.length - 1 == row) {
        this.rowCount++;
      }
      this.createRows();
    }
    this.currentrow = row + 1;
    this.currentcol = column + 1;
    this.lastcol = column + 1;
    var newelement = [];

    this.tempRows = this.rows;
    this.rows = new Array();
    this.columnsData.forEach(function (ele, i) {

      var colelement = Object()
      var key = ele.valueStreamCategoryName;

      colelement[key] = '';
      colelement['id'] = '';
      colelement['valueStreamID'] = undefined;
      colelement['valueStreamCategoryID'] = undefined;
      colelement['shifts'] = undefined;
      colelement['responsible_UserID'] = undefined;
      colelement['responsibleEmployee'] = undefined;
      colelement['ParentId'] = undefined
      colelement['ValueStreamName'] = undefined
      colelement['isNew'] = 'new'
      newelement.push(colelement);
    });
    

    this.InserRow(newelement, row + 1, column + 1)
    this.rows = this.tempRows;
    this.DeleteemptyRow(column + 1);
  }

  CheckHide(value, i, j) {
    if (this.valueStreamTemplate.visualizationViewModeID == 2) {
      if (i < this.rows.length - 1) {
        if ((value && value.length > 0) || (i == this.currentrow && j == this.currentcol))
          return false

      }
      else {
        if (j == 2) {

          if ((this.rows[i][j][this.columnsData[j].valueStreamCategoryName] == undefined && this.rows[i][j].ParentId == undefined || this.rows[i][j].ParentId == null)) {
            this.rows[i][j].ParentId = this.newGuid(3)

          }
          return false
        }
      }

      return true;
    }
    else {
      return false
    }

  }

  DeleteemptyRow(column) {
   
    for (var i = 0; i < this.rows.length - 1; i++) {

      if (this.rows[i][0].isNew == 'old' && (!this.rows[i][0]['responsibleEmployee'] || this.rows[i][0]['responsibleEmployee'].length == 0)) {
        let row = this.rows[i];
        if (i !== this.rows.length - 1) {
          this.rows = this.rows.filter(x => x !== row);
          this.rowCount = this.rows.length;

        }

        i = this.rows.length - 1
      }


    }


    for (var i = 0; i < this.rows.length - 1; i++) {

      for (var j = 0; j < this.rows[i].length - 1; j++) {
        if (this.rows[i][j].isNew == 'new') {
          this.rows[i][j].isNew = 'old'
          this.currentrow = i
          this.currentcol = column;
        }

      }
    }
  }
  
  InserRow(item, position, col) {
    
    if (item[col].ParentId == undefined || item[col].ParentId == 'null')
      item[col].ParentId = this.EditableCol + ',' + this.newGuid(3);
    //item[col].ParentId = this.EditableCol


    var length = this.tempRows.length;
    for (var i = length - 1; i >= position; i--) {

      this.tempRows[length] = this.tempRows[i];
      length--;
    };
    this.tempRows[position] = item;

  }
  rowCount = 1;
  newGuid(n) {

    var add = 1, max = 12 - add;   // 12 is the min safe number Math.random() can generate without it starting to pad the end with zeros.   

    if (n > max) {
      return this.newGuid(max) + this.newGuid(n - max);
    }

    max = Math.pow(10, n + add);
    var min = max / 10; // Math.pow(10, n) basically
    var number = Math.floor(Math.random() * (max - min + 1)) + min;

    return ("" + number).substring(add);
  }

  rearrangeParent(row) {
    
    var deletedid;
    var collength = this.columnsData.length - 1;
    var c = 0;
    this.columnsData.forEach(x => {
      if (this.rows[row][c].ParentId != undefined && this.rows[row][c].ParentId != 'null') {
        deletedid = this.rows[row][c].ParentId.split(',')[this.rows[row][c].ParentId.split(',').length - 1];
      }
      c = c + 1;
    })
    var r = 0
    while (r < this.rows.length - 1) {
      var isdeleted = false;
      var col = 0
      this.columnsData.forEach(x => {
        if (this.rows[r][col].ParentId != undefined && this.rows[r][col].ParentId != null) {

          //for (var i = 0; i < this.rows.length - 1; i++) {
          var currentparentid = this.rows[r][col].ParentId
          if (currentparentid != undefined && currentparentid != null && currentparentid.split(',').indexOf(deletedid) !== -1) {
            this.rows = this.rows.filter(x => x !== this.rows[r])
            isdeleted = true;

          }
          //}
        }

        col++
      })
      if (isdeleted)
        r = 0;
      else
        r++;
    }
  }

  createRows() {
    var self = this;
    this.tempRows = this.rows;
    this.rows = new Array();

    for (var i = 1; i <= self.rowCount; i++) {
      var rowelement = new Array();
      this.columnsData.forEach(function (ele, i) {
        var colelement = new Object();
        var key = ele.valueStreamCategoryName;
        colelement[key] = '';
        colelement['id'] = '';
        colelement['valueStreamID'] = undefined;
        colelement['valueStreamCategoryID'] = undefined;
        colelement['shifts'] = undefined;
        colelement['responsible_UserID'] = undefined;
        colelement['responsibleEmployee'] = undefined;
        colelement['ParentId'] = undefined;
        rowelement.push(colelement);
      });

      self.rows.push(rowelement);
    };
    
    for (var i = 0; i < this.tempRows.length; i++) {
      for (var j1 = 0; j1 < this.tempRows[0].length; j1++) {       
        this.rows[i][j1] = this.tempRows[i][j1];
      }
    }
  }

  createTempRows() {
    var self = this;
    this.tempRows = this.rows;
    this.rows = new Array();

    for (var i = 1; i <= self.rowCount; i++) {
      var rowelement = new Array();
      this.columnsData.forEach(function (ele, i) {
        var colelement = new Object();
        var key = ele.valueStreamCategoryName;
        colelement[key] = '';
        colelement['id'] = '';
        colelement['valueStreamID'] = '';
        colelement['valueStreamCategoryID'] = '';
        colelement['shifts'] = undefined;
        colelement['responsible_UserID'] = undefined;
        colelement['responsibleEmployee'] = undefined;
        colelement['ParentId'] = undefined;

        rowelement.push(colelement);
      });

      self.rows.push(rowelement);
    };
  }


  shifts: Shift[] = [];
  public async onSubmit(valuestreamtemplate: ValueStreamTemplate) {
    
    this.isDisabled = false; 
    
    if(this.onchange) {
      this.alertText = this.labels.default.fillResponsibleEmployee;

            this.modalService.show(this.warningModal);
            $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
            this.isDisabled = true;
            return;
    }
    if (this.isAdd && this.valueStreamTemplateList != null) {

      var existingValueStreams = this.valueStreamTemplateList.filter(x => x.valueStreamTemplateName.toLowerCase() === this.valueStreamTemplate.valueStreamTemplateName.toLowerCase());
      if (existingValueStreams && existingValueStreams.length > 0) {
        this.alertText = this.labels.default.uniqueName + "\n" + this.labels.default.alreadyTaken + ":\n\n" + valuestreamtemplate.valueStreamTemplateName;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;
        return;
      }

    }
    else if (this.isEdit) {
      var existingValueStreams = this.valueStreamTemplateList.filter(x => x.valueStreamTemplateName.toLowerCase() === this.valueStreamTemplate.valueStreamTemplateName.toLowerCase() && x.valueStreamTemplateID !== this.valueStreamTemplate.valueStreamTemplateID);
      if (existingValueStreams && existingValueStreams.length > 0) {
        this.alertText = this.labels.default.uniqueName + "\n" + this.labels.default.alreadyTaken + ":\n\n" + valuestreamtemplate.valueStreamTemplateName;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;

        return;
      }
    }

    this.valueStreamTemplate.valuestreamCategories = this.columnsData;
    this.valueStreams = [];
    this.columnsData = this.columnsData;

    for (let i = 0; i < this.rows.length - 1; i++) {

      if (!this.rows[i][0]["responsible_UserID"]) {
        this.alertText = this.labels.default.responsibleEmployee + (i + 1);
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;
        return;
      }
    }

    for (let c = 0; c < this.columnsData.length; c++) {

      if (this.columnsData.length < 3) {
        this.alertText = this.labels.default.valueStreamCategory;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;

        return;
      }

    }

    let row = 0
    this.sharedService.show();
    //new logic with complex array, rows.length-1 -->removes the empty row
    this.rows.forEach(x => {
      let i = row;
      let c = 0;
      if (this.rows[i][c]["responsibleEmployee"])
        this.columnsData.forEach(y => {
          this.valueStream = new ValueStream();
          this.valueStream.valueStreamCategoryName = this.columnsData[c].valueStreamCategoryName;
          this.valueStream.valueStreamData = this.rows[i][c][this.columnsData[c].valueStreamCategoryName];
          this.valueStream.valueStreamCategoryID = this.rows[i][c]["valueStreamCategoryID"]! ? this.rows[i][c]["valueStreamCategoryID"] : undefined;
          this.valueStream.valueStreamID = this.rows[i][c]["valueStreamID"] ? this.rows[i][c]["valueStreamID"] : undefined;
          this.valueStream.nodeID = this.columnsData[c]["nodeID"];
          this.valueStream.responsible_UserID = this.rows[i][c]["responsible_UserID"];
          this.valueStream.responsibleEmployee = this.rows[i][c]["responsibleEmployee"];
          this.valueStream.rowID = i;

          if (this.valueStream.valueStreamData != undefined && this.valueStream.valueStreamData != '')
            this.valueStream.ParentId = this.rows[i][c].ParentId != undefined && this.rows[i][c].ParentId != 'null' ? this.rows[i][c].ParentId : undefined
          this.valueStream.valueStreamName = this.valueStream.valueStreamData
          this.valueStreams.push(this.valueStream);
          c++;
        })

      //validation for listview (mandatory categories should not be empty)
      if (this.valueStreamTemplate.visualizationViewModeID == 1 && this.isDisabled == false ) {
        let mandatoryCategories = this.valueStreamCategoryList.filter(x => x.isColumnRequired);
        for (let category of mandatoryCategories) {
          if (category && category.valueStreamCategoryName !== 'VS Responsible Employee' && category.valueStreamCategoryName !== 'SHIFT') {
            let mandatoryValueStreams = this.valueStreams.filter(x => x.valueStreamCategoryName == category.valueStreamCategoryName &&
              (x.valueStreamData == null || x.valueStreamData == undefined || x.valueStreamData == ""));
            if (mandatoryValueStreams && mandatoryValueStreams.length > 0 && category.isDataRequired && this.isDisabled == false) {
              this.alertText = this.labels.default.fillMandatoryValueStreams;
              this.modalService.show(this.warningModal);
              $("modal-container").removeClass("fade");
              $(".modal-dialog").addClass("modalSize");
              this.isDisabled = true;
              this.sharedService.hide();
              break;
            }

            let rowValues = this.valueStreams.filter(x => x.valueStreamCategoryName == category.valueStreamCategoryName &&
              (x.valueStreamData != null && x.valueStreamData != undefined && x.valueStreamData != ""));


            for (let i = 0; i < rowValues.length && this.isDisabled == false; i++) {
              if (category.isDataRequiredToFitSpecLength) {
                category.minimumNoOfCharacters = (category.minimumNoOfCharacters == undefined || category.minimumNoOfCharacters == 0) ? 1 : category.minimumNoOfCharacters;
                category.maximumNoOfCharacters = (category.maximumNoOfCharacters == undefined || category.maximumNoOfCharacters == 0) ? 100 : category.maximumNoOfCharacters;
                if (!(rowValues[i].valueStreamData.length >= category.minimumNoOfCharacters && rowValues[i].valueStreamData.length <= category.maximumNoOfCharacters)) {
                  this.alertText = this.labels.default.minOrMaxNumberCharacters;
                  this.modalService.show(this.warningModal);
                  $("modal-container").removeClass("fade");
                  $(".modal-dialog").addClass("modalSize");
                  this.isDisabled = true;
                  this.sharedService.hide();
                  return;
                }
              }
            }
          }

        }
      }



      //to add the full name in listview/treeview format
      if (this.valueStreamTemplate.visualizationViewModeID === 1) {

        let currentRow = this.valueStreams.filter(x => x.rowID == i && x.nodeID !== 0);

        let vsName = "";
        for (let n = 0; n < currentRow.length; n++) {
          if (currentRow[n].valueStreamData) {
            if (vsName) {
              vsName = vsName.concat(this.valueStreamTemplate.delimiter).concat(currentRow[n].valueStreamData);
            }
            else {
              vsName = currentRow[n].valueStreamData;
            }
          }
        }
        if (vsName) {
          //to find out the last node where the actual valuestream is mapped
          //let actualValueStreams = currentRow.filter(x =>x.valueStreamData);
          //let actualValueStream = actualValueStreams[actualValueStreams.length-1];
          let actualValueStream = this.valueStreams.filter(x => x.rowID == i && x.valueStreamCategoryName == 'VS Responsible Employee')[0];
          this.valueStreams.filter(x => x == actualValueStream)[0].valueStreamName = vsName;
        }
      }

      else {

        for (let valueStream of this.valueStreams) {
          if (valueStream.valueStreamData) {
            valueStream.valueStreamName = valueStream.valueStreamName + '_' + valueStream.valueStreamData;
          }
        }
      }
      row++;
    })
   
    //end of full name adding in Listview/treeview
    if (this.valueStreamTemplate.visualizationViewModeID === 2 && this.isDisabled == false) {
      var parentvaluestream: any = []
      this.valueStreams.forEach(vs => {
        if (vs.nodeID > 0 && vs.ParentId != undefined && vs.ParentId != null) {
          var id = vs.ParentId.split(',')[vs.ParentId.split(',').length - 1]
          if (id != undefined)
            if (parentvaluestream.filter(f => f.Id == id).length == 0)
              parentvaluestream.push({ Id: id, value: vs.valueStreamData })
        }

      })
      for (var v = 0; v < this.valueStreams.length; v++) {
        if (this.valueStreams[v].nodeID > 0 && this.valueStreams[v].ParentId != undefined && this.valueStreams[v].ParentId != null) {
          this.valueStreams[v].valueStreamName = '';
          this.valueStreams[v].ParentId.split(',').forEach(sp => {
            var streanname = parentvaluestream.filter(f => f.Id == sp)
            this.valueStreams[v].valueStreamName = this.valueStreams[v].valueStreamName.length > 0 ? this.valueStreams[v].valueStreamName + this.valueStreamTemplate.delimiter + streanname[0].value : streanname[0].value;
          })
        }
      }
    }

    for (let i = 0; i < this.rows.length - 1; i++) {
      let vstreams = this.valueStreams.filter(x => x.rowID == i && x.valueStreamData);
      if (vstreams && vstreams.length < 1) {
        this.alertText = this.labels.default.atleastOneValueStream + (i + 1);
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;
        this.sharedService.hide();
        return;
      }
    }

    this.shifts = new Array();
    if (this.valueStreamTemplate.isOperatedInShifts) {
      for (let i = 0; i < this.rows.length - 1; i++) {
        if (this.rows[i][1].shifts != undefined) {
          for (let shift of this.rows[i][1].shifts) {
            //this.ConvertStartAndEndDateTime(shift);
            this.shifts.push(shift);
          }
        }
      }
    }
    let error = false;
    if (this.valueStreams.length == 0) {
      this.alertText = this.labels.default.vsPopUpWarning;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      this.isDisabled = true;
      this.sharedService.hide();
      return;
    }
    this.valueStreams.forEach((item, index) => {
      if (item.valueStreamCategoryName == 'VS Responsible Employee') {
        if (item.responsibleEmployee == undefined || item.responsibleEmployee == '') {
          error = true;
        }
      }
    });

    this.shifts.forEach((item, index) => {
      if (item.shiftName == undefined || item.shiftName == '') {
        error = true;
      }
      var d = new Date();
      var _frmTime = new Date(item.fromTime);
      var _toTime = new Date(item.toTime);
      item.fromTime  = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate(), _frmTime.getHours(), _frmTime.getMinutes(), 0)).toISOString();
      item.toTime  = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate(), _toTime.getHours(),_toTime.getMinutes(), 0)).toISOString();
    });
    
    if (error) {
      this.alertText = this.labels.default.vsEnterAllFields;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      this.isDisabled = true;
      this.sharedService.hide();
      return;
    }
    this.valueStreamTemplate.valueStreams = this.valueStreams;
    this.valueStreamTemplate.shifts = this.shifts;

    if (this.isAdd) {
      this.valueStreamTemplate.createdBy_NTID = this.sharedService.ntid;
      this.valueStreamTemplate.modifiedBy_NTID = this.sharedService.ntid;
      this.valueStreamTemplate.isLocked = false;
    }
    if (this.isEdit) {
      this.valueStreamTemplate.modifiedBy_NTID = this.sharedService.ntid;
    }


    
    if (this.isDisabled) {
      this.sharedService.hide();
      return;
    }

    await this.valuestreamtemplateService.insertValueStreamTemplate(valuestreamtemplate).subscribe(
      res => {
        if (res && res.resultCode == 0) {
          this.alertText = this.labels.default.insertedSuccessfully;
          this.modalService.show(this.successModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          this.sharedService.hide();
          this.router.navigate([environment.home + 'valuestream/valuestreams-edit'])
        }
        else {
          this.alertText = this.labels.default.insertOpertionFailed;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          this.isDisabled = true;
          this.sharedService.hide();
          return;
        }
      });
    }


  // **************************delete ValueStreamTemplate*****************
  deleteValueStreamTemplate(valueStreamTemplate: any) {
    if (this.sharedService.ntid) {
      this.valueStreamTemplate.modifiedBy_NTID = this.sharedService.ntid;
      var d = new Date();
      this.valueStreamTemplate.modifiedAt = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate(), d.getHours(), d.getMinutes(), d.getSeconds()));
    }

    this.valuestreamtemplateService.deleteValueStreamTemplate(this.valueStreamTemplate).subscribe(
      res => {
        if (res.resultCode == 0) {
          this.getValueStreamTemplateList();
          this.alertText = this.labels.default.deleteSuccessfully;
          this.modalService.show(this.successModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          this.router.navigate([environment.home + '/valuestreams']);
        }
        else if (res.resultCode == 1) {
          this.alertText = this.labels.default.valuestreamLinked;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
        }
        else {
          this.alertText = this.labels.default.failedDeleteAssessor;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");

        }

      },
      err => {
        console.log(err);
      });
  }
  // **************************Delete End******************************


  public insertValueStreamCategory(valuestreamcategory: Array<ValueStreamCategory>) {
    this.valuestreamtemplateService.insertValueStreamCategory(valuestreamcategory).subscribe(
      res => {
        this.alertText = this.labels.default.insertedSuccessfully;
        this.modalService.show(this.successModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
      });
  }

  valueStreamTemplateList: ValueStreamTemplate[] = [];
  public getValueStreamTemplateList() {
    this.valuestreamtemplateService.getValueStreamTemplate().subscribe(res => {
      this.valueStreamTemplateList = res;
    },
      err => {
        console.log(err);
      }
    );
  }

  // ************************************************************************************

  proxies1: any;
  proxy: any;
  //Edit function for ValueStream template
  updateTemplate(valueStreamTemplate: any) {

    this.isAdd = false;
    this.isEdit = true;
    this.valueStreams = [];
    this.valueStreamTemplate = new ValueStreamTemplate();
    this.valueStreamTemplate = valueStreamTemplate;

    this.valuestreamtemplateService.getValueStreamCategoryByTemplateID(this.valueStreamTemplate.valueStreamTemplateID).subscribe(
      res => {
        
        this.rows = [];
        this.valueStreamCategoryList = res;//binding ValueStreamTemplates values
        this.valuestreamtemplateService.getShiftsByTemplateID(this.valueStreamTemplate.valueStreamTemplateID).subscribe(res => {
          this.shifts = res;

          this.shifts.forEach((item, index) => {
            item.rowPosition = index++;
          });

          this.columnsData = [];
          this.columnsData = this.valueStreamCategoryList;//Binding the ValueStreamCategory columns values.
         
          var obj: any;
          /**Binding valuestream for editing */
          for (let hvs of this.valueStreamCategoryList) {

            this.obj[hvs.valueStreamCategoryName] = undefined;
            let a = this.obj;
          }


          this.obj1 = [];
          for (let vs of this.valueStreamCategoryList) {
            let vstreams = vs.valueStreams;
            for (let sl of vstreams) {
              this.obj1.push(sl);
            }
          }

          //for shifts
          //new insert logic
          this.rows = [];
          var col = this.valueStreamCategoryList.length;
          var row = this.obj1.length / col;
          this.obj11 = [];
          for (var n = 0; n < row; n++) {
            for (let vs of this.valueStreamCategoryList) {
              let vstreams = vs.valueStreams;
              if (vstreams[n]) {
                this.obj11.push(vstreams[n]);
              }
            }
          }

          var r = 0;
          var ob = Object.getOwnPropertyNames(this.obj).length;

          //new logic with complex array
          this.rowCount = row + 1; //to reduce the count while saving
          this.createTempRows();
         
          for (var i = 0; i < this.rows.length - 1; i++) {
            for (var j = 0; j < this.columnsData.length; j++) {
              if (i == 0) {
                this.rows[i][j][this.columnsData[j].valueStreamCategoryName] = this.obj11[j].valueStreamData;
                this.rows[i][j]["valueStreamID"] = this.obj11[j].valueStreamID;
                this.rows[i][j]["valueStreamCategoryID"] = this.obj11[j].valueStreamCategoryID;
                this.rows[i][j]["responsible_UserID"] = this.obj11[j].responsible_UserID;
                this.rows[i][j]["responsibleEmployee"] = this.obj11[j].responsibleEmployee;
                this.rows[i][j]["ParentId"] = this.obj11[j].parentId

              }
              else {
                this.rows[i][j][this.columnsData[j].valueStreamCategoryName] = this.obj11[j + (i * ob)].valueStreamData;
                this.rows[i][j]["valueStreamID"] = this.obj11[j + (i * ob)].valueStreamID;
                this.rows[i][j]["valueStreamCategoryID"] = this.obj11[j + (i * ob)].valueStreamCategoryID;
                this.rows[i][j]["responsible_UserID"] = this.obj11[j + (i * ob)].responsible_UserID;
                this.rows[i][j]["responsibleEmployee"] = this.obj11[j + (i * ob)].responsibleEmployee;
                this.rows[i][j]["ParentId"] = this.obj11[j + (i * ob)].parentId
              }
            }
          }

          for (var i = 0; i < this.rows.length - 1; i++) {
            this.rows[i][1]["shifts"] = this.shifts.filter(x => x.rowID == i);
          }

        }, error => console.error(error));
      },

      err => {
        console.log(err);
      }
    );
  }

  openVerticallyCentered(template: TemplateRef<any>, name) {
    this.modalRef = this.modalService.show(template, this.config);
    this.modalRef.setClass('modal-lg');
  }

  redirectToList() {
    this.router.navigate([environment.home + '/valuestreams']);
  }

  redirect() {
    this.isEdit = false;
    this.isAdd = false;
    this.valueStreamTemplate = new ValueStreamTemplate();
    this.valueStreams = [{ valueStreamData: "" }];
    this.router.navigate([environment.home + '/valuestreams']);
  }
  // ***************************************************************************************


  // ****************************************************************
  //sorting
  key: string = 'name';
  reverse1: boolean = false;
  sort(key) {
    this.key = key;
    this.reverse1 = !this.reverse1;
  }
  p: number = 1;
  // ***********************************************************************

  vsCategoryName: string = '';

  OpenContentPopUp(template: TemplateRef<any>, data: any) {
    this.vsCategoryName = '';
    this.modalRef = this.modalService.show(template, this.config);
    this.modalRef.setClass('modal-lg');
    this.valueStreamCategory = data;
    if (this.actualCategory == null) {
      this.actualCategory = Object.assign({}, data);
    }


    this.category = true;
    this.shift = new Shift();
    this.actualShift = null;

  }

  CancelContentPopUp(valueStreamCategoryID: number) {
    let colindex: number = -1;
    if (valueStreamCategoryID > 0) {
      for (var i = 0; i < this.columnsData.length; i++) {
        if (this.actualCategory != null && this.columnsData[i].valueStreamCategoryID == valueStreamCategoryID) {
          this.columnsData[i] = this.actualCategory;
        }
      }
    }
    this.closeAlertModal();
    this.shift = new Shift();
    this.actualShift = null;
    this.actualCategory = null;
  }

  open(template: TemplateRef<any>) {
    this.vsCategoryName = '';
    this.modalRef = this.modalService.show(template, this.config);
    this.modalRef.setClass('modal-lg');
    this.valueStreamCategory = new ValueStreamCategory();
    this.valueStreamCategory.isDataRequired = true;
    this.category = true;
    this.shift = new Shift();
    this.actualShift = null;
  }

  shiftModal(template: TemplateRef<any>, event) {
    this.modalRef = this.modalService.show(template, this.config);
    this.modalRef.setClass('modal-lg');
  }
  currentRow: number;
  openShiftModal(template: TemplateRef<any>, event, i: number, s: number) {
    this.shift = this.rows[i][1]['shifts'][s];
    this.shift.rowPosition = this.rows[i][1]['shifts'][s].rowPosition;
    if (this.actualShift == null) {
      this.actualRowPostion = i;
      this.actualShift = Object.assign({}, this.shift);
    }
    this.modalRef = this.modalService.show(template, this.config);
    this.modalRef.setClass('modal-lg');
    this.currentRow = i;
    this.weekdays = false;
  }
  emptyShiftModal(template: TemplateRef<any>, event, i: number) {
    this.shift = new Shift();
    this.actualShift = null;
    this.modalRef = this.modalService.show(template, this.config);
    this.modalRef.setClass('modal-lg');
    this.currentRow = i;
    this.weekdays = false;
  }

  /** Method is responsible to move to first page of the pagination. */
  isFirstPage() {
    if (this.page == 1) {
      return;
    }
    else {
    }

    this.page = 1;
    this.startPage = (this.page - 1) * 4 + 1;
    this.endPage = this.page * this.resultPerPage;
  }

  /** Method is responsible to move to last page of the pagination. */
  isLastPage() {
    if (Math.ceil(this.valueStreamTemplateList.length / this.resultPerPage) <= this.page) {
      return;
    }
    else {

    }

    this.page = Math.ceil(this.valueStreamTemplateList.length / this.resultPerPage);
    this.startPage = (this.page - 1) * 4 + 1;
    this.endPage = this.page * this.resultPerPage;
  }

  /** Method is responsible to change page of the pagination. */
  pageChanged(event): void {

    if (event == 0) {
      return;
    }
    else if (Math.ceil(this.valueStreamTemplateList.length / this.resultPerPage) < event) {
      return;
    }
    else {
      this.page = event;
      this.startPage = (this.page - 1) * 4 + 1;
      this.endPage = this.page * this.resultPerPage;
    }
  }


  /** for Proxy */
  keyword = 'userName';
  proxies: User[] = [];

  selectEvent(item) {
    // do something with selected item
    if (item !== null) {
      let x = this.proxies.filter(x => x.ntid == item.ntid);
      if (x.length == 0)
        this.proxies.push(item);
    }
  }
  currentRowSelection: number;

  onChangeSearch(val: any, i: number) {
    this.currentRowSelection = i;
    let user = new User();
    user.firstName = this.rows[i][0].responsibleEmployee;
    this.commonService.activeDirectoryByName(user).subscribe(res => {
      this.activeDirectoryData = [];
      this.activeDirectoryData = res;
      if(this.activeDirectoryData.length ==1 ){

        this.SelectedIndex=i+1;
        console.log("sel index",this.SelectedIndex)
       this.onchange=true;
       console.log("active directory data length is 1");
        }
    },
      err => console.error(err));
    // fetch remote data from here
    // And reassign the 'data' which is binded to 'data' property.
  }

  selectUser(user: any, i: number) {
  
    console.log("inside select ussrr seleced index",this.SelectedIndex)
    console.log("inside select user i",i+1)
    if(this.SelectedIndex == i+1){
      this.onselect = true;
      this.onchange = false;
      console.log("onselect:",this.onselect)
      console.log("onselect:",this.onchange)
    }
    this.rows[i][0]["responsibleEmployee"] = user.userName;
    this.rows[i][0]["responsible_UserID"] = user.ntid;
    if (this.valueStreamTemplate.visualizationViewModeID == 2) {
      if (this.lastcol > 2 && (this.rows[i][this.lastcol].ParentId == undefined || this.rows[i][this.lastcol].ParentId == 'null')) {
        this.rows[i][this.lastcol].ParentId = this.EditableCol + ',' + this.newGuid(3)

      }
      this.InsertTempRow(i);
    }

    this.activeDirectoryData = [];

  }

  onFocusEvent( index: number) {

    console.log("index",index)
    // if(this.SelectedIndex==0){
    // this.SelectedIndex=index;
    // }

    console.log("Selected index:",this.SelectedIndex);
    // this.tempin
    console.log("oncahnge:",this.onchange);

      console.log("false");
    if(this.onchange) {
      console.log("inside 1600",this.SelectedIndex)
      if(  this.SelectedIndex != index) {
        this.alertText = this.labels.default.responsibleEmployeeVal1+" "+this.SelectedIndex + " " + this.labels.default.responsibleEmployeeVal2; 
        this.modalService.show(this.warningModal);
         $("modal-container").removeClass("fade");
         $(".modal-dialog").addClass("modalSize"),1000;
          this.isDisabled = true;

          // setTimeout(function () {
          //   $("#valueHistory tbody tr").click(function () {
          //     $(".selected").removeClass('selected');
          //     $(this).addClass('selected');
          //     $('.isRestoreDisabled').prop('disabled', false);
          //   });
          // }, 100);
          
          return;
      }


    }

  }

  InsertTempRow(i)
  {
    if (this.rows.length - 1 == 0 || i == this.rows.length - 1) {

      this.currentrow = i;
      this.currentcol = 2;
      var newelement = []
      this.tempRows = this.rows;
      this.columnsData.forEach(function (ele, i) {

        var colelement = Object()
        var key = ele.valueStreamCategoryName;

        colelement[key] = '';
        colelement['id'] = '';
        colelement['valueStreamID'] = undefined;
        colelement['valueStreamCategoryID'] = undefined;
        colelement['shifts'] = undefined;
        colelement['responsible_UserID'] = undefined;
        colelement['responsibleEmployee'] = undefined;
        colelement['ParentId'] = undefined
        colelement['ValueStreamName'] = undefined
        colelement['isNew'] = 'new'
        newelement.push(colelement);
      });
      if (this.rows.length - 1 == 0)
        this.InserRow(newelement, 1, 2)
      else
        this.InserRow(newelement, i + 1, 2)
      this.rows = this.tempRows;
      this.currentcol = 2;
      this.rows[i + 1][2].ParentId = this.newGuid(3)
    }
  }
  removeProxy(event: any) {
    let ntid = event.target.id;
    this.proxies = this.proxies.filter(x => x.ntid !== ntid);
  }


  /*for lock settings*/
  lockValueStream() {
    this.valuestreamtemplateService.valueStreamTemplate = this.valueStreamTemplate;
    this.router.navigate([environment.home + '/valuestreams/valuestreams-lock']);

  }

  /*for removing shift*/

  removeShift(shift: Shift) {
    this.rows[shift.rowID][1]['shifts'] = this.rows[shift.rowID][1]['shifts'].filter(x => x.shiftName !== shift.shiftName);
    //this.rows = this.rows[event.target.id][1].filter(x => x.shifts.shiftName !== event.target.name);
  }


  openValueStreamHistory(valueStreamHistory: TemplateRef<any>) {
    this.modalRef = this.modalService.show(valueStreamHistory, this.config);
    this.modalRef.setClass('modal-lg');
    $('.isRestoreDisabled').prop('disabled', true);

    setTimeout(function () {
      $("#valueHistory tbody tr").click(function () {
        $(".selected").removeClass('selected');
        $(this).addClass('selected');
        $('.isRestoreDisabled').prop('disabled', false);
      });
    }, 100);
  }

  templateHistoryId: number;

  restoreVersion() {
    this.valueStreamTemplateHistoryID = $("#valueHistory tbody tr.selected td:first").html();
    this.valuestreamtemplateService.valueStreamRestoreByTemplateHistoryID(this.valueStreamTemplateHistoryID).subscribe(res => {

      if (res) {
        this.closeAlertModal();
        this.alertText = this.labels.default.restoreSuccessfully;
        this.modalService.show(this.successModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.router.navigate(['../' + environment.home + 'valuestream/valuestreams-edit']);
      }
      else {
        this.closeAlertModal();
        this.alertText = this.labels.default.restoreFailed;
        this.modalService.show(this.successModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
      }
    },
      (err) => {
        alert(err.message);
        this.closeAlertModal();
      });
  }

  setTargetFrequency(value: any) {
    if (value) {
      this.columnsData[1].isColumnRequired = true;
    }
    else {
      this.columnsData[1].isColumnRequired = false;
    }
  }

  removeRow(i: any) {
    let row = this.rows[i];

    if (i !== this.rows.length - 1) {
      if (this.valueStreamTemplate.visualizationViewModeID == 2)
        this.rearrangeParent(i)
      else
        this.rows = this.rows.filter(x => x !== row);
      this.rowCount = this.rows.length;

      this.createRows();
    }
  }
}
//end of the class
