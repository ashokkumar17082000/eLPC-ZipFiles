import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { SharedService } from 'src/app/service/shared.service';
import { ValueStreamTemplate, ValueStreamProxy } from './valuestreamtemplate';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { ValuestreamTemplateService } from 'src/app/service/common/valuestreamtemplate.service';
import { OrderPipe } from 'ngx-order-pipe';
import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { CommonService } from 'src/app/service/common/common.service';
import { Router } from '@angular/router';
import { LanguageService } from 'src/app/language.service';
import { environment } from 'src/environments/environment';
import { DataPoolService } from 'src/app/service/data-pool.service';

declare var $;

@Component({
  selector: 'app-value-streams',
  templateUrl: './value-streams.component.html',
  styleUrls: ['./value-streams.component.css']
})
export class ValueStreamsComponent implements OnInit {

  @ViewChild('fileInput') fileInput;
  @ViewChild('lockPopup') lockModal: TemplateRef<any>;
  dateTimeFormat = environment.dateTimeFormat;
  filterdateFormat  = environment.dateTimeFormat.split(" ")[0];

  key: string = 'name';//for sorting
  reverse1: boolean = false;//for sorting
  dropdownList = [];
  public data = [];
  public settings = {};
  public form: FormGroup;
  public loadContent: boolean = false;

  filterId = false;
  filterName = false;
  filterLock = false;
  filterModified = false;
  filterModifiedBy = false;
  filterCreated = false;
  filterCreatedBy = false;
  labels: any;
  _subscription: any;
  filtertext: any;

  page: number = 1;
  resultPerPage: number = 10;
  startPage: number;
  endPage: number;

  modalRef: BsModalRef;
  dataTable: any;
  buttonId: number = 0;

  public id = 0;
  valueStreamTemplateList: ValueStreamTemplate[] = [];
  valueStreamTemplate: ValueStreamTemplate = new ValueStreamTemplate();
  filterType: string = "test";
  headerFilterName: string = "";

  // ***************************************for multiselext drodown******
  myForm: FormGroup;
  disabled = false;
  ShowFilter = true;
  showAll = true;
  limitSelection = false;
  lockFilters: Array<any> = [];
  selectedItems: Array<any> = [];
  dropdownSettings: any;
  filterPopUp :any;
  // *******************************end multiselect**************


  config = {
    animated: false,
    keyboard: true,
    ignoreBackdropClick: true
  };

  sortedCollection: any[];
  activeDirectoryData: any[];
  tempRows: any[];
  totalList: ValueStreamTemplate[];
  str1: string;
  vsSearchText: string;
  constructor(private local_label: LanguageService, private modalService: BsModalService, private sharedService: SharedService,private dataPoolService: DataPoolService,
    private valuestreamtemplateService: ValuestreamTemplateService, private orderPipe: OrderPipe,
    private fb: FormBuilder, private datePipe: DatePipe, private http: HttpClient, private commonService: CommonService, private router: Router) {

    if (location.reload) {
      this.sharedService.setIconName("Shuffle Mode");
      setTimeout(() => {
        this.sharedService.setIcon("assets/image/Material.svg");
      }, 100);
    }
  }

  closeAlert() {
    if (document.getElementsByTagName("modal-container").length > 1) {
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1]);
    }
    else {
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if (document.getElementsByTagName("bs-modal-backdrop").length > 0) {
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }
  }

  public openAlertModal(popUp:any) {
    this.filterPopUp = popUp;
  }

  public closeAlertModal() {
    this.filterPopUp.hide();
    //document.getElementsByTagName("popover-container")[0].parentNode.removeChild(document.getElementsByTagName("popover-container")[0]);

    if(this.valueStreamTemplateList.length == this.totalList.length)
    {
    this.filtertext = '';
    this.filterId = false;
    this.filterName = false;
    this.filterLock = false;
    this.filterModified = false;
    this.filterModifiedBy = false;
    this.filterCreated = false;
    this.filterCreatedBy = false;
    }
    //document.querySelector('body').classList.remove('-is-modal');
  }

  ngOnInit() {
    if(this.sharedService.role !=="Designer")
    {
      this.router.navigate([environment.home +'/accessdenied']);
    }

    this.sharedService.show();

    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
    });


    // *****************************end multiselect drodwn*************************

    this.getValueStreamTemplateList();

  }
  setForm() {
    this.form = new FormGroup({
      name: new FormControl(
        this.data
      )
    });
    this.loadContent = true;
  }

  //#region filtering
  searchFilter() {

    this.data = [];
    // ********************************searching
    if (this.headerFilterName == "valueStreamTemplateName") {
      for (var valuestreamTemp of this.valueStreamTemplateList) {
        let newItem = {
          valueStreamTemplateID: valuestreamTemp.valueStreamTemplateID,
          valueStreamTemplateName: valuestreamTemp.valueStreamTemplateName
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.valueStreamTemplateName === valuestreamTemp.valueStreamTemplateName)) {//newly added
            this.data.push(newItem);
          }
        }
      }
    }
    else if (this.headerFilterName == "isLocked") {
      for (var valuestreamTemp of this.valueStreamTemplateList) {
        let newItem = {
          valueStreamTemplateID: valuestreamTemp.valueStreamTemplateID,
          isLocked: valuestreamTemp.isLocked
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.isLocked === valuestreamTemp.isLocked)) {
            this.data.push(newItem);
          }
        }
      }
    }
    else if (this.headerFilterName == "modifiedAt") {
      for (var valuestreamTemp of this.valueStreamTemplateList) {
        this.str1 = this.datePipe.transform(valuestreamTemp.modifiedAt,this.filterdateFormat);//converting the date format

        let newItem = {
          valueStreamTemplateID: valuestreamTemp.valueStreamTemplateID,
          modifiedAt: this.str1 //passing the formatted date
        };

        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.modifiedAt === this.str1)) {
            this.data.push(newItem);
          }
        }
      }
    }
    else if (this.headerFilterName == "modifiedBy") {


      for (var valuestreamTemp of this.valueStreamTemplateList) {
        let newItem = {
          valueStreamTemplateID: valuestreamTemp.valueStreamTemplateID,
          modifiedBy: valuestreamTemp.modifiedBy
        };
        if (!this.data.includes(newItem)) {

          if (!this.data.some(e => e.modifiedBy === valuestreamTemp.modifiedBy)) {
            /* data contains the element we're looking for */
            this.data.push(newItem);
          }
        }
      }

      let unique = Array.from(new Set(this.data.map(item => item.valueStreamTemplateName)));
    }
    else if (this.headerFilterName == "createdAt") {
      for (var valuestreamTemp of this.valueStreamTemplateList) {
        this.str1 = this.datePipe.transform(valuestreamTemp.createdAt, this.filterdateFormat);//converting the date format
        let newItem = {
          valueStreamTemplateID: valuestreamTemp.valueStreamTemplateID,
          createdAt: this.str1 //passing the formatted date
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.createdAt === this.str1)) {
            this.data.push(newItem);
          }
        }
      }
    }
    else if (this.headerFilterName == "createdBy") {
      for (var valuestreamTemp of this.valueStreamTemplateList) {
        let newItem = {
          valueStreamTemplateID: valuestreamTemp.valueStreamTemplateID,
          createdBy: valuestreamTemp.createdBy
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.createdBy === valuestreamTemp.createdBy)) {
            this.data.push(newItem);
          }
        }
      }
    }

    else if (this.headerFilterName == "valueStreamTemplateDisplayID") {
      for (var valuestreamTemp of this.valueStreamTemplateList) {
        let newItem = {
          valueStreamTemplateID: valuestreamTemp.valueStreamTemplateID,
          valueStreamTemplateDisplayID: valuestreamTemp.valueStreamTemplateDisplayID
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.ValueStreamTemplateDisplayID === valuestreamTemp.valueStreamTemplateDisplayID)) {
            this.data.push(newItem);
          }
        }
      }
    }

    this.settings = {//setting for multiselect dropdown
      singleSelection: false,
      idField: 'valueStreamTemplateID',
      textField: this.headerFilterName,

      lazyLoading: true,
      enableCheckAll: true,
      selectAllText: 'Select All',
      unSelectAllText: 'Unselect All',
      allowSearchFilter: true,
      limitSelection: -1,
      clearSearchFilter: true,
      maxHeight: 197,
      itemsShowLimit: 0,
      searchPlaceholderText: 'Search',
      noDataAvailablePlaceholderText: 'No Data Available',
      closeDropDownOnSelection: false,
      showSelectedItemsAtTop: false,
      defaultOpen: false
    };
    this.setForm();
    // ************************************************
  }

  //#endregion filtering

  /** Method is responsible to Reinitialize Resourcing Table. */
  reInitializeDataTable() {
    if (this.dataTable) {
      this.dataTable.destroy();
      this.dataTable = null;
    }
    this.initializeDataTable();
  }

  initializeDataTable() {
    setTimeout(() => {
      this.dataTable = $('#valuestreams').DataTable({
        "serverSide": true,
        "ordering": false,
        "searching": false,
        "bPaginate": true,
        "bLengthChange": false,
        "bFilter": true,
        "bInfo": false,
        "bAutoWidth": false,
        "pagingType": "full_numbers",
        destroy: true,
        "pageLength": 10,
        language: {
          paginate: {
            next: `<svg class="DP-next" version="1.1" id="Icon_x5F_contour_1_2" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"   viewBox="0 0 192 192"   style="enable-background:new 0 0 192 192;" xml:space="preserve" width="35" height="35"> <g> <polygon points="70.8,158.8 65.2,153.2 122.3,96 65.2,38.8 70.8,33.2 133.7,96 " /> </g> </svg>`,
            previous: `<svg class="DP-prev" version="1.1" id="Icon_x5F_contour_1_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 192 192" style="enable-background:new 0 0 192 192;" xml:space="preserve" width="35" height="35"> <g> <polygon points="121.2,158.8 58.3,96 121.2,33.2 126.8,38.8 69.7,96 126.8,153.2" /> </g> </svg>`,
            first: `<svg version="1.1" id="Icon_x5F_contour" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 192 192" enable-background="new 0 0 192 192" xml:space="preserve" width="18" height="18"><g><polygon points="145.3,158.9 78.3,96.1 141.2,33.2 146.8,38.8 89.7,95.9 150.7,153.1" /></g><g><polygon points="105.3,158.9 38.3,96.1 101.2,33.2 106.8,38.8 49.7,95.9 110.7,153.1" /></g></svg>`,
            last: `<svg version="1.1" id="Icon_x5F_contour" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 192 192" enable-background="new 0 0 192 192" xml:space="preserve" width="18" height="18"><g><polygon points="50.8,158.8 45.2,153.2 102.3,96 45.2,38.8 50.8,33.2 113.7,96 	" /></g><g><polygon points="90.8,158.8 85.2,153.2 142.3,96 85.2,38.8 90.8,33.2 153.7,96 	" /></g></svg>`
          }
        },

        ajax: (dataTablesParameters: any, callback) => {
          this.valuestreamtemplateService.getValueStreamTemplate()
            .subscribe(resp => {
              this.valueStreamTemplateList = resp;
              var out = [];

              for (var i = 0; i < this.valueStreamTemplateList.length; i++) {
                out.push([
                  this.valueStreamTemplateList[i].valueStreamTemplateID,
                  this.valueStreamTemplateList[i].valueStreamTemplateName,
                  this.valueStreamTemplateList[i].isLocked,
                  this.valueStreamTemplateList[i].modifiedAt,
                  this.valueStreamTemplateList[i].createdAt,
                ]);
              }

              setTimeout(function () {
                callback({
                  data: out,
                  recordsTotal: this.valueStreamTemplateList.length,
                  recordsFiltered: this.valueStreamTemplateList.length
                });
              }, 50);
            });
        },

        scrollY: 200,
        scroller: {
          loadingIndicator: true
        },
      });
    }, 1000);
  }


  // ****************************************multiselect dropdown*********************
  filteredItems: Array<any>;
  x: any;

  public onItemSelect(item: any) {

    if (this.filteredItems == undefined) {
      this.filteredItems = [];
    }

    if (this.headerFilterName == 'valueStreamTemplateName') {
      if (this.filteredItems.indexOf(item.valueStreamTemplateName) < 0) {
        this.filteredItems.push(item.valueStreamTemplateName);
      }
      this.valueStreamTemplateList = this.totalList.filter(f => this.filteredItems.includes(f.valueStreamTemplateName));
    }
    else if (this.headerFilterName == 'modifiedAt') {

      if (this.filteredItems.indexOf(item.modifiedAt) < 0) {
        this.filteredItems.push(item.modifiedAt);
      }
      this.valueStreamTemplateList = this.totalList.filter(f => this.filteredItems.includes(this.datePipe.transform(f.modifiedAt, this.filterdateFormat)));
    }

    else if (this.headerFilterName == 'modifiedBy') {
      if (this.filteredItems.indexOf(item.modifiedBy) < 0) {
        this.filteredItems.push(item.modifiedBy);
      }
      this.valueStreamTemplateList = this.totalList.filter(f => this.filteredItems.includes(f.modifiedBy));
    }
    else if (this.headerFilterName == 'createdAt') {
      if (this.filteredItems.indexOf(item.createdAt) < 0) {
        this.filteredItems.push(item.createdAt);
      }
      this.valueStreamTemplateList = this.totalList.filter(f => this.filteredItems.includes(this.datePipe.transform(f.createdAt, this.filterdateFormat)));
    }
    else if (this.headerFilterName == 'createdBy') {
      if (this.filteredItems.indexOf(item.createdBy) < 0) {
        this.filteredItems.push(item.createdBy);
      }
      this.valueStreamTemplateList = this.totalList.filter(f => this.filteredItems.includes(f.createdBy));
    }

    else if (this.headerFilterName == 'valueStreamTemplateDisplayID') {
      if (this.filteredItems.indexOf(item.valueStreamTemplateDisplayID) < 0) {
        this.filteredItems.push(item.valueStreamTemplateDisplayID);
      }
      this.valueStreamTemplateList = this.totalList.filter(f => this.filteredItems.includes(f.valueStreamTemplateDisplayID));
    }

    else if (this.headerFilterName == 'isLocked') {
      if (this.filteredItems.indexOf(item.isLocked) < 0) {
        this.filteredItems.push(item.isLocked);
      }
      this.valueStreamTemplateList = this.totalList.filter(f => this.filteredItems.includes(f.isLocked));
    }

  }


  public onDeSelect(item: any) {

    if (this.filteredItems == undefined) {
      this.filteredItems = [];
    }
    if (this.headerFilterName == 'valueStreamTemplateName') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.valueStreamTemplateName);
      this.valueStreamTemplateList = this.totalList.filter(f => this.filteredItems.includes(f.valueStreamTemplateName));
    }
    else if (this.headerFilterName == 'modifiedAt') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.modifiedAt);
      this.valueStreamTemplateList = this.totalList.filter(f => this.filteredItems.includes(this.datePipe.transform(f.modifiedAt, this.filterdateFormat)));
    }
    else if (this.headerFilterName == 'modifiedBy') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.modifiedBy);
      this.valueStreamTemplateList = this.totalList.filter(f => this.filteredItems.includes(f.modifiedBy));
    }
    else if (this.headerFilterName == 'createdAt') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.createdAt);
      this.valueStreamTemplateList = this.totalList.filter(f => this.filteredItems.includes(this.datePipe.transform(f.createdAt, this.filterdateFormat)));
    }
    else if (this.headerFilterName == 'createdBy') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.createdBy);
      this.valueStreamTemplateList = this.totalList.filter(f => this.filteredItems.includes(f.createdBy));
    }
    else if (this.headerFilterName == 'valueStreamTemplateDisplayID') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.valueStreamTemplateDisplayID);
      this.valueStreamTemplateList = this.totalList.filter(f => this.filteredItems.includes(f.valueStreamTemplateDisplayID));
    }

    else if (this.headerFilterName == 'isLocked') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.isLocked);
      this.valueStreamTemplateList = this.totalList.filter(f => this.filteredItems.includes(f.isLocked));
    }


  }
  onSelectAll(items: any) {

    if (this.filteredItems == undefined) {
      this.filteredItems = [];
    }
    for (var i = 0; i < items.length; i++) {
      if (this.headerFilterName == 'valueStreamTemplateName') {
        this.filteredItems.push(items[i].valueStreamTemplateName);
      }
      else if (this.headerFilterName == 'modifiedAt') {
        this.filteredItems.push(items[i].modifiedAt);
      }
      else if (this.headerFilterName == 'modifiedBy') {
        this.filteredItems.push(items[i].modifiedBy);
      }
      else if (this.headerFilterName == 'createdAt') {
        this.filteredItems.push(items[i].createdAt);
      }
      else if (this.headerFilterName == 'createdBy') {
        this.filteredItems.push(items[i].createdBy);
      }
      else if (this.headerFilterName == 'valueStreamTemplateDisplayID') {
        this.filteredItems.push(items[i].valueStreamTemplateDisplayID);
      }
      else if (this.headerFilterName == 'isLocked') {
        this.filteredItems.push(items[i].isLocked);
      }
    }
    this.valueStreamTemplateList = this.totalList;
  }
  public onDeSelectAll(items: any) {
    this.filteredItems = [];
    this.valueStreamTemplateList = this.totalList;
  }
  public onFilterChange(item: any) {

  }

  onDropDownClose() {
  }


  // *************************************************end multiselct dropwn***************

  addValueStream() {

    this.valueStreamTemplate = new ValueStreamTemplate();
    this.router.navigate([environment.home + '/valuestreams/valuestreams-edit']);
  }


  ExportExcel() {

    window.location.href = environment.baseUrl + 'ValueStreamTemplate/ExportExcel';

  }
  importAsXLSX() {

    let formData = new FormData();
    formData.append('upload', this.fileInput.nativeElement.files[0])
    this.valuestreamtemplateService.ImportExcel(formData).subscribe(result => {
      this.getValueStreamTemplateList();
    });

  }


  order: string = "displayName";
  reverse: boolean = false;
  setOrder(value: string) {
    if (this.order === value) {
      this.reverse = !this.reverse;
    }

    this.order = value;
  }
  //resetting all the filtering and sorting
  resetAll() {
    this.reverse1 = false;
    this.filtertext = "";
  }
  //*********************sorting*********
  sort(key) {
    this.key = this.headerFilterName;
    this.reverse1 = !this.reverse1;
  }
  getButtonType(buttonname: any): any {

    this.filterType = buttonname;
  }
  // *********************************

  getColumnName(headername: any) {

    if (this.filteredItems == undefined) {
      this.filteredItems = []
    }

    this.valueStreamTemplateList = this.totalList;//newly added
    this.filtertext = '';
    this.filterId = false;
    this.filterName = false;
    this.filterLock = false;
    this.filterModified = false;
    this.filterModifiedBy = false;
    this.filterCreated = false;
    this.filterCreatedBy = false;

    if (headername == 'valueStreamTemplateDisplayID') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].valueStreamTemplateDisplayID);
      }
      this.filterId = !this.filterId;

    }

    else if (headername == 'valueStreamTemplateName') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].valueStreamTemplateName);
      }
      this.filterName = !this.filterName;
    }
    else if (headername == 'isLocked') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].isLocked);
      }
      this.filterLock = !this.filterLock;
    }
    else if (headername == 'modifiedAt') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.datePipe.transform(this.totalList[i].modifiedAt,this.filterdateFormat));
      }
      this.filterModified = !this.filterModified;
    }
    else if (headername == 'modifiedBy') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].modifiedBy);
      }
      this.filterModifiedBy = !this.filterModifiedBy;
    }
    else if (headername == 'createdAt') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.datePipe.transform(this.totalList[i].createdAt,this.filterdateFormat));
      }
      this.filterCreated = !this.filterCreated;
    }
    else if (headername == 'createdBy') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].createdBy);
      }
      this.filterCreatedBy = !this.filterCreatedBy;
    }
    this.headerFilterName = headername;
    this.searchFilter();
  }

  // ************************************************
  //This function is called on keyup and checks the checkbox on that row and adds new row if the action was on the last row
  myrow = {
    valueStreamCategoryName: 'Col2', inputType: 'text', isDataRequiredToFitSpecLength: false, minimumNoOfCharacters: 1, maximumNoOfCharacters: 3,
    isDataRequired: true, valueitem: 'ok'
  };



  public getValueStreamTemplateList() {
    this.valuestreamtemplateService.getValueStreamTemplate().subscribe(res => {
      this.valueStreamTemplateList = res;
      this.sharedService.hide();
      if (this.valueStreamTemplateList != null && this.valueStreamTemplateList.length > 0) {
        this.totalList = this.valueStreamTemplateList;//mk
        if (this.sharedService.activeDateRange != null && this.sharedService.activeDateRange.vsSearchText != null 
          &&  this.sharedService.activeDateRange.vsSearchText.length > 0 ) {
          this.vsSearchText = this.sharedService.activeDateRange.vsSearchText;
          this.searchGrid(this.sharedService.activeDateRange.vsSearchText);
        }
      }
      this.sharedService.hide();
    },
      err => {
        this.sharedService.hide();
      }
    );
  }

  proxies: any;
  proxy: any;
  alertText;
  // ************************************************************************************
  updateTemplate(valueStreamTemplate: any) {

    if (valueStreamTemplate.isLocked) {
      this.valuestreamtemplateService.valueStreamProxiesByTemplateID(valueStreamTemplate.valueStreamTemplateID).subscribe(res => {
        this.proxies = res;

        let ProxyCreatedBy = new ValueStreamProxy();
        ProxyCreatedBy.userName = valueStreamTemplate.createdBy;
        ProxyCreatedBy.ntid = valueStreamTemplate.createdBy_NTID;
        ProxyCreatedBy.createdBy_NTID = valueStreamTemplate.createdBy_NTID;
        ProxyCreatedBy.modifiedBy_NTID = valueStreamTemplate.modifiedBy_NTID;
        if (!this.proxies.some(e => valueStreamTemplate.createdBy_NTID != null && e.ntid.toLowerCase() === valueStreamTemplate.createdBy_NTID.toLowerCase())) {
          this.proxies.push(ProxyCreatedBy);
        }

        let ProxyModified = new ValueStreamProxy();
        ProxyModified.userName = valueStreamTemplate.modifiedBy;
        ProxyModified.ntid = valueStreamTemplate.modifiedBy_NTID;
        ProxyModified.createdBy_NTID = valueStreamTemplate.createdBy_NTID;
        ProxyModified.modifiedBy_NTID = valueStreamTemplate.modifiedBy_NTID;
        if (!this.proxies.some(e => valueStreamTemplate.modifiedBy_NTID != null && e.ntid.toLowerCase() === valueStreamTemplate.modifiedBy_NTID.toLowerCase())) {
          this.proxies.push(ProxyModified);
        }

        if (this.sharedService.ntid && this.proxies && this.proxies.length > 0) {
          this.proxy = this.proxies.filter(x => x.ntid == this.sharedService.ntid
            || (x.createdBy_NTID != null && x.createdBy_NTID.toLowerCase() == this.sharedService.ntid.toLowerCase())
            || (x.modifiedBy_NTID != null && x.modifiedBy_NTID.toLowerCase() == this.sharedService.ntid.toLowerCase())); //checking for the proxy, designer, who locked the record

        }
        if (this.proxy && this.proxy.length > 0) {
          this.valuestreamtemplateService.valueStreamTemplate = valueStreamTemplate;
          this.router.navigate([environment.home + '/valuestreams/valuestreams-edit']);
        }

        else {
          this.alertText = this.labels.default.notAuthorizedToEdit;
          this.modalService.show(this.lockModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          this.router.navigate([environment.home + '/valuestreams']);
        }
      }, err => console.error(err));
    }
    else {
      this.valuestreamtemplateService.valueStreamTemplate = valueStreamTemplate;
      this.router.navigate([environment.home + '/valuestreams/valuestreams-edit']);
    }

  }

  // ***************************************************************************************

  // ***********************************************************************


  /** Method is responsible to move to first page of the pagination. */
  isFirstPage() {
    if (this.page == 1) {
      return;
    }
    else {
    }

    this.page = 1;
    this.startPage = (this.page - 1) * 4 + 1;
    this.endPage = this.page * this.resultPerPage;
  }

  /** Method is responsible to move to last page of the pagination. */
  isLastPage() {
    if (Math.ceil(this.valueStreamTemplateList.length / this.resultPerPage) <= this.page) {
      return;
    }
    else {

    }

    this.page = Math.ceil(this.valueStreamTemplateList.length / this.resultPerPage);
    this.startPage = (this.page - 1) * 4 + 1;
    this.endPage = this.page * this.resultPerPage;
  }

  /** Method is responsible to change page of the pagination. */
  pageChanged(event): void {

    if (event == 0) {
      return;
    }
    else if (Math.ceil(this.valueStreamTemplateList.length / this.resultPerPage) < event) {
      return;
    }
    else {
      this.page = event;
      this.startPage = (this.page - 1) * 4 + 1;
      this.endPage = this.page * this.resultPerPage;
    }
  }
  ExportExcelValueStream() {
    this.dataPoolService.GetExcelFile("ValueStream");
  }

  exportAsXLSX() {
    var IDs = this.valueStreamTemplateList.map(r => {
      return r.valueStreamTemplateID
    });
    this.dataPoolService.GetExcelFileByIDs("ValueStream", IDs);
  }

  searchGrid(value: string) {
    if (value.length > 0) {
      var searchText = value.trim().toLowerCase();
      this.sharedService.activeDateRange.vsSearchText = value;
      this.valueStreamTemplateList = this.totalList;

      this.valueStreamTemplateList = this.valueStreamTemplateList.filter(x =>
           (x.valueStreamTemplateName != null && x.valueStreamTemplateName.trim().toLowerCase().includes(searchText)) 
        || (x.isLocked != null && x.isLocked.toString().trim().toLowerCase().includes(searchText)) 
        || (x.modifiedAt != null && this.datePipe.transform(x.modifiedAt,this.filterdateFormat).trim().toLowerCase().includes(searchText)) 
        || (x.modifiedBy != null && x.modifiedBy.trim().toLowerCase().includes(searchText))
        || (x.createdAt != null && this.datePipe.transform(x.createdAt,this.filterdateFormat).trim().toLowerCase().includes(searchText)) 
        || (x.createdBy != null && x.createdBy.trim().toLowerCase().includes(searchText))
      );
      this.page = 1;
    }
    else {
      this.valueStreamTemplateList = this.totalList;
      this.sharedService.activeDateRange.vsSearchText = "";
    }
  }

}
export class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}

