export class RecycleBinTemplate {
  iD: number;
  itemType: string;
  itemName: string;
  deletedBy: string;
  deleted: Date;
  modifiedBy : string
  selected: boolean;
  rowNumber: number;
  resultCode: number;
}

