import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'columnFilter'
})
export class ColumnFilterPipe implements PipeTransform {

  // transform(value: any, args?: any): any {
  transform(value: any, args1: any, args2: any, args3: any): any {
    
//console.log(value);//list
//console.log(args1);//inputs from the etxtbox
//console.log(args2);//type like equals
//console.log(args3);//column name like valuestreamtemplatename

    //here value is array,args1 is input,arg2 is filtertype lik equal,not equal etc,args3 is column name

//     let filter;
//         let newValue;
//         // check if search term is undefined
//         if (!args1 || args2 == 'test') {
//             return value;
//         } else if (args1) {
//             filter = args1.toLocaleLowerCase();
//         }

//         if (filter && value) {
//             // newValue = value.filter((alias) => alias.local_part.toLocaleLowerCase().indexOf(filter) !== -1 || alias.domain.toLocaleLowerCase().indexOf(filter) !== -1);
//             newValue=  value.filter(
//               product => product.toLowerCase().includes(filter.toLowerCase())
//             )
//         } else {
//             newValue = value;
//         }

// console.log(newValue);
    if (!args1 || args2 == 'test') {
      return value;
    }
    // else {
    //   args1 = args1.toUpperCase();
    // }
   

      return value.filter(items => {
        //debugger;
        //  items[args3] = items[args3].toUpperCase();
        

        if (args2 == 'equals') {
         
// //debugger;
// var arr = [];
// arr = args1.split(',');
// console.log(arr);
// var arr1 = [];
// let vs;
// for (let i in arr) {
//           if(items[args3]==arr[i]){
//             vs=true;  
//           }  
//           else{
//             vs=false;
//           }
//           // if(!arr1){
//           //   arr1 = [];
//           // }
//           if(vs){
//             arr1.push(vs);
//           }
//           }
          //for loop ends
      
          //return (value || []).filter(item => args1.split(',').some(key => item.hasOwnProperty(key) && new RegExp(args1, 'gi').test(item[key])));

            return items[args3].toUpperCase()==args1.toUpperCase()==true;

        }

        else if (args2 == 'notEquals') {
          return items[args3].toUpperCase() == args1.toUpperCase() == false;
        }

        else if (args2 == 'startsWith') {

          return items[args3].toUpperCase().startsWith(args1.toUpperCase()) == true
        }
        else if (args2 == 'endsWith') {
          return items[args3].toUpperCase().endsWith(args1.toUpperCase()) == true
        }
        else if (args2 == 'contains') {
          return items[args3].toUpperCase().indexOf(args1.toUpperCase()) !== -1
        }
        else if (args2 == 'notContains') {
          return items[args3].toUpperCase().indexOf(args1.toUpperCase()) == -1
        }


      })//filter ends
   
  }

}
