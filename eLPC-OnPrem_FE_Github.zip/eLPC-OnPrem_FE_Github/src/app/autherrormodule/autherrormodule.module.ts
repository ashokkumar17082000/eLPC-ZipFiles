import { NgModule ,CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthErrorComponent } from './auth-error/auth-error.component';
import { AutherrormoduleRoutingModule } from './autherrormodule-routing.module';


@NgModule({
  declarations: [AuthErrorComponent],
  imports: [
    CommonModule,
    AutherrormoduleRoutingModule
  ],
  
  schemas: [CUSTOM_ELEMENTS_SCHEMA] // Add this line
})
export class AutherrormoduleModule { }
