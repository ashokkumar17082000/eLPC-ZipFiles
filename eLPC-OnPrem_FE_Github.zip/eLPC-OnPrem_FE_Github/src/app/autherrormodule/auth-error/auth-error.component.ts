import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
//import { template } from '@angular/core/src/render3';
import { Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
//import { LanguageService } from '../language.service';
import { LanguageService } from 'src/app/language.service';
//import { CommonService } from '../service/common/common.service';
import { CommonService } from 'src/app/service/common/common.service';
//import { SharedService } from '../service/shared.service';
import { SharedService } from 'src/app/service/shared.service';
// import * as english from "../../assets/localize/eng.json";
//import { User } from '../main/body/shared/common';
import { User } from 'src/app/main/body/shared/common';
@Component({
  selector: 'app-appinfo',
  templateUrl: './auth-error.component.html',
  styleUrls: ['./auth-error.component.css']
})
export class AuthErrorComponent implements OnInit {
  displayMessage: string;
  UserPlantDetails: any;
  originalPlantID : number;
  key: string = 'name';//for sorting
  reverse1: boolean = false;//for sorting
  headerFilterName:string="";//for filtering
  page: number = 1;
  resultPerPage: number = 5;
  startPage: number;
  endPage: number;
  defaultPlantID: any;
  defaultPlantName: string;
  slectedPlantDescription: string;
  isSetAsDefault: boolean = false;

  modalRef: BsModalRef;
  @ViewChild('plantTemplate') plantTemplateModal: TemplateRef<any>;
  @ViewChild('alertPopup') warningModal : TemplateRef<any>;

  config = {
    animated: false,
    keyboard: true,
    ignoreBackdropClick: true
  };
  labels: any;
  private _subscription: any;
  alertText: any;

  constructor(private router: Router, private commonService: CommonService, private sharedService:SharedService,private local_label:LanguageService, private modalService: BsModalService) {

    if (this.sharedService.sharedUserDetails != null && this.sharedService.sharedUserDetails.avaliablePlants != null && this.sharedService.sharedUserDetails.avaliablePlants.length > 0) {
      this.UserPlantDetails = JSON.parse(JSON.stringify(this.sharedService.sharedUserDetails.avaliablePlants));
    }

    if(this.sharedService.showPlantSelectionPopup)
    {
      this.open(this.plantTemplateModal);
    }
  }

  ngOnInit() {
    this.sharedService.hide();
    this.displayMessage = this.sharedService.errorMessage;

    if (this.sharedService.showPlantSelectionPopup) {
      this.open(this.plantTemplateModal);
    }
    this.updateLanguage("EN");
  }

  async updateLanguage(languageCode) {
    this.labels = await this.local_label.changeLanguage(languageCode);
  }


  open(template: TemplateRef<any>) {
    this.isSetAsDefault = false;
    let defaultPlant = JSON.parse(JSON.stringify(this.sharedService.sharedUserDetails.avaliablePlants)).filter(item => item.isDefault == true);
    if (defaultPlant.length > 0) {
      this.defaultPlantID = defaultPlant[0].plantID;
      this.defaultPlantName = defaultPlant[0].plantCode + '-' + defaultPlant[0].plantName;
    }

    this.modalRef = this.modalService.show(template, this.config);
    this.modalRef.setClass('modal-lg calendar-modal');
  }

  onPlantDescriptionChange(plantID: Number) {
    this.slectedPlantDescription = "";
    let selectedPlant = this.UserPlantDetails.filter(item => item.plantID == plantID);
    if (selectedPlant.length > 0) {
      this.slectedPlantDescription = selectedPlant[0].generalMessage;
    }
  }

  onPlantSelectionChange(plantID: Number) {
    this.UserPlantDetails.forEach(item => {
      item.isDefault = false;
      if (item.plantID == plantID) {
        item.isDefault = true;
      }
    });
  }

  doFilter = (value: string) => {
    this.UserPlantDetails = JSON.parse(JSON.stringify(this.sharedService.sharedUserDetails.avaliablePlants));

    if (value.length > 0) {
      this.UserPlantDetails = this.UserPlantDetails.filter(x =>
        x.plantCode.trim().toLowerCase().includes(value.trim().toLowerCase()) || 
        x.plantName.trim().toLowerCase().includes(value.trim().toLowerCase()) || 
        x.currentDisplayRole.trim().toLowerCase().includes(value.trim().toLowerCase()) 
      );
      this.page = 1;
    }
  }

  save() {
    this.page = 1;
    let selectedPlant = this.UserPlantDetails.filter(item => item.isDefault == true);
    if (selectedPlant.length > 0) {
      
      if(!selectedPlant[0].isActive || selectedPlant[0].isUnderMaintenance)
        return;

      if (this.defaultPlantID == selectedPlant[0].plantID) {
        this.closeAlertModal(true);
      }
      else {
        this.closeAlertModal(false);
        this.sharedService.show();
        this.sharedService.apiURL = "";
        this.sharedService.plantID = selectedPlant[0].plantID;
        this.sharedService.currentUserInfo = selectedPlant[0];
        //this.sharedService.currentRole = selectedPlant[0].currentRole;

        var NTID = this.sharedService.ntid;

        if (NTID == null || NTID == undefined || NTID == "") {
          NTID = localStorage.getItem('ntid');
          this.sharedService.ntid = NTID;
        }

        //If first time login set current selected plant as default
        if(this.defaultPlantID == undefined)
        {
          this.isSetAsDefault = true;
        }

        if (this.isSetAsDefault) {

          var user = new User();
          user.emailAddress = this.sharedService.sharedUserDetails.emailAddress;
          user.firstName = this.sharedService.sharedUserDetails.firstName;
          user.lastName = this.sharedService.sharedUserDetails.lastName;
          user.ntid  = this.sharedService.sharedUserDetails.ntid;
          user.plantID = selectedPlant[0].plantID;
          user.userName = this.sharedService.sharedUserDetails.userName;

          this.sharedService.SetDefaultPlant(user).subscribe(res => {

          });
        }
        this.sharedService.GetEnironmentConfigFromDBAndLogin(NTID, this.router, "/dashboard");
        this.sharedService.hide();
      }
    }
    else {
      this.alertText = this.labels.default.selectChoice;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
    }
  }

  public closeAlertInfo() {
    if (document.getElementsByTagName("modal-container").length > 1) {
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1]);
    }
    else {
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if (document.getElementsByTagName("bs-modal-backdrop").length > 0) {
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }
  }

  public closeAlertModal(isCancel:boolean = true) {
    this.page = 1;
    if(isCancel)
    {
      this.UserPlantDetails = JSON.parse(JSON.stringify(this.sharedService.sharedUserDetails.avaliablePlants));
    }
    if (document.getElementsByTagName("modal-container").length > 1) {
      //document.getElementsByTagName("modal-container").parentNode.removeChild(document.getElementsByTagName("modal-container"));
      if (document.getElementsByTagName("bs-modal-backdrop").length > 0) {
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      $("modal-container").remove();
    }
    else {
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if (document.getElementsByTagName("bs-modal-backdrop").length > 0) {
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }
  }


  isFirstPage() {
    if (this.page == 1) {
      return;
    }
    else {
    }

    this.page = 1;
    this.startPage = (this.page - 1) * 4 + 1;
    this.endPage = this.page * this.resultPerPage;
  }

  /** Method is responsible to move to last page of the pagination. */
  isLastPage() {
    if (Math.ceil(this.UserPlantDetails.length / this.resultPerPage) <= this.page) {
      return;
    }
    else {

    }

    this.page = Math.ceil(this.UserPlantDetails.length / this.resultPerPage);
    this.startPage = (this.page - 1) * 4 + 1;
    this.endPage = this.page * this.resultPerPage;
  }

  /** Method is responsible to change page of the pagination. */
  pageChanged(event): void {

    if (event == 0) {
      return;
    }
    else if (Math.ceil(this.UserPlantDetails.length / this.resultPerPage) < event) {
      return;
    }
    else {
      this.page = event;
      this.startPage = (this.page - 1) * 4 + 1;
      this.endPage = this.page * this.resultPerPage;
    }
  }

  
}





