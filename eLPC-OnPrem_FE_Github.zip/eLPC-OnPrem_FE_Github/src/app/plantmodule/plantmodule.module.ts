import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PlantComponent } from './plant/plant.component';
import { PlantmoduleRoutingModule } from './plantmodule-routing.module';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [PlantComponent],
  imports: [
    CommonModule,
    PlantmoduleRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  
  schemas: [CUSTOM_ELEMENTS_SCHEMA] // Add this line
})
export class PlantmoduleModule { }
