CREATE TYPE [RecycleTable] AS TABLE(
	[ID] [int] NULL,
	[PlantID] [int] NOT NULL,
	[ItemType] [nvarchar](max) NULL,
	[ItemName] [nvarchar](max) NULL,
	[DeletedBy] [nvarchar](max) NULL,
	[ModifiedBy] [nvarchar](max) NULL,
	[Deleted] [datetime] NULL,
	[Selected] [bit] NULL
)
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*  
///<SUMMARY>  
///DESCRIPTION                  : FUNCTION - [FN_GetNextDisplayID]
///AUTHOR                       : VENKATESH GOVINDARAJ
///CREATED DATE                 : 12-MAR-2021
///SEE ALSO                     : THIS FUNCTION IS USED FOR GENERATE NEXT DISPLAYID FOR THE GIVEN TABLE NAME
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_002					12-MAR-2021			VENKATESH GOVINDARAJ		INITIAL VERSION

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
SELECT DisplayID from [FN_GetNextDisplayID] (1,'T_TRN_Deviation')
*/

CREATE FUNCTION [FN_GetNextDisplayID] (
	@PlantID INT
	,@TableName VARCHAR(100)
	)
RETURNS @DisplayID TABLE ([DisplayID] INT NOT NULL)
AS
BEGIN
	DECLARE @GetDisplayID INT

	SELECT @GetDisplayID = CASE @TableName
			WHEN 'T_TRN_Deviation'
				THEN (
						SELECT TOP 1 DeviationDisplayID
						FROM T_TRN_Deviation
						WHERE PlantID = @PlantID
						ORDER BY DeviationID DESC
						)
			WHEN 'T_TRN_ValueStreamTemplate'
				THEN (
						SELECT TOP 1 ValueStreamTemplateDisplayID
						FROM T_TRN_ValueStreamTemplate
						WHERE PlantID = @PlantID
						ORDER BY ValueStreamTemplateID DESC
						)
			WHEN 'T_TRN_AssessorTemplate'
				THEN (
						SELECT TOP 1 AssessorTemplateDisplayID
						FROM T_TRN_AssessorTemplate
						WHERE PlantID = @PlantID
						ORDER BY AssessorTemplateID DESC
						)
			WHEN 'T_TRN_Tag'
				THEN (
						SELECT TOP 1 TagDisplayID
						FROM T_TRN_Tag
						WHERE PlantID = @PlantID
						ORDER BY TagID DESC
						)
			WHEN 'T_TRN_Question'
				THEN (
						SELECT TOP 1 QuestionDisplayID
						FROM T_TRN_Question
						WHERE PlantID = @PlantID
						ORDER BY QuestionID DESC
						)
			WHEN 'T_TRN_DataPool'
				THEN (
						SELECT TOP 1 DataPoolDisplayID
						FROM T_TRN_DataPool
						WHERE PlantID = @PlantID
						ORDER BY DataPoolID DESC
						)
			END

	IF (
			@GetDisplayID IS NULL
			OR @GetDisplayID = 0
			)
	BEGIN
		SET @GetDisplayID = 1
	END
	ELSE
	BEGIN
		SET @GetDisplayID = @GetDisplayID + 1
	END

	INSERT INTO @DisplayID ([DisplayID])
	VALUES (@GetDisplayID);

	RETURN;
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*  
///<SUMMARY>  
///DESCRIPTION                  : FUNCTION - [FN_GetNextHistoryDisplayID]
///AUTHOR                       : KARTHIKEYAN KANDASAMY
///CREATED DATE                 : 05-APR-2021
///SEE ALSO                     : THIS FUNCTION IS USED FOR GENERATE NEXT DISPLAYID FOR HISTORY ON THE GIVEN TABLE NAME
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_002					05-APR-2021			KARTHIKEYAN KANDASAMY		INITIAL VERSION

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
SELECT * from [FN_GetNextHistoryDisplayID] (1,'T_HST_ValueStreamTemplateHistory',1)
*/
CREATE FUNCTION [FN_GetNextHistoryDisplayID] (
	@PlantID INT
	,@TableName VARCHAR(100)
	,@TemplateID INT
	)
RETURNS @DisplayID TABLE ([DisplayID] INT NOT NULL)
AS
BEGIN
	DECLARE @GetDisplayID INT;

	SELECT @GetDisplayID = CASE @TableName
			WHEN 'T_HST_ValueStreamTemplateHistory'
				THEN (
						SELECT TOP 1 ValueStreamTemplateHistoryDisplayID
						FROM T_HST_ValueStreamTemplateHistory WITH(NOLOCK)
						WHERE PlantID = @PlantID
							AND ValueStreamTemplateID = @TemplateID
						ORDER BY ValueStreamTemplateHistoryID DESC
						)
			WHEN 'T_TRN_AssessorTemplateHistory'
				THEN (
						SELECT TOP 1 AssessorTemplateHistoryDisplayID
						FROM T_TRN_AssessorTemplateHistory  WITH(NOLOCK)
						WHERE PlantID = @PlantID
							AND AssessorTemplateID = @TemplateID
						ORDER BY AssessorTemplateHistoryID DESC
						)
			WHEN 'T_TRN_TagHistory'
				THEN (
						SELECT TOP 1 TagHistoryDisplayID
						FROM T_TRN_TagHistory  WITH(NOLOCK)
						WHERE PlantID = @PlantID
							AND TagID = @TemplateID
						ORDER BY TagHistoryID DESC
						)
			WHEN 'T_TRN_QuestionHistory'
				THEN (
						SELECT TOP 1 QuestionHistoryDisplayID
						FROM T_TRN_QuestionHistory  WITH(NOLOCK)
						WHERE PlantID = @PlantID
							AND QuestionID = @TemplateID
						ORDER BY QuestionHistoryID DESC
						)
			WHEN 'T_TRN_DataPoolHistory'
				THEN (
						SELECT TOP 1 DataPoolHistoryDisplayID
						FROM T_TRN_DataPoolHistory  WITH(NOLOCK)
						WHERE PlantID = @PlantID
							AND DataPoolID = @TemplateID
						ORDER BY DataPoolHistoryID DESC
						)
			END

	IF (
			@GetDisplayID IS NULL
			OR @GetDisplayID = 0
			)
	BEGIN
		SET @GetDisplayID = 1;
	END
	ELSE
	BEGIN
		SET @GetDisplayID = @GetDisplayID + 1;
	END

	INSERT INTO @DisplayID ([DisplayID])
	VALUES (@GetDisplayID);

	RETURN;
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*  
///<SUMMARY>  
///DESCRIPTION                  : FUNCTION - [fnGetDateTime]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS FUNCTION IS USED FOR GET PLANT SPECIFIC DATE AND TIME FORMAT
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
select FormattedDateTime from [fnGetDateTime](1)
*/
CREATE FUNCTION [fnGetDateTime] (
	@PlantID INT
)
RETURNS @dateTime TABLE (FormattedDateTime DATETIME NOT NULL)
AS
BEGIN
	DECLARE @UTCDateTime DATETIME = GETUTCDATE();
	DECLARE @ConvertedZoneDateTime DATETIME;
	DECLARE @TimeZoneName NVARCHAR(100);

	SET @TimeZoneName = CASE 
			--BhP, SgmP, BrhP, MlsP, WwP, HlP, HiP, SeP, TbP, WaP, EhP, RtP2, SzP, BaP, BarP, FeP, MagP, MrP, CC, NuP1, RzP, HoP1, PS, RBEF, OfoP, RBCB
			WHEN @PlantID IN (1, 4, 16, 37, 64, 5, 6, 55, 61, 63, 23, 53, 60, 11, 12, 24, 36, 38, 66, 41, 54, 29, 45, 51, 42, 48)
				THEN 'W. Europe Standard Time'
			--Test, HtvP, MoP, RtP1, RBEM, GlnP, Abt, CCL5, BrmP, JhP, MtP, LeP, AnP, FraP, Che, GleP, VxP ,AfP ,HorP ,CCLW, RvP, DCC ,NntP ,NuP2,SwP,Pas
			WHEN @PlantID IN (80, 74, 75, 77, 81, 87, 102, 103, 82, 31, 92, 89, 104, 86, 106, 107, 109, 110, 114, 115, 99, 116 , 120 ,121, 122, 123)
				THEN 'W. Europe Standard Time'
			--ChP, AdP, FleP, JpP, KwP, FniP ,Chr, LctP
			WHEN @PlantID IN (2, 8, 7, 33, 35, 112, 113, 88)
				THEN 'Eastern Standard Time'
			--CljP, BljP
			WHEN @PlantID IN (3, 14)
				THEN 'GTB Standard Time'
			--AguP, QueP, SlpP
			WHEN @PlantID IN (9, 47, 56)
				THEN 'Central Standard Time (Mexico)'
			--AmaP, HcP, HmjP, RBIY
			WHEN @PlantID IN (10, 26, 28, 52)
				THEN 'SE Asia Standard Time'
			--SmrP, Eng2
			WHEN @PlantID IN (57, 85)
				THEN 'Russia Time Zone 3'
			--SzhB, SzhC, CgdP, NjP, JnaP, RBCW, RBCD, HzP, Wuj1, SzhA, PujP, QinP, XiP, Wuj2, PkP
			WHEN @PlantID IN (67, 68, 69, 70, 32, 50, 49, 72, 79, 78, 98, 46, 117, 118, 119)
				THEN 'China Standard Time'	
			--CaP, CtP, SrbP, CaPT, PoP
			WHEN @PlantID IN (19, 21, 58, 95, 108)
				THEN 'E. South America Standard Time'
			--NaP, ChkP, BiD1, GanP, JaP, NhP1, ChiP
			WHEN @PlantID IN (40, 20, 13, 25, 30, 76, 83)
				THEN 'India Standard Time'
			--HigP, MusP, TgP, YhP, YorP
			WHEN @PlantID IN (27, 39, 62, 71, 65)
				THEN 'Tokyo Standard Time'
			--JuP1, CeaP
			WHEN @PlantID IN (34, 73)
				THEN 'Mountain Standard Time (Mexico)'
			--PgP1, PgP3, PgP2
			WHEN @PlantID IN (43, 44, 94)
				THEN 'Singapore Standard Time'
			--BuP1, BuP3
			WHEN @PlantID IN (17, 18)
				THEN 'Turkey Standard Time'
			--DaeP
			WHEN @PlantID IN (22)
				THEN 'Korea Standard Time'
			--BrgP 
			WHEN @PlantID IN (15)
				THEN 'GMT Standard Time'
			--Dev
			ELSE 'India Standard Time'
			END

	SET @ConvertedZoneDateTime = @UTCDateTime AT TIME ZONE 'UTC' AT TIME ZONE @TimeZoneName

	INSERT INTO @dateTime (FormattedDateTime)
	VALUES (@ConvertedZoneDateTime);

	RETURN;
END;
GO


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*  
///<SUMMARY>  
///DESCRIPTION                  : FUNCTION - [fnSplit]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS FUNCTION IS USED FOR SPLITTING/TRIMMING OF INPUT
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
EXEC [fnSplit]
*/
CREATE FUNCTION [fnSplit] (
	-- Add the parameters for the function here
	@input NVARCHAR(MAX)
	)
RETURNS @retBigint TABLE ([Value] [BIGINT] NOT NULL)
AS
BEGIN
	DECLARE @int NVARCHAR(MAX);
	DECLARE @pos [INT];

	SET @input = LTRIM(RTRIM(@input)) + ',';-- TRIMMING THE BLANK SPACES
	SET @pos = CHARINDEX(',', @input, 1);-- OBTAINING THE STARTING POSITION OF COMMA IN THE GIVEN STRING

	IF REPLACE(@input, ',', '') <> '' -- CHECK IF THE STRING EXIST FOR US TO SPLIT
	BEGIN
		WHILE @pos > 0
		BEGIN
			SET @int = LTRIM(RTRIM(LEFT(@input, @pos - 1)));-- GET THE 1ST INT VALUE TO BE INSERTED

			IF @int <> ''
			BEGIN
				INSERT INTO @retBigint (Value)
				VALUES (CAST(@int AS int));
			END;

			SET @input = RIGHT(@input, LEN(@input) - @pos);-- RESETTING THE INPUT STRING BY REMOVING THE INSERTED ONES
			SET @pos = CHARINDEX(',', @input, 1);-- OBTAINING THE STARTING POSITION OF COMMA IN THE RESETTED NEW STRING
		END;
	END;

	RETURN;
END;
GO



/*  
///<SUMMARY>  
///DESCRIPTION                  : FUNCTION - [FN_GetNestedQuestionsByTagID]
///AUTHOR                       : CHHETRI MONASH
///CREATED DATE                 : 01-OCT-2021
///SEE ALSO                     : THIS FUNCTION IS USED FOR SPLITTING/TRIMMING OF INPUT
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_002					01-OCT-2021			CHHETRI MONASH		INITIAL VERSION

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
SELECT distinct QuestionID FROM [FN_GetNestedQuestionsByTagID](3,1)
*/
CREATE FUNCTION [FN_GetNestedQuestionsByTagID] (
	@TagID INT
	,@PlantID INT
	)
RETURNS @NestedQuestions TABLE (QuestionID INT)
AS
BEGIN
	DECLARE @tempCTE TABLE (
		tagID INT
		,lnkTagID INT
		);
	DECLARE @AQ TABLE (questionID INT);
	DECLARE @TRNQ TABLE (questionID INT);;

	WITH CTE
	AS (
		SELECT TAQ.TagID AS tagID
			,TAQ.LinkedTagID AS lnkTagID
			,0 AS rowCounter
		FROM [T_LNK_Tag_AssignedQuestionsTags] TAQ WITH (NOLOCK)
		WHERE TAQ.IsDeleted = 0
			AND TAQ.TagID = @TagID
		
		UNION ALL
		
		SELECT AQT.TagID AS tagID
			,AQT.LinkedTagID AS lnkTagID
			,(rowCounter + 1) AS rowCounter
		FROM CTE
		INNER JOIN [T_LNK_Tag_AssignedQuestionsTags] AQT WITH (NOLOCK) ON CTE.lnkTagID = AQT.TagID
			AND AQT.IsDeleted = 0
			AND AQT.LinkedTagID NOT IN (CTE.TagID)
			AND lnkTagID NOT IN (
				SELECT TagID
				FROM [T_LNK_Tag_AssignedQuestionsTags] WITH (NOLOCK)
				WHERE IsDeleted = 0
					AND TagID = @TagID
				)
			AND CTE.rowCounter < 5
		)
	INSERT INTO @tempCTE (
		tagID
		,lnkTagID
		)
	SELECT tagID
		,lnkTagID
	FROM CTE

	--FETCH LINKED TAG QUESTIONS BASED ON TagID FROM T_LNK_Tag_AssignedQuestionsTags
	INSERT INTO @AQ (questionID)
	SELECT questionID
	FROM (
		SELECT DISTINCT (QuestionID)
		FROM [T_LNK_Tag_AssignedQuestionsTags] WITH (NOLOCK)
		WHERE IsDeleted = 0
			AND LinkedTagID IS NULL
			AND (
				TagID IN (
					SELECT tagID
					FROM @tempCTE
					)
				OR TagID IN (
					SELECT lnkTagID
					FROM @tempCTE
					)
				OR TagID = @TagID 
				)
		) AS Table1
	
	UNION
	
	(
		SELECT DISTINCT (QuestionID)
		FROM T_LNK_QN_AssignedTags WITH (NOLOCK)
		WHERE (
				TagID IN (
					SELECT tagID
					FROM @tempCTE
					)
				OR TagID IN (
					SELECT lnkTagID
					FROM @tempCTE
					)
				OR TagID = @TagID  
				)
			AND (isDeleted = 0)
		)

	--FETCH SUPPRESS QUESTION NOT BASED ON TagID
	DECLARE @IsSingleQuestionSuppressed INT = 0

	SET @IsSingleQuestionSuppressed = (
			SELECT TOP 1 IsSingleQuestionSuppressed
			FROM T_TRN_Tag WITH (NOLOCK)
			WHERE TagID = @TagID
			)

	INSERT INTO @TRNQ (questionID)
	SELECT QuestionID
	FROM (
		SELECT DISTINCT (QuestionID)
		FROM T_TRN_Question WITH (NOLOCK)
		WHERE PlantID = @PlantID
			AND (
				IsQuestionAlwaysActive = 1
				OR (
					@IsSingleQuestionSuppressed = 1
					AND IsQuestionAlwaysActive = 0
					AND (
						(CAST(ActiveDateRangeFrom AS DATE) >= CAST(- 53690 AS DATETIME))
						AND (CAST(ActiveDateRangeTo AS DATE) < = CAST('12/31/9999' AS DATE))
						)
					)
				OR (
					cast(@IsSingleQuestionSuppressed AS INT) <> 1
					AND IsQuestionAlwaysActive = 0
					AND (
						(
							CAST((
									SELECT FormattedDateTime
									FROM fnGetDateTime(@PlantID)
									) AS DATE) >= CAST(ActiveDateRangeFrom AS DATE)
							)
						AND (
							CAST((
									SELECT FormattedDateTime
									FROM fnGetDateTime(@PlantID)
									) AS DATE) <= CAST(ActiveDateRangeTo AS DATE)
							)
						)
					)
				)
		) AS TRNQ;

	INSERT INTO @NestedQuestions (QuestionID)
	SELECT DISTINCT aq.QuestionID
	FROM @AQ aq
	INNER JOIN @TRNQ trnq ON aq.QuestionID = trnq.QuestionID

	RETURN
END
GO


/*  
///<SUMMARY>  
///DESCRIPTION                  : FUNCTION - [FN_GetNestedTagsByQuestionID]
///AUTHOR                       : CHHETRI MONASH
///CREATED DATE                 : 01-OCT-2021
///SEE ALSO                     : THIS FUNCTION IS USED FOR SPLITTING/TRIMMING OF INPUT
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_002					01-OCT-2021			CHHETRI MONASH		INITIAL VERSION
ELPC_LH_006					18-AUG-2023			SUSHANTH		GLOBAL TAG
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
SELECT ListTag FROM [FN_GetNestedTagsByQuestionID](1,'strTagName') where ListTag is not null 
SELECT ListTag FROM [FN_GetNestedTagsByQuestionID](1,'strTagID') where ListTag is not null 
SELECT distinct TagID FROM [FN_GetNestedTagsByQuestionID](1,'')
*/
ALTER FUNCTION [FN_GetNestedTagsByQuestionID] (    
 @questionID INT    
 ,@option NVARCHAR(MAX)    
 )    
RETURNS @LnkAssignedTags TABLE (    
 TagID INT    
 ,ListTag NVARCHAR(MAX)    
 )    
AS    
BEGIN    
 DECLARE @tmpTag TABLE (TagName NVARCHAR(max));    
    
 WITH cteLinkedTag    
 AS (    
  SELECT TagID    
   ,LinkedTagID    
   ,0 AS rowCounter    
  FROM [T_LNK_Tag_AssignedQuestionsTags] WITH (NOLOCK)    
  WHERE IsDeleted = 0    
   AND QuestionID = @questionID  
  
      
  UNION ALL    
      
  (    
   SELECT LNK.TagID    
    ,LNK.LinkedTagID   
    ,(rowCounter + 1) AS rowCounter    
   FROM [T_LNK_Tag_AssignedQuestionsTags] LNK WITH (NOLOCK)    
   INNER JOIN cteLinkedTag CTE ON CTE.TagID = LNK.LinkedTagID    
    AND LNK.IsDeleted = 0    
    AND CTE.rowCounter < 5    
   )    
  )    
  
  
 INSERT INTO @LnkAssignedTags (TagID)    
 SELECT DISTINCT TagID    
 FROM cteLinkedTag    
     
 UNION    
     
 (    
  SELECT TagID    
  FROM T_LNK_QN_AssignedTags LNK WITH (NOLOCK)    
  WHERE IsDeleted = 0    
   AND QuestionID = @questionID    
  )    
    
 IF (@option = 'strTagID')    
 BEGIN    
  INSERT INTO @LnkAssignedTags (ListTag)    
  SELECT STRING_AGG(cast(TagID AS NVARCHAR(MAX)), ',') WITHIN    
  FROM (    
   SELECT LNKAT.TagID    
   FROM @LnkAssignedTags LNKAT    
   INNER JOIN T_TRN_Tag T ON T.TagID = LNKAT.TagID    
    AND T.IsDeleted = 0    
   ) AS concatString    
 END    
 ELSE IF (@option = 'strTagName')    
 BEGIN    
  INSERT INTO @tmpTag (TagName) (    
   SELECT CASE     
    WHEN T.TagTypeID = 1    
     THEN COALESCE('#' + T.TagName, '')    
    WHEN T.TagTypeID = 2    
     THEN COALESCE('#' + T.TagName, '')    
    WHEN T.TagTypeID = 3    
     THEN COALESCE('#' + T.TagName, '')    
 WHEN T.TagTypeID = 4   
     THEN COALESCE('#' + T.TagName, '')    
    END AS TagDisplayName FROM T_TRN_Tag T WITH (NOLOCK) INNER JOIN @LnkAssignedTags LNK ON LNK.TagID = T.TagID AND T.IsDeleted = 0    
   )    
    
  INSERT INTO @LnkAssignedTags (ListTag)    
  SELECT STRING_AGG(cast(TagName AS NVARCHAR(MAX)), ',')    
  FROM (    
   SELECT TagName    
   FROM @tmpTag    
   ) AS concatString    
 END    
    
 RETURN    
END
GO 

/*  
///<SUMMARY>  
///DESCRIPTION                  : FUNCTION - [FN_GetNestedTagsByQuestionID]
///AUTHOR                       : CHHETRI MONASH
///CREATED DATE                 : 01-OCT-2021
///SEE ALSO                     : THIS FUNCTION IS USED FOR SPLITTING/TRIMMING OF INPUT
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_002					01-OCT-2021			CHHETRI MONASH		INITIAL VERSION

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
Declare @ID INT =3

SELECT StringName FROM [FN_GetTemplateInfoByQuestionID](@ID,'ValueStreamTemplate', 'StringName', ',') where StringName is not null 
SELECT StringID FROM [FN_GetTemplateInfoByQuestionID](@ID,'ValueStreamTemplate', 'StringID', ',') where StringID is not null 
SELECT ListTemplateName FROM [FN_GetTemplateInfoByQuestionID](@ID,'ValueStreamTemplate', 'ListTemplateName', NULL) where ListTemplateName is not null 
SELECT ListTemplateID FROM [FN_GetTemplateInfoByQuestionID](@ID,'ValueStreamTemplate', 'ListTemplateID', NULL) where ListTemplateID is not null 


SELECT StringName FROM [FN_GetTemplateInfoByQuestionID](@ID,'AssessorTemplate', 'StringName', ',') where StringName is not null 
SELECT StringID FROM [FN_GetTemplateInfoByQuestionID](@ID,'AssessorTemplate', 'StringID', ',') where StringID is not null 
SELECT ListTemplateName FROM [FN_GetTemplateInfoByQuestionID](@ID,'AssessorTemplate', 'ListTemplateName', NULL) where ListTemplateName is not null 
SELECT ListTemplateID FROM [FN_GetTemplateInfoByQuestionID](@ID,'AssessorTemplate', 'ListTemplateID', NULL) where ListTemplateID is not null 

*/
CREATE FUNCTION [FN_GetTemplateInfoByQuestionID] (
	@questionID INT
	,@module NVARCHAR(MAX)			-- ValueStreamTemplate, AssessorTemplate
	,@option NVARCHAR(MAX)			-- StringName, StringID, ListTemplateName, ListTemplateID
	,@delimeter NVARCHAR(1)
	)
RETURNS @Result TABLE (
	QuestionID INT
	,StringName NVARCHAR(MAX)
	,StringID NVARCHAR(MAX)
	,ListTemplateName NVARCHAR(MAX)
	,ListTemplateID INT
	)
AS
BEGIN
	IF(@delimeter IS NULL)
	BEGIN
		set @delimeter =';';
	END

	DECLARE @tmpVSTemplateID TABLE (TemplateID INT);

	INSERT INTO @tmpVSTemplateID (TemplateID)
	SELECT VS.ValueStreamTemplateID
				FROM T_LNK_AssignedValueStreams LNK INNER JOIN T_TRN_ValueStream VS ON VS.ValueStreamID = LNK.ValueStreamID
				WHERE QuestionID = @questionID
					AND LNK.IsDeleted = 0


	
	DECLARE @tmpASTemplateID TABLE (TemplateID INT);

	INSERT INTO @tmpASTemplateID (TemplateID)
	SELECT ASR.AssessorTemplateID
				FROM T_LNK_AssignedAssessors LNK INNER JOIN T_TRN_Assessor ASR ON ASR.AssessorID = LNK.AssessorID
				WHERE QuestionID = @questionID
					AND LNK.IsDeleted = 0

	IF (@option = 'StringName' AND @module = 'ValueStreamTemplate')
	BEGIN
		INSERT INTO @Result (
			QuestionID
			,StringName
			,StringID
			,ListTemplateName
			,ListTemplateID
			)
		SELECT @questionID
			,STRING_AGG(ValueStreamTemplateName, @delimeter) AS ValueStreamTemplateName
			,NULL
			,NULL
			,NULL
		FROM T_TRN_ValueStreamTemplate WITH (NOLOCK)
		WHERE ValueStreamTemplateID IN (select TemplateID from @tmpVSTemplateID)
	END
	ELSE IF (@option = 'StringID' AND @module = 'ValueStreamTemplate')
	BEGIN
		INSERT INTO @Result (
			QuestionID
			,StringName
			,StringID
			,ListTemplateName
			,ListTemplateID
			)
		SELECT @questionID
			,NULL
			,STRING_AGG(ValueStreamTemplateID, @delimeter) AS ValueStreamTemplateID
			,NULL
			,NULL
		FROM T_TRN_ValueStreamTemplate WITH (NOLOCK)
		WHERE ValueStreamTemplateID IN (select TemplateID from @tmpVSTemplateID)
	END
	ELSE IF (@option = 'ListTemplateName' AND @module = 'ValueStreamTemplate')
	BEGIN
		INSERT INTO @Result (
			QuestionID
			,StringName
			,StringID
			,ListTemplateName
			,ListTemplateID
			)
		SELECT @questionID
			,NULL
			,NULL
			,ValueStreamTemplateName
			,NULL
		FROM T_TRN_ValueStreamTemplate WITH (NOLOCK)
		WHERE ValueStreamTemplateID IN (select TemplateID from @tmpVSTemplateID)
	END
	ELSE IF (@option = 'ListTemplateID' AND @module = 'ValueStreamTemplate')
	BEGIN
		INSERT INTO @Result (
			QuestionID
			,StringName
			,StringID
			,ListTemplateName
			,ListTemplateID
			)
		SELECT @questionID
			,NULL
			,NULL
			,NULL
			,ValueStreamTemplateID
		FROM T_TRN_ValueStreamTemplate WITH (NOLOCK)
		WHERE ValueStreamTemplateID IN (select TemplateID from @tmpVSTemplateID)
	END

	ELSE IF (@option = 'StringName' AND @module = 'AssessorTemplate')
	BEGIN
		INSERT INTO @Result (
			QuestionID
			,StringName
			,StringID
			,ListTemplateName
			,ListTemplateID
			)
		SELECT @questionID
			,STRING_AGG(AssessorTemplateName, @delimeter) AS AssessorTemplateName
			,NULL
			,NULL
			,NULL
		FROM T_TRN_AssessorTemplate WITH (NOLOCK)
		WHERE AssessorTemplateID IN (select TemplateID from @tmpASTemplateID)
	END
	ELSE IF (@option = 'StringID' AND @module = 'AssessorTemplate')
	BEGIN
		INSERT INTO @Result (
			QuestionID
			,StringName
			,StringID
			,ListTemplateName
			,ListTemplateID
			)
		SELECT @questionID
			,NULL
			,STRING_AGG(AssessorTemplateID, @delimeter) AS AssessorTemplateID
			,NULL
			,NULL
		FROM T_TRN_AssessorTemplate WITH (NOLOCK)
		WHERE AssessorTemplateID IN (select TemplateID from @tmpASTemplateID)
	END
	ELSE IF (@option = 'ListTemplateName' AND @module = 'AssessorTemplate')
	BEGIN
		INSERT INTO @Result (
			QuestionID
			,StringName
			,StringID
			,ListTemplateName
			,ListTemplateID
			)
		SELECT @questionID
			,NULL
			,NULL
			,AssessorTemplateName
			,NULL
		FROM T_TRN_AssessorTemplate WITH (NOLOCK)
		WHERE AssessorTemplateID IN (select TemplateID from @tmpASTemplateID)
	END
	ELSE IF (@option = 'ListTemplateID' AND @module = 'AssessorTemplate')
	BEGIN
		INSERT INTO @Result (
			QuestionID
			,StringName
			,StringID
			,ListTemplateName
			,ListTemplateID
			)
		SELECT @questionID
			,NULL
			,NULL
			,NULL
			,AssessorTemplateID
		FROM T_TRN_AssessorTemplate WITH (NOLOCK)
		WHERE AssessorTemplateID IN (select TemplateID from @tmpASTemplateID)
	END

	RETURN
END;
GO


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [vwDeviationDescription]
AS
/**************************************************************************
*
*   Author - PowerBI Team
*   Created Date - 05/02/2020
*   
*   Logic for Deviation Description
*   Implemented to accomodate PowerBI Visualisation 
*
*   Modified on - (DD/MM/YYYY)
*   Modified by - 
*   Modification - 
*
***************************************************************************/
SELECT 1 [DeviationTypeID]
	,'No' [Description]

UNION

SELECT 2
	,'Yes, Corrective Measures are not taken'

UNION

SELECT 3
	,'Yes, Corrective Measures are taken'

UNION

SELECT 4
	,'Yes, Corrective Measures are not taken'
	
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [vwShiftDays]
AS
/**************************************************************************
*
*   Author - PowerBI Team
*   Created Date - 05/02/2020
*   
*   Logic for ShiftDays used by a line
*   Implemented to accomodate PowerBI Visualisation 
*
*   Modified on - (DD/MM/YYYY)
*   Modified by - 
*   Modification - 
*
***************************************************************************/
SELECT ShiftID
		,CASE 
			WHEN IsMonday = 1
				THEN 'Mon, '
			ELSE ''
			END AS Mon
		,CASE 
			WHEN IsTuesDay = 1
				THEN 'Tue, '
			ELSE ''
			END AS Tue
		,CASE 
			WHEN IsWednesday = 1
				THEN 'Wed, '
			ELSE ''
			END AS Wed
		,CASE 
			WHEN IsThursday = 1
				THEN 'Thu, '
			ELSE ''
			END AS Thur
		,CASE 
			WHEN IsFriday = 1
				THEN 'Fri, '
			ELSE ''
			END AS Fri
		,CASE 
			WHEN IsSaturday = 1
				THEN 'Sat, '
			ELSE ''
			END AS Sat
		,CASE 
			WHEN IsSunday = 1
				THEN 'Sun,'
			ELSE ''
			END AS Sun
		,CASE 
			WHEN IsMonday = 1
				AND IsTuesDay = 1
				AND IsWednesday = 1
				AND IsThursday = 1
				AND IsFriday = 1
				AND IsSaturday = 1
				AND IsSunday = 1
				THEN 1
			ELSE 0
			END AS Alldays
	FROM T_LNK_ValueStream_Shift
GO


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [vwTagQuestionMapping]
AS

/**************************************************************************
*
*   Author - eLPC Dev Team
*   Created Date - 05/10/2021
*   
*   Logic for Getting Nested Questions & Tag By QuestionID
*   Implemented to accomodate PowerBI Visualisation 
*
*   Modified on - (DD/MM/YYYY)
*   Modified by - 
*   Modification - 
*
***************************************************************************/

SELECT Q.QuestionID, TagID FROM T_TRN_Question AS Q WITH (NOLOCK)
CROSS APPLY [FN_GetNestedTagsByQuestionID](Q.QuestionID,'') AS FN WHERE Q.IsDeleted = 0

GO
