/*          
///<SUMMARY>          
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchTagModeTagsCalendar]          
///AUTHOR                       : JANARTHANAN KRISHNASAMY        
///CREATED DATE                 : 7-july-2022        
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING TAG MODE TAGS based on UserProfile VSAS Combination        
///MODIFICATION HISTORY   :          
************************************************************************************************************         
///REF      DATE    MODIFIED BY     CHANGE DESCRIPTION          
************************************************************************************************************         
ELPC_LH_001     25-NOV-2020   JANARTHANAN KRISHNASAMY  INITIAL VERSION        
ELPC_LH_002     25-MAR-2021   KARTHIKEYAN KANDASAMY  PLANTID ADDED        
ELPC_LH_003     14-July-2022   Venkatesh and ASHOK KUMAR R B   Fetch Based on VSAS Combination        
ELPC_LH_006     18-AUG-2023   Sushanth  and ASHOK KUMAR R B   Global Tag Change
************************************************************************************************************         
///</SUMMARY>        
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)        
EXEC [USP_FetchTagModeTags] 1,'FSM1COB'        
*/        
CREATE PROCEDURE [USP_FetchTagModeTagsCalendar] (@PlantID INT, @CurrentUserNTID NVARCHAR(20))        
AS        
BEGIN        
        
        
create table #MyTags(TagID Int)        
insert into #MyTags EXEC [USP_Fetch_VSAS_TagsMode_CustomMode] 4,@PlantID,@CurrentUserNTID        
        
 SELECT (        
   SELECT TOP 1 UserName        
   FROM T_MST_User WITH (NOLOCK)        
   WHERE NTID = TT.ModifiedBy_NTID        
    AND PlantID = @PlantID        
   ) AS ModifiedBy        
  ,(        
   SELECT TOP 1 UserName        
   FROM T_MST_User WITH (NOLOCK)        
   WHERE NTID = TT.CreatedBy_NTID        
    AND PlantID = @PlantID        
   ) AS CreatedBy        
  ,CASE         
   WHEN TT.TagTypeID = 1        
    THEN COALESCE('#' + TT.TagName, '')        
   WHEN TT.TagTypeID = 2        
    THEN COALESCE('#' + TT.TagName, '')        
   WHEN TT.TagTypeID = 3        
    THEN COALESCE('#' + TT.TagName, '')        
    WHEN TT.TagTypeID = 4       
    THEN COALESCE('#' + TT.TagName, '')        
   END AS TagDisplayName        
  ,TT.TagID        
  ,TT.PlantID        
  ,TT.TagDisplayID        
  ,TT.TagName        
  ,TT.IsSingleQuestionSuppressed        
  ,TT.SuppressedDateRangeFrom        
  ,TT.SuppressedDateRangeTo        
  ,TT.IsTargetFrequencyDefined        
  ,TT.TargetFrequencyTypeID        
  ,TT.TargetFrequencyValue        
  ,TT.Tag_PriorityID        
  ,TT.TagTypeID        
  ,TT.IsLocked        
  ,TT.AnonymizeUserDataSettingID        
  ,TT.IsBranchLogicToBeFollowed        
  ,TT.IsMandatoryAssessorsDefined        
  ,TT.IsDeleted        
  ,TT.CreatedAt        
  ,TT.ModifiedAt        
  ,TT.CreatedBy_NTID        
  ,TT.ModifiedBy_NTID   
  ,TT.IsSearchableTag
  ,TT.IsSkipQuestionDefined
  ,TT.IsQuestionOverviewDefined
  ,TT.IsProgressPercentageDefined
  ,TT.IsResultOverviewDefined
  ,TT.IsResumeTagDefined
  ,TT.IsReportingEmailDefined
 -- ,TT.Assigned_ValueStreamTemplateID        
 -- ,TT.Assigned_ValueStreamCategoryID        
 -- ,TT.Assigned_AssessorTemplateID        
 FROM T_TRN_Tag TT WITH (NOLOCK)        
 INNER JOIN #MyTags MY ON TT.TagID =MY.TagID        
 WHERE TT.PlantID = @PlantID        
  AND TT.TagID IS NOT NULL        
  AND (        
   TT.IsDeleted = 0        
   OR TT.IsDeleted IS NULL        
   )   
  AND TT.IsSearchableTag = 1  
 ORDER BY TagTypeID;        
END 
GO