/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchAssessorProxiesByTemplateID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING ASSESSOR PROXIES BY TEMPLATE ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					12-MAR-2021			KARTHIKEYAN KANDASAMY		MODIFIED VERSION
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S
EXEC [USP_FetchAssessorProxiesByTemplateID] @PlantID=1, @AssessorTemplateID=1
*/
CREATE PROCEDURE [USP_FetchAssessorProxiesByTemplateID] (
	@PlantID INT
	,@AssessorTemplateID INT
	)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT (
			SELECT TOP 1 UR.NTID
			) AS NTID
		,(
			SELECT TOP 1 UR.UserName
			) AS UserName
		,AP.ID
		,AP.AssessorTemplateID
		,AP.Proxy
		,AP.IsDeleted
		,AP.CreatedAt
		,AP.CreatedBy_NTID
		,AP.ModifiedAt
		,AP.ModifiedBy_NTID
		,UR.UserID
		,UR.PlantID
		,UR.Role_RoleID
		,UR.EmployeeID
		,UR.EmailAddress
		,UR.FirstName
		,UR.LastName
	FROM T_LNK_Assessor_Proxy AP WITH (NOLOCK)
	INNER JOIN T_MST_User UR WITH (NOLOCK) ON AP.Proxy = UR.NTID
		AND UR.PlantID = @PlantID
	INNER JOIN T_TRN_AssessorTemplate asrtmp WITH (NOLOCK) ON asrtmp.AssessorTemplateID = AP.AssessorTemplateID
	WHERE (
			asrtmp.PlantID = @PlantID
			AND AP.AssessorTemplateID = @AssessorTemplateID
			AND AP.IsDeleted = 0
			);
END
GO


