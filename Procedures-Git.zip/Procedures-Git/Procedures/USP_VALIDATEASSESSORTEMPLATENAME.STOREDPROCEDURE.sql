/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_ValidateAssessorTemplateName]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE TO VALIDATE ASSESSOR TEMPLATE NAME 
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					12-MAR-2021			KARTHIKEYAN KANDASAMY		MODIFIED VERSION
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
EXEC [USP_ValidateAssessorTemplateName] @PlantID=1, @AssessorTemplateName='QMM'
*/
CREATE PROCEDURE [USP_ValidateAssessorTemplateName] (
	@PlantID INT
	,@AssessorTemplateName NVARCHAR(50)
	)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT AssessorTemplateID
		,PlantID
		,AssessorTemplateDisplayID
		,AssessorTemplateName
		,IsTargetFrequencyDefined
		,IsLocked
		,IsDeleted
		,CreatedAt
		,CreatedBy_NTID
		,ModifiedAt
		,ModifiedBy_NTID
	FROM T_TRN_AssessorTemplate WITH (NOLOCK)
	WHERE (
			PlantID = @PlantID
			AND AssessorTemplateName = RTRIM(LTRIM(@AssessorTemplateName))
			);
END
GO


