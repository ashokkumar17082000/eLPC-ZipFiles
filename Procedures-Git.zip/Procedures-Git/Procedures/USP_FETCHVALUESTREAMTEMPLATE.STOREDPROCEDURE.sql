/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchValuestreamTemplate]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING VALUESTREAM TEMPLATE
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					18-MAR-2021			Rajasekar S					PlantId, DisplayId added
ELPC_LH_002					25-MAY-2022			SHUBHAM BARANGE		        Added Is Accessible Column for Merge
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_FetchValuestreamTemplate]
*/
CREATE PROCEDURE [USP_FetchValuestreamTemplate] @PlantID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	SET NOCOUNT ON;

	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = 0
		,@Mode = 'VALUESTREAMTEMPLATE'
		,@CurrentUserNTID = @CurrentUserNTID

	SELECT VST.ValueStreamTemplateID
		,VST.PlantID
		,VST.ValueStreamTemplateDisplayID
		,VST.ValueStreamTemplateName
		,VST.IsLocked
		,VST.Delimiter
		,VST.IsOperatedInShifts
		,VST.VisualizationViewModeID
		,VST.CreatedAt
		,VST.CreatedBy_NTID
		,VST.ModifiedAt
		,VST.ModifiedBy_NTID
		,(
			SELECT TOP 1 UserName
			FROM T_MST_User WITH (NOLOCK)
			WHERE NTID = VST.ModifiedBy_NTID
				AND PlantID = @PlantID
			) AS ModifiedBy
		,(
			SELECT TOP 1 UserName
			FROM T_MST_User WITH (NOLOCK)
			WHERE NTID = VST.CreatedBy_NTID
				AND PlantID = @PlantID
			) AS CreatedBy
		,CASE 
			WHEN VST.IsLocked = 1
				THEN IIF((
							SELECT COUNT(*)
							FROM T_LNK_ValueStream_Proxy
							WHERE ValueStreamTemplateID = VST.ValueStreamTemplateID
								AND (
									Proxy = @CurrentUserNTID
									OR CreatedBy_NTID = VST.CreatedBy_NTID
									OR ModifiedBy_NTID = @CurrentUserNTID
									)
								AND IsDeleted=0
							) > 0, 1, 0)
			ELSE 1
			END AS IsAccessible
	FROM T_TRN_ValueStreamTemplate VST WITH (NOLOCK)
	WHERE ValueStreamTemplateName IS NOT NULL
		AND (
			VST.PlantID = @PlantID
			AND VST.IsDeleted = 0
			)
	ORDER BY VST.ModifiedAt DESC
END
GO


