/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_DeleteValueStreamTemplate]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR DELETING VALUESTREAM TEMPLATE
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					18-MAR-2021			RAJASEKAR S					Trigger login , plantid included
ELPC_LH_002					25-MAR-2021			RAJASEKAR S					CurrentUserNTID related changes
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_DeleteValueStreamTemplate] 1,'OSP4KOR','2020-11-15 14:18:21.720'
*/
CREATE PROCEDURE [USP_DeleteValueStreamTemplate] @PlantID INT
	,@ValueStreamTemplateID INT
	,@ModifiedAt DATETIME
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = @ValueStreamTemplateID
		,@Mode = 'VALUESTREAMTEMPLATE'
		,@CurrentUserNTID = @CurrentUserNTID

	BEGIN TRY
		BEGIN TRANSACTION TRNDELETETVS

		SET @ModifiedAt = (
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				)

		UPDATE [T_TRN_ValueStreamTemplate]
		SET IsDeleted = 1
			,ModifiedBy_NTID = @CurrentUserNTID
			,ModifiedAt = @ModifiedAt
		WHERE PlantID = @PlantID
			AND ValueStreamTemplateID = @ValueStreamTemplateID

		COMMIT TRANSACTION TRNDELETETVS
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNDELETETVS

		EXEC USP_LogError @PlantID
			,@CurrentUserNTID
	END CATCH
END
GO


