/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_GetDeviationDataPool]
///AUTHOR                       : VENKATESH GOVINDARAJ
///CREATED DATE                 : 21-JAN-2021
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING DATA POOL
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					21-JAN-2021			VENKATESH GOVINDARAJ		INITIAL VERSION
ELPC_LH_002					25-MAR-2021			SIKHESH S					ADDITIONAL PARAMATERS INCLUDED, OUTPUT PARAMETERS REVISED, STANDARD RULES APPLIED
ELPC_LH_002					31-MAY-2022			VENKATESH GOVINDARAJ		Update ChoiceScore to ObtainedScore
ELPC_LH_005                 15-MAR-2023         GOPIKA P G                  INCLUDED ADDITIONAL PARAMETERS FOR INFORMATION TO  AND TAG
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_GetDeviationDataPool_old] 80,'FSM1COB'
*/
CREATE PROCEDURE [USP_GetDeviationDataPool_old] (
	@PlantID INT
	,@CurrentUserNTID NVARCHAR(20) = NULL
	,@FromDate DATETIME = NULL
	,@ToDate DATETIME = NULL
	)
AS
BEGIN
	SET NOCOUNT ON;

	IF (
			@ToDate IS NOT NULL
			AND @ToDate != '1900-01-01 00:00:00.000'
			)
	BEGIN
		SET @ToDate = DATEADD(DAY, 1, @ToDate)
	END

	SELECT TD.DeviationID
		,TD.DeviationDisplayID
		,TD.PlantID
		,TD.ModifiedAt AS 'timeStamp'
		,TU.UserName
		,TD.ValueStreamID
		,CONCAT (
			VST.ValueStreamTemplateName
			,VST.Delimiter
			,TV.ValueStreamName
			) AS ValueStreamName
		,TD.QuestionID
		,TQ.QuestionDisplayID
		,TQ.QuestionText
		,DP.Answer
		,DP.ChoiceID
		,(
			SELECT ChoiceScore
			FROM T_TRN_Choice
			WHERE ChoiceID = DP.ChoiceID
			) AS ObtainedScore
		,TD.DeviationDescription
		,TD.ResponsibleEmployee
		,(
			SELECT DISTINCT abc = STUFF((
						SELECT ',' + Convert(VARCHAR, DeviationAttachmentsID)
						FROM T_TRN_DeviationAttachments WITH (NOLOCK)
						WHERE DeviationID = TD.DeviationID
							AND (
								IsDeleted IS NULL
								OR IsDeleted = 0
								)
						FOR XML PATH('')
							,TYPE
						).value('.', 'NVARCHAR(MAX)'), 1, 1, '')
			) AS TagIDList --DeviationAttachmentID
		,(
			SELECT DISTINCT abc = STUFF((
						SELECT ',' + Convert(VARCHAR, ImageTitle)
						FROM T_TRN_DeviationAttachments WITH (NOLOCK)
						WHERE DeviationID = TD.DeviationID
							AND (
								IsDeleted IS NULL
								OR IsDeleted = 0
								)
						FOR XML PATH('')
							,TYPE
						).value('.', 'NVARCHAR(MAX)'), 1, 1, '')
			) AS AssessorNameList --UploadedImageTitle with time stamp
		,(
			SELECT DISTINCT abc = STUFF((
						SELECT ',' + Convert(VARCHAR, DisplayFileName)
						FROM T_TRN_DeviationAttachments WITH (NOLOCK)
						WHERE DeviationID = TD.DeviationID
							AND (
								IsDeleted IS NULL
								OR IsDeleted = 0
								)
						FOR XML PATH('')
							,TYPE
						).value('.', 'NVARCHAR(MAX)'), 1, 1, '')
			) AS TagNameList --DisplayFileName
		,(
			SELECT DISTINCT abc = STUFF((
						SELECT ',' + convert(VARCHAR, UserName)
						FROM T_LNK_Deviation_AdditionalEmployee WITH (NOLOCK)
						WHERE DeviationID = TD.DeviationID
							AND (
								IsDeleted IS NULL
								OR IsDeleted = 0
								)
						FOR XML PATH('')
							,TYPE
						).value('.', 'NVARCHAR(MAX)'), 1, 1, '')
			) AS EmpList
		,(
			SELECT DISTINCT abc = STUFF((
						SELECT ',' + convert(VARCHAR, TagName)
						FROM T_LNK_Deviation_AssignedTags WITH (NOLOCK)
						WHERE DeviationID = TD.DeviationID
							AND (
								IsDeleted IS NULL
								OR IsDeleted = 0
								)
						FOR XML PATH('')
							,TYPE
						).value('.', 'NVARCHAR(MAX)'), 1, 1, '')
			) AS MultiTagList
		,(
			SELECT DISTINCT abc = STUFF((
						SELECT ',' + convert(VARCHAR, TagID)
						FROM T_LNK_Deviation_AssignedTags WITH (NOLOCK)
						WHERE DeviationID = TD.DeviationID
							AND (
								IsDeleted IS NULL
								OR IsDeleted = 0
								)
						FOR XML PATH('')
							,TYPE
						).value('.', 'NVARCHAR(MAX)'), 1, 1, '')
			) AS MultiTagID
		,TD.CreatedBy_NTID
		,TD.SuperOPLURL AS OPLURL
	FROM T_TRN_Deviation TD WITH (NOLOCK)
	INNER JOIN T_TRN_ValueStream TV WITH (NOLOCK) ON TV.ValueStreamID = TD.ValueStreamID
	LEFT JOIN T_TRN_Question TQ WITH (NOLOCK) ON TQ.QuestionID = TD.QuestionID
		AND TQ.PlantID = @PlantID
	LEFT JOIN T_TRN_DataPool DP WITH (NOLOCK) ON DP.DeviationID = TD.DeviationID
	INNER JOIN T_MSt_User TU WITH (NOLOCK) ON TD.CreatedBy_NTID = TU.NTID
		AND TU.PlantID = @PlantID
	INNER JOIN T_TRN_ValueStreamTemplate VST WITH (NOLOCK) ON VST.ValueStreamTemplateID = TV.ValueStreamTemplateID
		AND VST.PlantID = @PlantID
	WHERE TD.PlantID = @PlantID
		AND TD.CreatedAt >= IIF(@FromDate IS NULL
			OR @FromDate = '1900-01-01 00:00:00.000', TD.CreatedAt, @FromDate)
		AND TD.CreatedAt <= IIF(@ToDate IS NULL
			OR @ToDate = '1900-01-01 00:00:00.000', TD.CreatedAt, @ToDate)
	ORDER BY TD.CreatedAT DESC;
END
GO	