/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_UpdateDataPool]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE TO UPDATE DATA POOL DETAILS 
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					25-MAR-2021			SIKHESH S					ADDITIONAL PARAMATERS INCLUDED AND RELEATED CHANGES, STANDARD RULES APPLIED
ELPC_LH_002					27-MAR-2021			RAJASEKAR S					NEW TRIGGER LOGIC ADDED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
EXEC [USP_UpdateDataPool]
*/
CREATE PROCEDURE [USP_UpdateDataPool] @ModeTypeID INT
	,@ValueStreamID INT
	,@AssessorID INT
	,@QuestionID INT
	,@Answer NVARCHAR(max)
	,@AnswerType_AnswerTypeID INT
	,@TagId INT
	,@IsDeviation BIT
	,@ObtainedSCore DECIMAL(10, 2)
	,@DeviationDescription NVARCHAR(max)
	,@ResponsibleEmployee NVARCHAR(50)
	,@HintImages XML NULL
	,@ChoiceID INT
	,@DataPoolID INT
	,@DeviationID INT
	,@PlantID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	--Inputs filed variable for triggers
	DECLARE @Input_Ids_Trigger VARCHAR(MAX);
	DECLARE @TableName_Trigger VARCHAR(100);
	DECLARE @ActionType VARCHAR(10);

	-- SET NOCOUNT ON ADDED TO PREVENT EXTRA RESULT SETS FROM INTERFERING WITH SELECT STATEMENTS.
	SET NOCOUNT ON;

	IF (
			@DeviationID <> NULL
			OR @DeviationID <> 0
			)
	BEGIN
		UPDATE [T_TRN_Deviation]
		SET DeviationDescription = @DeviationDescription
			,ValueStreamID = @ValueStreamID
			,ResponsibleEmployee = @ResponsibleEmployee
			,ModifiedBy_NTID = @CurrentUserNTID
			-- ,ModifiedAt = (
				-- SELECT FormattedDateTime
				-- FROM fnGetDateTime(@PlantID)
				-- )
		WHERE DeviationID = @DeviationID
			AND PlantID = @PlantID;
	END

	SELECT @QuestionID AS QuestionID
		,HintImage.value('(ImagePath/text())[1]', 'NVARCHAR(50)') AS ImagePath
		,HintImage.value('(ImageTitle/text())[1]', 'NVARCHAR(100)') AS ImageTitle
		,HintImage.value('(ByteData/text())[1]', 'varbinary(max)') AS FileContent
		,HintImage.value('(DeviationAttachmentsID/text())[1]', 'int') AS DeviationAttachmentsID
		,HintImage.value('(DisplayFileName/text())[1]', 'NVARCHAR(100)') AS DisplayFileName
		,@CurrentUserNTID AS ModifiedBy_NTID
		,@DeviationID AS DeviationID
	INTO #HintImage1
	FROM @HintImages.nodes('/ArrayOfHintImage/HintImage') AS TEMPTABLE(HintImage)

	UPDATE T_TRN_DeviationAttachments
	SET IsDeleted = 1
		,ModifiedBy_NTID = @CurrentUserNTID
	WHERE DeviationAttachmentsID NOT IN (
			SELECT DeviationAttachmentsID
			FROM #HintImage1
			WHERE DeviationAttachmentsID != 0
				OR DeviationAttachmentsID IS NOT NULL
			)
		AND DeviationID = @DeviationID --REMOVES THE DELETED IMAGE FILES

	INSERT INTO [T_TRN_DeviationAttachments] (
		ImagePath
		,ImageTitle
		,FileContent
		,QuestionID
		,ModifiedBy_NTID
		,DeviationID
		,DisplayFileName
		)
	SELECT ImagePath
		,ImageTitle
		,FileContent
		,QuestionID
		,ModifiedBy_NTID
		,DeviationID
		,DisplayFileName
	FROM #HintImage1
	WHERE DeviationAttachmentsID IS NULL
		OR DeviationAttachmentsID = 0

	--UPDATING DATAPOOL TABLE
	UPDATE [T_TRN_DataPool]
	SET TIMESTAMP = (
			SELECT FormattedDateTime
			FROM fnGetDateTime(@PlantID)
			)
		,ValueStreamID = @ValueStreamID
		,AssessorID = @AssessorID
		,Answer = @Answer
		-- ,ModifiedAt = (
			-- SELECT FormattedDateTime
			-- FROM fnGetDateTime(@PlantID)
			-- )
		,ChoiceID = @ChoiceID
		,IsDeviation = @IsDeviation
		,ObtainedSCore = @ObtainedSCore
		,ModifiedBy_NTID = @CurrentUserNTID
	WHERE DataPoolID = @DataPoolID
		AND PlantID = @PlantID;

	SELECT @TableName_Trigger = 'DATAPOOL'
		,@ActionType = 'U'
		,@Input_Ids_Trigger = @DataPoolID;

	EXEC [USP_DATAPOOL_HISTORY] @PlantID = @PlantID
		,@CurrentUserNTID = @CurrentUserNTID
		,@TableName = @TableName_Trigger
		,@ActionType = @ActionType
		,@INPUT_IDS = @Input_Ids_Trigger;
END
GO


