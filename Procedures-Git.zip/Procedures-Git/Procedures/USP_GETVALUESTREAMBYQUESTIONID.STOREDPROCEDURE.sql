/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_GetValueStreamByQuestionID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING VALUESTREAMS BY QUESTION ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					27-MAR-2021			VENKATESH GOVINDARAJ		PLANTID & CODE CLEANUP

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_GetValueStreamByQuestionID] 1, 1
*/
CREATE PROCEDURE [USP_GetValueStreamByQuestionID] @QuestionID INT
	,@PlantID INT
AS
BEGIN
	SET NOCOUNT ON;

	SELECT DISTINCT TQ.QuestionID
		,ValueStreamTemplateName
		,Delimiter
		,TV.ValueStreamID
		,TV.Responsible_UserID
		,TV.ValueStreamTemplateID
		,TV.ValueStreamCategoryID
		,TV.ValueStreamData
		,TV.RowID
		,TV.NodeID
		,TV.ResponsibleEmployee
		,TV.ValueStreamName
		,TV.ParentId
		,TV.CreatedBy_NTID
		,TV.ModifiedBy_NTID
		,TV.IsDeleted
	FROM [T_TRN_ValueStream] TV WITH (NOLOCK)
	INNER JOIN [T_LNK_AssignedValueStreams] TA WITH (NOLOCK) ON TV.ValueStreamID = TA.ValueStreamID
	INNER JOIN [T_TRN_Question] TQ WITH (NOLOCK) ON TQ.QuestionID = TA.QuestionID
	INNER JOIN [T_TRN_ValueStreamTemplate] TVT WITH (NOLOCK) ON TVT.ValueStreamTemplateID = TV.ValueStreamTemplateID
		AND TVT.PlantID = @PlantID
	INNER JOIN [T_TRN_ValueStreamCategory] TVC WITH (NOLOCK) ON TVC.ValueStreamCategoryID = TV.ValueStreamCategoryID
	WHERE TQ.QuestionID = @QuestionID
		AND (TV.IsDeleted = 0)
		AND (TV.NodeID IS NOT NULL)
		AND TV.Responsible_UserID IS NOT NULL
		AND (TA.IsDeleted = 0)
		AND TQ.PlantID = @PlantID
	ORDER BY TVT.ValueStreamTemplateName
		,TV.ValueStreamName
END
GO


