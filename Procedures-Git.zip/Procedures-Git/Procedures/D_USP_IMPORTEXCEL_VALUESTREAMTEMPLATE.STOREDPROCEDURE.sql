SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [USP_ImportExcel_ValueStreamTemplate] @ImportExcel_ValueStreamTemplate XML NULL
	,@ImportExcelCat_ValueStreamTemplate XML NULL
	--@UserName varchar(50),
	--@EmailId varchar(50),
	--@Gender varchar(50), 
	--@Address varchar(50),
	--@MobileNo varchar(50),
	--@PinCode varchar(50)
AS
BEGIN
	BEGIN TRY
		DECLARE @min INT = 0
			,@max INT = 0
			,@UserId INT
			,@UserName NVARCHAR(50)
			,@EmailId NVARCHAR(50)
			,@Gender NVARCHAR(50)
			,@Address NVARCHAR(50)
			,@MobileNo NVARCHAR(50)
			,@PinCode NVARCHAR(50)
			,
			--****************newly added for vCAT***
			@ValueStreamCategoryID INT
			,@ValueStreamCategoryName NVARCHAR
			,@ValueStreamTemplateID INT
			,@IsDataRequired BIT
			,@TypeOfInput_InputTypeID INT
			,@IsDataRequiredToFitSpecLength BIT
			,@MinimumNoOfCharacters INT
			,@MaximumNoOfCharacters INT
			,@TempID INT

		--*********************************************
		SELECT Category.value('(UserId)[1]', 'VARCHAR(100)') AS UserId
			,Category.value('(UserName)[1]', 'VARCHAR(100)') AS UserName
			,Category.value('(EmailId/text())[1]', 'VARCHAR(100)') AS EmailId
			,Category.value('(Gender/text())[1]', 'VARCHAR(10)') AS Gender
			,Category.value('(Address/text())[1]', 'VARCHAR(100)') AS Address
			,Category.value('(MobileNo/text())[1]', 'VARCHAR(100)') AS MobileNo
			,Category.value('(PinCode/text())[1]', 'VARCHAR(100)') AS PinCode
			,Category.value('(TempID/text())[1]', 'VARCHAR(100)') AS TempID
		INTO #T1
		--FROM @ImportExcel_ValueStreamTemplate.nodes('/ArrayOfImportExcel/ImportExcel')AS TEMPTABLE(Category)
		FROM @ImportExcel_ValueStreamTemplate.nodes('/ImportExcel') AS TEMPTABLE(Category)

		INSERT INTO UserDetails (
			UserName
			,EmailId
			,Gender
			,Address
			,MobileNo
			,PinCode
			,TempID
			)
		SELECT UserName
			,EmailId
			,Gender
			,Address
			,MobileNo
			,PinCode
			,TempID
		FROM #T1
		WHERE UserId = NULL
			OR UserId = 0

		SET @UserId = SCOPE_IDENTITY()

		--set @TempID = (select TempID from #T1 where UserId=@UserId)
		--**************************************Inserting into VCAT**********
		SELECT Category.value('(ValueStreamCategoryID)[1]', 'VARCHAR(100)') AS ValueStreamCategoryID
			,Category.value('(ValueStreamCategoryName)[1]', 'VARCHAR(100)') AS ValueStreamCategoryName
			,@UserId AS ValueStreamTemplateID
			,Category.value('(IsDataRequired/text())[1]', 'VARCHAR(10)') AS IsDataRequired
			,Category.value('(TypeOfInput_InputTypeID/text())[1]', 'VARCHAR(100)') AS TypeOfInput_InputTypeID
			,Category.value('(IsDataRequiredToFitSpecLength/text())[1]', 'VARCHAR(100)') AS IsDataRequiredToFitSpecLength
			,Category.value('(MinimumNoOfCharacters/text())[1]', 'VARCHAR(100)') AS MinimumNoOfCharacters
			,Category.value('(MaximumNoOfCharacters/text())[1]', 'VARCHAR(100)') AS MaximumNoOfCharacters
			,Category.value('(TempID/text())[1]', 'VARCHAR(100)') AS TempID
		INTO #T2
		FROM @ImportExcelCat_ValueStreamTemplate.nodes('/ArrayOfImportExcelCat/ImportExcelCat') AS TEMPTABLE(Category)

		--FROM @ImportExcelCat_ValueStreamTemplate.nodes('/ImportExcelCat')AS TEMPTABLE(Category)
		SELECT *
		FROM #T2

		--set @value=(select (ValueStreamCategoryName) from #T2)
		INSERT INTO UserDetails1 (
			ValueStreamCategoryName
			,ValueStreamTemplateID
			,IsDataRequired
			,TypeOfInput_InputTypeID
			,IsDataRequiredToFitSpecLength
			,MinimumNoOfCharacters
			,MaximumNoOfCharacters
			,TempID
			)
		SELECT ValueStreamCategoryName
			,ValueStreamTemplateID
			,IsDataRequired
			,TypeOfInput_InputTypeID
			,IsDataRequiredToFitSpecLength
			,MinimumNoOfCharacters
			,MaximumNoOfCharacters
			,TempID
		FROM #T2
		WHERE ValueStreamCategoryID = NULL
			OR ValueStreamCategoryID = 0

		--*************************************************************************
		--*********************
		SET @min = (
				SELECT MIN(UserId)
				FROM #T1
				);--Get minimum row number from temp table
		SET @max = (
				SELECT Max(UserId)
				FROM #T1
				);--Get maximum row number from temp table

		WHILE (@min <= @max)
		BEGIN
			SELECT @UserName = UserName
				,@EmailId = EmailId
				,@Gender = Gender
				,@Address = Address
				,@MobileNo = MobileNo
				,@PinCode = PinCode
			FROM #T1
			WHERE UserId = @min

			UPDATE UserDetails
			SET UserName = @UserName
				,EmailId = @EmailId
				,Gender = @Gender
				,Address = @Address
				,MobileNo = @MobileNo
				,PinCode = @PinCode
			WHERE UserId = @min

			SET @min = @min + 1 --Increment of current row number
		END
				--************************
	END TRY

	BEGIN CATCH
		SELECT ERROR_NUMBER() AS ErrorNumber
			,ERROR_SEVERITY() AS ErrorSeverity
			,ERROR_STATE() AS ErrorState
			,ERROR_PROCEDURE() AS ErrorProcedure
			,ERROR_LINE() AS ErrorLine
			,ERROR_MESSAGE() AS ErrorMessage;
	END CATCH
END
GO


