/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_GetAssessorsByQuestionID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING ASSESSORS BY QUESTION ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					27-MAR-2021			VENKATESH GOVINDARAJ		PLANTID & CODE CLEANUP

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_GetAssessorsByQuestionID] 1,1
*/
CREATE PROCEDURE [USP_GetAssessorsByQuestionID] @QuestionID INT
	,@PlantID INT
AS
BEGIN
	SELECT AssessorTemplateName
		,TV.AssessorID
		,TV.AssessorName
		,TV.TargetFrequencyValue
		,TV.AssessorTemplateID
		,TV.TargetFrequencyTypeID
		,TV.Category
		,TV.TargetFrequencyLowLimit
		,TV.IsDeleted
		,TV.ModifiedAt
		,TV.CreatedAt
	FROM [T_TRN_Assessor] TV WITH(NOLOCK)
	INNER JOIN [T_LNK_AssignedAssessors] TA WITH(NOLOCK) ON TV.AssessorID = TA.AssessorID
	INNER JOIN [T_TRN_Question] TQ WITH(NOLOCK) ON TQ.QuestionID = TA.QuestionID
	INNER JOIN [T_TRN_AssessorTemplate] TVT WITH(NOLOCK) ON TVT.AssessorTemplateID = TV.AssessorTemplateID
		AND TVT.PlantID = @PlantID
	WHERE TQ.QuestionID = @QuestionID
		AND (TV.IsDeleted = 0)
		AND (TA.IsDeleted = 0)
		AND TQ.PlantID = @PlantID
END
GO


