/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_UpdateResponsibleEmployee]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE TO UPDATE RESPONSIBLE EMPLOYEE
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY				CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY INITIAL VERSION
ELPC_LH_002					25-MAR-2021			RAJASEKAR S					CurrentUserNTID related changes

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
EXEC [USP_UpdateResponsibleEmployee] 
*/
CREATE PROCEDURE [USP_UpdateResponsibleEmployee] @PlantID INT
	,@ValueStreamTemplateID INT = 0
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = @ValueStreamTemplateID
		,@Mode = 'VALUESTREAMTEMPLATE'
		,@CurrentUserNTID = @CurrentUserNTID

	BEGIN TRY
		BEGIN TRANSACTION TRNUPATERESPONSEUSER

		SELECT DISTINCT (VS.RowID)
		INTO #T1
		FROM T_TRN_ValueStream VS WITH (NOLOCK)
		INNER JOIN T_TRN_ValueStreamTemplate VST WITH (NOLOCK) ON VST.ValueStreamTemplateID = VS.ValueStreamTemplateID
		WHERE VST.PlantID = @PlantID
			AND VS.ValueStreamTemplateID = @ValueStreamTemplateID

		DECLARE CUR_Accessor CURSOR FORWARD_ONLY
		FOR
		SELECT RowID
		FROM #T1

		DECLARE @ValueStreamID INT = 0;
		DECLARE @Responsible_UserID NVARCHAR(20);
		DECLARE @ResponsibleEmployee NVARCHAR(200);
		DECLARE @RowID INT = 0;
		DECLARE @MinNodeID INT = 0;
		DECLARE @MaxNodeID INT = 0;
		DECLARE @MinNodeID1 NVARCHAR(max);
		DECLARE @MaxNodeID1 NVARCHAR(max);

		OPEN CUR_Accessor;

		FETCH NEXT
		FROM CUR_Accessor
		INTO @RowID

		PRINT @RowID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @MaxNodeID1 = (
					SELECT Max(VS.NodeID)
					FROM T_TRN_ValueStream VS WITH (NOLOCK)
					INNER JOIN T_TRN_ValueStreamTemplate VST WITH (NOLOCK) ON VST.ValueStreamTemplateID = VS.ValueStreamTemplateID
					WHERE VST.PlantID = @PlantID
						AND VS.ValueStreamTemplateID = @ValueStreamTemplateID
						AND VS.RowID = @RowID
						AND (
							VS.ValueStreamData IS NOT NULL
							AND VS.ValueStreamData != ''
							)
					)
			SET @MinNodeID1 = (
					SELECT Min(VS.NodeID)
					FROM T_TRN_ValueStream VS WITH (NOLOCK)
					INNER JOIN T_TRN_ValueStreamTemplate VST WITH (NOLOCK) ON VST.ValueStreamTemplateID = VS.ValueStreamTemplateID
					WHERE VST.PlantID = @PlantID
						AND VS.ValueStreamTemplateID = @ValueStreamTemplateID
						AND VS.RowID = @RowID
					)
			SET @MinNodeID = CAST(@MinNodeID1 AS INT)
			SET @MaxNodeID = CAST(@MaxNodeID1 AS INT)
			SET @Responsible_UserID = (
					SELECT TOP 1 VS.Responsible_UserID
					FROM T_TRN_ValueStream VS WITH (NOLOCK)
					INNER JOIN T_TRN_ValueStreamTemplate VST WITH (NOLOCK) ON VST.ValueStreamTemplateID = VS.ValueStreamTemplateID
					WHERE VST.PlantID = @PlantID
						AND VS.ValueStreamTemplateID = @ValueStreamTemplateID
						AND VS.RowID = @RowID
						AND VS.NodeID = @MinNodeID
						AND VS.Responsible_UserID IS NOT NULL
					)
			SET @ResponsibleEmployee = (
					SELECT TOP 1 VS.ResponsibleEmployee
					FROM T_TRN_ValueStream VS WITH (NOLOCK)
					INNER JOIN T_TRN_ValueStreamTemplate VST WITH (NOLOCK) ON VST.ValueStreamTemplateID = VS.ValueStreamTemplateID
					WHERE VST.PlantID = @PlantID
						AND VS.ValueStreamTemplateID = @ValueStreamTemplateID
						AND VS.RowID = @RowID
						AND VS.NodeID = @MinNodeID
						AND VS.Responsible_UserID IS NOT NULL
					)

			PRINT @Responsible_UserID;
			PRINT @MinNodeID
			PRINT @MaxNodeID
			PRINT @RowID

			UPDATE T_TRN_ValueStream
			SET Responsible_UserID = @Responsible_UserID
				,ResponsibleEmployee = @ResponsibleEmployee
			WHERE ValueStreamTemplateID = @ValueStreamTemplateID
				AND NodeID = @MaxNodeID
				AND RowID = @RowID
				AND (
					ValueStreamData IS NOT NULL
					AND ValueStreamData != ''
					)

			FETCH NEXT
			FROM CUR_Accessor
			INTO @RowID
		END

		CLOSE CUR_Accessor;

		DEALLOCATE CUR_Accessor;

		COMMIT TRANSACTION TRNUPATERESPONSEUSER
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNUPATERESPONSEUSER

		EXEC USP_LogError @PlantID
			,@CurrentUserNTID
	END CATCH
END
GO


