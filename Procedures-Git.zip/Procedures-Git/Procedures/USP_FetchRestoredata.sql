/****** Object:  StoredProcedure [USP_FetchRestoredata]    Script Date: 08.03.2024 08:59:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--exec [dbo].[USP_FetchRestoredata] 2
CREATE PROCEDURE [USP_FetchRestoredata] (@PlantID INT)
AS

BEGIN
declare @HistoryID int;
	SET NOCOUNT ON;
	
--select @HistoryID=ISNULL(MAX(HistoryID),0) from T_TRN_LaunchpadSetting

	
   SELECT  distinct[HistoryID]
		  ,[ModifiedAt]
		   ,[CreatedAt]
		   ,[PlantID]
		   ,(SELECT TOP 1 UserName
			FROM T_MST_User WITH (NOLOCK)
			WHERE NTID =CreatedBy
				AND PlantID = @PlantID
			 )AS CreatedBy
			
			FROM T_TRN_LaunchpadSetting WITH (NOLOCK)
	
	WHERE (
			PlantID = @PlantID
			AND HistoryId>0
		  -- AND IsDeleted = 0
			);
/* SELECT   [TextName] as reportTextName
           ,[ValidURL] as reportTextURL
           ,[IsDeleted]
		   ,[ModifiedAt]
		   ,[CreatedAt]
		   ,[PlantID]
		   ,[HistoryID]
		   ,(SELECT TOP 1 UserName
			FROM T_MST_User WITH (NOLOCK)
			WHERE NTID =CreatedBy
				AND PlantID = @PlantID
			 )AS CreatedBy
		   FROM T_TRN_LaunchpadSettings WITH (NOLOCK)
	
	WHERE (
			PlantID = @PlantID
		   AND IsDeleted = 0);*/
		
END




/****** Object:  StoredProcedure [dbo].[USP_RestoreLaunchPadSettings]    Script Date: 2/21/2024 12:00:11 PM ******/
SET ANSI_NULLS ON

----------------------------------
USE [DB_eLPC_P_SL2_SQL]
GO
