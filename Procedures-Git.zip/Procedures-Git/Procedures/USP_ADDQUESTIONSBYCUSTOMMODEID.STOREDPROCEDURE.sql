/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_AddQuestionsByCustomModeID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR ADDING QUESTIONS BY CUSTOM MODE ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					28-MAR-2021			SIKHESH S					ADDITIONAL PARAMATERS INCLUDED AND RELEATED CHANGES, STANDARD RULES APPLIED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_AddQuestionsByCustomModeID] 1,1, 1,'sse4cob'
*/
CREATE PROCEDURE [USP_AddQuestionsByCustomModeID] (
	@CustomModeID INT
	,@TmpTagID INT
	,@PlantID INT
	,@CurrentUserNTID NVARCHAR(20)
	)
AS
BEGIN
	DECLARE @CustomQuestionTagsID INT;

	BEGIN TRY
		BEGIN TRANSACTION ADDQUESTIONSBYCUSTOMMODEID;

		SELECT DISTINCT QuestionID
		INTO #questionIDs
		FROM [FN_GetNestedQuestionsByTagID](@TmpTagID, @PlantID)

		--FETCH SUPPRESS QUESTION NOT BASED ON TagID
		INSERT INTO [T_LNK_Custom_QuestionsTags] (
			CustomModeID
			,TagID
			)
		VALUES (
			@CustomModeID
			,@TmpTagID
			)

		SET @CustomQuestionTagsID = SCOPE_IDENTITY();

		INSERT INTO [T_LNK_Custom_Questions] (
			CustomModeID
			,QuestionID
			,AnswerTypeID
			,IsCustomMode
			,CustomQuestionTagsID
			)
		SELECT @CustomModeID
			,QuestionID
			,AnswerType_AnswerTypeID
			,0
			,@CustomQuestionTagsID
		FROM [T_TRN_Question] WITH (NOLOCK)
		WHERE QuestionID IN (
				SELECT q.QuestionID
				FROM #questionIDs q
				)
			AND PlantID = @PlantID
			AND IsDeleted = 0

		COMMIT TRANSACTION ADDQUESTIONSBYCUSTOMMODEID;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION ADDQUESTIONSBYCUSTOMMODEID;

		EXEC USP_LogError @PlantID
			,@CurrentUserNTID;
	END CATCH
END
GO

