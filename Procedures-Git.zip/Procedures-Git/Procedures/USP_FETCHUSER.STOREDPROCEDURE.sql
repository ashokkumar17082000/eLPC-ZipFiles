/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchUser]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING USER DETAILS
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					26-MAR-2021			SIKHESH S					ADDITIONAL INPUT PARAMATERS INCLUDED, OUTPUT PARAMETERS REVISED, STANDARD RULES APPLIED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_FetchUser] 1
*/
CREATE PROCEDURE [USP_FetchUser] (
	@PlantID INT
	,@CurrentUserNTID NVARCHAR(20) = NULL
	)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT TOP 1 USR.UserID
		,CONCAT (
			ISNULL(USR.FirstName, USR.UserName)
			,+ ' ' + ISNULL(USR.LastName, '')
			) AS UserName
		,USR.EmployeeID
		,USR.EmailAddress
		,USR.NTID
		,USR.FirstName
		,USR.LastName
		,USR.ModifiedAt
		,USR.Role_RoleID
		,ROL.RoleName AS RoleName
	FROM T_MST_User USR WITH(NOLOCK)
	LEFT JOIN T_MST_Role ROL ON USR.Role_RoleID = ROL.RoleID
		AND USR.PlantID = @PlantID
	WHERE USR.PlantID = @PlantID
END
GO


