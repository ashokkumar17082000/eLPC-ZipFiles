/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_GetFullTagDetailsByID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING FULL TAG DETAILS BY ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					22-MAR-2021			KARTHIKEYAN KANDASAMY		PLANTID ADDED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_GetFullTagDetailsByID] 1, 1
*/
CREATE PROCEDURE [USP_GetFullTagDetailsByID] (
	@PlantID INT
	,@TagID INT
	)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT TagID
		,PlantID
		,TagDisplayID
		,TagName
		,IsSingleQuestionSuppressed
		,SuppressedDateRangeFrom
		,SuppressedDateRangeTo
		,IsTargetFrequencyDefined
		,TargetFrequencyTypeID
		,TargetFrequencyValue
		,Tag_PriorityID
		,TagTypeID
		,IsLocked
		,AnonymizeUserDataSettingID
		,IsBranchLogicToBeFollowed
		,IsMandatoryAssessorsDefined
		,IsDeleted
		,CreatedAt
		,ModifiedAt
		,CreatedBy_NTID
		,ModifiedBy_NTID
	-- ,Assigned_ValueStreamTemplateID
	-- ,Assigned_ValueStreamCategoryID
	-- ,Assigned_AssessorTemplateID
	FROM T_TRN_Tag WITH (NOLOCK)
	WHERE (
			TagID = @TagID
			AND PlantID = @PlantID
			AND IsDeleted = 0
			);
END
GO

