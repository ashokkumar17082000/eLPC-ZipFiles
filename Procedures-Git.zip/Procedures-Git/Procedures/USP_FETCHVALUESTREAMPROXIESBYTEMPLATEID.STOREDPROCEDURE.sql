/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchValueStreamProxiesByTemplateID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING VALUESTREAM PROXIES BY TEMPLATE ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					18-MAR-2021			Rajasekar S					PlantId, DisplayId, 'set NOCOUNT ON' added. * expanded
ELPC_LH_002					26-MAR-2021			Rajasekar S					@CurrentUserNTID,PlantIDValidation added

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_FetchValueStreamProxiesByTemplateID] 1
*/
CREATE PROCEDURE [USP_FetchValueStreamProxiesByTemplateID] @ValueStreamTemplateID INT
	,@PlantID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = @ValueStreamTemplateID
		,@Mode = 'VALUESTREAMTEMPLATE'
		,@CurrentUserNTID = @CurrentUserNTID

	SET NOCOUNT ON;

	SELECT VP.ID
		,VP.ValueStreamTemplateID
		,VP.Proxy
		,VP.CreatedBy_NTID
		,VP.ModifiedBy_NTID
		,(
			SELECT TOP 1 UR.NTID
			) AS NTID
		,(
			SELECT TOP 1 UR.UserName
			) AS UserName
	FROM T_LNK_ValueStream_Proxy VP WITH (NOLOCK)
	INNER JOIN T_MST_User UR WITH (NOLOCK) ON VP.Proxy = UR.NTID
	INNER JOIN T_TRN_ValueStreamTemplate VST WITH (NOLOCK) ON VP.ValueStreamTemplateID = VST.ValueStreamTemplateID
	WHERE VP.ValueStreamTemplateID = @ValueStreamTemplateID
		AND (
			VST.ValueStreamTemplateID = @ValueStreamTemplateID
			AND UR.PlantID = @PlantID
			AND VP.IsDeleted = 0
			)
END
GO


