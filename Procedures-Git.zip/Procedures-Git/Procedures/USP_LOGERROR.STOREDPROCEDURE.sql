/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_LogError]
///AUTHOR                       : RAJASEKAR S
///CREATED DATE                 : 16-MAR-2021
///SEE ALSO                     : THIS PROCEDURE TO ADD Error log 
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_002					16-MAR-2021			RAJASEKAR S					INITIAL VERSION
************************************************************************************************************ 
///</SUMMARY>

EXEC [USP_LogError] 1,'rsb4cob'
*/
CREATE PROCEDURE [USP_LogError] @PlantId INT
	,@UserNtId VARCHAR(10)
AS
BEGIN
	INSERT INTO T_TRN_LogError (
		ErrorNumber
		,ErrorSeverity
		,ErrorState
		,ErrorProcedure
		,ErrorLine
		,ErrorMessage
		,PlantID
		,CreatedOn
		,CreatedBy
		)
	SELECT ERROR_NUMBER() AS ErrorNumber
		,ERROR_SEVERITY() AS ErrorSeverity
		,ERROR_STATE() AS ErrorState
		,ERROR_PROCEDURE() AS ErrorProcedure
		,ERROR_LINE() AS ErrorLine
		,ERROR_MESSAGE() AS ErrorMessage
		,@PlantId
		,(
			SELECT FormattedDateTime
			FROM fnGetDateTime(@PlantId)
			)
		,@UserNtId;
END
GO


