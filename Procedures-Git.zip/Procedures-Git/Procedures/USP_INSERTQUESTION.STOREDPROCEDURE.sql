


/*        
///<SUMMARY>        
///DESCRIPTION                  : STORE PROCEDURE - [USP_InsertQuestion]      
///AUTHOR                       : JANARTHANAN KRISHNASAMY      
///CREATED DATE                 : 25-NOV-2020      
///SEE ALSO                     : THIS PROCEDURE TO INSERT QUESTION      
///MODIFICATION HISTORY   :        
************************************************************************************************************       
///REF      DATE    MODIFIED BY     CHANGE DESCRIPTION        
************************************************************************************************************       
ELPC_LH_001     25-NOV-2020   JANARTHANAN KRISHNASAMY  INITIAL VERSION      
ELPC_LH_002     12-MAR-2021   RAJASEKAR S     TRIGGER REMOVAL AND NEW TRIGGER LOGIC      
ELPC_LH_002     24-MAR-2021   VENKATESH GOVINDARAJ  PLANTID & CODE CLEANUP      
ELPC_LH_002     8-APR-2021   RAJASEKAR S     Update Question history input logic correction      
ELPC_LH_003     26-JUL-2021   MONASH CHHETRI    ChoiceCategory is added for T_TRN_CHOICE      
ELPC_LH_005     18-AUG-2023   BARDHAN SUSHANT  GLOBAL TAG, Multiple Questions import through excel  
ELPC_LH_005     18-AUG-2023   gopika            CreatedBy Issue fixed  
************************************************************************************************************       
///</SUMMARY>      
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)      
EXEC [USP_InsertQuestion_bak] 'What is your name?.,Where is your birthplace?.,What is the product name?.,what is your address?',      
'starts with ''S''.,golden city.,ayurvedic.,old town',1,1,false,false,true,false,null,null,true,'9/9/2022 12:00:00 AM','9/9/2022 11:59:59 PM',      
false,null,null,4,false,'9/9/2022 4:54:34 PM','JSD2KOR','9/9/2022 4:54:34 PM','JSD2KOR',null,null,false,      
null,      
null,      
null,      
null,      
null,      
null,      
null,      
null,      
null,      
null,      
0,      
null,      
null,      
null,      
1,'JSD2KOR'


*/      
CREATE PROCEDURE [USP_InsertQuestion] @QuestionText NVARCHAR(MAX)      
 ,@QuestionHintText NVARCHAR(max) NULL      
 ,@AnswerType_AnswerTypeID INT NULL      
 ,@ChoiceDisplayTypeID INT NULL      
 ,@IsFilledInChoiceAllowed BIT NULL      
 ,@IsUniqueAnswerRequired BIT NULL      
 ,@IsAnswerRequired BIT NULL      
 ,@IsDefaultAnswerRequired BIT NULL      
 ,@DefaultChoiceID INT NULL      
 ,@DefaultChoice NVARCHAR(500) NULL      
 ,@IsQuestionAlwaysActive BIT NULL      
 ,@ActiveDateRangeFrom DATETIME NULL      
 ,@ActiveDateRangeTo DATETIME NULL      
 ,@IsTargetFrequencyDefined BIT NULL      
 ,@TargetFrequencyTypeID INT NULL      
 ,@TargetFrequencyValue NVARCHAR(50) NULL      
 ,@Question_PriorityID INT NULL      
 ,@IsLocked BIT NULL      
 ,@CreatedAt DATETIME NULL      
 ,@CreatedBy_NTID NVARCHAR(20) NULL      
 ,@ModifiedAt DATETIME NULL      
 ,@ModifiedBy_NTID NVARCHAR(20) NULL      
 -- ,@Assigned_ValueStreamTemplateID INT NULL      
 -- ,@Assigned_ValueStreamCategoryID INT NULL      
 -- ,@Assigned_AssessorTemplateID INT NULL      
 ,@Assigned_AssessorID INT NULL      
 ,@AssignedTargetFrequencies XML NULL      
 ,@IsDeleted BIT NULL      
 ,@Choices XML NULL      
 ,@HintImages XML NULL      
 ,@HintHyperLinks XML NULL      
 ,@SingleLineText XML NULL      
 ,@MultipleLinesText XML NULL      
 ,@AnswerTypeNumber XML NULL      
 ,@AnswerTypeCurrency XML NULL      
 ,@AnswerTypeDateTime XML NULL      
 ,@RatingScale XML NULL      
 ,@SubQuestions XML NULL      
 ,@QuestionID INT NULL      
 ,@ValueStreams XML NULL      
 ,@Assessors XML NULL      
 ,@Tags XML NULL      
 ,@PlantID INT      
 ,@CurrentUserNTID NVARCHAR(20) NULL      
AS      
BEGIN      
 BEGIN TRY      
  BEGIN TRANSACTION TRNINSERTQUESTION      
      
  --Inputs filed variable for triggers      
  DECLARE @QuestionHistoryID INT = 0;      
  DECLARE @Scope_Identity_Table_Trigger TABLE (id INT);--Scope identities for all inserted rows      
  DECLARE @Input_Ids_Trigger VARCHAR(MAX);      
  DECLARE @TableName_Trigger VARCHAR(100);      
  DECLARE @ActionType VARCHAR(10);      
  ----to avoid entries from Lock settings update, it is enabled/disabled       
  --ALTER TABLE [T_TRN_Question] ENABLE TRIGGER [TR_HISTORYFOR_T_TRN_Question]      
  --ALTER TABLE [T_TRN_HintImage] ENABLE TRIGGER [TR_HISTORYFOR_T_TRN_HintImage]      
  --ALTER TABLE [T_TRN_HintHyperLink] ENABLE TRIGGER [TR_HISTORYFOR_T_TRN_HintHyperLink]      
  --ALTER TABLE [T_LNK_AssignedValueStreams] ENABLE TRIGGER [TR_HISTORYFOR_T_LNK_AssignedValueStreams]      
  --ALTER TABLE [T_LNK_AssignedAssessors] ENABLE TRIGGER [TR_HISTORYFOR_T_LNK_AssignedAssessors]      
  --ALTER TABLE [T_LNK_QN_AssignedTags] ENABLE TRIGGER [TR_HISTORYFOR_T_LNK_QN_AssignedTags]      
  --ALTER TABLE [T_TRN_SingleLineText] ENABLE TRIGGER [TR_HISTORYFOR_T_TRN_SingleLineText]      
  --ALTER TABLE [T_TRN_MultipleLinesText] ENABLE TRIGGER [TR_HISTORYFOR_T_TRN_MultipleLinesText]      
  --ALTER TABLE [T_TRN_Choice] ENABLE TRIGGER [TR_HISTORYFOR_T_TRN_Choice]      
  DECLARE @min INT = 0      
   ,@max INT = 0      
   ,@minHl INT = 0      
   ,@maxHl INT = 0      
   ,@ImagePath NVARCHAR(50)      
   ,@FileContent VARBINARY(max)      
   ,@ImageTitle NVARCHAR(50)      
   ,@HyperLinkTitle NVARCHAR(50)      
   ,@HyperLinkURL NVARCHAR(500)      
   ,@MaxCharacters INT = 0      
   ,@IsCalculated BIT      
   ,@DefaultValue NVARCHAR(MAX)      
   ,@MaxLines INT      
   ,@IsPlaintText INT      
   ,@ChoiceName NVARCHAR(500)      
   ,@ChoiceScore DECIMAL(10, 2)      
   ,@IsDeviationEntryRequired BIT      
   ,@MaxValue INT = 0      
   ,@MinValue INT = 0      
   ,@NumberOfDecimalPlaces NVARCHAR(10)      
   ,@IsNumber BIT      
   ,@ShowPercentage BIT      
   ,@IsCurrency BIT      
   ,@CurrencyFormat NVARCHAR(100)      
   ,@IsDateOnly BIT      
   ,@IsStandard BIT      
   ,@Name NVARCHAR(200)      
   ,@DefaultDateType BIT      
   ,@ValueStreamID INT      
   ,@AssessorID INT      
   ,@NumberRange NVARCHAR(10)      
   ,@RangeText1 NVARCHAR(50)      
   ,@RangeText2 NVARCHAR(50)      
   ,@RangeText3 NVARCHAR(50)      
   ,@ShowNA BIT      
   ,@TextNA NVARCHAR(10)      
   ,@TagID INT = 0      
   ,@DisplayFileName NVARCHAR(MAX)      
   ,@DeviationTypeID INT = 0      
   ,@ID INT = 0      
   ,@ChoiceID INT = 0      
   ,@AnswerCategory VARCHAR(50);      
      
 DECLARE @TotalCount INT      
    SET @TotalCount = (Select count(*) from string_split(REPLACE(@QuestionText,'!@#$%','~'),'~'))       
       
    DECLARE @Counter INT      
    SET @Counter = 1      
 DECLARE @QText NVARCHAR(MAX)      
 DECLARE @QHText NVARCHAR(MAX)      
    WHILE (@Counter <= @TotalCount)      
    BEGIN      
  SELECT  @QText = item FROM (SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 0)) RowNumber, t.value as item FROM String_split(REPLACE(@QuestionText,'!@#$%','~'),'~') t) y WHERE RowNumber = @Counter      
  SELECT  @QHText = item FROM (SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 0)) RowNumber, t.value as item FROM String_split(REPLACE(@QuestionHintText,'!@#$%','~'),'~') t) y WHERE RowNumber = @Counter      
    if object_id('tempdb..#HintImage1') is not null     
        begin     
            drop table #HintImage1                             
        end     
 if object_id('tempdb..#HyperLink1') is not null     
        begin     
            drop table #HyperLink1                             
        end     
 if object_id('tempdb..#ValueStream1') is not null     
        begin     
            drop table #ValueStream1                             
        end     
 if object_id('tempdb..#Assessor') is not null     
    begin     
        drop table #Assessor                             
    end     
 if object_id('tempdb..#Tag') is not null     
    begin     
        drop table #Tag                             
    end     
 if object_id('tempdb..#RemovedTagIDs') is not null     
    begin     
        drop table #RemovedTagIDs                             
    end     
 if object_id('tempdb..#SL1') is not null     
    begin     
        drop table #SL1                             
    end     
 if object_id('tempdb..#ML') is not null     
    begin     
        drop table #ML                             
    end     
 if object_id('tempdb..#Choice') is not null     
    begin     
        drop table #Choice                             
    end     
 if object_id('tempdb..#RatingScale') is not null     
    begin     
        drop table #RatingScale                             
    end     
 if object_id('tempdb..#SubQuestion') is not null     
    begin     
        drop table #SubQuestion                             
    end     
 if object_id('tempdb..#ATN') is not null     
    begin     
        drop table #ATN                             
    end     
 if object_id('tempdb..#ATC') is not null     
    begin     
        drop table #ATC                             
    end     
 if object_id('tempdb..#ATD') is not null     
    begin     
        drop table #ATD                             
    end     
       
  --  IF NOT EXISTS (      
  --   SELECT TOP 1 1      
  --   FROM [T_TRN_Question] WITH (NOLOCK)      
  --   WHERE QuestionText = @QText      
  --    AND PlantID = @PlantID      
  --   )      
  --BEGIN      
   IF (      
    (      
     @QuestionID IS NULL      
     OR @QuestionID = 0      
     )      
    AND NOT EXISTS (      
     SELECT TOP 1 1      
     FROM [T_TRN_Question] WITH (NOLOCK)      
     WHERE QuestionID = @QuestionID      
      AND PlantID = @PlantID      
     )           
    )      
  BEGIN      
      
   INSERT INTO [T_TRN_Question] (      
    PlantID      
    ,QuestionDisplayID      
    ,QuestionText      
    ,QuestionHintText      
    ,AnswerType_AnswerTypeID      
    ,ChoiceDisplayTypeID      
    ,IsFilledInChoiceAllowed      
    ,IsUniqueAnswerRequired      
    ,IsAnswerRequired      
    ,DefaultChoiceID      
    ,IsQuestionAlwaysActive      
    ,ActiveDateRangeFrom      
    ,ActiveDateRangeTo      
    ,IsTargetFrequencyDefined      
    ,TargetFrequencyTypeID      
    ,TargetFrequencyValue      
    ,Question_PriorityID      
    ,IsLocked      
    ,CreatedAt      
    ,CreatedBy_NTID      
    ,ModifiedAt      
    ,ModifiedBy_NTID      
    -- ,Assigned_ValueStreamTemplateID      
    -- ,Assigned_ValueStreamCategoryID      
    -- ,Assigned_AssessorTemplateID      
    ,Assigned_AssessorID      
    ,IsDeleted      
    ,DefaultChoice      
    ,IsDefaultAnswerRequired      
    )      
   VALUES (      
    @PlantID      
    ,(      
     SELECT DisplayID      
     FROM [FN_GetNextDisplayID](@PlantID, 'T_TRN_Question')      
     )      
    ,@QText      
    ,@QHText      
    ,@AnswerType_AnswerTypeID      
    ,@ChoiceDisplayTypeID      
    ,@IsFilledInChoiceAllowed      
    ,@IsUniqueAnswerRequired      
    ,@IsAnswerRequired      
    ,@DefaultChoiceID      
    ,@IsQuestionAlwaysActive      
    ,@ActiveDateRangeFrom      
    ,@ActiveDateRangeTo      
    ,@IsTargetFrequencyDefined      
    ,@TargetFrequencyTypeID      
    ,@TargetFrequencyValue      
    ,@Question_PriorityID      
    ,@IsLocked      
    ,@CreatedAt      
    ,@CreatedBy_NTID      
    ,@ModifiedAt      
    ,@ModifiedBy_NTID      
    -- ,@Assigned_ValueStreamTemplateID      
    -- ,@Assigned_ValueStreamCategoryID      
    -- ,@Assigned_AssessorTemplateID      
    ,@Assigned_AssessorID      
    ,@IsDeleted      
    ,@DefaultChoice      
    ,@IsDefaultAnswerRequired      
    )      
      
   SET @QuestionID = SCOPE_IDENTITY()      
         
   SELECT @TableName_Trigger = 'Question'      
    ,@ActionType = 'I'      
      
   EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
    ,@QuestionHistoryID = @QuestionHistoryID OUTPUT      
    ,@ActionType = @ActionType      
    ,@INPUT_IDS = @QuestionID      
    ,@PlantID = @PlantID      
    ,@CurrentUserNTID = @CurrentUserNTID;      
      
   DELETE      
   FROM @Scope_Identity_Table_Trigger      
      
   INSERT INTO T_TRN_HintImage (      
    QuestionID      
    ,ImagePath      
    ,ImageTitle      
    ,FileContent      
    ,DisplayFileName      
    ,CreatedBy_NTID      
    ,ModifiedBy_NTID      
    )      
   OUTPUT inserted.ID      
   INTO @Scope_Identity_Table_Trigger      
   SELECT @QuestionID AS QuestionID      
    ,HintImage.value('(ImagePath/text())[1]', 'NVARCHAR(max)') AS ImagePath      
    ,HintImage.value('(ImageTitle/text())[1]', 'NVARCHAR(max)') AS ImageTitle      
    ,HintImage.value('(ByteData/text())[1]', 'varbinary(max)') AS FileContent      
    ,HintImage.value('(DisplayFileName/text())[1]', 'NVARCHAR(MAX)') AS DisplayFileName      
    ,@CreatedBy_NTID AS CreatedBy_NTID      
    ,@ModifiedBy_NTID AS ModifiedBy_NTID      
   FROM @HintImages.nodes('/ArrayOfHintImage/HintImage') AS TEMPTABLE(HintImage)      
      
   SELECT @TableName_Trigger = 'HintImage'      
    ,@ActionType = 'I'      
    ,@Input_Ids_Trigger = (      
     SELECT CAST(id AS VARCHAR(MAX)) + ', '      
     FROM @Scope_Identity_Table_Trigger      
     FOR XML PATH('')      
     );      
      
   EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
    ,@QuestionHistoryID = @QuestionHistoryID      
    ,@ActionType = @ActionType      
    ,@INPUT_IDS = @Input_Ids_Trigger      
    ,@PlantID = @PlantID      
    ,@CurrentUserNTID = @CurrentUserNTID;      
      
   DELETE      
   FROM @Scope_Identity_Table_Trigger      
      
   INSERT INTO T_TRN_HintHyperLink (      
    QuestionID      
    ,HyperLinkTitle      
    ,HyperLinkURL      
    )      
   OUTPUT inserted.ID      
   INTO @Scope_Identity_Table_Trigger      
   SELECT @QuestionID AS QuestionID      
    ,HyperLink.value('(HyperLinkTitle/text())[1]', 'NVARCHAR(50)') AS HyperLinkTitle      
    ,HyperLink.value('(HyperLinkURL/text())[1]', 'NVARCHAR(500)') AS HyperLinkURL      
   FROM @HintHyperLinks.nodes('/ArrayOfHintHyperLink/HintHyperLink') AS TEMPTABLE(HyperLink)      
      
   SELECT @TableName_Trigger = 'HintHyperLink'      
    ,@ActionType = 'I'      
    ,@Input_Ids_Trigger = (      
     SELECT CAST(id AS VARCHAR(MAX)) + ', '      
     FROM @Scope_Identity_Table_Trigger      
     FOR XML PATH('')      
     );      
      
   EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
    ,@QuestionHistoryID = @QuestionHistoryID      
    ,@ActionType = @ActionType      
    ,@INPUT_IDS = @Input_Ids_Trigger      
    ,@PlantID = @PlantID      
    ,@CurrentUserNTID = @CurrentUserNTID;      
      
   DELETE      
   FROM @Scope_Identity_Table_Trigger      
      
   INSERT INTO T_LNK_AssignedValueStreams (      
    QuestionID      
    ,ValueStreamID      
    )      
   OUTPUT inserted.ID      
   INTO @Scope_Identity_Table_Trigger      
   SELECT @QuestionID AS QuestionID      
    ,ValueStream.value('(ValueStreamID/text())[1]', 'int') AS ValueStreamID      
   FROM @ValueStreams.nodes('/ArrayOfValueStream/ValueStream') AS TEMPTABLE(ValueStream)      
      
   SELECT @TableName_Trigger = 'AssignedValueStreams'      
    ,@ActionType = 'I'      
    ,@Input_Ids_Trigger = (      
     SELECT CAST(id AS VARCHAR(MAX)) + ', '      
     FROM @Scope_Identity_Table_Trigger      
     FOR XML PATH('')      
     );      
      
   EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
    ,@QuestionHistoryID = @QuestionHistoryID      
    ,@ActionType = @ActionType      
    ,@INPUT_IDS = @Input_Ids_Trigger      
    ,@PlantID = @PlantID      
    ,@CurrentUserNTID = @CurrentUserNTID;      
      
   DELETE      
   FROM @Scope_Identity_Table_Trigger      
      
   INSERT INTO T_LNK_AssignedAssessors (      
    QuestionID      
    ,AssessorID      
    ,TargetFrequencyTypeID      
    ,TargetFrequencyValue      
    )      
   OUTPUT inserted.ID      
   INTO @Scope_Identity_Table_Trigger      
   SELECT @QuestionID AS QuestionID      
    ,Assessor.value('(AssessorID/text())[1]', 'int') AS AssessorID      
    ,Assessor.value('(TargetFrequencyTypeID/text())[1]', 'int') AS TargetFrequencyTypeID      
    ,Assessor.value('(TargetFrequencyValue/text())[1]', 'nvarchar(50)') AS TargetFrequencyValue      
   FROM @Assessors.nodes('/ArrayOfAssessor/Assessor') AS TEMPTABLE(Assessor)      
      
   SELECT @TableName_Trigger = 'AssignedAssessors'      
    ,@ActionType = 'I'      
    ,@Input_Ids_Trigger = (      
     SELECT CAST(id AS VARCHAR(MAX)) + ', '      
     FROM @Scope_Identity_Table_Trigger      
     FOR XML PATH('')      
     );      
   
   EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
    ,@QuestionHistoryID = @QuestionHistoryID      
    ,@ActionType = @ActionType      
    ,@INPUT_IDS = @Input_Ids_Trigger      
    ,@PlantID = @PlantID      
    ,@CurrentUserNTID = @CurrentUserNTID;      
      
   DELETE      
   FROM @Scope_Identity_Table_Trigger      
      
   INSERT INTO T_LNK_QN_AssignedTags (      
    QuestionID      
    ,TagID      
    )      
   OUTPUT inserted.ID      
   INTO @Scope_Identity_Table_Trigger      
   SELECT @QuestionID AS QuestionID      
    ,Tag.value('(TagID/text())[1]', 'int') AS TagID      
   FROM @Tags.nodes('/ArrayOfTag/Tag') AS TEMPTABLE(Tag)      
      
   SELECT @TableName_Trigger = 'AssignedTags'      
    ,@ActionType = 'I'      
    ,@Input_Ids_Trigger = (      
     SELECT CAST(id AS VARCHAR(MAX)) + ', '      
     FROM @Scope_Identity_Table_Trigger      
     FOR XML PATH('')      
     );      
      
   EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
    ,@QuestionHistoryID = @QuestionHistoryID      
    ,@ActionType = @ActionType      
    ,@INPUT_IDS = @Input_Ids_Trigger      
    ,@PlantID = @PlantID      
    ,@CurrentUserNTID = @CurrentUserNTID;      
      
   IF (@AnswerType_AnswerTypeID = 1)      
   BEGIN      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO T_TRN_SingleLineText (      
     QuestionID      
     ,MaxCharacters      
     ,IsCalculated      
     ,DefaultValue      
     )      
    OUTPUT inserted.ID      
    INTO @Scope_Identity_Table_Trigger      
    SELECT @QuestionID AS QuestionID      
     ,SL.value('(MaxCharacters/text())[1]', 'int') AS MaxCharacters      
     ,SL.value('(IsCalculated/text())[1]', 'bit') AS IsCalculated      
     ,SL.value('(DefaultValue/text())[1]', 'NVARCHAR(MAX)') AS DefaultValue      
    FROM @SingleLineText.nodes('/SingleLineText') AS TEMPTABLE(SL)      
      
    SELECT @TableName_Trigger = 'SingleLineText'      
     ,@ActionType = 'I'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
     ,@QuestionHistoryID = @QuestionHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger      
     ,@PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID;      
   END      
      
   IF (@AnswerType_AnswerTypeID = 2)      
   BEGIN      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO T_TRN_MultipleLinesText (      
     QuestionID      
     ,MaxLines      
     ,IsPlaintText      
     )      
    OUTPUT inserted.ID      
    INTO @Scope_Identity_Table_Trigger      
    SELECT @QuestionID AS QuestionID      
     ,ML.value('(MaxLines/text())[1]', 'int') AS MaxLines      
     ,ML.value('(IsPlaintText/text())[1]', 'bit') AS IsPlaintText      
    FROM @MultipleLinesText.nodes('/MultipleLinesText') AS TEMPTABLE(ML)      
      
    SELECT @TableName_Trigger = 'MultipleLinesText'      
     ,@ActionType = 'I'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
     ,@QuestionHistoryID = @QuestionHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger      
     ,@PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID;      
   END      
      
   IF (@AnswerType_AnswerTypeID = 3)      
   BEGIN      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO T_TRN_Choice (      
     QuestionID      
     ,ChoiceName      
     ,ChoiceScore      
     ,IsDeviationEntryRequired      
     ,DeviationTypeID      
     ,AnswerCategory      
     )      
    OUTPUT inserted.ChoiceID      
    INTO @Scope_Identity_Table_Trigger      
    SELECT @QuestionID AS QuestionID      
     ,Choice.value('(ChoiceName/text())[1]', 'NVARCHAR(500)') AS ChoiceName      
     ,Choice.value('(ChoiceScore/text())[1]', 'decimal(10,2)') AS ChoiceScore      
     ,Choice.value('(IsDeviationEntryRequired/text())[1]', 'bit') AS IsDeviationEntryRequired      
     ,Choice.value('(DeviationTypeID/text())[1]', 'int') AS DeviationTypeID      
     ,Choice.value('(AnswerCategory/text())[1]', 'NVARCHAR(50)') AS AnswerCategory      
    FROM @Choices.nodes('/ArrayOfChoice/Choice') AS TEMPTABLE(Choice)      
      
    SELECT @TableName_Trigger = 'Choice'      
     ,@ActionType = 'I'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
     ,@QuestionHistoryID = @QuestionHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger      
     ,@PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID;      
      
    --DELETE      
    --FROM @Scope_Identity_Table_Trigger      
    --INSERT INTO @Scope_Identity_Table_Trigger      
    --SELECT QuestionID      
    --FROM [T_TRN_Question]      
    --WHERE QuestionID = @QuestionID      
    -- AND PlantID = @PlantID      
    -- AND IsDefaultAnswerRequired = @IsDefaultAnswerRequired      
    UPDATE [T_TRN_Question]      
    SET DefaultChoiceID = (      
      SELECT TOP 1 ChoiceID      
      FROM T_TRN_Choice WITH (NOLOCK)      
      WHERE ChoiceName = @DefaultChoice      
       AND QuestionID = @QuestionID      
      )      
    WHERE QuestionID = @QuestionID      
     AND PlantID = @PlantID      
     AND IsDefaultAnswerRequired = @IsDefaultAnswerRequired      
      
    SELECT @TableName_Trigger = 'Question'      
     ,@ActionType = 'U'      
     ,@Input_Ids_Trigger = @QuestionID;      
      
    EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
     ,@QuestionHistoryID = @QuestionHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger      
     ,@PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID;      
   END      
      
   IF (@AnswerType_AnswerTypeID = 4)      
   BEGIN      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO T_TRN_RatingScale (      
     QuestionID      
     ,NumberRange      
     ,RangeText1      
     ,RangeText2      
     ,RangeText3      
     ,ShowNA      
     ,TextNA      
     )      
    OUTPUT inserted.ID      
    INTO @Scope_Identity_Table_Trigger      
    SELECT @QuestionID AS QuestionID      
     ,RatingScale.value('(NumberRange/text())[1]', 'NVARCHAR(10)') AS NumberRange      
     ,RatingScale.value('(RangeText1/text())[1]', 'NVARCHAR(50)') AS RangeText1      
     ,RatingScale.value('(RangeText2/text())[1]', 'NVARCHAR(50)') AS RangeText2      
     ,RatingScale.value('(RangeText3/text())[1]', 'NVARCHAR(50)') AS RangeText3      
     ,RatingScale.value('(ShowNA/text())[1]', 'bit') AS ShowNA      
     ,RatingScale.value('(TextNA/text())[1]', 'NVARCHAR(10)') AS TextNA      
    FROM @RatingScale.nodes('/RatingScale') AS TEMPTABLE(RatingScale)      
      
    SELECT @TableName_Trigger = 'RatingScale'      
     ,@ActionType = 'I'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
     ,@QuestionHistoryID = @QuestionHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger      
     ,@PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID;      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO T_TRN_SubQuestion (      
     QuestionID      
     ,Name      
     )      
    OUTPUT inserted.ID      
    INTO @Scope_Identity_Table_Trigger      
    SELECT @QuestionID AS QuestionID      
     ,SubQuestion.value('(Name/text())[1]', 'NVARCHAR(200)') AS Name      
    FROM @SubQuestions.nodes('/ArrayOfSubQuestion/SubQuestion') AS TEMPTABLE(SubQuestion)      
      
    SELECT @TableName_Trigger = 'SubQuestion'      
     ,@ActionType = 'I'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
     ,@QuestionHistoryID = @QuestionHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger      
     ,@PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID;      
   END      
      
   IF (@AnswerType_AnswerTypeID = 5)      
   BEGIN      
    INSERT INTO T_TRN_AnswerTypeNumber (      
     QuestionID      
     ,MaxValue      
     ,MinValue      
     ,NumberOfDecimalPlaces      
     ,IsNumber      
     ,DefaultValue      
     ,ShowPercentage      
     )      
    SELECT @QuestionID AS QuestionID      
     ,ATN.value('(MaxValue/text())[1]', 'int') AS MaxValue      
     ,ATN.value('(MinValue/text())[1]', 'int') AS MinValue      
     ,ATN.value('(NumberOfDecimalPlaces/text())[1]', 'NVARCHAR(10)') AS NumberOfDecimalPlaces      
     ,ATN.value('(IsNumber/text())[1]', 'bit') AS IsNumber      
     ,ATN.value('(DefaultValue/text())[1]', 'NVARCHAR(50)') AS DefaultValue      
     ,ATN.value('(ShowPercentage/text())[1]', 'bit') AS ShowPercentage      
    FROM @AnswerTypeNumber.nodes('/AnswerTypeNumber') AS TEMPTABLE(ATN)      
   END      
      
   IF (@AnswerType_AnswerTypeID = 6)      
   BEGIN      
    INSERT INTO T_TRN_AnswerTypeCurrency (      
     QuestionID      
     ,MaxValue      
     ,MinValue      
     ,NumberOfDecimalPlaces      
     ,IsCurrency      
     ,DefaultValue      
     ,CurrencyFormat      
     )      
    SELECT @QuestionID AS QuestionID      
     ,ATC.value('(MaxValue/text())[1]', 'bit') AS MaxValue      
     ,ATC.value('(MinValue/text())[1]', 'bit') AS MinValue      
     ,ATC.value('(NumberOfDecimalPlaces/text())[1]', 'NVARCHAR(10)') AS NumberOfDecimalPlaces      
     ,ATC.value('(IsCurrency/text())[1]', 'bit') AS IsCurrency      
     ,ATC.value('(DefaultValue/text())[1]', 'NVARCHAR(50)') AS DefaultValue      
     ,ATC.value('(CurrencyFormat/text())[1]', 'bit') AS CurrencyFormat      
    FROM @AnswerTypeCurrency.nodes('/AnswerTypeCurrency') AS TEMPTABLE(ATC)      
   END      
      
   IF (@AnswerType_AnswerTypeID = 7)      
   BEGIN      
    INSERT INTO T_TRN_AnswerTypeDateTime (      
     QuestionID      
     ,IsDateOnly      
     ,IsStandard      
     ,DefaultDateType      
     ,DefaultValue      
     )      
    SELECT @QuestionID AS QuestionID      
     ,ATD.value('(IsDateOnly/text())[1]', 'bit') AS MaxValue      
     ,ATD.value('(IsStandard/text())[1]', 'bit') AS MinValue      
     ,ATD.value('(DefaultDateType/text())[1]', 'NVARCHAR(10)') AS DefaultDateType      
     ,ATD.value('(DefaultValue/text())[1]', 'NVARCHAR(10)') AS DefaultValue      
    FROM @AnswerTypeDateTime.nodes('/AnswerTypeDateTime') AS TEMPTABLE(ATD)      
   END      
  END      
  ELSE IF (      
    @QuestionID IS NOT NULL      
    AND EXISTS (      
     SELECT TOP 1 1      
     FROM [T_TRN_Question] WITH (NOLOCK)      
     WHERE QuestionID = @QuestionID      
      AND PlantID = @PlantID      
     )      
    )      
  BEGIN      
   UPDATE T_TRN_Question      
   SET QuestionText = @QText      
    ,QuestionHintText = @QHText      
    ,AnswerType_AnswerTypeID = @AnswerType_AnswerTypeID      
    ,ChoiceDisplayTypeID = @ChoiceDisplayTypeID      
    ,@IsFilledInChoiceAllowed = @IsFilledInChoiceAllowed      
    ,IsUniqueAnswerRequired = @IsUniqueAnswerRequired      
    ,IsAnswerRequired = @IsAnswerRequired      
    ,DefaultChoiceID = @DefaultChoiceID      
    ,IsQuestionAlwaysActive = @IsQuestionAlwaysActive      
    ,ActiveDateRangeFrom = @ActiveDateRangeFrom      
    ,ActiveDateRangeTo = @ActiveDateRangeTo      
    ,IsTargetFrequencyDefined = @IsTargetFrequencyDefined      
    ,TargetFrequencyTypeID = @TargetFrequencyTypeID      
    ,TargetFrequencyValue = @TargetFrequencyValue      
    ,Question_PriorityID = @Question_PriorityID      
    ,IsLocked = @IsLocked      
    ,CreatedAt = @CreatedAt      
    --,CreatedBy_NTID = @CreatedBy_NTID      
    ,ModifiedAt = @ModifiedAt      
    ,ModifiedBy_NTID = @ModifiedBy_NTID      
    -- ,Assigned_ValueStreamTemplateID = @Assigned_ValueStreamTemplateID      
    -- ,Assigned_ValueStreamCategoryID = @Assigned_ValueStreamCategoryID      
    -- ,Assigned_AssessorTemplateID = @Assigned_AssessorTemplateID      
    ,Assigned_AssessorID = @Assigned_AssessorID      
    ,IsDeleted = @IsDeleted      
    ,DefaultChoice = @DefaultChoice      
    ,IsDefaultAnswerRequired = @IsDefaultAnswerRequired      
   WHERE QuestionID = @QuestionID      
    AND PlantID = @PlantID      
              
   SELECT @TableName_Trigger = 'Question'      
    ,@ActionType = 'U'      
      
   EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
    ,@QuestionHistoryID = @QuestionHistoryID OUTPUT      
    ,@ActionType = @ActionType      
    ,@INPUT_IDS = @QuestionID      
    ,@PlantID = @PlantID      
    ,@CurrentUserNTID = @CurrentUserNTID;      
      
   --for HintImages      
   BEGIN      
    SELECT @QuestionID AS QuestionID      
     ,HintImage.value('(ID/text())[1]', 'int') AS ID      
     ,Identity(INT, 1, 1) AS RowID      
     ,HintImage.value('(ImagePath/text())[1]', 'NVARCHAR(MAX)') AS ImagePath      
     ,HintImage.value('(ImageTitle/text())[1]', 'NVARCHAR(MAX)') AS ImageTitle      
     ,HintImage.value('(ByteData/text())[1]', 'varbinary(max)') AS FileContent      
     ,HintImage.value('(DisplayFileName/text())[1]', 'NVARCHAR(MAX)') AS DisplayFileName      
     ,@CreatedBy_NTID AS CreatedBy_NTID      
     ,@ModifiedBy_NTID AS ModifiedBy_NTID      
    INTO #HintImage1      
    FROM @HintImages.nodes('/ArrayOfHintImage/HintImage') AS TEMPTABLE(HintImage)      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO @Scope_Identity_Table_Trigger      
    SELECT ID      
    FROM T_TRN_HintImage WITH (NOLOCK)      
    WHERE ID NOT IN (      
      SELECT ID      
      FROM #HintImage1      
      WHERE ID != 0      
       OR ID IS NOT NULL      
      )      
     AND QuestionID = @QuestionID      
      
    UPDATE T_TRN_HintImage      
    SET IsDeleted = 1      
    WHERE ID IN (      
      SELECT id      
      FROM @Scope_Identity_Table_Trigger      
      ) --removes the deleted image files      
      
    SELECT @TableName_Trigger = 'HintImage'      
     ,@ActionType = 'U'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
     ,@QuestionHistoryID = @QuestionHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger      
     ,@PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID;      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO T_TRN_HintImage (      
     ImagePath      
     ,ImageTitle      
     ,FileContent      
     ,QuestionID      
     ,DisplayFileName      
     ,CreatedBy_NTID      
     ,ModifiedBy_NTID      
     )      
    OUTPUT inserted.ID      
    INTO @Scope_Identity_Table_Trigger      
    SELECT ImagePath      
     ,ImageTitle      
     ,FileContent      
     ,QuestionID      
     ,DisplayFileName      
     ,CreatedBy_NTID      
     ,ModifiedBy_NTID      
    FROM #HintImage1      
    WHERE ID IS NULL      
     OR ID = 0      
      
    SELECT @TableName_Trigger = 'HintImage'      
     ,@ActionType = 'I'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );    
      
    EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
     ,@QuestionHistoryID = @QuestionHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger      
     ,@PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID;      
      
    SET @min = (      
      SELECT MIN(RowID)      
      FROM #HintImage1      
      );--Get minimum row number from temp table      
    SET @max = (      
      SELECT Max(RowID)      
      FROM #HintImage1      
      );--Get maximum row number from temp table      
      
    WHILE (@min <= @max)      
    BEGIN      
     SELECT @ImagePath = ImagePath      
      ,@ImageTitle = ImageTitle      
      ,@FileContent = FileContent      
      ,@DisplayFileName = DisplayFileName      
      ,@ID = ID      
     FROM #HintImage1      
     WHERE RowID = @min      
      
     UPDATE T_TRN_HintImage      
     SET ImagePath = @ImagePath      
      ,ImageTitle = @ImageTitle      
      ,FileContent = @FileContent      
      ,DisplayFileName = @DisplayFileName      
     WHERE ID = @ID      
      
     SELECT @TableName_Trigger = 'HintImage'      
      ,@ActionType = 'U'      
      ,@Input_Ids_Trigger = @ID;      
      
     EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
      ,@QuestionHistoryID = @QuestionHistoryID      
      ,@ActionType = @ActionType      
      ,@INPUT_IDS = @Input_Ids_Trigger      
      ,@PlantID = @PlantID      
      ,@CurrentUserNTID = @CurrentUserNTID;      
      
     SET @min = @min + 1 --Increment of current row number      
    END      
   END      
      
   --for Hint Hyperlinks      
   BEGIN      
    SELECT @QuestionID AS QuestionID      
     ,HyperLink.value('(ID/text())[1]', 'int') AS ID      
     ,Identity(INT, 1, 1) AS RowID      
     ,HyperLink.value('(HyperLinkTitle/text())[1]', 'NVARCHAR(50)') AS HyperLinkTitle      
     ,HyperLink.value('(HyperLinkURL/text())[1]', 'NVARCHAR(500)') AS HyperLinkURL      
    INTO #HyperLink1      
    FROM @HintHyperLinks.nodes('/ArrayOfHintHyperLink/HintHyperLink') AS TEMPTABLE(HyperLink)      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO @Scope_Identity_Table_Trigger      
    SELECT ID      
    FROM T_TRN_HintHyperLink WITH (NOLOCK)      
    WHERE ID NOT IN (      
      SELECT ID      
      FROM #HyperLink1      
      WHERE ID != 0      
       OR ID IS NOT NULL      
      )      
     AND QuestionID = @QuestionID      
      
    UPDATE T_TRN_HintHyperLink      
    SET IsDeleted = 1      
    WHERE ID IN (      
      SELECT ID      
      FROM @Scope_Identity_Table_Trigger      
      ) -- removes the deleted hyperlinks      
      
    SELECT @TableName_Trigger = 'HintHyperLink'      
     ,@ActionType = 'U'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
     ,@QuestionHistoryID = @QuestionHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger      
     ,@PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID;      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO T_TRN_HintHyperLink (      
     HyperLinkTitle      
     ,HyperLinkURL      
     ,QuestionID      
     )      
    OUTPUT inserted.ID      
    INTO @Scope_Identity_Table_Trigger      
    SELECT HyperLinkTitle      
     ,HyperLinkURL      
     ,QuestionID      
    FROM #HyperLink1      
    WHERE (      
      ID IS NULL      
      OR ID = 0      
      )      
      
    SELECT @TableName_Trigger = 'HintHyperLink'      
     ,@ActionType = 'I'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
     ,@QuestionHistoryID = @QuestionHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger      
     ,@PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID;      
      
    SET @minHl = (      
      SELECT MIN(RowID)      
      FROM #HyperLink1      
      );--Get minimum row number from temp table      
    SET @maxHl = (      
      SELECT Max(RowID)      
      FROM #HyperLink1      
      );--Get maximum row number from temp table      
      
    WHILE (@minHl <= @maxHl)      
    BEGIN      
     SELECT @HyperLinkTitle = HyperLinkTitle      
      ,@HyperLinkURL = HyperLinkURL      
      ,@QuestionID = QuestionID      
      ,@ID = ID      
     FROM #HyperLink1      
     WHERE RowID = @minHl      
      
     UPDATE T_TRN_HintHyperLink      
     SET HyperLinkTitle = @HyperLinkTitle      
      ,HyperLinkURL = @HyperLinkURL      
      ,QuestionID = @QuestionID      
     WHERE ID = @ID      
      
     SELECT @TableName_Trigger = 'HintHyperLink'      
      ,@ActionType = 'U'      
      ,@Input_Ids_Trigger = @ID;      
      
     EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
      ,@QuestionHistoryID = @QuestionHistoryID      
      ,@ActionType = @ActionType      
      ,@INPUT_IDS = @Input_Ids_Trigger      
      ,@PlantID = @PlantID      
      ,@CurrentUserNTID = @CurrentUserNTID;      
      
     SET @minHl = @minHl + 1 --Increment of current row number      
    END      
   END      
      
   --for Assigned ValueStreams      
   BEGIN      
    SELECT @QuestionID AS QuestionID      
     ,ValueStream.value('(ID/text())[1]', 'int') AS ID      
     ,Identity(INT, 1, 1) AS RowID      
     ,ValueStream.value('(ValueStreamID/text())[1]', 'int') AS ValueStreamID      
    INTO #ValueStream1      
    FROM @ValueStreams.nodes('/ArrayOfValueStream/ValueStream') AS TEMPTABLE(ValueStream)      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO @Scope_Identity_Table_Trigger      
    SELECT ID      
    FROM T_LNK_AssignedValueStreams WITH (NOLOCK)      
    WHERE ID NOT IN (      
      SELECT ID      
      FROM #ValueStream1      
      WHERE ID != 0      
       OR ID IS NOT NULL      
      )      
     AND QuestionID = @QuestionID      
      
    UPDATE T_LNK_AssignedValueStreams      
    SET IsDeleted = 1      
    WHERE ID IN (      
      SELECT id      
      FROM @Scope_Identity_Table_Trigger      
      ) -- removes the deleted valuestreams      
      
    SELECT @TableName_Trigger = 'AssignedValueStreams'      
     ,@ActionType = 'U'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
     ,@QuestionHistoryID = @QuestionHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger      
     ,@PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID;      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO T_LNK_AssignedValueStreams (      
     QuestionID      
     ,ValueStreamID      
     )      
    OUTPUT inserted.ID      
    INTO @Scope_Identity_Table_Trigger      
    SELECT QuestionID      
     ,ValueStreamID      
    FROM #ValueStream1      
    WHERE (      
      ID IS NULL      
      OR ID = 0      
      )      
      
    SELECT @TableName_Trigger = 'AssignedValueStreams'      
     ,@ActionType = 'I'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
     ,@QuestionHistoryID = @QuestionHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger      
     ,@PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID;      
      
    SET @min = (      
      SELECT MIN(RowID)      
      FROM #ValueStream1      
      );--Get minimum row number from temp table      
    SET @max = (      
      SELECT Max(RowID)      
      FROM #ValueStream1      
      );--Get maximum row number from temp table      
      
    WHILE (@min <= @max)      
    BEGIN      
     SELECT @QuestionID = QuestionID      
      ,@ValueStreamID = ValueStreamID      
      ,@ID = ID      
     FROM #ValueStream1      
     WHERE RowID = @min      
      
     UPDATE T_LNK_AssignedValueStreams      
     SET QuestionID = @QuestionID      
      ,ValueStreamID = @ValueStreamID      
     WHERE ID = @ID      
      
     SELECT @TableName_Trigger = 'AssignedValueStreams'      
      ,@ActionType = 'U'      
      ,@Input_Ids_Trigger = @ID;      
      
     EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
      ,@QuestionHistoryID = @QuestionHistoryID      
      ,@ActionType = @ActionType      
      ,@INPUT_IDS = @Input_Ids_Trigger      
      ,@PlantID = @PlantID      
      ,@CurrentUserNTID = @CurrentUserNTID;      
      
     SET @min = @min + 1 --Increment of current row number      
    END      
   END      
      
   --for Assigned Assessors      
   BEGIN      
    SELECT Assessor.value('(ID/text())[1]', 'int') AS ID      
     ,@QuestionID AS QuestionID      
     ,Identity(INT, 1, 1) AS RowID      
     ,Assessor.value('(AssessorID/text())[1]', 'int') AS AssessorID      
     ,Assessor.value('(TargetFrequencyTypeID/text())[1]', 'int') AS TargetFrequencyTypeID      
     ,Assessor.value('(TargetFrequencyValue/text())[1]', 'nvarchar(50)') AS TargetFrequencyValue      
    INTO #Assessor      
    FROM @Assessors.nodes('/ArrayOfAssessor/Assessor') AS TEMPTABLE(Assessor)      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO @Scope_Identity_Table_Trigger      
    SELECT ID      
    FROM T_LNK_AssignedAssessors WITH (NOLOCK)      
    WHERE ID NOT IN (      
      SELECT ID      
      FROM #Assessor      
      WHERE ID != 0      
       OR ID IS NOT NULL      
      )      
     AND QuestionID = @QuestionID      
      
    UPDATE T_LNK_AssignedAssessors      
    SET IsDeleted = 1      
    WHERE ID IN (      
      SELECT id      
      FROM @Scope_Identity_Table_Trigger      
      ) -- removes the deleted assessors      
      
    SELECT @TableName_Trigger = 'AssignedAssessors'      
     ,@ActionType = 'U'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
     ,@QuestionHistoryID = @QuestionHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger      
     ,@PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID;      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO T_LNK_AssignedAssessors (      
     QuestionID      
     ,AssessorID      
     ,TargetFrequencyTypeID      
     ,TargetFrequencyValue      
     )      
    OUTPUT inserted.ID      
    INTO @Scope_Identity_Table_Trigger      
    SELECT QuestionID      
     ,AssessorID      
     ,TargetFrequencyTypeID      
     ,TargetFrequencyValue      
    FROM #Assessor      
    WHERE (      
      ID IS NULL      
      OR ID = 0      
      )      
     AND QuestionID = @QuestionID      
      
    SELECT @TableName_Trigger = 'AssignedAssessors'      
     ,@ActionType = 'I'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
     ,@QuestionHistoryID = @QuestionHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger      
     ,@PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID;      
      
    SET @min = (      
      SELECT MIN(RowID)      
      FROM #Assessor      
      );--Get minimum row number from temp table      
    SET @max = (      
      SELECT Max(RowID)      
      FROM #Assessor      
      );--Get maximum row number from temp table      
      
    WHILE (@min <= @max)      
    BEGIN      
     SELECT @QuestionID = QuestionID      
      ,@AssessorID = AssessorID      
      ,@TargetFrequencyTypeID = TargetFrequencyTypeID      
      ,@TargetFrequencyValue = TargetFrequencyValue      
      ,@ID = ID      
     FROM #Assessor      
     WHERE RowID = @min      
      
     UPDATE T_LNK_AssignedAssessors      
     SET QuestionID = @QuestionID      
      ,AssessorID = @AssessorID      
      ,TargetFrequencyTypeID = @TargetFrequencyTypeID      
      ,TargetFrequencyValue = @TargetFrequencyValue      
     WHERE ID = @ID      
      
     SELECT @TableName_Trigger = 'AssignedAssessors'      
      ,@ActionType = 'U'      
      ,@Input_Ids_Trigger = @ID;      
      
     EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
      ,@QuestionHistoryID = @QuestionHistoryID      
      ,@ActionType = @ActionType      
      ,@INPUT_IDS = @Input_Ids_Trigger      
      ,@PlantID = @PlantID      
      ,@CurrentUserNTID = @CurrentUserNTID;      
      
     SET @min = @min + 1 --Increment of current row number      
    END      
   END      
      
   --for Assigned Tags      
   BEGIN      
    SELECT @QuestionID AS QuestionID      
     ,Identity(INT, 1, 1) AS RowID      
     ,Tag.value('(TagID/text())[1]', 'int') AS TagID      
    INTO #Tag      
    FROM @Tags.nodes('/ArrayOfTag/Tag') AS TEMPTABLE(Tag)      
      
    SELECT Identity(INT, 1, 1) AS RowID      
     ,TagID      
    INTO #RemovedTagIDs      
    FROM T_LNK_QN_AssignedTags WITH (NOLOCK)      
    WHERE TagID NOT IN (      
      SELECT TagID      
      FROM #Tag      
      )      
     AND QuestionID = @QuestionID      
     AND IsDeleted = 0 -- removes the deleted tags      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO @Scope_Identity_Table_Trigger      
    SELECT ID      
    FROM T_LNK_QN_AssignedTags WITH (NOLOCK)      
    WHERE TagID NOT IN (      
      SELECT TagID      
      FROM #Tag      
      )      
     AND QuestionID = @QuestionID      
      
    UPDATE T_LNK_QN_AssignedTags      
    SET IsDeleted = 1      
    WHERE ID IN (      
      SELECT id      
      FROM @Scope_Identity_Table_Trigger      
      ) -- removes the deleted tags      
      
    SELECT @TableName_Trigger = 'AssignedTags'      
     ,@ActionType = 'U'      
     ,@Input_Ids_Trigger = (     
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
     ,@QuestionHistoryID = @QuestionHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger      
     ,@PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID;      
      
    SET @min = (      
      SELECT MIN(RowID)      
      FROM #Tag      
      WHERE QuestionID = @QuestionID      
      );--Get minimum row number from temp table      
    SET @max = (      
      SELECT Max(RowID)      
      FROM #Tag      
      WHERE QuestionID = @QuestionID      
      );--Get maximum row number from temp table      
      
    WHILE (@min <= @max)      
    BEGIN      
     SELECT @QuestionID = QuestionID      
      ,@TagID = TagID      
     FROM #Tag      
     WHERE RowID = @min      
      AND QuestionID = @QuestionID      
      
     IF NOT EXISTS (      
       SELECT TOP (1) 1      
       FROM T_LNK_QN_AssignedTags WITH (NOLOCK)      
       WHERE TagID = @TagID      
        AND QuestionID = @QuestionID      
       )      
     BEGIN      
      INSERT INTO T_LNK_QN_AssignedTags (      
       QuestionID      
       ,TagID      
       )      
      VALUES (      
       @QuestionID      
       ,@TagID      
       )      
      
      SELECT @TableName_Trigger = 'AssignedTags'      
       ,@ActionType = 'I'      
       ,@Input_Ids_Trigger = SCOPE_IDENTITY();      
      
      EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
       ,@QuestionHistoryID = @QuestionHistoryID      
       ,@ActionType = @ActionType      
       ,@INPUT_IDS = @Input_Ids_Trigger      
       ,@PlantID = @PlantID      
       ,@CurrentUserNTID = @CurrentUserNTID;      
     END      
     ELSE      
     BEGIN      
      DELETE      
      FROM @Scope_Identity_Table_Trigger      
      
      INSERT INTO @Scope_Identity_Table_Trigger      
      SELECT ID      
      FROM T_LNK_QN_AssignedTags WITH (NOLOCK)      
      WHERE QuestionID = @QuestionID      
       AND TagID = @TagID      
      
      UPDATE T_LNK_QN_AssignedTags      
      SET IsDeleted = 0      
      WHERE ID IN (      
        SELECT id      
        FROM @Scope_Identity_Table_Trigger      
        )      
      
      SELECT @TableName_Trigger = 'AssignedTags'      
       ,@ActionType = 'U'      
       ,@Input_Ids_Trigger = (      
        SELECT CAST(id AS VARCHAR(MAX)) + ', '      
        FROM @Scope_Identity_Table_Trigger      
        FOR XML PATH('')      
        );      
      
      EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
       ,@QuestionHistoryID = @QuestionHistoryID      
       ,@ActionType = @ActionType      
       ,@INPUT_IDS = @Input_Ids_Trigger      
       ,@PlantID = @PlantID      
       ,@CurrentUserNTID = @CurrentUserNTID;      
     END      
      
     SET @min = @min + 1 --Increment of current row number      
    END      
   END      
      
   --Update the audit question with respect to changes done on question creation tag linking      
   SET @min = (      
     SELECT MIN(RowID)      
     FROM #RemovedTagIDs      
     );      
   SET @max = (      
     SELECT Max(RowID)      
     FROM #RemovedTagIDs      
     );      
      
   IF (@min <> 0)      
   BEGIN      
    WHILE (@min <= @max)      
    BEGIN      
     DECLARE @RemovedTagID INT      
      
     SET @RemovedTagID = (      
       SELECT TagID      
       FROM #RemovedTagIDs      
       WHERE RowID = @min      
       )      
     
	 BEGIN

     EXEC USP_UpdateAuditQuestionsAndValueStreamsByTagID @PlantID      
      ,@RemovedTagID      
      ,@CurrentUserNTID      
    END
     SET @min = @min + 1 --Increment of current row number      
    END      
   END      
      
   --ENDS-- Update the audit question with respect to changes done on question creation tag linking      
   IF (@AnswerType_AnswerTypeID = 1)      
   BEGIN      
    SELECT @QuestionID AS QuestionID      
     ,Identity(INT, 1, 1) AS RowID      
     ,SL.value('(ID/text())[1]', 'int') AS ID      
     ,SL.value('(MaxCharacters/text())[1]', 'int') AS MaxCharacters      
     ,SL.value('(IsCalculated/text())[1]', 'bit') AS IsCalculated      
     ,SL.value('(DefaultValue/text())[1]', 'NVARCHAR(10)') AS DefaultValue      
    INTO #SL1      
    FROM @SingleLineText.nodes('/SingleLineText') AS TEMPTABLE(SL)      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO @Scope_Identity_Table_Trigger      
    SELECT ID      
    FROM T_TRN_SingleLineText WITH (NOLOCK)      
    WHERE ID NOT IN (      
      SELECT ID      
      FROM #SL1      
      WHERE (      
        ID != 0      
        OR ID IS NOT NULL      
        )      
      )      
     AND QuestionID = @QuestionID      
      
    UPDATE T_TRN_SingleLineText      
    SET IsDeleted = 1      
    WHERE ID IN (      
      SELECT id      
      FROM @Scope_Identity_Table_Trigger      
      ) -- removes the deleted items      
      
    SELECT @TableName_Trigger = 'SingleLineText'      
     ,@ActionType = 'U'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
     ,@QuestionHistoryID = @QuestionHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger      
    ,@PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID;      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO T_TRN_SingleLineText (      
     MaxCharacters      
     ,IsCalculated      
     ,DefaultValue      
     ,QuestionID      
     )      
    OUTPUT inserted.ID      
    INTO @Scope_Identity_Table_Trigger      
    SELECT MaxCharacters      
     ,IsCalculated      
     ,DefaultValue      
     ,QuestionID      
    FROM #SL1      
    WHERE ID IS NULL      
     OR ID = 0      
      
    SELECT @TableName_Trigger = 'SingleLineText'      
     ,@ActionType = 'I'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
     ,@QuestionHistoryID = @QuestionHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger      
     ,@PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID;      
      
    SET @min = (      
      SELECT MIN(RowID)      
      FROM #SL1      
      );--Get minimum row number from temp table      
    SET @max = (      
      SELECT Max(RowID)      
      FROM #SL1      
      );--Get maximum row number from temp table      
      
    WHILE (@min <= @max)      
    BEGIN      
     SELECT @MaxCharacters = MaxCharacters      
      ,@IsCalculated = IsCalculated      
      ,@DefaultValue = DefaultValue      
      ,@ID = ID      
     FROM #SL1      
     WHERE RowID = @min      
      
     UPDATE T_TRN_SingleLineText      
     SET MaxCharacters = @MaxCharacters      
      ,IsCalculated = @IsCalculated      
      ,DefaultValue = @DefaultValue      
     WHERE ID = @ID      
      
     SELECT @TableName_Trigger = 'SingleLineText'      
      ,@ActionType = 'I'      
      ,@Input_Ids_Trigger = @ID;      
      
     EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
      ,@QuestionHistoryID = @QuestionHistoryID      
      ,@ActionType = @ActionType      
      ,@INPUT_IDS = @Input_Ids_Trigger      
      ,@PlantID = @PlantID      
      ,@CurrentUserNTID = @CurrentUserNTID;      
      
     SET @min = @min + 1      
    END      
   END      
      
   IF (@AnswerType_AnswerTypeID = 2)      
   BEGIN      
    SELECT @QuestionID AS QuestionID      
     ,Identity(INT, 1, 1) AS RowID      
     ,ML.value('(ID/text())[1]', 'int') AS ID      
     ,ML.value('(MaxLines/text())[1]', 'int') AS MaxLines      
     ,ML.value('(IsPlaintText/text())[1]', 'bit') AS IsPlaintText      
    INTO #ML      
    FROM @MultipleLinesText.nodes('/MultipleLinesText') AS TEMPTABLE(ML)      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO @Scope_Identity_Table_Trigger      
    SELECT ID      
    FROM T_TRN_MultipleLinesText WITH (NOLOCK)      
    WHERE ID NOT IN (      
      SELECT ID      
      FROM #ML      
      WHERE ID != 0      
       OR ID IS NOT NULL      
      )      
     AND QuestionID = @QuestionID      
      
    UPDATE T_TRN_MultipleLinesText      
    SET IsDeleted = 1      
    WHERE ID IN (      
      SELECT id      
      FROM @Scope_Identity_Table_Trigger      
      ) -- removes the deleted items      
      
    SELECT @TableName_Trigger = 'MultipleLinesText'      
     ,@ActionType = 'U'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
     ,@QuestionHistoryID = @QuestionHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger      
     ,@PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID;      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO T_TRN_MultipleLinesText (      
     MaxLines      
     ,IsPlaintText      
     ,QuestionID           )      
    OUTPUT inserted.ID      
    INTO @Scope_Identity_Table_Trigger      
    SELECT MaxLines      
     ,IsPlaintText      
     ,QuestionID      
    FROM #ML      
    WHERE ID IS NULL      
     OR ID = 0      
      
    SELECT @TableName_Trigger = 'MultipleLinesText'      
     ,@ActionType = 'I'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
     ,@QuestionHistoryID = @QuestionHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger      
     ,@PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID;      
      
    SET @min = (      
      SELECT MIN(RowID)      
      FROM #ML      
      );--Get minimum row number from temp table      
    SET @max = (      
      SELECT Max(RowID)      
      FROM #ML      
      );--Get maximum row number from temp table      
      
    WHILE (@min <= @max)      
    BEGIN      
     SELECT @MaxLines = MaxLines      
      ,@IsPlaintText = IsPlaintText      
      ,@QuestionID = QuestionID      
      ,@ID = ID      
     FROM #ML      
     WHERE RowID = @min      
      
     UPDATE T_TRN_MultipleLinesText      
     SET MaxLines = @MaxLines      
      ,IsPlaintText = @IsPlaintText      
      ,QuestionID = @QuestionID      
     WHERE ID = @ID      
      
     SELECT @TableName_Trigger = 'MultipleLinesText'      
      ,@ActionType = 'U'      
      ,@Input_Ids_Trigger = @ID;      
      
     EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
      ,@QuestionHistoryID = @QuestionHistoryID      
      ,@ActionType = @ActionType      
      ,@INPUT_IDS = @Input_Ids_Trigger      
      ,@PlantID = @PlantID      
      ,@CurrentUserNTID = @CurrentUserNTID;      
      
     SET @min = @min + 1      
    END      
   END      
      
   IF (@AnswerType_AnswerTypeID = 3)      
   BEGIN      
    SELECT @QuestionID AS QuestionID      
     ,Identity(INT, 1, 1) AS RowID      
     ,Choice.value('(ChoiceID/text())[1]', 'int') AS ChoiceID      
     ,Choice.value('(ChoiceName/text())[1]', 'NVARCHAR(500)') AS ChoiceName      
     ,Choice.value('(ChoiceScore/text())[1]', 'decimal(10,2)') AS ChoiceScore      
     ,Choice.value('(IsDeviationEntryRequired/text())[1]', 'bit') AS IsDeviationEntryRequired      
     ,Choice.value('(DeviationTypeID/text())[1]', 'int') AS DeviationTypeID      
     ,Choice.value('(AnswerCategory/text())[1]', 'NVARCHAR(50)') AS AnswerCategory      
    INTO #Choice      
    FROM @Choices.nodes('/ArrayOfChoice/Choice') AS TEMPTABLE(Choice)      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO @Scope_Identity_Table_Trigger      
    SELECT ChoiceID      
    FROM T_TRN_Choice WITH (NOLOCK)      
    WHERE ChoiceID NOT IN (      
      SELECT ChoiceID      
      FROM #Choice      
      WHERE ChoiceID != 0      
       OR ChoiceID IS NOT NULL      
      )      
     AND QuestionID = @QuestionID      
      
    UPDATE T_TRN_Choice      
    SET IsDeleted = 1      
    WHERE ChoiceID IN (      
      SELECT id      
      FROM @Scope_Identity_Table_Trigger      
      ) -- removes the deleted items      
      
    SELECT @TableName_Trigger = 'Choice'      
     ,@ActionType = 'U'      
 ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
     ,@QuestionHistoryID = @QuestionHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger      
     ,@PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID;      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO T_TRN_Choice (      
     ChoiceName      
     ,ChoiceScore      
     ,IsDeviationEntryRequired      
     ,DeviationTypeID      
     ,QuestionID      
     ,AnswerCategory      
     )      
    OUTPUT inserted.ChoiceID      
    INTO @Scope_Identity_Table_Trigger      
    SELECT ChoiceName      
     ,ChoiceScore      
     ,IsDeviationEntryRequired      
     ,DeviationTypeID      
     ,QuestionID      
     ,AnswerCategory      
    FROM #Choice      
    WHERE ChoiceID IS NULL      
     OR ChoiceID = 0      
      
    SELECT @TableName_Trigger = 'Choice'      
     ,@ActionType = 'I'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
     ,@QuestionHistoryID = @QuestionHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger      
     ,@PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID;      
      
    SET @min = (      
      SELECT MIN(RowID)      
      FROM #Choice      
      );--Get minimum row number from temp table      
    SET @max = (      
      SELECT Max(RowID)      
      FROM #Choice      
      );--Get maximum row number from temp table      
      
    WHILE (@min <= @max)      
    BEGIN      
     SELECT @ChoiceName = ChoiceName      
      ,@ChoiceScore = ChoiceScore      
      ,@IsDeviationEntryRequired = IsDeviationEntryRequired      
      ,@QuestionID = QuestionID      
      ,@DeviationTypeID = DeviationTypeID      
      ,@ChoiceID = ChoiceID      
      ,@AnswerCategory = AnswerCategory      
     FROM #Choice      
     WHERE RowID = @min      
      AND QuestionID = @QuestionID      
      
     UPDATE T_TRN_Choice      
     SET ChoiceName = @ChoiceName      
      ,ChoiceScore = @ChoiceScore      
      ,IsDeviationEntryRequired = @IsDeviationEntryRequired      
      ,QuestionID = @QuestionID      
      ,DeviationTypeID = @DeviationTypeID      
      ,AnswerCategory = @AnswerCategory      
     WHERE ChoiceID = @ChoiceID      
      AND QuestionID = @QuestionID      
      
     SELECT @TableName_Trigger = 'Choice'      
      ,@ActionType = 'U'      
      ,@Input_Ids_Trigger = @ChoiceID;      
      
     EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
      ,@QuestionHistoryID = @QuestionHistoryID      
      ,@ActionType = @ActionType      
      ,@INPUT_IDS = @Input_Ids_Trigger      
      ,@PlantID = @PlantID      
      ,@CurrentUserNTID = @CurrentUserNTID;      
      
     SET @min = @min + 1      
    END      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    UPDATE [T_TRN_Question]      
    SET DefaultChoiceID = (      
      SELECT TOP 1 ChoiceID      
      FROM T_TRN_Choice      
      WHERE ChoiceName = @DefaultChoice      
       AND QuestionID = @QuestionID      
      )      
    WHERE QuestionID = @QuestionID      
     AND IsDefaultAnswerRequired = @IsDefaultAnswerRequired      
     AND PlantID = @PlantID;      
      
    SELECT @TableName_Trigger = 'Question'      
     ,@ActionType = 'U'      
     ,@Input_Ids_Trigger = @QuestionID;      
      
    EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
     ,@QuestionHistoryID = @QuestionHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @QuestionID      
     ,@PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID;      
   END      
      
   IF (@AnswerType_AnswerTypeID = 4)      
   BEGIN      
    SELECT @QuestionID AS QuestionID      
     ,RatingScale.value('(ID/text())[1]', 'int') AS ID      
     ,RatingScale.value('(NumberRange/text())[1]', 'NVARCHAR(10)') AS NumberRange      
     ,RatingScale.value('(RangeText1/text())[1]', 'NVARCHAR(50)') AS RangeText1      
     ,RatingScale.value('(RangeText2/text())[1]', 'NVARCHAR(50)') AS RangeText2      
     ,RatingScale.value('(RangeText3/text())[1]', 'NVARCHAR(50)') AS RangeText3      
     ,RatingScale.value('(ShowNA/text())[1]', 'bit') AS ShowNA      
     ,RatingScale.value('(TextNA/text())[1]', 'NVARCHAR(10)') AS TextNA   
    INTO #RatingScale      
    FROM @RatingScale.nodes('/RatingScale') AS TEMPTABLE(RatingScale)      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO @Scope_Identity_Table_Trigger      
    SELECT ID      
    FROM T_TRN_RatingScale WITH (NOLOCK)      
    WHERE ID NOT IN (      
      SELECT ID      
      FROM #RatingScale      
      WHERE ID != 0      
       OR ID IS NOT NULL      
      )      
     AND QuestionID = @QuestionID      
      
    UPDATE T_TRN_RatingScale      
    SET IsDeleted = 1      
    WHERE ID IN (      
      SELECT id      
      FROM @Scope_Identity_Table_Trigger      
      ) -- removes the deleted items      
      
    SELECT @TableName_Trigger = 'RatingScale'      
     ,@ActionType = 'U'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
     ,@QuestionHistoryID = @QuestionHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger      
     ,@PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID;      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO T_TRN_RatingScale (      
     QuestionID      
     ,NumberRange      
     ,RangeText1      
     ,RangeText2      
     ,RangeText3      
     ,ShowNA      
     ,TextNA      
     )      
    OUTPUT inserted.ChoiceID      
    INTO @Scope_Identity_Table_Trigger      
    SELECT QuestionID      
     ,NumberRange      
     ,RangeText1      
     ,RangeText2      
     ,RangeText3      
     ,ShowNA      
     ,TextNA      
    FROM #RatingScale      
    WHERE ID IS NULL      
     OR ID = 0      
      
    SELECT @TableName_Trigger = 'RatingScale'      
     ,@ActionType = 'I'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
     ,@QuestionHistoryID = @QuestionHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger      
     ,@PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID;      
      
    WHILE (@min <= @max)      
    BEGIN      
     SELECT @QuestionID = QuestionID      
      ,@NumberRange = NumberRange      
      ,@RangeText1 = RangeText1      
      ,@RangeText2 = RangeText2      
      ,@RangeText3 = RangeText3      
      ,@ShowNA = ShowNA      
      ,@TextNA = TextNA      
     FROM #RatingScale      
     WHERE ID = @min      
      
     UPDATE T_TRN_RatingScale      
     SET QuestionID = @QuestionID      
      ,NumberRange = @NumberRange      
      ,RangeText1 = @RangeText1      
      ,RangeText2 = @RangeText2      
      ,RangeText3 = @RangeText3      
      ,ShowNA = @ShowNA      
      ,TextNA = @TextNA      
     WHERE ID = @min      
      
     SELECT @TableName_Trigger = 'RatingScale'      
      ,@ActionType = 'U'      
      ,@Input_Ids_Trigger = @min;      
      
     EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
      ,@QuestionHistoryID = @QuestionHistoryID      
      ,@ActionType = @ActionType      
      ,@INPUT_IDS = @Input_Ids_Trigger      
      ,@PlantID = @PlantID      
      ,@CurrentUserNTID = @CurrentUserNTID;      
      
     SET @min = @min + 1      
    END      
      
    SELECT @QuestionID AS QuestionID      
     ,SubQuestion.value('(ID/text())[1]', 'int') AS ID      
     ,SubQuestion.value('(Name/text())[1]', 'NVARCHAR(200)') AS Name      
    INTO #SubQuestion      
    FROM @SubQuestions.nodes('/ArrayOfSubQuestion/SubQuestion') AS TEMPTABLE(SubQuestion)      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO @Scope_Identity_Table_Trigger      
    SELECT ID      
    FROM T_TRN_SubQuestion WITH (NOLOCK)      
    WHERE ID NOT IN (      
      SELECT ID      
      FROM #SubQuestion      
      WHERE ID != 0      
       OR ID IS NOT NULL      
      )      
     AND QuestionID = @QuestionID      
      
    UPDATE T_TRN_SubQuestion      
    SET IsDeleted = 1      
    WHERE ID IN (      
      SELECT id      
      FROM @Scope_Identity_Table_Trigger      
      ) -- removes the deleted items      
      
    SELECT @TableName_Trigger = 'SubQuestion'      
     ,@ActionType = 'U'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
     ,@QuestionHistoryID = @QuestionHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger      
     ,@PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID;      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO T_TRN_SubQuestion (      
     QuestionID      
     ,Name      
     )      
    OUTPUT inserted.ID      
    INTO @Scope_Identity_Table_Trigger      
    SELECT QuestionID      
     ,Name      
    FROM #SubQuestion      
    WHERE ID IS NULL      
     OR ID = 0      
      
    SELECT @TableName_Trigger = 'SubQuestion'      
     ,@ActionType = 'I'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
     ,@QuestionHistoryID = @QuestionHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger      
     ,@PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID;      
      
    WHILE (@min <= @max)      
    BEGIN      
     SELECT @QuestionID = QuestionID      
      ,@Name = Name      
     FROM #SubQuestion      
     WHERE ID = @min      
      
     UPDATE T_TRN_SubQuestion      
     SET QuestionID = @QuestionID      
      ,Name = @Name      
     WHERE ID = @min      
      
     SELECT @TableName_Trigger = 'SubQuestion'      
      ,@ActionType = 'U'      
      ,@Input_Ids_Trigger = @min;      
      
     EXEC [USP_QUESTION_HISTORY] @TableName = @TableName_Trigger      
      ,@QuestionHistoryID = @QuestionHistoryID      
      ,@ActionType = @ActionType      
      ,@INPUT_IDS = @Input_Ids_Trigger      
      ,@PlantID = @PlantID      
      ,@CurrentUserNTID = @CurrentUserNTID;      
      
     SET @min = @min + 1      
    END      
   END      
      
   IF (@AnswerType_AnswerTypeID = 5)      
   BEGIN      
    SELECT @QuestionID AS QuestionID      
     ,ATN.value('(ID/text())[1]', 'int') AS ID      
     ,ATN.value('(MaxValue/text())[1]', 'int') AS MaxValue      
     ,ATN.value('(MinValue/text())[1]', 'int') AS MinValue      
     ,ATN.value('(NumberOfDecimalPlaces/text())[1]', 'NVARCHAR(10)') AS NumberOfDecimalPlaces      
     ,ATN.value('(IsNumber/text())[1]', 'bit') AS IsNumber      
     ,ATN.value('(DefaultValue/text())[1]', 'NVARCHAR(MAX)') AS DefaultValue      
     ,ATN.value('(ShowPercentage/text())[1]', 'bit') AS ShowPercentage      
    INTO #ATN      
    FROM @AnswerTypeNumber.nodes('/AnswerTypeNumber') AS TEMPTABLE(ATN)      
      
    UPDATE T_TRN_AnswerTypeNumber      
    SET IsDeleted = 1      
    WHERE ID NOT IN (      
      SELECT ID      
      FROM #ATN      
      WHERE ID != 0      
       OR ID IS NOT NULL      
      )      
     AND QuestionID = @QuestionID -- removes the deleted items      
      
    INSERT INTO T_TRN_AnswerTypeNumber (      
     MaxValue      
     ,MinValue      
     ,NumberOfDecimalPlaces      
     ,IsNumber      
     ,defaultValue      
     ,ShowPercentage      
     )      
    SELECT MaxValue      
     ,MinValue      
     ,NumberOfDecimalPlaces      
     ,IsNumber      
     ,defaultValue      
     ,ShowPercentage      
    FROM #ATN      
    WHERE ID IS NULL      
     OR ID = 0      
      
    SET @min = (      
      SELECT MIN(ID)      
      FROM #ATN      
      );--Get minimum row number from temp table      
    SET @max = (      
      SELECT Max(ID)      
      FROM #ATN      
      );--Get maximum row number from temp table      
      
    WHILE (@min <= @max)      
    BEGIN      
     SELECT @MaxValue = MaxValue      
      ,@MinValue = MinValue      
      ,@NumberOfDecimalPlaces = NumberOfDecimalPlaces      
      ,@IsNumber = IsNumber      
      ,@defaultValue = defaultValue      
      ,@ShowPercentage = ShowPercentage      
      ,@QuestionID = QuestionID      
     FROM #ATN      
     WHERE ID = @min      
      
     UPDATE T_TRN_AnswerTypeNumber      
     SET MaxValue = @MaxValue      
      ,MinValue = @MinValue      
      ,NumberOfDecimalPlaces = @NumberOfDecimalPlaces      
      ,IsNumber = @IsNumber      
      ,defaultValue = @defaultValue      
      ,ShowPercentage = @ShowPercentage      
      ,QuestionID = @QuestionID      
     WHERE ID = @min      
      
     SET @min = @min + 1      
    END      
   END      
      
   IF (@AnswerType_AnswerTypeID = 6)      
   BEGIN      
    SELECT @QuestionID AS QuestionID      
     ,ATC.value('(ID/text())[1]', 'int') AS ID      
     ,ATC.value('(MaxValue/text())[1]', 'bit') AS MaxValue      
     ,ATC.value('(MinValue/text())[1]', 'bit') AS MinValue      
     ,ATC.value('(NumberOfDecimalPlaces/text())[1]', 'NVARCHAR(10)') AS NumberOfDecimalPlaces      
     ,ATC.value('(IsCurrency/text())[1]', 'bit') AS IsCurrency      
     ,ATC.value('(DefaultValue/text())[1]', 'NVARCHAR(MAX)') AS DefaultValue      
     ,ATC.value('(CurrencyFormat/text())[1]', 'NVARCHAR(100)') AS CurrencyFormat      
    INTO #ATC      
    FROM @AnswerTypeCurrency.nodes('/AnswerTypeCurrency') AS TEMPTABLE(ATC)      
      
    UPDATE T_TRN_AnswerTypeCurrency      
    SET IsDeleted = 1      
    WHERE ID NOT IN (      
      SELECT ID      
      FROM #ATC      
      WHERE ID != 0      
       OR ID IS NOT NULL      
      )      
     AND QuestionID = @QuestionID -- removes the deleted items      
      
    INSERT INTO T_TRN_AnswerTypeCurrency (      
     MaxValue      
     ,MinValue      
     ,NumberOfDecimalPlaces      
     ,IsCurrency      
     ,defaultValue      
     ,CurrencyFormat      
     )      
    SELECT MaxValue      
     ,MinValue      
     ,NumberOfDecimalPlaces      
     ,IsCurrency      
     ,defaultValue      
     ,CurrencyFormat      
    FROM #ATC      
    WHERE ID IS NULL      
     OR ID = 0      
      
    SET @min = (      
      SELECT MIN(ID)      
      FROM #ATN      
      );--Get minimum row number from temp table      
    SET @max = (      
      SELECT Max(ID)      
      FROM #ATN      
      );--Get maximum row number from temp table      
      
    WHILE (@min <= @max)      
    BEGIN      
     SELECT @MaxValue = MaxValue      
      ,@MinValue = MinValue      
      ,@NumberOfDecimalPlaces = NumberOfDecimalPlaces      
      ,@IsCurrency = IsCurrency      
      ,@defaultValue = defaultValue      
      ,@CurrencyFormat = CurrencyFormat      
      ,@QuestionID = QuestionID      
     FROM #ATC      
     WHERE ID = @min      
      
     UPDATE T_TRN_AnswerTypeCurrency      
     SET MaxValue = @MaxValue      
      ,MinValue = @MinValue      
      ,NumberOfDecimalPlaces = @NumberOfDecimalPlaces      
      ,IsCurrency = @IsCurrency      
      ,defaultValue = @defaultValue      
      ,CurrencyFormat = @CurrencyFormat      
      ,QuestionID = @QuestionID      
     WHERE ID = @min      
      
     SET @min = @min + 1      
    END      
   END      
      
   IF (@AnswerType_AnswerTypeID = 7)      
   BEGIN      
    SELECT @QuestionID AS QuestionID      
     ,ATD.value('(ID/text())[1]', 'int') AS ID      
     ,ATD.value('(IsDateOnly/text())[1]', 'bit') AS IsDateOnly      
     ,ATD.value('(IsStandard/text())[1]', 'bit') AS IsStandard      
     ,ATD.value('(DefaultDateType/text())[1]', 'NVARCHAR(10)') AS DefaultDateType      
     ,ATD.value('(DefaultValue/text())[1]', 'NVARCHAR(MAX)') AS DefaultValue      
    INTO #ATD      
    FROM @AnswerTypeDateTime.nodes('/AnswerTypeDateTime') AS TEMPTABLE(ATD)      
      
    UPDATE T_TRN_AnswerTypeDateTime      
    SET IsDeleted = 1      
    WHERE ID NOT IN (      
      SELECT ID      
      FROM #ATD      
      WHERE ID != 0      
       OR ID IS NOT NULL      
      )      
     AND QuestionID = @QuestionID -- removes the deleted items      
      
    INSERT INTO T_TRN_AnswerTypeDateTime (      
     IsDateOnly      
     ,IsStandard      
     ,DefaultDateType      
     ,DefaultValue      
     ,QuestionID      
     )      
    SELECT IsDateOnly      
     ,IsStandard      
     ,DefaultDateType      
     ,DefaultValue      
     ,QuestionID      
    FROM #ATD      
    WHERE ID IS NULL      
     OR ID = 0      
      
    SET @min = (      
      SELECT MIN(ID)      
      FROM #ATD      
      );--Get minimum row number from temp table      
    SET @max = (      
      SELECT Max(ID)      
      FROM #ATD      
      );--Get maximum row number from temp table      
      
    WHILE (@min <= @max)      
    BEGIN      
     SELECT @IsDateOnly = IsDateOnly      
      ,@IsStandard = IsStandard      
      ,@DefaultDateType = DefaultDateType      
      ,@DefaultValue = DefaultValue      
      ,@QuestionID = QuestionID      
     FROM #ATD      
     WHERE ID = @min      
      
     UPDATE T_TRN_AnswerTypeDateTime      
     SET IsDateOnly = @IsDateOnly      
      ,IsStandard = @IsStandard      
      ,DefaultDateType = @DefaultDateType      
      ,DefaultValue = @DefaultValue      
      ,QuestionID = @QuestionID      
     WHERE ID = @min      
      
     SET @min = @min + 1      
    END      
   END      
  END      
      
  ----to disable the history after the insert/update, to avoid lock settings history      
  --ALTER TABLE [T_TRN_Question] DISABLE TRIGGER [TR_HISTORYFOR_T_TRN_Question]      
  --ALTER TABLE [T_TRN_HintImage] DISABLE TRIGGER [TR_HISTORYFOR_T_TRN_HintImage]      
  --ALTER TABLE [T_TRN_HintHyperLink] DISABLE TRIGGER [TR_HISTORYFOR_T_TRN_HintHyperLink]      
  --ALTER TABLE [T_LNK_AssignedValueStreams] DISABLE TRIGGER [TR_HISTORYFOR_T_LNK_AssignedValueStreams]      
  --ALTER TABLE [T_LNK_AssignedAssessors] DISABLE TRIGGER [TR_HISTORYFOR_T_LNK_AssignedAssessors]      
  --ALTER TABLE [T_LNK_QN_AssignedTags] DISABLE TRIGGER [TR_HISTORYFOR_T_LNK_QN_AssignedTags]      
  --ALTER TABLE [T_TRN_SingleLineText] DISABLE TRIGGER [TR_HISTORYFOR_T_TRN_SingleLineText]      
  --ALTER TABLE [T_TRN_MultipleLinesText] DISABLE TRIGGER [TR_HISTORYFOR_T_TRN_MultipleLinesText]      
  --ALTER TABLE [T_TRN_Choice] DISABLE TRIGGER [TR_HISTORYFOR_T_TRN_Choice]      
      --  END      
  SELECT QuestionID      
   ,PlantID      
   ,QuestionDisplayID      
   ,QuestionText      
   ,QuestionHintText      
   ,AnswerType_AnswerTypeID      
   ,ChoiceDisplayTypeID      
   ,IsFilledInChoiceAllowed      
   ,IsUniqueAnswerRequired      
   ,IsAnswerRequired      
   ,DefaultChoiceID      
   ,IsQuestionAlwaysActive      
   ,ActiveDateRangeFrom      
   ,ActiveDateRangeTo      
   ,IsTargetFrequencyDefined      
   ,TargetFrequencyTypeID      
   ,TargetFrequencyValue      
   ,Question_PriorityID      
   ,IsLocked      
   -- ,Assigned_ValueStreamTemplateID      
   -- ,Assigned_ValueStreamCategoryID      
   -- ,Assigned_AssessorTemplateID      
   ,IsDeleted      
   ,CreatedAt      
   ,ModifiedAt      
   ,IsDefaultAnswerRequired      
   ,Assigned_AssessorID      
   ,IsAnswered      
   ,CreatedBy_NTID      
   ,ModifiedBy_NTID      
   ,DefaultChoice      
  FROM [T_TRN_Question] WITH (NOLOCK)      
  WHERE QuestionID = @QuestionID      
   AND PlantID = @PlantID;      
         
     SET @Counter = @Counter + 1      
  SET @QuestionID = null      
        CONTINUE      
 END      
  COMMIT TRANSACTION TRNINSERTQUESTION;      
 END TRY      
      
 BEGIN CATCH      
  ROLLBACK TRANSACTION TRNINSERTQUESTION;      
      
  EXEC USP_LogError @PlantID      
   ,@CurrentUserNTID;      
 END CATCH      
END 

