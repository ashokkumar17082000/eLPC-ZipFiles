/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_ProcessConfirmationByTagID] 
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR PROCESS CONFIRMATION BY TAG ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			VENKATESH GOVINDARAJ		PLANTID & CODE CLEANUP

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_ProcessConfirmationByTagID] 3, 1
*/
CREATE PROCEDURE [USP_ProcessConfirmationByTagID] @PCTagID INT
	,@PlantID INT
AS
BEGIN
	SET NOCOUNT ON;

	SELECT DISTINCT QuestionID
	INTO #questionIDs
	FROM [FN_GetNestedQuestionsByTagID](@PCTagID, @PlantID)

	SELECT QuestionID
		,PlantID
		,QuestionDisplayID
		,QuestionText
		,QuestionHintText
		,AnswerType_AnswerTypeID
		,ChoiceDisplayTypeID
		,IsFilledInChoiceAllowed
		,IsUniqueAnswerRequired
		,IsAnswerRequired
		,DefaultChoiceID
		,IsQuestionAlwaysActive
		,ActiveDateRangeFrom
		,ActiveDateRangeTo
		,IsTargetFrequencyDefined
		,TargetFrequencyTypeID
		,TargetFrequencyValue
		,Question_PriorityID
		,IsLocked
		-- ,Assigned_ValueStreamTemplateID
		-- ,Assigned_ValueStreamCategoryID
		-- ,Assigned_AssessorTemplateID
		,IsDeleted
		,CreatedAt
		,ModifiedAt
		,IsDefaultAnswerRequired
		,Assigned_AssessorID
		,IsAnswered
		,CreatedBy_NTID
		,ModifiedBy_NTID
		,DefaultChoice
	FROM T_TRN_Question WITH (NOLOCK)
	WHERE QuestionID IN (
			SELECT q.QuestionID
			FROM #questionIDs q
			)
		AND PlantID = @PlantID
		AND IsDeleted = 0
END
GO

