/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [[USP_UpdateAuditAssessorsbyTagID]]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR UPDATING AUDIT ANSWERED QUESTIONS BY TAG ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_006					18-AUG-2023			ASHOK KUMAR R B 		INITIAL VERSION

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_UpdateAuditAnsweredQuestionsByTagID] 1,1,'RSB4COB'
*/
CREATE PROCEDURE [USP_UpdateAuditAssessorsbyTagID] @PlantID INT
	,@TagID INT
	,@CurrentUserNTID NVARCHAR(20)
	,@Assessor XML NULL  
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION TRNUPATEAUDITANSWER

		EXEC [USP_PlantIDValidation] @PlantID = @PlantID
			,@ID = 0
			,@Mode = 'AUDIT'
			,@CurrentUserNTID = @CurrentUserNTID

		DECLARE @ID INT
		DECLARE @Scope_Identity_Table_Trigger TABLE (id INT);--Scope identities for all inserted rows    
		update T_TRN_AuditAssessor set IsActive=0 where AuditID in (
		SELECT AuditID
		FROM T_TRN_Audit WITH(NOLOCK)
		WHERE TagID = @TagID
			AND PlantID = @PlantID
			And IsDeleted =0
			)
		SELECT AuditID AS ID
		INTO #T1
		FROM T_TRN_Audit WITH(NOLOCK)
		WHERE TagID = @TagID
			AND PlantID = @PlantID
			And IsDeleted =0


		DECLARE MY_CURSOR CURSOR FORWARD_ONLY
		FOR
		SELECT ID
		FROM #T1

		OPEN MY_CURSOR

		FETCH NEXT
		FROM MY_CURSOR
		INTO @ID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			--UPDATE T_LNK_Audit_AnsweredQuestions
			--SET IsAuditActive = 0 
			--WHERE AuditID = @ID  and CAST(ModifiedAt As Date) = CAST(GETDATE() As Date)
			
			INSERT INTO T_TRN_AuditAssessor (    
					   AuditID    
					   ,AssessorName    
					   ,IsMandatoryAssessor    
					   ,IsActive    
					   )    
					  OUTPUT inserted.AuditAssessorID  
					  INTO @Scope_Identity_Table_Trigger    
					  SELECT @ID AS AuditID    
					   ,Assessor.value('(AssessorName/text())[1]', 'nvarchar(50)') AS AssessorName    
					   ,Assessor.value( '(IsMandatoryAssessor/text())[1]', 'bit') AS IsMandatoryAssessor 
					   ,1 AS IsActive    
					  FROM @Assessor.nodes('/ArrayOfAssessor/Assessor') AS TEMPTABLE1(Assessor)

			FETCH NEXT
			FROM MY_CURSOR
			INTO @ID
		END

		CLOSE MY_CURSOR

		DEALLOCATE MY_CURSOR

		COMMIT TRANSACTION TRNUPATEAUDITANSWER
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNUPATEAUDITANSWER

		EXEC USP_LogError @PlantID
			,@CurrentUserNTID
	END CATCH
END
GO