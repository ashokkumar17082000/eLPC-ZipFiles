/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_AuditQuestionsByAuditID] 
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING AUDIT QUESTIONS BY AUDIT ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			Rajasekar S					PlantId,CurrentUserNTID added
ELPC_LH_002					02-DEC-2021			VENKATESH GOVINDARAJ		CHANGED QUESTION LOAD LOGIC
ELPC_LH_005					14-AUG-2022			ASHOK KUMAR R B      		CHANGED QUESTION LOAD LOGIC based on RandomQuesiton Order
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_AuditQuestionsByAuditID] 1,163,'FSM1COB'
*/
CREATE PROCEDURE [USP_AuditQuestionsByAuditID] @PlantID INT
	,@AuditID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	SET NOCOUNT ON;

	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = @AuditID
		,@Mode = 'AUDIT'
		,@CurrentUserNTID = @CurrentUserNTID

	DECLARE @TagID INT = 0
	DECLARE @ValueStreamID INT = 0

	SELECT TOP (1) @TagID = [TagID]
		,@ValueStreamID = [ValueStreamID]
	FROM T_TRN_Audit WITH (NOLOCK)
	WHERE AuditID = @AuditID
		AND PlantID = @PlantID;

	SELECT DISTINCT QuestionID
	INTO #questionIDs
	FROM [FN_GetNestedQuestionsByTagID](@TagID, @PlantID)

	--select * from #questionIDs
	SELECT @AuditID AS AuditID
		,Q.QuestionID
		,Q.QuestionDisplayID
		,Q.AnswerType_AnswerTypeID AS AnswerTypeID
		,NULL AS Answer
		,NULL AS IsAnswered
		,Q.IsAnswerRequired
		,NULL AS CreatedAt
		,NULL AS CreatedBy_NTID
		,NULL AS ModifiedAt
		,NULL AS ModifiedBy_NTID
		,Q.QuestionText
		,Q.QuestionHintText
		,Q.IsAnswerRequired
		,Q.IsDefaultAnswerRequired
		,Q.DefaultChoiceID
		,'' AS TagNameList
		,'' AS TagIDList
		,RQ.RandomQuestionOrder
		,ROW_NUMBER() OVER (
			ORDER BY AQ.QuestionID
			) AS ID
	FROM #questionIDs AQ WITH (NOLOCK)
	INNER JOIN T_TRN_Question Q WITH (NOLOCK) ON AQ.QuestionID = Q.QuestionID
	INNER JOIN T_TRN_Audit A WITH (NOLOCK) ON A.AuditID = @AuditID
	LEFT JOIN T_LNK_Tag_AssignedQuestionsTags RQ WITH (NOLOCK) ON RQ.QuestionID = AQ.QuestionID
		AND RQ.TagID = @tagid and RQ.IsDeleted=0
	WHERE A.PlantID = @PlantID
		AND Q.PlantID = @PlantID
		AND Q.IsDeleted = 0
	AND Q.QuestionID IN (
		(
			SELECT q.QuestionID
			FROM #questionIDs q
			INNER JOIN (
				SELECT DISTINCT (QuestionID)
				FROM T_LNK_AssignedValueStreams WITH (NOLOCK)
				WHERE IsDeleted = 0
					AND ValueStreamID = @ValueStreamID 
				) AS vs ON vs.QuestionID = q.QuestionID
			)
		)
	ORDER BY  case when RQ.RandomQuestionOrder  is null then 998  end, RQ.RandomQuestionOrder
,Question_PriorityID 
	,TargetFrequencyTypeID
	,ChoiceDisplayTypeID DESC
	,QuestionID
END
GO