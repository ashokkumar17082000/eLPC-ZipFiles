/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_GetFullQuestionDetailsByID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING GET FULL QUESTION DETAILS BY ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			VENKATESH GOVINDARAJ		PlantID & Code Cleanup
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_GetFullQuestionDetailsByID] 1, 1
*/
CREATE PROCEDURE [USP_GetFullQuestionDetailsByID] @QuestionID AS INT
	,@PlantID AS INT
AS
BEGIN
	SET NOCOUNT ON;

	SELECT QuestionID
		,PlantID
		,QuestionDisplayID
		,QuestionText
		,QuestionHintText
		,AnswerType_AnswerTypeID
		,ChoiceDisplayTypeID
		,IsFilledInChoiceAllowed
		,IsUniqueAnswerRequired
		,IsAnswerRequired
		,DefaultChoiceID
		,IsQuestionAlwaysActive
		,ActiveDateRangeFrom
		,ActiveDateRangeTo
		,IsTargetFrequencyDefined
		,TargetFrequencyTypeID
		,TargetFrequencyValue
		,Question_PriorityID
		,IsLocked
		--,Assigned_ValueStreamTemplateID
		--,Assigned_ValueStreamCategoryID
		--,Assigned_AssessorTemplateID
		,IsDeleted
		,CreatedAt
		,ModifiedAt
		,IsDefaultAnswerRequired
		,Assigned_AssessorID
		,IsAnswered
		,CreatedBy_NTID
		,ModifiedBy_NTID
		,DefaultChoice
	FROM T_TRN_Question Q WITH (NOLOCK)
	WHERE Q.QuestionID = @QuestionID
		AND Q.IsDeleted = 0
		AND Q.PlantID = @PlantID
END
GO

