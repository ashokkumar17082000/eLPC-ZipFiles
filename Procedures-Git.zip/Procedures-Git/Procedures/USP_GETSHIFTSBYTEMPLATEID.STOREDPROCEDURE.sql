/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_GetShiftsByTemplateID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING SHIFTS BY TEMPLATEID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					19-MAR-2021			RAJASEKAR S					Plantid included
ELPC_LH_002					26-MAR-2021			Rajasekar S					@CurrentUserNTID,PlantIDValidation added
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_GetShiftsByTemplateID] 1,1
*/
CREATE PROCEDURE [USP_GetShiftsByTemplateID] @PlantID INT
	,@ValueStreamTemplateID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = @ValueStreamTemplateID
		,@Mode = 'VALUESTREAMTEMPLATE'
		,@CurrentUserNTID = @CurrentUserNTID

	SET NOCOUNT ON;

	SELECT VSF.ShiftID
		,VSF.ShiftName
		,VSF.FromTime
		,VSF.ToTime
		,VSF.RowID
		,VSF.IsMonday
		,VSF.IsTuesDay
		,VSF.IsWednesday
		,VSF.IsThursday
		,VSF.IsFriday
		,VSF.IsSaturday
		,VSF.IsSunday
		,VSF.DisplayName
		,VSF.ValueStreamTemplateID
	FROM T_LNK_ValueStream_Shift VSF WITH (NOLOCK)
	INNER JOIN T_TRN_ValueStreamTemplate VST WITH (NOLOCK) ON VST.ValueStreamTemplateID = VSF.ValueStreamTemplateID
	WHERE VSF.ValueStreamTemplateID = @ValueStreamTemplateID
		AND (
			VST.PlantID = @PlantID
			AND VSF.IsDeleted = 0
			)
END
GO


