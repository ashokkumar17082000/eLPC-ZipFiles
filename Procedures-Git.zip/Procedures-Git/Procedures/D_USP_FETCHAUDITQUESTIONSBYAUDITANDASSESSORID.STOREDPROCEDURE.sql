/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchAuditQuestionsByAuditAndAssessorID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE TO FETCH AUDIT QUESTIONS BY AUDIT AND ASSESSOR ID 
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_FetchAuditQuestionsByAuditAndAssessorID] 'OSP4KOR',3
*/
CREATE PROCEDURE [USP_FetchAuditQuestionsByAuditAndAssessorID] @NTID NVARCHAR(20)
	,@AuditID INT
AS
BEGIN
	SELECT DISTINCT (AuditTemplateID)
		,(
			SELECT TOP 1 UserName
			FROM T_MST_User
			WHERE NTID = AQ.ModifiedBy_NTID
			) AS ModifiedBy
		,CreatedAt
		,NULL AS ValueStreamName
		,AuditID
	FROM T_LNK_Audit_AnsweredQuestions AQ
	WHERE AuditID = @AuditID
		AND (
			IsAuditCompleted = 0
			OR IsAuditCompleted IS NULL
			)
END

SELECT *
FROM T_LNK_Audit_AnsweredQuestions

SELECT *
FROM T_TRN_Audit
GO


