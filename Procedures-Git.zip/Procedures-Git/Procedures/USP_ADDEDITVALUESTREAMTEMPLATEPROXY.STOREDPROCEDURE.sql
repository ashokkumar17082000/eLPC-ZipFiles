/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_AddEditValueStreamTemplateProxy]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE TO ADD AND EDIT VALUESTREAM TEMPLATE PROXY
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					18-MAR-2021			RAJASEKAR S					Trigger login , plantid included
ELPC_LH_002					25-MAR-2021			RAJASEKAR S					CurrentUserNTID related changes
ELPC_LH_002					26-MAR-2021			RAJASEKAR S					Trigger logic removal
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_AddEditValueStreamTemplateProxy]
*/
CREATE PROCEDURE [USP_AddEditValueStreamTemplateProxy] @ID INT
	,@PlantID INT
	,@ValueStreamTemplateID INT
	,@Proxies XML NULL
	,@IsLocked BIT NULL
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = @ValueStreamTemplateID
		,@Mode = 'VALUESTREAMTEMPLATE'
		,@CurrentUserNTID = @CurrentUserNTID

	----Inputs filed variable for triggers
	--DECLARE @Input_Ids_Trigger varchar(MAX);
	--DECLARE @TableName_Trigger varchar(100);
	--DECLARE @ActionType varchar(10);
	BEGIN TRY
		BEGIN TRANSACTION TRNADDEDITVSPROXY

		IF (@IsLocked = 1)
		BEGIN
			SELECT @ID AS ID
				,@ValueStreamTemplateID AS ValueStreamTemplateID
				,@CurrentUserNTID AS ModifiedBy_NTID
				,@CurrentUserNTID AS CreatedBy_NTID
				,Proxie.value('(NTID/text())[1]', 'NVARCHAR(20)') AS Proxy
			INTO #T1
			FROM @Proxies.nodes('/ArrayOfUser/User') AS TEMPTABLE(Proxie)
			WHERE (
					@ID IS NOT NULL
					AND @ID != 0
					)

			UPDATE T_LNK_ValueStream_Proxy
			SET IsDeleted = 1
			WHERE ID NOT IN (
					SELECT ID
					FROM #T1
					)
				AND ValueStreamTemplateID = @ValueStreamTemplateID

			UPDATE T_TRN_ValueStreamTemplate
			SET IsLocked = 1
			WHERE ValueStreamTemplateID = @ValueStreamTemplateID
				AND PlantID = @PlantID

			--select @TableName_Trigger='ValueStreamTemplate',
			--@ActionType='U',
			--@Input_Ids_Trigger=@ValueStreamTemplateID;
			--Exec [USP_VALUESTREAM_HISTORY] 
			--	@PlantID=@PlantID
			--	,@CurrentUserNTID=@CurrentUserNTID
			--	,@TableName= @TableName_Trigger
			--	,@ValueStreamTemplateHistoryID=NULL 
			--	,@ActionType=@ActionType
			--	,@INPUT_IDS=@Input_Ids_Trigger;
			---
			INSERT INTO T_LNK_ValueStream_Proxy (
				ValueStreamTemplateID
				,ModifiedBy_NTID
				,CreatedBy_NTID
				,Proxy
				)
			SELECT @ValueStreamTemplateID AS ValueStreamTemplateID
				,@CurrentUserNTID AS ModifiedBy_NTID
				,@CurrentUserNTID AS CreatedBy_NTID
				,Proxie.value('(NTID/text())[1]', 'NVARCHAR(20)') AS Proxy
			FROM @Proxies.nodes('/ArrayOfUser/User') AS TEMPTABLE(Proxie)
			WHERE (
					@ID IS NULL
					OR @ID = 0
					)

			EXEC USP_AddEditusers @PlantID
				,@CurrentUserNTID
				,@Proxies
		END
		ELSE
		BEGIN
			UPDATE T_TRN_ValueStreamTemplate
			SET IsLocked = 0
			WHERE ValueStreamTemplateID = @ValueStreamTemplateID
				AND PlantID = @plantID
				--select @TableName_Trigger='ValueStreamTemplate',
				--@ActionType='U',
				--@Input_Ids_Trigger=@ValueStreamTemplateID;
				--Exec [USP_VALUESTREAM_HISTORY] 
				--	@PlantID=@plantID
				--	,@CurrentUserNTID=@CurrentUserNTID
				--	,@TableName= @TableName_Trigger
				--	,@ValueStreamTemplateHistoryID=NULL 
				--	,@ActionType=@ActionType
				--	,@INPUT_IDS=@Input_Ids_Trigger;
		END

		COMMIT TRANSACTION TRNADDEDITVSPROXY
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNADDEDITVSPROXY

		EXEC USP_LogError @PlantID
			,@CurrentUserNTID
	END CATCH
END
GO


