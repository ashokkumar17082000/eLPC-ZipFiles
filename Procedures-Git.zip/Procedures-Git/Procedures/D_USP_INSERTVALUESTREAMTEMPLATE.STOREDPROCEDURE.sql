SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [USP_InsertValueStreamTemplate] @ValueStreamTemplateName VARCHAR(50)
	,@IsLocked BIT
	,@ModifiedAt DATETIME
	,@ModifiedBy_UserID INT
	,@CreatedAt DATETIME
	,@CreatedBy_UserID INT
	,@Delimiter CHAR
	,@IsOperatedInShifts BIT
	,@VisualizationViewModeID INT
	,@ValueStreamCategories XML NULL
	,@ValueStreams XML NULL
AS
BEGIN
	--set @ValueStreamTemplateName='Buildings'
	SET @IsLocked = 1
	SET @ModifiedAt = (SELECT * from fnGetDateTime());
	SET @ModifiedBy_UserID = 1;
	SET @CreatedAt = (SELECT * from fnGetDateTime());
	SET @CreatedBy_UserID = 1;

	--set @Delimiter='*';
	--set @IsOperatedInShifts=1;
	--set @VisualizationViewModeID=1;
	BEGIN TRY
		DECLARE @ValueStreamTemplateID INT;

		INSERT INTO [T_TRN_ValueStreamTemplate] (
			ValueStreamTemplateName
			,IsLocked
			,ModifiedAt
			,ModifiedBy_UserID
			,CreatedAt
			,CreatedBy_UserID
			,Delimiter
			,IsOperatedInShifts
			,VisualizationViewModeID
			)
		VALUES (
			@ValueStreamTemplateName
			,@IsLocked
			,@ModifiedAt
			,@ModifiedBy_UserID
			,@CreatedAt
			,@CreatedBy_UserID
			,@Delimiter
			,@IsOperatedInShifts
			,@VisualizationViewModeID
			)

		SET @ValueStreamTemplateID = SCOPE_IDENTITY()

		PRINT @ValueStreamTemplateID

		INSERT INTO T_TRN_ValueStreamCategory (
			ValueStreamTemplateID
			,ValueStreamCategoryName
			,IsDataRequired
			,TypeOfInput_InputTypeID
			,IsDataRequiredToFitSpecLength
			,MinimumNoOfCharacters
			,MaximumNoOfCharacters
			)
		--INSERT INTO T_TRN_ValueStreamCategory(ValueStreamTemplateID,ValueStreamCategoryName)
		SELECT SCOPE_IDENTITY() AS ValueStreamTemplateID
			,--ATTRIBUTE
			Category.value('(ValueStreamCategoryName)[1]', 'VARCHAR(100)') AS ValueStreamCategoryName
			,Category.value('(IsDataRequired/text())[1]', 'bit') AS IsDataRequired
			,Category.value('(TypeOfInput_InputTypeID/text())[1]', 'VARCHAR(100)') AS TypeOfInput_InputTypeID
			,Category.value('(IsDataRequiredToFitSpecLength/text())[1]', 'bit') AS IsDataRequiredToFitSpecLength
			,Category.value('(MinimumNoOfCharacters/text())[1]', 'INT') AS MinimumNoOfCharacters
			,Category.value('(MaximumNoOfCharacters/text())[1]', 'INT') AS MaximumNoOfCharacters
		FROM @ValueStreamCategories.nodes('/ArrayOfValueStreamCategory/ValueStreamCategory') AS TEMPTABLE(Category)

		SELECT @ValueStreamTemplateID AS ValueStreamTemplateID
			,--ATTRIBUTE
			ValueStream.value('(ValueStreamCategoryName)[1]', 'VARCHAR(100)') AS ValueStreamCategoryName
			,ValueStream.value('(ValueStreamData)[1]', 'VARCHAR(100)') AS ValueStreamName
			,NULL AS ValueStreamCategoryID
		INTO #T3
		FROM @ValueStreams.nodes('/ArrayOfValueStream/ValueStream') AS TEMPTABLE(ValueStream)

		UPDATE #T3
		SET ValueStreamCategoryID = (
				SELECT ValueStreamCategoryID
				FROM T_TRN_ValueStreamCategory t1
				WHERE #T3.ValueStreamCategoryName = t1.ValueStreamCategoryName
					AND t1.ValueStreamTemplateID = @ValueStreamTemplateID
				)

		INSERT INTO T_TRN_ValueStream (
			ValueStreamCategoryID
			,ValueStreamTemplateID
			,ValueStreamData
			)
		SELECT ValueStreamCategoryID
			,ValueStreamTemplateID
			,ValueStreamName
		FROM #T3
	END TRY

	BEGIN CATCH
		SELECT ERROR_NUMBER() AS ErrorNumber
			,ERROR_SEVERITY() AS ErrorSeverity
			,ERROR_STATE() AS ErrorState
			,ERROR_PROCEDURE() AS ErrorProcedure
			,ERROR_LINE() AS ErrorLine
			,ERROR_MESSAGE() AS ErrorMessage;
	END CATCH
END
GO


