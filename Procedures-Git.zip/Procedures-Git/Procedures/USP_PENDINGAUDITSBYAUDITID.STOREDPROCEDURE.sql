/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_PendingAuditsByAuditID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR PENDING AUDITS BY AUDIT ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			Rajasekar S					PlantId,CurrentUserNTID added
ELPC_LH_005					15-MAR-2023	        Snehitha Kannaboyina        Added new logic for getting ValueStream details
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_PendingAuditsByAuditID] 1,2,'ZNN1KOR'
*/
CREATE PROCEDURE [USP_PendingAuditsByAuditID] @PlantID INT
	,@AuditID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	SET NOCOUNT ON;

	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = @AuditID
		,@Mode = 'AUDIT'
		,@CurrentUserNTID = @CurrentUserNTID

	DECLARE @ValueStreamID INT
		,@ValueStreamName NVARCHAR(max);

	SET @ValueStreamID = (
			SELECT TOP 1 ValueStreamID
			FROM T_trn_Audit WITH (NOLOCK)
			WHERE AuditID = @AuditID
				AND PlantID = @PlantID
			)
	SET @ValueStreamName = (
			SELECT TOP 1 ValueStreamName
			FROM T_TRN_ValueStream WITH (NOLOCK)
			WHERE ValueStreamID = @ValueStreamID
			)

	SELECT DISTINCT (AQ.AuditTemplateID)
		,(
			SELECT TOP 1 UserName
			FROM T_MST_User WITH (NOLOCK)
			WHERE NTID = AQ.ModifiedBy_NTID
				AND PlantID = @PlantID
			) AS ModifiedBy
		,AQ.CreatedAt
		,(
			CASE 
				WHEN AQ.ValueStreamID IS NULL
					THEN @ValueStreamName
				ELSE vs.ValueStreamName
				END
			) AS ValueStreamName
		--,vs.valuestreamname  as ValueStreamName
		--,vs.ValueStreamID as ValueStreamID
		,(
			CASE 
				WHEN AQ.ValueStreamID IS NULL
					THEN A.ValueStreamID
				ELSE vs.ValueStreamID
				END
			) AS ValueStreamID
		,AQ.AuditID
	FROM T_LNK_Audit_AnsweredQuestions AQ WITH (NOLOCK)
	INNER JOIN T_TRN_Audit A WITH (NOLOCK) ON A.AuditID = AQ.AuditID
	LEFT JOIN (
		SELECT *
		FROM (
			SELECT ROW_NUMBER() OVER (
					PARTITION BY ValueStreamID ORDER BY ID
					) AS rowno
				,valuestreamid
			FROM T_LNK_Audit_AnsweredQuestions WITH (NOLOCK)
			WHERE AuditID = @AuditID
			) AS S
		WHERE S.rowno = 1
		) AS T ON T.valuestreamid = AQ.valuestreamid
		OR AQ.valuestreamid IS NULL
	LEFT JOIN T_TRN_ValueStream vs ON T.valuestreamid = vs.valuestreamid
	WHERE AQ.AuditID = @AuditID
		AND A.PlantID = @PlantID
		AND (
			AQ.IsAuditCompleted = 0
			OR AQ.IsAuditCompleted IS NULL
			)
		AND AQ.IsAuditActive = 1
END
GO