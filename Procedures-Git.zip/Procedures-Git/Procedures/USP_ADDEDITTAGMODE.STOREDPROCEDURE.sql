/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_AddEditTagMode]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR ADDING/EDITING TAG MODE
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					25-MAR-2021			KARTHIKEYAN KANDASAMY		PLANTID ADDED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_AddEditTagMode] 1,1,'2021-03-25 13:00',0,<<>>,<<>>,1,'kkn4cob'
*/
CREATE PROCEDURE [USP_AddEditTagMode] (
	@PlantID INT
	,@TagModeID INT NULL
	,@CreatedAt DATETIME NULL
	,@IsDeleted BIT NULL
	,@AssignedTags XML NULL
	,@AssignedQuestions XML NULL
	,@IsCompleted BIT NULL
	,@CurrentUserNTID NVARCHAR(20)
	)
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION TRNADDEDITTAGMODE

		DECLARE @TagID INT;

		SET @CreatedAt = (
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				);
		SET @IsCompleted = 0;
		SET @IsDeleted = 0;

		DECLARE @min INT = 0
			,@max INT = 0

		SET @TagModeID = (
				SELECT TagModeID
				FROM [T_TRN_TagMode] WITH(NOLOCK)
				WHERE CreatedBy_NTID = @CurrentUserNTID
					AND PlantID = @PlantID
				);

		IF (
				(
					@TagModeID IS NULL
					OR @TagModeID = 0
					)
				AND NOT EXISTS (
					SELECT TOP 1 1
					FROM [T_TRN_TagMode] WITH(NOLOCK)
					WHERE TagModeID = @TagModeID
						AND PlantID = @PlantID
					)
				)
		BEGIN
			INSERT INTO [T_TRN_TagMode] (
				PlantID
				,CreatedAt
				,IsCompleted
				,CreatedBy_NTID
				)
			VALUES (
				@PlantID
				,@CreatedAt
				,@IsCompleted
				,@CurrentUserNTID
				);

			SET @TagModeID = SCOPE_IDENTITY();

			INSERT INTO [T_LNK_TagMode_Tags] (
				TagModeID
				,TagID
				)
			SELECT @TagModeID AS TagModeID
				,Tag.value('(TagID/text())[1]', 'int') AS TagID
			FROM @AssignedTags.nodes('/ArrayOfTag/Tag') AS TEMPTABLE(Tag);

			INSERT INTO [T_LNK_TagMode_Tags] (
				TagModeID
				,QuestionID
				)
			SELECT @TagModeID AS TagModeID
				,Question.value('(QuestionID/text())[1]', 'int') AS QuestionID
			FROM @AssignedQuestions.nodes('/ArrayOfQuestion/Question') AS TEMPTABLE(Question);

			--Inserting into the [T_LNK_Custom_Questions] table when CustomModeID is zero*
			EXEC USP_AddQuestionsByTagModeID @PlantID
				,@TagModeID
				,@CurrentUserNTID;
		END
		ELSE IF (
				EXISTS (
					SELECT TOP 1 1
					FROM [T_TRN_TagMode] WITH(NOLOCK)
					WHERE TagModeID = @TagModeID
						AND PlantID = @PlantID
					)
				)
		BEGIN
			SELECT @TagModeID AS TagModeID
				,Tag.value('(TagID/text())[1]', 'int') AS TagID
				,Tag.value('(TagModeTagsID/text())[1]', 'int') AS TagModeTagsID
			INTO #T1
			FROM @AssignedTags.nodes('/ArrayOfTag/Tag') AS TEMPTABLE(Tag);

			DELETE
			FROM T_LNK_TagMode_Questions
			WHERE TagModeID = @TagModeID;

			SELECT TOP 1 @TagModeID = TagModeID
				,@TagID = TagID
			FROM #T1

			UPDATE [T_LNK_TagMode_Tags]
			SET TagID = @TagID
			WHERE TagModeID = @TagModeID;

			--Inserting into the [T_LNK_Custom_Questions] table when CustomModeID is zero
			EXEC USP_AddQuestionsByTagModeID @PlantID
				,@TagModeID
				,@CurrentUserNTID;
		END

		COMMIT TRANSACTION TRNADDEDITTAGMODE;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNADDEDITTAGMODE;

		EXEC [USP_LogError] @PlantID
			,@CurrentUserNTID;
	END CATCH
END
GO


