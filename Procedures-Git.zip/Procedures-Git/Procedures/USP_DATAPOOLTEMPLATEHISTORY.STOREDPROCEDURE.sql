/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_DataPoolTemplateHistory] 
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING DATA POOL TEMPLATE HISTORY
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					25-MAR-2021			SIKHESH S					ADDITIONAL INPUT PARAMATERS INCLUDED, OUTPUT PARAMETERS REVISED, STANDARD RULES APPLIED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_DataPoolTemplateHistory]  1, 1
*/
CREATE PROCEDURE [USP_DataPoolTemplateHistory] (
	@DataPoolID INT
	,@PlantID INT
	,@CurrentUserNTID NVARCHAR(20) = NULL
	)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT DH.DataPoolHistoryID
		,DH.DataPoolHistoryDisplayID
		,DH.DataPoolID
		,DH.DataPoolDisplayID
		,DH.ModifiedBy_NTID
		,(TU.UserName) AS ModifiedBy
		,DH.ModifiedAt
		,DH.CreatedAt
	FROM [T_TRN_DataPoolHistory] DH WITH (NOLOCK)
	INNER JOIN T_MST_User TU WITH (NOLOCK) ON DH.ModifiedBy_NTID = TU.NTID
		AND TU.PlantID = @PlantID
	WHERE DH.DataPoolID = @DataPoolID
		AND DH.PlantID = @PlantID
	ORDER BY DH.DataPoolHistoryDisplayID DESC
END
GO


