/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_QuestionsByTagID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING QUESTIONS BY TAGID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					22-MAR-2021			KARTHIKEYAN KANDASAMY		PLANTID ADDED
ELPC_LH_005					16-AUG-2022			ASHOK KUMAR R B 			Returm Questin based on RandomQuestion Order 

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_QuestionsByTagID] 1, 1
*/
CREATE PROCEDURE [USP_QuestionsByTagID] (
	@PlantID INT
	,@TagID INT
	)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT DISTINCT LNK.TagID
		,(
			SELECT TOP 1 QuestionText
			FROM T_TRN_Question Q WITH (NOLOCK)
			WHERE Q.QuestionID = LNK.QuestionID
				AND Q.PlantID = @PlantID
			) AS QuestionText
		,LNK.QuestionID
		,LNK.RandomQuestionOrder
		,LNK.QuestionType
		,Q.QuestionDisplayID
	FROM T_LNK_Tag_AssignedQuestionsTags LNK WITH (NOLOCK)
	INNER JOIN T_TRN_Tag T WITH (NOLOCK) ON LNK.TagID = T.TagID
		AND T.PlantID = @PlantID
	INNER JOIN T_TRN_Question Q WITH (NOLOCK) ON LNK.QuestionID = Q.QuestionID
		AND Q.PlantID = @PlantID
	WHERE (
			LNK.TagID = @TagID
			AND LNK.QuestionID IS NOT NULL
			AND LNK.IsDeleted = 0
			)
	
	UNION
	
	SELECT DISTINCT LNK.TagID
		,(
			SELECT TOP 1 QuestionText
			FROM T_TRN_Question Q WITH (NOLOCK)
			WHERE Q.QuestionID = LNK.QuestionID
				AND Q.PlantID = @PlantID
			) AS QuestionText
		,LNK.QuestionID
		,1001
		,0
		,Q.QuestionDisplayID
	FROM T_LNK_QN_AssignedTags LNK WITH (NOLOCK)
	INNER JOIN T_TRN_Tag T WITH (NOLOCK) ON LNK.TagID = T.TagID
		AND T.PlantID = @PlantID
	INNER JOIN T_TRN_Question Q WITH (NOLOCK) ON LNK.QuestionID = Q.QuestionID
		AND Q.PlantID = @PlantID
	WHERE (
			LNK.TagID = @TagID
			AND LNK.QuestionID IS NOT NULL
			AND LNK.IsDeleted = 0
			)
	ORDER BY RandomQuestionOrder
END
GO