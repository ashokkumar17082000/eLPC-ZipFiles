/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_GetTagModeByNTID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE TO GET TAG MODE BY NTID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					25-MAR-2021			KARTHIKEYAN KANDASAMY		PLANTID ADDED
ELPC_LH_006					18-AUG-2023			ASHOK KUMAR R B 		global Tag Additional Columns
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_GetTagModeByNTID] 1, 'OSP4KOR'
*/
CREATE PROCEDURE [USP_GetTagModeByNTID] (    
 @PlantID INT    
 ,@CurrentUserNTID NVARCHAR(20)    
 )    
AS    
BEGIN    
 SET NOCOUNT ON;    
    
 SELECT TT.TagID    
  ,TT.TagDisplayID    
  ,TT.TagName    
  ,TT.TagID
  ,TT.IsMandatoryAssessorsDefined
  ,TT.IsQuestionOverviewDefined
  ,TT.IsReportingEmailDefined
  ,TT.IsResultOverviewDefined
  ,TT.IsResumeTagDefined
  ,TT.IsProgressPercentageDefined
  ,TT.IsSkipQuestionDefined
  ,TT.TagTypeID

  ,CASE     
   WHEN TT.TagTypeID = 1    
    THEN COALESCE('#' + TT.TagName, '')    
   WHEN TT.TagTypeID = 2    
    THEN COALESCE('#' + TT.TagName, '')    
   WHEN TT.TagTypeID = 3    
    THEN COALESCE('#' + TT.TagName, '')  
 WHEN TT.TagTypeID = 4    
    THEN COALESCE('#' + TT.TagName, '')  
   END AS TagDisplayName    
  ,CQ.TagModeTagsID    
  ,TC.CreatedBy_NTID    
 FROM [T_TRN_Tag] TT WITH (NOLOCK)    
 INNER JOIN [T_LNK_TagMode_Tags] CQ WITH (NOLOCK) ON CQ.TagID = TT.TagID    
 INNER JOIN [T_TRN_TagMode] TC WITH (NOLOCK) ON TC.TagModeID = CQ.TagModeID    
  AND TC.PlantID = @PlantID    
 WHERE TT.PlantID = @PlantID    
  AND CQ.TagID IS NOT NULL    
  AND TC.CreatedBy_NTID = @CurrentUserNTID    
  AND CQ.IsDeleted <> 1    
 ORDER BY CQ.TagModeTagsID;    
    
 SELECT TQ.QuestionID    
  ,TQ.QuestionDisplayID    
  ,TQ.QuestionText    
  ,CQ.TagModeTagsID    
  ,TC.CreatedBy_NTID    
 FROM T_TRN_Question TQ WITH (NOLOCK)    
 INNER JOIN [T_LNK_TagMode_Tags] CQ WITH (NOLOCK) ON CQ.QuestionID = TQ.QuestionID    
 INNER JOIN [T_TRN_TagMode] TC WITH (NOLOCK) ON TC.TagModeID = CQ.TagModeID    
  AND TC.PlantID = @PlantID    
 WHERE TQ.PlantID = @PlantID    
  AND CQ.QuestionID IS NOT NULL    
  AND TC.CreatedBy_NTID = @CurrentUserNTID    
  AND CQ.IsDeleted <> 1;    
END 
GO