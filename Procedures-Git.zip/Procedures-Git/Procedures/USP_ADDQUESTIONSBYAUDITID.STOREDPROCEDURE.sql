/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_AddQuestionsByAuditID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR ADDING QUESTIONS BY AUDIT ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			Rajasekar S					PlantId,CurrentUserNTID added
ELPC_LH_005					15-MAR-2023         Snehitha Kannaboyina        Added new condition
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_AddQuestionsByAuditID] 1,1243,null,'znn1kor'
*/
CREATE PROCEDURE [USP_AddQuestionsByAuditID] @PlantID INT  
 ,@AuditID INT  
 ,@Valuestream XML NULL  
 ,@CurrentUserNTID NVARCHAR(20) = NULL  
AS  
BEGIN  
 BEGIN TRY  
  BEGIN TRANSACTION ADDQUESTIONSBYAUDITID  
  
  EXEC [USP_PlantIDValidation] @PlantID = @PlantID  
   ,@ID = @AuditID  
   ,@Mode = 'AUDIT'  
   ,@CurrentUserNTID = @CurrentUserNTID  
  
  DELETE  
  FROM T_LNK_Audit_AssignedQuestions  
  WHERE AuditID = @AuditID --to remove the duplicate records while updating the audit  
  
  DECLARE @TagID INT = 0  
  DECLARE @ValueStreamID INT = 0  
  
  SELECT TOP (1) @TagID = [TagID]  
   ,@ValueStreamID = [ValueStreamID]  
  FROM T_TRN_Audit WITH (NOLOCK)  
  WHERE AuditID = @AuditID  
   AND PlantID = @PlantID;  
  
  --SET @TagID = (  
  --  SELECT TOP (1) TagID  
  --  FROM T_TRN_Audit  
  --  WHERE AuditID = @AuditID  
  --  );  
  SELECT DISTINCT QuestionID  
  INTO #questionIDs  
  FROM [FN_GetNestedQuestionsByTagID](@TagID, @PlantID)  
  
  --Fetch Suppress question not based on TagID  
  DECLARE @IsSingleQuestionSuppressed INT = 0  
  
  SET @IsSingleQuestionSuppressed = (  
    SELECT IsSingleQuestionSuppressed  
    FROM T_TRN_Tag WITH (NOLOCK)  
    WHERE TagID = @TagID  
     AND PlantID = @PlantID  
    )  
  
  SELECT *  
  INTO #TRNQ  
  FROM (  
   SELECT DISTINCT (QuestionID)  
   FROM T_TRN_Question WITH (NOLOCK)  
   WHERE PlantID = @PlantID  
    AND IsQuestionAlwaysActive = 1  
    OR (  
     @IsSingleQuestionSuppressed = 1  
     AND IsQuestionAlwaysActive = 0  
     AND (  
      (CAST(ActiveDateRangeFrom AS DATE) >= CAST(- 53690 AS DATETIME))  
      AND (CAST(ActiveDateRangeTo AS DATE) < = CAST('12/31/9999' AS DATE))  
      )  
     )  
    OR (  
     cast(@IsSingleQuestionSuppressed AS INT) <> 1  
     AND IsQuestionAlwaysActive = 0  
     AND (  
      (  
       CAST((  
         SELECT FormattedDateTime  
         FROM fnGetDateTime(@PlantID)  
         ) AS DATE) >= CAST(ActiveDateRangeFrom AS DATE)  
       )  
      AND (  
       CAST((  
         SELECT FormattedDateTime  
         FROM fnGetDateTime(@PlantID)  
         ) AS DATE) <= CAST(ActiveDateRangeTo AS DATE)  
       )  
      )  
     )  
   ) AS TRNQ  
  
  --Fetch Suppress question not based on TagID  
  INSERT INTO T_LNK_Audit_AssignedQuestions (  
   AuditID  
   ,QuestionID  
   ,AnswerTypeID  
   ,IsAnswerRequired  
   )  
  SELECT @AuditID  
   ,QuestionID  
   ,AnswerType_AnswerTypeID  
   ,IsAnswerRequired  
  FROM T_TRN_Question WITH (NOLOCK)  
  WHERE QuestionID IN (  
    (  
     SELECT q.QuestionID  
     FROM #questionIDs q  
     INNER JOIN (  
      SELECT DISTINCT (QuestionID)  
      FROM T_LNK_AssignedValueStreams WITH (NOLOCK)  
      WHERE IsDeleted = 0  
       AND ValueStreamID IN (  
        SELECT ValueStreamID  
        FROM T_LNK_Audit_ValueStreams  
        WHERE AuditID = @AuditID  
        )  
      ) AS vs ON vs.QuestionID = q.QuestionID  
     )  
    )  
   AND PlantID = @PlantID;  
  
   --drop table #questionIDs    --drop table #TRNQ  
  COMMIT TRANSACTION ADDQUESTIONSBYAUDITID;  
 END TRY  
  
 BEGIN CATCH  
  ROLLBACK TRANSACTION ADDQUESTIONSBYAUDITID;  
  
  EXEC USP_LogError @PlantID  
   ,@CurrentUserNTID  
 END CATCH  
END  
