SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [USP_FetchValueStreamsByTags] @TagIDs NVARCHAR(max)
AS
BEGIN
	SELECT *
	FROM T_LNK_AssignedValueStreams
	WHERE QuestionID IN (
			SELECT DISTINCT (QuestionID)
			FROM T_LNK_QN_AssignedTags
			WHERE TagID IN (
					SELECT DISTINCT (TagID)
					FROM T_LNK_Tag_AssignedQuestionsTags
					WHERE TagID IN (
							2
							,7
							,8
							,9
							)
					)
			)
END
GO


