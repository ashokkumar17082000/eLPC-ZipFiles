SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [USP_QuestionProxiesByQuestionID] @QuestionID INT
AS
BEGIN
	SELECT DISTINCT (UR.UserName)
		,QP.QuestionID
		,QP.Proxy
	FROM T_LNK_Question_Proxy QP
	INNER JOIN T_MST_User UR ON QP.Proxy = UR.NTID
	WHERE QuestionID = @QuestionID
END
GO


