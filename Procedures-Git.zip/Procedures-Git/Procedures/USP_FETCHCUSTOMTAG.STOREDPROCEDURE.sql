/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchCustomTag] 
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING CUSTOM TAG
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					28-MAR-2021			SIKHESH S					ADDITIONAL INPUT PARAMATERS INCLUDED, OUTPUT PARAMETERS REVISED, STANDARD RULES APPLIED
ELPC_LH_006					18-AUG-2023			SUSHANTH					GLOBAL TAG
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_FetchCustomTag]  1
*/
CREATE PROCEDURE [USP_FetchCustomTag] (      
 @PlantID INT      
 ,@CurrentUserNTID NVARCHAR(20) = NULL      
 )      
AS      
BEGIN      
 SET NOCOUNT ON;      
      
 SELECT (      
   SELECT TOP 1 UserName      
   FROM T_MST_User WITH (NOLOCK)      
   WHERE NTID = TT.ModifiedBy_NTID      
    AND PlantID = @PlantID      
   ) AS ModifiedBy      
  ,(      
   SELECT TOP 1 UserName      
   FROM T_MST_User WITH (NOLOCK)      
   WHERE NTID = TT.CreatedBy_NTID      
    AND PlantID = @PlantID      
   ) AS CreatedBy      
  ,CASE       
   WHEN TT.TagTypeID = 1      
    THEN COALESCE('#' + TT.TagName, '')      
   WHEN TT.TagTypeID = 2      
    THEN COALESCE('#' + TT.TagName, '')      
   WHEN TT.TagTypeID = 3      
    THEN COALESCE('#' + TT.TagName, '')      
 WHEN TT.TagTypeID = 4      
    THEN COALESCE('#' + TT.TagName, '')     
   END AS TagDisplayName      
  ,TT.TagID      
  ,TT.TagDisplayID      
  ,TT.TagName      
 FROM T_TRN_Tag TT WITH (NOLOCK)      
 WHERE TT.TagID IS NOT NULL      
  AND (      
   TT.IsDeleted = 0      
   OR TT.IsDeleted IS NULL      
   )      
  AND TT.TagTypeID IN (1, 2, 4)   
  AND TT.IsSearchableTag = 1  
  AND TT.PlantID = @PlantID      
 ORDER BY TT.TagTypeID      
  ,TT.TagName      
END 

GO