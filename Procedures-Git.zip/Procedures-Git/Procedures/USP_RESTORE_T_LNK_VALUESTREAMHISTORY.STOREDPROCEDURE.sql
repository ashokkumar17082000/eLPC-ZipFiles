/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_Restore_T_LNK_ValueStreamHistory]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RESTORING VALUE STREAM HISTORY
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					18-MAR-2021			RAJASEKAR s					PLANTID ADDED
ELPC_LH_002					18-MAR-2021			RAJASEKAR s					CurrentUserNTID ADDED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_Restore_T_LNK_ValueStreamHistory] 1
*/
CREATE PROCEDURE [USP_Restore_T_LNK_ValueStreamHistory] (
	@PlantID INT
	,@ValueStreamTemplateHistoryID INT
	,@CurrentUserNTID NVARCHAR(20)
	)
AS
BEGIN
	SET NOCOUNT ON;
	SET LOCK_TIMEOUT 5000;

	BEGIN TRANSACTION TRNRESTOREVSHISTORY;

	BEGIN TRY
		EXEC [USP_PlantIDValidation] @PlantID = @PlantID
			,@ID = @ValueStreamTemplateHistoryID
			,@Mode = 'VALUESTREAMTEMPLATEHISTORY'
			,@CurrentUserNTID = @CurrentUserNTID

		-- ALTER TABLE [T_TRN_ValueStreamTemplate] DISABLE TRIGGER [TR_HISTORYFOR_T_TRN_ValueStreamTemplate]

		-- ALTER TABLE [T_TRN_ValueStreamCategory] DISABLE TRIGGER [TR_HISTORYFOR_T_TRN_ValueStreamCategory]

		-- ALTER TABLE [T_TRN_ValueStream] DISABLE TRIGGER [TR_HISTORYFOR_T_TRN_ValueStream]

		-- ALTER TABLE [T_LNK_ValueStream_Shift] DISABLE TRIGGER [TR_HISTORYFOR_T_LNK_ValueStream_Shift]

		IF EXISTS (
				SELECT 1
				FROM T_HST_ValueStreamTemplateHistory WITH(NOLOCK)
				WHERE ValueStreamTemplateHistoryID = @ValueStreamTemplateHistoryID 
				)
		BEGIN
			-- Update [T_TRN_ValueStreamTemplate]
			DECLARE @ValueStreamTemplateID INT;
			DECLARE @ValueStreamTemplateName NVARCHAR(50);
			DECLARE @IsLocked BIT;
			DECLARE @ModifiedAt DATETIME;
			DECLARE @CreatedAt DATETIME;
			DECLARE @Delimiter NVARCHAR(5);
			DECLARE @IsOperatedInShifts BIT;
			DECLARE @VisualizationViewModeID INT;
			DECLARE @IsDeleted BIT;
			DECLARE @CreatedBy_NTID NVARCHAR(20);
			DECLARE @ValueStreamTemplateDisplayID INT = NULL;
			DECLARE @Plant_ID INT = NULL;
			DECLARE @Modified_At DATETIME = (
					SELECT FormattedDateTime
					FROM [fnGetDateTime](@PlantID)
					);

			SELECT TOP 1 @ValueStreamTemplateID = ValueStreamTemplateID
				,@ValueStreamTemplateName = ValueStreamTemplateName
				,@IsLocked = IsLocked
				,@ModifiedAt = ModifiedAt
				,@CreatedAt = CreatedAt
				,@Delimiter = Delimiter
				,@IsOperatedInShifts = IsOperatedInShifts
				,@VisualizationViewModeID = VisualizationViewModeID
				,@IsDeleted = IsDeleted
				,@CreatedBy_NTID = CreatedBy_NTID
				,@Plant_ID = PlantID
				,@ValueStreamTemplateDisplayID = ValueStreamTemplateDisplayID
			FROM T_HST_ValueStreamTemplateHistory WITH(NOLOCK)
			WHERE ValueStreamTemplateHistoryID = @ValueStreamTemplateHistoryID
				AND PlantID = @PlantID;

			UPDATE T_TRN_ValueStreamTemplate
			SET ValueStreamTemplateName = @ValueStreamTemplateName
				,IsLocked = @IsLocked
				,ModifiedAt = @ModifiedAt
				,CreatedAt = @CreatedAt
				,Delimiter = @Delimiter
				,IsOperatedInShifts = @IsOperatedInShifts
				,VisualizationViewModeID = @VisualizationViewModeID
				,IsDeleted = @IsDeleted
				,CreatedBy_NTID = @CreatedBy_NTID
				,ModifiedBy_NTID = @CurrentUserNTID
				,PlantID = @Plant_ID
				,@ValueStreamTemplateDisplayID = ValueStreamTemplateDisplayID
			WHERE ValueStreamTemplateID = @ValueStreamTemplateID
				AND PlantID = @PlantID;

			--END - Update [T_TRN_ValueStreamTemplate]
			-- Update [T_TRN_ValueStreamCategory]
			DECLARE @ValueStreamCategoryID INT;
			DECLARE @ValueStreamCategoryName NVARCHAR(50);
			DECLARE @IsDataRequired BIT;
			DECLARE @TypeOfInput_InputTypeID INT;
			DECLARE @IsDataRequiredToFitSpecLength BIT;
			DECLARE @MinimumNoOfCharacters INT;
			DECLARE @MaximumNoOfCharacters INT;
			DECLARE @NodeID INT;

			SET @IsDeleted = 0;

			DECLARE @IsColumnRequired BIT;
			DECLARE @InputType NVARCHAR(100);

			DECLARE CUR_ValueStreamCategory CURSOR FORWARD_ONLY
			FOR
			SELECT ValueStreamCategoryID
				,ValueStreamCategoryName
				,ValueStreamTemplateID
				,IsDataRequired
				,TypeOfInput_InputTypeID
				,IsDataRequiredToFitSpecLength
				,MinimumNoOfCharacters
				,MaximumNoOfCharacters
				,NodeID
				,IsColumnRequired
				,IsDeleted
				,InputType
			FROM T_TRN_ValueStreamCategoryHistory WITH(NOLOCK)
			WHERE ValueStreamTemplateHistoryID = @ValueStreamTemplateHistoryID;

			--to move the records into temp table
			SELECT ValueStreamCategoryID
				,ValueStreamCategoryName
				,ValueStreamTemplateID
				,IsDataRequired
				,TypeOfInput_InputTypeID
				,IsDataRequiredToFitSpecLength
				,MinimumNoOfCharacters
				,MaximumNoOfCharacters
				,NodeID
				,IsColumnRequired
				,IsDeleted
				,InputType
			INTO #C1
			FROM T_TRN_ValueStreamCategoryHistory WITH(NOLOCK)
			WHERE ValueStreamTemplateHistoryID = @ValueStreamTemplateHistoryID;

			--to soft delete the records based on history
			UPDATE T_TRN_ValueStreamCategory
			SET IsDeleted = 1
			WHERE ValueStreamCategoryID NOT IN (
					SELECT ValueStreamCategoryID
					FROM #C1
					)
				AND ValueStreamTemplateID = @ValueStreamTemplateID

			--
			OPEN CUR_ValueStreamCategory;

			FETCH NEXT
			FROM CUR_ValueStreamCategory
			INTO @ValueStreamCategoryID
				,@ValueStreamCategoryName
				,@ValueStreamTemplateID
				,@IsDataRequired
				,@TypeOfInput_InputTypeID
				,@IsDataRequiredToFitSpecLength
				,@MinimumNoOfCharacters
				,@MaximumNoOfCharacters
				,@NodeID
				,@IsColumnRequired
				,@IsDeleted
				,@InputType;

			WHILE @@FETCH_STATUS = 0
			BEGIN
				IF EXISTS (
						SELECT 1
						FROM T_TRN_ValueStreamCategory WITH(NOLOCK)
						WHERE ValueStreamCategoryID = @ValueStreamCategoryID
						)
				BEGIN
					-- Update the ValueStreamCategory data if that exists
					UPDATE T_TRN_ValueStreamCategory
					SET ValueStreamCategoryName = @ValueStreamCategoryName
						,ValueStreamTemplateID = @ValueStreamTemplateID
						,IsDataRequired = @IsDataRequired
						,TypeOfInput_InputTypeID = @TypeOfInput_InputTypeID
						,IsDataRequiredToFitSpecLength = @IsDataRequiredToFitSpecLength
						,MinimumNoOfCharacters = @MinimumNoOfCharacters
						,MaximumNoOfCharacters = @MaximumNoOfCharacters
						,NodeID = @NodeID
						,IsColumnRequired = @IsColumnRequired
						,IsDeleted = @IsDeleted
						,InputType = @InputType
						,ModifiedBy_NTID = @CurrentUserNTID
					WHERE ValueStreamCategoryID = @ValueStreamCategoryID;
				END
				ELSE
				BEGIN
					-- Insert the ValueStreamCategory data if that not exists(may be removed)
					INSERT INTO T_TRN_ValueStreamCategory (
						ValueStreamCategoryName
						,ValueStreamTemplateID
						,IsDataRequired
						,TypeOfInput_InputTypeID
						,IsDataRequiredToFitSpecLength
						,MinimumNoOfCharacters
						,MaximumNoOfCharacters
						,NodeID
						,IsColumnRequired
						,IsDeleted
						,InputType
						,ModifiedBy_NTID
						)
					VALUES (
						@ValueStreamCategoryName
						,@ValueStreamTemplateID
						,@IsDataRequired
						,@TypeOfInput_InputTypeID
						,@IsDataRequiredToFitSpecLength
						,@MinimumNoOfCharacters
						,@MaximumNoOfCharacters
						,@NodeID
						,@IsColumnRequired
						,@IsDeleted
						,@InputType
						,@CurrentUserNTID
						);
				END

				FETCH NEXT
				FROM CUR_ValueStreamCategory
				INTO @ValueStreamCategoryID
					,@ValueStreamCategoryName
					,@ValueStreamTemplateID
					,@IsDataRequired
					,@TypeOfInput_InputTypeID
					,@IsDataRequiredToFitSpecLength
					,@MinimumNoOfCharacters
					,@MaximumNoOfCharacters
					,@NodeID
					,@IsColumnRequired
					,@IsDeleted
					,@InputType;
			END

			CLOSE CUR_ValueStreamCategory;

			DEALLOCATE CUR_ValueStreamCategory;

			--END - Update [T_TRN_ValueStreamCategory]
			-- Update [T_TRN_ValueStream]
			DECLARE @ValueStreamID INT;
			DECLARE @Responsible_UserID NVARCHAR(50);

			SET @ValueStreamCategoryID = 0;

			DECLARE @ValueStreamData NVARCHAR(50);

			SET @NodeID = 0;
			SET @IsDeleted = 0;

			DECLARE @ResponsibleEmployee NVARCHAR(200);
			DECLARE @RowID INT;
			DECLARE @ValueStreamName NVARCHAR(max);

			DECLARE CUR_ValueStream CURSOR FORWARD_ONLY
			FOR
			SELECT ValueStreamID
				,Responsible_UserID
				,ValueStreamTemplateID
				,ValueStreamCategoryID
				,ValueStreamData
				,NodeID
				,IsDeleted
				,ResponsibleEmployee
				,RowID
				,ValueStreamName
			FROM T_TRN_ValueStreamHistory WITH(NOLOCK)
			WHERE ValueStreamTemplateHistoryID = @ValueStreamTemplateHistoryID;

			--to move the valuestream records into temp table
			SELECT ValueStreamID
				,Responsible_UserID
				,ValueStreamTemplateID
				,ValueStreamCategoryID
				,ValueStreamData
				,NodeID
				,IsDeleted
				,ResponsibleEmployee
				,RowID
				,ValueStreamName
			INTO #VS1
			FROM T_TRN_ValueStreamHistory WITH(NOLOCK)
			WHERE ValueStreamTemplateHistoryID = @ValueStreamTemplateHistoryID;

			--to soft delete the records in valuestream table
			UPDATE T_TRN_ValueStream
			SET IsDeleted = 1
				,ModifiedBy_NTID = @CurrentUserNTID
			WHERE ValueStreamID NOT IN (
					SELECT ValueStreamID
					FROM #VS1
					)
				AND ValueStreamTemplateID = @ValueStreamTemplateID

			------------------
			OPEN CUR_ValueStream;

			FETCH NEXT
			FROM CUR_ValueStream
			INTO @ValueStreamID
				,@Responsible_UserID
				,@ValueStreamTemplateID
				,@ValueStreamCategoryID
				,@ValueStreamData
				,@NodeID
				,@IsDeleted
				,@ResponsibleEmployee
				,@RowID
				,@ValueStreamName;

			WHILE @@FETCH_STATUS = 0
			BEGIN
				IF EXISTS (
						SELECT 1
						FROM T_TRN_ValueStream WITH(NOLOCK)
						WHERE ValueStreamID = @ValueStreamID
						)
				BEGIN
					-- Update the ValueStream data if that exists
					UPDATE T_TRN_ValueStream
					SET Responsible_UserID = @Responsible_UserID
						,ValueStreamTemplateID = @ValueStreamTemplateID
						,ValueStreamCategoryID = @ValueStreamCategoryID
						,ValueStreamData = @ValueStreamData
						,NodeID = @NodeID
						,IsDeleted = @IsDeleted
						,ResponsibleEmployee = @ResponsibleEmployee
						,RowID = @RowID
						,ValueStreamName = @ValueStreamName
						,ModifiedBy_NTID = @CurrentUserNTID
					WHERE ValueStreamID = @ValueStreamID;
				END
				ELSE
				BEGIN
					-- Insert the ValueStream data if that not exists(may be removed)
					INSERT INTO T_TRN_ValueStream (
						Responsible_UserID
						,ValueStreamTemplateID
						,ValueStreamCategoryID
						,ValueStreamData
						,NodeID
						,IsDeleted
						,ResponsibleEmployee
						,RowID
						,ValueStreamName
						,CreatedBy_NTID
						,ModifiedBy_NTID
						)
					VALUES (
						@Responsible_UserID
						,@ValueStreamTemplateID
						,@ValueStreamCategoryID
						,@ValueStreamData
						,@NodeID
						,@IsDeleted
						,@ResponsibleEmployee
						,@RowID
						,@ValueStreamName
						,@CurrentUserNTID
						,@CurrentUserNTID
						);
				END

				FETCH NEXT
				FROM CUR_ValueStream
				INTO @ValueStreamID
					,@Responsible_UserID
					,@ValueStreamTemplateID
					,@ValueStreamCategoryID
					,@ValueStreamData
					,@NodeID
					,@IsDeleted
					,@ResponsibleEmployee
					,@RowID
					,@ValueStreamName;
			END

			CLOSE CUR_ValueStream;

			DEALLOCATE CUR_ValueStream;

			--END - Update [T_TRN_ValueStream]
			-- Update [T_LNK_ValueStream_Shift]
			DECLARE @ShiftID INT;
			DECLARE @ShiftName NVARCHAR(50);

			SET @RowID = 0;

			DECLARE @FromTime DATETIME;
			DECLARE @ToTime DATETIME;
			DECLARE @IsMonday BIT;
			DECLARE @IsTuesDay BIT;
			DECLARE @IsWednesday BIT;
			DECLARE @IsThursday BIT;
			DECLARE @IsFriday BIT;
			DECLARE @IsSaturday BIT;
			DECLARE @IsSunday BIT;
			DECLARE @DisplayName NVARCHAR(200);

			SET @IsDeleted = 0;

			DECLARE CUR_ValueStream_Shift CURSOR FORWARD_ONLY
			FOR
			SELECT ShiftID
				,ShiftName
				,RowID
				,ValueStreamTemplateID
				,FromTime
				,ToTime
				,IsMonday
				,IsTuesDay
				,IsWednesday
				,IsThursday
				,IsFriday
				,IsSaturday
				,IsSunday
				,DisplayName
				,IsDeleted
			FROM T_LNK_ValueStream_ShiftHistory WITH(NOLOCK)
			WHERE ValueStreamTemplateHistoryID = @ValueStreamTemplateHistoryID;

			OPEN CUR_ValueStream_Shift;

			FETCH NEXT
			FROM CUR_ValueStream_Shift
			INTO @ShiftID
				,@ShiftName
				,@RowID
				,@ValueStreamTemplateID
				,@FromTime
				,@ToTime
				,@IsMonday
				,@IsTuesDay
				,@IsWednesday
				,@IsThursday
				,@IsFriday
				,@IsSaturday
				,@IsSunday
				,@DisplayName
				,@IsDeleted;

			WHILE @@FETCH_STATUS = 0
			BEGIN
				IF EXISTS (
						SELECT 1
						FROM T_LNK_ValueStream_Shift WITH(NOLOCK)
						WHERE ShiftID = @ShiftID
						)
				BEGIN
					-- Update the ValueStream_Shift data if that exists
					UPDATE T_LNK_ValueStream_Shift
					SET ShiftName = @ShiftName
						,RowID = @RowID
						,ValueStreamTemplateID = @ValueStreamTemplateID
						,FromTime = @FromTime
						,ToTime = @ToTime
						,IsMonday = @IsMonday
						,IsTuesDay = @IsTuesDay
						,IsWednesday = @IsWednesday
						,IsThursday = @IsThursday
						,IsFriday = @IsFriday
						,IsSaturday = @IsSaturday
						,IsSunday = @IsSunday
						,DisplayName = @DisplayName
						,IsDeleted = @IsDeleted
					WHERE ShiftID = @ShiftID;
				END
				ELSE
				BEGIN
					-- Insert the ValueStream_Shift data if that not exists(may be removed)
					INSERT INTO T_LNK_ValueStream_Shift (
						ShiftName
						,RowID
						,ValueStreamTemplateID
						,FromTime
						,ToTime
						,IsMonday
						,IsTuesDay
						,IsWednesday
						,IsThursday
						,IsFriday
						,IsSaturday
						,IsSunday
						,DisplayName
						,IsDeleted
						)
					VALUES (
						@ShiftName
						,@RowID
						,@ValueStreamTemplateID
						,@FromTime
						,@ToTime
						,@IsMonday
						,@IsTuesDay
						,@IsWednesday
						,@IsThursday
						,@IsFriday
						,@IsSaturday
						,@IsSunday
						,@DisplayName
						,@IsDeleted
						);
				END

				FETCH NEXT
				FROM CUR_ValueStream_Shift
				INTO @ShiftID
					,@ShiftName
					,@RowID
					,@ValueStreamTemplateID
					,@FromTime
					,@ToTime
					,@IsMonday
					,@IsTuesDay
					,@IsWednesday
					,@IsThursday
					,@IsFriday
					,@IsSaturday
					,@IsSunday
					,@DisplayName
					,@IsDeleted;
			END

			CLOSE CUR_ValueStream_Shift;

			DEALLOCATE CUR_ValueStream_Shift;

			--END - Update [T_LNK_ValueStream_Shift]
			COMMIT TRANSACTION TRNRESTOREVSHISTORY;
		END
		ELSE
		BEGIN
			ROLLBACK TRANSACTION TRNRESTOREVSHISTORY;
		END
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNRESTOREVSHISTORY;

		EXEC [USP_LogError] @PlantID
			,@CurrentUserNTID;

		SELECT ERROR_NUMBER() AS ErrorNumber
			,ERROR_MESSAGE() AS ErrorMessage;
	END CATCH
END
GO


