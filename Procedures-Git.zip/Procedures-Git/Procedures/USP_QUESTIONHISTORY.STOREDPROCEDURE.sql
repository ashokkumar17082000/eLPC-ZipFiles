/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_QuestionHistory] 
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING QUESTION HISTORY
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			VENKATESH GOVINDARAJ		PlantID & Code Cleanup
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_QuestionHistory] 1, 1
*/
CREATE PROCEDURE [USP_QuestionHistory] @QuestionID INT
	,@PlantID INT
AS
BEGIN
	SET NOCOUNT ON;

	SELECT
		--ROW_NUMBER() OVER (
		--		ORDER BY QH.QuestionHistoryID
		--		) AS RowNumber
		QH.QuestionHistoryDisplayID
		,(TU.UserName) AS ModifiedBy
		,QH.QuestionHistoryID
		,QH.ModifiedAt
	FROM [T_TRN_QuestionHistory] QH WITH (NOLOCK)
	INNER JOIN T_MST_User TU ON QH.ModifiedBy_NTID = TU.NTID
		AND TU.PlantID = @PlantID
	WHERE QH.QuestionID = @QuestionID
		AND QH.PlantID = @PlantID
	ORDER BY QH.QuestionHistoryDisplayID DESC
END
GO


