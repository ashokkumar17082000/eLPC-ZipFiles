/****** Object:  StoredProcedure [dbo].[USP_Insertprocessconfimration_TagMode_DeviationWithPicAdditionalsettings]    Script Date: 4/11/2024 12:05:58 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [USP_Insertprocessconfimration_TagMode_DeviationWithPicAdditionalsettings]
    @ModeTypeID INT,
    @ValueStreamID INT,
    @AssessorID INT,
    @QuestionID INT,
    @Answer NVARCHAR(MAX),
    @AnswerType_AnswerTypeID INT,
    @CreatedAt DATETIME,
    @ModifiedAt DATETIME,
    @TagId INT,
    @AnsweredBy_NTID NVARCHAR(20),
    @IsDeviation BIT,
    @ObtainedSCore DECIMAL(10, 2),
    @DeviationDescription NVARCHAR(MAX),
    @ResponsibleEmployee NVARCHAR(50),
    @HintImages XML = NULL,
    @ChoiceID INT,
    @IsSHowVsAs BIT,
    @SessionID NVARCHAR(20) = NULL,
    @PlantID INT,
    @AdditionalEmployee XML = NULL,
    @TagName XML = NULL,
    @IsDeleted BIT = NULL,
    @CurrentUserNTID NVARCHAR(20) = NULL,
    @TagmodeID INT,
    @CustomModeID INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @DeviationID INT;
    DECLARE @Timestamp DATETIME;

    BEGIN TRY
        BEGIN TRANSACTION TRNINSERTPC;
INSERT  into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('START_PC',@PlantID,@CurrentUserNTID, getdate(),@ModeTypeID)

		 -- Retrieve formatted date and time using the function fnGetDateTime
        SELECT @TimeStamp = FormattedDateTime
        FROM fnGetDateTime(@PlantID);

		 -- Set CreatedAt and ModifiedAt to the same value as Timestamp
        SET @CreatedAt = @Timestamp;
        SET @ModifiedAt = @Timestamp;

        -- Insert into T_TRN_Deviation
        INSERT INTO T_TRN_Deviation (
            DeviationDescription, ValueStreamID, ResponsibleEmployee,
            QuestionID, CreatedBy_NTID, CreatedAt, ModifiedAt,
            PlantID, DeviationDisplayID
        )
        VALUES (
            @DeviationDescription, @ValueStreamID, @ResponsibleEmployee,
            @QuestionID, @AnsweredBy_NTID, @CreatedAt, @ModifiedAt,
            @PlantID,
            (SELECT DisplayID FROM [FN_GetNextDisplayID](@PlantID, 'T_TRN_Deviation'))
        );

        SET @DeviationID = SCOPE_IDENTITY();

        -- Insert into T_LNK_Tag_AnsweredQuestions if ModeTypeID is 3
        IF @ModeTypeID = 3
        BEGIN
            INSERT INTO T_LNK_Tag_AnsweredQuestions (
                TagID, QuestionID, CreatedAt, ModifiedAt,
                IsDeleted, AnswerTypeID, IsAnswered, Answer,
                CreatedBy_NTID, ModifiedBy_NTID, IsTagCompleted,
                IsTagActive, ValueStreamID, TagModeID, PlantID,
                DeviationDescription, ChoiceID
            )
            VALUES (
                @TagId, @QuestionID, @CreatedAt, @ModifiedAt,
                0, @AnswerType_AnswerTypeID, 1, @Answer,
                @AnsweredBy_NTID, @AnsweredBy_NTID, 0,
                1, @ValueStreamID, @TagmodeID, @PlantID,
                @DeviationDescription, @ChoiceID
            );
        END

		IF @ModeTypeID = 2
        BEGIN
            INSERT INTO T_LNK_Custom_AnsweredQuestions (
             TagID,QuestionID,CreatedAt,ModifiedAt
			,IsDeleted,AnswerTypeID	,IsAnswered	,Answer
			,CreatedBy_NTID	,ModifiedBy_NTID,IsCustomModeCompleted
			,ValueStreamID,CustomModeID	,PlantID,ChoiceID,DeviationDescription
            )
            VALUES (
              	@TagId,@QuestionID,@CreatedAt
			,@ModifiedAt,0,@AnswerType_AnswerTypeID
			,1,@Answer,@AnsweredBy_NTID	,@AnsweredBy_NTID
			,0	,@ValueStreamID,@CustomModeID
			,@PlantID	,@ChoiceID	,@DeviationDescription
			--@DeviationID	
            );
        END

        -- Insert into T_LNK_Deviation_AdditionalEmployee
        INSERT INTO T_LNK_Deviation_AdditionalEmployee (
            DeviationID, NTID, CreatedAt, ModifiedAt,
            IsDeleted, CreatedBy_NTID, UserName
        )
        SELECT
            @DeviationID,
            Emp.value('(NTID/text())[1]', 'NVARCHAR(100)'),
            @CreatedAt,
            @ModifiedAt,
            0,
            @AnsweredBy_NTID,
            Emp.value('(UserName/text())[1]', 'NVARCHAR(100)')
        FROM @AdditionalEmployee.nodes('/ArrayOfUser/User') AS TEMPTABLE(Emp);

        -- Insert into T_LNK_Deviation_AssignedTags
        INSERT INTO T_LNK_Deviation_AssignedTags (
            DeviationID, TagID, IsDeleted,
            CreatedAt, ModifiedAt, CreatedBy_NTID, TagName
        )
        SELECT
            @DeviationID,
            TagName.value('(TagID/text())[1]', 'int'),
            @IsDeleted,
            @CreatedAt,
            @ModifiedAt,
            @AnsweredBy_NTID,
            TagName.value('(FormattedTag/text())[1]', 'nvarchar(100)')
        FROM @TagName.nodes('/ArrayOfTag1/Tag1') AS TEMPTABLE(TagName);

        -- Insert into T_TRN_DeviationAttachments
        --INSERT INTO T_TRN_DeviationAttachments (
        --    QuestionID, ImagePath, ImageTitle, FileContent,
        --    DisplayFileName, CreatedBy_NTID, DeviationID
        --)
        --SELECT
        --    @QuestionID,
        --    HintImage.value('(ImagePath/text())[1]', 'NVARCHAR(50)'),
        --    HintImage.value('(ImageTitle/text())[1]', 'NVARCHAR(100)'),
        --    HintImage.value('(ByteData/text())[1]', 'varbinary(max)'),
        --    HintImage.value('(DisplayFileName/text())[1]', 'NVARCHAR(100)'),
        --    @AnsweredBy_NTID,
        --    @DeviationID
        --FROM @HintImages.nodes('/ArrayOfHintImage/HintImage') AS TEMPTABLE(HintImage);

		UPDATE [T_TRN_DeviationAttachments]
		SET DeviationID = @DeviationID  ,IsDeleted=0
		WHERE IsDeleted=1 and CreatedBy_NTID=@CurrentUserNTID

        -- Insert into T_TRN_DataPool
        INSERT INTO T_TRN_DataPool (
            TIMESTAMP, ValueStreamID, AssessorID, QuestionID,
            Answer, AnswerType_AnswerTypeID, AnsweredBy_NTID,
            CreatedAt, ModifiedBy_NTID, ModifiedAt, TagId,
            IsDeviation, ObtainedSCore, ChoiceID,DeviationID,
            IsSHowVsAs, SessionID, PlantID
        )
        VALUES (
            @Timestamp, @ValueStreamID, @AssessorID, @QuestionID,
            @Answer, @AnswerType_AnswerTypeID, @AnsweredBy_NTID,
            @CreatedAt, @AnsweredBy_NTID, @ModifiedAt, @TagId,
            @IsDeviation, @ObtainedSCore, @ChoiceID,@DeviationID,
            @IsSHowVsAs, @SessionID, @PlantID
        );
INSERT  into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('END_PC',@PlantID,@CurrentUserNTID, getdate(),@ModeTypeID)

        COMMIT TRANSACTION TRNINSERTPC;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION TRNINSERTPC;

        EXEC [USP_LogError] @PlantID, @CurrentUserNTID;

        -- Set the DeviationID to indicate failure (optional)
        SET @DeviationID = 0; -- or any other value to indicate failure
    END CATCH;

    -- Select the DeviationID to return it
    SELECT @DeviationID AS DeviationID;
END

SET QUOTED_IDENTIFIER ON;
GO