/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_GetTagModeAuditMailData]
///AUTHOR                       : RAJASEKAR S
///CREATED DATE                 : 26-JUL-2021
///SEE ALSO                     : THIS PROCEDURE TO GET AUDIT MAIL CONTENT 
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 

ELPC_LH_006					18-AUG-2023			ASHOK KUMAR R B					INITIAL VERSION

************************************************************************************************************ 
*/
/*
exec [USP_GetTagModeAuditMailData] 608,17,5,'FSM1COB',105267
*/
CREATE PROCEDURE [USP_GetTagModeAuditMailData] (    
 @TagID INT    
 ,@TagModeID INT    
 ,@PlantID INT 
 ,@CurrentUserNTID NVARCHAR(20)   
 ,@ValueStreamID INT
    
 )    
AS    
BEGIN    
 DECLARE @NtIdTable TABLE (NTID VARCHAR(20));    
 DECLARE @From VARCHAR(MAX);    
 DECLARE @To VARCHAR(MAX);    
 DECLARE @Cc VARCHAR(MAX);    
 DECLARE @Subject NVARCHAR(MAX);    
 DECLARE @Body NVARCHAR(MAX);    
 DECLARE @TagName VARCHAR(MAX);    
 DECLARE @LeadAuditor VARCHAR(MAX);    
 DECLARE @Attendees VARCHAR(MAX);    
 DECLARE @ValueStreamText NVARCHAR(MAX);    
 
  

 --FROM    
 INSERT INTO @NtIdTable    
 SELECT @CurrentUserNTID    
    
    
 SELECT @From = STUFF((    
    SELECT DISTINCT ';' + EmailAddress    
    FROM T_MST_User    
    WHERE NTID IN (    
      SELECT NTID    
      FROM @NtIdTable    
      )    
    FOR XML PATH('')    
    ), 1, 1, '')    
    
   
    
 SELECT @To = STUFF((    
    SELECT DISTINCT ';' + EmailAddress    
    FROM T_MST_User WITH(NOLOCK)    
    WHERE NTID IN (    
      SELECT NTID    
      FROM @NtIdTable    
      )    
    FOR XML PATH('')    
    ), 1, 1, '')    
 SELECT @Cc = STUFF((    
    SELECT DISTINCT ';' + EmailAddress    
    FROM T_MST_User WITH(NOLOCK)    
    WHERE NTID IN (    
      SELECT NTID    
      FROM @NtIdTable    
      )    
    FOR XML PATH('')    
    ), 1, 1, '')    
    
 --Subject    
 SELECT @Subject = T.TagName    
 FROM T_TRN_Audit A WITH(NOLOCK)    
 INNER JOIN T_TRN_Tag T WITH(NOLOCK) ON A.TagID = T.TagID    
 WHERE A.TagID = @TagID --AuditorSurvey Type>> (Audit / Survey)    
    
 --Body    
 SELECT @LeadAuditor = STUFF((    
    SELECT DISTINCT ';' + EmailAddress    
    FROM T_MST_User WITH(NOLOCK)    
    WHERE NTID IN (    
      SELECT NTID    
      FROM @NtIdTable    
      )    
    FOR XML PATH('')    
    ), 1, 1, '')    
    

 SET @ValueStreamText= (  
SELECT  ValueStreamName  
 FROM T_TRN_Valuestream where valuestreamid=@valuestreamID)
    
	--select @plantid
	--select @tagmodeid
	--select @tagid
	--select @currentuserntid
 SELECT @From [From]    
  ,@To [To]    
  ,@Cc Cc    
  ,@Subject [Subject]    
  ,@LeadAuditor LeadAuditor    
  ,@Attendees Attendees    
  ,@ValueStreamText ValueStreamText    
  ,(    
   SELECT FormattedDateTime    
   FROM [fnGetDateTime](@PlantID)    
   ) AS AnsweredTime    


   DECLARE @RowExists BIT = 0;
	DECLARE @ValidRows BIT = 0;
	--Fetch Suppress question not based on TagID
	DECLARE @SelectedQuestionID INT =0;
	SET @TagModeID = (
			SELECT TOP 1 TagModeID
			FROM T_TRN_TagMode WITH (NOLOCK)
			WHERE CreatedBy_NTID = @CurrentUserNTID
				AND PlantID = @PlantID
			)

	DECLARE @SelectedTagID INT = 0

	SET @SelectedTagID = (
			SELECT TagID
			FROM T_LNK_TagMode_Tags WITH (NOLOCK)
			WHERE TagModeID = @TagModeID
			)

	DECLARE @IsSingleQuestionSuppressed INT = 0

	SET @IsSingleQuestionSuppressed = (
			SELECT IsSingleQuestionSuppressed
			FROM T_TRN_Tag WITH (NOLOCK)
			WHERE TagID = @SelectedTagID
				AND PlantID = @PlantID
			)

	IF EXISTS (
			SELECT TOP 1 1
			FROM [T_TRN_ValueStreamConfig] vsc WITH (NOLOCK)
			CROSS JOIN [T_TRN_AssessorConfig] ac WITH (NOLOCK)
			WHERE vsc.IsDeleted = 0
				AND ac.IsDeleted = 0
				AND vsc.PlantID = @PlantID
				AND ac.PlantID = @PlantID
				AND vsc.User_NTID = @CurrentUserNTID
				AND ac.User_NTID = @CurrentUserNTID
				AND vsc.ValueStreamID IN (
					SELECT c.ValueStreamID
					FROM [T_TRN_ValueStreamConfig] c
					INNER JOIN T_TRN_ValueStreamTemplate vst WITH (NOLOCK) ON vst.ValueStreamTemplateID = c.ValueStreamTemplateID
					INNER JOIN T_TRN_ValueStream vs WITH (NOLOCK) ON vs.ValueStreamID = c.ValueStreamID
					INNER JOIN T_TRN_ValueStreamCategory cat WITH (NOLOCK) ON c.ValueStreamTemplateID = cat.ValueStreamTemplateID
					WHERE c.PlantID = @PlantID
						AND c.User_NTID = @CurrentUserNTID
						AND c.IsDeleted = 0
						AND vst.IsDeleted = 0
						AND vs.IsDeleted = 0
						AND cat.IsDeleted = 0
					)
				AND ac.AssessorID IN (
					SELECT DISTINCT c.AssessorID
					FROM T_TRN_AssessorConfig c WITH (NOLOCK)
					INNER JOIN T_TRN_AssessorTemplate ast WITH (NOLOCK) ON ast.AssessorTemplateID = c.AssessorTemplateID
					INNER JOIN T_TRN_Assessor a WITH (NOLOCK) ON a.AssessorID = c.AssessorID
					WHERE c.PlantID = @PlantID
						AND c.User_NTID = @CurrentUserNTID
						AND c.IsDeleted = 0
						AND ast.IsDeleted = 0
						AND a.IsDeleted = 0
					)
			)
	BEGIN
		SET @RowExists = 1
	END

	IF NOT EXISTS (
			SELECT TOP 1 1
			FROM [T_TRN_ValueStreamConfig] vsc WITH (NOLOCK)
			CROSS JOIN [T_TRN_AssessorConfig] ac WITH (NOLOCK)
			WHERE vsc.IsDeleted = 0
				AND ac.IsDeleted = 0
				AND vsc.PlantID = @PlantID
				AND ac.PlantID = @PlantID
				AND vsc.User_NTID = @CurrentUserNTID
				AND ac.User_NTID = @CurrentUserNTID
				AND vsc.ValueStreamID IN (
					SELECT c.ValueStreamID
					FROM [T_TRN_ValueStreamConfig] c
					INNER JOIN T_TRN_ValueStreamTemplate vst WITH (NOLOCK) ON vst.ValueStreamTemplateID = c.ValueStreamTemplateID
					INNER JOIN T_TRN_ValueStream vs WITH (NOLOCK) ON vs.ValueStreamID = c.ValueStreamID
					INNER JOIN T_TRN_ValueStreamCategory cat WITH (NOLOCK) ON c.ValueStreamTemplateID = cat.ValueStreamTemplateID
					WHERE c.PlantID = @PlantID
						AND c.User_NTID = @CurrentUserNTID
						AND c.IsDeleted = 0
						AND vst.IsDeleted = 0
						AND vs.IsDeleted = 0
						AND cat.IsDeleted = 0
					)
				AND ac.AssessorID IN (
					SELECT DISTINCT c.AssessorID
					FROM T_TRN_AssessorConfig c WITH (NOLOCK)
					INNER JOIN T_TRN_AssessorTemplate ast WITH (NOLOCK) ON ast.AssessorTemplateID = c.AssessorTemplateID
					INNER JOIN T_TRN_Assessor a WITH (NOLOCK) ON a.AssessorID = c.AssessorID
					WHERE c.PlantID = @PlantID
						AND c.User_NTID = @CurrentUserNTID
						AND c.IsDeleted = 0
						AND ast.IsDeleted = 0
						AND a.IsDeleted = 0
					)
				AND (
					(
						vsc.IsForgotValueStream = 1
					
						)
					OR (
						ac.IsForgotAssessor = 1
						
						)
					)
			)
	BEGIN
		SET @ValidRows = 1
	END

	IF (
			@RowExists = 1
			AND @ValidRows = 1
			)
	
		
			--BEGIN TRANSACTION TAG_BINDQUESTIONANDANSWERTYPE

			-- Starts ****** Identifying the custome mode questions *****************
			DECLARE @CustomModeID INT;
			DECLARE @myCustomTableVariable TABLE (QuestionID INT)

			SET @CustomModeID = (
					SELECT CustomModeID
					FROM [T_TRN_CustomMode] WITH (NOLOCK)
					WHERE CreatedBy_NTID = @CurrentUserNTID
						AND PlantID = @PlantID
					);

			INSERT INTO @myCustomTableVariable (QuestionID)
			SELECT QuestionID
			FROM (
				SELECT QuestionID
				FROM [T_LNK_Custom_Questions] WITH (NOLOCK)
				WHERE CustomModeID = @CustomModeID
					AND IsCustomMode = 1
					AND IsDeleted = 0
				) AS tmpCusttbl

			-- Ends ****** Identifying the custome mode questions *****************
			-- Starts ****** Combing & forming VS & AS for filtering Questions belongs to available combination *****************
			SELECT *
			INTO #VSASCombination
			FROM (
				SELECT vsc.User_NTID
					,vsc.ValueStreamTemplateID
					,vsc.ValueStreamID
					,ac.AssessorTemplateID
					,ac.AssessorID
					,vsc.IsForgotValueStream
					,ac.IsForgotAssessor
					,vsc.SessionID AS VSSessionID
					,ac.SessionID AS ASSessionID
				FROM [T_TRN_ValueStreamConfig] vsc WITH (NOLOCK)
				CROSS JOIN [T_TRN_AssessorConfig] ac WITH (NOLOCK)
				WHERE vsc.IsDeleted = 0
					AND ac.IsDeleted = 0
					AND vsc.PlantID = @PlantID
					AND ac.PlantID = @PlantID
					AND vsc.User_NTID = @CurrentUserNTID
					AND ac.User_NTID = @CurrentUserNTID
				) AS VSASCombination

			-- Ends ****** Combing & forming VS & AS for filtering Questions belongs to available combination *****************
			
				--select * from #VSASCombination
			-- Starts ****** Filter the question in sorted order *****************
			SELECT Identity(INT, 1, 1) AS OrderByID
				,VSAS.*
				,Q.QuestionID
				,RQ.RandomQuestionOrder
				,Q.Question_PriorityID
				,Q.TargetFrequencyTypeID
				,Q.ChoiceDisplayTypeID
			--,DP.DataPoolID
			INTO #FilteredQuestion
			FROM #VSASCombination VSAS WITH (NOLOCK)
			INNER JOIN T_LNK_TagMode_Questions TM WITH (NOLOCK) ON TM.TagModeID = @TagModeID

			INNER JOIN T_TRN_Question Q WITH (NOLOCK) ON Q.QuestionID = TM.QuestionID
				
				AND Q.QuestionID = IIF(@SelectedQuestionID = 0, Q.QuestionID, @SelectedQuestionID)
				AND Q.IsDeleted = 0
				AND Q.PlantID = @PlantID
				AND (
					(Q.IsQuestionAlwaysActive = 1)
					OR (
						@IsSingleQuestionSuppressed = 1
						AND Q.IsQuestionAlwaysActive = 0
						AND (
							(CAST(Q.ActiveDateRangeFrom AS DATE) >= CAST(- 53690 AS DATETIME))
							AND (CAST(Q.ActiveDateRangeTo AS DATE) < = CAST('12/31/9999' AS DATE))
							)
						)
					OR (
						cast(@IsSingleQuestionSuppressed AS INT) <> 1
						AND Q.IsQuestionAlwaysActive = 0
						AND (
							(
								CAST((
										SELECT FormattedDateTime
										FROM fnGetDateTime(@PlantID)
										) AS DATE) >= CAST(Q.ActiveDateRangeFrom AS DATE)
								)
							AND (
								CAST((
										SELECT FormattedDateTime
										FROM fnGetDateTime(@PlantID)
										) AS DATE) <= CAST(Q.ActiveDateRangeTo AS DATE)
								)
							)
						)
					)
			
			LEFT JOIN T_LNK_Tag_AssignedQuestionsTags RQ WITH (NOLOCK) ON RQ.QuestionID = Q.QuestionID
				AND RQ.TagID = @SelectedTagID
				AND RQ.IsDeleted = 0				
			--LEFT JOIN T_LNK_QN_AssignedTags QAT  WITH (NOLOCK) ON QAT.QuestionID =Q.QuestionID AND QAT.TagID = @SelectedTagID AND QAT.IsDeleted = 0
			INNER JOIN T_LNK_AssignedValueStreams LVS WITH (NOLOCK) ON LVS.QuestionID = Q.QuestionID
			INNER JOIN T_LNK_AssignedAssessors LAS WITH (NOLOCK) ON LAS.QuestionID = LVS.QuestionID
				AND LVS.IsDeleted = 0
				AND LAS.IsDeleted = 0
			INNER JOIN T_TRN_ValueStream VS WITH (NOLOCK) ON VS.ValueStreamID = LVS.ValueStreamID
				AND VS.IsDeleted = 0
			INNER JOIN T_TRN_Assessor A WITH (NOLOCK) ON A.AssessorID = LAS.AssessorID
				AND A.IsDeleted = 0
			WHERE VSAS.ValueStreamTemplateID = VS.ValueStreamTemplateID
				AND VSAS.ValueStreamID = VS.ValueStreamID
				AND VSAS.AssessorTemplateID = A.AssessorTemplateID
				AND VSAS.AssessorID = A.AssessorID
			ORDER BY
			 case when RQ.RandomQuestionOrder  is null then 998  end, RQ.RandomQuestionOrder
				,Q.Question_PriorityID
				,Q.TargetFrequencyTypeID
				,Q.ChoiceDisplayTypeID DESC
				,Q.QuestionID



--select * from #FilteredQuestion

 select * from (
 select DISTINCT TMQ.QuestionID
  ,'Q' + CAST(Q.QuestionDisplayID AS VARCHAR) AS QuestionDisplayID
 ,Q.QuestionText
  , CASE 
 WHEN TAQ.Answer is null then 'Question Skipped'
 ELSE TAQ.Answer
 END AS Answer
 ,TAQ.DeviationDescription
 ,TMQ.TagModeID  from [T_LNK_TagMode_Questions] TMQ 
 inner join #FilteredQuestion FQ  WITH(NOLOCK) ON FQ.QuestionID = TMQ.QuestionID
 LEFT JOIN (select * from (select ROW_NUMBER() over( partition by  QuestionID order by TagAnsweredQuestionID desc ) AS ROWID ,* from T_LNK_Tag_AnsweredQuestions ) AS T where rowid=1 and tagmodeid=@TagModeID and ModifiedBy_NTID= @CurrentUserNTID and plantid=@PlantID and tagid=@SelectedTagID ) AS TAQ   ON TAQ.QuestionID = TMQ.QuestionID and TAQ.isdeleted =0 
 -- left  join [T_LNK_Tag_AnsweredQuestions]  TAQ ON TMQ.QuestionID= TAQ.QuestionID  and TAQ.isdeleted =0 
 left join T_TRN_Question Q WITH(NOLOCK) ON Q.QuestionID = TMQ.QuestionID ) 
 as temp 
 where temp.TagModeID=@TagModeID

 
 update T_LNK_Tag_AnsweredQuestions  SET IsDeleted=1 where TagModeID =@TagModeID AND PlantID=@Plantid AND  TagID=@TagID AND ModifiedBy_NTID= @CurrentUserNTID

END
GO