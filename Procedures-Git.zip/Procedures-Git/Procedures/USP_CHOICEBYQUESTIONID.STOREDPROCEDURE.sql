/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_ChoiceByQuestionID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING CHOICE BY QUESTION ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			VENKATESH GOVINDARAJ		PlantID & Code Cleanup
ELPC_LH_003					27-JUL-2021			MONASH CHHETRI				AnswerCategory column added
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_ChoiceByQuestionID] 1, 1
*/
CREATE PROCEDURE [USP_ChoiceByQuestionID] @QuestionID INT
	,@PlantID INT
AS
BEGIN
	SET NOCOUNT ON;

	SELECT TC.ChoiceID
		,TC.QuestionID
		,TC.ChoiceName
		,TC.ChoiceScore
		,TC.IsDeviationEntryRequired
		,TC.IsDeleted
		,TC.DeviationTypeID
		,TC.AnswerCategory
	FROM T_TRN_Choice TC WITH (NOLOCK)
	INNER JOIN T_TRN_QUESTION Q WITH (NOLOCK) ON Q.QuestionID = TC.QuestionID
	WHERE TC.QuestionID = @QuestionID
		AND TC.IsDeleted = 0
		AND Q.PlantID = @PlantID
END
GO


