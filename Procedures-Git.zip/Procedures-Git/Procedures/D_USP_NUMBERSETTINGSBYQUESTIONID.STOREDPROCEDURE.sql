/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_NumberSettingsByQuestionID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING ANSWERTYPE NUMBER SETTINGS BY QUESTIONID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
EXEC [USP_NumberSettingsByQuestionID]
*/
CREATE PROCEDURE [USP_NumberSettingsByQuestionID] @QuestionID INT
AS
BEGIN
	SELECT *
	FROM T_TRN_AnswerTypeNumber
	WHERE QuestionID = @QuestionID
		AND (IsDeleted = 0)
END
GO


