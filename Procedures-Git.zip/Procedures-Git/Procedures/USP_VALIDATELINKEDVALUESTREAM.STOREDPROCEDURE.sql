/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_ValidateLinkedValueStream]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR VALIDATING LINKED VALUESTREAM
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					19-MAR-2021			RAJASEKAR S					Plantid included, valuestream id select script change
ELPC_LH_002					26-MAR-2021			Rajasekar S					@CurrentUserNTID,PlantIDValidation added
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
EXEC [USP_ValidateLinkedValueStream] 1
*/
CREATE PROCEDURE [USP_ValidateLinkedValueStream] @PlantID INT
	,@ValueStreamTemplateID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = @ValueStreamTemplateID
		,@Mode = 'VALUESTREAMTEMPLATE'
		,@CurrentUserNTID = @CurrentUserNTID

	SET NOCOUNT ON;

	DECLARE @ValueStreamID_Table TABLE (id INT);

	INSERT INTO @ValueStreamID_Table
	SELECT VS.ValueStreamID
	FROM T_TRN_ValueStream VS WITH (NOLOCK)
	INNER JOIN T_TRN_ValueStreamTemplate VST WITH (NOLOCK) ON VST.ValueStreamTemplateID = VS.ValueStreamTemplateID
	WHERE VST.PlantID = @PlantID
		AND VS.ValueStreamTemplateID = @ValueStreamTemplateID

	SELECT AVS.ID
	FROM T_LNK_AssignedValueStreams AVS WITH (NOLOCK)
	INNER JOIN T_TRN_Question Q WITH (NOLOCK) ON AVS.QuestionID = Q.QuestionID
		AND Q.PlantID = @PlantID
	WHERE ValueStreamID IN (
			SELECT id
			FROM @ValueStreamID_Table
			)
		AND (AVS.IsDeleted = 0)
		AND (Q.IsDeleted = 0)
	
	UNION
	
	SELECT TVS.ID
	FROM T_LNK_Tag_AssignedValueStreams TVS WITH (NOLOCK)
	INNER JOIN T_TRN_Tag T WITH (NOLOCK) ON TVS.TagID = T.TagID
	WHERE ValueStreamID IN (
			SELECT id
			FROM @ValueStreamID_Table
			)
		AND (TVS.IsDeleted = 0)
		AND T.PlantID = @PlantID
		AND (T.IsDeleted = 0)
END
GO


