/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_AddEditQuestionProxy]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE TO ADD AND EDIT QUESTION PROXY
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY 	INITIAL VERSION
ELPC_LH_002					23-MAR-2021			VENKATESH GOVINDARAJ		PlantID & Code Cleanup
ELPC_LH_002					08-JUNE-2022	    SHUBHAM BARANGE			    FOR PROXY MERGE
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
EXEC [USP_AddEditQuestionProxy] 
*/
CREATE PROCEDURE [USP_AddEditQuestionProxy] @ID INT
	,@QuestionID INT
	,@Proxies XML NULL
	,@PlantID INT
	,@CurrentUserNTID NVARCHAR(20)
	,@IsProxyMerge BIT = 0
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION TRNADDEDITQUESTIONPROXY

		SELECT @ID AS ID
			,@QuestionID AS QuestionID
			,@CurrentUserNTID AS ModifiedBy_NTID
			,@CurrentUserNTID AS CreatedBy_NTID
			,Proxie.value('(NTID/text())[1]', 'NVARCHAR(20)') AS Proxy
		INTO #T1
		FROM @Proxies.nodes('/ArrayOfUser/User') AS TEMPTABLE(Proxie)
		WHERE (
				@ID IS NOT NULL
				AND @ID != 0
				)
		IF(@IsProxyMerge = 0)
		BEGIN
		UPDATE T_LNK_Question_Proxy
		SET IsDeleted = 1
			,ModifiedBy_NTID = @CurrentUserNTID
		WHERE ID NOT IN (
				SELECT ID
				FROM #T1
				)
			AND QuestionID = @QuestionID
		END

		UPDATE T_TRN_Question
		SET IsLocked = 1
		WHERE QuestionID = @QuestionID
			AND PlantID = @PlantID;

		INSERT INTO T_LNK_Question_Proxy (
			QuestionID
			,ModifiedBy_NTID
			,CreatedBy_NTID
			,Proxy
			)
		SELECT @QuestionID AS QuestionID
			,@CurrentUserNTID AS ModifiedBy_NTID
			,@CurrentUserNTID AS CreatedBy_NTID
			,Proxie.value('(NTID/text())[1]', 'NVARCHAR(20)') AS Proxy
		FROM @Proxies.nodes('/ArrayOfUser/User') AS TEMPTABLE(Proxie)

		EXEC USP_AddEditusers @PlantID
			,@CurrentUserNTID
			,@Proxies

		COMMIT TRANSACTION TRNADDEDITQUESTIONPROXY;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNADDEDITQUESTIONPROXY;

		EXEC [USP_LogError] @PlantID
			,@CurrentUserNTID;
	END CATCH
END

GO


