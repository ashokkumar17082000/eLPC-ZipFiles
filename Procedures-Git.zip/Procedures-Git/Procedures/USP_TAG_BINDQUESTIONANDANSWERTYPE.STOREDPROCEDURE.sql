
/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_Tag_BindQuestionAndAnswerType] 
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR TAGS TO BIND QUESTION AND ANSWER TYPE
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_004.6				15-JUN-2024			ASHOK KUMAR 				V4.6

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
exec [USP_Tag_BindQuestionAndAnswerType] @ValueStreamID=0,@AssessorID=0,@NTID='FSM1COB',@PlantID=1,@CurrentUserNTID='FSM1COB',@AnsweredAndSkippedQueestionIDs='',@SessionID ='1659066655400',@ResumeTag=1
*/
CREATE PROCEDURE [USP_Tag_BindQuestionAndAnswerType] @ValueStreamID INT
	,@AssessorID INT
	,@NTID NVARCHAR(20)
	,@PlantID INT
	,@CurrentUserNTID NVARCHAR(20) NULL
	,@SelectedQuestionID INT = 0
	,@AnsweredAndSkippedQueestionIDs XML NULL
	,@SessionID NVARCHAR(MAX) NULL
	,@ResumeTag BIT 
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @RowExists BIT = 0;
	DECLARE @ValidRows BIT = 0;
--insert into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('39_(1_TagBind)',@PlantID,@CurrentUserNTID, getdate(),3)

	--Fetch Suppress question not based on TagID

	DECLARE @TagModeID INT = 0
	
	SET @TagModeID = (	SELECT Top 1 TagModeID
					FROM T_TRN_TagMode WITH(NOLOCK)
					WHERE CreatedBy_NTID = @NTID
						AND PlantID = @PlantID
					)

	DECLARE @SelectedTagID INT = 0
	SET @SelectedTagID = (select TagID from T_LNK_TagMode_Tags WITH(NOLOCK) where TagModeID = @TagModeID)

	DECLARE @IsSingleQuestionSuppressed INT = 0

	SET @IsSingleQuestionSuppressed = (
				SELECT IsSingleQuestionSuppressed
				FROM T_TRN_Tag WITH (NOLOCK)
				WHERE TagID = @SelectedTagID
					AND PlantID = @PlantID
		)

	IF EXISTS (
		SELECT TOP 1 1
		FROM [T_TRN_ValueStreamConfig] vsc WITH (NOLOCK)
		CROSS JOIN [T_TRN_AssessorConfig] ac WITH (NOLOCK)
		WHERE vsc.IsDeleted = 0
			AND ac.IsDeleted = 0
			AND vsc.PlantID = @PlantID
			AND ac.PlantID = @PlantID
			AND vsc.User_NTID = @CurrentUserNTID
			AND ac.User_NTID = @CurrentUserNTID
			AND vsc.ValueStreamID IN (
				SELECT c.ValueStreamID
				FROM [T_TRN_ValueStreamConfig] c
				INNER JOIN T_TRN_ValueStreamTemplate vst WITH (NOLOCK) ON vst.ValueStreamTemplateID = c.ValueStreamTemplateID
				INNER JOIN T_TRN_ValueStream vs WITH (NOLOCK) ON vs.ValueStreamID = c.ValueStreamID
				INNER JOIN T_TRN_ValueStreamCategory cat WITH (NOLOCK) ON c.ValueStreamTemplateID = cat.ValueStreamTemplateID
				WHERE c.PlantID = @PlantID
					AND c.User_NTID = @CurrentUserNTID
					AND c.IsDeleted = 0
					AND vst.IsDeleted = 0
					AND vs.IsDeleted = 0
					AND cat.IsDeleted = 0
				)
			AND ac.AssessorID IN (
				SELECT DISTINCT c.AssessorID
				FROM T_TRN_AssessorConfig c WITH (NOLOCK)
				INNER JOIN T_TRN_AssessorTemplate ast WITH (NOLOCK) ON ast.AssessorTemplateID = c.AssessorTemplateID
				INNER JOIN T_TRN_Assessor a WITH (NOLOCK) ON a.AssessorID = c.AssessorID
				WHERE c.PlantID = @PlantID
					AND c.User_NTID = @CurrentUserNTID
					AND c.IsDeleted = 0
					AND ast.IsDeleted = 0
					AND a.IsDeleted = 0
				)
		)
	BEGIN
		SET @RowExists = 1
	END

	IF NOT EXISTS (
		SELECT TOP 1 1
		FROM [T_TRN_ValueStreamConfig] vsc WITH (NOLOCK)
		CROSS JOIN [T_TRN_AssessorConfig] ac WITH (NOLOCK)
		WHERE vsc.IsDeleted = 0
			AND ac.IsDeleted = 0
			AND vsc.PlantID = @PlantID
			AND ac.PlantID = @PlantID
			AND vsc.User_NTID = @CurrentUserNTID
			AND ac.User_NTID = @CurrentUserNTID
			AND vsc.ValueStreamID IN (
				SELECT c.ValueStreamID
				FROM [T_TRN_ValueStreamConfig] c
				INNER JOIN T_TRN_ValueStreamTemplate vst WITH (NOLOCK) ON vst.ValueStreamTemplateID = c.ValueStreamTemplateID
				INNER JOIN T_TRN_ValueStream vs WITH (NOLOCK) ON vs.ValueStreamID = c.ValueStreamID
				INNER JOIN T_TRN_ValueStreamCategory cat WITH (NOLOCK) ON c.ValueStreamTemplateID = cat.ValueStreamTemplateID
				WHERE c.PlantID = @PlantID
					AND c.User_NTID = @CurrentUserNTID
					AND c.IsDeleted = 0
					AND vst.IsDeleted = 0
					AND vs.IsDeleted = 0
					AND cat.IsDeleted = 0
				)
			AND ac.AssessorID IN (
				SELECT DISTINCT c.AssessorID
				FROM T_TRN_AssessorConfig c WITH (NOLOCK)
				INNER JOIN T_TRN_AssessorTemplate ast WITH (NOLOCK) ON ast.AssessorTemplateID = c.AssessorTemplateID
				INNER JOIN T_TRN_Assessor a WITH (NOLOCK) ON a.AssessorID = c.AssessorID
				WHERE c.PlantID = @PlantID
					AND c.User_NTID = @CurrentUserNTID
					AND c.IsDeleted = 0
					AND ast.IsDeleted = 0
					AND a.IsDeleted = 0
				)
			AND (
				(
					vsc.IsForgotValueStream = 1
					AND vsc.SessionID IS NOT NULL
					AND vsc.SessionID <> @SessionID
					)
				OR (
					ac.IsForgotAssessor = 1
					AND ac.SessionID IS NOT NULL
					AND ac.SessionID <> @SessionID
					)
				)
		)
	BEGIN
		SET @ValidRows = 1
	END

--insert into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('153_(2_TagBind)',@PlantID,@CurrentUserNTID, getdate(),3)

	IF (@RowExists = 1 AND @ValidRows = 1)
	BEGIN
		BEGIN TRY
			BEGIN TRANSACTION TAG_BINDQUESTIONANDANSWERTYPE

			-- Starts ****** Identifying the custome mode questions *****************
			DECLARE @CustomModeID INT;
			DECLARE @myCustomTableVariable TABLE (QuestionID INT)

			SET @CustomModeID = (
					SELECT CustomModeID
					FROM [T_TRN_CustomMode] WITH (NOLOCK)
					WHERE CreatedBy_NTID = @NTID
						AND PlantID = @PlantID
					);

			INSERT INTO @myCustomTableVariable (QuestionID)
			SELECT QuestionID
			FROM (
				SELECT QuestionID
				FROM [T_LNK_Custom_Questions] WITH (NOLOCK)
				WHERE CustomModeID = @CustomModeID
					AND IsCustomMode = 1
					AND IsDeleted = 0
				) AS tmpCusttbl

			-- Ends ****** Identifying the custome mode questions *****************
			-- Starts ****** Combing & forming VS & AS for filtering Questions belongs to available combination *****************
			SELECT *
			INTO #VSASCombination
			FROM (
				SELECT vsc.User_NTID
					,vsc.ValueStreamTemplateID
					,vsc.ValueStreamID
					,ac.AssessorTemplateID
					,ac.AssessorID
					,vsc.IsForgotValueStream
					,ac.IsForgotAssessor
					,vsc.SessionID AS VSSessionID
					,ac.SessionID AS ASSessionID
				FROM [T_TRN_ValueStreamConfig] vsc WITH (NOLOCK)
				CROSS JOIN [T_TRN_AssessorConfig] ac WITH (NOLOCK)
				WHERE vsc.IsDeleted = 0
					AND ac.IsDeleted = 0
					AND vsc.PlantID = @PlantID
					AND ac.PlantID = @PlantID
					AND vsc.User_NTID = @CurrentUserNTID
					AND ac.User_NTID = @CurrentUserNTID
				) AS VSASCombination

			-- Ends ****** Combing & forming VS & AS for filtering Questions belongs to available combination *****************
			SELECT *
			INTO #AnsweredAndSkippedQueestionIDs
			FROM (
				SELECT AnsweredAndSkippedQueestionIDs.value('.', 'int') AS QuestionID
				FROM @AnsweredAndSkippedQueestionIDs.nodes('/ArrayOfInt/int') AS TEMPTABLE(AnsweredAndSkippedQueestionIDs)
				) AS AnsweredAndSkippedQueestionIDs
--insert into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('212_(3_TagBind)',@PlantID,@CurrentUserNTID, getdate(),3)

		SELECT * INTO #TAQT  from [T_LNK_Tag_AssignedQuestionsTags] where tagid=@SelectedTagID and isdeleted=0
		--update #TAQT set #TAQT.RandomQuestionOrder=9999 from #TAQT where RandomQuestionOrder is null or RandomQuestionOrder=0
		--select * from #TAQT
		--select * from #TAQT
			-- Starts ****** Filter the question in sorted order *****************
			SELECT  Identity(INT, 1, 1) AS OrderByID
				,VSAS.*, Q.QuestionID
				,Q.Question_PriorityID
				,Q.TargetFrequencyTypeID
				,Q.ChoiceDisplayTypeID
			--,DP.DataPoolID
			INTO #FilteredQuestion
			FROM #VSASCombination VSAS WITH (NOLOCK) 
				INNER JOIN T_LNK_TagMode_Questions TM WITH (NOLOCK) ON TM.TagModeID = @TagModeID
				INNER JOIN T_TRN_Question Q WITH (NOLOCK) ON Q.QuestionID = TM.QuestionID
					AND Q.QuestionID NOT IN (
						SELECT QuestionID
						FROM #AnsweredAndSkippedQueestionIDs
						)
					AND Q.QuestionID = IIF(@SelectedQuestionID = 0, Q.QuestionID, @SelectedQuestionID)
					AND Q.IsDeleted = 0
					AND Q.PlantID = @PlantID
					AND (
						(Q.IsQuestionAlwaysActive = 1)
						OR (
							@IsSingleQuestionSuppressed = 1
							AND Q.IsQuestionAlwaysActive = 0
							AND (
								(CAST(Q.ActiveDateRangeFrom AS DATE) >= CAST(- 53690 AS DATETIME))
								AND (CAST(Q.ActiveDateRangeTo AS DATE) < = CAST('12/31/9999' AS DATE))
								)
							)
						OR (
							cast(@IsSingleQuestionSuppressed AS INT) <> 1
							AND Q.IsQuestionAlwaysActive = 0
							AND (
								(
									CAST((
											SELECT FormattedDateTime
											FROM fnGetDateTime(@PlantID)
											) AS DATE) >= CAST(Q.ActiveDateRangeFrom AS DATE)
									)
								AND (
									CAST((
											SELECT FormattedDateTime
											FROM fnGetDateTime(@PlantID)
											) AS DATE) <= CAST(Q.ActiveDateRangeTo AS DATE)
									)
								)
							)
						)
				INNER JOIN T_LNK_AssignedValueStreams LVS WITH (NOLOCK) ON LVS.QuestionID = Q.QuestionID
				INNER JOIN T_LNK_AssignedAssessors LAS WITH (NOLOCK) ON LAS.QuestionID = LVS.QuestionID
					AND LVS.IsDeleted = 0
					AND LAS.IsDeleted = 0
				INNER JOIN T_TRN_ValueStream VS WITH (NOLOCK) ON VS.ValueStreamID = LVS.ValueStreamID
					AND VS.IsDeleted = 0
				INNER JOIN T_TRN_Assessor A WITH (NOLOCK) ON A.AssessorID = LAS.AssessorID
					AND A.IsDeleted = 0
				WHERE VSAS.ValueStreamTemplateID = VS.ValueStreamTemplateID
					AND VSAS.ValueStreamID = VS.ValueStreamID
					AND VSAS.AssessorTemplateID = A.AssessorTemplateID
					AND VSAS.AssessorID = A.AssessorID
			ORDER BY Q.Question_PriorityID
				,Q.TargetFrequencyTypeID
				,Q.ChoiceDisplayTypeID DESC
				,Q.QuestionID

--insert into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('281_(4_TagBind)',@PlantID,@CurrentUserNTID, getdate(),3)

			--select * from #FilteredQuestion
			-- Ends ****** Filter the question in sorted order *****************
			-- Starts ****** Send Back the result in sorted order *****************
			SELECT *
			INTO #ResultQuestions
			FROM (
				SELECT TQ.QuestionID
					,TQ.QuestionDisplayID
					,@CurrentUserNTID AS CurrentUserNTID
					,TV.ResponsibleEmployee
					,TVT.Delimiter
					,QL.ValueStreamTemplateID
					,TVT.ValueStreamTemplateName
					,TV.ValueStreamCategoryID
					,TVC.valueStreamCategoryName
					,QL.ValueStreamID
					,TV.ValueStreamName
					,QL.AssessorTemplateID
					,TRA.AssessorTemplateName
					,QL.AssessorID
					,TTA.AssessorName
					,QL.IsForgotValueStream
					,CASE 
						WHEN (QL.IsForgotValueStream = 1)
							THEN QL.VSSessionID
						ELSE NULL
						END AS VSSessionID
					,QL.IsForgotAssessor
					,CASE 
						WHEN (QL.IsForgotAssessor = 1)
							THEN QL.ASSessionID
						ELSE NULL
						END AS ASSessionID
					--,(
					--	SELECT MAX(DataPoolID) AS DataPoolID
					--	FROM [t_trn_datapool] WITH(NOLOCK)
					--	WHERE answeredby_ntid = @NTID
					--		AND (IsDeleted = 0)
					--		AND AuditID IS NULL
					--		AND QuestionID = TQ.QuestionID
					--		AND PlantID = @PlantID
					--	) 
						,1 AS DataPoolID
					,TQ.QuestionText
					,TQ.QuestionHintText
					,TQ.AnswerType_AnswerTypeID
					,TQ.ChoiceDisplayTypeID
					,TQ.IsFilledInChoiceAllowed
					,TQ.IsUniqueAnswerRequired
					,TQ.IsAnswerRequired
					,TQ.DefaultChoiceID
					,TQ.IsQuestionAlwaysActive
					,TQ.ActiveDateRangeFrom
					,TQ.ActiveDateRangeTo
					,TQ.IsTargetFrequencyDefined
					,TQ.TargetFrequencyTypeID
					,TQ.TargetFrequencyValue
					,TQ.Question_PriorityID
					,TQ.IsDeleted
					,TQ.IsDefaultAnswerRequired
					,TQ.IsAnswered
					,TQ.CreatedAt
					,TQ.ModifiedAt
					,(
						SELECT DISTINCT abc = STUFF((
									SELECT ',' + HyperLinkURL
									FROM [T_TRN_HintHyperLink] WITH (NOLOCK)
									WHERE QuestionID = TQ.QuestionID
										AND (IsDeleted = 0)
									FOR XML PATH('')
										,TYPE
									).value('.', 'NVARCHAR(MAX)'), 1, 1, '')
						) AS HyperLinkURL
					,(
						SELECT DISTINCT abc = STUFF((
									SELECT ',' + ImageTitle
									FROM T_TRN_HintImage WITH (NOLOCK)
									WHERE QuestionID = TQ.QuestionID
										AND (IsDeleted = 0)
									FOR XML PATH('')
										,TYPE
									).value('.', 'NVARCHAR(MAX)'), 1, 1, '')
						) AS ImageTitle
					,(
						SELECT DISTINCT abc = STUFF((
									SELECT ',' + DisplayFileName
									FROM T_TRN_HintImage WITH (NOLOCK)
									WHERE QuestionID = TQ.QuestionID
										AND (IsDeleted = 0)
									FOR XML PATH('')
										,TYPE
									).value('.', 'NVARCHAR(MAX)'), 1, 1, '')
						) AS DisplayFileName
					,(SELECT ListTag FROM [FN_GetNestedTagsByQuestionID](TQ.QuestionID,'strTagName') where ListTag is not null) AS TagNameList
					,(SELECT ListTag FROM [FN_GetNestedTagsByQuestionID](TQ.QuestionID,'strTagID') where ListTag is not null ) AS TagIDList
					,CASE 
						WHEN TQ.QuestionID IN (
								SELECT QuestionID
								FROM @myCustomTableVariable
								)
							THEN 1
						ELSE 0
						END AS IsCustomMode
					,'' AS SessionID
				FROM T_TRN_Question TQ WITH (NOLOCK)
				LEFT JOIN #FilteredQuestion QL WITH (NOLOCK) ON TQ.QuestionID = QL.QuestionID
				INNER JOIN [T_TRN_ValueStream] TV WITH (NOLOCK) ON TV.ValueStreamID = QL.ValueStreamID
				INNER JOIN [T_TRN_ValueStreamTemplate] TVT WITH (NOLOCK) ON TVT.ValueStreamTemplateID = TV.ValueStreamTemplateID
					AND TVT.PlantID = @PlantID
				INNER JOIN [T_TRN_ValueStreamCategory] TVC WITH (NOLOCK) ON TVC.ValueStreamCategoryID = TV.ValuestreamCategoryID
				INNER JOIN [T_TRN_Assessor] TTA WITH (NOLOCK) ON TTA.AssessorID = QL.AssessorID
				INNER JOIN [T_TRN_AssessorTemplate] TRA WITH (NOLOCK) ON TRA.AssessorTemplateID = TTA.AssessorTemplateID
					AND TRA.PlantID = @PlantID
				LEFT JOIN [T_TRN_HintHyperLink] TTH WITH (NOLOCK) ON TTH.QuestionID = TQ.QuestionID
				WHERE TV.Responsible_UserID IS NOT NULL -- and  TQ.QuestionID not in(select QuestionID from #Temp) 
					AND (TQ.IsDeleted = 0)
					AND TQ.PlantID = @PlantID
				) AS t2
				
			--select * from #ResultQuestions
			IF (@ResumeTag=1)
			BEGIN
		--	select * from #TAQT
		--select * from #ResultQuestions
		--	select * from T_LNK_Tag_AnsweredQuestions where TagModeID =@TagModeID and TagID=@SelectedTagID AND PlantID=@Plantid AND ModifiedBy_NTID=@CurrentUserNTID
		--select * from (select ROW_NUMBER() over( partition by  QuestionID order by TagAnsweredQuestionID desc ) AS ROWID ,* from T_LNK_Tag_AnsweredQuestions ) AS T where rowid=1 and TagModeID=@TagModeID and ModifiedBy_NTID= @CurrentUserNTID and plantid=@PlantID and tagid=@SelectedTagID and T.isdeleted=0  
			SELECT Rq.RandomQuestionOrder,TAQ.Answer, *
			FROM #ResultQuestions ResQ WITH (NOLOCK) 
			LEFT JOIN #TAQT RQ WITH (NOLOCK) ON RQ.QuestionID =ResQ.QuestionID
			LEFT JOIN (select * from (select ROW_NUMBER() over( partition by TagID order by CreatedAT desc , isdeleted asc ) AS ROWID ,* from T_LNK_Tag_AnsweredQuestions ) AS T where  TagModeID=@TagModeID and ModifiedBy_NTID= @CurrentUserNTID and plantid=@PlantID and tagid=@SelectedTagID 
		) AS TAQ   ON TAQ.QuestionID = ResQ.QuestionID
			ORDER BY
			 case when RandomQuestionOrder  is null then 998  end, RQ.RandomQuestionOrder
				,Question_PriorityID
				,TargetFrequencyTypeID
				,ChoiceDisplayTypeID DESC
				,ResQ.QuestionID

			--UPDATE  [T_LNK_Tag_AnsweredQuestions] SET IsDeleted=1 where TagModeID =@TagModeID and TagID=@SelectedTagID AND PlantID=@Plantid AND ModifiedBy_NTID=@CurrentUserNTID
			END

			ELSE
			BEGIN
			SELECT Rq.RandomQuestionOrder,*
			FROM #ResultQuestions ResQ WITH (NOLOCK) 
			LEFT JOIN #TAQT RQ WITH (NOLOCK) ON RQ.QuestionID =ResQ.QuestionID
			 ORDER BY
			case when RandomQuestionOrder  is null then 998  end, RQ.RandomQuestionOrder  
				,Question_PriorityID
				,TargetFrequencyTypeID
				,ChoiceDisplayTypeID DESC
				,ResQ.QuestionID

			--UPDATE  [T_LNK_Tag_AnsweredQuestions] SET IsDeleted=1 where TagModeID =@TagModeID and TagID=@SelectedTagID AND PlantID=@Plantid AND ModifiedBy_NTID=@CurrentUserNTID
			END

--	insert into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('430_(5_TagBind)',@PlantID,@CurrentUserNTID, getdate(),3)

			-- Ends ****** Send Back the result in sorted order *****************
			COMMIT TRANSACTION TAG_BINDQUESTIONANDANSWERTYPE;
		END TRY

		BEGIN CATCH
			ROLLBACK TRANSACTION TAG_BINDQUESTIONANDANSWERTYPE;

			EXEC [USP_LogError] @PlantID
				,@CurrentUserNTID;
		END CATCH
	END
	ELSE
	BEGIN
		SELECT - 1 AS QuestionID
	END
END
GO
