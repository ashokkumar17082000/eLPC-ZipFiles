/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchQuestion]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING QUESTION
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			VENKATESH GOVINDARAJ		PlantID & Code Cleanup
ELPC_LH_002					25-MAY-2022			SHUBHAM BARANGE		        Added Is Accessible Column for Merge 
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_FetchQuestion] 1
*/
CREATE PROCEDURE [USP_FetchQuestion] @PlantID AS INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT Q.QuestionID
		,Q.QuestionText
		,Q.QuestionDisplayID
		,Q.QuestionHintText
		,CASE 
			WHEN Q.IsLocked = 1
				THEN IIF((
							SELECT COUNT(*)
							FROM T_LNK_Question_Proxy
							WHERE QuestionID = Q.QuestionID
								AND (
									Proxy = @CurrentUserNTID
									OR CreatedBy_NTID = @CurrentUserNTID
									OR ModifiedBy_NTID = @CurrentUserNTID
									)
								AND IsDeleted=0
							) > 0, 1, 0)
			ELSE 1
			END AS IsAccessible
	FROM T_TRN_Question Q WITH (NOLOCK)
	WHERE Q.QuestionID IS NOT NULL
		AND Q.IsDeleted = 0
		AND Q.PlantID = @PlantID
	ORDER BY ModifiedAt DESC
END

GO


