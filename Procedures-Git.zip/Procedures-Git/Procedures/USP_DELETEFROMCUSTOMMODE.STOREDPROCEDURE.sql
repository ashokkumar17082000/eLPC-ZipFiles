/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_DeleteFromCustomMode]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR DELETING CUSTOM MODE
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			VENKATESH GOVINDARAJ		PLANTID & CODE CLEANUP

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_DeleteFromCustomMode] 1,1,1,'OSP4KOR'
*/
CREATE PROCEDURE [USP_DeleteFromCustomMode] @QuestionID INT
	,@TagID INT
	,@PlantID INT
	,@CurrentUserNTID NVARCHAR(20) NULL
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION TRNDELETECUSTOM

		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		DECLARE @CustomModeID INT;

		SET @CustomModeID = (
				SELECT CustomModeID
				FROM [T_TRN_CustomMode] WITH(NOLOCK)
				WHERE CreatedBy_NTID = @CurrentUserNTID
					AND PlantID = @PlantID
				)

		UPDATE [T_LNK_Custom_Questions]
		SET IsCustomMode = 0
		WHERE QuestionID IN (@QuestionID)
			AND CustomModeID = @CustomModeID

		COMMIT TRANSACTION TRNDELETECUSTOM;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNDELETECUSTOM;

		EXEC [USP_LogError] @PlantID
			,@CurrentUserNTID;
	END CATCH
END
GO


