/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_InsertIntoDeviation]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR INSERTING IN TO DEVIATION [T_TRN_Deviation] TABLE
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001                                     08-APR-2024                     SHUBHAM BARANGE                 INITIAL VERSION :To Store Attachementson Select File click
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_InsertIntoDeviation] 
*/
CREATE PROCEDURE [USP_INSERTINTODEVIATIONATTACHMENTS] (
	@HintImages XML NULL
	,@CurrentUserNTID NVARCHAR(20)
	,@PlantID INT
	,@IsDeleted BIT NULL
	)
AS
BEGIN
	DECLARE @DeviationID INT;

	BEGIN TRY
		BEGIN TRANSACTION INSERTINTODEVIATIONATTACHMENTS;
INSERT  into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('START_PC',@PlantID,@CurrentUserNTID, getdate(),5)

		SET @DeviationID = Scope_Identity();

		INSERT INTO [T_TRN_DeviationAttachments] (
			ImagePath
			,ImageTitle
			,FileContent
			,DisplayFileName
			,CreatedBy_NTID
			,DeviationID
			,IsDeleted
			)
		SELECT HintImage.value('(ImagePath/text())[1]', 'NVARCHAR(50)') AS ImagePath
			,HintImage.value('(ImageTitle/text())[1]', 'NVARCHAR(100)') AS ImageTitle
			,HintImage.value('(ByteData/text())[1]', 'varbinary(max)') AS FileContent
			,HintImage.value('(DisplayFileName/text())[1]', 'NVARCHAR(100)') AS DisplayFileName
			,@CurrentUserNTID
			,@DeviationID AS DeviationID
			,1
		FROM @HintImages.nodes('/ArrayOfHintImage/HintImage') AS TEMPTABLE(HintImage)
		INSERT  into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('END_PC',@PlantID,@CurrentUserNTID, getdate(),5)
		COMMIT TRANSACTION INSERTINTODEVIATIONATTACHMENTS;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION INSERTINTODEVIATIONATTACHMENTS;

		EXEC USP_LogError @PlantID
			,@CurrentUserNTID;
	END CATCH

	SELECT @DeviationID AS DeviationID
END
GO