SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [USP_AddEditAuditQuestion_OLD] @ID INT
	,@AuditID INT
	,@QuestionID INT
	,@IsDeleted BIT
	,@CreatedBy_NTID NVARCHAR(20)
	,@ModifiedBy_NTID NVARCHAR(20)
	,@AnswerTypeID INT
	,@IsAnswered BIT
	,@Answer NVARCHAR(max) NULL
	,@IsAnswerRequired BIT
AS
BEGIN
	DECLARE @NotAnswered INT
		,@CreatedAt DATETIME
		,@ModifiedAt DATETIME;

	IF (@Answer IS NULL)
		SET @IsAnswered = 0
	ELSE
		SET @IsAnswered = 1

	--IF(@ID is null or @ID = 0)
	--BEGIN
	--insert into T_LNK_Audit_AnsweredQuestions(AuditID, QuestionID, CreatedAt,ModifiedAt,
	--IsDeleted, CreatedBy_NTID,ModifiedBy_NTID,AnswerTypeID,IsAnswered,Answer) values(@AuditID, @QuestionID, (SELECT * from fnGetDateTime()), (SELECT * from fnGetDateTime()),
	--@IsDeleted, @CreatedBy_NTID,@ModifiedBy_NTID,@AnswerTypeID,@IsAnswered,@Answer)
	SELECT *
	INTO #T1
	FROM T_LNK_Audit_AssignedQuestions
	WHERE AuditID = @AuditID

	UPDATE #T1
	SET CreatedBy_NTID = @CreatedBy_NTID;

	DECLARE CUR_AuditQuestion CURSOR FORWARD_ONLY
	FOR
	SELECT AuditID
		,QuestionID
		,CreatedAt
		,ModifiedAt
		,IsDeleted
		,CreatedBy_NTID
		,ModifiedBy_NTID
		,AnswerTypeID
		,IsAnswerRequired
	FROM #T1

	OPEN CUR_AuditQuestion;

	FETCH NEXT
	FROM CUR_AuditQuestion
	INTO @AuditID
		,@QuestionID
		,@CreatedAt
		,@ModifiedAt
		,@IsDeleted
		,@CreatedBy_NTID
		,@ModifiedBy_NTID
		,@AnswerTypeID
		,@IsAnswerRequired

	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF EXISTS (
				SELECT *
				FROM T_LNK_Audit_AnsweredQuestions
				WHERE AuditID = @AuditID
					AND QuestionID = @QuestionID
					AND CreatedBy_NTID = @CreatedBy_NTID
				)
		BEGIN
			-- Update the Assessor data if that exists
			UPDATE T_LNK_Audit_AnsweredQuestions
			SET AuditID = @AuditID
				,QuestionID = @QuestionID
				,ModifiedAt = @ModifiedAt
				,IsDeleted = @IsDeleted
				,ModifiedBy_NTID = @ModifiedBy_NTID
				,IsAnswered = @IsAnswered
				,Answer = @Answer
				,IsAnswerRequired = @IsAnswerRequired
			WHERE AuditID = @AuditID
				AND QuestionID = @QuestionID
				AND CreatedBy_NTID = @CreatedBy_NTID;
		END
		ELSE
		BEGIN
			-- Insert the Assessor data if that not exists(may be removed)
			INSERT INTO T_LNK_Audit_AnsweredQuestions (
				AuditID
				,QuestionID
				,CreatedAt
				,ModifiedAt
				,IsDeleted
				,CreatedBy_NTID
				,ModifiedBy_NTID
				,AnswerTypeID
				,IsAnswered
				,Answer
				,IsAnswerRequired
				)
			VALUES (
				@AuditID
				,@QuestionID
				,@CreatedAt
				,@ModifiedAt
				,@IsDeleted
				,@CreatedBy_NTID
				,@ModifiedBy_NTID
				,@AnswerTypeID
				,@IsAnswered
				,@Answer
				,@IsAnswerRequired
				);
		END

		FETCH NEXT
		FROM CUR_AuditQuestion
		INTO @AuditID
			,@QuestionID
			,@CreatedAt
			,@ModifiedAt
			,@IsDeleted
			,@CreatedBy_NTID
			,@ModifiedBy_NTID
			,@AnswerTypeID
			,@IsAnswered
			,@Answer
			,@IsAnswerRequired;
	END

	CLOSE CUR_AuditQuestion;

	DEALLOCATE CUR_AuditQuestion;

	--END
	--ELSE
	--BEGIN
	UPDATE T_LNK_Audit_AnsweredQuestions
	SET AuditID = @AuditID
		,QuestionID = @QuestionID
		,ModifiedAt = (SELECT * from fnGetDateTime())
		,IsDeleted = 0
		,CreatedBy_NTID = @CreatedBy_NTID
		,ModifiedBy_NTID = @ModifiedBy_NTID
		,AnswerTypeID = @AnswerTypeID
		,IsAnswered = @IsAnswered
		,Answer = @Answer
		,IsAnswerRequired = @IsAnswerRequired
	WHERE QuestionID = @QuestionID
		AND AuditID = @AuditID
		AND CreatedBy_NTID = @CreatedBy_NTID
		--END
		--update T_LNK_Audit_AssignedQuestions set Answer = @Answer,
		--  IsAnswered = @IsAnswered, ModifiedAt = (SELECT * from fnGetDateTime()) where ID = @ID
		--SET @NotAnswered = (select Count(ID)  from T_LNK_Audit_AssignedQuestions where IsAnswered = 0 and AuditID = @AuditID)
		--IF(@NotAnswered = 0)
		--BEGIN
		--update T_TRN_Audit SET IsAuditCompleted = 1 where AuditID = @AuditID
		--insert into T_TRN_DataPool (TimeStamp,QuestionID, Answer, AnswerType_AnswerTypeID, CreatedAt, AnsweredBy_NTID, ModifiedAt, ModifiedBy_NTID,IsAnswered)
		--select (SELECT * from fnGetDateTime()), QuestionID, Answer, AnswerTypeID as AnswerType_AnswerTypeID, CreatedAt, CreatedBy_NTID as AnsweredBy_NTID, ModifiedAt, ModifiedBy_NTID,1 
		--from T_LNK_Audit_AssignedQuestions where AuditID = @AuditID 
		--END
END
GO


