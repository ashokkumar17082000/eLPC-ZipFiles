SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Manish Karn>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [USP_PopulateVstreamAndAssessorDropdown]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT ValueStreamID
		,ValueStreamName
	FROM [T_TRN_ValueStream]
		--select  AssessorID,AssessorName from [T_TRN_Assessor]
END
GO


