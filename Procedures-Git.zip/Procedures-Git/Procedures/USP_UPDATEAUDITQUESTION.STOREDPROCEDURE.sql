/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_UpdateAuditQuestion]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR UPDATING AUDIT QUESTIONS
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			Rajasekar S					PlantId,CurrentUserNTID added

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_UpdateAuditQuestion] 1,1, 'Answer', 1, 'RSB4COB'
*/
CREATE PROCEDURE [USP_UpdateAuditQuestion] @PlantID INT
	,@ID INT
	,@Answer NVARCHAR(max) NULL
	,@AuditID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	BEGIN TRY
		--Inputs filed variable for triggers
		DECLARE @Scope_Identity_Table_Trigger TABLE (id INT);--Scope identities for all inserted rows
		DECLARE @Input_Ids_Trigger VARCHAR(MAX);
		DECLARE @TableName_Trigger VARCHAR(100);
		DECLARE @ActionType VARCHAR(10);

		BEGIN TRANSACTION TRNUPATEAUDITQN

		EXEC [USP_PlantIDValidation] @PlantID = @PlantID
			,@ID = @AuditID
			,@Mode = 'AUDIT'
			,@CurrentUserNTID = @CurrentUserNTID

		DECLARE @IsAnswered BIT
			,@NotAnswered INT;

		IF (@Answer IS NULL)
			SET @IsAnswered = 0
		ELSE
			SET @IsAnswered = 1

		UPDATE T_LNK_Audit_AssignedQuestions
		SET Answer = @Answer
			,IsAnswered = @IsAnswered
			,ModifiedAt = (
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				)
		WHERE ID = @ID

		SET @NotAnswered = (
				SELECT Count(ID)
				FROM T_LNK_Audit_AssignedQuestions WITH(NOLOCK)
				WHERE IsAnswered = 0
					AND AuditID = @AuditID
				)

		IF (@NotAnswered = 0)
		BEGIN
			UPDATE T_TRN_Audit
			SET IsAuditCompleted = 1
			WHERE AuditID = @AuditID
				AND PlantID = @PlantID

			DELETE
			FROM @Scope_Identity_Table_Trigger

			INSERT INTO T_TRN_DataPool (
				TIMESTAMP
				,QuestionID
				,Answer
				,AnswerType_AnswerTypeID
				,CreatedAt
				,AnsweredBy_NTID
				,ModifiedAt
				,ModifiedBy_NTID
				,IsAnswered
				)
			OUTPUT inserted.DataPoolID
			INTO @Scope_Identity_Table_Trigger
			SELECT (
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
				,QuestionID
				,Answer
				,AnswerTypeID AS AnswerType_AnswerTypeID
				,CreatedAt
				,CreatedBy_NTID AS AnsweredBy_NTID
				,ModifiedAt
				,ModifiedBy_NTID
				,1
			FROM T_LNK_Audit_AssignedQuestions WITH(NOLOCK)
			WHERE AuditID = @AuditID

			SELECT @TableName_Trigger = 'DATAPOOL'
				,@ActionType = 'I'
				,@Input_Ids_Trigger = (
					SELECT CAST(id AS VARCHAR(MAX)) + ', '
					FROM @Scope_Identity_Table_Trigger
					FOR XML PATH('')
					);

			EXEC [USP_DATAPOOL_HISTORY] @PlantID = @PlantID
				,@CurrentUserNTID = @CurrentUserNTID
				,@TableName = @TableName_Trigger
				,@ActionType = @ActionType
				,@INPUT_IDS = @Input_Ids_Trigger;
		END

		COMMIT TRANSACTION TRNUPATEAUDITQN
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNUPATEAUDITQN

		EXEC USP_LogError @PlantID
			,@CurrentUserNTID
	END CATCH
END
GO


