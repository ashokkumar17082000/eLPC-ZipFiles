/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_VALUESTREAM_HISTORY]
///AUTHOR                       : RAJASEKAR S
///CREATED DATE                 : 10-MAR-2021
///SEE ALSO                     : THIS PROCEDURE TO ADD VALUE STREAM HISTORY DETAILS 
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_002					10-MAR-2021			RAJASEKAR S					INITIAL VERSION
************************************************************************************************************ 
///</SUMMARY>

EXEC [USP_VALUESTREAM_HISTORY] 1,'ValueStreamTemplate',1,'I','1'
*/
CREATE PROCEDURE [USP_VALUESTREAM_HISTORY] @PlantID INT
	,@CurrentUserNTID NVARCHAR(20) NULL
	,@TableName VARCHAR(100)
	,@ValueStreamTemplateHistoryID INT OUTPUT
	,@ActionType VARCHAR(10)
	,@INPUT_IDS VARCHAR(MAX)
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION TRNVSHISTORY
		IF (@TableName = 'ValueStreamTemplate')
		BEGIN
			INSERT INTO [T_HST_ValueStreamTemplateHistory] (
				PlantID
				,[ValueStreamTemplateID]
				,ValueStreamTemplateDisplayID
				,ValueStreamTemplateHistoryDisplayID
				,[ValueStreamTemplateName]
				,[IsLocked]
				,[ModifiedAt]
				,[CreatedAt]
				,[Delimiter]
				,[VisualizationViewModeID]
				,[IsOperatedInShifts]
				,[IsDeleted]
				,[ActionType]
				,[ActionDate]
				,[CreatedBy_NTID]
				,[ModifiedBy_NTID]
				)
			SELECT PlantID
				,[ValueStreamTemplateID]
				,ValueStreamTemplateDisplayID
				,(
					SELECT DisplayID
					FROM [FN_GetNextHistoryDisplayID](@PlantID, 'T_HST_ValueStreamTemplateHistory', ValueStreamTemplateID)
					)
				,[ValueStreamTemplateName]
				,[IsLocked]
				,[ModifiedAt]
				,[CreatedAt]
				,[Delimiter]
				,[VisualizationViewModeID]
				,[IsOperatedInShifts]
				,[IsDeleted]
				,@ActionType
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
				,[CreatedBy_NTID]
				,[ModifiedBy_NTID]
			FROM [T_TRN_ValueStreamTemplate] WITH(NOLOCK)
			WHERE [ValueStreamTemplateID] = @INPUT_IDS
				AND PlantID = @PlantID;

			SET @ValueStreamTemplateHistoryID = SCOPE_IDENTITY()
		END
		ELSE IF (@TableName = 'VALUESTREAM')
		BEGIN
			INSERT INTO [T_TRN_ValueStreamHistory] (
				ValueStreamTemplateHistoryID
				,ValueStreamID
				,Responsible_UserID
				,ValueStreamTemplateID
				,ValueStreamCategoryID
				,ValueStreamData
				,NodeID
				,IsDeleted
				,ResponsibleEmployee
				,RowID
				,ActionType
				,ActionDate
				,ValueStreamName
				,ModifiedBy_NTID
				,CreatedBy_NTID
				,ParentId
				)
			SELECT @ValueStreamTemplateHistoryID
				,ValueStreamID
				,Responsible_UserID
				,ValueStreamTemplateID
				,ValueStreamCategoryID
				,ValueStreamData
				,NodeID
				,IsDeleted
				,ResponsibleEmployee
				,RowID
				,@ActionType
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
				,ValueStreamName
				,ModifiedBy_NTID
				,CreatedBy_NTID
				,ParentId
			FROM T_TRN_ValueStream WITH(NOLOCK)
			WHERE ValueStreamID IN (
					SELECT *
					FROM fnSplit(@INPUT_IDS)
					)
		END
		ELSE IF (@TableName = 'ValueStreamCategory')
		BEGIN
			INSERT INTO [T_TRN_ValueStreamCategoryHistory] (
				ValueStreamTemplateHistoryID
				,ValueStreamCategoryID
				,ValueStreamCategoryName
				,ValueStreamTemplateID
				,IsDataRequired
				,TypeOfInput_InputTypeID
				,IsDataRequiredToFitSpecLength
				,MinimumNoOfCharacters
				,MaximumNoOfCharacters
				,NodeID
				,ActionType
				,ActionDate
				,IsDeleted
				,IsColumnRequired
				,InputType
				)
			SELECT @ValueStreamTemplateHistoryID
				,ValueStreamCategoryID
				,ValueStreamCategoryName
				,ValueStreamTemplateID
				,IsDataRequired
				,TypeOfInput_InputTypeID
				,IsDataRequiredToFitSpecLength
				,MinimumNoOfCharacters
				,MaximumNoOfCharacters
				,NodeID
				,@ActionType
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
				,IsDeleted
				,IsColumnRequired
				,InputType
			FROM T_TRN_ValueStreamCategory WITH(NOLOCK)
			WHERE ValueStreamCategoryID IN (
					SELECT *
					FROM fnSplit(@INPUT_IDS)
					)
		END
		ELSE IF (@TableName = 'VALUESTREAM_SHIFT')
		BEGIN
			INSERT INTO [T_LNK_ValueStream_ShiftHistory] (
				ValueStreamTemplateHistoryID
				,ShiftID
				,ShiftName
				,RowID
				,ValueStreamTemplateID
				,FromTime
				,ToTime
				,IsMonday
				,IsTuesDay
				,IsWednesday
				,IsThursday
				,IsFriday
				,IsSaturday
				,IsSunday
				,DisplayName
				,IsDeleted
				,ActionType
				,ActionDate
				)
			SELECT @ValueStreamTemplateHistoryID
				,ShiftID
				,ShiftName
				,RowID
				,ValueStreamTemplateID
				,FromTime
				,ToTime
				,IsMonday
				,IsTuesDay
				,IsWednesday
				,IsThursday
				,IsFriday
				,IsSaturday
				,IsSunday
				,DisplayName
				,IsDeleted
				,@ActionType
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
			FROM T_LNK_ValueStream_Shift WITH(NOLOCK)
			WHERE ShiftID IN (
					SELECT *
					FROM fnSplit(@INPUT_IDS)
					)
		END
		COMMIT TRANSACTION TRNVSHISTORY;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNVSHISTORY;
		EXEC [USP_LogError] @PlantID
			,@CurrentUserNTID
	END CATCH
END
GO


