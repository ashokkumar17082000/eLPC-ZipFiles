/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchRecycleBinTemplate]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING RECYCLE BIN TEMPLATE
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					26-MAR-2021			VENKATESH GOVINDARAJ		PlantID & Code Cleanup
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_FetchRecycleBinTemplate] 
*/
CREATE PROCEDURE [USP_FetchRecycleBinTemplate] @PlantID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT *
	INTO #Temp1
	FROM (
		SELECT (TU.UserName) AS ModifiedBy
			,TRN.ModifiedAt AS Deleted
			,TRN.AssessorTemplateID AS ID
			,TRN.AssessorTemplateName AS ItemName
			,'Assessor' AS ItemType
			,TRN.ModifiedBy_NTID AS DeletedBy
		FROM T_TRN_AssessorTemplate TRN WITH (NOLOCK)
		INNER JOIN T_MST_User TU WITH (NOLOCK) ON TRN.ModifiedBy_NTID = TU.NTID
			AND TU.PlantID = @PlantID
		WHERE TRN.IsDeleted = 1
			AND TRN.PlantID = @PlantID
		
		UNION
		
		SELECT (TU.UserName) AS ModifiedBy
			,TRN.ModifiedAt AS Deleted
			,TRN.ValueStreamTemplateID AS ID
			,TRN.ValueStreamTemplateName AS ItemName
			,'Value Stream Template' AS ItemType
			,TRN.ModifiedBy_NTID AS DeletedBy
		FROM T_TRN_ValueStreamTemplate TRN WITH (NOLOCK)
		INNER JOIN T_MST_User TU WITH (NOLOCK) ON TRN.ModifiedBy_NTID = TU.NTID
			AND TU.PlantID = @PlantID
		WHERE TRN.IsDeleted = 1
			AND TRN.PlantID = @PlantID
		
		UNION
		
		SELECT (TU.UserName) AS ModifiedBy
			,TRN.ModifiedAt AS Deleted
			,TRN.QuestionID AS ID
			,TRN.QuestionText AS ItemName
			,'Question' AS ItemType
			,TRN.ModifiedBy_NTID AS DeletedBy
		FROM T_TRN_Question TRN WITH (NOLOCK)
		INNER JOIN T_MST_User TU WITH (NOLOCK) ON TRN.ModifiedBy_NTID = TU.NTID
			AND TU.PlantID = @PlantID
		WHERE TRN.IsDeleted = 1
			AND TRN.PlantID = @PlantID
		
		UNION
		
		SELECT (TU.UserName) AS ModifiedBy
			,TRN.ModifiedAt AS Deleted
			,TRN.TagID AS ID
			,TRN.TagName AS ItemName
			,'Tag' AS ItemType
			,TRN.ModifiedBy_NTID AS DeletedBy
		FROM T_TRN_Tag TRN WITH (NOLOCK)
		INNER JOIN T_MST_User TU WITH (NOLOCK) ON TRN.ModifiedBy_NTID = TU.NTID
			AND TU.PlantID = @PlantID
		WHERE TRN.IsDeleted = 1
			AND TRN.PlantID = @PlantID
		
		UNION
		
		SELECT (TU.UserName) AS ModifiedBy
			,TRN.ModifiedAt AS Deleted
			,TRN.DataPoolID AS ID
			,TRN.Answer AS ItemName
			,'Data Pool' AS ItemType
			,TRN.ModifiedBy_NTID AS DeletedBy
		FROM T_TRN_DataPool TRN WITH (NOLOCK)
		INNER JOIN T_MST_User TU WITH (NOLOCK) ON TRN.ModifiedBy_NTID = TU.NTID
			AND TU.PlantID = @PlantID
		WHERE TRN.IsDeleted = 1
			AND TRN.PlantID = @PlantID
		) AS tbl1

	SELECT ROW_NUMBER() OVER (
			ORDER BY #Temp1.deleted
			) AS RowNumber
		,*
	FROM #Temp1
		--ORDER BY Deleted DESC;
END
GO


