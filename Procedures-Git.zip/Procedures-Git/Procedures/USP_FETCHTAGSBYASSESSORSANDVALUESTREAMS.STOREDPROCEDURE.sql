/*      
///<SUMMARY>      
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchTagsByAssessorsAndValuestreams]    
///AUTHOR                       : JANARTHANAN KRISHNASAMY    
///CREATED DATE                 : 25-NOV-2020    
///SEE ALSO                     : THIS PROCEDURE TO FETCH TAGS BY ASSESSORS AND VALUESTREAMS    
///MODIFICATION HISTORY   :      
************************************************************************************************************     
///REF      DATE    MODIFIED BY     CHANGE DESCRIPTION      
************************************************************************************************************     
ELPC_LH_001     25-NOV-2020   JANARTHANAN KRISHNASAMY  INITIAL VERSION    
ELPC_LH_002     22-MAR-2021   KARTHIKEYAN KANDASAMY  PLANTID ADDED    
ELPC_LH_006     18-AUG-2023   SUSHANTH     GLOBAL TAG  
************************************************************************************************************     
///</SUMMARY>    
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)    
EXEC [USP_FetchTagsByAssessorsAndValuestreams] 1, '1,2,3','4,5,6'    
*/    
CREATE PROCEDURE [USP_FetchTagsByAssessorsAndValuestreams] (    
 @PlantID INT    
 ,@AssessorIDs NVARCHAR(MAX)    
 ,@ValueStreamIDs NVARCHAR(MAX)    
 )    
AS    
BEGIN    
 SET NOCOUNT ON;    
    
 SELECT T.TagID    
  ,T.PlantID    
  ,T.TagDisplayID    
  ,T.TagName    
  ,T.IsSingleQuestionSuppressed    
  ,T.SuppressedDateRangeFrom    
  ,T.SuppressedDateRangeTo    
  ,T.IsTargetFrequencyDefined    
  ,T.TargetFrequencyTypeID    
  ,T.TargetFrequencyValue    
  ,T.Tag_PriorityID    
  ,T.TagTypeID    
  ,T.IsLocked    
  ,T.AnonymizeUserDataSettingID    
  ,T.IsBranchLogicToBeFollowed    
  ,T.IsMandatoryAssessorsDefined    
  ,T.IsDeleted    
  ,T.CreatedAt    
  ,T.ModifiedAt    
  ,T.CreatedBy_NTID    
  ,T.ModifiedBy_NTID   
  -- ,T.Assigned_ValueStreamTemplateID    
  -- ,T.Assigned_ValueStreamCategoryID    
  -- ,T.Assigned_AssessorTemplateID    
  ,CASE     
   WHEN T.TagTypeID = 1    
    THEN COALESCE('#' + T.TagName, '')    
   WHEN T.TagTypeID = 2    
    THEN COALESCE('#' + T.TagName, '')    
   WHEN T.TagTypeID = 3    
    THEN COALESCE('#' + T.TagName, '')   
 WHEN T.TagTypeID = 4    
    THEN COALESCE('#' + T.TagName, '')   
   END AS TagDisplayName   
    ,T.IsSearchableTag 
	,T.IsSkipQuestionDefined
	,T.IsQuestionOverviewDefined
	,T.IsProgressPercentageDefined
	,T.IsResultOverviewDefined
	,T.IsResumeTagDefined
	,T.IsReportingEmailDefined
 FROM T_TRN_Tag T WITH (NOLOCK)    
 WHERE T.PlantID = @PlantID    
  AND TagID IN (    
   SELECT DISTINCT (AR.TagID)    
   FROM T_LNK_Tag_AssignedAssessors AR WITH (NOLOCK)    
   INNER JOIN T_TRN_Tag TG WITH (NOLOCK) ON TG.TagID = AR.TagID    
    AND TG.PlantID = @PlantID    
   INNER JOIN T_LNK_Tag_AssignedValueStreams VS WITH (NOLOCK) ON AR.TagID = VS.TagID    
   WHERE VS.ValueStreamID IN (    
     (    
      SELECT *    
      FROM [fnSplit](@ValueStreamIDs)    
      )    
     )    
    AND (    
     (@AssessorIDs = '0')    
     OR (    
      @AssessorIDs <> '0'    
      AND AR.AssessorID IN (    
       (    
        SELECT *    
        FROM [fnSplit](@AssessorIDs)    
        )    
       )    
      )    
     )    
    AND (AR.IsDeleted = 0)    
    AND (VS.IsDeleted = 0)    
   )    
  AND (    
   T.IsDeleted = 0    
   OR T.IsDeleted IS NULL    
   );    
END 
GO