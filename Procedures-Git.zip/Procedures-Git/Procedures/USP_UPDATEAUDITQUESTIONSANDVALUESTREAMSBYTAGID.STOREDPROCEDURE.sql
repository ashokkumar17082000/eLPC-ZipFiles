/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_UpdateAuditQuestionsAndValueStreamsByTagID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR UPDATING AUDIT QUESTIONS AND VALUESTREAMS BY TAGID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			KARTHIKEYAN K				PLANTID ADDED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_UpdateAuditQuestionsAndValueStreamsByTagID] 1,1
*/
CREATE PROCEDURE [USP_UpdateAuditQuestionsAndValueStreamsByTagID] (
	@PlantID INT
	,@TagID INT
	,@CurrentUserNTID NVARCHAR(20)
	)
AS
BEGIN
	BEGIN TRY
		IF EXISTS (
				SELECT 1
				FROM T_TRN_Audit WITH(NOLOCK)
				WHERE TagID = @TagID
					AND PlantID = @PlantID
				)
		BEGIN
			BEGIN TRANSACTION TRNUPATEAUDITQNVS

			DECLARE @LinkedID INT
				,@min INT = 0
				,@max INT = 0
				,@ID INT = 0;

			--for tagID direct execution-------
			SELECT AuditID AS ID
			INTO #T1
			FROM T_TRN_Audit WITH(NOLOCK)
			WHERE TagID = @TagID
				AND PlantID = @PlantID;

			DECLARE MY_CURSOR CURSOR FORWARD_ONLY
			FOR
			SELECT ID
			FROM #T1

			OPEN MY_CURSOR

			FETCH NEXT
			FROM MY_CURSOR
			INTO @ID

			WHILE @@FETCH_STATUS = 0
			BEGIN
				--PRINT @ID
				EXEC USP_AddQuestionsByAuditID @PlantID
					,@ID
					,@CurrentUserNTID;

				EXEC USP_UpdateAuditAssessorsByAuditID @PlantID
					,@ID
					,@CurrentUserNTID;

				FETCH NEXT
				FROM MY_CURSOR
				INTO @ID
			END

			CLOSE MY_CURSOR

			DEALLOCATE MY_CURSOR

			----------------end of direct tagID execution------------
			SELECT *
			INTO #LinkedTags
			FROM (
				SELECT ROW_NUMBER() OVER (
						ORDER BY TagID
						) AS RowNum
					,*
				FROM T_LNK_Tag_AssignedQuestionsTags WITH(NOLOCK)
				WHERE LinkedTagID = @TagID
					AND (IsDeleted = 0)
				) AS LT

			SELECT *
			FROM #LinkedTags

			IF EXISTS (
					SELECT 1
					FROM #LinkedTags
					)
			BEGIN
				SET @min = (
						SELECT Min(RowNum)
						FROM #LinkedTags
						);--Get minimum row number from temp table
				SET @max = (
						SELECT Max(RowNum)
						FROM #LinkedTags
						);--Get maximum row number from temp table

				WHILE (@min <= @max)
				BEGIN
					SET @LinkedID = (
							SELECT TagID
							FROM #LinkedTags
							WHERE RowNum = @min
							)

					DECLARE MY_CURSOR CURSOR FORWARD_ONLY
					FOR
					SELECT AuditID AS ID
					FROM T_TRN_Audit WITH(NOLOCK)
					WHERE TagID = @LinkedID
						AND PlantID = @PlantID;

					OPEN MY_CURSOR

					FETCH NEXT
					FROM MY_CURSOR
					INTO @ID

					WHILE @@FETCH_STATUS = 0
					BEGIN
						--PRINT @ID
						EXEC USP_AddQuestionsByAuditID @PlantID
							,@ID
							,@CurrentUserNTID;

						EXEC USP_UpdateAuditAssessorsByAuditID @PlantID
							,@ID
							,@CurrentUserNTID;

						FETCH NEXT
						FROM MY_CURSOR
						INTO @ID
					END

					CLOSE MY_CURSOR

					DEALLOCATE MY_CURSOR

					--end
					EXEC [USP_UpdateAuditAnsweredQuestionsByTagID] @PlantID
						,@LinkedID
						,@CurrentUserNTID;

					SET @min = @min + 1 --Increment of current row number
				END
			END

			COMMIT TRANSACTION TRNUPATEAUDITQNVS;
		END
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNUPATEAUDITQNVS;

		EXEC USP_LogError @PlantID
			,@CurrentUserNTID;
	END CATCH
END
GO


