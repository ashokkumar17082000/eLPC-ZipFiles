/****** Object:  StoredProcedure [USP_RestoreLaunchPadSettings]    Script Date: 08.03.2024 09:00:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 
/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_RestoreLaunchPadSettings]
///AUTHOR                       : SHUBHAM BARANGE 
///CREATED DATE                 : 13-FEB-2024
///SEE ALSO                     : THIS PROCEDURE FOR RESTORING LAUNCHPAD HISTORY
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					13-FEB-2024		  SHUBHAM BARANGE	             INITIAL VERSION
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_RestoreLaunchPadSettings] 1 , 1 ,'HBA8KOR'
*/
CREATE PROCEDURE [USP_RestoreLaunchPadSettings](
	 @PlantID INT
	,@HistoryID INT
	,@CurrentUserNTID NVARCHAR(20)
	)
AS
BEGIN
   SET NOCOUNT ON;
UPDATE [T_TRN_LaunchpadSetting]
  SET [IsDeleted]=0
  WHERE [HistoryID]=@HistoryID and [PlantID]=@PlantID
 
  UPDATE [T_TRN_LaunchpadSetting]
  SET [IsDeleted]=1
  WHERE [HistoryID] NOT IN (@HistoryID) and [PlantID]=@PlantID
 
END
GO
