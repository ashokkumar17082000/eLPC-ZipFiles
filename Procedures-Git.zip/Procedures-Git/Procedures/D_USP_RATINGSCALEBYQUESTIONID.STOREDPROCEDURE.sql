/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_RatingScaleByQuestionID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING RATING SACLE BY QUESTIONID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			VENKATESH GOVINDARAJ		PlantID & Code Cleanup
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_RatingScaleByQuestionID] 1
*/
CREATE PROCEDURE [USP_RatingScaleByQuestionID] @QuestionID INT
	,@PlantID INT
AS
BEGIN
	SET NOCOUNT ON;

	SELECT TR.ID
		,TR.NumberRange
		,TR.RangeText1
		,TR.RangeText2
		,TR.RangeText3
		,TR.ShowNA
		,TR.TextNA
		,TR.QuestionID
		,TR.IsDeleted
	FROM T_TRN_RatingScale TR WITH (NOLOCK)
	INNER JOIN T_TRN_QUESTION Q WITH (NOLOCK) ON Q.QuestionID = TR.QuestionID
	WHERE TR.QuestionID = @QuestionID
		AND TR.IsDeleted = 0
		AND Q.PlantID = @PlantID
END
GO