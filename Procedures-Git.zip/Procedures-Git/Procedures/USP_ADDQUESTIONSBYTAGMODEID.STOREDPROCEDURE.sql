/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_AddQuestionsByTagModeID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR ADDING QUESTIONS BY TAG MODE ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					25-MAR-2021			KARTHIKEYAN KANDASAMY		PLANTID ADDED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_AddQuestionsByTagModeID] 1,1,'kkn4cob'
*/
CREATE PROCEDURE [USP_AddQuestionsByTagModeID] (
	@PlantID INT
	,@TagModeID INT
	,@CurrentUserNTID NVARCHAR(20)
	)
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION ADDQUESTIONSBYTAGMODEID

		IF EXISTS (
				SELECT TOP (1) 1
				FROM [T_TRN_TagMode] WITH (NOLOCK)
				WHERE TagModeID = @TagModeID
					AND PlantID = @PlantID
				)
		BEGIN
			DECLARE @TagID INT = 0

			SELECT TOP (1) @TagID = [TagID]
			FROM T_LNK_TagMode_Tags WITH (NOLOCK)
			WHERE TagModeID = @TagModeID

			SELECT DISTINCT QuestionID
			INTO #questionIDs
			FROM [FN_GetNestedQuestionsByTagID](@TagID, @PlantID)

			--Fetch Suppress question not based on TagID
			INSERT INTO [T_LNK_TagMode_Questions] (
				TagModeID
				,QuestionID
				,AnswerTypeID
				)
			SELECT @TagModeID
				,QuestionID
				,AnswerType_AnswerTypeID
			FROM [T_TRN_Question] WITH (NOLOCK)
			WHERE PlantID = @PlantID
				AND QuestionID IN (
					SELECT q.QuestionID
					FROM #questionIDs q
					);
		END

		COMMIT TRANSACTION ADDQUESTIONSBYTAGMODEID;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION ADDQUESTIONSBYTAGMODEID;

		EXEC [USP_LogError] @PlantID
			,@CurrentUserNTID;
	END CATCH
END
GO

