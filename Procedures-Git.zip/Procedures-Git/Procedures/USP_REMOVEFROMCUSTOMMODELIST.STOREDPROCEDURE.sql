/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_RemoveFromCustomModeList]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR REMOVING CUSTOM MODE LIST
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					28-MAR-2021			SIKHESH S					ADDITIONAL PARAMATERS INCLUDED AND RELEATED CHANGES, STANDARD RULES APPLIED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_RemoveFromCustomModeList] 'OSP4KOR', 1
*/
CREATE PROCEDURE [USP_RemoveFromCustomModeList] (
	@NTID NVARCHAR(20)
	,@CustomQuestionTagsID INT
	,@PlantID INT
	,@CurrentUserNTID NVARCHAR(20)
	)
AS
BEGIN
	-- SET NOCOUNT ON ADDED TO PREVENT EXTRA RESULT SETS FROM INTERFERING WITH SELECT STATEMENTS.
	SET NOCOUNT ON;

	DECLARE @CustomModeID INT;

	BEGIN TRY
		BEGIN TRANSACTION REMOVEFROMCUSTOMMODELIST;

		SET @CustomModeID = (
				SELECT TOP 1 CustomModeID
				FROM [T_TRN_CustomMode] WITH (NOLOCK)
				WHERE CreatedBy_NTID = @NTID
					AND PlantID = @PlantID
				)

		DELETE
		FROM [T_LNK_Custom_QuestionsTags]
		WHERE CustomQuestionTagsID = @CustomQuestionTagsID
			AND CustomModeID = @CustomModeID

		DELETE
		FROM [T_LNK_Custom_Questions]
		WHERE CustomQuestionTagsID = @CustomQuestionTagsID
			AND CustomModeID = @CustomModeID

		COMMIT TRANSACTION REMOVEFROMCUSTOMMODELIST;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION REMOVEFROMCUSTOMMODELIST;

		EXEC USP_LogError @PlantID
			,@CurrentUserNTID;
	END CATCH
END
GO


