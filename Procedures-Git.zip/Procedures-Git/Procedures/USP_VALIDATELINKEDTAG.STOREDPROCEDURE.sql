/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_ValidateLinkedTag]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR VALIDATING LINKED TAG
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					22-MAR-2021			KARTHIKEYAN KANDASAMY		PLANTID ADDED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_ValidateLinkedTag] 1, 1
*/
CREATE PROCEDURE [USP_ValidateLinkedTag] (
	@PlantID INT
	,@TagID INT
	)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT ID
	FROM T_LNK_QN_AssignedTags QAT WITH (NOLOCK)
	INNER JOIN T_TRN_Tag T WITH (NOLOCK) ON QAT.TagID = T.TagID
		AND T.PlantID = @PlantID
	WHERE (
			QAT.TagID = @TagID
			AND QAT.IsDeleted = 0
			AND T.IsDeleted = 0
			AND 1 = 0	--Added to skip validaiton
			)
	
	UNION
	
	SELECT ID
	FROM T_LNK_Tag_AssignedQuestionsTags TAT WITH (NOLOCK)
	INNER JOIN T_TRN_Tag T WITH (NOLOCK) ON TAT.TagID = T.TagID
		AND T.PlantID = @PlantID
	WHERE (
			TAT.LinkedTagID = @TagID
			AND TAT.IsDeleted = 0
			AND T.IsDeleted = 0
			AND 1 = 0	--Added to skip validaiton
			);
END
GO


