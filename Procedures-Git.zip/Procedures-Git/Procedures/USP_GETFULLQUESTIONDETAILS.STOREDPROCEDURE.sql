/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_GetFullQuestionDetails]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING FULL QUESTION DETAILS
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			VENKATESH GOVINDARAJ		PLANTID,CURRENTUSERNTID ADDED
ELPC_LH_002					17-DEC-2021			VENKATESH GOVINDARAJ		OPTIMIZED FOR FASTER DATA LOADING
ELPC_LH_006					18-AUG-2023			SUSHANTH		OPTIMIZED FOR FASTER DATA LOADING HIDING COLUMS 
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_GetFullQuestionDetails] 1
*/
CREATE PROCEDURE [USP_GetFullQuestionDetails] @PlantID INT  
AS  
BEGIN  
 SET NOCOUNT ON;  
  
 SELECT (  
   SELECT TOP 1 UserName  
   FROM T_MST_User WITH (NOLOCK)  
   WHERE NTID = Q.ModifiedBy_NTID  
    AND PlantID = @PlantID  
   ) AS ModifiedBy  
  ,(  
   SELECT TOP 1 UserName  
   FROM T_MST_User WITH (NOLOCK)  
   WHERE NTID = Q.CreatedBy_NTID  
    AND PlantID = @PlantID  
   ) AS CreatedBy  
  ,(  
   SELECT TOP 1 PriorityName  
   FROM [T_MST_Priority] WITH (NOLOCK)  
   WHERE PriorityID = Q.Question_PriorityID  
   ) AS PriorityName  
  ,(  
   SELECT TOP 1 TargetFrequencyTypeName  
   FROM T_MST_TargetFrequencyType WITH (NOLOCK)  
   WHERE TargetFrequencyTypeID = Q.TargetFrequencyTypeID  
   ) AS TargetFrequencyTypeName  
  --,(  
  -- SELECT STRING_AGG(CONVERT(NVARCHAR(MAX), ValueStreamID), ',')  
  -- FROM T_TRN_ValueStream WITH (NOLOCK)  
  -- WHERE ValueStreamID IN (  
  --   SELECT DISTINCT ValueStreamID  
  --   FROM T_LNK_AssignedValueStreams WITH (NOLOCK)  
  --   WHERE (IsDeleted = 0)  
  --    AND QuestionID = Q.QuestionID  
  --    AND Q.PlantID = @PlantID  
  --   )  
  --  --AND ValueStreamTemplateID = Q.Assigned_ValueStreamTemplateID  
  --  AND IsDeleted = 0  
  -- ) AS ValueStreamIDList  
  ,null as ValuestreamIDList
  --,(  
  -- SELECT STRING_AGG(CONVERT(NVARCHAR(MAX), AssessorID), ',')  
  -- FROM T_TRN_Assessor WITH (NOLOCK)  
  -- WHERE AssessorID IN (  
  --   SELECT DISTINCT AssessorID  
  --   FROM T_LNK_AssignedAssessors WITH (NOLOCK)  
  --   WHERE (IsDeleted = 0)  
  --    AND QuestionID = Q.QuestionID  
  --    AND Q.PlantID = @PlantID  
  --   )  
  --  --AND AssessorTemplateID = Q.Assigned_AssessorTemplateID  
  --  AND IsDeleted = 0  
  -- ) AS AssessorIDList  
  ,null as AssessorIDList
  --,(  
  -- SELECT ListTag  
  -- FROM [FN_GetNestedTagsByQuestionID](Q.QuestionID, 'strTagName')  
  -- WHERE ListTag IS NOT NULL  
  -- ) AS TagNameList  
  --,(  
  -- SELECT ListTag  
  -- FROM [FN_GetNestedTagsByQuestionID](Q.QuestionID, 'strTagID')  
  -- WHERE ListTag IS NOT NULL  
  -- ) AS TagIDList  
  ,null as TagNameList
  ,null as TagIDList
  ,Q.QuestionID  
  ,Q.PlantID  
  ,Q.QuestionDisplayID  
  ,Q.QuestionText  
  ,Q.QuestionHintText  
  ,Q.AnswerType_AnswerTypeID  
  ,Q.ChoiceDisplayTypeID  
  ,Q.IsFilledInChoiceAllowed  
  ,Q.IsUniqueAnswerRequired  
  ,Q.IsAnswerRequired  
  ,Q.DefaultChoiceID  
  ,Q.IsQuestionAlwaysActive  
  ,Q.ActiveDateRangeFrom  
  ,Q.ActiveDateRangeTo  
  ,Q.IsTargetFrequencyDefined  
  ,Q.TargetFrequencyTypeID  
  ,Q.TargetFrequencyValue  
  ,Q.Question_PriorityID  
  ,Q.IsLocked  
  ,Q.IsDeleted  
  ,Q.CreatedAt  
  ,Q.ModifiedAt  
  ,Q.IsDefaultAnswerRequired  
  ,Q.Assigned_AssessorID  
  ,Q.IsAnswered  
  ,Q.CreatedBy_NTID  
  ,Q.ModifiedBy_NTID  
  ,Q.DefaultChoice  
 FROM T_TRN_Question Q WITH (NOLOCK)  
 WHERE Q.QuestionID IS NOT NULL  
  AND (Q.IsDeleted = 0)  
  AND Q.PlantID = @PlantID  
 ORDER BY Q.ModifiedAt DESC;  
END  
GO