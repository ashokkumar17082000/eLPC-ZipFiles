/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchValueStreamTemplateByTemplateID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING VALUESTREAM TEMPLATE BY TEMPLATE ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					18-MAR-2021			Rajasekar S					PlantId, DisplayId added
ELPC_LH_002					26-MAR-2021			Rajasekar S					@CurrentUserNTID,PlantIDValidation added
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_FetchValueStreamTemplateByTemplateID] 1,1
*/
CREATE PROCEDURE [USP_FetchValueStreamTemplateByTemplateID] @PlantID INT
	,@ValueStreamTemplateID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = @ValueStreamTemplateID
		,@Mode = 'VALUESTREAMTEMPLATE'
		,@CurrentUserNTID = @CurrentUserNTID

	SET NOCOUNT ON;

	SELECT ValueStreamTemplateID
		,PlantID
		,ValueStreamTemplateDisplayID
		,ValueStreamTemplateName
		,IsLocked
		,Delimiter
		,IsOperatedInShifts
		,VisualizationViewModeID
		,ModifiedAt
		,CreatedAt
		,CreatedBy_NTID
		,ModifiedBy_NTID
	FROM T_TRN_ValuestreamTemplate WITH (NOLOCK)
	WHERE PlantID = @PlantID
		AND ValueStreamTemplateID = @ValueStreamTemplateID
END
GO


