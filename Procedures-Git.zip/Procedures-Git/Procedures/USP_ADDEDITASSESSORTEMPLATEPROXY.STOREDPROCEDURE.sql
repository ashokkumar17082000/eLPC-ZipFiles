/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_AddEditAssessorTemplateProxy]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE TO ADD AND EDIT ASSESSOR TEMPLATE PROXY 
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					17-MAR-2021			KARTHIKEYAN KANDASAMY		PLANTID ADDED
ELPC_LH_002					18-MAR-2021			RAJASEKAR S					REPLACED TRIGGERS
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
EXEC [USP_AddEditAssessorTemplateProxy] 1,1,1,'kkn4cob','kkn4cob',<<XML>>,1
*/
CREATE PROCEDURE [USP_AddEditAssessorTemplateProxy] (
	@PlantID INT
	,@ID INT
	,@AssessorTemplateID INT
	,@Proxies XML NULL
	,@IsLocked BIT NULL
	,@CurrentUserNTID NVARCHAR(20)
	)
AS
BEGIN
	BEGIN TRY
		--Inputs filed variable for triggers
		DECLARE @Scope_Identity_Table_Trigger TABLE (id INT);--Scope identities for all inserted rows
		DECLARE @Input_Ids_Trigger VARCHAR(MAX);
		DECLARE @TableName_Trigger VARCHAR(100);
		DECLARE @ActionType VARCHAR(10);

		BEGIN TRANSACTION TRNADDEDITASSESSORPROXY

		IF (@IsLocked = 1)
		BEGIN
			SELECT @ID AS ID
				,@AssessorTemplateID AS AssessorTemplateID
				,@CurrentUserNTID AS ModifiedBy_NTID
				,@CurrentUserNTID AS CreatedBy_NTID
				,Proxie.value('(NTID/text())[1]', 'NVARCHAR(20)') AS Proxy
			INTO #T1
			FROM @Proxies.nodes('/ArrayOfUser/User') AS TEMPTABLE(Proxie)
			WHERE (
					@ID IS NOT NULL
					AND @ID != 0
					);

			DELETE
			FROM @Scope_Identity_Table_Trigger

			INSERT INTO @Scope_Identity_Table_Trigger
			SELECT ID
			FROM T_LNK_Assessor_Proxy WITH(NOLOCK)
			WHERE ID NOT IN (
					SELECT ID
					FROM #T1
					)
				AND AssessorTemplateID = @AssessorTemplateID;

			UPDATE T_LNK_Assessor_Proxy
			SET IsDeleted = 1
			WHERE ID IN (
					SELECT id
					FROM @Scope_Identity_Table_Trigger
					);

			SELECT @TableName_Trigger = 'Assessor_Proxy'
				,@ActionType = 'U'
				,@Input_Ids_Trigger = (
					SELECT CAST(id AS VARCHAR(MAX)) + ', '
					FROM @Scope_Identity_Table_Trigger
					FOR XML PATH('')
					);

			EXEC [USP_ASSESSOR_HISTORY] @PlantID = @PlantID
				,@CurrentUserNTID = @CurrentUserNTID
				,@TableName = @TableName_Trigger
				,@AssessorTemplateHistoryID = NULL
				,@ActionType = @ActionType
				,@INPUT_IDS = @Input_Ids_Trigger;

			UPDATE T_TRN_AssessorTemplate
			SET IsLocked = 1
			WHERE AssessorTemplateID = @AssessorTemplateID
				AND PlantID = @PlantID;

			--select @TableName_Trigger='AssessorTemplate',
			--@ActionType='U',
			--@Input_Ids_Trigger=@AssessorTemplateID;
			--Exec [USP_ASSESSOR_HISTORY] 
			--	@PlantID=@PlantID
			--	,@CurrentUserNTID=@CurrentUserNTID
			--	,@TableName=@TableName_Trigger
			--	,@AssessorTemplateHistoryID=NULL 
			--	,@ActionType=@ActionType
			--	,@INPUT_IDS=@Input_Ids_Trigger;
			DELETE
			FROM @Scope_Identity_Table_Trigger

			INSERT INTO T_LNK_Assessor_Proxy (
				AssessorTemplateID
				,ModifiedBy_NTID
				,CreatedBy_NTID
				,Proxy
				)
			OUTPUT inserted.ID
			INTO @Scope_Identity_Table_Trigger
			SELECT @AssessorTemplateID AS AssessorTemplateID
				,@CurrentUserNTID AS ModifiedBy_NTID
				,@CurrentUserNTID AS CreatedBy_NTID
				,Proxie.value('(NTID/text())[1]', 'NVARCHAR(20)') AS Proxy
			FROM @Proxies.nodes('/ArrayOfUser/User') AS TEMPTABLE(Proxie);

			SELECT @TableName_Trigger = 'Assessor_Proxy'
				,@ActionType = 'I'
				,@Input_Ids_Trigger = (
					SELECT CAST(id AS VARCHAR(MAX)) + ', '
					FROM @Scope_Identity_Table_Trigger
					FOR XML PATH('')
					);

			EXEC [USP_ASSESSOR_HISTORY] @PlantID = @PlantID
				,@CurrentUserNTID = @CurrentUserNTID
				,@TableName = @TableName_Trigger
				,@AssessorTemplateHistoryID = NULL
				,@ActionType = @ActionType
				,@INPUT_IDS = @Input_Ids_Trigger;

			EXEC USP_AddEditusers @PlantID
				,@CurrentUserNTID
				,@Proxies;
		END
		ELSE
		BEGIN
			UPDATE T_TRN_AssessorTemplate
			SET IsLocked = 0
			WHERE AssessorTemplateID = @AssessorTemplateID
				AND PlantID = @PlantID;
				--select @TableName_Trigger='AssessorTemplate',
				--@ActionType='U',
				--@Input_Ids_Trigger=@AssessorTemplateID;
				--Exec [USP_ASSESSOR_HISTORY] 
				--	@PlantID=@PlantID
				--	,@CurrentUserNTID=@CurrentUserNTID
				--	,@TableName=@TableName_Trigger
				--	,@AssessorTemplateHistoryID=NULL 
				--	,@ActionType=@ActionType
				--	,@INPUT_IDS=@Input_Ids_Trigger;
		END

		COMMIT TRANSACTION TRNADDEDITASSESSORPROXY;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNADDEDITASSESSORPROXY;

		EXEC [USP_LogError] @PlantID
			,@CurrentUserNTID;
	END CATCH
END
GO


