/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_CurrencySettingsByQuestionID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING CURRENCY SETTINGS BY QUESTION ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_CurrencySettingsByQuestionID] 1
*/
CREATE PROCEDURE [USP_CurrencySettingsByQuestionID] @QuestionID INT
AS
BEGIN
	SELECT *
	FROM T_TRN_AnswerTypeCurrency
	WHERE QuestionID = @QuestionID
		AND (IsDeleted = 0)
END
GO


