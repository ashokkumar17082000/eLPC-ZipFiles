/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_InsertUser]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE TO INSERT USER
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					25-MAR-2021			SIKHESH S					ADDITIONAL PARAMATERS INCLUDED AND RELEATED CHANGES, STANDARD RULES APPLIED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_InsertUser] 'Sikhesh Sekharan (RBEI/BSA4)',1,'Sikhesh.Sekharan@in.bosch.com','SSE4COB','Sekharan','Sikhesh', 1, 'SSE4COB'

SELECT * FROM [T_MST_User]
*/
CREATE PROCEDURE [USP_InsertUser] @UserName NVARCHAR(200) NULL
	,@RoleID INT
	,@EmailAddress NVARCHAR(200) NULL
	,@NTID NVARCHAR(20) NULL
	,@FirstName NVARCHAR(100) NULL
	,@LastName NVARCHAR(100) NULL
	,@PlantID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	BEGIN TRY
		IF NOT EXISTS (
				SELECT NTID
				FROM T_MST_User WITH(NOLOCK)
				WHERE NTID = @NTID
					AND PlantID = @PlantID
				)
		BEGIN
			INSERT INTO T_MST_User (
				PlantID
				,UserName
				,Role_RoleID
				,EmailAddress
				,NTID
				,FirstName
				,LastName
				,ModifiedAt
				)
			VALUES (
				@PlantID
				,@UserName
				,@RoleID
				,@EmailAddress
				,@NTID
				,@FirstName
				,@LastName
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
				)
		END
		ELSE
		BEGIN
			UPDATE T_MST_User
			SET UserName = @UserName
				,EmailAddress = @EmailAddress
				,FirstName = @FirstName
				,LastName = @LastName
				,Role_RoleID = @RoleID
				,ModifiedAt = (
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
			WHERE NTID = @NTID
				AND PlantID = @PlantID
		END
	END TRY

	BEGIN CATCH
		EXEC USP_LogError @PlantID
			,@CurrentUserNTID;
	END CATCH
END
GO


