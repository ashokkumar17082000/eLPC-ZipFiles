/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_TagTemplateHistory] 
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING TAG TEMPLATE HISTORY
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					22-MAR-2021			KARTHIKEYAN KANDASAMY		PLANTID ADDED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_TagTemplateHistory]  1, 1
*/
CREATE PROCEDURE [USP_TagTemplateHistory] (
	@PlantID INT
	,@TagID INT
	)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT (TU.UserName) AS ModifiedBy
		,TH.TagHistoryID
		,TH.PlantID
		,TH.TagID
		,TH.TagDisplayID
		,TH.TagHistoryDisplayID
		,TH.TagName
		,TH.IsSingleQuestionSuppressed
		,TH.SuppressedDateRangeFrom
		,TH.SuppressedDateRangeTo
		,TH.IsTargetFrequencyDefined
		,TH.TargetFrequencyTypeID
		,TH.TargetFrequencyValue
		,TH.Tag_PriorityID
		,TH.TagTypeID
		,TH.IsLocked
		,TH.AnonymizeUserDataSettingID
		,TH.IsBranchLogicToBeFollowed
		,TH.IsMandatoryAssessorsDefined
		,TH.IsDeleted
		,TH.CreatedAt
		,TH.ModifiedAt
		,TH.ActionType
		,TH.ActionAt
		-- ,TH.Assigned_ValueStreamTemplateID
		-- ,TH.Assigned_ValueStreamCategoryID
		-- ,TH.Assigned_AssessorTemplateID
		,TH.CreatedBy_NTID
		,TH.ModifiedBy_NTID
		,TU.UserID
		,TU.UserName
		,TU.Role_RoleID
		,TU.EmployeeID
		,TU.EmailAddress
		,TU.NTID
		,TU.FirstName
		,TU.LastName
	FROM [T_TRN_TagHistory] TH WITH (NOLOCK)
	INNER JOIN T_MST_User TU WITH (NOLOCK) ON TH.ModifiedBy_NTID = TU.NTID
		AND TU.PlantID = @PlantID
	WHERE TagID = @TagID
		AND TH.PlantID = @PlantID
	ORDER BY TH.TagHistoryDisplayID DESC
END
GO

