/*  
--///<SUMMARY>  
--///DESCRIPTION                  : STORE PROCEDURE - [USP_UpdateUserProfileVSAS]
--///AUTHOR                       : VENKATESH
--///CREATED DATE                 : 16-JUN-2021 
--///SEE ALSO                     : THIS PROCEDURE IS USED FOR UPDATE USER PROFILE DETAILS FOR VALUESTREAM AND ASSESSORS BY TEMPLATEID
--///MODIFICATION HISTORY		  :  
--///************************************************************************************************************/  
--///REF							DATE				    MODIFIED BY				CHANGE DESCRIPTION  
--///************************************************************************************************************/  
--///eLPC_LH_002					16-JUN-2021    			VENKATESH				INITIAL VERSION
--///************************************************************************************************************/  
--///</SUMMARY>

----SAMPLE EXECUTION
--EXEC [USP_UpdateUserProfileVSAS] 21,'EGV1COB',NULL
*/
CREATE PROCEDURE [USP_UpdateUserProfileVSAS] (
	@PlantID INT
	,@UserProfileVSAS XML NULL
	,@CurrentUserNTID NVARCHAR(20)
	)
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION TRNUPATEUSERVSAS

		DECLARE @min INT = 0
			,@max INT = 0
		DECLARE @Scope_Identity_Table_VS TABLE (UserProfileValueStreamID INT);--Scope identities for all inserted rows
		DECLARE @Scope_Identity_Table_AS TABLE (UserProfileAssessorID INT);--Scope identities for all inserted rows

		SELECT Identity(INT, 1, 1) AS ID
			,VSAS.value('(ValueStreamTemplateID/text())[1]', 'INT') AS ValueStreamTemplateID
			,VSAS.value('(ValueStreamID/text())[1]', 'INT') AS ValueStreamID
			,VSAS.value('(IsForgotValueStream/text())[1]', 'BIT') AS IsForgotValueStream
			,VSAS.value('(AssessorTemplateID/text())[1]', 'INT') AS AssessorTemplateID
			,VSAS.value('(AssessorID/text())[1]', 'INT') AS AssessorID
			,VSAS.value('(IsForgotAssessor/text())[1]', 'BIT') AS IsForgotAssessor
			,VSAS.value('(SessionID/text())[1]', 'NVARCHAR(20)') AS SessionID
		INTO #T1
		FROM @UserProfileVSAS.nodes('/UserProfileUpdateVSAS') AS TEMPTABLE(VSAS);

		--select * from #T1
		--select * from #T2
		IF @UserProfileVSAS IS NOT NULL
		BEGIN
			SET @min = (
					SELECT MIN(ID)
					FROM #T1
					);--Get minimum row number from temp table
			SET @max = (
					SELECT Max(ID)
					FROM #T1
					);--Get maximum row number from temp table

			WHILE (@min <= @max)
			BEGIN
				DECLARE @ValueStreamTemplateID INT
					,@ValueStreamID INT
					,@IsForgotValueStream BIT
					,@AssessorTemplateID INT
					,@AssessorID INT
					,@IsForgotAssessor BIT
					,@SessionID NVARCHAR(20)

				SELECT @ValueStreamTemplateID = ValueStreamTemplateID
					,@ValueStreamID = ValueStreamID
					,@IsForgotValueStream = IsForgotValueStream
					,@AssessorTemplateID = AssessorTemplateID
					,@AssessorID = AssessorID
					,@IsForgotAssessor = IsForgotAssessor
					,@SessionID = SessionID
				FROM #T1
				WHERE ID = @min;

				IF EXISTS (
						SELECT TOP (1) 1
						FROM T_TRN_ValueStreamConfig WITH (NOLOCK)
						WHERE ValueStreamTemplateID = @ValueStreamTemplateID
							AND User_NTID = @CurrentUserNTID
							AND PlantID = @PlantID
						)
				BEGIN
					-- Update the Assessor data if that exists
					UPDATE T_TRN_ValueStreamConfig
					SET ValueStreamID = @ValueStreamID
						,IsForgotValueStream = @IsForgotValueStream
						,SessionID = @SessionID
						,IsDeleted = 0
						,ModifiedAt = (
							SELECT FormattedDateTime
							FROM fnGetDateTime(@PlantID)
							)
					WHERE ValueStreamTemplateID = @ValueStreamTemplateID
						AND User_NTID = @CurrentUserNTID
						AND PlantID = @PlantID
				END

				SET @min = @min + 1;
			END

			IF EXISTS (
					SELECT TOP (1) 1
					FROM T_TRN_AssessorConfig WITH (NOLOCK)
					WHERE AssessorTemplateID = @AssessorTemplateID
						AND User_NTID = @CurrentUserNTID
						AND PlantID = @PlantID
					)
			BEGIN
				-- Update the Assessor data if that exists
				UPDATE T_TRN_AssessorConfig
				SET AssessorID = @AssessorID
					,IsForgotAssessor = @IsForgotAssessor
					,SessionID = @SessionID
					,IsDeleted = 0
					,ModifiedAt = (
						SELECT FormattedDateTime
						FROM fnGetDateTime(@PlantID)
						)
				WHERE AssessorTemplateID = @AssessorTemplateID
					AND User_NTID = @CurrentUserNTID
					AND PlantID = @PlantID
			END
		END

		COMMIT TRANSACTION TRNUPATEUSERVSAS;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNUPATEUSERVSAS;

		EXEC [USP_LogError] @PlantID
			,@CurrentUserNTID;
	END CATCH
END
GO

