/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchValueStream]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING VALUESTREAM
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					18-MAR-2021			Rajasekar S					PlantId, DisplayId, 'set NOCOUNT ON' added. * expanded
ELPC_LH_002					14-JULY-2022		SHUBHAM BARANGE				Data redundacy via ValueStream Datacondition added
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_FetchValueStream]
*/
CREATE PROCEDURE [USP_FetchValueStream] @PlantID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = 0
		,@Mode = 'VALUESTREAMTEMPLATE'
		,@CurrentUserNTID = @CurrentUserNTID

	SET NOCOUNT ON;

	SELECT DISTINCT VS.ValueStreamID
		,VS.Responsible_UserID
		,VS.ResponsibleEmployee
		,VS.ValueStreamTemplateID
		,VS.ValueStreamCategoryID
		,VS.ValueStreamData
		,VSC.ValueStreamCategoryName
		,VS.NodeID
		,VS.RowID
		,VST.ValueStreamTemplateName
		,VST.Delimiter
		,NULL ResponsibleEmployeeID
		,VS.ValueStreamName
		,VS.ParentId
	FROM T_TRN_ValueStream VS WITH (NOLOCK)
	INNER JOIN T_TRN_ValueStreamTemplate VST WITH (NOLOCK) ON VST.ValueStreamTemplateID = VS.ValueStreamTemplateID
	INNER JOIN T_TRN_ValueStreamCategory VSC WITH (NOLOCK) ON VSC.ValueStreamCategoryID = VS.ValueStreamCategoryID
	WHERE (
			VST.PlantID = @PlantID
			AND VS.IsDeleted = 0
			)
		AND VS.Responsible_UserID IS NOT NULL
		AND valueStreamName <> ''
		AND VST.IsDeleted = 0
		AND VS.ValueStreamData=''
	ORDER BY VST.ValueStreamTemplateName
		,VS.ValueStreamName
END
GO
