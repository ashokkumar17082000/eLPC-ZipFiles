/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_Restore_T_TRN_QuestionHistory]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RESTORING QUESTION HISTORY
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			VENKATESH GOVINDARAJ		PlantID & Code Cleanup
ELPC_LH_003					26-07-2021			MONASH CHHETRI				AnswerCategory Column added

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_Restore_T_TRN_QuestionHistory] 1
*/
CREATE PROCEDURE [USP_Restore_T_TRN_QuestionHistory] @QuestionHistoryID INT
	,@PlantID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRANSACTION TRNRESTOREQNHISTORY;

	--to disable the history after restoring history
	--ALTER TABLE [T_TRN_Question] DISABLE TRIGGER [TR_HISTORYFOR_T_TRN_Question]
	--ALTER TABLE [T_TRN_HintImage] DISABLE TRIGGER [TR_HISTORYFOR_T_TRN_HintImage]
	--ALTER TABLE [T_TRN_HintHyperLink] DISABLE TRIGGER [TR_HISTORYFOR_T_TRN_HintHyperLink]
	--ALTER TABLE [T_LNK_AssignedValueStreams] DISABLE TRIGGER [TR_HISTORYFOR_T_LNK_AssignedValueStreams]
	--ALTER TABLE [T_LNK_AssignedAssessors] DISABLE TRIGGER [TR_HISTORYFOR_T_LNK_AssignedAssessors]
	--ALTER TABLE [T_LNK_QN_AssignedTags] DISABLE TRIGGER [TR_HISTORYFOR_T_LNK_QN_AssignedTags]
	--ALTER TABLE [T_TRN_SingleLineText] DISABLE TRIGGER [TR_HISTORYFOR_T_TRN_SingleLineText]
	--ALTER TABLE [T_TRN_MultipleLinesText] DISABLE TRIGGER [TR_HISTORYFOR_T_TRN_MultipleLinesText]
	--ALTER TABLE [T_TRN_Choice] DISABLE TRIGGER [TR_HISTORYFOR_T_TRN_Choice]
	BEGIN TRY
		IF EXISTS (
				SELECT TOP 1 QuestionHistoryID
				FROM [T_TRN_QuestionHistory] WITH (NOLOCK)
				WHERE QuestionHistoryID = @QuestionHistoryID
					AND PlantID = @PlantID
				)
		BEGIN
			-- Update [T_TRN_Question]
			DECLARE @QuestionID INT;
			DECLARE @QuestionText NVARCHAR(MAX);
			DECLARE @QuestionHintText NVARCHAR(max);
			DECLARE @AnswerType_AnswerTypeID INT;
			DECLARE @ChoiceDisplayTypeID INT;
			DECLARE @IsFilledInChoiceAllowed BIT;
			DECLARE @IsUniqueAnswerRequired BIT;
			DECLARE @IsAnswerRequired BIT;
			DECLARE @DefaultChoiceID INT;
			DECLARE @IsQuestionAlwaysActive BIT;
			DECLARE @ActiveDateRangeFrom DATETIME;
			DECLARE @ActiveDateRangeTo DATETIME;
			DECLARE @IsTargetFrequencyDefined BIT;
			DECLARE @TargetFrequencyTypeID INT;
			DECLARE @TargetFrequencyValue NVARCHAR(50);
			DECLARE @Question_PriorityID INT;
			DECLARE @IsLocked BIT;
			-- DECLARE @Assigned_ValueStreamTemplateID INT;
			-- DECLARE @Assigned_ValueStreamCategoryID INT;
			-- DECLARE @Assigned_AssessorTemplateID INT;
			DECLARE @IsDeleted BIT;
			DECLARE @CreatedAt DATETIME;
			DECLARE @ModifiedAt DATETIME;
			DECLARE @IsDefaultAnswerRequired BIT;
			DECLARE @Assigned_AssessorID INT;
			DECLARE @IsAnswered BIT;
			DECLARE @CreatedBy_NTID NVARCHAR(20);
			DECLARE @ModifiedBy_NTID NVARCHAR(20) = @CurrentUserNTID;;

			SELECT TOP 1 @QuestionID = QuestionID
				,@QuestionText = QuestionText
				,@QuestionHintText = QuestionHintText
				,@AnswerType_AnswerTypeID = AnswerType_AnswerTypeID
				,@ChoiceDisplayTypeID = ChoiceDisplayTypeID
				,@IsFilledInChoiceAllowed = IsFilledInChoiceAllowed
				,@IsUniqueAnswerRequired = IsUniqueAnswerRequired
				,@IsAnswerRequired = IsAnswerRequired
				,@DefaultChoiceID = DefaultChoiceID
				,@IsQuestionAlwaysActive = IsQuestionAlwaysActive
				,@ActiveDateRangeFrom = ActiveDateRangeFrom
				,@ActiveDateRangeTo = ActiveDateRangeTo
				,@IsTargetFrequencyDefined = IsTargetFrequencyDefined
				,@TargetFrequencyTypeID = TargetFrequencyTypeID
				,@TargetFrequencyValue = TargetFrequencyValue
				,@Question_PriorityID = Question_PriorityID
				,@IsLocked = IsLocked
				-- ,@Assigned_ValueStreamTemplateID = Assigned_ValueStreamTemplateID
				-- ,@Assigned_ValueStreamCategoryID = Assigned_ValueStreamCategoryID
				-- ,@Assigned_AssessorTemplateID = Assigned_AssessorTemplateID
				,@IsDeleted = IsDeleted
				,@CreatedAt = CreatedAt
				,@ModifiedAt = ModifiedAt
				,@IsDefaultAnswerRequired = IsDefaultAnswerRequired
				,@Assigned_AssessorID = Assigned_AssessorID
				,@IsAnswered = IsAnswered
				,@CreatedBy_NTID = CreatedBy_NTID
			FROM T_TRN_QuestionHistory WITH (NOLOCK)
			WHERE @QuestionHistoryID = QuestionHistoryID
				AND PlantID = @PlantID;

			UPDATE [T_TRN_Question]
			SET QuestionText = @QuestionText
				,QuestionHintText = @QuestionHintText
				,AnswerType_AnswerTypeID = @AnswerType_AnswerTypeID
				,ChoiceDisplayTypeID = @ChoiceDisplayTypeID
				,IsFilledInChoiceAllowed = @IsFilledInChoiceAllowed
				,IsUniqueAnswerRequired = @IsUniqueAnswerRequired
				,IsAnswerRequired = @IsAnswerRequired
				,DefaultChoiceID = @DefaultChoiceID
				,IsQuestionAlwaysActive = @IsQuestionAlwaysActive
				,ActiveDateRangeFrom = @ActiveDateRangeFrom
				,ActiveDateRangeTo = @ActiveDateRangeTo
				,IsTargetFrequencyDefined = @IsTargetFrequencyDefined
				,TargetFrequencyTypeID = @TargetFrequencyTypeID
				,TargetFrequencyValue = @TargetFrequencyValue
				,Question_PriorityID = @Question_PriorityID
				,IsLocked = @IsLocked
				-- ,Assigned_ValueStreamTemplateID = @Assigned_ValueStreamTemplateID
				-- ,Assigned_ValueStreamCategoryID = @Assigned_ValueStreamCategoryID
				-- ,Assigned_AssessorTemplateID = @Assigned_AssessorTemplateID
				,IsDeleted = @IsDeleted
				,CreatedAt = @CreatedAt
				,ModifiedAt = @ModifiedAt
				,IsDefaultAnswerRequired = @IsDefaultAnswerRequired
				,Assigned_AssessorID = @Assigned_AssessorID
				,IsAnswered = @IsAnswered
				,CreatedBy_NTID = @CreatedBy_NTID
				,ModifiedBy_NTID = @ModifiedBy_NTID
			WHERE QuestionID = @QuestionID
				AND PlantID = @PlantID;

			--END - Update [T_TRN_Question]
			-- Update [T_TRN_HintImage]
			DECLARE @ID [int];
			DECLARE @ImageTitle [nvarchar] (max);
			DECLARE @ImagePath [nvarchar] (max);
			DECLARE @FileContent [varbinary] (max);

			SET @IsDeleted = 0;

			-- Soft deletes the data based on the history ID
			UPDATE T_TRN_HintImage
			SET IsDeleted = 1
			WHERE QuestionID = @QuestionID
				AND ID NOT IN (
					SELECT ID
					FROM [T_TRN_HintImageHistory] WITH (NOLOCK)
					WHERE (
							IsDeleted IS NULL
							OR IsDeleted = 0
							)
						AND QuestionHistoryID = @QuestionHistoryID
					);

			DECLARE CUR_HistoryRows CURSOR FORWARD_ONLY
			FOR
			SELECT ID
				,QuestionID
				,ImageTitle
				,ImagePath
				,
				--FileContent	,to reduce data storage
				IsDeleted
			FROM [T_TRN_HintImageHistory] WITH (NOLOCK)
			WHERE QuestionHistoryID = @QuestionHistoryID;

			OPEN CUR_HistoryRows;

			FETCH NEXT
			FROM CUR_HistoryRows
			INTO @ID
				,@QuestionID
				,@ImageTitle
				,@ImagePath
				,
				--@FileContent,to reduce data storage
				@IsDeleted;

			WHILE @@FETCH_STATUS = 0
			BEGIN
				IF EXISTS (
						SELECT ID
						FROM T_TRN_HintImage WITH (NOLOCK)
						WHERE ID = @ID
						)
				BEGIN
					-- Update the main table data if that exists in history
					UPDATE T_TRN_HintImage
					SET QuestionID = @QuestionID
						,ImageTitle = @ImageTitle
						,ImagePath = @ImagePath
						,
						--FileContent	= @FileContent	,to reduce data storage
						IsDeleted = @IsDeleted
					WHERE ID = @ID;
				END
				ELSE
				BEGIN
					-- Insert to the main table if that not exists(may be removed)
					INSERT INTO T_TRN_HintImage (
						QuestionID
						,ImageTitle
						,ImagePath
						,
						--FileContent,to reduce data storage
						IsDeleted
						)
					VALUES (
						@QuestionID
						,@ImageTitle
						,@ImagePath
						,
						--@FileContent,to reduce data storage
						@IsDeleted
						);
				END

				FETCH NEXT
				FROM CUR_HistoryRows
				INTO @ID
					,@QuestionID
					,@ImageTitle
					,@ImagePath
					,
					--@FileContent,to reduce data storage
					@IsDeleted;
			END

			CLOSE CUR_HistoryRows;

			DEALLOCATE CUR_HistoryRows;

			-- END - Update [T_TRN_HintImage]
			-- Update [T_TRN_HintHyperLink]
			SET @ID = 0;

			DECLARE @HyperLinkTitle [nvarchar] (50);
			DECLARE @HyperLinkURL [nvarchar] (500);

			SET @IsDeleted = 0;

			-- Soft deletes the data based on the history ID
			UPDATE T_TRN_HintHyperLink
			SET IsDeleted = 1
			WHERE QuestionID = @QuestionID
				AND ID NOT IN (
					SELECT ID
					FROM [T_TRN_HintHyperLinkHistory] WITH (NOLOCK)
					WHERE (
							IsDeleted IS NULL
							OR IsDeleted = 0
							)
						AND QuestionHistoryID = @QuestionHistoryID
					);

			DECLARE CUR_HistoryRows CURSOR FORWARD_ONLY
			FOR
			SELECT ID
				,QuestionID
				,HyperLinkTitle
				,HyperLinkURL
				,IsDeleted
			FROM [T_TRN_HintHyperLinkHistory] WITH (NOLOCK)
			WHERE QuestionHistoryID = @QuestionHistoryID;

			OPEN CUR_HistoryRows;

			FETCH NEXT
			FROM CUR_HistoryRows
			INTO @ID
				,@QuestionID
				,@HyperLinkTitle
				,@HyperLinkURL
				,@IsDeleted;

			WHILE @@FETCH_STATUS = 0
			BEGIN
				IF EXISTS (
						SELECT ID
						FROM T_TRN_HintHyperLink WITH (NOLOCK)
						WHERE ID = @ID
						)
				BEGIN
					-- Update the main table data if that exists in history
					UPDATE T_TRN_HintHyperLink
					SET QuestionID = @QuestionID
						,HyperLinkTitle = @HyperLinkTitle
						,HyperLinkURL = @HyperLinkURL
						,IsDeleted = @IsDeleted
					WHERE ID = @ID;
				END
				ELSE
				BEGIN
					-- Insert to the main table if that not exists(may be removed)
					INSERT INTO T_TRN_HintHyperLink (
						QuestionID
						,HyperLinkTitle
						,HyperLinkURL
						,IsDeleted
						)
					VALUES (
						@QuestionID
						,@HyperLinkTitle
						,@HyperLinkURL
						,@IsDeleted
						);
				END

				FETCH NEXT
				FROM CUR_HistoryRows
				INTO @ID
					,@QuestionID
					,@HyperLinkTitle
					,@HyperLinkURL
					,@IsDeleted;
			END

			CLOSE CUR_HistoryRows;

			DEALLOCATE CUR_HistoryRows;

			-- END - [T_TRN_HintHyperLink]
			-- Update [T_LNK_AssignedAssessors]
			SET @ID = 0;

			DECLARE @AssessorID INT;
			DECLARE @TargetFrequencyValue20 [nvarchar] (10);

			SET @TargetFrequencyTypeID = 0;
			SET @IsDeleted = 0;

			-- Soft deletes the data based on the history ID
			UPDATE T_LNK_AssignedAssessors
			SET IsDeleted = 1
			WHERE QuestionID = @QuestionID
				AND AssessorID NOT IN (
					SELECT AssessorID
					FROM T_LNK_AssignedAssessorsHistory WITH (NOLOCK)
					WHERE (
							IsDeleted IS NULL
							OR IsDeleted = 0
							)
						AND QuestionHistoryID = @QuestionHistoryID
					);

			DECLARE CUR_HistoryRows CURSOR FORWARD_ONLY
			FOR
			SELECT ID
				,QuestionID
				,AssessorID
				,TargetFrequencyValue
				,TargetFrequencyTypeID
				,IsDeleted
			FROM [T_LNK_AssignedAssessorsHistory] WITH (NOLOCK)
			WHERE QuestionHistoryID = @QuestionHistoryID;

			OPEN CUR_HistoryRows;

			FETCH NEXT
			FROM CUR_HistoryRows
			INTO @ID
				,@QuestionID
				,@AssessorID
				,@TargetFrequencyValue20
				,@TargetFrequencyTypeID
				,@IsDeleted;

			WHILE @@FETCH_STATUS = 0
			BEGIN
				IF EXISTS (
						SELECT ID
						FROM T_LNK_AssignedAssessors WITH (NOLOCK)
						WHERE ID = @ID
						)
				BEGIN
					-- Update the main table data if that exists in history
					UPDATE T_LNK_AssignedAssessors
					SET QuestionID = @QuestionID
						,AssessorID = @AssessorID
						,TargetFrequencyValue = @TargetFrequencyValue20
						,TargetFrequencyTypeID = @TargetFrequencyTypeID
						,IsDeleted = @IsDeleted
					WHERE ID = @ID;
				END
				ELSE
				BEGIN
					-- Insert to the main table if that not exists(may be removed)
					INSERT INTO T_LNK_AssignedAssessors (
						QuestionID
						,AssessorID
						,TargetFrequencyValue
						,TargetFrequencyTypeID
						,IsDeleted
						)
					VALUES (
						@QuestionID
						,@AssessorID
						,@TargetFrequencyValue20
						,@TargetFrequencyTypeID
						,@IsDeleted
						);
				END

				FETCH NEXT
				FROM CUR_HistoryRows
				INTO @ID
					,@QuestionID
					,@AssessorID
					,@TargetFrequencyValue20
					,@TargetFrequencyTypeID
					,@IsDeleted;
			END

			CLOSE CUR_HistoryRows;

			DEALLOCATE CUR_HistoryRows;

			-- END - [T_LNK_AssignedAssessors]
			-- Update [T_LNK_AssignedTargetFrequency]
			SET @ID = 0;
			SET @TargetFrequencyValue = 0;
			SET @TargetFrequencyTypeID = 0;
			SET @IsDeleted = 0;

			--soft deletes based on Question History ID
			UPDATE T_LNK_AssignedTargetFrequency
			SET IsDeleted = 1
			WHERE QuestionID = @QuestionID
				AND ID NOT IN (
					SELECT ID
					FROM [T_LNK_AssignedTargetFrequencyHistory] WITH (NOLOCK)
					WHERE (
							IsDeleted IS NULL
							OR IsDeleted = 0
							)
						AND QuestionHistoryID = @QuestionHistoryID
					);

			DECLARE CUR_HistoryRows CURSOR FORWARD_ONLY
			FOR
			SELECT ID
				,QuestionID
				,TargetFrequencyValue
				,TargetFrequencyTypeID
				,IsDeleted
			FROM [T_LNK_AssignedTargetFrequencyHistory] WITH (NOLOCK)
			WHERE QuestionHistoryID = @QuestionHistoryID;

			OPEN CUR_HistoryRows;

			FETCH NEXT
			FROM CUR_HistoryRows
			INTO @ID
				,@QuestionID
				,@TargetFrequencyValue
				,@TargetFrequencyTypeID
				,@IsDeleted;

			WHILE @@FETCH_STATUS = 0
			BEGIN
				IF EXISTS (
						SELECT ID
						FROM T_LNK_AssignedTargetFrequency WITH (NOLOCK)
						WHERE ID = @ID
						)
				BEGIN
					-- Update the main table data if that exists in history
					UPDATE T_LNK_AssignedTargetFrequency
					SET QuestionID = @QuestionID
						,TargetFrequencyValue = @TargetFrequencyValue
						,TargetFrequencyTypeID = @TargetFrequencyTypeID
						,IsDeleted = @IsDeleted
					WHERE ID = @ID;
				END
				ELSE
				BEGIN
					-- Insert to the main table if that not exists(may be removed)
					INSERT INTO T_LNK_AssignedTargetFrequency (
						QuestionID
						,TargetFrequencyValue
						,TargetFrequencyTypeID
						,IsDeleted
						)
					VALUES (
						@QuestionID
						,@TargetFrequencyValue
						,@TargetFrequencyTypeID
						,@IsDeleted
						);
				END

				FETCH NEXT
				FROM CUR_HistoryRows
				INTO @ID
					,@QuestionID
					,@TargetFrequencyValue
					,@TargetFrequencyTypeID
					,@IsDeleted;
			END

			CLOSE CUR_HistoryRows;

			DEALLOCATE CUR_HistoryRows;

			-- END - [T_LNK_AssignedTargetFrequency]
			-- Update [T_LNK_AssignedValueStreams]
			SET @ID = 0;

			DECLARE @ValueStreamID INT;

			SET @IsDeleted = 0;

			--soft deletes based on Question History ID
			UPDATE T_LNK_AssignedValueStreams
			SET IsDeleted = 1
			WHERE QuestionID = @QuestionID
				AND ID NOT IN (
					SELECT ID
					FROM [T_LNK_AssignedValueStreamsHistory] WITH (NOLOCK)
					WHERE (
							IsDeleted IS NULL
							OR IsDeleted = 0
							)
						AND QuestionHistoryID = @QuestionHistoryID
					);

			DECLARE CUR_HistoryRows CURSOR FORWARD_ONLY
			FOR
			SELECT ID
				,QuestionID
				,ValueStreamID
				,IsDeleted
			FROM [T_LNK_AssignedValueStreamsHistory] WITH (NOLOCK)
			WHERE QuestionHistoryID = @QuestionHistoryID;

			OPEN CUR_HistoryRows;

			FETCH NEXT
			FROM CUR_HistoryRows
			INTO @ID
				,@QuestionID
				,@ValueStreamID
				,@IsDeleted;

			WHILE @@FETCH_STATUS = 0
			BEGIN
				IF EXISTS (
						SELECT ID
						FROM T_LNK_AssignedValueStreams WITH (NOLOCK)
						WHERE ID = @ID
						)
				BEGIN
					-- Update the main table data if that exists in history
					UPDATE T_LNK_AssignedValueStreams
					SET QuestionID = @QuestionID
						,ValueStreamID = @ValueStreamID
						,IsDeleted = @IsDeleted
					WHERE ID = @ID;
				END
				ELSE
				BEGIN
					-- Insert to the main table if that not exists(may be removed)
					INSERT INTO T_LNK_AssignedValueStreams (
						QuestionID
						,ValueStreamID
						,IsDeleted
						)
					VALUES (
						@QuestionID
						,@ValueStreamID
						,@IsDeleted
						);
				END

				FETCH NEXT
				FROM CUR_HistoryRows
				INTO @ID
					,@QuestionID
					,@ValueStreamID
					,@IsDeleted;
			END

			CLOSE CUR_HistoryRows;

			DEALLOCATE CUR_HistoryRows;

			-- END - [T_LNK_AssignedValueStreams]
			-- Update [T_LNK_QN_AssignedTags]
			SET @ID = 0;

			DECLARE @TagID INT;

			SET @IsDeleted = 0;

			--soft deletes based on Question History ID
			UPDATE T_LNK_QN_AssignedTags
			SET IsDeleted = 1
			WHERE QuestionID = @QuestionID
				AND ID NOT IN (
					SELECT ID
					FROM [T_LNK_QN_AssignedTagsHistory] WITH (NOLOCK)
					WHERE QuestionHistoryID = @QuestionHistoryID
					);

			SELECT ID
				,TagID
				,QuestionID
				,IsDeleted
			FROM T_LNK_QN_AssignedTags WITH (NOLOCK)
			WHERE QuestionID = @QuestionID

			DECLARE CUR_HistoryRows CURSOR FORWARD_ONLY
			FOR
			SELECT ID
				,QuestionID
				,TagID
				,IsDeleted
			FROM [T_LNK_QN_AssignedTagsHistory] WITH (NOLOCK)
			WHERE QuestionHistoryID = @QuestionHistoryID;

			OPEN CUR_HistoryRows;

			FETCH NEXT
			FROM CUR_HistoryRows
			INTO @ID
				,@QuestionID
				,@TagID
				,@IsDeleted;

			WHILE @@FETCH_STATUS = 0
			BEGIN
				IF EXISTS (
						SELECT ID
						FROM T_LNK_QN_AssignedTags WITH (NOLOCK)
						WHERE ID = @ID
						)
				BEGIN
					-- Update the main table data if that exists in history
					UPDATE T_LNK_QN_AssignedTags
					SET QuestionID = @QuestionID
						,TagID = @TagID
						,IsDeleted = @IsDeleted
					WHERE ID = @ID;
				END
				ELSE
				BEGIN
					-- Insert to the main table if that not exists(may be removed)
					INSERT INTO T_LNK_QN_AssignedTags (
						QuestionID
						,TagID
						,IsDeleted
						)
					VALUES (
						@QuestionID
						,@TagID
						,@IsDeleted
						);
				END

				FETCH NEXT
				FROM CUR_HistoryRows
				INTO @ID
					,@QuestionID
					,@TagID
					,@IsDeleted;
			END

			CLOSE CUR_HistoryRows;

			DEALLOCATE CUR_HistoryRows;

			-- END - [T_LNK_QN_AssignedTags]
			-- Update [T_TRN_SingleLineText]
			SET @ID = 0;

			DECLARE @MaxCharacters INT;
			DECLARE @IsCalculated BIT;
			DECLARE @DefaultValue NVARCHAR(max);

			SET @IsDeleted = 0;

			--soft deletes based on Question History ID
			UPDATE T_TRN_SingleLineText
			SET IsDeleted = 1
			WHERE QuestionID = @QuestionID
				AND ID NOT IN (
					SELECT ID
					FROM [T_TRN_SingleLineTextHistory] WITH (NOLOCK)
					WHERE QuestionHistoryID = @QuestionHistoryID
					);

			-- WHERE (IsDeleted  is NULL OR IsDeleted =0)
			DECLARE CUR_HistoryRows CURSOR FORWARD_ONLY
			FOR
			SELECT ID
				,QuestionID
				,MaxCharacters
				,IsCalculated
				,DefaultValue
				,IsDeleted
			FROM [T_TRN_SingleLineTextHistory] WITH (NOLOCK)
			WHERE QuestionHistoryID = @QuestionHistoryID;

			OPEN CUR_HistoryRows;

			FETCH NEXT
			FROM CUR_HistoryRows
			INTO @ID
				,@QuestionID
				,@MaxCharacters
				,@IsCalculated
				,@DefaultValue
				,@IsDeleted;

			WHILE @@FETCH_STATUS = 0
			BEGIN
				IF EXISTS (
						SELECT ID
						FROM T_TRN_SingleLineText WITH (NOLOCK)
						WHERE ID = @ID
						)
				BEGIN
					-- Update the main table data if that exists in history
					UPDATE T_TRN_SingleLineText
					SET QuestionID = @QuestionID
						,MaxCharacters = @MaxCharacters
						,IsCalculated = @IsCalculated
						,DefaultValue = @DefaultValue
						,IsDeleted = @IsDeleted
					WHERE ID = @ID;
				END
				ELSE
				BEGIN
					-- Insert to the main table if that not exists(may be removed)
					INSERT INTO T_TRN_SingleLineText (
						QuestionID
						,MaxCharacters
						,IsCalculated
						,DefaultValue
						,IsDeleted
						)
					VALUES (
						@QuestionID
						,@MaxCharacters
						,@IsCalculated
						,@DefaultValue
						,@IsDeleted
						);
				END

				FETCH NEXT
				FROM CUR_HistoryRows
				INTO @ID
					,@QuestionID
					,@MaxCharacters
					,@IsCalculated
					,@DefaultValue
					,@IsDeleted;
			END

			CLOSE CUR_HistoryRows;

			DEALLOCATE CUR_HistoryRows;

			-- END - [T_TRN_SingleLineText]
			-- Update [T_TRN_MultipleLinesText]
			SET @ID = 0;

			DECLARE @MaxLines INT;
			DECLARE @IsPlaintText BIT;

			SET @IsDeleted = 0;

			--soft deletes based on Question History ID
			UPDATE T_TRN_MultipleLinesText
			SET IsDeleted = 1
			WHERE QuestionID = @QuestionID
				AND ID NOT IN (
					SELECT ID
					FROM [T_TRN_MultipleLinesTextHistory] WITH (NOLOCK)
					WHERE (
							IsDeleted IS NULL
							OR IsDeleted = 0
							)
						AND QuestionHistoryID = @QuestionHistoryID
					);

			DECLARE CUR_HistoryRows CURSOR FORWARD_ONLY
			FOR
			SELECT ID
				,QuestionID
				,MaxLines
				,IsPlaintText
				,IsDeleted
			FROM [T_TRN_MultipleLinesTextHistory] WITH (NOLOCK)
			WHERE QuestionHistoryID = @QuestionHistoryID;

			OPEN CUR_HistoryRows;

			FETCH NEXT
			FROM CUR_HistoryRows
			INTO @ID
				,@QuestionID
				,@MaxLines
				,@IsPlaintText
				,@IsDeleted;

			WHILE @@FETCH_STATUS = 0
			BEGIN
				IF EXISTS (
						SELECT ID
						FROM T_TRN_MultipleLinesText WITH (NOLOCK)
						WHERE ID = @ID
						)
				BEGIN
					-- Update the main table data if that exists in history
					UPDATE T_TRN_MultipleLinesText
					SET QuestionID = @QuestionID
						,MaxLines = @MaxLines
						,IsPlaintText = @IsPlaintText
						,IsDeleted = @IsDeleted
					WHERE ID = @ID;
				END
				ELSE
				BEGIN
					-- Insert to the main table if that not exists(may be removed)
					INSERT INTO T_TRN_MultipleLinesText (
						QuestionID
						,MaxLines
						,IsPlaintText
						,IsDeleted
						)
					VALUES (
						@QuestionID
						,@MaxLines
						,@IsPlaintText
						,@IsDeleted
						);
				END

				FETCH NEXT
				FROM CUR_HistoryRows
				INTO @ID
					,@QuestionID
					,@MaxLines
					,@IsPlaintText
					,@IsDeleted;
			END

			CLOSE CUR_HistoryRows;

			DEALLOCATE CUR_HistoryRows;

			-- END - [T_TRN_MultipleLinesText]
			-- Update [T_TRN_Choice]
			DECLARE @ChoiceID INT;
			DECLARE @ChoiceName NVARCHAR(500);
			DECLARE @ChoiceScore INT;
			DECLARE @IsDeviationEntryRequired BIT;
			DECLARE @AnswerCategory NVARCHAR(50);

			SET @IsDeleted = 0;

			--soft deletes based on Question History ID
			UPDATE T_TRN_Choice
			SET IsDeleted = 1
			WHERE QuestionID = @QuestionID
				AND ChoiceID NOT IN (
					SELECT ChoiceID
					FROM [T_TRN_ChoiceHistory] WITH (NOLOCK)
					WHERE (
							IsDeleted IS NULL
							OR IsDeleted = 0
							)
						AND QuestionHistoryID = @QuestionHistoryID
					);

			DECLARE CUR_HistoryRows CURSOR FORWARD_ONLY
			FOR
			SELECT ChoiceID
				,QuestionID
				,ChoiceName
				,ChoiceScore
				,IsDeviationEntryRequired
				,IsDeleted
				,AnswerCategory
			FROM [T_TRN_ChoiceHistory] WITH (NOLOCK)
			WHERE QuestionHistoryID = @QuestionHistoryID;

			OPEN CUR_HistoryRows;

			FETCH NEXT
			FROM CUR_HistoryRows
			INTO @ChoiceID
				,@QuestionID
				,@ChoiceName
				,@ChoiceScore
				,@IsDeviationEntryRequired
				,@IsDeleted
				,@AnswerCategory;

			WHILE @@FETCH_STATUS = 0
			BEGIN
				IF EXISTS (
						SELECT ChoiceID
						FROM T_TRN_Choice WITH (NOLOCK)
						WHERE ChoiceID = @ChoiceID
						)
				BEGIN
					-- Update the main table data if that exists in history
					UPDATE T_TRN_Choice
					SET QuestionID = @QuestionID
						,ChoiceName = @ChoiceName
						,ChoiceScore = @ChoiceScore
						,IsDeviationEntryRequired = @IsDeviationEntryRequired
						,IsDeleted = @IsDeleted
						,AnswerCategory = @AnswerCategory
					WHERE ChoiceID = @ChoiceID;
				END
				ELSE
				BEGIN
					-- Insert to the main table if that not exists(may be removed)
					INSERT INTO T_TRN_Choice (
						QuestionID
						,ChoiceName
						,ChoiceScore
						,IsDeviationEntryRequired
						,IsDeleted
						,AnswerCategory
						)
					VALUES (
						@QuestionID
						,@ChoiceName
						,@ChoiceScore
						,@IsDeviationEntryRequired
						,@IsDeleted
						,@AnswerCategory
						);
				END

				FETCH NEXT
				FROM CUR_HistoryRows
				INTO @ChoiceID
					,@QuestionID
					,@ChoiceName
					,@ChoiceScore
					,@IsDeviationEntryRequired
					,@IsDeleted
					,@AnswerCategory;
			END

			CLOSE CUR_HistoryRows;

			DEALLOCATE CUR_HistoryRows;

			---- END - [T_TRN_Choice]
			---- Update [T_TRN_AnswerTypeNumber]
			--SET @ID = 0;
			--DECLARE @MaxValue INT;
			--DECLARE @MinValue INT;
			--DECLARE @NumberOfDecimalPlaces NVARCHAR(10);
			--DECLARE @IsNumber BIT;
			--DECLARE @defaultValue50 NVARCHAR(50);
			--DECLARE @ShowPercentage BIT;
			--SET @IsDeleted = 0;
			----soft deletes based on Question History ID
			--UPDATE [T_TRN_AnswerTypeNumber]
			--SET IsDeleted = 1
			--WHERE QuestionID = @QuestionID
			--	AND ID NOT IN (
			--		SELECT ID
			--		FROM [T_TRN_AnswerTypeNumberHistory] WITH (NOLOCK)
			--		WHERE (
			--				IsDeleted IS NULL
			--				OR IsDeleted = 0
			--				)
			--			AND QuestionHistoryID = @QuestionHistoryID
			--		);
			--DECLARE CUR_HistoryRows CURSOR FORWARD_ONLY
			--FOR
			--SELECT ID
			--	,QuestionID
			--	,MaxValue
			--	,MinValue
			--	,NumberOfDecimalPlaces
			--	,IsNumber
			--	,DefaultValue
			--	,ShowPercentage
			--	,IsDeleted
			--FROM [T_TRN_AnswerTypeNumberHistory] WITH (NOLOCK)
			--WHERE QuestionHistoryID = @QuestionHistoryID;
			--OPEN CUR_HistoryRows;
			--FETCH NEXT
			--FROM CUR_HistoryRows
			--INTO @ID
			--	,@QuestionID
			--	,@MaxValue
			--	,@MinValue
			--	,@NumberOfDecimalPlaces
			--	,@IsNumber
			--	,@defaultValue50
			--	,@ShowPercentage
			--	,@IsDeleted;
			--WHILE @@FETCH_STATUS = 0
			--BEGIN
			--	IF EXISTS (
			--			SELECT ID
			--			FROM T_TRN_AnswerTypeNumber WITH (NOLOCK)
			--			WHERE ID = @ID
			--			)
			--	BEGIN
			--		-- Update the main table data if that exists in history
			--		UPDATE T_TRN_AnswerTypeNumber
			--		SET QuestionID = @QuestionID
			--			,MaxValue = @MaxValue
			--			,MinValue = @MinValue
			--			,NumberOfDecimalPlaces = @NumberOfDecimalPlaces
			--			,IsNumber = @IsNumber
			--			,DefaultValue = @defaultValue50
			--			,ShowPercentage = @ShowPercentage
			--			,IsDeleted = @IsDeleted
			--		WHERE ID = @ID;
			--	END
			--	ELSE
			--	BEGIN
			--		-- Insert to the main table if that not exists(may be removed)
			--		INSERT INTO T_TRN_AnswerTypeNumber (
			--			QuestionID
			--			,MaxValue
			--			,MinValue
			--			,NumberOfDecimalPlaces
			--			,IsNumber
			--			,DefaultValue
			--			,ShowPercentage
			--			,IsDeleted
			--			)
			--		VALUES (
			--			@QuestionID
			--			,@MaxValue
			--			,@MinValue
			--			,@NumberOfDecimalPlaces
			--			,@IsNumber
			--			,@defaultValue50
			--			,@ShowPercentage
			--			,@IsDeleted
			--			);
			--	END
			--	FETCH NEXT
			--	FROM CUR_HistoryRows
			--	INTO @ID
			--		,@QuestionID
			--		,@MaxValue
			--		,@MinValue
			--		,@NumberOfDecimalPlaces
			--		,@IsNumber
			--		,@defaultValue50
			--		,@ShowPercentage
			--		,@IsDeleted;
			--END
			--CLOSE CUR_HistoryRows;
			--DEALLOCATE CUR_HistoryRows;
			---- END - [T_TRN_AnswerTypeNumber]
			---- Update [T_TRN_AnswerTypeCurrency]
			--SET @ID = 0;
			--SET @MaxValue = 0;
			--SET @MinValue = 0;
			--SET @NumberOfDecimalPlaces = '';
			--DECLARE @IsCurrency BIT;
			--SET @defaultValue50 = '';
			--DECLARE @CurrencyFormat NVARCHAR(100);
			--SET @IsDeleted = 0;
			----soft deletes based on Question History ID
			--UPDATE T_TRN_AnswerTypeCurrency
			--SET IsDeleted = 1
			--WHERE QuestionID = @QuestionID
			--	AND ID NOT IN (
			--		SELECT ID
			--		FROM [T_TRN_AnswerTypeCurrencyHistory] WITH (NOLOCK)
			--		WHERE (
			--				IsDeleted IS NULL
			--				OR IsDeleted = 0
			--				)
			--			AND QuestionHistoryID = @QuestionHistoryID
			--		);
			--DECLARE CUR_HistoryRows CURSOR FORWARD_ONLY
			--FOR
			--SELECT ID
			--	,QuestionID
			--	,MaxValue
			--	,MinValue
			--	,NumberOfDecimalPlaces
			--	,IsCurrency
			--	,DefaultValue
			--	,CurrencyFormat
			--	,IsDeleted
			--FROM [T_TRN_AnswerTypeCurrencyHistory] WITH (NOLOCK)
			--WHERE QuestionHistoryID = @QuestionHistoryID;
			--OPEN CUR_HistoryRows;
			--FETCH NEXT
			--FROM CUR_HistoryRows
			--INTO @ID
			--	,@QuestionID
			--	,@MaxValue
			--	,@MinValue
			--	,@NumberOfDecimalPlaces
			--	,@IsCurrency
			--	,@defaultValue50
			--	,@CurrencyFormat
			--	,@IsDeleted;
			--WHILE @@FETCH_STATUS = 0
			--BEGIN
			--	IF EXISTS (
			--			SELECT ID
			--			FROM T_TRN_AnswerTypeCurrency WITH (NOLOCK)
			--			WHERE ID = @ID
			--			)
			--	BEGIN
			--		-- Update the main table data if that exists in history
			--		UPDATE T_TRN_AnswerTypeCurrency
			--		SET QuestionID = @QuestionID
			--			,MaxValue = @MaxValue
			--			,MinValue = @MinValue
			--			,NumberOfDecimalPlaces = @NumberOfDecimalPlaces
			--			,IsCurrency = @IsCurrency
			--			,DefaultValue = @defaultValue50
			--			,CurrencyFormat = @CurrencyFormat
			--			,IsDeleted = @IsDeleted
			--		WHERE ID = @ID;
			--	END
			--	ELSE
			--	BEGIN
			--		-- Insert to the main table if that not exists(may be removed)
			--		INSERT INTO T_TRN_AnswerTypeCurrency (
			--			QuestionID
			--			,MaxValue
			--			,MinValue
			--			,NumberOfDecimalPlaces
			--			,IsCurrency
			--			,defaultValue
			--			,CurrencyFormat
			--			,IsDeleted
			--			)
			--		VALUES (
			--			@QuestionID
			--			,@MaxValue
			--			,@MinValue
			--			,@NumberOfDecimalPlaces
			--			,@IsCurrency
			--			,@defaultValue50
			--			,@CurrencyFormat
			--			,@IsDeleted
			--			);
			--	END
			--	FETCH NEXT
			--	FROM CUR_HistoryRows
			--	INTO @ID
			--		,@QuestionID
			--		,@MaxValue
			--		,@MinValue
			--		,@NumberOfDecimalPlaces
			--		,@IsCurrency
			--		,@defaultValue50
			--		,@CurrencyFormat
			--		,@IsDeleted;
			--END
			--CLOSE CUR_HistoryRows;
			--DEALLOCATE CUR_HistoryRows;
			---- END - [T_TRN_AnswerTypeCurrency]
			---- Update [T_TRN_AnswerTypeDateTime]
			--SET @ID = 0;
			--DECLARE @IsDateOnly BIT;
			--DECLARE @IsStandard BIT;
			--DECLARE @DefaultDateType NVARCHAR(10);
			--DECLARE @DefaultValue10 NVARCHAR(10);
			--SET @IsDeleted = 0;
			----soft deletes based on Question History ID
			--UPDATE T_TRN_AnswerTypeDateTime
			--SET IsDeleted = 1
			--WHERE QuestionID = @QuestionID
			--	AND ID NOT IN (
			--		SELECT ID
			--		FROM [T_TRN_AnswerTypeDateTimeHistory] WITH (NOLOCK)
			--		WHERE (
			--				IsDeleted IS NULL
			--				OR IsDeleted = 0
			--				)
			--			AND QuestionHistoryID = @QuestionHistoryID
			--		);
			--DECLARE CUR_HistoryRows CURSOR FORWARD_ONLY
			--FOR
			--SELECT ID
			--	,QuestionID
			--	,IsDateOnly
			--	,IsStandard
			--	,DefaultDateType
			--	,DefaultValue
			--	,IsDeleted
			--FROM [T_TRN_AnswerTypeDateTimeHistory] WITH (NOLOCK)
			--WHERE QuestionHistoryID = @QuestionHistoryID;
			--OPEN CUR_HistoryRows;
			--FETCH NEXT
			--FROM CUR_HistoryRows
			--INTO @ID
			--	,@QuestionID
			--	,@IsDateOnly
			--	,@IsStandard
			--	,@DefaultDateType
			--	,@DefaultValue10
			--	,@IsDeleted;
			--WHILE @@FETCH_STATUS = 0
			--BEGIN
			--	IF EXISTS (
			--			SELECT ID
			--			FROM T_TRN_AnswerTypeDateTime WITH (NOLOCK)
			--			WHERE ID = @ID
			--			)
			--	BEGIN
			--		-- Update the main table data if that exists in history
			--		UPDATE T_TRN_AnswerTypeDateTime
			--		SET QuestionID = @QuestionID
			--			,IsDateOnly = @IsDateOnly
			--			,IsStandard = @IsStandard
			--			,DefaultDateType = @DefaultDateType
			--			,DefaultValue = @DefaultValue10
			--			,IsDeleted = @IsDeleted
			--		WHERE ID = @ID;
			--	END
			--	ELSE
			--	BEGIN
			--		-- Insert to the main table if that not exists(may be removed)
			--		INSERT INTO T_TRN_AnswerTypeDateTime (
			--			QuestionID
			--			,IsDateOnly
			--			,IsStandard
			--			,DefaultDateType
			--			,DefaultValue
			--			,IsDeleted
			--			)
			--		VALUES (
			--			@QuestionID
			--			,@IsDateOnly
			--			,@IsStandard
			--			,@DefaultDateType
			--			,@DefaultValue10
			--			,@IsDeleted
			--			);
			--	END
			--	FETCH NEXT
			--	FROM CUR_HistoryRows
			--	INTO @ID
			--		,@QuestionID
			--		,@IsDateOnly
			--		,@IsStandard
			--		,@DefaultDateType
			--		,@DefaultValue10
			--		,@IsDeleted;
			--END
			--CLOSE CUR_HistoryRows;
			--DEALLOCATE CUR_HistoryRows;
			---- END - [T_TRN_AnswerTypeDateTime]
			---- Update [T_TRN_RatingScale]
			--SET @ID = 0;
			--DECLARE @NumberRange NVARCHAR(10);
			--DECLARE @RangeText1 NVARCHAR(50);
			--DECLARE @RangeText2 NVARCHAR(50);
			--DECLARE @RangeText3 NVARCHAR(50);
			--DECLARE @ShowNA BIT;
			--DECLARE @TextNA NVARCHAR(10);
			--SET @IsDeleted = 0;
			----soft deletes based on Question History ID
			--UPDATE T_TRN_RatingScale
			--SET IsDeleted = 1
			--WHERE QuestionID = @QuestionID
			--	AND ID NOT IN (
			--		SELECT ID
			--		FROM [T_TRN_RatingScaleHistory] WITH (NOLOCK)
			--		WHERE (
			--				IsDeleted IS NULL
			--				OR IsDeleted = 0
			--				)
			--			AND QuestionHistoryID = @QuestionHistoryID
			--		);
			--DECLARE CUR_HistoryRows CURSOR FORWARD_ONLY
			--FOR
			--SELECT ID
			--	,QuestionID
			--	,NumberRange
			--	,RangeText1
			--	,RangeText2
			--	,RangeText3
			--	,ShowNA
			--	,TextNA
			--	,IsDeleted
			--FROM [T_TRN_RatingScaleHistory] WITH (NOLOCK)
			--WHERE QuestionHistoryID = @QuestionHistoryID;
			--OPEN CUR_HistoryRows;
			--FETCH NEXT
			--FROM CUR_HistoryRows
			--INTO @ID
			--	,@QuestionID
			--	,@NumberRange
			--	,@RangeText1
			--	,@RangeText2
			--	,@RangeText3
			--	,@ShowNA
			--	,@TextNA
			--	,@IsDeleted;
			--WHILE @@FETCH_STATUS = 0
			--BEGIN
			--	IF EXISTS (
			--			SELECT ID
			--			FROM T_TRN_RatingScale WITH (NOLOCK)
			--			WHERE ID = @ID
			--			)
			--	BEGIN
			--		-- Update the main table data if that exists in history
			--		UPDATE T_TRN_RatingScale
			--		SET QuestionID = @QuestionID
			--			,NumberRange = @NumberRange
			--			,RangeText1 = @RangeText1
			--			,RangeText2 = @RangeText2
			--			,RangeText3 = @RangeText3
			--			,ShowNA = @ShowNA
			--			,TextNA = @TextNA
			--			,IsDeleted = @IsDeleted
			--		WHERE ID = @ID;
			--	END
			--	ELSE
			--	BEGIN
			--		-- Insert to the main table if that not exists(may be removed)
			--		INSERT INTO T_TRN_RatingScale (
			--			QuestionID
			--			,NumberRange
			--			,RangeText1
			--			,RangeText2
			--			,RangeText3
			--			,ShowNA
			--			,TextNA
			--			,IsDeleted
			--			)
			--		VALUES (
			--			@QuestionID
			--			,@NumberRange
			--			,@RangeText1
			--			,@RangeText2
			--			,@RangeText3
			--			,@ShowNA
			--			,@TextNA
			--			,@IsDeleted
			--			);
			--	END
			--	FETCH NEXT
			--	FROM CUR_HistoryRows
			--	INTO @ID
			--		,@QuestionID
			--		,@NumberRange
			--		,@RangeText1
			--		,@RangeText2
			--		,@RangeText3
			--		,@ShowNA
			--		,@TextNA
			--		,@IsDeleted;
			--END
			--CLOSE CUR_HistoryRows;
			--DEALLOCATE CUR_HistoryRows;
			---- END - [T_TRN_RatingScale]
			---- Update [T_TRN_SubQuestion]
			--SET @ID = 0;
			--DECLARE @Name NVARCHAR(200);
			--SET @IsDeleted = 0;
			----soft deletes based on Question History ID
			--UPDATE T_TRN_SubQuestion
			--SET IsDeleted = 1
			--WHERE QuestionID = @QuestionID
			--	AND ID NOT IN (
			--		SELECT ID
			--		FROM [T_TRN_SubQuestionHistory] WITH (NOLOCK)
			--		WHERE (
			--				IsDeleted IS NULL
			--				OR IsDeleted = 0
			--				)
			--			AND QuestionHistoryID = @QuestionHistoryID
			--		);
			--DECLARE CUR_HistoryRows CURSOR FORWARD_ONLY
			--FOR
			--SELECT ID
			--	,QuestionID
			--	,Name
			--	,IsDeleted
			--FROM [T_TRN_SubQuestionHistory] WITH (NOLOCK)
			--WHERE QuestionHistoryID = @QuestionHistoryID;
			--OPEN CUR_HistoryRows;
			--FETCH NEXT
			--FROM CUR_HistoryRows
			--INTO @ID
			--	,@QuestionID
			--	,@Name
			--	,@IsDeleted;
			--WHILE @@FETCH_STATUS = 0
			--BEGIN
			--	IF EXISTS (
			--			SELECT ID
			--			FROM T_TRN_SubQuestion WITH (NOLOCK)
			--			WHERE ID = @ID
			--			)
			--	BEGIN
			--		-- Update the main table data if that exists in history
			--		UPDATE T_TRN_SubQuestion
			--		SET QuestionID = @QuestionID
			--			,Name = @Name
			--			,IsDeleted = @IsDeleted
			--		WHERE ID = @ID;
			--	END
			--	ELSE
			--	BEGIN
			--		-- Insert to the main table if that not exists(may be removed)
			--		INSERT INTO T_TRN_SubQuestion (
			--			QuestionID
			--			,Name
			--			,IsDeleted
			--			)
			--		VALUES (
			--			@QuestionID
			--			,@Name
			--			,@IsDeleted
			--			);
			--	END
			--	FETCH NEXT
			--	FROM CUR_HistoryRows
			--	INTO @ID
			--		,@QuestionID
			--		,@Name
			--		,@IsDeleted;
			--END
			--CLOSE CUR_HistoryRows;
			--DEALLOCATE CUR_HistoryRows;
			-- END - [T_TRN_SubQuestion]
			COMMIT TRANSACTION TRNRESTOREQNHISTORY;
		END
		ELSE
		BEGIN
			ROLLBACK TRANSACTION TRNRESTOREQNHISTORY;
		END
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNRESTOREQNHISTORY;

		SELECT ERROR_NUMBER() AS ErrorNumber
			,ERROR_MESSAGE() AS ErrorMessage;
	END CATCH
END
GO

