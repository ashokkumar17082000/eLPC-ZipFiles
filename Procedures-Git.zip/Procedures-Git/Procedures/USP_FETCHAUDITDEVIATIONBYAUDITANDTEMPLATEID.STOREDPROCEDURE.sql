/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchAuditDeviationByAuditAndTemplateID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING AUDIT DEVIATION BY AUDIT AND TEMPLATEID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			Rajasekar S					PlantId,CurrentUserNTID added

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_FetchAuditDeviationByAuditAndTemplateID] 1, 1
*/
CREATE PROCEDURE [USP_FetchAuditDeviationByAuditAndTemplateID] @PlantID INT
	,@AuditID INT
	,@AuditTemplateID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	SET NOCOUNT ON;

	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = @AuditID
		,@Mode = 'AUDIT'
		,@CurrentUserNTID = @CurrentUserNTID

	SELECT AD.AuditDeviationID
		,AD.AuditTemplateID
		,AD.AuditID
		,AD.ValueStreamID
		,AD.DeviationDescription
		,AD.ResponsibleEmployee
		,AD.QuestionID
		,AD.CreatedBy_NTID
		,AD.ModifiedBy_NTID
		,AD.ManagerEmailAddress
		,AD.ResponsibleEmployeeEmailAddress
		,AD.ValueStreamName
		,AD.UserEmailAddress
		,AD.DeviationTypeID
		,AD.QuestionText
		,AD.ResponsibleEmpNTID
		,AD.OWNER
		,AD.OwnerNTID
		,AD.CreatedBy_Name
		,AD.AuditAnsweredQuestionID
	FROM T_LNK_Audit_AnsweredQuestions AQ WITH (NOLOCK)
	INNER JOIN [T_TRN_AuditDeviation] AD WITH (NOLOCK) ON AD.AuditTemplateID = AQ.AuditTemplateID
		AND AD.AuditID = AQ.AuditID
		AND AD.QuestionID = AQ.QuestionID
	INNER JOIN T_TRN_Audit A WITH (NOLOCK) ON A.AuditID = AQ.AuditID
	WHERE AQ.AuditID = @AuditID
		AND (
			AQ.IsAuditCompleted = 0
			OR AQ.IsAuditCompleted IS NULL
			)
		AND AQ.AuditTemplateID = @AuditTemplateID
		AND A.PlantID = @PlantID
END
GO


