/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_UPDATEDATAPOOL_SUMMARYBYQUESTIONID]
///AUTHOR                       : VENKATESH GOVINDARAJ
///CREATED DATE                 : 01-DEC-2021
///SEE ALSO                     : THIS PROCEDURE FOR UPDATING DATAPOOL SUMMARY BY QUESTIONID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_002					01-DEC-2021			VENKATESH GOVINDARAJ		INITIAL VERSION

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_UpdateDataPool_SummaryByQuestionID] 145
*/
CREATE PROCEDURE [USP_UpdateDataPool_SummaryByQuestionID] @QuestionID INT
AS
BEGIN
	-- Fetch AnswerCount, NegativeAnswerCount from DataPool by QuestionID & ValueStreamID
	SELECT *
	INTO #CurrentQuestion
	FROM (
		SELECT PlantID
			,QuestionID
			,ValueStreamID
			,COUNT(DataPoolID) AS AnswerCount
			,(
				SELECT Count(ChoiceID) AS NegativeAnswerCount
				FROM T_TRN_DataPool  WITH (NOLOCK)
				WHERE choiceID IN (
						SELECT choiceID
						FROM T_TRN_Choice WITH (NOLOCK)
						WHERE AnswerCategory = 'negative'
						)
					AND PlantID = DP.PlantID
					AND QuestionID = DP.QuestionID
					AND ValueStreamID = DP.ValueStreamID
					AND IsDeleted = 0
				) AS NegativeAnswerCount
			,0 AS Perc
		FROM T_TRN_DataPool DP  WITH (NOLOCK)
		WHERE DP.QuestionID = @QuestionID
			AND DP.IsDeleted = 0
			--AND (
			--	DP.AuditID IS NULL
			--	OR DP.AuditID = 0
			--	)
		GROUP BY PlantID
			,QuestionID
			,ValueStreamID
			,IsDeleted
		) AS CurrentQuestion

	IF NOT EXISTS (
			SELECT TOP 1 1
			FROM #CurrentQuestion WITH (NOLOCK)
			)
	BEGIN
		DELETE
		FROM T_TRN_DataPool_Summary
		WHERE QuestionID = @QuestionID
	END
	ELSE
	BEGIN
		--select * from #CurrentQuestion
		MERGE T_TRN_DataPool_Summary AS Target
		USING #CurrentQuestion AS Source
			ON Source.QuestionID = Target.QuestionID
				AND Source.ValueStreamID = Target.ValueStreamID

		-- For Updates
		WHEN MATCHED
			THEN
				UPDATE
				SET Target.AnswerCount = Source.AnswerCount
					,Target.NegativeAnswerCount = Source.NegativeAnswerCount

		-- For Inserts
		WHEN NOT MATCHED BY Target
			THEN
				INSERT (
					QuestionID
					,PlantID
					,ValueStreamID
					,AnswerCount
					,NegativeAnswerCount
					,Percentage
					)
				VALUES (
					Source.QuestionID
					,Source.PlantID
					,Source.ValueStreamID
					,Source.AnswerCount
					,Source.NegativeAnswerCount
					,NULL
					);
		-- For Deletes
		--WHEN NOT MATCHED BY Source THEN
		--DELETE;
		---- Checking the actions by MERGE statement
		--OUTPUT $action, 
		--INSERTED.QuestionID AS SourceQuestionID, 
		--INSERTED.ValueStreamID AS SourceValueStreamID, 
		--INSERTED.AnswerCount AS SourceAnswerCount;
	END
END
GO