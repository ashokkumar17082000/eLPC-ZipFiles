/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_DeleteDataPool] 
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE TO DELETE DATA POOL
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					25-MAR-2021			SIKHESH S					ADDITIONAL PARAMATERS INCLUDED AND RELEATED CHANGES, STANDARD RULES APPLIED
ELPC_LH_002_CR05			06-Dec-2021			VENKATESH GOVINDARAJ		QUESTION ORDER BY LOGIC CHANGED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_DeleteDataPool] 1, 'OSP4KOR','2020-11-27 06:21:32.380'
*/
CREATE PROCEDURE [USP_DeleteDataPool] (
	@DataPoolID INT
	,@ModifiedAt DATETIME
	,@PlantID INT
	,@CurrentUserNTID NVARCHAR(20)
	)
AS
BEGIN
	DECLARE @AuditID INT
	DECLARE @AuditTemplateID INT

	SET @ModifiedAt = (
			SELECT FormattedDateTime
			FROM fnGetDateTime(@PlantID)
			)

	SELECT @AuditID = AuditID
		,@AuditTemplateID = AuditTemplateID
	FROM T_TRN_DataPool WITH (NOLOCK)
	WHERE DataPoolID = @DataPoolID
		AND PlantID = @PlantID;

	--DELETE SINGLE ANSWERED QUESTION WHEN AUDIT ID IS NULL
	IF @AuditID IS NULL
	BEGIN
		UPDATE T_TRN_DataPool
		SET IsDeleted = 1
			,ModifiedBy_NTID = @CurrentUserNTID
			,ModifiedAt = @ModifiedAt
		WHERE DataPoolID = @DataPoolID
			AND PlantID = @PlantID;

		DECLARE @tmpQuestionID INT = (
				SELECT QuestionID
				FROM T_TRN_DataPool WITH(NOLOCK)
				WHERE DataPoolID = @DataPoolID
					AND PlantID = @PlantID
				)

		EXEC [USP_UpdateDataPool_SummaryByQuestionID] @tmpQuestionID
	END
	ELSE --DELETE ALL AUDIT ANSWERED QUESTIONS
	BEGIN
		UPDATE T_TRN_DataPool
		SET IsDeleted = 1
			,ModifiedBy_NTID = @CurrentUserNTID
			,ModifiedAt = @ModifiedAt
		WHERE AuditID = @AuditID
			AND AuditTemplateID = @AuditTemplateID
			AND PlantID = @PlantID
	END
END
GO

