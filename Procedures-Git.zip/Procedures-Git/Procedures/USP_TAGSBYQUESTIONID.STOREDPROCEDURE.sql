/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_TagsByQuestionID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING TAGS BY QUESTIONID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			VENKATESH GOVINDARAJ		PlantID & Code Cleanup
ELPC_LH_006                	18-AUG-2023         SUSHANTH                  GLOBAL TAG

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_TagsByQuestionID] 1, 1
*/
ALTER PROCEDURE [USP_TagsByQuestionID] @QuestionID INT
	,@PlantID INT
AS
BEGIN
	SET NOCOUNT ON;

	SELECT LNK.TagID
		,(
			SELECT TOP 1 TagName
			FROM T_TRN_Tag T WITH (NOLOCK)
			WHERE T.TagID = LNK.TagID
				AND T.PlantID = @PlantID
			) AS TagName
		,LNK.QuestionID
		,CASE 
			WHEN Tag.TagTypeID = 1
				THEN COALESCE('#' + Tag.TagName, '')
			WHEN Tag.TagTypeID = 2
				THEN COALESCE('#' + Tag.TagName, '')
			WHEN Tag.TagTypeID = 3
				THEN COALESCE('#' + Tag.TagName, '')
			WHEN Tag.TagTypeID = 4
			THEN COALESCE('#' + Tag.TagName, '')
			END AS TagDisplayName
	FROM T_LNK_QN_AssignedTags LNK WITH (NOLOCK)
	INNER JOIN T_TRN_Tag Tag WITH (NOLOCK) ON LNK.TagID = Tag.TagID
		AND Tag.PlantID = @PlantID
	INNER JOIN T_TRN_QUESTION Q WITH (NOLOCK) ON Q.QuestionID = LNK.QuestionID
	WHERE LNK.QuestionID = @QuestionID
		AND LNK.IsDeleted = 0
		AND Q.PlantID = @PlantID

	UNION

	SELECT LNK.TagID
		,(
			SELECT TOP 1 TagName
			FROM T_TRN_Tag T WITH (NOLOCK)
			WHERE T.TagID = LNK.TagID
				AND T.PlantID = @PlantID
			) AS TagName
		,LNK.QuestionID
		,CASE 
			WHEN Tag.TagTypeID = 1
				THEN COALESCE('#' + Tag.TagName, '')
			WHEN Tag.TagTypeID = 2
				THEN COALESCE('#' + Tag.TagName, '')
			WHEN Tag.TagTypeID = 3
				THEN COALESCE('#' + Tag.TagName, '')
			WHEN Tag.TagTypeID = 4
				THEN COALESCE('#' + Tag.TagName, '')
			END AS TagDisplayName
	FROM T_LNK_Tag_AssignedQuestionsTags LNK WITH (NOLOCK)
	INNER JOIN T_TRN_Tag Tag WITH (NOLOCK) ON LNK.TagID = Tag.TagID
		AND Tag.PlantID = @PlantID
	INNER JOIN T_TRN_QUESTION Q WITH (NOLOCK) ON Q.QuestionID = LNK.QuestionID
	WHERE LNK.QuestionID = @QuestionID
		AND LNK.IsDeleted = 0
		AND Q.PlantID = @PlantID

END
GO