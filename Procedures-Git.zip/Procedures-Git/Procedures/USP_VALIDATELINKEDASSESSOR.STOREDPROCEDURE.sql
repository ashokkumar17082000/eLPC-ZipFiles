/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_ValidateLinkedAssessor]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR VALIDATING LINKED ASSESSOR
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					12-MAR-2021			KARTHIKEYAN KANDASAMY		MODIFIED VERSION
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_ValidateLinkedAssessor] @PlantID=1, @AssessorTemplateID=1
*/
CREATE PROCEDURE [USP_ValidateLinkedAssessor] (
	@PlantID INT
	,@AssessorTemplateID INT
	)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT QASR.ID
	FROM T_LNK_AssignedAssessors QASR WITH (NOLOCK)
	INNER JOIN T_TRN_Question Q WITH (NOLOCK) ON QASR.QuestionID = Q.QuestionID
	WHERE QASR.AssessorID IN (
			SELECT AssessorID
			FROM T_TRN_Assessor asr WITH (NOLOCK)
			INNER JOIN T_TRN_AssessorTemplate asrtmp WITH (NOLOCK) ON asrtmp.AssessorTemplateID = asr.AssessorTemplateID
			WHERE asrtmp.PlantID = @PlantID
				AND asr.AssessorTemplateID = @AssessorTemplateID
			)
		AND (QASR.IsDeleted = 0)
		AND (
			Q.PlantID = @PlantID
			AND Q.IsDeleted = 0
			)
	
	UNION
	
	SELECT TASR.ID
	FROM T_LNK_Tag_AssignedAssessors TASR WITH (NOLOCK)
	INNER JOIN T_TRN_Tag T WITH (NOLOCK) ON TASR.TagID = T.TagID
	WHERE TASR.AssessorID IN (
			SELECT AssessorID
			FROM T_TRN_Assessor asr WITH (NOLOCK)
			INNER JOIN T_TRN_AssessorTemplate asrtmp WITH (NOLOCK) ON asrtmp.AssessorTemplateID = asr.AssessorTemplateID
			WHERE asrtmp.PlantID = @PlantID
				AND asr.AssessorTemplateID = @AssessorTemplateID
			)
		AND (TASR.IsDeleted = 0)
		AND (
			T.PlantID = @PlantID
			AND T.IsDeleted = 0
			);
END
GO


