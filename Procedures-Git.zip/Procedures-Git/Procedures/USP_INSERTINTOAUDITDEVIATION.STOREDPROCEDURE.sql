/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_InsertIntoAuditDeviation]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR INSERTING IN TO AUDIT DEVIATION
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			Rajasekar S					PlantId,CurrentUserNTID added
ELPC_LH_005                 18-MAY-2023         GOPIKA P G                  Information To and Tag info added
ELPC_LH_006                	 16-AUG-2023         GOPIKA P G                  Information To and Tag info added
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_InsertIntoAuditDeviation] 
*/
CREATE PROCEDURE [USP_InsertIntoAuditDeviation] @PlantID INT
	,@ValueStreamID INT
	,@AuditID INT
	,@AuditTemplateID INT
	,@DeviationDescription NVARCHAR(500)
	,@ResponsibleEmployee NVARCHAR(200)
	,@HintImages XML NULL
	,@QuestionID INT
	,@ManagerEmailAddress NVARCHAR(100)
	,@ResponsibleEmployeeEmailAddress NVARCHAR(100)
	,@ValueStreamName NVARCHAR(Max)
	,@UserEmailAddress NVARCHAR(100)
	,@DeviationTypeID INT
	,@QuestionText NVARCHAR(Max)
	,@ResponsibleEmpNTID NVARCHAR(20)
	,@Owner NVARCHAR(100)
	,@AdditionalEmployee XML NULL
	,@TagName XML NULL
	,@IsDeleted BIT NULL
	,@OwnerNTID NVARCHAR(20)
	,@CreatedBy_Name NVARCHAR(100)
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION TRNINSERTAUDITDEVIATION

		EXEC [USP_PlantIDValidation] @PlantID = @PlantID
			,@ID = @AuditID
			,@Mode = 'AUDIT'
			,@CurrentUserNTID = @CurrentUserNTID

		IF (
				@AuditTemplateID = 0
				OR @AuditTemplateID IS NULL
				)
		BEGIN
			IF EXISTS (
					SELECT TOP(1) 1
					FROM T_LNK_Audit_AnsweredQuestions WITH(NOLOCK)
					WHERE AuditID = @AuditID
					)
			BEGIN
				SET @AuditTemplateID = (
						SELECT Max(AuditTemplateID)
						FROM T_LNK_Audit_AnsweredQuestions WITH(NOLOCK)
						WHERE AuditID = @AuditID
						)
			END
			ELSE
			BEGIN
				SET @AuditTemplateID = 1
			END
		END
		
		DECLARE @DeviationID INT;
		DECLARE @AnsweredBy_NTID NVARCHAR(20);

		SET @DeviationID = (
				SELECT TOP 1 [AuditDeviationID]
				FROM [T_TRN_AuditDeviation] WITH(NOLOCK)
				WHERE AuditID = @AuditID
					AND AuditTemplateID = @AuditTemplateID
					AND QuestionID = @QuestionID
				)

		DELETE
		FROM [T_TRN_AuditDeviation]
		WHERE AuditDeviationID = @DeviationID

		DELETE
		FROM [T_TRN_AuditDeviationAttachments]
		WHERE AuditDeviationID = @DeviationID

		INSERT INTO [T_TRN_AuditDeviation] (
			AuditID
			,AuditTemplateID
			,ValueStreamID
			,DeviationDescription
			,ResponsibleEmployee
			,CreatedBy_NTID
			,CreatedAt
			,ModifiedAt
			,QuestionID
			,ManagerEmailAddress
			,ResponsibleEmployeeEmailAddress
			,ValueStreamName
			,UserEmailAddress
			,DeviationTypeID
			,QuestionText
			,ResponsibleEmpNTID
			,[Owner]
			,OwnerNTID
			,CreatedBy_Name
			)
		VALUES (
			@AuditID
			,@AuditTemplateID
			,@ValueStreamID
			,@DeviationDescription
			,@ResponsibleEmployee
			,@CurrentUserNTID
			,(
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				)
			,(
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				)
			,@QuestionID
			,@ManagerEmailAddress
			,@ResponsibleEmployeeEmailAddress
			,@ValueStreamName
			,@UserEmailAddress
			,@DeviationTypeID
			,@QuestionText
			,@ResponsibleEmpNTID
			,@Owner
			,@OwnerNTID
			,@CreatedBy_Name
			)

		SET @DeviationID = Scope_Identity();
		INSERT INTO T_LNK_AuditDeviation_AdditionalEmployee (
			DeviationID
			,NTID
			,CreatedAt
			,ModifiedAt
			,IsDeleted
			,CreatedBy_NTID
			,ModifiedBy_NTID
			,UserName
			)
		SELECT @DeviationID AS AuditDeviationID
			,Emp.value('(NTID/text())[1]', 'NVARCHAR(100)') AS NTID
			,(
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				) AS CreatedAt
			,(
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				) AS ModifiedAt
			,@IsDeleted AS FALSE
			,@CurrentUserNTID AS CreatedBy_NTID
			,@CurrentUserNTID AS ModifiedBy_NTID
			,Emp.value('(UserName/text())[1]', 'NVARCHAR(100)') AS UserName
		FROM @AdditionalEmployee.nodes('/ArrayOfUser/User') AS TEMPTABLE(Emp)

		INSERT INTO T_LNK_AuditDeviation_AssignedTags (
			DeviationID
			,TagID
			,IsDeleted
			,CreatedAt
			,ModifiedAt
			,CreatedBy_NTID
			,ModifiedBy_NTID
			,TagName
			)
		SELECT @DeviationID AS AuditDeviationID
			,TagName.value('(TagID/text())[1]', 'int') AS TagID
			,@IsDeleted AS FALSE
			,(
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				) AS CreatedAt
			,(
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				) AS ModifiedAt
			,@CurrentUserNTID AS CreatedBy_NTID
			,@CurrentUserNTID AS ModifiedBy_NTID
			,TagName.value('(FormattedTag/text())[1]', 'nvarchar(100)') AS TagName
		FROM @TagName.nodes('/ArrayOfTag1/Tag1') AS TEMPTABLE(TagName)

		--*******************insert Deviation Images and files**************************
		INSERT INTO [T_TRN_AuditDeviationAttachments] (
			ImagePath
			,ImageTitle
			,FileContent
			,DisplayFileName
			,CreatedBy_NTID
			,AuditDeviationID
			)
		SELECT HintImage.value('(ImagePath/text())[1]', 'NVARCHAR(50)') AS ImagePath
			,HintImage.value('(ImageTitle/text())[1]', 'NVARCHAR(100)') AS ImageTitle
			,HintImage.value('(ByteData/text())[1]', 'varbinary(max)') AS FileContent
			,HintImage.value('(DisplayFileName/text())[1]', 'NVARCHAR(100)') AS DisplayFileName
			,@AnsweredBy_NTID AS CreatedBy_NTID
			,@DeviationID AS AuditDeviationID
		FROM @HintImages.nodes('/ArrayOfHintImage/HintImage') AS TEMPTABLE(HintImage)

		COMMIT TRANSACTION TRNINSERTAUDITDEVIATION
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNINSERTAUDITDEVIATION

		EXEC USP_LogError @PlantID
			,@CurrentUserNTID
	END CATCH
END
GO