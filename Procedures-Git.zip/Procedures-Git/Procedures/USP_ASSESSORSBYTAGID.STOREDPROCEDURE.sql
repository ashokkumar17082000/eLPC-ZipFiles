/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_AssessorsByTagID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING ASSESSORS BY TAGID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					22-MAR-2021			KARTHIKEYAN KANDASAMY		PLANTID ADDED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_AssessorsByTagID] 1, 1
*/
CREATE PROCEDURE [USP_AssessorsByTagID] (
	@PlantID INT
	,@TagID INT
	)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT TA.ID
		,TA.AssessorID
		,TA.TagID
		,TA.TargetFrequencyValue
		,TA.TargetFrequencyTypeID
		,TA.IsDeleted
		,TA.IsMandatoryAssessor
	FROM T_LNK_Tag_AssignedAssessors TA WITH (NOLOCK)
	INNER JOIN T_TRN_Tag T WITH (NOLOCK) ON T.TagID = @TagID
		AND TA.TagID = T.TagID
		AND T.PlantID = @PlantID
	WHERE (
			TA.TagID = @TagID
			AND TA.IsDeleted = 0
			);
END
GO


