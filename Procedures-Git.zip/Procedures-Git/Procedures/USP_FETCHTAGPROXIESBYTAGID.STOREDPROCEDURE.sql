/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchTagProxiesByTagID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING TAG PROXIES BY TAG ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					22-MAR-2021			KARTHIKEYAN KANDASAMY		PLANTID ADDED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_FetchTagProxiesByTagID] 1, 1
*/
CREATE PROCEDURE [USP_FetchTagProxiesByTagID] (
	@PlantID INT
	,@TagID INT
	)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT (
			SELECT TOP 1 UR.NTID
			) AS NTID
		,(
			SELECT TOP 1 UR.UserName
			) AS UserName
		,TP.ID
		,TP.TagID
		,TP.Proxy
		,TP.IsDeleted
		,TP.CreatedAt
		,TP.ModifiedAt
		,TP.CreatedBy_NTID
		,TP.ModifiedBy_NTID
		,UR.UserID
		,UR.PlantID
		,UR.Role_RoleID
		,UR.EmployeeID
		,UR.EmailAddress
		,UR.FirstName
		,UR.LastName
	FROM T_LNK_Tag_Proxy TP WITH (NOLOCK)
	INNER JOIN T_TRN_Tag T WITH (NOLOCK) ON T.TagID = @TagID
		AND T.PlantID = @PlantID
		AND TP.TagID = T.TagID
	INNER JOIN T_MST_User UR WITH (NOLOCK) ON TP.Proxy = UR.NTID
		AND UR.PlantID = @PlantID
	WHERE (
			TP.TagID = @TagID
			AND TP.IsDeleted = 0
			);
END
GO


