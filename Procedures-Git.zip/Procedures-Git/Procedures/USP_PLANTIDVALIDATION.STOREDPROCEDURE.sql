/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_AuditPlantValidation]
///AUTHOR                       : Rajasekar S
///CREATED DATE                 : 23-MAR-2021
///SEE ALSO                     : THIS PROCEDURE TO VALIDATE AUDIT DETAILS 
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_002					23-MAR-2021			Rajasekar S					Initial version
ELPC_LH_002					2-MAR-2021			Rajasekar S					Value stream logic added
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_AuditPlantValidation] 1,1,'RSB4COB'
*/
CREATE PROCEDURE [USP_PlantIDValidation] @PlantID INT
	,@ID INT
	,@Mode VARCHAR(20)
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	IF (@Mode = 'AUDIT')
	BEGIN
		IF ISNULL(@PlantID, 0) <= 0
			OR (
				ISNULL(@ID, 0) > 0
				AND NOT EXISTS (
					SELECT 1
					FROM T_TRN_Audit WITH(NOLOCK)
					WHERE AuditID = @ID
						AND PlantID = @PlantID
					)
				)
		BEGIN
			RAISERROR (
					'Plant ID is empty or Audit/Plant ID combination not found.'
					,16
					,1
					);
		END
	END
	ELSE IF (@Mode = 'VALUESTREAMTEMPLATE')
	BEGIN
		IF ISNULL(@PlantID, 0) <= 0
			OR (
				ISNULL(@ID, 0) > 0
				AND NOT EXISTS (
					SELECT 1
					FROM T_TRN_ValueStreamTemplate WITH(NOLOCK)
					WHERE ValueStreamTemplateID = @ID
						AND PlantID = @PlantID
					)
				)
		BEGIN
			RAISERROR (
					'Plant ID is empty or ValueStreamTemplate/Plant ID combination not found.'
					,16
					,1
					);
		END
	END
	ELSE IF (@Mode = 'VALUESTREAMTEMPLATEHISTORY')
	BEGIN
		IF ISNULL(@PlantID, 0) <= 0
			OR (
				ISNULL(@ID, 0) > 0
				AND NOT EXISTS (
					SELECT 1
					FROM T_HST_ValueStreamTemplateHistory WITH(NOLOCK)
					WHERE ValueStreamTemplateHistoryID = @ID
						AND PlantID = @PlantID
					)
				)
		BEGIN
			RAISERROR (
					'Plant ID is empty or ValueStreamTemplateHistory/Plant ID combination not found.'
					,16
					,1
					);
		END
	END
END
GO


