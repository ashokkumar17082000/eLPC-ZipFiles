/*            
///<SUMMARY>            
///DESCRIPTION                  : STORE PROCEDURE - [USP_GetFullTagDetails]          
///AUTHOR                       : JANARTHANAN KRISHNASAMY          
///CREATED DATE                 : 25-NOV-2020          
///SEE ALSO                     : THIS PROCEDURE TO GET FULL TAG DETAILS          
///MODIFICATION HISTORY   :            
************************************************************************************************************           
///REF      DATE    MODIFIED BY     CHANGE DESCRIPTION            
************************************************************************************************************           
ELPC_LH_001     25-NOV-2020   JANARTHANAN KRISHNASAMY  INITIAL VERSION          
ELPC_LH_002     22-MAR-2021   KARTHIKEYAN KANDASAMY  PLANTID ADDED          
ELPC_LH_002     25-MAY-2022   SHUBHAM BARANGE          Added Is Accessible Column for Merge 
ELPC_LH_002     18-AUG-2023   Sushanth           Perfomance Improvement  
************************************************************************************************************           
///</SUMMARY>          
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)          
EXEC [USP_GetFullTagDetails] 20          
*/          
CREATE PROCEDURE [USP_GetFullTagDetails] (@PlantID INT          
,@CurrentUserNTID NVARCHAR(20))          
AS          
BEGIN          
 SET NOCOUNT ON;          
          
 SELECT (          
   SELECT TOP 1 UserName          
   FROM T_MST_User WITH (NOLOCK)          
   WHERE NTID = TT.ModifiedBy_NTID          
    AND PlantID = @PlantID          
   ) AS ModifiedBy          
  ,(          
   SELECT TOP 1 UserName          
   FROM T_MST_User WITH (NOLOCK)          
   WHERE NTID = TT.CreatedBy_NTID          
    AND PlantID = @PlantID          
   ) AS CreatedBy          
  ,CASE           
   WHEN TT.TagTypeID = 1          
    THEN COALESCE('#' + TT.TagName, '')          
   WHEN TT.TagTypeID = 2          
    THEN COALESCE('#' + TT.TagName, '')          
   WHEN TT.TagTypeID = 3          
    THEN COALESCE('#' + TT.TagName, '')         
 WHEN TT.TagTypeID = 4         
    THEN COALESCE('#' + TT.TagName, '')        
   END AS TagDisplayName          
  ,TagID          
  ,TagDisplayID          
  ,TagName          
  ,IsSingleQuestionSuppressed          
  ,SuppressedDateRangeFrom          
  ,SuppressedDateRangeTo          
  ,IsTargetFrequencyDefined          
  ,TargetFrequencyTypeID          
  ,TargetFrequencyValue          
  ,Tag_PriorityID          
  ,TagTypeID          
  ,IsLocked          
  ,AnonymizeUserDataSettingID          
  ,IsBranchLogicToBeFollowed          
  ,IsMandatoryAssessorsDefined          
  ,IsDeleted          
  ,CreatedAt          
  ,ModifiedAt          
  ,PlantID          
  ,CreatedBy_NTID          
  ,ModifiedBy_NTID          
  --,(          
  -- SELECT STRING_AGG(CONVERT(NVARCHAR(MAX), ValueStreamID), ',')          
  -- FROM T_TRN_ValueStream WITH (NOLOCK)          
  -- WHERE ValueStreamID IN (          
  --   SELECT DISTINCT ValueStreamID          
  --   FROM T_LNK_Tag_AssignedValueStreams WITH (NOLOCK)          
  --   WHERE (IsDeleted = 0)          
  --    AND TagID = TT.TagID          
  --   )          
  --  --AND AssessorTemplateID = Q.Assigned_AssessorTemplateID          
  --  AND IsDeleted = 0          
  -- ) AS ValueStreamIDList 
  ,NULL  AS ValueStreamIDList 
  --,(          
  -- SELECT STRING_AGG(CONVERT(NVARCHAR(MAX), AssessorID), ',')          
  -- FROM T_TRN_Assessor WITH (NOLOCK)          
  -- WHERE AssessorID IN (          
  --   SELECT DISTINCT AssessorID          
  --   FROM T_LNK_Tag_AssignedAssessors WITH (NOLOCK)          
  --   WHERE (IsDeleted = 0)          
  --    AND TagID = TT.TagID          
  --   )          
  --  --AND AssessorTemplateID = Q.Assigned_AssessorTemplateID          
  --  AND IsDeleted = 0          
  -- ) AS AssessorIDList 
  ,NULL  AS AssessorIDList 
  ,CASE           
   WHEN IsLocked = 1          
    THEN IIF((          
       SELECT COUNT(*)          
       FROM T_LNK_Tag_Proxy          
       WHERE TagID = TagID          
        AND (          
         Proxy = @CurrentUserNTID          
         OR CreatedBy_NTID = @CurrentUserNTID          
         OR ModifiedBy_NTID = @CurrentUserNTID          
         )          
        AND IsDeleted=0          
       ) > 0, 1, 0)          
   ELSE 1          
   END AS IsAccessible    
   ,IsSearchableTag  
   ,IsSkipQuestionDefined  
   ,IsQuestionOverviewDefined  
   ,IsProgressPercentageDefined  
   ,IsResultOverviewDefined  
   ,IsResumeTagDefined  
   ,IsReportingEmailDefined  
 FROM T_TRN_Tag TT WITH (NOLOCK)          
 WHERE (          
   TT.TagID IS NOT NULL          
   AND TT.PlantID = @PlantID          
   AND (          
    TT.IsDeleted = 0          
    OR TT.IsDeleted IS NULL          
    )          
   )          
 ORDER BY TT.ModifiedAt DESC;          
END  
GO
