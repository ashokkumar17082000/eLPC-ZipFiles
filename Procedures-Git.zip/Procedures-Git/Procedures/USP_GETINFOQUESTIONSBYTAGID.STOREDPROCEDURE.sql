/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_GetInfoQuestionsByTagID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING INFO QUESTIONS BY TAGID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					25-MAR-2021			KARTHIKEYAN KANDASAMY		PLANTID ADDED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_GetInfoQuestionsByTagID] 1, 1
*/
CREATE PROCEDURE [USP_GetInfoQuestionsByTagID] (
	@PlantID INT
	,@TagID INT
	)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT LNK.TagID
		,TT.TagDisplayID
		,(
			SELECT TOP 1 QuestionText
			FROM T_TRN_Question Q WITH(NOLOCK)
			WHERE Q.QuestionID = LNK.QuestionID
				AND Q.PlantID = @PlantID
			) AS QuestionText
		,LNK.QuestionID
		,TQ.QuestionDisplayID
	FROM T_LNK_Tag_AssignedQuestionsTags LNK WITH (NOLOCK)
	INNER JOIN [T_TRN_Tag] TT WITH (NOLOCK) ON TT.TagID = LNK.TagID
		AND TT.PlantID = @PlantID
	INNER JOIN [T_TRN_Question] TQ WITH (NOLOCK) ON TQ.QuestionID = LNK.QuestionID
		AND TQ.PlantID = @PlantID
	WHERE LNK.TagID = @TagID
		AND LNK.QuestionID IS NOT NULL
		AND (LNK.IsDeleted = 0)
	
	UNION
	
	SELECT LNK.TagID
		,TT.TagDisplayID
		,(
			SELECT TOP 1 QuestionText
			FROM T_TRN_Question Q WITH(NOLOCK)
			WHERE Q.QuestionID = LNK.QuestionID
				AND Q.PlantID = @PlantID
			) AS QuestionText
		,LNK.QuestionID
		,TQ.QuestionDisplayID
	FROM T_LNK_QN_AssignedTags LNK WITH (NOLOCK)
	INNER JOIN [T_TRN_Tag] TT WITH (NOLOCK) ON TT.TagID = LNK.TagID
		AND TT.PlantID = @PlantID
	INNER JOIN [T_TRN_Question] TQ WITH (NOLOCK) ON TQ.QuestionID = LNK.QuestionID
		AND TQ.PlantID = @PlantID
	WHERE LNK.TagID = @TagID
		AND LNK.QuestionID IS NOT NULL
		AND (LNK.IsDeleted = 0)
	ORDER BY LNK.QuestionID;
END
GO


