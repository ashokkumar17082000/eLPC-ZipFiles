/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_AddEditAuditDetail]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR ADD/EDIT AUDIT DETAILS
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_AddEditAuditDetail]
*/
CREATE PROCEDURE [USP_AddEditAuditDetail] @AuditID INT NULL
	,@AuditDetailID INT NULL
	,@ValueStreamID INT NULL
	,@LeadAuditor NVARCHAR(10) NULL
	,@HOD NVARCHAR(10) NULL
	,@FloorManager NVARCHAR(10) NULL
	,@QMM NVARCHAR(10) NULL
	,@CreatedBy_UserID INT NULL
	,@ModifiedBy_UserID INT NULL
	,@Others NVARCHAR(max)
	,@Users XML NULL
AS
BEGIN
	BEGIN TRY
		DECLARE @min INT = 0
			,@max INT = 0
			,@TagID INT = 0

		IF (
				@AuditDetailID IS NULL
				OR @AuditDetailID = 0
				)
		BEGIN
			INSERT INTO [T_TRN_AuditDetail] (
				AuditID
				,ValueStreamID
				,LeadAuditor
				,HOD
				,FloorManager
				,QMM
				,CreatedAt
				,ModifiedAt
				,CreatedBy_UserID
				,ModifiedBy_UserID
				)
			VALUES (
				@AuditID
				,@ValueStreamID
				,@LeadAuditor
				,@HOD
				,@FloorManager
				,@QMM
				,(SELECT * from fnGetDateTime())
				,(SELECT * from fnGetDateTime())
				,@CreatedBy_UserID
				,@ModifiedBy_UserID
				)

			SET @AuditDetailID = SCOPE_IDENTITY()
		END
		ELSE IF (@AuditDetailID IS NOT NULL)
		BEGIN
			UPDATE T_TRN_AuditDetail
			SET AuditID = @AuditID
				,ValueStreamID = @ValueStreamID
				,LeadAuditor = @LeadAuditor
				,HOD = @HOD
				,FloorManager = @FloorManager
				,QMM = @QMM
				,ModifiedAt = (SELECT * from fnGetDateTime())
				,ModifiedBy_UserID = @ModifiedBy_UserID
			WHERE AuditDetailID = @AuditDetailID
		END

		EXEC USP_AddEditUsers @Users
	END TRY

	BEGIN CATCH
		SELECT ERROR_NUMBER() AS ErrorNumber
			,ERROR_SEVERITY() AS ErrorSeverity
			,ERROR_STATE() AS ErrorState
			,ERROR_PROCEDURE() AS ErrorProcedure
			,ERROR_LINE() AS ErrorLine
			,ERROR_MESSAGE() AS ErrorMessage;
	END CATCH
END
GO


