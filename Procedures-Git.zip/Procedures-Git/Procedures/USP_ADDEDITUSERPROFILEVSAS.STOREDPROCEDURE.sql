/****** Object:  StoredProcedure [dbo].[USP_AddEditUserProfileVSAS]    Script Date: 1/11/2024 4:04:45 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
  
/*    
--///<SUMMARY>    
--///DESCRIPTION                  : STORE PROCEDURE - [USP_AddEditUserProfileVSAS]  
--///AUTHOR                       : VENKATESH  
--///CREATED DATE                 : 16-JUN-2021   
--///SEE ALSO                     : THIS PROCEDURE IS USED FOR ADD/EDIT USER PROFILE DETAILS FOR VALUESTREAM AND ASSESSORS  
--///MODIFICATION HISTORY    :    
--///************************************************************************************************************/    
--///REF       DATE        MODIFIED BY    CHANGE DESCRIPTION    
--///************************************************************************************************************/    
--///eLPC_LH_002     16-JUN-2021       VENKATESH    INITIAL VERSION  
--///eLPC_LH_002     5-JAN-2024         ASHOK       CustomIcon change
--///************************************************************************************************************/    
--///</SUMMARY>  
  
----SAMPLE EXECUTION  
--EXEC [USP_AddEditUserProfileVSAS] 1,'<?xml version="1.0" encoding="utf-16"?><ArrayOfUserProfileValueStream xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <UserProfileValueStream>
    <UserProfileValueStreamID>31</UserProfileValueStreamID>
    <PlantID xsi:nil="true" />
    <RowID>0</RowID>
    <ValueStreamTemplateID>189</ValueStreamTemplateID>
    <ValueStreamTemplateArr />
    <SelectedItemValueStreamTemplate />
    <ValueStreamCategoryID xsi:nil="true" />
    <ValueStreamCategoryArr />
    <SelectedItemvalueStreamCategory />
    <ValueStreamID>37668</ValueStreamID>
    <ValueStreamArr />
    <SelectedItemvalueStream />
    <IsForgotValueStream>false</IsForgotValueStream>
    <IsDeleted>false</IsDeleted>
    <ModifiedAt>0001-01-01T00:00:00</ModifiedAt>
    <CreatedAt>0001-01-01T00:00:00</CreatedAt>
  </UserProfileValueStream>
  <UserProfileValueStream>
    <UserProfileValueStreamID>32</UserProfileValueStreamID>
    <PlantID xsi:nil="true" />
    <RowID>1</RowID>
    <ValueStreamTemplateID>187</ValueStreamTemplateID>
    <ValueStreamTemplateArr />
    <SelectedItemValueStreamTemplate />
    <ValueStreamCategoryID xsi:nil="true" />
    <ValueStreamCategoryArr />
    <SelectedItemvalueStreamCategory />
    <ValueStreamID>37183</ValueStreamID>
    <ValueStreamArr />
    <SelectedItemvalueStream />
    <IsForgotValueStream>false</IsForgotValueStream>
    <IsDeleted>false</IsDeleted>
    <ModifiedAt>0001-01-01T00:00:00</ModifiedAt>
    <CreatedAt>0001-01-01T00:00:00</CreatedAt>
  </UserProfileValueStream>
  <UserProfileValueStream>
    <UserProfileValueStreamID>33</UserProfileValueStreamID>
    <PlantID xsi:nil="true" />
    <RowID>2</RowID>
    <ValueStreamTemplateID>188</ValueStreamTemplateID>
    <ValueStreamTemplateArr />
    <SelectedItemValueStreamTemplate />
    <ValueStreamCategoryID xsi:nil="true" />
    <ValueStreamCategoryArr />
    <SelectedItemvalueStreamCategory />
    <ValueStreamID>37532</ValueStreamID>
    <ValueStreamArr />
    <SelectedItemvalueStream />
    <IsForgotValueStream>false</IsForgotValueStream>
    <IsDeleted>false</IsDeleted>
    <ModifiedAt>0001-01-01T00:00:00</ModifiedAt>
    <CreatedAt>0001-01-01T00:00:00</CreatedAt>
  </UserProfileValueStream>
</ArrayOfUserProfileValueStream>','<?xml version="1.0" encoding="utf-16"?><ArrayOfUserProfileAssessor xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <UserProfileAssessor>
    <UserProfileAssessorID>33</UserProfileAssessorID>
    <PlantID xsi:nil="true" />
    <RowID>0</RowID>
    <AssessorTemplateID>187</AssessorTemplateID>
    <AssessorTemplateArr />
    <SelectedItemAssessorTemplate />
    <AssessorID>941</AssessorID>
    <AssessorArr />
    <SelectedItemAssessor />
    <IsForgotAssessor>false</IsForgotAssessor>
    <IsDeleted>false</IsDeleted>
    <ModifiedAt>0001-01-01T00:00:00</ModifiedAt>
    <CreatedAt>0001-01-01T00:00:00</CreatedAt>
  </UserProfileAssessor>
</ArrayOfUserProfileAssessor>','JSD2KOR',0  
*/  
CREATE PROCEDURE [dbo].[USP_AddEditUserProfileVSAS] (  
 @PlantID INT  
 ,@UserProfileVSXML XML NULL  
 ,@UserProfileASXML XML NULL  
 ,@CurrentUserNTID NVARCHAR(20)  
 ,@customeIconID INT  
 ,@customeIconID1 INT
 )  
AS  
BEGIN  
 BEGIN TRY  
  BEGIN TRANSACTION TRNADDEDITUSERVSAS  
  
  DECLARE @min INT = 0  
   ,@max INT = 0  
  DECLARE @Scope_Identity_Table_VS TABLE (UserProfileValueStreamID INT);--Scope identities for all inserted rows  
  DECLARE @Scope_Identity_Table_AS TABLE (UserProfileAssessorID INT);--Scope identities for all inserted rows  
  
  SELECT Identity(INT, 1, 1) AS ID  
   ,ValueStreamConfig.value('(UserProfileValueStreamID/text())[1]', 'INT') AS UserProfileValueStreamID  
   ,ValueStreamConfig.value('(RowID/text())[1]', 'INT') AS RowID  
   ,ValueStreamConfig.value('(ValueStreamTemplateID/text())[1]', 'INT') AS ValueStreamTemplateID  
   ,ValueStreamConfig.value('(ValueStreamCategoryID/text())[1]', 'INT') AS ValueStreamCategoryID  
   ,ValueStreamConfig.value('(ValueStreamID/text())[1]', 'INT') AS ValueStreamID  
   ,ValueStreamConfig.value('(IsForgotValueStream/text())[1]', 'BIT') AS IsForgotValueStream  
   ,ValueStreamConfig.value('(SessionID/text())[1]', 'NVARCHAR(20)') AS SessionID  
  INTO #T1  
  FROM @UserProfileVSXML.nodes('/ArrayOfUserProfileValueStream/UserProfileValueStream') AS TEMPTABLE(ValueStreamConfig);  
  
  --select * from #T1  
  SELECT Identity(INT, 1, 1) AS ID  
   ,AssessorConfig.value('(UserProfileAssessorID/text())[1]', 'INT') AS UserProfileAssessorID  
   ,AssessorConfig.value('(RowID/text())[1]', 'INT') AS RowID  
   ,AssessorConfig.value('(AssessorTemplateID/text())[1]', 'INT') AS AssessorTemplateID  
   ,AssessorConfig.value('(AssessorID/text())[1]', 'INT') AS AssessorID  
   ,AssessorConfig.value('(IsForgotAssessor/text())[1]', 'BIT') AS IsForgotAssessor  
   ,AssessorConfig.value('(SessionID/text())[1]', 'NVARCHAR(20)') AS SessionID  
  INTO #T2  
  FROM @UserProfileASXML.nodes('/ArrayOfUserProfileAssessor/UserProfileAssessor') AS TEMPTABLE(AssessorConfig);  
  
  --select * from #T2  
  INSERT INTO @Scope_Identity_Table_VS  
  SELECT UserProfileValueStreamID  
  FROM T_TRN_ValueStreamConfig WITH (NOLOCK)  
  WHERE UserProfileValueStreamID NOT IN (  
    SELECT UserProfileValueStreamID  
    FROM #T1 WITH (NOLOCK)  
    WHERE (  
      UserProfileValueStreamID IS NOT NULL  
      AND UserProfileValueStreamID > 0  
      )  
    )  
   AND PlantID = @PlantID  
   AND User_NTID = @CurrentUserNTID  
  
  --select * from @Scope_Identity_Table_VS  
  DELETE T_TRN_ValueStreamConfig  
  WHERE UserProfileValueStreamID IN (  
    SELECT UserProfileValueStreamID  
    FROM @Scope_Identity_Table_VS  
    )  
  /*** New User Profile Table Data ***/
  /***Start***/
  Update T_TRN_UserProfile 
  Set ValueStreamTemplateID = null,
      ValueStreamTemplateName = null, 
	  ValueStreamID = null,
	  ValueStreamName = null 
	  where UserProfileValueStreamID in (SELECT UserProfileValueStreamID FROM @Scope_Identity_Table_VS)
	  and user_NTID = @CurrentUserNTID
	  and PlantID = @PlantID
 /***End***/

  INSERT INTO T_TRN_ValueStreamConfig (  
   ValueStreamTemplateID  
   ,ValueStreamCategoryID  
   ,ValueStreamID  
   ,RowID  
   ,IsForgotValueStream  
   ,SessionID  
   ,IsDeleted  
   ,CreatedAt  
   ,ModifiedAt  
   ,PlantID  
   ,User_NTID  
   )  
  OUTPUT inserted.UserProfileValueStreamID  
  INTO @Scope_Identity_Table_VS  
  SELECT ValueStreamTemplateID  
   ,ValueStreamCategoryID  
   ,ValueStreamID  
   ,RowID  
   ,IsForgotValueStream     ,SessionID  
   ,0  
   ,(  
    SELECT FormattedDateTime  
    FROM fnGetDateTime(@PlantID)  
    )  
   ,(  
    SELECT FormattedDateTime  
    FROM fnGetDateTime(@PlantID)  
    )  
   ,@PlantID  
   ,@CurrentUserNTID  
  FROM #T1 WITH (NOLOCK)  
  WHERE (  
    UserProfileValueStreamID IS NULL  
    OR UserProfileValueStreamID = 0  
    )  
  
    /*** New User Profile Table Data ***/
  /***Start***/
  INSERT INTO T_TRN_UserProfile (       
    User_NTID
   ,PlantID
   ,UserProfileValueStreamID  
   ,ValueStreamTemplateID  
   ,ValueStreamTemplateName
   ,ValueStreamID
   ,ValueStreamName
   ,UserProfileAssessorID
   ,AssessorTemplateID
   ,AssessorTemplateName
   ,AssessorID
   ,AssessorName
   ,CustomIConID
   )
   SELECT 
   @CurrentUserNTID
  ,@PlantID
  ,vsc.UserProfileValueStreamID  
  ,vsc.ValueStreamTemplateID
  ,vst.ValueStreamTemplateName
  ,vsc.ValueStreamID
  ,vs.ValueStreamName
  ,null
  ,null
  ,null
  ,null
  ,null
  ,null
  FROM T_TRN_ValueStreamConfig vsc WITH (NOLOCK)
  INNER JOIN T_TRN_ValueStreamTemplate vst WITH (NOLOCK) on vsc.ValueStreamTemplateID = vst.ValueStreamTemplateID
  INNER JOIN T_TRN_ValueStream vs WITH (NOLOCK)  on vsc.ValueStreamID = vs.ValueStreamID
  WHERE vsc.UserProfileValueStreamID NOT IN (SELECT DISTINCT UserProfileValueStreamID FROM T_TRN_UserProfile 
        WHERE PlantID = @PlantID AND user_NTID = @CurrentUserNTID AND UserProfileValueStreamID IS NOT NULL)
		AND vsc.PlantID = @PlantID AND vsc.User_NTID = @CurrentUserNTID

  --INSERT INTO T_TRN_UserProfile (       
  --  User_NTID
  -- ,PlantID
  -- ,UserProfileValueStreamID  
  -- ,ValueStreamTemplateID  
  -- ,ValueStreamTemplateName
  -- ,ValueStreamID
  -- ,ValueStreamName
  -- ,UserProfileAssessorID
  -- ,AssessorTemplateID
  -- ,AssessorTemplateName
  -- ,AssessorID
  -- ,AssessorName
  -- ,CustomIConID
  -- )
  --Select 
  --@CurrentUserNTID
  --,@PlantID
  --,(SELECT UserProfileValueStreamID  
  --  FROM @Scope_Identity_Table_VS)
  --,temp.ValueStreamTemplateID
  --,vst.ValueStreamTemplateName
  --,temp.ValueStreamID
  --,vs.ValueStreamName
  --,null
  --,null
  --,null
  --,null
  --,null
  --,null
  --from #T1 temp WITH (NOLOCK)
  --inner join T_TRN_ValueStreamTemplate vst WITH (NOLOCK) on temp.ValueStreamTemplateID = vst.ValueStreamTemplateID
  --inner join T_TRN_ValueStream vs WITH (NOLOCK)  on temp.ValueStreamID = vs.ValueStreamID
  --WHERE (  
  --  temp.UserProfileValueStreamID IS NULL  
  --  OR temp.UserProfileValueStreamID = 0  
  --  )  

  /***End***/

  --select * from @Scope_Identity_Table_VS  
  SET @min = (  
    SELECT MIN(ID)  
    FROM #T1  
    );--Get minimum row number from temp table  
  SET @max = (  
    SELECT Max(ID)  
    FROM #T1  
    );--Get maximum row number from temp table  
  
  WHILE (@min <= @max)  
  BEGIN  
   DECLARE @UserProfileValueStreamID INT  
    ,@RowID INT  
    ,@ValueStreamTemplateID INT  
    ,@ValueStreamCategoryID INT  
    ,@ValueStreamID INT  
    ,@IsForgotValueStream BIT  
    ,@SessionID NVARCHAR(20)  
  
   --select * from #T1 WHERE ID = @min;  
   SELECT @UserProfileValueStreamID = UserProfileValueStreamID  
    ,@RowID = RowID  
    ,@ValueStreamTemplateID = ValueStreamTemplateID  
    ,@ValueStreamCategoryID = ValueStreamCategoryID  
    ,@ValueStreamID = ValueStreamID  
    ,@IsForgotValueStream = IsForgotValueStream  
    ,@SessionID = SessionID  
   FROM #T1 WITH (NOLOCK)  
   WHERE ID = @min;  
  
   IF EXISTS (  
     SELECT 1  
     FROM T_TRN_ValueStreamConfig WITH (NOLOCK)  
     WHERE UserProfileValueStreamID = @UserProfileValueStreamID  
     )  
   BEGIN  
    -- Update the Assessor data if that exists  
    UPDATE T_TRN_ValueStreamConfig  
    SET RowID = @RowID  
     ,ValueStreamTemplateID = @ValueStreamTemplateID  
     ,ValueStreamCategoryID = @ValueStreamCategoryID  
     ,ValueStreamID = @ValueStreamID  
     ,IsForgotValueStream = @IsForgotValueStream  
     ,SessionID = @SessionID  
     ,User_NTID = @CurrentUserNTID  
     ,PlantID = @PlantID  
     ,IsDeleted = 0  
     ,ModifiedAt = (  
      SELECT FormattedDateTime  
      FROM fnGetDateTime(@PlantID)  
      )  
    WHERE UserProfileValueStreamID = @UserProfileValueStreamID;  
   END  
  
   /*** New User Profile Table Data ***/
  /***Start***/
  IF EXISTS (  
     SELECT 1  
     FROM T_TRN_UserProfile WITH (NOLOCK)  
     WHERE UserProfileValueStreamID = @UserProfileValueStreamID 
	 AND PlantID = @PlantID AND user_NTID = @CurrentUserNTID
     )  
   BEGIN  
    UPDATE u  
    SET u.User_NTID = @CurrentUserNTID  
     ,u.PlantID = @PlantID
	 ,u.ValueStreamTemplateID = @ValueStreamTemplateID 
	 ,u.ValueStreamTemplateName = vst.ValueStreamTemplateName
     ,u.ValueStreamID = @ValueStreamID  
     ,u.ValueStreamName = vs.ValueStreamName
	 FROM T_TRN_UserProfile u WITH (NOLOCK) 
	 inner join #T1 temp WITH (NOLOCK)  on u.UserProfileValueStreamID = temp.UserProfileValueStreamID
	 inner join T_TRN_ValueStreamTemplate vst WITH (NOLOCK) on temp.ValueStreamTemplateID = vst.ValueStreamTemplateID
	 inner join T_TRN_ValueStream vs WITH (NOLOCK) on temp.ValueStreamID = vs.ValueStreamID
    WHERE u.UserProfileValueStreamID = @UserProfileValueStreamID;  
   END  

  /***End***/

   SET @min = @min + 1;  
    --select @min  
  END  
  
  INSERT INTO @Scope_Identity_Table_AS  
  SELECT UserProfileAssessorID  
  FROM T_TRN_AssessorConfig WITH (NOLOCK)  
  WHERE UserProfileAssessorID NOT IN (  
    SELECT UserProfileAssessorID  
    FROM #T2 WITH (NOLOCK)  
    WHERE (  
      UserProfileAssessorID IS NOT NULL  
      AND UserProfileAssessorID > 0  
      )  
    )  
   AND PlantID = @PlantID  
   AND User_NTID = @CurrentUserNTID  
  
  --select * from @Scope_Identity_Table_AS  
  DELETE T_TRN_AssessorConfig  
  WHERE UserProfileAssessorID IN (  
    SELECT UserProfileAssessorID  
    FROM @Scope_Identity_Table_AS  
    )  
  
  /*** New User Profile Table Data ***/
  /***Start***/
  Update T_TRN_UserProfile 
  Set AssessorTemplateID = null,
      AssessorTemplateName = null, 
	  AssessorID = null,
	  AssessorName = null 
	  where UserProfileAssessorID in (SELECT UserProfileAssessorID  
    FROM @Scope_Identity_Table_AS  
    )  
	  and user_NTID = @CurrentUserNTID
	  and PlantID = @PlantID
 /***End***/

  INSERT INTO T_TRN_AssessorConfig (  
   AssessorTemplateID  
   ,AssessorID  
   ,RowID  
   ,IsForgotAssessor  
   ,SessionID  
   ,IsDeleted  
   ,CreatedAt  
   ,ModifiedAt  
   ,PlantID  
   ,User_NTID  
   )  
  OUTPUT inserted.UserProfileAssessorID  
  INTO @Scope_Identity_Table_VS  
  SELECT AssessorTemplateID  
   ,AssessorID  
   ,RowID  
   ,IsForgotAssessor  
   ,SessionID  
   ,0  
   ,(  
    SELECT FormattedDateTime  
    FROM fnGetDateTime(@PlantID)  
    )  
   ,(  
    SELECT FormattedDateTime  
    FROM fnGetDateTime(@PlantID)  
    )  
   ,@PlantID  
   ,@CurrentUserNTID  
  FROM #T2 WITH (NOLOCK)  
  WHERE (  
    UserProfileAssessorID IS NULL  
    OR UserProfileAssessorID = 0  
    )  
  
  /*** New User Profile Table Data ***/
  /***Start***/
  INSERT INTO T_TRN_UserProfile (       
    User_NTID
   ,PlantID
   ,UserProfileValueStreamID  
   ,ValueStreamTemplateID  
   ,ValueStreamTemplateName
   ,ValueStreamID
   ,ValueStreamName
   ,UserProfileAssessorID
   ,AssessorTemplateID
   ,AssessorTemplateName
   ,AssessorID
   ,AssessorName
   ,CustomIConID
   )
   SELECT 
   @CurrentUserNTID
  ,@PlantID
  ,null
  ,null
  ,null
  ,null
  ,null
  ,a.UserProfileAssessorID  
  ,a.AssessorTemplateID
  ,ast.AssessorTemplateName
  ,a.AssessorID
  ,ts.AssessorName
  ,null
  FROM T_TRN_AssessorConfig a WITH (NOLOCK)
  INNER JOIN T_TRN_AssessorTemplate ast WITH (NOLOCK) on a.AssessorTemplateID = ast.AssessorTemplateID
  INNER JOIN T_TRN_Assessor ts WITH (NOLOCK)  on a.AssessorID = ts.AssessorID
  WHERE a.UserProfileAssessorID NOT IN (SELECT DISTINCT UserProfileAssessorID FROM T_TRN_UserProfile 
        WHERE PlantID = @PlantID AND user_NTID = @CurrentUserNTID AND UserProfileAssessorID IS NOT NULL)
		AND a.PlantID = @PlantID AND a.User_NTID = @CurrentUserNTID

  --INSERT INTO T_TRN_UserProfile (       
  --  User_NTID
  -- ,PlantID
  -- ,UserProfileValueStreamID  
  -- ,ValueStreamTemplateID  
  -- ,ValueStreamTemplateName
  -- ,ValueStreamID
  -- ,ValueStreamName
  -- ,UserProfileAssessorID
  -- ,AssessorTemplateID
  -- ,AssessorTemplateName
  -- ,AssessorID
  -- ,AssessorName
  -- ,CustomIConID
  -- )
  --Select 
  --@CurrentUserNTID
  --,@PlantID
  --,null
  --,null
  --,null
  --,null
  --,null
  --,(SELECT UserProfileAssessorID  
  --  FROM @Scope_Identity_Table_VS  
  --  )  
  --,temp2.AssessorTemplateID
  --,ast.AssessorTemplateName
  --,temp2.AssessorID
  --,a.AssessorName
  --,null
  --from #T2 temp2 WITH (NOLOCK) 
  --inner join T_TRN_AssessorTemplate ast WITH (NOLOCK) on temp2.AssessorTemplateID = ast.AssessorTemplateID
  --inner join T_TRN_Assessor a WITH (NOLOCK) on temp2.AssessorID = a.AssessorID
  --WHERE (  
  --  temp2.UserProfileAssessorID IS NULL  
  --  OR temp2.UserProfileAssessorID = 0  
  --  )  

  /***End***/

  --select * from @Scope_Identity_Table_VS  
  SET @min = (  
    SELECT MIN(ID)  
    FROM #T2  
    );--Get minimum row number from temp table  
  SET @max = (  
    SELECT Max(ID)  
    FROM #T2  
    );--Get maximum row number from temp table  
  
  WHILE (@min <= @max)  
  BEGIN  
   DECLARE @UserProfileAssessorID INT  
    ,@AS_RowID INT  
    ,@AssessorTemplateID INT  
    ,@AssessorID INT  
    ,@IsForgotAssessor BIT  
    ,@AS_SessionID NVARCHAR(20)  
  
   --select * from #T2 WHERE ID = @min;  
   SELECT @UserProfileAssessorID = UserProfileAssessorID  
    ,@AS_RowID = RowID  
    ,@AssessorTemplateID = AssessorTemplateID  
    ,@AssessorID = AssessorID  
    ,@IsForgotAssessor = IsForgotAssessor  
    ,@AS_SessionID = SessionID  
   FROM #T2 WITH (NOLOCK)  
   WHERE ID = @min;  
  
   IF EXISTS (  
     SELECT 1  
     FROM T_TRN_AssessorConfig WITH (NOLOCK)  
     WHERE UserProfileAssessorID = @UserProfileAssessorID  
     )  
   BEGIN  
    -- Update the Assessor data if that exists  
    UPDATE T_TRN_AssessorConfig  
    SET RowID = @AS_RowID  
     ,AssessorTemplateID = @AssessorTemplateID  
     ,AssessorID = @AssessorID  
     ,IsForgotAssessor = @IsForgotAssessor  
     ,SessionID = @AS_SessionID  
     ,User_NTID = @CurrentUserNTID  
     ,PlantID = @PlantID  
     ,IsDeleted = 0  
     ,ModifiedAt = (  
      SELECT FormattedDateTime  
      FROM fnGetDateTime(@PlantID)  
      )  
    WHERE UserProfileAssessorID = @UserProfileAssessorID;  
   END  
  
  /*** New User Profile Table Data ***/
  /***Start***/
  IF EXISTS (  
     SELECT 1  
     FROM T_TRN_UserProfile WITH (NOLOCK)  
     WHERE UserProfileAssessorID = @UserProfileAssessorID 
	 AND PlantID = @PlantID AND user_NTID = @CurrentUserNTID
     )  
   BEGIN  
    UPDATE u  
    SET u.User_NTID = @CurrentUserNTID  
     ,u.PlantID = @PlantID
	 ,u.AssessorTemplateID = @AssessorTemplateID 
	 ,u.AssessorTemplateName = ast.AssessorTemplateName
     ,u.AssessorID = @AssessorID  
     ,u.AssessorName = a.AssessorName
	 FROM T_TRN_UserProfile u WITH (NOLOCK) 
	 inner join #T2 temp2 WITH (NOLOCK) on u.UserProfileAssessorID = temp2.UserProfileAssessorID
	 inner join T_TRN_AssessorTemplate ast WITH (NOLOCK) on temp2.AssessorTemplateID = ast.AssessorTemplateID
	 inner join T_TRN_Assessor a WITH (NOLOCK) on temp2.AssessorID = a.AssessorID
    WHERE u.UserProfileAssessorID = @UserProfileAssessorID;  
   END  

  /***End***/

   SET @min = @min + 1;  
  END  
  
  UPDATE T_MST_USER SET CustomIConID=@customeIconID WHERE  PlantID = @PlantID AND NTID = @CurrentUserNTID
  
  /*** New User Profile Table Data ***/
  /***Start***/
  UPDATE T_TRN_UserProfile SET CustomIConID = @customeIconID WHERE  PlantID = @PlantID AND user_NTID = @CurrentUserNTID
    /***End***/

	delete from t_trn_customicons where plantid=@plantid and ntid=@CurrentUserNTID
  IF @customeIconID=0
  BEGIN
  insert into t_trn_customicons values(@plantID,@CurrentUserNTID,getdate(),@customeIconID) 
  END	
  IF @customeIconID >0
  BEGIN
  insert into t_trn_customicons values(@plantID,@CurrentUserNTID,getdate(),@customeIconID) 
  END	
 
  IF @customeIconID1 > 0
  BEGIN
  insert into t_trn_customicons values(@plantID,@CurrentUserNTID,getdate(),@customeIconID1) 
  END
  SELECT count(*)  
  FROM T_TRN_ValueStreamConfig WITH (NOLOCK)  
  WHERE PlantID = @PlantID  
  
  COMMIT TRANSACTION TRNADDEDITUSERVSAS;  
 END TRY  
  
 BEGIN CATCH  
  ROLLBACK TRANSACTION TRNADDEDITUSERVSAS;  
  
  EXEC [USP_LogError] @PlantID  
   ,@CurrentUserNTID;  
 END CATCH  
END  
  
