/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_SingleLineTextByQuestionID] 
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING SINGLE LINE TEXT BY QUESTIONID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			VENKATESH GOVINDARAJ		PlantID & Code Cleanup
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_SingleLineTextByQuestionID] 1, 1
*/
CREATE PROCEDURE [USP_SingleLineTextByQuestionID] @QuestionID INT
	,@PlantID INT
AS
BEGIN
	SET NOCOUNT ON;

	SELECT T.ID
		,T.MaxCharacters
		,T.IsCalculated
		,T.DefaultValue
		,T.QuestionID
		,T.IsDeleted
	FROM T_TRN_SingleLineText T WITH (NOLOCK)
	INNER JOIN T_TRN_QUESTION Q WITH (NOLOCK) ON Q.QuestionID = T.QuestionID
	WHERE T.QuestionID = @QuestionID
		AND T.IsDeleted = 0
		AND Q.PlantID = @PlantID
END
GO


