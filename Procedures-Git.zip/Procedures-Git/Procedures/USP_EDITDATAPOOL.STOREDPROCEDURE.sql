/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_EditDataPool]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR FETCHING THE DETAILS WHILE EDITING DATAPOOL
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					25-MAR-2021			SIKHESH S					ADDITIONAL INPUT PARAMATERS INCLUDED, OUTPUT PARAMETERS REVISED, STANDARD RULES APPLIED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_EditDataPool] 2,1
*/
CREATE PROCEDURE [USP_EditDataPool] (
	@DataPoolID INT
	,@PlantID INT
	,@CurrentUserNTID NVARCHAR(20) = NULL
	)
AS
BEGIN
	SELECT DISTINCT (PN.DataPoolID)
		,PN.DataPoolDisplayID
		,PN.TIMESTAMP
		,TU.UserName
		,vs.ValueStreamData
		,vs.ValueStreamName
		,TA.AssessorName
		,Q.QuestionText
		,PN.Answer
		,PN.ChoiceID
		,PN.ObtainedScore
		,PN.answerType_AnswerTypeID
		,PN.ObtainedScore
		,PN.QuestionID
		,Q.QuestionDisplayID
		,PN.AssessorID
		,PN.ValueStreamID
		,PN.AnsweredBy_NTID
		,D.DeviationDescription
		,D.ResponsibleEmployee
		,D.DeviationID
		,D.DeviationDisplayID
		,VST.ValueStreamTemplateName
		,VST.Delimiter
		,VSC.ValueStreamCategoryName
		,CASE 
			WHEN Q.QuestionID IN (
					SELECT QuestionID
					FROM T_LNK_Custom_Questions WITH(NOLOCK)
					WHERE IsCustomMode = 1
					)
				THEN 1
			ELSE 0
			END AS IsCustomMode
		,PN.AuditID
		,PN.AuditTemplateID
	FROM [T_TRN_DataPool] PN WITH (NOLOCK)
	INNER JOIN T_TRN_ValueStream VS WITH (NOLOCK) ON PN.ValueStreamID = VS.ValueStreamID
	LEFT JOIN T_TRN_Assessor TA WITH (NOLOCK) ON PN.AssessorID = TA.AssessorID
	INNER JOIN T_MSt_User TU WITH (NOLOCK) ON PN.AnsweredBy_NTID = TU.NTID
		AND TU.PlantID = @PlantID
	INNER JOIN T_TRN_Question Q WITH (NOLOCK) ON PN.QuestionID = Q.QuestionID
		AND Q.PlantID = @PlantID
	LEFT JOIN T_TRN_Deviation D WITH (NOLOCK) ON D.DeviationID = PN.DeviationID
		AND D.PlantID = @PlantID
	INNER JOIN T_TRN_ValueStreamTemplate VST WITH (NOLOCK) ON VST.ValueStreamTemplateID = VS.ValueStreamTemplateID
		AND VST.PlantID = @PlantID
	INNER JOIN T_TRN_ValueStreamCategory VSC WITH (NOLOCK) ON VSC.ValueStreamCategoryID = VS.ValueStreamCategoryID
	WHERE PN.DataPoolID = @DataPoolID
		AND PN.PlantID = @PlantID
		AND TU.UserName IS NOT NULL
END
GO


