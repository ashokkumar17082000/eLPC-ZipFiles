/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_AuditQuestionsByAuditIDSelectedValuestream] 
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING AUDIT QUESTIONS BY AUDIT ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_005				15-MAR-2023			Snehitha Kannaboyina		Initial Version(for loading questions based on selected VS)
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_AuditQuestionsByAuditIDSelectedValuestream] 1,1346,'znn1kor',15847
*/
CREATE PROCEDURE [USP_AuditQuestionsByAuditIDSelectedValuestream] @PlantID INT
	,@AuditID INT
	,@CurrentUserNTID NVARCHAR(20)
	,@valueStreamID INT
AS
BEGIN
	SET NOCOUNT ON;

	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = @AuditID
		,@Mode = 'AUDIT'
		,@CurrentUserNTID = @CurrentUserNTID

	DECLARE @TagID INT = 0

	SELECT TOP (1) @TagID = [TagID]
	FROM T_TRN_Audit WITH (NOLOCK)
	WHERE AuditID = @AuditID
		AND PlantID = @PlantID;

	SELECT DISTINCT QuestionID
	INTO #questionIDs
	FROM [FN_GetNestedQuestionsByTagID](@TagID, @PlantID)

	SELECT @AuditID AS AuditID
		,Q.QuestionID
		,Q.QuestionDisplayID
		,Q.AnswerType_AnswerTypeID AS AnswerTypeID
		,NULL AS Answer
		,NULL AS IsAnswered
		,Q.IsAnswerRequired
		,NULL AS CreatedAt
		,NULL AS CreatedBy_NTID
		,NULL AS ModifiedAt
		,NULL AS ModifiedBy_NTID
		,Q.QuestionText
		,Q.QuestionHintText
		,Q.IsAnswerRequired
		,Q.IsDefaultAnswerRequired
		,Q.DefaultChoiceID
		,'' AS TagNameList
		,'' AS TagIDList
		,RQ.RandomQuestionOrder
		,ROW_NUMBER() OVER (
			ORDER BY AQ.QuestionID
			) AS ID
	FROM #questionIDs AQ WITH (NOLOCK)
	INNER JOIN T_TRN_Question Q WITH (NOLOCK) ON AQ.QuestionID = Q.QuestionID
	INNER JOIN T_TRN_Audit A WITH (NOLOCK) ON A.AuditID = @AuditID
	LEFT JOIN T_LNK_Tag_AssignedQuestionsTags RQ WITH (NOLOCK) ON RQ.QuestionID = AQ.QuestionID
		AND RQ.TagID = @tagid
		AND RQ.IsDeleted = 0
	WHERE A.PlantID = @PlantID
		AND Q.PlantID = @PlantID
		AND Q.IsDeleted = 0
		AND Q.QuestionID IN (
			(
				SELECT q.QuestionID
				FROM #questionIDs q
				INNER JOIN (
					SELECT DISTINCT (QuestionID)
					FROM T_LNK_AssignedValueStreams WITH (NOLOCK)
					WHERE IsDeleted = 0
						AND ValueStreamID = @valueStreamID
					) AS vs ON vs.QuestionID = q.QuestionID
				)
			)
	ORDER BY CASE 
			WHEN RQ.RandomQuestionOrder IS NULL
				THEN 998
			END
		,RQ.RandomQuestionOrder
		,Question_PriorityID
		,TargetFrequencyTypeID
		,ChoiceDisplayTypeID DESC
		,QuestionID

	UPDATE T_TRN_Audit
	SET ValueStreamID = @valueStreamID
	WHERE AuditID = @AuditID
END
GO