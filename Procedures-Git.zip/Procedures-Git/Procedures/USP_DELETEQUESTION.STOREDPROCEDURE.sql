/****** Object:  StoredProcedure [dbo].[USP_DeleteQuestion]    Script Date: 11/14/2023 9:13:50 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_DeleteQuestion]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR DELETING QUESTION
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			VENKATESH GOVINDARAJ		PlantID & Code Cleanup
ELPC_LH_003					15-NOV-2023			SHUBHAM BARANGE		        Soft Delete Question Linkage
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_DeleteQuestion] 1,'OSP4KOR','2020-11-15 14:18:21.720', 1
*/
CREATE PROCEDURE [USP_DeleteQuestion] @QuestionID INT
	, @CurrentUserNTID NVARCHAR(20)
	, @ModifiedAt DATETIME
	, @PlantID INT
AS
BEGIN
	SET @ModifiedAt = (
			SELECT FormattedDateTime
			FROM fnGetDateTime(@PlantID)
			)

	-- Start - Soft Delete Question
	UPDATE T_TRN_Question
	SET IsDeleted = 1
		, ModifiedBy_NTID = @CurrentUserNTID
		, ModifiedAt = @ModifiedAt
	WHERE QuestionID = @QuestionID
		AND PlantID = @PlantID

	UPDATE [T_LNK_AssignedAssessorsHistory]
	SET IsDeleted = 1
		, ActionType = 'U'
		, ActionDate = @ModifiedAt
	WHERE QuestionID = @QuestionID

	UPDATE [T_LNK_AssignedAssessors]
	SET IsDeleted = 1
	WHERE QuestionID = @QuestionID

	UPDATE [T_LNK_AssignedValueStreamsHistory]
	SET IsDeleted = 1
		, ActionType = 'U'
		, ActionDate = @ModifiedAt
	WHERE QuestionID = @QuestionID

	UPDATE [T_TRN_HintImageHistory]
	SET IsDeleted = 1
		, ModifiedBy_NTID = @CurrentUserNTID
		, ActionType = 'U'
		, ActionDate = @ModifiedAt
	WHERE QuestionID = @QuestionID

	UPDATE [T_TRN_HintImage]
	SET IsDeleted = 1
		, ModifiedBy_NTID = @CurrentUserNTID
	WHERE QuestionID = @QuestionID

	UPDATE [T_TRN_HintHyperLinkHistory]
	SET IsDeleted = 1
		, ActionType = 'U'
		, ActionDate = @ModifiedAt
	WHERE QuestionID = @QuestionID

	UPDATE [T_TRN_HintHyperLink]
	SET IsDeleted = 1
	WHERE QuestionID = @QuestionID

	UPDATE [T_TRN_ChoiceHistory]
	SET IsDeleted = 1
		, ActionType = 'U'
		, ActionDate = @ModifiedAt
	WHERE QuestionID = @QuestionID

	UPDATE [T_TRN_Choice]
	SET IsDeleted = 1
	WHERE QuestionID = @QuestionID

	UPDATE [T_TRN_MultipleLinesTextHistory]
	SET IsDeleted = 1
		, ActionType = 'U'
		, ActionDate = @ModifiedAt
	WHERE QuestionID = @QuestionID

	UPDATE [T_TRN_MultipleLinesText]
	SET IsDeleted = 1
	WHERE QuestionID = @QuestionID

	UPDATE [T_TRN_SingleLineTextHistory]
	SET IsDeleted = 1
		, ActionType = 'U'
		, ActionDate = @ModifiedAt
	WHERE QuestionID = @QuestionID

	UPDATE [T_TRN_SingleLineText]
	SET IsDeleted = 1
	WHERE QuestionID = @QuestionID

	UPDATE [T_LNK_Question_Proxy]
	SET IsDeleted = 1
		, ModifiedBy_NTID = @CurrentUserNTID
		, ModifiedAt = @ModifiedAt
	WHERE QuestionID = @QuestionID

	UPDATE [T_TRN_QuestionHistory]
	SET IsDeleted = 1
		, ModifiedBy_NTID = @CurrentUserNTID
		, ModifiedAt = @ModifiedAt
	WHERE QuestionID = @QuestionID
		AND PlantID = @PlantID

	UPDATE T_LNK_QN_AssignedTags
	SET IsDeleted = 1
	WHERE QuestionID = @QuestionID
		-- END - Soft Delete Question
END
