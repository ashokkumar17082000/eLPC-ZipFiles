/****** Object:  StoredProcedure [dbo].[USP_Insertprocessconfirmation_TagMode_NormalAnswer]    Script Date: 4/11/2024 12:06:58 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [USP_Insertprocessconfirmation_TagMode_NormalAnswer]
    @ModeTypeID INT,
    @ValueStreamID INT,
    @AssessorID INT,
    @QuestionID INT,
    @Answer NVARCHAR(MAX),
    @AnswerType_AnswerTypeID INT,
	@CreatedAt DATETIME,
	@ModifiedAt DATETIME,
    @TagId INT,
    @AnsweredBy_NTID NVARCHAR(20),
    @IsDeviation BIT,
    @ObtainedSCore DECIMAL(10, 2),
    @DeviationDescription NVARCHAR(MAX),
    @ResponsibleEmployee NVARCHAR(50),
    @HintImages XML = NULL,
    @ChoiceID INT,
    @IsSHowVsAs BIT,
    @SessionID NVARCHAR(20) = NULL,
    @PlantID INT,
    @AdditionalEmployee XML = NULL,
    @TagName XML = NULL,
    @IsDeleted BIT = NULL,
    @CurrentUserNTID NVARCHAR(20) = NULL,
    @TagmodeID INT,
    @CustomModeID INT
AS
BEGIN
    SET NOCOUNT ON;

	DECLARE @DeviationID INT;
    DECLARE @TimeStamp DATETIME;

    BEGIN TRY
        BEGIN TRANSACTION TRNINSERTPC;
INSERT  into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('START_PC',@PlantID,@CurrentUserNTID, getdate(),@ModeTypeID)

        -- Retrieve formatted date and time using the function fnGetDateTime
        SELECT @TimeStamp = FormattedDateTime
        FROM fnGetDateTime(@PlantID);

		 -- Set CreatedAt and ModifiedAt to the same value as Timestamp
        SET @CreatedAt = @Timestamp;
        SET @ModifiedAt = @Timestamp;

		IF @ModeTypeID = 2
        BEGIN
            INSERT INTO T_LNK_Custom_AnsweredQuestions (
             TagID,QuestionID,CreatedAt,ModifiedAt
			,IsDeleted,AnswerTypeID	,IsAnswered	,Answer
			,CreatedBy_NTID	,ModifiedBy_NTID,IsCustomModeCompleted
			,ValueStreamID,CustomModeID	,PlantID,ChoiceID,DeviationDescription
            )
            VALUES (
              	@TagId,@QuestionID,@CreatedAt
			,@ModifiedAt,0,@AnswerType_AnswerTypeID
			,1,@Answer,@AnsweredBy_NTID	,@AnsweredBy_NTID
			,0	,@ValueStreamID,@CustomModeID
			,@PlantID	,@ChoiceID	,@DeviationDescription
			--@DeviationID	
            );
        END

		IF @ModeTypeID = 3
		BEGIN
        -- Insert into T_LNK_Tag_AnsweredQuestions
        INSERT INTO T_LNK_Tag_AnsweredQuestions (
            TagID, QuestionID, CreatedAt, ModifiedAt,
            IsDeleted, AnswerTypeID, IsAnswered, Answer,
            CreatedBy_NTID, ModifiedBy_NTID, IsTagCompleted,
            IsTagActive, ValueStreamID, TagModeID, PlantID,
            DeviationDescription, ChoiceID
        )
        VALUES (
            @TagId, @QuestionID, @CreatedAt, @ModifiedAt,
            0, @AnswerType_AnswerTypeID, 1, @Answer,
            @AnsweredBy_NTID, @AnsweredBy_NTID, 0,
            1, @ValueStreamID, @TagmodeID, @PlantID,
            @DeviationDescription, @ChoiceID
        );
		END

        -- Insert into T_TRN_DataPool
        INSERT INTO T_TRN_DataPool (
            TIMESTAMP, ValueStreamID, AssessorID, QuestionID,
            Answer, AnswerType_AnswerTypeID, AnsweredBy_NTID,
            CreatedAt, ModifiedBy_NTID, ModifiedAt, TagId,
            IsDeviation, ObtainedSCore, ChoiceID, DeviationID,
            IsSHowVsAs, SessionID, PlantID
        )
        VALUES (
            @TimeStamp, @ValueStreamID, @AssessorID, @QuestionID,
            @Answer, @AnswerType_AnswerTypeID, @AnsweredBy_NTID,
            @CreatedAt, @AnsweredBy_NTID, @ModifiedAt, @TagId,
            @IsDeviation, @ObtainedSCore, @ChoiceID, NULL,
            @IsSHowVsAs, @SessionID, @PlantID
        );
		SET @DeviationID = 1;
		INSERT  into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('END_PC',@PlantID,@CurrentUserNTID, getdate(),@ModeTypeID)

        COMMIT TRANSACTION TRNINSERTPC;
		
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION TRNINSERTPC;

        EXEC [USP_LogError] @PlantID, @CurrentUserNTID;
		SET @DeviationID = 0;
    END CATCH;

	SELECT @DeviationID AS DeviationID;

END;
GO