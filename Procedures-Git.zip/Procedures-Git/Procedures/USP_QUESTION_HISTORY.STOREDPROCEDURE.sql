/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_QUESTION_HISTORY]
///AUTHOR                       : RAJASEKAR S
///CREATED DATE                 : 12-MAR-2021
///SEE ALSO                     : THIS PROCEDURE TO ADD VALUE QUESTION HISTORY DETAILS 
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_002					10-MAR-2021			RAJASEKAR S					INITIAL VERSION
ELPC_LH_002					27-MAR-2021			RAJASEKAR S					PlantID,CurrentUserNTID,DisplayID columns added
ELPC_LH_003					26-JUL-2021			MONASH CHHETRI				AnswerCategory columns added
************************************************************************************************************ 
///</SUMMARY>

EXEC [USP_QUESTION_HISTORY] 
*/
CREATE PROCEDURE [USP_QUESTION_HISTORY] @PlantID INT
	,@CurrentUserNTID NVARCHAR(20) NULL
	,@TableName VARCHAR(100)
	,@QuestionHistoryID INT OUTPUT
	,@ActionType VARCHAR(10)
	,@INPUT_IDS VARCHAR(MAX)
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION TRNQUESTIONHISTORY

		IF (@TableName = 'Question')
		BEGIN
			INSERT INTO [T_TRN_QuestionHistory] (
				[QuestionID]
				,[QuestionText]
				,[QuestionHintText]
				,[AnswerType_AnswerTypeID]
				,[ChoiceDisplayTypeID]
				,[IsFilledInChoiceAllowed]
				,[IsUniqueAnswerRequired]
				,[IsAnswerRequired]
				,[DefaultChoiceID]
				,[IsQuestionAlwaysActive]
				,[ActiveDateRangeFrom]
				,[ActiveDateRangeTo]
				,[IsTargetFrequencyDefined]
				,[TargetFrequencyTypeID]
				,[TargetFrequencyValue]
				,[Question_PriorityID]
				,[IsLocked]
				-- ,[Assigned_ValueStreamTemplateID]
				-- ,[Assigned_ValueStreamCategoryID]
				-- ,[Assigned_AssessorTemplateID]
				,[IsDeleted]
				,[CreatedAt]
				,[ModifiedAt]
				,[IsDefaultAnswerRequired]
				,[Assigned_AssessorID]
				,[IsAnswered]
				,[ActionType]
				,[ActionAt]
				,CreatedBy_NTID
				,ModifiedBy_NTID
				,DefaultChoice
				,PlantID
				,QuestionHistoryDisplayID
				,QuestionDisplayID
				)
			SELECT [QuestionID]
				,[QuestionText]
				,[QuestionHintText]
				,[AnswerType_AnswerTypeID]
				,[ChoiceDisplayTypeID]
				,[IsFilledInChoiceAllowed]
				,[IsUniqueAnswerRequired]
				,[IsAnswerRequired]
				,[DefaultChoiceID]
				,[IsQuestionAlwaysActive]
				,[ActiveDateRangeFrom]
				,[ActiveDateRangeTo]
				,[IsTargetFrequencyDefined]
				,[TargetFrequencyTypeID]
				,[TargetFrequencyValue]
				,[Question_PriorityID]
				,[IsLocked]
				-- ,[Assigned_ValueStreamTemplateID]
				-- ,[Assigned_ValueStreamCategoryID]
				-- ,[Assigned_AssessorTemplateID]
				,[IsDeleted]
				,[CreatedAt]
				,[ModifiedAt]
				,[IsDefaultAnswerRequired]
				,[Assigned_AssessorID]
				,[IsAnswered]
				,@ActionType
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
				,CreatedBy_NTID
				,ModifiedBy_NTID
				,DefaultChoice
				,PlantID
				,(
					SELECT DisplayID
					FROM [FN_GetNextHistoryDisplayID](@PlantID, 'T_TRN_QuestionHistory', QuestionID)
					)
				,QuestionDisplayID
			FROM [T_TRN_Question] WITH (NOLOCK)
			WHERE [QuestionID] = @INPUT_IDS
				AND PlantID = @PlantID;--Always single value

			SET @QuestionHistoryID = SCOPE_IDENTITY()
		END
		ELSE IF (@TableName = 'HintImage')
		BEGIN
			INSERT INTO [T_TRN_HintImageHistory] (
				[QuestionHistoryID]
				,[ID]
				,[QuestionID]
				,[ImageTitle]
				,[ImagePath]
				,[IsDeleted]
				,[ActionType]
				,[ActionDate]
				,DisplayFileName
				,CreatedBy_NTID
				,ModifiedBy_NTID
				)
			SELECT @QuestionHistoryID
				,[ID]
				,[QuestionID]
				,[ImageTitle]
				,[ImagePath]
				,[IsDeleted]
				,@ActionType
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
				,DisplayFileName
				,CreatedBy_NTID
				,ModifiedBy_NTID
			FROM [T_TRN_HintImage] WITH (NOLOCK)
			WHERE ID IN (
					SELECT *
					FROM fnSplit(@INPUT_IDS)
					)
		END
		ELSE IF (@TableName = 'HintHyperLink')
		BEGIN
			INSERT INTO [T_TRN_HintHyperLinkHistory] (
				[QuestionHistoryID]
				,[ID]
				,[QuestionID]
				,[HyperLinkTitle]
				,[HyperLinkURL]
				,[IsDeleted]
				,[ActionType]
				,[ActionDate]
				)
			SELECT @QuestionHistoryID
				,[ID]
				,[QuestionID]
				,[HyperLinkTitle]
				,[HyperLinkURL]
				,[IsDeleted]
				,@ActionType
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
			FROM [T_TRN_HintHyperLink] WITH (NOLOCK)
			WHERE ID IN (
					SELECT *
					FROM fnSplit(@INPUT_IDS)
					)
		END
		ELSE IF (@TableName = 'AssignedValueStreams')
		BEGIN
			INSERT INTO [T_LNK_AssignedValueStreamsHistory] (
				[QuestionHistoryID]
				,[ID]
				,[ValueStreamID]
				,[QuestionID]
				,[IsDeleted]
				,[ActionType]
				,[ActionDate]
				)
			SELECT @QuestionHistoryID
				,[ID]
				,[ValueStreamID]
				,[QuestionID]
				,[IsDeleted]
				,@ActionType
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
			FROM [T_LNK_AssignedValueStreams] WITH (NOLOCK)
			WHERE ID IN (
					SELECT *
					FROM fnSplit(@INPUT_IDS)
					)
		END
		ELSE IF (@TableName = 'AssignedAssessors')
		BEGIN
			INSERT INTO [T_LNK_AssignedAssessorsHistory] (
				[QuestionHistoryID]
				,[ID]
				,[AssessorID]
				,[QuestionID]
				,[TargetFrequencyValue]
				,[TargetFrequencyTypeID]
				,[IsDeleted]
				,[ActionType]
				,[ActionDate]
				)
			SELECT @QuestionHistoryID
				,[ID]
				,[AssessorID]
				,[QuestionID]
				,[TargetFrequencyValue]
				,[TargetFrequencyTypeID]
				,[IsDeleted]
				,@ActionType
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
			FROM [T_LNK_AssignedAssessors] WITH (NOLOCK)
			WHERE ID IN (
					SELECT *
					FROM fnSplit(@INPUT_IDS)
					)
		END
		ELSE IF (@TableName = 'AssignedTags')
		BEGIN
			INSERT INTO [T_LNK_QN_AssignedTagsHistory] (
				[QuestionHistoryID]
				,[ID]
				,[TagID]
				,[QuestionID]
				,[IsDeleted]
				,[ActionType]
				,[ActionDate]
				)
			SELECT @QuestionHistoryID
				,[ID]
				,[TagID]
				,[QuestionID]
				,[IsDeleted]
				,@ActionType
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
			FROM [T_LNK_QN_AssignedTags] WITH (NOLOCK)
			WHERE ID IN (
					SELECT *
					FROM fnSplit(@INPUT_IDS)
					)
		END
		ELSE IF (@TableName = 'SingleLineText')
		BEGIN
			INSERT INTO [T_TRN_SingleLineTextHistory] (
				[QuestionHistoryID]
				,[ID]
				,[MaxCharacters]
				,[IsCalculated]
				,[DefaultValue]
				,[QuestionID]
				,[IsDeleted]
				,[ActionType]
				,[ActionDate]
				)
			SELECT @QuestionHistoryID
				,[ID]
				,[MaxCharacters]
				,[IsCalculated]
				,[DefaultValue]
				,[QuestionID]
				,[IsDeleted]
				,@ActionType
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
			FROM [T_TRN_SingleLineText] WITH (NOLOCK)
			WHERE ID IN (
					SELECT *
					FROM fnSplit(@INPUT_IDS)
					)
		END
		ELSE IF (@TableName = 'MultipleLinesText')
		BEGIN
			INSERT INTO [T_TRN_MultipleLinesTextHistory] (
				[QuestionHistoryID]
				,[ID]
				,[MaxLines]
				,[IsPlaintText]
				,[QuestionID]
				,[IsDeleted]
				,[ActionType]
				,[ActionDate]
				)
			SELECT @QuestionHistoryID
				,[ID]
				,[MaxLines]
				,[IsPlaintText]
				,[QuestionID]
				,[IsDeleted]
				,@ActionType
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
			FROM [T_TRN_MultipleLinesText] WITH (NOLOCK)
			WHERE ID IN (
					SELECT *
					FROM fnSplit(@INPUT_IDS)
					)
		END
		ELSE IF (@TableName = 'Choice')
		BEGIN
			INSERT INTO [T_TRN_ChoiceHistory] (
				[QuestionHistoryID]
				,[ChoiceID]
				,[QuestionID]
				,[ChoiceName]
				,[ChoiceScore]
				,[IsDeviationEntryRequired]
				,[IsDeleted]
				,[ActionType]
				,[ActionDate]
				,[DeviationTypeID]
				,[AnswerCategory]
				)
			SELECT @QuestionHistoryID
				,[ChoiceID]
				,[QuestionID]
				,[ChoiceName]
				,[ChoiceScore]
				,[IsDeviationEntryRequired]
				,[IsDeleted]
				,@ActionType
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
				,[DeviationTypeID]
				,[AnswerCategory]
			FROM [T_TRN_Choice] WITH (NOLOCK)
			WHERE ChoiceID IN (
					SELECT *
					FROM fnSplit(@INPUT_IDS)
					)
		END
		ELSE IF (@TableName = 'RatingScale')
		BEGIN
			INSERT INTO [T_TRN_RatingScaleHistory] (
				[QuestionHistoryID]
				,[ID]
				,[NumberRange]
				,[RangeText1]
				,[RangeText2]
				,[RangeText3]
				,[ShowNA]
				,[TextNA]
				,[QuestionID]
				,[IsDeleted]
				,[ActionType]
				,[ActionDate]
				)
			SELECT @QuestionHistoryID
				,[ID]
				,[NumberRange]
				,[RangeText1]
				,[RangeText2]
				,[RangeText3]
				,[ShowNA]
				,[TextNA]
				,[QuestionID]
				,[IsDeleted]
				,@ActionType
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
			FROM [T_TRN_RatingScale] WITH (NOLOCK)
			WHERE ID IN (
					SELECT *
					FROM fnSplit(@INPUT_IDS)
					)
		END
		ELSE IF (@TableName = 'SubQuestion')
		BEGIN
			INSERT INTO [T_TRN_SubQuestionHistory] (
				[QuestionHistoryID]
				,[ID]
				,[Name]
				,[QuestionID]
				,[IsDeleted]
				,[ActionType]
				,[ActionDate]
				)
			SELECT @QuestionHistoryID
				,[ID]
				,[Name]
				,[QuestionID]
				,[IsDeleted]
				,@ActionType
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
			FROM [T_TRN_SubQuestion] WITH (NOLOCK)
			WHERE ID IN (
					SELECT *
					FROM fnSplit(@INPUT_IDS)
					)
		END

		COMMIT TRANSACTION TRNQUESTIONHISTORY;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNQUESTIONHISTORY;

		EXEC [USP_LogError] @PlantID
			,@CurrentUserNTID;
	END CATCH
END
GO

