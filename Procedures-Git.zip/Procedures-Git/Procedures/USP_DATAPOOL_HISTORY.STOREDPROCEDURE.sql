/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_DATAPOOL_HISTORY]
///AUTHOR                       : RAJASEKAR S
///CREATED DATE                 : 27-MAR-2021
///SEE ALSO                     : THIS PROCEDURE TO ADD DATAPOOL HISTORY DETAILS 
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_002					27-MAR-2021			RAJASEKAR S					INITIAL VERSION
************************************************************************************************************ 
///</SUMMARY>

EXEC [USP_DATAPOOL_HISTORY] 1,'RSB4COB', 'DATAPOOL', 'I','1,2'
*/
CREATE PROCEDURE [USP_DATAPOOL_HISTORY] @PlantID INT
	,@CurrentUserNTID NVARCHAR(20) NULL
	,@TableName VARCHAR(100)
	,@ActionType VARCHAR(10)
	,@INPUT_IDS VARCHAR(MAX)
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION TRNDATAPOOLHISTORY
		IF (@TableName = 'DATAPOOL')
		BEGIN
			INSERT INTO [T_TRN_DataPoolHistory] (
				[DataPoolID]
				,[TimeStamp]
				,[ValueStreamID]
				,[AssessorID]
				,[QuestionID]
				,[Answer]
				,[answerType_AnswerTypeID]
				,[CreatedAt]
				,[AnsweredBy_NTID]
				,[ModifiedAt]
				,[ModifiedBy_NTID]
				,[TagID]
				,[IsDeviation]
				,[IsAnswered]
				,[ObtainedScore]
				,[ChoiceID]
				,[DeviationID]
				,[AuditID]
				,[AuditTemplateID]
				,[IsShowVsAs]
				,[IsDeleted]
				,[ActionType]
				,[ActionDate]
				,[SessionID]
				,PlantID
				,DataPoolHistoryDisplayID
				,DataPoolDisplayID
				)
			SELECT [DataPoolID]
				,[TimeStamp]
				,[ValueStreamID]
				,[AssessorID]
				,[QuestionID]
				,[Answer]
				,[answerType_AnswerTypeID]
				,[CreatedAt]
				,[AnsweredBy_NTID]
				,[ModifiedAt]
				,[ModifiedBy_NTID]
				,[TagID]
				,[IsDeviation]
				,[IsAnswered]
				,[ObtainedScore]
				,[ChoiceID]
				,[DeviationID]
				,[AuditID]
				,[AuditTemplateID]
				,[IsShowVsAs]
				,[IsDeleted]
				,@ActionType
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
				,[SessionID]
				,PlantID
				,(
					SELECT DisplayID
					FROM [FN_GetNextHistoryDisplayID](@PlantID, 'T_TRN_DataPoolHistory', DataPoolID)
					)
				,DataPoolDisplayID
			FROM T_TRN_DataPool WITH (NOLOCK)
			WHERE DataPoolID IN (
					SELECT *
					FROM fnSplit(@INPUT_IDS)
					)
				AND PlantID = @PlantID;
		END
		COMMIT TRANSACTION TRNDATAPOOLHISTORY;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNDATAPOOLHISTORY;

		EXEC [USP_LogError] @PlantID
			,@CurrentUserNTID;
	END CATCH
END
GO


