/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_ASSESSOR_HISTORY]
///AUTHOR                       : RAJASEKAR S
///CREATED DATE                 : 16-MAR-2021
///SEE ALSO                     : THIS PROCEDURE TO ADD ASSESSOR DETAILS 
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_002					17-MAR-2021			RAJASEKAR S					INITIAL VERSION
************************************************************************************************************ 
///</SUMMARY>

EXEC [USP_ASSESSOR_HISTORY] 'TAG',1,'I','1'
*/
CREATE PROCEDURE [USP_ASSESSOR_HISTORY] @PlantID INT
	,@CurrentUserNTID NVARCHAR(20) NULL
	,@TableName VARCHAR(100)
	,@AssessorTemplateHistoryID INT OUTPUT
	,@ActionType VARCHAR(10)
	,@INPUT_IDS VARCHAR(MAX)
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION TRNASSHISTORY
		IF (@TableName = 'AssessorTemplate')
		BEGIN
			INSERT INTO [T_TRN_AssessorTemplateHistory] (
				[AssessorTemplateID]
				,PlantID
				,AssessorTemplateDisplayID
				,AssessorTemplateHistoryDisplayID
				,[AssessorTemplateName]
				,[IsLocked]
				,[ModifiedAt]
				,[CreatedAt]
				,[IsTargetFrequencyDefined]
				,[IsDeleted]
				,[ActionType]
				,[ActionDate]
				,CreatedBy_NTID
				,ModifiedBy_NTID
				)
			SELECT [AssessorTemplateID]
				,PlantID
				,AssessorTemplateDisplayID
				,(
					SELECT DisplayID
					FROM [FN_GetNextHistoryDisplayID](@PlantID, 'T_TRN_AssessorTemplateHistory', AssessorTemplateID)
					)
				,[AssessorTemplateName]
				,[IsLocked]
				,[ModifiedAt]
				,[CreatedAt]
				,[IsTargetFrequencyDefined]
				,[IsDeleted]
				,@ActionType
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
				,CreatedBy_NTID
				,ModifiedBy_NTID
			FROM [T_TRN_AssessorTemplate] WITH(NOLOCK)
			WHERE AssessorTemplateID = @INPUT_IDS
				AND PlantID = @PlantID;--Always single value

			SET @AssessorTemplateHistoryID = SCOPE_IDENTITY();
		END
		ELSE IF (@TableName = 'Assessor')
		BEGIN
			INSERT INTO [T_TRN_AssessorHistory] (
				[AssessorTemplateHistoryID]
				,[AssessorID]
				,[AssessorName]
				,[TargetFrequencyValue]
				,[AssessorTemplateID]
				,[TargetFrequencyTypeID]
				,[ActionType]
				,[ActionDate]
				,[IsDeleted]
				,[ModifiedAt]
				,[CreatedAt]
				,[Category]
				,[TargetFrequencyLowLimit]
				)
			SELECT @AssessorTemplateHistoryID
				,[AssessorID]
				,[AssessorName]
				,[TargetFrequencyValue]
				,[AssessorTemplateID]
				,[TargetFrequencyTypeID]
				,@ActionType
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
				,[IsDeleted]
				,[ModifiedAt]
				,[CreatedAt]
				,[Category]
				,[TargetFrequencyLowLimit]
			FROM [T_TRN_Assessor] WITH(NOLOCK)
			WHERE AssessorID IN (
					SELECT *
					FROM fnSplit(@INPUT_IDS)
					)
		END
		ELSE IF (@TableName = 'Assessor_Proxy')
		BEGIN
			INSERT INTO [T_LNK_Assessor_ProxyHistory] (
				[ID]
				,[AssessorTemplateID]
				,[Proxy]
				,[IsDeleted]
				,[CreatedAt]
				,[ModifiedAt]
				,[CreatedBy_NTID]
				,[ModifiedBy_NTID]
				,[ActionType]
				,[ActionDate]
				)
			SELECT ID
				,AssessorTemplateID
				,Proxy
				,IsDeleted
				,CreatedAt
				,ModifiedAt
				,CreatedBy_NTID
				,ModifiedBy_NTID
				,@ActionType
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
			FROM [T_LNK_Assessor_Proxy] WITH(NOLOCK)
			WHERE ID IN (
					SELECT *
					FROM fnSplit(@INPUT_IDS)
					)
		END
		COMMIT TRANSACTION TRNASSHISTORY;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNASSHISTORY;
		EXEC [USP_LogError] @PlantID
			,@CurrentUserNTID;
	END CATCH
END
GO


