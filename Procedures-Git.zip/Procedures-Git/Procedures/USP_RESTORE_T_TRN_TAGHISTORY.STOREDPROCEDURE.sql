/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_Restore_T_TRN_TagHistory]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RESTORING TAG HISTORY
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					24-MAR-2021			KARTHIKEYAN K				PLANTID ADDED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_Restore_T_TRN_TagHistory] 1, 1, 1
*/
CREATE PROCEDURE [USP_Restore_T_TRN_TagHistory] (
	@PlantID INT
	,@TagHistoryID INT
	,@CurrentUserNTID NVARCHAR(20)
	)
AS
BEGIN
	SET NOCOUNT ON;
	SET LOCK_TIMEOUT 10000;

	BEGIN TRANSACTION TRNRESTORETAGHISTORY;

	--to avoid entries from restore it is disabled 
	--ALTER TABLE [T_TRN_Tag] DISABLE TRIGGER [TR_HISTORYFOR_T_TRN_Tag]
	--ALTER TABLE [T_LNK_Tag_AssignedQuestionsTags] DISABLE TRIGGER [TR_HISTORYFOR_T_LNK_Tag_AssignedQuestionsTags]
	--ALTER TABLE [T_LNK_Tag_AssignedValueStreams] DISABLE TRIGGER [TR_HISTORYFOR_T_LNK_Tag_AssignedValueStreams]
	--ALTER TABLE [T_LNK_Tag_AssignedAssessors] DISABLE TRIGGER [TR_HISTORYFOR_T_LNK_Tag_AssignedAssessors]
	BEGIN TRY
		IF EXISTS (
				SELECT 1
				FROM T_TRN_TagHistory WITH (NOLOCK)
				WHERE TagHistoryID = @TagHistoryID
					AND PlantID = @PlantID
				)
		BEGIN
			-- Update [T_TRN_Tag]
			DECLARE @TagID INT;
			DECLARE @TagDisplayID INT;
			DECLARE @TagName NVARCHAR(MAX);
			DECLARE @IsSingleQuestionSuppressed BIT;
			DECLARE @SuppressedDateRangeFrom DATETIME;
			DECLARE @SuppressedDateRangeTo DATETIME;
			DECLARE @IsTargetFrequencyDefined BIT;
			DECLARE @TargetFrequencyTypeID INT;
			DECLARE @TargetFrequencyValue NVARCHAR(50);
			DECLARE @Tag_PriorityID INT;
			DECLARE @TagTypeID INT;
			DECLARE @IsLocked BIT;
			DECLARE @AnonymizeUserDataSettingID INT;
			DECLARE @IsBranchLogicToBeFollowed BIT;
			DECLARE @IsMandatoryAssessorsDefined BIT;
			DECLARE @IsDeleted BIT;
			DECLARE @CreatedAt DATETIME;
			DECLARE @ModifiedAt DATETIME = (
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					);
			DECLARE @CreatedBy_NTID NVARCHAR(20);
			DECLARE @ModifiedBy_NTID NVARCHAR(20) = @CurrentUserNTID;

			-- DECLARE @Assigned_ValueStreamTemplateID INT;
			-- DECLARE @Assigned_ValueStreamCategoryID INT;
			-- DECLARE @Assigned_AssessorTemplateID INT;
			SELECT TOP 1 @TagID = TagID
				,@TagName = TagName
				,@TagDisplayID = TagDisplayID
				,@IsSingleQuestionSuppressed = IsSingleQuestionSuppressed
				,@SuppressedDateRangeFrom = SuppressedDateRangeFrom
				,@SuppressedDateRangeTo = SuppressedDateRangeTo
				,@IsTargetFrequencyDefined = IsTargetFrequencyDefined
				,@TargetFrequencyTypeID = TargetFrequencyTypeID
				,@TargetFrequencyValue = TargetFrequencyValue
				,@Tag_PriorityID = Tag_PriorityID
				,@TagTypeID = TagTypeID
				,@IsLocked = IsLocked
				,@AnonymizeUserDataSettingID = AnonymizeUserDataSettingID
				,@IsBranchLogicToBeFollowed = IsBranchLogicToBeFollowed
				,@IsMandatoryAssessorsDefined = IsMandatoryAssessorsDefined
				,@IsDeleted = IsDeleted
				,@CreatedAt = CreatedAt
				,@CreatedBy_NTID = CreatedBy_NTID
			-- ,@Assigned_ValueStreamTemplateID = Assigned_ValueStreamTemplateID
			-- ,@Assigned_ValueStreamCategoryID = Assigned_ValueStreamCategoryID
			-- ,@Assigned_AssessorTemplateID = Assigned_AssessorTemplateID
			FROM T_TRN_TagHistory WITH (NOLOCK)
			WHERE @TagHistoryID = TagHistoryID
				AND PlantID = @PlantID;

			UPDATE [T_TRN_Tag]
			SET TagName = @TagName
				,TagDisplayID = @TagDisplayID
				,IsSingleQuestionSuppressed = @IsSingleQuestionSuppressed
				,SuppressedDateRangeFrom = @SuppressedDateRangeFrom
				,SuppressedDateRangeTo = @SuppressedDateRangeTo
				,IsTargetFrequencyDefined = @IsTargetFrequencyDefined
				,TargetFrequencyTypeID = @TargetFrequencyTypeID
				,TargetFrequencyValue = @TargetFrequencyValue
				,Tag_PriorityID = @Tag_PriorityID
				,TagTypeID = @TagTypeID
				,IsLocked = @IsLocked
				,AnonymizeUserDataSettingID = @AnonymizeUserDataSettingID
				,IsBranchLogicToBeFollowed = @IsBranchLogicToBeFollowed
				,IsMandatoryAssessorsDefined = @IsMandatoryAssessorsDefined
				,IsDeleted = @IsDeleted
				,CreatedAt = @CreatedAt
				,ModifiedAt = @ModifiedAt
				,CreatedBy_NTID = @CreatedBy_NTID
				,ModifiedBy_NTID = @ModifiedBy_NTID
			-- ,Assigned_ValueStreamTemplateID = @Assigned_ValueStreamTemplateID
			-- ,Assigned_ValueStreamCategoryID = @Assigned_ValueStreamCategoryID
			-- ,Assigned_AssessorTemplateID = @Assigned_AssessorTemplateID
			WHERE TagID = @TagID
				AND PlantID = @PlantID;

			--END - Update [T_TRN_Tag]
			-- Update [T_LNK_Tag_AssignedQuestionsTags]
			DECLARE @ID INT;
			DECLARE @QuestionID INT;
			DECLARE @LinkedTagID INT;

			SET @IsDeleted = 0;

			-- Remove the data if that not exists(may be not available on that time)
			UPDATE T_LNK_Tag_AssignedQuestionsTags
			SET IsDeleted = 1
			WHERE TagID = @TagID
				AND ID NOT IN (
					SELECT ID
					FROM [T_LNK_Tag_AssignedQuestionsTagsHistory] WITH (NOLOCK)
					WHERE (
							IsDeleted IS NULL
							OR IsDeleted = 0
							)
						AND TagHistoryID = @TagHistoryID
					);

			DECLARE CUR_AssignedQuestionsTags CURSOR FORWARD_ONLY
			FOR
			SELECT ID
				,TagID
				,QuestionID
				,LinkedTagID
				,IsDeleted
			FROM [T_LNK_Tag_AssignedQuestionsTagsHistory] WITH (NOLOCK)
			WHERE TagHistoryID = @TagHistoryID;

			OPEN CUR_AssignedQuestionsTags;

			FETCH NEXT
			FROM CUR_AssignedQuestionsTags
			INTO @ID
				,@TagID
				,@QuestionID
				,@LinkedTagID
				,@IsDeleted;

			WHILE @@FETCH_STATUS = 0
			BEGIN
				IF EXISTS (
						SELECT 1
						FROM T_LNK_Tag_AssignedQuestionsTags WITH (NOLOCK)
						WHERE ID = @ID
						)
				BEGIN
					-- Update the AssignedQuestionsTags data if that exists
					UPDATE T_LNK_Tag_AssignedQuestionsTags
					SET TagID = @TagID
						,QuestionID = @QuestionID
						,LinkedTagID = @LinkedTagID
						,IsDeleted = @IsDeleted
					WHERE ID = @ID;
				END
				ELSE
				BEGIN
					-- Insert the AssignedQuestionsTags data if that not exists(may be removed)
					INSERT INTO T_LNK_Tag_AssignedQuestionsTags (
						TagID
						,QuestionID
						,LinkedTagID
						,IsDeleted
						)
					VALUES (
						@TagID
						,@QuestionID
						,@LinkedTagID
						,@IsDeleted
						);
				END

				FETCH NEXT
				FROM CUR_AssignedQuestionsTags
				INTO @ID
					,@TagID
					,@QuestionID
					,@LinkedTagID
					,@IsDeleted;
			END

			CLOSE CUR_AssignedQuestionsTags;

			DEALLOCATE CUR_AssignedQuestionsTags;

			-- Update [T_LNK_TagAssessors]
			SET @ID = 0;

			DECLARE @AssessorID INT;

			SET @TargetFrequencyValue = '';
			SET @TargetFrequencyTypeID = 0;
			SET @IsDeleted = 0;
			-- Update [T_LNK_Tag_AssignedAssessors]
			SET @ID = 0;
			SET @AssessorID = 0;
			SET @TargetFrequencyValue = '';
			SET @TargetFrequencyTypeID = 0;
			SET @IsDeleted = 0;

			DECLARE @IsMandatoryAssessor BIT;

			-- Remove the data if that not exists(may be not available on that time)
			UPDATE T_LNK_Tag_AssignedAssessors
			SET IsDeleted = 1
			WHERE TagID = @TagID
				AND ID NOT IN (
					SELECT ID
					FROM [T_LNK_Tag_AssignedAssessorsHistory] WITH (NOLOCK)
					WHERE (
							IsDeleted IS NULL
							OR IsDeleted = 0
							)
						AND TagHistoryID = @TagHistoryID
					);

			DECLARE CUR_Tag_AssignedAssessors CURSOR FORWARD_ONLY
			FOR
			SELECT ID
				,AssessorID
				,TargetFrequencyValue
				,TargetFrequencyTypeID
				,TagID
				,IsMandatoryAssessor
				,IsDeleted
			FROM [T_LNK_Tag_AssignedAssessorsHistory] WITH (NOLOCK)
			WHERE TagHistoryID = @TagHistoryID;

			OPEN CUR_Tag_AssignedAssessors;

			FETCH NEXT
			FROM CUR_Tag_AssignedAssessors
			INTO @ID
				,@AssessorID
				,@TargetFrequencyValue
				,@TargetFrequencyTypeID
				,@TagID
				,@IsMandatoryAssessor
				,@IsDeleted;

			WHILE @@FETCH_STATUS = 0
			BEGIN
				IF EXISTS (
						SELECT 1
						FROM T_LNK_Tag_AssignedAssessors WITH (NOLOCK)
						WHERE ID = @ID
						)
				BEGIN
					-- Update the Tag_AssignedAssessors data if that exists
					UPDATE T_LNK_Tag_AssignedAssessors
					SET AssessorID = @AssessorID
						,TargetFrequencyValue = @TargetFrequencyValue
						,TargetFrequencyTypeID = @TargetFrequencyTypeID
						,TagID = @TagID
						,IsMandatoryAssessor = @IsMandatoryAssessor
						,IsDeleted = @IsDeleted
					WHERE ID = @ID;
				END
				ELSE
				BEGIN
					-- Insert the Tag_AssignedAssessors data if that not exists(may be removed)
					INSERT INTO T_LNK_Tag_AssignedAssessors (
						AssessorID
						,TargetFrequencyValue
						,TargetFrequencyTypeID
						,TagID
						,IsMandatoryAssessor
						,IsDeleted
						)
					VALUES (
						@AssessorID
						,@TargetFrequencyValue
						,@TargetFrequencyTypeID
						,@TagID
						,@IsMandatoryAssessor
						,@IsDeleted
						);
				END

				FETCH NEXT
				FROM CUR_Tag_AssignedAssessors
				INTO @ID
					,@AssessorID
					,@TargetFrequencyValue
					,@TargetFrequencyTypeID
					,@TagID
					,@IsMandatoryAssessor
					,@IsDeleted;
			END

			CLOSE CUR_Tag_AssignedAssessors;

			DEALLOCATE CUR_Tag_AssignedAssessors;

			-- Update [T_LNK_Tag_AssignedValueStreams]
			SET @ID = 0;

			DECLARE @ValueStreamID INT;

			SET @IsDeleted = 0;

			-- Remove the data if that not exists(may be not available on that time)
			UPDATE T_LNK_Tag_AssignedValueStreams
			SET IsDeleted = 1
			WHERE TagID = @TagID
				AND ID NOT IN (
					SELECT ID
					FROM [T_LNK_Tag_AssignedValueStreamsHistory] WITH (NOLOCK)
					WHERE (
							IsDeleted IS NULL
							OR IsDeleted = 0
							)
						AND TagHistoryID = @TagHistoryID
					);

			DECLARE CUR_Tag_AssignedValueStreams CURSOR FORWARD_ONLY
			FOR
			SELECT ID
				,ValueStreamID
				,TagID
				,IsDeleted
			FROM [T_LNK_Tag_AssignedValueStreamsHistory] WITH (NOLOCK)
			WHERE TagHistoryID = @TagHistoryID;

			OPEN CUR_Tag_AssignedValueStreams;

			FETCH NEXT
			FROM CUR_Tag_AssignedValueStreams
			INTO @ID
				,@ValueStreamID
				,@TagID
				,@IsDeleted;

			WHILE @@FETCH_STATUS = 0
			BEGIN
				IF EXISTS (
						SELECT 1
						FROM T_LNK_Tag_AssignedValueStreams WITH (NOLOCK)
						WHERE ID = @ID
						)
				BEGIN
					-- Update the Tag_AssignedValueStreams data if that exists
					UPDATE T_LNK_Tag_AssignedValueStreams
					SET ValueStreamID = @ValueStreamID
						,TagID = @TagID
						,IsDeleted = @IsDeleted
					WHERE ID = @ID;
				END
				ELSE
				BEGIN
					-- Insert the Tag_AssignedValueStreams data if that not exists(may be removed)
					INSERT INTO T_LNK_Tag_AssignedValueStreams (
						ValueStreamID
						,TagID
						,IsDeleted
						)
					VALUES (
						@ValueStreamID
						,@TagID
						,@IsDeleted
						);
				END

				FETCH NEXT
				FROM CUR_Tag_AssignedValueStreams
				INTO @ID
					,@ValueStreamID
					,@TagID
					,@IsDeleted;
			END

			CLOSE CUR_Tag_AssignedValueStreams;

			DEALLOCATE CUR_Tag_AssignedValueStreams;

			COMMIT TRANSACTION TRNRESTORETAGHISTORY;
		END
		ELSE
		BEGIN
			ROLLBACK TRANSACTION TRNRESTORETAGHISTORY;
		END
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNRESTORETAGHISTORY;

		EXEC USP_LogError @PlantID
			,@CurrentUserNTID;
	END CATCH
END
GO

