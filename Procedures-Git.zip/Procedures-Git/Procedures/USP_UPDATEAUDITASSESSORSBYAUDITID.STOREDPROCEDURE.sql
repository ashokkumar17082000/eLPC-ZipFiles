/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_UpdateAuditAssessorsByAuditID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR UPDATING AUDIT ASSESSORS BY AUDIT ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			Rajasekar S					PlantId,CurrentUserNTID added

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_UpdateAuditAssessorsByAuditID] 1
*/
CREATE PROCEDURE [USP_UpdateAuditAssessorsByAuditID] @PlantID INT
	,@AuditID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION TRNUPATEAUDITASSESSOR

		EXEC [USP_PlantIDValidation] @PlantID = @PlantID
			,@ID = @AuditID
			,@Mode = 'AUDIT'
			,@CurrentUserNTID = @CurrentUserNTID

		DECLARE @TagID INT;
		DECLARE @min INT;
		DECLARE @max INT;
		DECLARE @AssessorName NVARCHAR(200)
			,@NTID NVARCHAR(20)
			,@CreatedBy_NTID NVARCHAR(20)
			,@ModifiedBy_NTID NVARCHAR(20)
			,@IsMandatoryAssessor BIT

		SET @TagID = (
				SELECT TagID
				FROM T_TRN_Audit
				WHERE AuditID = @AuditID 
				AND PlantID = @PlantID
				)

		SELECT TA.AssessorID AS AssessorID
			,TA.IsMandatoryAssessor AS IsMandatoryAssessor
			,AR.AssessorName AS AssessorName
		INTO #T71
		FROM T_LNK_Tag_AssignedAssessors TA WITH(NOLOCK)
		INNER JOIN T_TRN_Assessor AR WITH(NOLOCK) ON TA.AssessorID = AR.AssessorID
		WHERE TA.TagID = @TagID
			AND TA.IsDeleted = 0

		UPDATE T_TRN_AuditAssessor
		SET IsActive = 0
		WHERE AssessorName NOT IN (
				SELECT AssessorName
				FROM #T71
				)
			AND AuditID = @AuditID -- removes the deleted assessors

		DECLARE CUR_AuditAssessorr CURSOR FORWARD_ONLY
		FOR
		SELECT AssessorName
			,IsMandatoryAssessor
		FROM #T71

		OPEN CUR_AuditAssessorr;

		FETCH NEXT
		FROM CUR_AuditAssessorr
		INTO @AssessorName
			,@IsMandatoryAssessor

		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF NOT EXISTS (
					SELECT 1
					FROM T_TRN_AuditAssessor WITH(NOLOCK)
					WHERE AssessorName = @AssessorName
						AND AuditID = @AuditID
					)
			BEGIN
				INSERT INTO T_TRN_AuditAssessor (
					AuditID
					,AssessorName
					,IsMandatoryAssessor
					)
				VALUES (
					@AuditID
					,@AssessorName
					,@IsMandatoryAssessor
					)
			END
			ELSE
			BEGIN
				UPDATE T_TRN_AuditAssessor
				SET IsMandatoryAssessor = @IsMandatoryAssessor
				WHERE AuditID = @AuditID
					AND AssessorName = @AssessorName
			END

			FETCH NEXT
			FROM CUR_AuditAssessorr
			INTO @AssessorName
				,@IsMandatoryAssessor
		END

		CLOSE CUR_AuditAssessorr;

		DEALLOCATE CUR_AuditAssessorr;

		COMMIT TRANSACTION TRNUPATEAUDITASSESSOR
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNUPATEAUDITASSESSOR

		EXEC USP_LogError @PlantID
			,@CurrentUserNTID
	END CATCH
END
GO


