SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [USP_ImportExcel_AssessorTemplate] @ImportExcel_AssessorTemplate XML NULL
	,@ImportExcel_Assessor XML NULL
AS
BEGIN
	BEGIN TRY
		DECLARE @min INT = 0
			,@max INT = 0
			,@AssessorTemplateID INT
			,@AssessorTemplateName VARCHAR(50)
			,@IsLocked BIT
			,@IsTargetFrequencyDefined BIT
			,@ModifiedAt DATETIME
			,@ModifiedBy_UserID INT
			,@CreatedAt DATETIME
			,@CreatedBy_UserID INT
			,@Temp INT
			,
			--@AssessorCategoryID int,
			--@AssessorCategoryName varchar(50) ,
			--@IsDataRequired bit,
			--@TypeOfInput_InputTypeID varchar(50),
			--@IsDataRequiredToFitSpecLength bit,
			--@MinimumNoOfCharacters int,
			--@MaximumNoOfCharacters int
			--@ValueStreamData varchar(50)
			@AssessorID INT
			,@AssessorName NVARCHAR(50)
			,@TargetFrequencyValue NVARCHAR(50)
			,@TargetFrequencyTypeID INT

		SELECT Category.value('(AssessorTemplateID)[1]', 'VARCHAR(100)') AS AssessorTemplateID
			,Category.value('(AssessorTemplateName)[1]', 'VARCHAR(100)') AS AssessorTemplateName
			,Category.value('(IsLocked)[1]', 'VARCHAR(100)') AS IsLocked
			,Category.value('(IsTargetFrequencyDefined)[1]', 'VARCHAR(100)') AS IsTargetFrequencyDefined
			,Category.value('(ModifiedAt/text())[1]', 'VARCHAR(100)') AS ModifiedAt
			,Category.value('(ModifiedBy_UserID/text())[1]', 'VARCHAR(10)') AS ModifiedBy_UserID
			,Category.value('(CreatedAt/text())[1]', 'VARCHAR(100)') AS CreatedAt
			,Category.value('(CreatedBy_UserID/text())[1]', 'VARCHAR(100)') AS CreatedBy_UserID
		INTO #T1
		FROM @ImportExcel_AssessorTemplate.nodes('/AssessorTemplate') AS TEMPTABLE(Category)

		SET @AssessorTemplateID = (
				SELECT AssessorTemplateID
				FROM #T1
				)

		PRINT @AssessorTemplateID

		--****************start of IF*********************************************************************************
		IF (
				@AssessorTemplateID IS NULL
				OR @AssessorTemplateID = 0
				)
		BEGIN
			INSERT INTO T_TRN_AssessorTemplate (
				AssessorTemplateName
				,IsLocked
				,IsTargetFrequencyDefined
				,ModifiedAt
				,ModifiedBy_UserID
				,CreatedAt
				,CreatedBy_UserID
				)
			SELECT AssessorTemplateName
				,IsLocked
				,IsTargetFrequencyDefined
				,ModifiedAt
				,ModifiedBy_UserID
				,CreatedAt
				,CreatedBy_UserID
			FROM #T1
			WHERE AssessorTemplateID = NULL
				OR AssessorTemplateID = 0

			SET @AssessorTemplateID = SCOPE_IDENTITY()

			PRINT @AssessorTemplateID

			--**************************************Inserting into VCAT**********
			INSERT INTO T_TRN_Assessor (
				AssessorTemplateID
				,AssessorName
				,TargetFrequencyValue
				,TargetFrequencyTypeID
				)
			SELECT SCOPE_IDENTITY() AS AssessorTemplateID
				,--ATTRIBUTE
				Category.value('(AssessorName)[1]', 'VARCHAR(100)') AS AssessorName
				,Category.value('(TargetFrequencyValue/text())[1]', 'VARCHAR(10)') AS TargetFrequencyValue
				,Category.value('(TargetFrequencyTypeID/text())[1]', 'VARCHAR(100)') AS TargetFrequencyTypeID
			FROM @ImportExcel_Assessor.nodes('/ArrayOfAssessor/Assessor') AS TEMPTABLE(Category)
				--*************************************************************************
				-- SELECT
				--   @ValueStreamTemplateID AS ValueStreamTemplateID, --ATTRIBUTE
				--   ValueStream.value('(ValueStreamCategoryName)[1]','VARCHAR(100)') AS ValueStreamCategoryName,
				--   ValueStream.value('(ValueStreamData)[1]','VARCHAR(100)') AS ValueStreamName,
				--NULL as ValueStreamCategoryID
				--cid
				--  into  #T3   
				--   FROM
				--   @ValueStreams.nodes('/ArrayOfValueStream/ValueStream')AS TEMPTABLE(ValueStream)
				--update #T3 set ValueStreamCategoryID = (select ValueStreamCategoryID from T_TRN_ValueStreamCategory_ImportTest t1 Where #T3.ValueStreamCategoryName = t1.ValueStreamCategoryName and t1.ValueStreamTemplateID = @ValueStreamTemplateID)
				--insert into T_TRN_ValueStream_ImportTest (ValueStreamCategoryID,ValueStreamTemplateID,ValueStreamData)
				-- select ValueStreamCategoryID,ValueStreamTemplateID,ValueStreamName from #T3
		END
				--**********************************END of IF and Initial Insertion************************
		ELSE IF (@AssessorTemplateID IS NOT NULL)
		BEGIN
			SELECT @AssessorTemplateName = AssessorTemplateName
				,@IsLocked = IsLocked
				,@ModifiedAt = ModifiedAt
				,@ModifiedBy_UserID = ModifiedBy_UserID
				,@CreatedAt = CreatedAt
				,@CreatedBy_UserID = CreatedBy_UserID
			FROM #T1

			UPDATE T_TRN_AssessorTemplate
			SET AssessorTemplateName = @AssessorTemplateName
				,IsLocked = @IsLocked
				,ModifiedAt = @ModifiedAt
				,CreatedAt = @CreatedAt
			WHERE AssessorTemplateID = @AssessorTemplateID

			--**************************************************UPDATE  VALUESTREAMCATEGORY**************************************************************************************************
			-- select
			--  @AssessorTemplateID AS AssessorTemplateID, --ATTRIBUTE
			-- Category.value('(AssessorCategoryID)[1]','VARCHAR(100)') AS AssessorCategoryID,
			--    Category.value('(AssessorCategoryName)[1]','VARCHAR(100)') AS AssessorCategoryName,	  
			--	 Category.value('(IsDataRequired/text())[1]','VARCHAR(10)') AS IsDataRequired,
			--	  Category.value('(TypeOfInput_InputTypeID/text())[1]','VARCHAR(100)') AS TypeOfInput_InputTypeID,
			--	   Category.value('(IsDataRequiredToFitSpecLength/text())[1]','VARCHAR(100)') AS IsDataRequiredToFitSpecLength,
			--	    Category.value('(MinimumNoOfCharacters/text())[1]','VARCHAR(100)') AS MinimumNoOfCharacters,
			--		Category.value('(MaximumNoOfCharacters/text())[1]','VARCHAR(100)') AS MaximumNoOfCharacters,
			--		Category.value('(TempID/text())[1]','VARCHAR(100)') AS TempID
			--		into #T4
			--   FROM @ImportExcel_AssessorTemplate_Cat.nodes('/ArrayOfValueStreamCategory/ValueStreamCategory')AS TEMPTABLE(Category)
			--INSERT INTO T_TRN_AssessorCategory(AssessorCategoryName,AssessorTemplateID,IsDataRequired,TypeOfInput_InputTypeID,IsDataRequiredToFitSpecLength,MinimumNoOfCharacters,MaximumNoOfCharacters)
			--select AssessorCategoryName,AssessorTemplateID,IsDataRequired,TypeOfInput_InputTypeID,IsDataRequiredToFitSpecLength,MinimumNoOfCharacters,MaximumNoOfCharacters from #T4 where AssessorCategoryID = NULL OR AssessorCategoryID = 0
			--   set @min = (select MIN(AssessorTemplateID) from #T4); 
			--set @max = (select Max(AssessorTemplateID) from #T4);  
			-- while(@min <= @max)
			-- BEGIN
			--      select @AssessorCategoryName=AssessorCategoryName, @IsDataRequired=IsDataRequired, @TypeOfInput_InputTypeID=TypeOfInput_InputTypeID,
			--@IsDataRequiredToFitSpecLength=IsDataRequiredToFitSpecLength,
			--@MinimumNoOfCharacters=MinimumNoOfCharacters,@MaximumNoOfCharacters=MaximumNoOfCharacters
			-- from #T4 where AssessorCategoryID=@min
			--update T_TRN_AssessorCategory Set AssessorCategoryName = @AssessorCategoryName, IsDataRequired = @IsDataRequired, TypeOfInput_InputTypeID = @TypeOfInput_InputTypeID,
			--IsDataRequiredToFitSpecLength=@IsDataRequiredToFitSpecLength,MinimumNoOfCharacters=@MinimumNoOfCharacters,MaximumNoOfCharacters=@MaximumNoOfCharacters
			-- Where AssessorCategoryID = @min and AssessorTemplateID=@AssessorTemplateID
			--      set @min=@min+1 
			--  END
			--******************************************************END UPDATE  VALUESTREAMCATEGORY ****************************************************************************************************
			--******************************************************UPDATE VALUESTREAM*****************************************************************************************************************
			SELECT Category.value('(AssessorID/text())[1]', 'int') AS AssessorID
				,@AssessorTemplateID AS AssessorTemplateID
				,--ATTRIBUTE
				Category.value('(AssessorName)[1]', 'VARCHAR(100)') AS AssessorName
				,Category.value('(TargetFrequencyValue/text())[1]', 'VARCHAR(10)') AS TargetFrequencyValue
				,Category.value('(TargetFrequencyTypeID/text())[1]', 'VARCHAR(100)') AS TargetFrequencyTypeID
			INTO #T2
			FROM @ImportExcel_Assessor.nodes('/ArrayOfAssessor/Assessor') AS TEMPTABLE(Category)

			SELECT *
			FROM #T2

			INSERT INTO T_TRN_Assessor (
				AssessorTemplateID
				,AssessorName
				,TargetFrequencyValue
				,TargetFrequencyTypeID
				)
			SELECT @AssessorTemplateID AS AssessorTemplateID
				,AssessorName
				,TargetFrequencyValue
				,TargetFrequencyTypeID
			FROM #T2
			WHERE AssessorID = NULL
				OR AssessorID = 0

			SELECT *
			FROM T_TRN_Assessor

			SELECT MIN(AssessorID)
			FROM #T2

			SELECT Max(AssessorID)
			FROM #T2

			SET @min = (
					SELECT MIN(AssessorID)
					FROM #T2
					);--Get minimum row number from temp table
			SET @max = (
					SELECT Max(AssessorID)
					FROM #T2
					);--Get maximum row number from temp table

			PRINT 'hello'
			PRINT @min
			PRINT @max
			PRINT @AssessorTemplateID

			WHILE (@min <= @max)
			BEGIN
				SELECT @AssessorName = AssessorName
					,@TargetFrequencyValue = TargetFrequencyValue
					,@TargetFrequencyTypeID = TargetFrequencyTypeID
				FROM #T2
				WHERE AssessorID = @min

				UPDATE T_TRN_Assessor
				SET AssessorName = @AssessorName
					,TargetFrequencyValue = @TargetFrequencyValue
					,TargetFrequencyTypeID = @TargetFrequencyTypeID
				WHERE AssessorID = @min
					AND AssessorTemplateID = @AssessorTemplateID

				SELECT *
				FROM T_TRN_Assessor

				SET @min = @min + 1 --Increment of current row number
			END
					--********************************************************UPDATE VALUESTREAM END*****************************************************************************************************************
		END
	END TRY

	BEGIN CATCH
		SELECT ERROR_NUMBER() AS ErrorNumber
			,ERROR_SEVERITY() AS ErrorSeverity
			,ERROR_STATE() AS ErrorState
			,ERROR_PROCEDURE() AS ErrorProcedure
			,ERROR_LINE() AS ErrorLine
			,ERROR_MESSAGE() AS ErrorMessage;
	END CATCH
END
GO


