/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_CompleteAuditByAuditAndTemplateID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING COMPLETE AUDIT BY AUDIT AND TEMPLATE ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			RAJASEKAR S					PLANTID,CURRENTUSERNTID ADDED
ELPC_LH_002					27-MAR-2021			RAJASEKAR S					HISTORY LOGIC ADDED
ELPC_LH_003					23-JUL-2021			RAJASEKAR S					ISDEVIATION WRONGLY UPDATING TO QUESTIONS IN DATAPOOL- FIXED
ELPC_LH_002_CR05				06-DEC-2021			VENKATESH GOVINDARAJ		QUESTION ORDER BY LOGIC CHANGED
ELPC_LH_006					18-AUG-2023			ASHOK KUMAR R B, GOPIKA 		V4.0
ELPC_LH_007				18-APR-2024			 GOPIKA 		V4.6 Assesor ID change

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_CompleteAuditByAuditAndTemplateID] 1,1
*/
CREATE PROCEDURE [USP_CompleteAuditByAuditAndTemplateID] @PlantID INT  
 ,@AuditID INT  
 ,@AuditTemplateID INT  
 ,@CurrentUserNTID NVARCHAR(20)  
AS  
BEGIN  
 BEGIN TRY  
  --Inputs filed variable for triggers  
  DECLARE @Scope_Identity_Table_Trigger TABLE (id INT);--Scope identities for all inserted rows  
  DECLARE @Input_Ids_Trigger VARCHAR(MAX);  
  DECLARE @TableName_Trigger VARCHAR(100);  
  DECLARE @ActionType VARCHAR(10);  
  
    BEGIN TRANSACTION TRNCOMPLETEAUDIT  
  
  EXEC [USP_PlantIDValidation] @PlantID = @PlantID  
   ,@ID = @AuditID  
   ,@Mode = 'AUDIT'  
   ,@CurrentUserNTID = @CurrentUserNTID  
  
  DECLARE @ValueStreamID INT  
  DECLARE @TagID INT  
  Declare @AssessorID INT
  
  SET @ValueStreamID = (  
    SELECT TOP 1 ValueStreamID  
    FROM T_TRN_Audit WITH(NOLOCK)  
    WHERE AuditID = @AuditID  
     AND PlantID = @PlantID  
    )  
  SET @TagID = (  
    SELECT TOP 1 TagID  
    FROM T_TRN_Audit WITH(NOLOCK)  
    WHERE AuditID = @AuditID  
     AND PlantID = @PlantID  
    )
	
  If(@AuditTemplateID = 0 OR @AuditTemplateID IS NULL)
  Begin
    Set @AuditTemplateID = 1
  End
  UPDATE T_LNK_Audit_AnsweredQuestions  
  SET IsAuditCompleted = 1  
  WHERE AuditID = @AuditID  
   AND AuditTemplateID = @AuditTemplateID  
  
  --List the questions avaliable on AuditTemplate  
  SELECT Identity(INT, 1, 1) AS RowID  
   ,convert(INT, QuestionID) AS QuestionID  
  INTO #tmpAuditQuestions  
  FROM T_LNK_Audit_AnsweredQuestions WITH(NOLOCK)  
  WHERE AuditID = @AuditID  
   AND AuditTemplateID = @AuditTemplateID  
  
  --SELECT * FROM #tmpAuditQuestions  
  DECLARE @min INT = 0  
   ,@max INT = 0;  
  
  SET @min = (  
    SELECT MIN(RowID)  
    FROM #tmpAuditQuestions  
    );--Get minimum row number from temp table  
  SET @max = (  
    SELECT Max(RowID)  
    FROM #tmpAuditQuestions  
    );--Get maximum row number from temp table  
  
  WHILE (@min <= @max)  
  BEGIN  
   DECLARE @DeviationID INT=0;  
   DECLARE @AuditQuestionID INT=0;  
  
   --Retrive aduit template current questionID from temp Table  
   SET @AuditQuestionID = (  
     SELECT TOP 1 QuestionID  
     FROM #tmpAuditQuestions  
     WHERE RowID = @min  
     );  
  set @AssessorID= (select TOP 1 AssessorID from T_LNK_Audit_AnsweredQuestions where AuditID =@AuditID
	 AND AuditTemplateID=@AuditTemplateID
	 AND QuestionID=@AuditQuestionID)

   --Retrive aduit template current question having any deviations or not  
   DECLARE @AuditDeviationID INT=0;  
  
   SET @AuditDeviationID = (  
     SELECT TOP 1 AuditDeviationID  
     FROM T_TRN_AuditDeviation WITH(NOLOCK)  
     WHERE QuestionID = @AuditQuestionID  
      AND AuditID = @AuditID  
      AND AuditTemplateID = @AuditTemplateID  
     )  
  
   --If current question having deviation then enter if condition else insert into datappol and increment loop by 1  
   IF (ISNULL(@AuditDeviationID,0)<>0)  
   BEGIN  
    --SELECT @AuditQuestionID as AuditQuestionID  
    --Retrive data from AuditDeviation & insert into Deviation table   
    INSERT INTO [T_TRN_Deviation] (  
     PlantID  
     ,DeviationDisplayID  
     ,ValueStreamID  
     ,DeviationDescription  
     ,ResponsibleEmployee  
     ,CreatedBy_NTID  
     ,CreatedAt  
     ,ModifiedAt  
     ,QuestionID  
     )  
    SELECT @PlantID  
     ,(  
      SELECT DisplayID  
      FROM [FN_GetNextDisplayID](@PlantID, 'T_TRN_Deviation')  
      )  
     ,ValueStreamID  
     ,DeviationDescription  
     ,ResponsibleEmployee  
     ,CreatedBy_NTID  
     ,(  
      SELECT FormattedDateTime  
      FROM fnGetDateTime(@PlantID)  
      )  
     ,(  
      SELECT FormattedDateTime  
      FROM fnGetDateTime(@PlantID)  
      )  
     ,@AuditQuestionID  
    FROM T_TRN_AuditDeviation WITH(NOLOCK)  
    WHERE QuestionID = @AuditQuestionID  
     AND AuditID = @AuditID  
     AND AuditTemplateID = @AuditTemplateID  
  
    SET @DeviationID = SCOPE_IDENTITY()  
     --(SELECT AuditDeviationID  
     --FROM T_TRN_AuditDeviation WITH(NOLOCK)  
     --WHERE QuestionID = @AuditQuestionID  
     -- AND AuditID = @AuditID  
     -- AND AuditTemplateID = @AuditTemplateID  
     --)  
    --SELECT @DeviationID AS DeviationID  
    --Check current deviation is having any attachment files,   
    --if yes then enter into if condition or else delete the deviation details  
    IF (  
      (  
       SELECT count(*)  
       FROM T_LNK_AuditDeviation_AdditionalEmployee WITH(NOLOCK)  
       WHERE DeviationID = @AuditDeviationID  
       ) > 0  
      )  
    BEGIN  
    insert into [T_LNK_Deviation_AdditionalEmployee]  
    (  
   DeviationID  
   ,NTID  
   ,CreatedAt  
   ,ModifiedAt  
   ,IsDeleted  
   ,CreatedBy_NTID  
   ,ModifiedBy_NTID  
   ,UserName  
    )  
    select  @DeviationID AS DeviationID  
    ,NTID  
    ,CreatedAt  
    ,ModifiedAt  
   ,IsDeleted  
   ,CreatedBy_NTID  
   ,ModifiedBy_NTID  
   ,UserName  
   from T_LNK_AuditDeviation_AdditionalEmployee WITH(NOLOCK)  
     WHERE DeviationID = @AuditDeviationID  
     IF (  
       (  
        SELECT Count(*)  
        FROM T_LNK_Audit_AnsweredQuestions WITH(NOLOCK)  
        WHERE AuditID = @AuditID  
         AND AuditTemplateID = @AuditTemplateID  
         AND IsAnswered = 1  
         AND QuestionID = @AuditQuestionID  
        ) > 0  
       )  
     BEGIN  
      --Delete data from AuditDeviationAttachment table  
      DELETE T_LNK_AuditDeviation_AdditionalEmployee  
      WHERE DeviationID = @AuditDeviationID  
     END  
    END  
    IF (  
      (  
       SELECT count(*)  
       FROM T_LNK_AuditDeviation_AssignedTags WITH(NOLOCK)  
       WHERE DeviationID = @AuditDeviationID  
       ) > 0  
      )  
    BEGIN  
    INSERT INTO T_LNK_Deviation_AssignedTags (  
   DeviationID  
   ,TagID  
   ,IsDeleted  
   ,CreatedAt  
   ,ModifiedAt  
   ,CreatedBy_NTID  
   ,ModifiedBy_NTID  
   ,TagName  
   )  
   select  @DeviationID AS DeviationID  
   ,TagID  
   ,IsDeleted  
   ,CreatedAt  
   ,ModifiedAt  
   ,CreatedBy_NTID  
   ,ModifiedBy_NTID  
   ,TagName  
   from T_LNK_AuditDeviation_AssignedTags WITH(NOLOCK)  
     WHERE DeviationID = @AuditDeviationID  
     IF (  
       (  
        SELECT Count(*)  
        FROM T_LNK_Audit_AnsweredQuestions WITH(NOLOCK)  
        WHERE AuditID = @AuditID  
         AND AuditTemplateID = @AuditTemplateID  
         AND IsAnswered = 1  
		 AND QuestionID = @AuditQuestionID  
        ) > 0  
       )  
     BEGIN  
      --Delete data from AuditDeviationAttachment table  
      DELETE T_LNK_AuditDeviation_AssignedTags  
      WHERE DeviationID = @AuditDeviationID  
     END  
    END  
  
    IF (  
      (  
       SELECT count(*)  
       FROM T_TRN_AuditDeviationAttachments WITH(NOLOCK)  
       WHERE AuditDeviationID = @AuditDeviationID  
       ) > 0  
      )  
    BEGIN  
     --select @AuditDeviationID as AuditDeviationID  
     --Retrive data from AuditDeviationAttachment table & insert into DeviationAttachment table   
     INSERT INTO [T_TRN_DeviationAttachments] (  
      DeviationID  
      ,QuestionID  
      ,ImageTitle  
      ,ImagePath  
      ,FileContent  
      ,CreatedBy_NTID  
      ,ModifiedBy_NTID  
      ,IsDeleted  
      ,DisplayFileName  
      )  
     SELECT @DeviationID AS DeviationID  
      ,QuestionID  
      ,ImageTitle  
      ,ImagePath  
      ,FileContent  
      ,CreatedBy_NTID  
      ,ModifiedBy_NTID  
      ,IsDeleted  
      ,DisplayFileName  
     FROM T_TRN_AuditDeviationAttachments WITH(NOLOCK)  
     WHERE AuditDeviationID = @AuditDeviationID  
  
     IF (  
       (  
        SELECT Count(*)  
        FROM T_LNK_Audit_AnsweredQuestions WITH(NOLOCK)  
        WHERE AuditID = @AuditID  
         AND AuditTemplateID = @AuditTemplateID  
          AND IsAuditCompleted=1
         AND QuestionID = @AuditQuestionID  
        ) > 0  
       )  
     BEGIN  
      --Delete data from AuditDeviationAttachment table  
      DELETE T_TRN_AuditDeviationAttachments  
      WHERE AuditDeviationID = @AuditDeviationID  
     END  
    END  
  
    IF (  
      (  
       SELECT Count(*)  
       FROM T_LNK_Audit_AnsweredQuestions WITH(NOLOCK)  
       WHERE AuditID = @AuditID  
        AND AuditTemplateID = @AuditTemplateID  
        AND IsAnswered = 1
        AND QuestionID = @AuditQuestionID 
		
       ) > 0  
      )  
    BEGIN  
     --delete data from deviation details  
     DELETE T_TRN_AuditDeviation  
     WHERE AuditDeviationID = @AuditDeviationID  
    END  
   END  
  
   DELETE  
   FROM @Scope_Identity_Table_Trigger  
  
   --To insert the completed audit questions into the Datapool  
   INSERT INTO T_TRN_DataPool (  
    [TIMESTAMP]  
    ,QuestionID  
    ,Answer  
    ,AnswerType_AnswerTypeID  
    ,CreatedAt  
    ,AnsweredBy_NTID  
    ,ModifiedAt  
    ,ModifiedBy_NTID  
    ,IsAnswered  
    ,AuditID  
    ,AuditTemplateID  
    ,ValueStreamID  
	,AssessorID
    ,TagID  
    ,ChoiceID  
    ,IsDeviation  
    ,DeviationID  
    ,PlantID  
    ,ObtainedScore  
    )  
   OUTPUT inserted.DataPoolID  
   INTO @Scope_Identity_Table_Trigger  
   SELECT (  
     SELECT FormattedDateTime  
     FROM fnGetDateTime(@PlantID)  
     )  
    ,QuestionID  
    ,CASE   
     WHEN AnswerTypeID = 3  
      THEN (  
        SELECT TOP 1 ChoiceName  
        FROM T_TRN_Choice WITH(NOLOCK)  
        WHERE choiceID = Answer  
        )  
     ELSE Answer  
     END AS Answer  
    ,AnswerTypeID AS AnswerType_AnswerTypeID  
    ,CreatedAt  
    ,CreatedBy_NTID AS AnsweredBy_NTID  
    ,ModifiedAt  
    ,ModifiedBy_NTID  
    ,1  
    ,@AuditID  
    ,@AuditTemplateID  
    ,@ValueStreamID 
	,@AssessorID
    ,@TagID  
    ,CASE   
     WHEN AnswerTypeID = 3  
      THEN Answer  
     ELSE NULL  
     END AS ChoiceID  
    ,CASE   
     WHEN (  
       @DeviationID IS NULL  
       OR @DeviationID = 0  
       )  
      THEN NULL  
     ELSE 1  
     END AS IsDeviation  
    ,CASE   
     WHEN (  
       @DeviationID IS NULL  
       OR @DeviationID = 0  
       )  
      THEN NULL  
     ELSE @DeviationID  
     END AS DeviationID  
    ,@PlantID  
    ,CASE   
     WHEN AnswerTypeID = 3  
      THEN (  
        SELECT TOP 1 ChoiceScore  
        FROM T_TRN_Choice WITH(NOLOCK)  
        WHERE choiceID = Answer  
        )  
     ELSE 0  
     END AS ObtainedScore  
   FROM T_LNK_Audit_AnsweredQuestions WITH(NOLOCK)  
   WHERE AuditID = @AuditID  
    AND AuditTemplateID = @AuditTemplateID  
    AND IsAuditCompleted = 1  -- TO insert the datapool entry only when the audit is comleted enen though by using the Skip Functionality
    AND QuestionID = @AuditQuestionID  
  
   SELECT @TableName_Trigger = 'DATAPOOL'  
    ,@ActionType = 'I'  
    ,@Input_Ids_Trigger = (  
     SELECT CAST(id AS VARCHAR(MAX)) + ', '  
     FROM @Scope_Identity_Table_Trigger  
     FOR XML PATH('')  
     );  
  
   EXEC [USP_DATAPOOL_HISTORY] @PlantID = @PlantID  
    ,@CurrentUserNTID = @CurrentUserNTID  
    ,@TableName = @TableName_Trigger  
    ,@ActionType = @ActionType  
    ,@INPUT_IDS = @Input_Ids_Trigger;  
  
   EXEC [USP_UpdateDataPool_SummaryByQuestionID] @AuditQuestionID  
  
   --Increment of current row number  
   SET @min = @min + 1  
   SET @DeviationID = NULL  
  END  
  
  COMMIT TRANSACTION TRNCOMPLETEAUDIT  
 END TRY  
  
 BEGIN CATCH  
  ROLLBACK TRANSACTION TRNCOMPLETEAUDIT  
  
  EXEC USP_LogError @PlantID  
   ,@CurrentUserNTID  
 END CATCH  
END
GO