/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_DeleteTag]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR DELETING TAG ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			KARTHIKEYAN K				PLANTID ADDED
ELPC_LH_003					15-NOV-2023			SHUBHAM BARANGE		        Soft Delete Tags Linkage
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_DeleteTag] 1,1,'OSP4KOR','2020-11-15 14:18:21.720'
*/
CREATE PROCEDURE [USP_DeleteTag] (
	@PlantID INT
	, @TagID INT
	, @ModifiedAt DATETIME
	, @CurrentUserNTID NVARCHAR(20)
	)
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION TRNDELETETAG

		SET @ModifiedAt = (
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				);

		-- Start - Soft Delete Tags
		UPDATE T_TRN_Tag
		SET IsDeleted = 1
			, ModifiedBy_NTID = @CurrentUserNTID
			, ModifiedAt = @ModifiedAt
		WHERE TagID = @TagID
			AND PlantID = @PlantID;

		UPDATE [T_LNK_QN_AssignedTagsHistory]
		SET IsDeleted = 1
			, ActionType = 'U'
			, ActionDate = @ModifiedAt
		--,ModifiedAt = @ModifiedAt
		WHERE TagID = @TagID

		UPDATE [T_LNK_QN_AssignedTags]
		SET IsDeleted = 1
		WHERE TagID = @TagID

		UPDATE [T_LNK_Tag_AssignedQuestionsTagsHistory]
		SET IsDeleted = 1
			, ActionType = 'U'
			, ActionAt = @ModifiedAt
		WHERE TagID = @TagID

		UPDATE [T_LNK_Tag_AssignedQuestionsTags]
		SET IsDeleted = 1
		WHERE TagID = @TagID

		UPDATE [T_LNK_Tag_AssignedAssessorsHistory]
		SET IsDeleted = 1
			, ActionType = 'U'
			, ActionAT = @ModifiedAt
		WHERE TagID = @TagID

		UPDATE [T_LNK_Tag_AssignedAssessors]
		SET IsDeleted = 1
		WHERE TagID = @TagID

		UPDATE [T_LNK_Tag_AssignedValueStreamsHistory]
		SET IsDeleted = 1
			, ActionType = 'U'
			, ActionAt = @ModifiedAt
		WHERE TagID = @TagID

		UPDATE [T_LNK_Tag_AssignedValueStreams]
		SET IsDeleted = 1
		WHERE TagID = @TagID

		UPDATE [T_LNK_Tag_Proxy]
		SET IsDeleted = 1
			, ModifiedBy_NTID = @CurrentUserNTID
			, ModifiedAt = @ModifiedAt
		WHERE TagID = @TagID

		UPDATE [T_TRN_TagHistory]
		SET IsDeleted = 1
			, ModifiedBy_NTID = @CurrentUserNTID
			, ModifiedAt = @ModifiedAt
		WHERE TagID = @TagID
			AND PlantID = @PlantID

		-- END - Soft Delete TAG
		COMMIT TRANSACTION TRNDELETETAG;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNDELETETAG;

		EXEC USP_LogError @PlantID
			, @CurrentUserNTID;
	END CATCH
END
GO