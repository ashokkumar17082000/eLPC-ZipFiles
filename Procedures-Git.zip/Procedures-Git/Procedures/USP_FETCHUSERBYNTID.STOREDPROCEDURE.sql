/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchUserByNTID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING USER DETAILS BY NTID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					26-MAR-2021			SIKHESH S					ADDITIONAL INPUT PARAMATERS INCLUDED, OUTPUT PARAMETERS REVISED, STANDARD RULES APPLIED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_FetchUserByNTID] 'OSP4KOR'

SELECT * FROM T_MST_User
*/
CREATE PROCEDURE [USP_FetchUserByNTID] (
	@NTID NVARCHAR(20)
	,@PlantID INT
	,@CurrentUserNTID NVARCHAR(20) = NULL
	)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT TOP 1 USR.UserID
		,USR.UserName
		,USR.EmployeeID
		,USR.EmailAddress
		,USR.NTID
		,USR.FirstName
		,USR.LastName
		,USR.ModifiedAt
		,USR.Role_RoleID
		,ROL.RoleName AS RoleName
		,USR.CustomIConID AS CustomIConID
	FROM T_MST_User USR WITH (NOLOCK)
	LEFT JOIN T_MST_Role ROL WITH (NOLOCK) ON USR.Role_RoleID = ROL.RoleID
		AND USR.PlantID = @PlantID
	WHERE USR.NTID = @NTID
		AND USR.PlantID = @PlantID
END
GO


