/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_ValidateAssessorByAuditAndNTID] 
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR PENDING AUDITS BY AUDIT ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			Rajasekar S					PlantId,CurrentUserNTID added

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_ValidateAssessorByAuditAndNTID]  1,1,'OSP4KOR'
*/
CREATE PROCEDURE [USP_ValidateAssessorByAuditAndNTID] @PlantID INT
	,@AuditID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	SET NOCOUNT ON;

	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = @AuditID
		,@Mode = 'AUDIT'
		,@CurrentUserNTID = @CurrentUserNTID

	SELECT TOP 1 RA.UserID
		,RA.NTID
		,RA.CreatedBy_NTID
		,RA.ModifiedBy_NTID
	FROM T_LNK_Audit_RequiredAttendees RA WITH (NOLOCK)
	INNER JOIN T_TRN_Audit A WITH (NOLOCK) ON A.AuditID = RA.AuditID
	WHERE RA.NTID = @CurrentUserNTID
		AND RA.AuditID = @AuditID
		AND A.PlantID = @PlantID
	
	UNION
	
	SELECT TOP 1 OA.UserID
		,OA.NTID
		,OA.CreatedBy_NTID
		,OA.ModifiedBy_NTID
	FROM T_LNK_Audit_OptionalAttendees OA WITH (NOLOCK)
	INNER JOIN T_TRN_Audit A WITH (NOLOCK) ON A.AuditID = OA.AuditID
	WHERE OA.NTID = @CurrentUserNTID
		AND OA.AuditID = @AuditID
		AND A.PlantID = @PlantID
END
GO


