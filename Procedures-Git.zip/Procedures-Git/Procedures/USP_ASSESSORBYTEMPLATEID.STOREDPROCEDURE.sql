/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_AssessorByTemplateID] 
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING ASSESSOR BY TEMPLATE ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					12-MAR-2021			KARTHIKEYAN KANDASAMY		MODIFIED VERSION
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_AssessorByTemplateID]  @PlantID=1, @AssessorTemplateID=1
*/
CREATE PROCEDURE [USP_AssessorByTemplateID] (
	@PlantID INT
	,@AssessorTemplateID INT
	)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT asr.AssessorID
		,asr.AssessorName
		,asr.TargetFrequencyValue
		,asr.AssessorTemplateID
		,asr.TargetFrequencyTypeID
		,asr.Category
		,asr.TargetFrequencyLowLimit
		,asr.IsDeleted
		,asr.ModifiedAt
		,asr.CreatedAt
		,asrtmp.PlantID
	FROM T_TRN_Assessor asr WITH (NOLOCK)
	INNER JOIN T_TRN_AssessorTemplate asrtmp WITH (NOLOCK) ON asrtmp.AssessorTemplateID = asr.AssessorTemplateID
	WHERE (
			asr.AssessorTemplateID = @AssessorTemplateID
			AND asrtmp.PlantID = @PlantID
			AND asr.IsDeleted = 0
			);
END
GO


