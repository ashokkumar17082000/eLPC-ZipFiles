/****** Object:  StoredProcedure [USP_ExportPlantReportOneYear]    Script Date: 08.03.2024 09:01:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
	/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_ExportPlantReport]
///AUTHOR                       : MONASH CHHETRI
///CREATED DATE                 : 19-OCT-2021
///SEE ALSO                     : THIS PROCEDURE TO EXPORT REPORT FOR PLANT
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
Phase2-eLPC_LH_003		    19-OCT-2021			MONASH CHHETRI				INITIAL VERSION
ELPC_LH_005					15-MAR-2023         Gopika PG                   Documenting a deviation 
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)

--Plant Report
EXEC [USP_ExportPlantReportOneYear] 1 , 'FSM1COB', 1

--User Report
EXEC [USP_ExportPlantReportOneYear] 2 , 'FSM1COB', 1
*/

CREATE PROCEDURE [USP_ExportPlantReportOneYear] (
		@PlantID INT
		,@CurrentUserNTID NVARCHAR(20) = NULL
		,@IsUserReport BIT = false
		)
	AS
	BEGIN
		SET NOCOUNT ON;

		----------DataPool------------------------------------------------------
		DECLARE @temp TABLE (
			DataPoolID INT
			,DataPoolDisplayID INT
			,TIMESTAMP DATETIME
			,UserName NVARCHAR(200)
			,ValueStreamData NVARCHAR(MAX)
			,AssessorName NVARCHAR(MAX)
			,QuestionID INT
			,QuestionDisplayID INT
			,QuestionText NVARCHAR(MAX)
			,Answer NVARCHAR(MAX)
			,ChoiceID NVARCHAR(MAX)
			,ObtainedScore DECIMAL(10, 2)
			,answerType_AnswerTypeID INT
			,ValueStreamID INT
			,AssessorID INT
			,DeviationID INT
			,TagID INT
			,AuditID INT
			,AuditTemplateID INT
			,AnsweredBy_NTID NVARCHAR(20)
			,TagIDList NVARCHAR(MAX)
			,OriginTag NVARCHAR(MAX)
			,OPLURL NVARCHAR(MAX)
			,EmpList NVARCHAR(MAX)
			,MultiTagList NVARCHAR(MAX)
			,MultiTagID NVARCHAR(MAX)
			,AnonymizeUserDataSettingID NVARCHAR(MAX)
			--,ByteData varbinary(max)
			);

		INSERT INTO @temp
		EXEC [USP_GetDataPool_old] @PlantID
			,@CurrentUserNTID
			,NULL
			,NULL
			
		SELECT DP.DataPoolID
			,DP.TIMESTAMP
			,DP.ValueStreamID AS VALUE_STREAM_NAME_ID
			,DP.AssessorID AS ASSESSOR_NAME_ID
			,OriginTag
			,OPLURL
			,DP.QuestionDisplayID
			,DP.Answer
			,DP.ObtainedScore
			,DP.EmpList as Informationto
			,DP.MultiTagList as DeviationAssignedTags
			,DP.answerType_AnswerTypeID AS ANSWER_TYPE
			,CASE 
				WHEN ch.AnswerCategory = 'positive'
					THEN 1 --'Positive'
				WHEN ch.AnswerCategory = 'neutral'
					THEN 2 --'Neutral'
				WHEN ch.AnswerCategory = 'negative'
					AND (
						ch.DeviationTypeID = 1
						OR ch.DeviationTypeID = 4
						)
					THEN 3 --'Negative, no documentation'
				WHEN ch.AnswerCategory = 'negative'
					AND ch.DeviationTypeID = 2
					THEN 4 --'Negative, with documentation'
				WHEN ch.AnswerCategory = 'negative'
					AND ch.DeviationTypeID = 3
					THEN 5 --'Negative, with documentation and OPL'
				END AS ANSWER_CATEGORIZATION
			,DV.DeviationDescription AS DEVIATION_DESCRIPTION
			,IIF(DV.ResponsibleEmployee IS NULL, VS.ResponsibleEmployee, DV.ResponsibleEmployee) AS RESPONSIBLE
		FROM @temp DP
		LEFT JOIN T_TRN_Deviation DV WITH (NOLOCK) ON DV.DeviationID = DP.DeviationID
		LEFT JOIN T_TRN_ValueStream VS WITH (NOLOCK) ON VS.ValueStreamID = DP.ValueStreamID
		LEFT JOIN T_TRN_Choice CH WITH (NOLOCK) ON CH.ChoiceID = DP.ChoiceID
		WHERE DP.AnsweredBy_NTID = IIF(@IsUserReport = 1, @CurrentUserNTID, DP.AnsweredBy_NTID)
		and TIMESTAMP >= DATEADD(year, -1, GETDATE())
		 
		ORDER BY 1 DESC 

		--@IsUserReport
		SET NOCOUNT ON;

		DECLARE @tempDeviation TABLE (
			DeviationID INT
			,DeviationDisplayID INT
			,PlantID INT
			,TIMESTAMP DATETIME
			,UserName NVARCHAR(200)
			,ValueStreamID INT
			,ValueStreamName NVARCHAR(MAX)
			,QuestionID INT
			,QuestionDisplayID INT
			,QuestionText NVARCHAR(MAX)
			,Answer NVARCHAR(MAX)
			,ChoiceID NVARCHAR(MAX)
			,ObtainedScore DECIMAL(10, 2)
			,DeviationDescription NVARCHAR(MAX)
			,ResponsibleEmployee NVARCHAR(MAX)
			,DeviationAttachmentID NVARCHAR(MAX)
			,UploadedFileName NVARCHAR(MAX)
			,DisplayFileName NVARCHAR(MAX)
			,EmpList NVARCHAR(MAX)
			,MultiTagList NVARCHAR(MAX)
			,MultiTagID NVARCHAR(MAX)
			,CreatedBy_NTID NVARCHAR(MAX)
			,SuperOPLURL NVARCHAR(MAX)
			--,ByteData varbinary(max)
			);

		INSERT INTO @tempDeviation
		EXEC [USP_GetDeviationDataPool_old] @PlantID
			,@CurrentUserNTID
			,null
			,null
			
		SELECT DeviationID
			,DeviationDisplayID
			,TIMESTAMP
			,UserName
			,ValueStreamName
			,SuperOPLURL AS OPLURL
			,QuestionID
			,QuestionDisplayID
			,QuestionText
			,Answer
			,ObtainedScore
			,DeviationDescription
			,ResponsibleEmployee
			,DisplayFileName AS Attachments
			,DP.EmpList as Informationto
			,DP.MultiTagList as DeviationAssignedTags
			--,ByteData AS imagedata 
		FROM @tempDeviation DP
		WHERE DP.CreatedBy_NTID = IIF(@IsUserReport = 1, @CurrentUserNTID, DP.CreatedBy_NTID)
		and TIMESTAMP >= DATEADD(year, -1, GETDATE())

		------------VS_VALUESTREAMS---------------------------------------------
		SELECT VS.ValueStreamID AS VALUE_STREAM_NAME_ID
			,VST.ValueStreamTemplateName AS VALUE_STREAM_TEMPLATE_NAME
			,(
				SELECT TOP 1 IVS.ValueStreamName
				FROM T_TRN_ValueStream IVS WITH (NOLOCK)
				WHERE IVS.NodeID = 0
					AND IVS.ValueStreamTemplateID = VS.ValueStreamTemplateID
					AND IVS.RowID = VS.RowID
					AND IVS.Responsible_UserID IS NOT NULL
					AND IVS.IsDeleted = 0
				) AS VALUE_STREAM_NAME
			,VSS.ShiftName AS SHIFT_NAME
			,convert(VARCHAR(5), VSS.FromTime, 108) AS FROM_TIME
			,convert(VARCHAR(5), VSS.ToTime, 108) AS TO_TIME
			,VSS.IsMonday AS IS_MONDAY
			,VSS.IsTuesDay AS IS_TUESDAY
			,VSS.IsWednesday AS IS_WEDNESDAY
			,VSS.IsThursday AS IS_THRUSDAY
			,VSS.IsFriday AS IS_FRIDAY
			,VSS.IsSaturday AS IS_SATURDAY
			,VSS.IsSunday AS IS_SUNDAY
		FROM T_TRN_ValueStream VS WITH (NOLOCK)
		INNER JOIN T_TRN_ValueStreamTemplate VST WITH (NOLOCK) ON VS.ValueStreamTemplateID = VST.ValueStreamTemplateID
			AND VST.IsDeleted = 0
			AND VST.PlantID = @PlantID
		INNER JOIN T_TRN_ValueStreamCategory VSC WITH (NOLOCK) ON VS.ValueStreamCategoryID = VSC.ValueStreamCategoryID
			AND VSC.IsDeleted = 0
			AND VS.Responsible_UserID IS NOT NULL
		LEFT JOIN T_LNK_ValueStream_Shift VSS WITH (NOLOCK) ON VST.ValueStreamTemplateID = VSS.ValueStreamTemplateID
			AND VSS.RowID = VS.RowID
		WHERE VS.IsDeleted = 0
		and   VST.CreatedAt >= DATEADD(year, -1, GETDATE())
		ORDER BY VS.ValueStreamTemplateID
			,VS.RowID
			,VS.ValueStreamCategoryID
			,VS.NodeID

		----------------A_ASSESSORS--------------------------------------------------
		SELECT TA.AssessorID AS ASSESSOR_NAME_ID
			,TAT.AssessorTemplateName AS ASSESSOR_TEMPLATE_NAME
			,TA.AssessorName AS ASSESSOR_NAME
			,ISNULL(TA.TargetFrequencyValue, '') AS TARGET_FREQUENCY_VALUE
			,ISNULL(CASE 
					WHEN TA.TargetFrequencyTypeID = 1
						THEN 'Shift'
					WHEN TA.TargetFrequencyTypeID = 2
						THEN 'Day'
					WHEN TA.TargetFrequencyTypeID = 3
						THEN 'Week'
					WHEN TA.TargetFrequencyTypeID = 4
						THEN 'Bi-Weekly'
					WHEN TA.TargetFrequencyTypeID = 5
						THEN 'Month'
					WHEN TA.TargetFrequencyTypeID = 6
						THEN 'Quarter'
					WHEN TA.TargetFrequencyTypeID = 7
						THEN 'Year'
					END, '') AS TARGET_FREQUENCY_TYPE
			,TA.TargetFrequencyLowLimit AS Frequency_Lower_Limit_Percentage
			,ISNULL(TA.Category, '') AS CATEGORY
		FROM T_TRN_Assessor TA WITH (NOLOCK)
		INNER JOIN T_TRN_AssessorTemplate TAT WITH (NOLOCK) ON TA.AssessorTemplateID = TAT.AssessorTemplateID
			AND TAT.IsDeleted = 0
		WHERE TA.IsDeleted = 0
			AND TAT.PlantID = @PlantID
			and  TAT.CreatedAt >= DATEADD(year, -1, GETDATE())
		ORDER BY TAT.AssessorTemplateID

		-------Q_TEMPLATE------------------------------------------------------------
		SELECT QuestionDisplayID AS QUESTION_DISPLAY_ID
			,QuestionText AS QUESTION_TEXT
			,TargetFrequencyValue AS TARGET_FREQUENCY_VALUE
			,(
				SELECT TargetFrequencyTypeName
				FROM T_MST_TargetFrequencyType WITH (NOLOCK)
				WHERE TargetFrequencyTypeID = Q.TargetFrequencyTypeID
				) AS TARGET_FREQUENCY_TYPE
		FROM T_TRN_Question Q WITH (NOLOCK)
		WHERE IsDeleted = 0
			AND Q.PlantID = @PlantID
			and   Q.CreatedAt >= DATEADD(year, -1, GETDATE())

		---------Q_TEMPLATE_VALUESTREAMS-----------------------
		SELECT QuestionDisplayID AS QUESTION_DISPLAY_ID
			,VS.ValueStreamID AS VALUE_STREAM_NAME_ID
		FROM T_LNK_AssignedValueStreams AVS WITH (NOLOCK)
		INNER JOIN T_TRN_Question Q WITH (NOLOCK) ON AVS.QuestionID = Q.QuestionID
			AND Q.IsDeleted = 0
			AND Q.PlantID = @PlantID
		INNER JOIN T_TRN_ValueStream VS WITH (NOLOCK) ON VS.ValueStreamID = AVS.ValueStreamID
			AND VS.IsDeleted = 0
		WHERE AVS.IsDeleted = 0
		and Q.CreatedAt >= DATEADD(year, -1, GETDATE())

		-----------Q_TEMPLATE_ASSESSORS---------------
		SELECT QuestionDisplayID AS QUESTION_DISPLAY_ID
			--QuestionText as QUES
			,ASR.AssessorID AS ASSESSOR_NAME_ID
		FROM T_LNK_AssignedAssessors ASS WITH (NOLOCK)
		INNER JOIN T_TRN_Question Q WITH (NOLOCK) ON ASS.QuestionID = Q.QuestionID
			AND Q.PlantID = @PlantID
		INNER JOIN T_TRN_Assessor ASR WITH (NOLOCK) ON ASR.AssessorID = ASS.AssessorID
		WHERE Q.IsDeleted = 0
			AND ASS.IsDeleted = 0
			AND ASR.IsDeleted = 0
			and Q.CreatedAt >= DATEADD(year, -1, GETDATE())

		------LINKED_TAGS_Q------------------------
		SELECT (
				SELECT TagDisplayID
				FROM T_TRN_Tag
				WHERE TagID = FN.TagID
				) AS TagDisplayID
			,Q.QuestionDisplayID
		FROM T_TRN_Question AS Q WITH (NOLOCK)
		CROSS APPLY [FN_GetNestedTagsByQuestionID](Q.QuestionID, '') AS FN
		WHERE Q.PlantID = @PlantID
		and Q.CreatedAt >= DATEADD(year, -1, GETDATE())

		----------TAG--------------------------
		SELECT T.TagDisplayID AS TAG_DISPLAY_ID
			,T.TagName AS TAG_NAME
			,TF.TargetFrequencyTypeName AS TARGET_FREQUENCY_TYPE
			,TF.TargetFrequencyTypeID AS TARGET_FREQUENCY_VALUE
			,(
				CASE 
					WHEN TagTypeID = 1
						THEN 'Process Confirmation'
					WHEN TagTypeID = 2
						THEN 'Audit'
					WHEN TagTypeID = 3
						THEN 'Survey'
					ELSE ''
					END
				) AS TAG_TYPE
			,VS.ValueStreamID AS VALUE_STREAM_NAME_ID
			,TA.AssessorID AS ASSESSOR_NAME_ID
		FROM T_TRN_TAG T WITH (NOLOCK)
		LEFT JOIN T_MST_TargetFrequencyType TF WITH (NOLOCK) ON T.TargetFrequencyTypeID = TF.TargetFrequencyTypeID
		INNER JOIN T_LNK_Tag_AssignedValueStreams TVS WITH (NOLOCK) ON TVS.TagID = T.TagID
			AND TVS.IsDeleted = 0
		INNER JOIN T_TRN_ValueStream VS WITH (NOLOCK) ON VS.ValueStreamID = TVS.ValueStreamID
			AND VS.IsDeleted = 0
		INNER JOIN T_LNK_Tag_AssignedAssessors TAS WITH (NOLOCK) ON TAS.TagID = T.TagID
			AND TAS.IsDeleted = 0
		INNER JOIN T_TRN_Assessor TA WITH (NOLOCK) ON TA.AssessorID = TAS.AssessorID
			AND TA.IsDeleted = 0
		WHERE ISNULL(T.IsDeleted, 0) = 0
			AND T.PlantID = @PlantID
			and  T.CreatedAt >= DATEADD(year, -1, GETDATE())

		---------TAG_TEMPLATE_VALUE_STREAMS---------------
		SELECT T.TagID AS TAG_ID
			,VS.ValueStreamID AS VALUE_STREAM_NAME_ID
		FROM T_TRN_TAG T WITH (NOLOCK)
		INNER JOIN T_LNK_Tag_AssignedValueStreams TVS WITH (NOLOCK) ON TVS.TagID = T.TagID
			AND TVS.IsDeleted = 0
		INNER JOIN T_TRN_ValueStream VS WITH (NOLOCK) ON VS.ValueStreamID = TVS.ValueStreamID
			AND VS.IsDeleted = 0
		WHERE ISNULL(T.IsDeleted, 0) = 0
			AND T.PlantID = @PlantID
			and  T.CreatedAt >= DATEADD(year, -1, GETDATE())
		-----TAG_TEMPLATE_ASSESSORS------------------
		SELECT T.TagID AS TAG_ID
			,TA.AssessorID AS ASSESSOR_NAME_ID
			,ISNULL(TAS.IsMandatoryAssessor, 0) AS IS_MANDATORY
		FROM T_TRN_TAG T WITH (NOLOCK)
		INNER JOIN T_LNK_Tag_AssignedAssessors TAS WITH (NOLOCK) ON TAS.TagID = T.TagID
			AND TAS.IsDeleted = 0
		INNER JOIN T_TRN_Assessor TA WITH (NOLOCK) ON TA.AssessorID = TAS.AssessorID
			AND TA.IsDeleted = 0
		WHERE ISNULL(T.IsDeleted, 0) = 0
			AND T.PlantID = @PlantID
			and  T.CreatedAt >= DATEADD(year, -1, GETDATE())
	END
GO
-----------------------------

