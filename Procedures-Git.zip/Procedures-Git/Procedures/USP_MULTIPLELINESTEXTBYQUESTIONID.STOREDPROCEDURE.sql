/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_MultipleLinesTextByQuestionID] 
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING MULTILINES TEXT BY QUESTION ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			VENKATESH GOVINDARAJ		PlantID & Code Cleanup
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_MultipleLinesTextByQuestionID] 1, 1
*/
CREATE PROCEDURE [USP_MultipleLinesTextByQuestionID] @QuestionID INT
	,@PlantID INT
AS
BEGIN
	SET NOCOUNT ON;

	SELECT T.ID
		,T.MaxLines
		,T.IsPlaintText
		,T.QuestionID
		,T.IsDeleted
	FROM T_TRN_MultipleLinesText T WITH (NOLOCK)
	INNER JOIN T_TRN_QUESTION Q WITH (NOLOCK) ON Q.QuestionID = T.QuestionID
	WHERE T.QuestionID = @QuestionID
		AND T.IsDeleted = 0
		AND Q.PlantID = @PlantID
END
GO


