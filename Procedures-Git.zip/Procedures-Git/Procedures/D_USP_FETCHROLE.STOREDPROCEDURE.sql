SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [USP_FetchRole]
	--@PageNumber INT,
	--@PageSize INT,
	--@SortColumn VARCHAR(100) = 'RoleID',
	--@SortOrder varchar(50) = 'DESC'
	--AS
	--BEGIN
	--SET NOCOUNT ON
	--SELECT * FROM T_MST_Role Order by 
	--case 
	--when @SortOrder <>'ASC' then 0
	--when @SortColumn = 'RoleID' then RoleID
	--end ASC,
	--case 
	--when @SortOrder <>'ASC' then ''
	--when @SortColumn = 'RoleName' then RoleName
	--end ASC,
	--case 
	--when @SortOrder <>'DESC' then 0
	--when @SortColumn = 'RoleID' then RoleID
	--end ASC,
	--case 
	--when @SortOrder <>'DESC' then ''
	--when @SortColumn = 'RoleName' then RoleName
	--end ASC
	--OFFSET @PageSize*(@PageNumber-1) Rows FETCH NEXT @PageSize Rows Only  
AS
BEGIN
	SELECT *
	FROM T_MST_Role
	WHERE (IsDeleted = 0)
END
GO


