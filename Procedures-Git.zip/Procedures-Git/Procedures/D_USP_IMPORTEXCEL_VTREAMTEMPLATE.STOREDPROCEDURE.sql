SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [USP_ImportExcel_VtreamTemplate] @ImportExcel_ValueStreamTemplate XML NULL
	,@ImportExcelCat_ValueStreamTemplate XML NULL
	-- @ValueStreams XML NULL
AS
BEGIN
	BEGIN TRY
		DECLARE @min INT = 0
			,@max INT = 0
			,@ValueStreamTemplateID INT
			,@ValueStreamTemplateName VARCHAR(50)
			,@IsLocked BIT
			,@ModifiedAt DATETIME
			,@ModifiedBy_UserID INT
			,@CreatedAt DATETIME
			,@CreatedBy_UserID INT
			,@Delimiter CHAR
			,@IsOperatedInShifts BIT
			,@VisualizationViewModeID INT
			,@ValueStreamCategoryName VARCHAR(50)
			,@IsDataRequired BIT
			,@TypeOfInput_InputTypeID VARCHAR(50)
			,@IsDataRequiredToFitSpecLength BIT
			,@MinimumNoOfCharacters INT
			,@MaximumNoOfCharacters INT
			,@ValueStreamData VARCHAR(50)

		SELECT Category.value('(ValueStreamTemplateID)[1]', 'VARCHAR(100)') AS ValueStreamTemplateID
			,Category.value('(ValueStreamTemplateName)[1]', 'VARCHAR(100)') AS ValueStreamTemplateName
			,Category.value('(IsLocked)[1]', 'VARCHAR(100)') AS IsLocked
			,Category.value('(ModifiedAt/text())[1]', 'VARCHAR(100)') AS ModifiedAt
			,Category.value('(ModifiedBy_UserID/text())[1]', 'VARCHAR(10)') AS ModifiedBy_UserID
			,Category.value('(CreatedAt/text())[1]', 'VARCHAR(100)') AS CreatedAt
			,Category.value('(CreatedBy_UserID/text())[1]', 'VARCHAR(100)') AS CreatedBy_UserID
			,Category.value('(Delimiter/text())[1]', 'VARCHAR(100)') AS Delimiter
			,Category.value('(IsOperatedInShifts/text())[1]', 'VARCHAR(100)') AS IsOperatedInShifts
			,Category.value('(VisualizationViewModeID/text())[1]', 'VARCHAR(100)') AS VisualizationViewModeID
			,Category.value('(TempID/text())[1]', 'VARCHAR(100)') AS TempID
		INTO #T1
		FROM @ImportExcel_ValueStreamTemplate.nodes('/ValueStreamTemplate') AS TEMPTABLE(Category)

		SET @ValueStreamTemplateID = (
				SELECT ValueStreamTemplateID
				FROM #T1
				)

		--****************start of IF*********************************************************************************
		IF (
				@ValueStreamTemplateID IS NULL
				OR @ValueStreamTemplateID = 0
				)
		BEGIN
			INSERT INTO T_TRN_ValueStreamTemplate_ImportTest (
				ValueStreamTemplateName
				,ModifiedAt
				,ModifiedBy_UserID
				,CreatedAt
				,CreatedBy_UserID
				,Delimiter
				,IsOperatedInShifts
				,VisualizationViewModeID
				,TempID
				,IsLocked
				)
			SELECT ValueStreamTemplateName
				,ModifiedAt
				,ModifiedBy_UserID
				,CreatedAt
				,CreatedBy_UserID
				,Delimiter
				,IsOperatedInShifts
				,VisualizationViewModeID
				,TempID
				,IsLocked
			FROM #T1
			WHERE ValueStreamTemplateID = NULL
				OR ValueStreamTemplateID = 0

			SET @ValueStreamTemplateID = SCOPE_IDENTITY()

			--**************************************Inserting into VCAT**********
			INSERT INTO T_TRN_ValueStreamCategory_ImportTest (
				ValueStreamTemplateID
				,ValueStreamCategoryName
				,IsDataRequired
				,TypeOfInput_InputTypeID
				,IsDataRequiredToFitSpecLength
				,MinimumNoOfCharacters
				,MaximumNoOfCharacters
				,TempID
				)
			SELECT SCOPE_IDENTITY() AS ValueStreamTemplateID
				,--ATTRIBUTE
				Category.value('(ValueStreamCategoryName)[1]', 'VARCHAR(100)') AS ValueStreamCategoryName
				,Category.value('(IsDataRequired/text())[1]', 'VARCHAR(10)') AS IsDataRequired
				,Category.value('(TypeOfInput_InputTypeID/text())[1]', 'VARCHAR(100)') AS TypeOfInput_InputTypeID
				,Category.value('(IsDataRequiredToFitSpecLength/text())[1]', 'VARCHAR(100)') AS IsDataRequiredToFitSpecLength
				,Category.value('(MinimumNoOfCharacters/text())[1]', 'VARCHAR(100)') AS MinimumNoOfCharacters
				,Category.value('(MaximumNoOfCharacters/text())[1]', 'VARCHAR(100)') AS MaximumNoOfCharacters
				,Category.value('(TempID/text())[1]', 'VARCHAR(100)') AS TempID
			FROM @ImportExcelCat_ValueStreamTemplate.nodes('/ArrayOfValueStreamCategory/ValueStreamCategory') AS TEMPTABLE(Category)
				--*************************************************************************
				-- SELECT
				--   @ValueStreamTemplateID AS ValueStreamTemplateID, --ATTRIBUTE
				--   ValueStream.value('(ValueStreamCategoryName)[1]','VARCHAR(100)') AS ValueStreamCategoryName,
				--   ValueStream.value('(ValueStreamData)[1]','VARCHAR(100)') AS ValueStreamName,
				--NULL as ValueStreamCategoryID
				--cid
				--  into  #T3   
				--   FROM
				--   @ValueStreams.nodes('/ArrayOfValueStream/ValueStream')AS TEMPTABLE(ValueStream)
				--update #T3 set ValueStreamCategoryID = (select ValueStreamCategoryID from T_TRN_ValueStreamCategory_ImportTest t1 Where #T3.ValueStreamCategoryName = t1.ValueStreamCategoryName and t1.ValueStreamTemplateID = @ValueStreamTemplateID)
				--insert into T_TRN_ValueStream_ImportTest (ValueStreamCategoryID,ValueStreamTemplateID,ValueStreamData)
				-- select ValueStreamCategoryID,ValueStreamTemplateID,ValueStreamName from #T3
		END
				--**********************************END of IF and Initial Insertion************************
		ELSE IF (@ValueStreamTemplateID IS NOT NULL)
		BEGIN
			PRINT @ValueStreamTemplateID

			SELECT @ValueStreamTemplateName = ValueStreamTemplateName
				,@IsLocked = IsLocked
				,@ModifiedAt = ModifiedAt
				,@ModifiedBy_UserID = ModifiedBy_UserID
				,@CreatedAt = CreatedAt
				,@CreatedBy_UserID = CreatedBy_UserID
				,@Delimiter = Delimiter
				,@IsOperatedInShifts = IsOperatedInShifts
				,@VisualizationViewModeID = VisualizationViewModeID
			FROM #T1

			UPDATE T_TRN_ValueStreamTemplate_ImportTest
			SET ValueStreamTemplateName = @ValueStreamTemplateName
				,IsLocked = @IsLocked
				,ModifiedAt = @ModifiedAt
				,ModifiedBy_UserID = @ModifiedBy_UserID
				,CreatedAt = @CreatedAt
				,CreatedBy_UserID = @CreatedBy_UserID
				,Delimiter = @Delimiter
				,IsOperatedInShifts = @IsOperatedInShifts
				,VisualizationViewModeID = @VisualizationViewModeID
			WHERE ValueStreamTemplateID = @ValueStreamTemplateID

			--**************************************************UPDATE  VALUESTREAMCATEGORY**************************************************************************************************
			SELECT @ValueStreamTemplateID AS ValueStreamTemplateID
				,--ATTRIBUTE
				Category.value('(ValueStreamCategoryID)[1]', 'VARCHAR(100)') AS ValueStreamCategoryID
				,Category.value('(ValueStreamCategoryName)[1]', 'VARCHAR(100)') AS ValueStreamCategoryName
				,Category.value('(IsDataRequired/text())[1]', 'VARCHAR(10)') AS IsDataRequired
				,Category.value('(TypeOfInput_InputTypeID/text())[1]', 'VARCHAR(100)') AS TypeOfInput_InputTypeID
				,Category.value('(IsDataRequiredToFitSpecLength/text())[1]', 'VARCHAR(100)') AS IsDataRequiredToFitSpecLength
				,Category.value('(MinimumNoOfCharacters/text())[1]', 'VARCHAR(100)') AS MinimumNoOfCharacters
				,Category.value('(MaximumNoOfCharacters/text())[1]', 'VARCHAR(100)') AS MaximumNoOfCharacters
				,Category.value('(TempID/text())[1]', 'VARCHAR(100)') AS TempID
			INTO #T4
			FROM @ImportExcelCat_ValueStreamTemplate.nodes('/ArrayOfValueStreamCategory/ValueStreamCategory') AS TEMPTABLE(Category)

			INSERT INTO T_TRN_ValueStreamCategory_ImportTest (
				ValueStreamCategoryName
				,ValueStreamTemplateID
				,IsDataRequired
				,TypeOfInput_InputTypeID
				,IsDataRequiredToFitSpecLength
				,MinimumNoOfCharacters
				,MaximumNoOfCharacters
				,TempID
				)
			SELECT ValueStreamCategoryName
				,ValueStreamTemplateID
				,IsDataRequired
				,TypeOfInput_InputTypeID
				,IsDataRequiredToFitSpecLength
				,MinimumNoOfCharacters
				,MaximumNoOfCharacters
				,TempID
			FROM #T4
			WHERE ValueStreamCategoryID = NULL
				OR ValueStreamCategoryID = 0

			SET @min = (
					SELECT MIN(ValueStreamCategoryID)
					FROM #T4
					);
			SET @max = (
					SELECT Max(ValueStreamCategoryID)
					FROM #T4
					);

			WHILE (@min <= @max)
			BEGIN
				SELECT @ValueStreamCategoryName = ValueStreamCategoryName
					,@IsDataRequired = IsDataRequired
					,@TypeOfInput_InputTypeID = TypeOfInput_InputTypeID
					,@IsDataRequiredToFitSpecLength = IsDataRequiredToFitSpecLength
					,@MinimumNoOfCharacters = MinimumNoOfCharacters
					,@MaximumNoOfCharacters = MaximumNoOfCharacters
				FROM #T4
				WHERE ValueStreamCategoryID = @min

				UPDATE T_TRN_ValueStreamCategory_ImportTest
				SET ValueStreamCategoryName = @ValueStreamCategoryName
					,IsDataRequired = @IsDataRequired
					,TypeOfInput_InputTypeID = @TypeOfInput_InputTypeID
					,IsDataRequiredToFitSpecLength = @IsDataRequiredToFitSpecLength
					,MinimumNoOfCharacters = @MinimumNoOfCharacters
					,MaximumNoOfCharacters = @MaximumNoOfCharacters
				WHERE ValueStreamCategoryID = @min
					AND ValueStreamTemplateID = @ValueStreamTemplateID

				SET @min = @min + 1
			END
					--******************************************************END UPDATE  VALUESTREAMCATEGORY ****************************************************************************************************
					--******************************************************UPDATE VALUESTREAM*****************************************************************************************************************
					--  SELECT
					--   @ValueStreamTemplateID AS ValueStreamTemplateID, --ATTRIBUTE
					--  ValueStream.value('(ValueStreamCategoryID)[1]','VARCHAR(100)') AS ValueStreamCategoryID,
					--  ValueStream.value('(ValueStreamID)[1]','VARCHAR(100)') AS ValueStreamID,
					--    ValueStream.value('(ValueStreamCategoryName)[1]','VARCHAR(100)') AS ValueStreamCategoryName,
					--    ValueStream.value('(ValueStreamData)[1]','VARCHAR(100)') AS ValueStreamName
					-- 	      into #T5
					--    FROM
					--    @ValueStreams.nodes('/ArrayOfValueStream/ValueStream')AS TEMPTABLE(ValueStream)
					-- insert into T_TRN_ValueStream (ValueStreamCategoryID,ValueStreamTemplateID,ValueStreamData)
					--  select ValueStreamCategoryID,ValueStreamTemplateID,ValueStreamName from #T5  where ValueStreamID = NULL OR ValueStreamID = 0
					--   set @min = (select MIN(ValueStreamID) from #T5); --Get minimum row number from temp table
					--set @max = (select Max(ValueStreamID) from #T5);  --Get maximum row number from temp table
					-- while(@min <= @max)
					-- BEGIN
					--      select @ValueStreamData=ValueStreamName from #T5 where ValueStreamID=@min
					--update T_TRN_ValueStream Set ValueStreamData = @ValueStreamData Where ValueStreamID = @min and ValueStreamTemplateID=@ValueStreamTemplateID
					--      set @min=@min+1 --Increment of current row number
					--  END
					--********************************************************UPDATE VALUESTREAM END*****************************************************************************************************************
		END
	END TRY

	BEGIN CATCH
		SELECT ERROR_NUMBER() AS ErrorNumber
			,ERROR_SEVERITY() AS ErrorSeverity
			,ERROR_STATE() AS ErrorState
			,ERROR_PROCEDURE() AS ErrorProcedure
			,ERROR_LINE() AS ErrorLine
			,ERROR_MESSAGE() AS ErrorMessage;
	END CATCH
END
GO


