/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_ValidateLinkedQuestion]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR VALIDATING LINKED QUESTION
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			VENKATESH GOVINDARAJ		PlantID & Code Cleanup
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_ValidateLinkedQuestion] 1, 1
*/
CREATE PROCEDURE [USP_ValidateLinkedQuestion] @QuestionID INT
	,@PlantID INT
AS
BEGIN
	SET NOCOUNT ON;

	SELECT AQN.ID
	FROM T_LNK_Tag_AssignedQuestionsTags AQN WITH (NOLOCK)
	INNER JOIN T_TRN_Tag T WITH (NOLOCK) ON AQN.TagID = T.TagID
	WHERE AQN.QuestionID = @QuestionID
		AND (AQN.IsDeleted = 0)
		AND (T.IsDeleted = 0)
		AND T.PlantID = @PlantID
		AND 1 = 0	--Added to skip validaiton
END
GO


