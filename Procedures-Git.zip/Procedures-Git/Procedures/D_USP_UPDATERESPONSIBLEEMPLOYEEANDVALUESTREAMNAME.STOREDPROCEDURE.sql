/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_UpdateResponsibleEmployeeAndValueStreamName]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE TO UPDATE RESPONSIBLE EMPLOYEE AND VALUE STREAM NAME
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY				CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY INITIAL VERSION

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
EXEC [USP_UpdateResponsibleEmployeeAndValueStreamName]
*/
CREATE PROCEDURE [USP_UpdateResponsibleEmployeeAndValueStreamName] @ValueStreamTemplateID INT = 0
AS
BEGIN
	SELECT DISTINCT (RowID)
	INTO #T1
	FROM T_TRN_ValueStream
	WHERE ValueStreamTemplateID = @ValueStreamTemplateID

	DECLARE CUR_Accessor CURSOR FORWARD_ONLY
	FOR
	SELECT RowID
	FROM #T1

	DECLARE @ValueStreamID INT = 0;
	DECLARE @Responsible_UserID NVARCHAR(20);
	DECLARE @ResponsibleEmployee NVARCHAR(200);
	DECLARE @RowID INT = 0;
	DECLARE @MinNodeID INT = 0;
	DECLARE @MaxNodeID INT = 0;
	DECLARE @MinNodeID1 NVARCHAR(max);
	DECLARE @MaxNodeID1 NVARCHAR(max);
	DECLARE @ValueStreamName NVARCHAR(max);

	OPEN CUR_Accessor;

	FETCH NEXT
	FROM CUR_Accessor
	INTO @RowID

	PRINT @RowID

	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @MaxNodeID1 = (
				SELECT Max(NodeID)
				FROM T_TRN_ValueStream
				WHERE ValueStreamTemplateID = @ValueStreamTemplateID
					AND RowID = @RowID
					AND (
						ValueStreamData IS NOT NULL
						AND ValueStreamData != ''
						)
				)
		SET @MinNodeID1 = (
				SELECT Min(NodeID)
				FROM T_TRN_ValueStream
				WHERE ValueStreamTemplateID = @ValueStreamTemplateID
					AND RowID = @RowID
				)
		SET @MinNodeID = CAST(@MinNodeID1 AS INT)
		SET @MaxNodeID = CAST(@MaxNodeID1 AS INT)
		SET @Responsible_UserID = (
				SELECT TOP 1 Responsible_UserID
				FROM T_TRN_ValueStream
				WHERE ValueStreamTemplateID = @ValueStreamTemplateID
					AND RowID = @RowID
					AND NodeID = @MinNodeID
					AND Responsible_UserID IS NOT NULL
				)
		SET @ResponsibleEmployee = (
				SELECT TOP 1 ResponsibleEmployee
				FROM T_TRN_ValueStream
				WHERE ValueStreamTemplateID = @ValueStreamTemplateID
					AND RowID = @RowID
					AND NodeID = @MinNodeID
					AND Responsible_UserID IS NOT NULL
				)
		SET @ValueStreamName = (
				SELECT TOP 1 ValueStreamName
				FROM T_TRN_ValueStream
				WHERE ValueStreamTemplateID = @ValueStreamTemplateID
					AND RowID = @RowID
					AND ValueStreamName IS NOT NULL
				)

		PRINT @Responsible_UserID;
		PRINT @MinNodeID
		PRINT @MaxNodeID
		PRINT @RowID

		UPDATE T_TRN_ValueStream
		SET Responsible_UserID = @Responsible_UserID
			,ResponsibleEmployee = @ResponsibleEmployee
			,ValueStreamName = @ValueStreamName
		WHERE ValueStreamTemplateID = @ValueStreamTemplateID
			--and NodeID = @MaxNodeID 
			AND RowID = @RowID
			AND (
				ValueStreamData IS NOT NULL
				AND ValueStreamData != ''
				)

		FETCH NEXT
		FROM CUR_Accessor
		INTO @RowID
	END

	CLOSE CUR_Accessor;

	DEALLOCATE CUR_Accessor;
END
GO


