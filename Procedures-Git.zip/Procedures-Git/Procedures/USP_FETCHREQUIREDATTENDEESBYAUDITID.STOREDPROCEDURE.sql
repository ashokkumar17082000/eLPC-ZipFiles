/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchRequiredAttendeesByAuditID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING REQUIRED ATTENDEES BY AUDIT ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			Rajasekar S					PlantId,CurrentUserNTID added

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_FetchRequiredAttendeesByAuditID] 1,1,'OSP4KOR'
*/
CREATE PROCEDURE [USP_FetchRequiredAttendeesByAuditID] @PlantID INT
	,@AuditID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	SET NOCOUNT ON;

	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = @AuditID
		,@Mode = 'AUDIT'
		,@CurrentUserNTID = @CurrentUserNTID

	SELECT (
			SELECT TOP 1 UserName
			FROM T_MST_User WITH (NOLOCK)
			WHERE NTID = RA.NTID
				AND UserName IS NOT NULL
			) AS UserName
		,(
			SELECT TOP 1 EmailAddress
			FROM T_MST_User WITH (NOLOCK)
			WHERE NTID = RA.NTID
				AND EmailAddress IS NOT NULL
			) AS EmailAddress
		,RA.UserID
		,RA.NTID
	FROM T_LNK_Audit_RequiredAttendees RA WITH (NOLOCK)
	INNER JOIN T_TRN_Audit A WITH (NOLOCK) ON A.AuditID = RA.AuditID
	WHERE RA.AuditID = @AuditID
		AND A.PlantID = @PlantID
		AND (RA.IsDeleted = 0)
END
GO


