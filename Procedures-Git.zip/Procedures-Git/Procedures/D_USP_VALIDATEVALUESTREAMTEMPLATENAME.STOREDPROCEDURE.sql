/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_ValidateValueStreamTemplateName]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE TO VALIDATE VALUESTREAM TEMPLATE NAME
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
EXEC [USP_ValidateValueStreamTemplateName] 'Production'
*/
CREATE PROCEDURE [USP_ValidateValueStreamTemplateName] @ValueStreamTemplateName NVARCHAR(50)
AS
BEGIN
	SELECT *
	FROM T_TRN_ValueStreamTemplate
	WHERE ValueStreamTemplateName = RTRIM(LTRIM(@ValueStreamTemplateName))
END
GO


