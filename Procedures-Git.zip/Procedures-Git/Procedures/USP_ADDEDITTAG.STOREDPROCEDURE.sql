
/*          
///<SUMMARY>          
///DESCRIPTION                  : STORE PROCEDURE - [USP_AddEditTag]        
///AUTHOR                       : JANARTHANAN KRISHNASAMY        
///CREATED DATE                 : 25-NOV-2020        
///SEE ALSO                     : THIS PROCEDURE TO ADD AND EDIT TAG DETAILS         
///MODIFICATION HISTORY   :          
************************************************************************************************************         
///REF      DATE    MODIFIED BY    CHANGE DESCRIPTION          
************************************************************************************************************         
ELPC_LH_001     25-NOV-2020   JANARTHANAN KRISHNASAMY INITIAL VERSION        
ELPC_LH_002     16-MAR-2021   RAJASEKAR s    TRIGGER REMOVAL AND NEW TRIGGER LOGIC        
ELPC_LH_003     23-MAR-2021   KARTHIKEYAN K   PLANTID ADDED        
ELPC_LH_002     26-MAR-2021   RAJASEKAR s      TRIGGER LOGIC not required hence removed        
ELPC_LH_002     28-MAR-2021   RAJASEKAR s      TRIGGER LOGIC re-add based on analysis   
ELPC_LH_001     15-AUG-2022   ASHOK KUMAR R B 	Load Question Based on random Questions
ELPC_LH_005     15-mar-2023   BARDHAN SUSHANT   Multiple Tag import through excel
ELPC_LH_005     18-AUG-2023   ASHOK KUMAR R B, BARDHAN SUSHANT   globalTag change
   
************************************************************************************************************         
///</SUMMARY>        
--SAMPLE EXECUTION        
EXEC [USP_AddEditTag] <<>>        
*/        
CREATE PROCEDURE [USP_AddEditTag] (      
 @PlantID INT      
 ,@TagID INT NULL      
 ,@TagName NVARCHAR(MAX) NULL      
 ,@IsSingleQuestionSuppressed BIT NULL      
 ,@SuppressedDateRangeFrom DATETIME NULL      
 ,@SuppressedDateRangeTo DATETIME NULL      
 ,@IsTargetFrequencyDefined BIT NULL      
 ,@TargetFrequencyTypeID INT NULL      
 ,@TargetFrequencyValue NVARCHAR(50) NULL      
 ,@Tag_PriorityID INT NULL      
 ,@TagTypeID INT NULL      
 ,@IsLocked BIT NULL      
 ,@AnonymizeUserDataSettingID INT NULL      
 ,@IsBranchLogicToBeFollowed BIT NULL      
 ,@IsMandatoryAssessorsDefined BIT NULL      
 ,@IsDeleted BIT NULL      
 ,@CreatedAt DATETIME NULL      
 ,@ModifiedAt DATETIME NULL      
 ,@AssignedTags XML NULL      
 ,@AssignedQuestions XML NULL      
 ,@AddedRandomQuestions XML NULL      
 ,@FinalQuestionOrder XML NULL      
 ,@isSaveTag INT NULL      
 --,@Assigned_ValueStreamTemplateID INT NULL      
 --,@Assigned_ValueStreamCategoryID INT NULL      
 --,@Assigned_AssessorTemplateID INT NULL      
 ,@ValueStreams XML NULL      
 ,@Assessors XML NULL      
 ,@CurrentUserNTID NVARCHAR(20)    
 ,@IsSearchableTag BIT   
 ,@IsSkipQuestionDefined BIT  
 ,@IsQuestionOverviewDefined BIT  
 ,@IsProgressPercentageDefined BIT  
 ,@IsResultOverviewDefined BIT  
 ,@IsResumeTagDefined BIT  
 ,@IsReportingEmailDefined BIT  
 )      
AS      
BEGIN      
 BEGIN TRY      
  --Inputs filed variable for triggers      
  DECLARE @TagHistoryID INT = 0;      
  DECLARE @Save INT=0;      
  DECLARE @Scope_Identity_Table_Trigger TABLE (id INT);--Scope identities for all inserted rows      
  DECLARE @Input_Ids_Trigger VARCHAR(MAX);      
  DECLARE @TableName_Trigger VARCHAR(100);      
  DECLARE @ActionType VARCHAR(10);      
      
  BEGIN TRANSACTION TRNADDEDITTAG      
      
  SET ARITHABORT ON;      
      
  DECLARE @InsertOrUpdated BIT = 0;      
  ----to avoid entries from Lock settings update, it is enabled/disabled       
  DECLARE @min INT = 0      
   ,@max INT = 0      
   ,@ValueStreamID INT = 0      
   ,@AssessorID INT = 0      
   ,@IsMandatoryAssessor BIT      
   ,@QuestionID INT = 0      
   ,@LinkedTagID INT = 0      
   ,@ID INT = 0;      
    DECLARE @TotalCount INT      
    SET @TotalCount = (Select count(*) from string_split(REPLACE(@TagName,'!@#$%','~'),'~'))         
       
    DECLARE @Counter INT      
    SET @Counter = 1      
 DECLARE @TagText NVARCHAR(MAX)      
       
    WHILE (@Counter <= @TotalCount)      
    BEGIN      
  SELECT  @TagText = item FROM (SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 0)) RowNumber, t.value as item FROM String_split(REPLACE(@TagName,'!@#$%','~'),'~') t) y WHERE RowNumber = @Counter      
      
  IF (      
    @TagID IS NULL      
    OR @TagID = 0      
    )      
  BEGIN      
   INSERT INTO [T_TRN_Tag] (      
    PlantID      
    ,TagDisplayID      
    ,TagName      
    ,IsSingleQuestionSuppressed      
    ,SuppressedDateRangeFrom      
    ,SuppressedDateRangeTo      
    ,IsTargetFrequencyDefined      
    ,TargetFrequencyTypeID      
    ,TargetFrequencyValue      
    ,Tag_PriorityID      
    ,TagTypeID      
    ,IsLocked      
    ,CreatedBy_NTID      
    ,ModifiedBy_NTID      
    ,AnonymizeUserDataSettingID      
    ,IsBranchLogicToBeFollowed      
    ,IsMandatoryAssessorsDefined      
    ,IsDeleted      
    ,CreatedAt      
    ,ModifiedAt     
    ,IsSearchableTag  
    ,IsSkipQuestionDefined  
 ,IsQuestionOverviewDefined  
 ,IsProgressPercentageDefined  
 ,IsResultOverviewDefined  
 ,IsResumeTagDefined  
 ,IsReportingEmailDefined  
    )      
   -- ,Assigned_ValueStreamTemplateID      
   -- ,Assigned_ValueStreamCategoryID      
   -- ,Assigned_AssessorTemplateID      
   VALUES (      
    @PlantID      
    ,(      
     SELECT DisplayID      
     FROM [FN_GetNextDisplayID](@PlantID, 'T_TRN_Tag')      
     )      
    ,@TagText       
    ,@IsSingleQuestionSuppressed      
    ,@SuppressedDateRangeFrom      
    ,@SuppressedDateRangeTo      
    ,@IsTargetFrequencyDefined      
    ,@TargetFrequencyTypeID      
    ,@TargetFrequencyValue      
    ,@Tag_PriorityID      
    ,@TagTypeID      
    ,@IsLocked      
    ,@CurrentUserNTID      
    ,@CurrentUserNTID      
    ,@AnonymizeUserDataSettingID      
    ,@IsBranchLogicToBeFollowed      
    ,@IsMandatoryAssessorsDefined      
    ,@IsDeleted      
    ,(      
     SELECT FormattedDateTime      
     FROM fnGetDateTime(@PlantID)      
     )      
    ,(      
     SELECT FormattedDateTime      
     FROM fnGetDateTime(@PlantID)      
     )    
    ,@IsSearchableTag    
 ,@IsSkipQuestionDefined  
 ,@IsQuestionOverviewDefined  
 ,@IsProgressPercentageDefined  
 ,@IsResultOverviewDefined  
 ,@IsResumeTagDefined  
 ,@IsReportingEmailDefined  
    -- ,@Assigned_ValueStreamTemplateID      
    -- ,@Assigned_ValueStreamCategoryID      
    -- ,@Assigned_AssessorTemplateID      
    );      
      
   SET @TagID = SCOPE_IDENTITY();      
      
   SELECT @TableName_Trigger = 'Tag'      
    ,@ActionType = 'I'      
    ,@Input_Ids_Trigger = SCOPE_IDENTITY();      
      
   EXEC [USP_TAG_HISTORY] @PlantID = @PlantID      
    ,@CurrentUserNTID = @CurrentUserNTID      
    ,@TableName = @TableName_Trigger      
    ,@TagHistoryID = @TagHistoryID OUTPUT      
    ,@ActionType = @ActionType      
    ,@INPUT_IDS = @Input_Ids_Trigger;      
      
   DELETE      
   FROM @Scope_Identity_Table_Trigger      
      
   INSERT INTO T_LNK_Tag_AssignedQuestionsTags (      
    TagID      
    ,LinkedTagID      
    )      
   OUTPUT inserted.ID      
   INTO @Scope_Identity_Table_Trigger      
   SELECT @TagID AS TagID      
    ,Tag.value('(TagID/text())[1]', 'int') AS LinkedTagID      
   FROM @AssignedTags.nodes('/ArrayOfTag/Tag') AS TEMPTABLE(Tag)      
      
   /*INSERT INTO T_LNK_Tag_AssignedQuestionsTags (      
    TagID      
    ,QuestionID      
    )      
   OUTPUT inserted.ID      
   INTO @Scope_Identity_Table_Trigger      
   SELECT @TagID AS TagID      
    ,Question.value('(QuestionID/text())[1]', 'int') AS QuestionID      
   FROM @AddedRandomQuestions.nodes('/ArrayOfRandomQuestion/RandomQuestion') AS TEMPTABLE(Question)*/      
   INSERT INTO T_LNK_Tag_AssignedQuestionsTags (      
    TagID      
    ,QuestionID      
    )      
   OUTPUT inserted.ID      
   INTO @Scope_Identity_Table_Trigger      
   SELECT @TagID AS TagID      
    ,Question.value('(QuestionID/text())[1]', 'int') AS QuestionID      
   FROM @AssignedQuestions.nodes('/ArrayOfQuestion/Question') AS TEMPTABLE(Question)      
      
   SELECT @TableName_Trigger = 'AssignedQuestionsTags'      
    ,@ActionType = 'I'      
    ,@Input_Ids_Trigger = (      
     SELECT CAST(id AS VARCHAR(MAX)) + ', '      
     FROM @Scope_Identity_Table_Trigger      
     FOR XML PATH('')      
     );      
      
   EXEC [USP_TAG_HISTORY] @PlantID = @PlantID      
    ,@CurrentUserNTID = @CurrentUserNTID      
    ,@TableName = @TableName_Trigger      
    ,@TagHistoryID = @TagHistoryID      
    ,@ActionType = @ActionType      
    ,@INPUT_IDS = @Input_Ids_Trigger;      
      
   DELETE      
   FROM @Scope_Identity_Table_Trigger      
      
   INSERT INTO T_LNK_Tag_AssignedValueStreams (      
    TagID      
    ,ValueStreamID      
    )      
   OUTPUT inserted.ID      
   INTO @Scope_Identity_Table_Trigger      
   SELECT @TagID AS TagID      
    ,--ATTRIBUTE      
    ValueStream.value('(ValueStreamID/text())[1]', 'int') AS ValueStreamID      
   FROM @ValueStreams.nodes('/ArrayOfValueStream/ValueStream') AS TEMPTABLE(ValueStream)      
      
   SELECT @TableName_Trigger = 'AssignedValueStreams'      
    ,@ActionType = 'I'      
    ,@Input_Ids_Trigger = (      
     SELECT CAST(id AS VARCHAR(MAX)) + ', '      
     FROM @Scope_Identity_Table_Trigger      
     FOR XML PATH('')      
     );      
      
   EXEC [USP_TAG_HISTORY] @PlantID = @PlantID      
    ,@CurrentUserNTID = @CurrentUserNTID        ,@TableName = @TableName_Trigger      
    ,@TagHistoryID = @TagHistoryID      
    ,@ActionType = @ActionType      
    ,@INPUT_IDS = @Input_Ids_Trigger;      
      
   DELETE      
   FROM @Scope_Identity_Table_Trigger      
      
   INSERT INTO T_LNK_Tag_AssignedAssessors (      
    TagID      
    ,AssessorID      
    ,TargetFrequencyTypeID      
    ,TargetFrequencyValue      
    ,IsMandatoryAssessor      
    )      
   OUTPUT inserted.ID      
   INTO @Scope_Identity_Table_Trigger      
   SELECT @TagID AS TagID      
    ,--ATTRIBUTE      
    Assessor.value('(AssessorID/text())[1]', 'int') AS AssessorID      
    ,Assessor.value('(TargetFrequencyTypeID/text())[1]', 'int') AS TargetFrequencyTypeID      
    ,Assessor.value('(TargetFrequencyValue/text())[1]', 'nvarchar(50)') AS TargetFrequencyValue      
    ,Assessor.value('(IsMandatoryAssessor/text())[1]', 'bit') AS IsMandatoryAssessor      
   FROM @Assessors.nodes('/ArrayOfAssessor/Assessor') AS TEMPTABLE(Assessor)      
      
   SELECT @TableName_Trigger = 'AssignedAssessors'      
    ,@ActionType = 'I'      
    ,@Input_Ids_Trigger = (      
     SELECT CAST(id AS VARCHAR(MAX)) + ', '      
     FROM @Scope_Identity_Table_Trigger      
     FOR XML PATH('')      
     );      
      
   EXEC [USP_TAG_HISTORY] @PlantID = @PlantID      
    ,@CurrentUserNTID = @CurrentUserNTID      
    ,@TableName = @TableName_Trigger      
    ,@TagHistoryID = @TagHistoryID      
    ,@ActionType = @ActionType      
    ,@INPUT_IDS = @Input_Ids_Trigger;      
      
   SET @InsertOrUpdated = 1;      
  END      
  ELSE IF (      
    @TagID IS NOT NULL      
    AND EXISTS (      
     SELECT TOP 1 1      
     FROM T_TRN_Tag WITH (NOLOCK)      
     WHERE TagID = @TagID      
      AND PlantID = @PlantID      
     )      
    )      
  BEGIN      
   UPDATE T_TRN_Tag      
   SET TagName = @TagName      
    ,IsSingleQuestionSuppressed = @IsSingleQuestionSuppressed      
    ,SuppressedDateRangeFrom = @SuppressedDateRangeFrom      
    ,SuppressedDateRangeTo = @SuppressedDateRangeTo      
    ,IsTargetFrequencyDefined = @IsTargetFrequencyDefined      
    ,TargetFrequencyTypeID = @TargetFrequencyTypeID      
    ,TargetFrequencyValue = @TargetFrequencyValue      
    ,Tag_PriorityID = @Tag_PriorityID      
    ,TagTypeID = @TagTypeID      
    ,IsLocked = @IsLocked      
    ,ModifiedBy_NTID = @CurrentUserNTID      
    ,AnonymizeUserDataSettingID = @AnonymizeUserDataSettingID      
    ,IsBranchLogicToBeFollowed = @IsBranchLogicToBeFollowed      
    ,IsMandatoryAssessorsDefined = @IsMandatoryAssessorsDefined      
    ,IsDeleted = @IsDeleted      
    ,ModifiedAt = (      
     SELECT FormattedDateTime      
     FROM fnGetDateTime(@PlantID)      
     )     
    ,IsSearchableTag = @IsSearchableTag   
    ,IsSkipQuestionDefined = @IsSkipQuestionDefined  
 ,IsQuestionOverviewDefined = @IsQuestionOverviewDefined  
 ,IsProgressPercentageDefined = @IsProgressPercentageDefined  
 ,IsResultOverviewDefined = @IsResultOverviewDefined  
 ,IsResumeTagDefined = @IsResumeTagDefined  
 ,IsReportingEmailDefined = @IsReportingEmailDefined  
   -- ,Assigned_ValueStreamTemplateID = @Assigned_ValueStreamTemplateID      
   -- ,Assigned_ValueStreamCategoryID = @Assigned_ValueStreamCategoryID      
   -- ,Assigned_AssessorTemplateID = @Assigned_AssessorTemplateID      
   WHERE TagID = @TagID      
    AND PlantID = @PlantID;      
      
   SELECT @TableName_Trigger = 'Tag'      
    ,@ActionType = 'U'      
    ,@Input_Ids_Trigger = @TagID;      
      
   EXEC [USP_TAG_HISTORY] @PlantID = @PlantID      
    ,@CurrentUserNTID = @CurrentUserNTID      
    ,@TableName = @TableName_Trigger      
    ,@TagHistoryID = @TagHistoryID OUTPUT      
    ,@ActionType = @ActionType      
    ,@INPUT_IDS = @Input_Ids_Trigger;      
      
   --for Assigned ValueStreams      
   BEGIN      
    SELECT @TagID AS TagID      
     ,--ATTRIBUTE      
     ValueStream.value('(ID/text())[1]', 'int') AS ID      
     ,Identity(INT, 1, 1) AS RowID      
     ,ValueStream.value('(ValueStreamID/text())[1]', 'int') AS ValueStreamID      
    INTO #ValueStream1      
    FROM @ValueStreams.nodes('/ArrayOfValueStream/ValueStream') AS TEMPTABLE(ValueStream)      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO @Scope_Identity_Table_Trigger      
    SELECT ID      
    FROM T_LNK_Tag_AssignedValueStreams WITH (NOLOCK)      
    WHERE ID NOT IN (      
      SELECT ID      
      FROM #ValueStream1      
      WHERE ID != 0      
       OR ID IS NOT NULL      
      )      
     AND TagID = @TagID;-- removes the deleted valuestreams      
      
    UPDATE T_LNK_Tag_AssignedValueStreams      
    SET IsDeleted = 1      
    WHERE ID IN (      
      SELECT id      
      FROM @Scope_Identity_Table_Trigger      
      ) -- removes the deleted valuestreams;-- removes the deleted valuestreams      
      
    SELECT @TableName_Trigger = 'AssignedValueStreams'      
     ,@ActionType = 'U'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_TAG_HISTORY] @PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID      
     ,@TableName = @TableName_Trigger      
     ,@TagHistoryID = @TagHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger;      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO T_LNK_Tag_AssignedValueStreams (      
     TagID      
     ,ValueStreamID      
     )      
    OUTPUT inserted.ID      
    INTO @Scope_Identity_Table_Trigger      
    SELECT TagID      
     ,ValueStreamID      
    FROM #ValueStream1      
    WHERE (      
      ID IS NULL      
      OR ID = 0      
      )      
      
    SELECT @TableName_Trigger = 'AssignedValueStreams'      
     ,@ActionType = 'I'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_TAG_HISTORY] @PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID      
     ,@TableName = @TableName_Trigger      
     ,@TagHistoryID = @TagHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger;      
      
    SET @min = (      
      SELECT MIN(RowID)      
      FROM #ValueStream1      
      );--Get minimum row number from temp table      
    SET @max = (      
      SELECT Max(RowID)      
      FROM #ValueStream1      
      );--Get maximum row number from temp table      
      
    WHILE (@min <= @max)      
    BEGIN      
     SELECT @TagID = TagID      
      ,@ValueStreamID = ValueStreamID      
      ,@ID = ID      
     FROM #ValueStream1      
     WHERE RowID = @min      
      
     UPDATE T_LNK_Tag_AssignedValueStreams      
     SET ValueStreamID = @ValueStreamID      
     WHERE ID = @ID      
      AND TagID = @TagID      
      
     SELECT @TableName_Trigger = 'AssignedValueStreams'      
  ,@ActionType = 'U'      
      ,@Input_Ids_Trigger = @ID;      
      
     EXEC [USP_TAG_HISTORY] @PlantID = @PlantID      
      ,@CurrentUserNTID = @CurrentUserNTID      
      ,@TableName = @TableName_Trigger      
      ,@TagHistoryID = @TagHistoryID      
      ,@ActionType = @ActionType      
      ,@INPUT_IDS = @Input_Ids_Trigger;      
      
     SET @min = @min + 1 --Increment of current row number      
    END      
   END      
      
   --for Assigned Assessors      
   BEGIN      
    SELECT Assessor.value('(ID/text())[1]', 'int') AS ID      
     ,@TagID AS TagID      
     ,Identity(INT, 1, 1) AS RowID      
     ,Assessor.value('(AssessorID/text())[1]', 'int') AS AssessorID      
     ,Assessor.value('(TargetFrequencyTypeID/text())[1]', 'int') AS TargetFrequencyTypeID      
     ,Assessor.value('(TargetFrequencyValue/text())[1]', 'nvarchar(50)') AS TargetFrequencyValue      
     ,Assessor.value('(IsMandatoryAssessor/text())[1]', 'bit') AS IsMandatoryAssessor      
    INTO #Assessor      
    FROM @Assessors.nodes('/ArrayOfAssessor/Assessor') AS TEMPTABLE(Assessor)      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO @Scope_Identity_Table_Trigger      
    SELECT ID      
    FROM T_LNK_Tag_AssignedAssessors WITH (NOLOCK)      
    WHERE ID NOT IN (      
      SELECT ID      
      FROM #Assessor      
      WHERE ID != 0      
       OR ID IS NOT NULL      
      )      
     AND TagID = @TagID      
      
    UPDATE T_LNK_Tag_AssignedAssessors      
    SET IsDeleted = 1      
    WHERE ID IN (      
      SELECT id      
      FROM @Scope_Identity_Table_Trigger      
      ) -- removes the deleted assessors      
      
    SELECT @TableName_Trigger = 'AssignedValueStreams'      
     ,@ActionType = 'U'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_TAG_HISTORY] @PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID      
     ,@TableName = @TableName_Trigger      
     ,@TagHistoryID = @TagHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger;      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO T_LNK_Tag_AssignedAssessors (      
     TagID      
     ,AssessorID      
     ,TargetFrequencyTypeID      
     ,TargetFrequencyValue      
     ,IsMandatoryAssessor      
     )      
    OUTPUT inserted.ID      
    INTO @Scope_Identity_Table_Trigger      
    SELECT TagID      
     ,AssessorID      
     ,TargetFrequencyTypeID      
     ,TargetFrequencyValue      
     ,IsMandatoryAssessor      
    FROM #Assessor      
    WHERE (      
      ID IS NULL      
      OR ID = 0      
      )      
     AND TagID = @TagID      
      
    SELECT @TableName_Trigger = 'AssignedAssessors'      
     ,@ActionType = 'I'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_TAG_HISTORY] @PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID      
     ,@TableName = @TableName_Trigger      
     ,@TagHistoryID = @TagHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger;      
      
    SET @min = (      
      SELECT MIN(RowID)      
      FROM #Assessor      
      );--Get minimum row number from temp table      
    SET @max = (      
      SELECT Max(RowID)      
      FROM #Assessor      
      );--Get maximum row number from temp table      
      
    WHILE (@min <= @max)      
    BEGIN      
     SELECT @TagID = TagID      
      ,@AssessorID = AssessorID      
      ,@TargetFrequencyTypeID = TargetFrequencyTypeID      
      ,@ID = ID      
      ,@TargetFrequencyValue = TargetFrequencyValue      
      ,@IsMandatoryAssessor = IsMandatoryAssessor      
     FROM #Assessor      
     WHERE RowID = @min      
      
     UPDATE T_LNK_Tag_AssignedAssessors      
     SET TagID = @TagID      
      ,AssessorID = @AssessorID      
      ,TargetFrequencyTypeID = @TargetFrequencyTypeID      
      ,IsMandatoryAssessor = @IsMandatoryAssessor      
      ,TargetFrequencyValue = @TargetFrequencyValue      
     WHERE ID = @ID      
      AND TagID = @TagID      
      
     SELECT @TableName_Trigger = 'AssignedAssessors'      
      ,@ActionType = 'U'      
      ,@Input_Ids_Trigger = @ID;      
      
     EXEC [USP_TAG_HISTORY] @PlantID = @PlantID      
      ,@CurrentUserNTID = @CurrentUserNTID      
      ,@TableName = @TableName_Trigger      
      ,@TagHistoryID = @TagHistoryID      
      ,@ActionType = @ActionType      
      ,@INPUT_IDS = @Input_Ids_Trigger;      
      
     SET @min = @min + 1 --Increment of current row number      
    END      
   END      
      
   --for Assigned Questions      
   BEGIN      
    SELECT @TagID AS TagID      
     ,--ATTRIBUTE      
     Identity(INT, 1, 1) AS ID      
     ,Question.value('(QuestionID/text())[1]', 'int') AS QuestionID      
    INTO #Q1      
    FROM @AssignedQuestions.nodes('/ArrayOfQuestion/Question') AS TEMPTABLE(Question)      
      
    --for Assigned Tags      
    SELECT @TagID AS TagID      
     ,Identity(INT, 1, 1) AS ID      
     ,Tag.value('(TagID/text())[1]', 'int') AS LinkedTagID      
    INTO #Tag1      
    FROM @AssignedTags.nodes('/ArrayOfTag/Tag') AS TEMPTABLE(Tag)      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO @Scope_Identity_Table_Trigger      
    SELECT ID      
    FROM T_LNK_Tag_AssignedQuestionsTags WITH (NOLOCK)      
    WHERE (      
      QuestionID NOT IN (      
       SELECT QuestionID      
       FROM #Q1      
       )      
      )      
     AND LinkedTagID IS NULL      
     AND TagID = @TagID;      
      
    UPDATE T_LNK_Tag_AssignedQuestionsTags      
    SET IsDeleted = 1      
    WHERE ID IN (      
      SELECT id      
      FROM @Scope_Identity_Table_Trigger      
      );-- removes the deleted questions/tags(soft delete)      
      
    SELECT @TableName_Trigger = 'AssignedQuestionsTags'      
     ,@ActionType = 'U'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_TAG_HISTORY] @PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID      
     ,@TableName = @TableName_Trigger      
     ,@TagHistoryID = @TagHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger;      
      
    --IF @TagTypeID = 1      
    BEGIN      
     --Update AssignedTags questions as deleted which are removed in tag screen      
     DELETE      
     FROM @Scope_Identity_Table_Trigger      
      
     INSERT INTO @Scope_Identity_Table_Trigger      
     SELECT ID      
     FROM T_LNK_QN_AssignedTags WITH (NOLOCK)      
     WHERE (      
       QuestionID NOT IN (      
        SELECT QuestionID      
        FROM #Q1      
        )      
       )      
      AND TagID = @TagID      
      
     UPDATE T_LNK_QN_AssignedTags      
     SET IsDeleted = 1      
     WHERE ID IN (      
       SELECT id      
       FROM @Scope_Identity_Table_Trigger      
       )      
      
     SELECT @TableName_Trigger = 'AssignedTags'      
      ,@ActionType = 'U'      
      ,@Input_Ids_Trigger = (      
       SELECT CAST(id AS VARCHAR(MAX)) + ', '      
       FROM @Scope_Identity_Table_Trigger      
       FOR XML PATH('')      
       );      
      
     EXEC [USP_TAG_HISTORY] @PlantID = @PlantID      
      ,@CurrentUserNTID = @CurrentUserNTID      
      ,@TableName = @TableName_Trigger      
      ,@TagHistoryID = @TagHistoryID      
      ,@ActionType = @ActionType      
      ,@INPUT_IDS = @Input_Ids_Trigger;      
      
     ----Insert AssignedTags questions which are added in tag screen      
     DELETE      
     FROM @Scope_Identity_Table_Trigger      
      
     INSERT INTO T_LNK_QN_AssignedTags (      
      QuestionID            ,TagID      
      )      
     OUTPUT inserted.ID      
     INTO @Scope_Identity_Table_Trigger      
     SELECT QuestionID      
      ,@TagID AS TagID      
     FROM #Q1      
     WHERE (      
       QuestionID NOT IN (      
        SELECT QuestionID      
        FROM T_LNK_QN_AssignedTags WITH (NOLOCK)      
        WHERE TagID = @TagID      
         AND IsDeleted = 0      
        )      
       )      
      
     SELECT @TableName_Trigger = 'AssignedTags'      
      ,@ActionType = 'I'      
      ,@Input_Ids_Trigger = (      
       SELECT CAST(id AS VARCHAR(MAX)) + ', '      
       FROM @Scope_Identity_Table_Trigger      
       FOR XML PATH('')      
       );      
      
     EXEC [USP_TAG_HISTORY] @PlantID = @PlantID      
      ,@CurrentUserNTID = @CurrentUserNTID      
      ,@TableName = @TableName_Trigger      
      ,@TagHistoryID = @TagHistoryID      
      ,@ActionType = @ActionType      
      ,@INPUT_IDS = @Input_Ids_Trigger;      
    END      
      
    DELETE      
    FROM @Scope_Identity_Table_Trigger      
      
    INSERT INTO @Scope_Identity_Table_Trigger      
    SELECT ID      
    FROM T_LNK_Tag_AssignedQuestionsTags WITH (NOLOCK)      
    WHERE LinkedTagID NOT IN (      
      SELECT LinkedTagID      
      FROM #Tag1      
      )      
     AND QuestionID IS NULL      
     AND IsDeleted = 0      
     AND TagID = @TagID      
      
    UPDATE T_LNK_Tag_AssignedQuestionsTags      
    SET IsDeleted = 1      
    WHERE ID IN (      
      SELECT id      
      FROM @Scope_Identity_Table_Trigger      
      );-- removes the deleted questions/tags(soft delete)      
      
    SELECT @TableName_Trigger = 'AssignedQuestionsTags'      
     ,@ActionType = 'U'      
     ,@Input_Ids_Trigger = (      
      SELECT CAST(id AS VARCHAR(MAX)) + ', '      
      FROM @Scope_Identity_Table_Trigger      
      FOR XML PATH('')      
      );      
      
    EXEC [USP_TAG_HISTORY] @PlantID = @PlantID      
     ,@CurrentUserNTID = @CurrentUserNTID      
     ,@TableName = @TableName_Trigger      
     ,@TagHistoryID = @TagHistoryID      
     ,@ActionType = @ActionType      
     ,@INPUT_IDS = @Input_Ids_Trigger;      
      
    --for updating Questions      
    SET @min = (      
      SELECT MIN(ID)      
      FROM #Q1      
      );--Get minimum row number from temp table      
    SET @max = (      
      SELECT Max(ID)      
    FROM #Q1      
      );--Get maximum row number from temp table      
      
    WHILE (@min <= @max)      
    BEGIN      
     SELECT @TagID = TagID      
      ,@QuestionID = QuestionID      
     FROM #Q1      
     WHERE ID = @min      
      
     IF NOT EXISTS (      
       SELECT 1      
       FROM T_LNK_Tag_AssignedQuestionsTags WITH (NOLOCK)      
       WHERE QuestionID = @QuestionID      
        AND TagID = @TagID      
        AND IsDeleted = 0      
       )      
     BEGIN      
      INSERT INTO T_LNK_Tag_AssignedQuestionsTags (      
       TagID      
       ,QuestionID      
       )      
      VALUES (      
       @TagID      
       ,@QuestionID      
       )      
      
      SELECT @TableName_Trigger = 'AssignedQuestionsTags'      
       ,@ActionType = 'I'      
       ,@Input_Ids_Trigger = SCOPE_IDENTITY();      
      
      EXEC [USP_TAG_HISTORY] @PlantID = @PlantID      
       ,@CurrentUserNTID = @CurrentUserNTID      
       ,@TableName = @TableName_Trigger      
       ,@TagHistoryID = @TagHistoryID      
       ,@ActionType = @ActionType      
       ,@INPUT_IDS = @Input_Ids_Trigger;      
     END      
      
     SET @min = @min + 1 --Increment of current row number      
    END      
      
    ----      
    --for updating Tags      
    SET @min = (      
      SELECT MIN(ID)      
      FROM #Tag1      
      );--Get minimum row number from temp table      
    SET @max = (      
      SELECT Max(ID)      
      FROM #Tag1      
      );--Get maximum row number from temp table      
      
    WHILE (@min <= @max)      
    BEGIN      
     SELECT @TagID = TagID      
      ,@LinkedTagID = LinkedTagID      
     FROM #Tag1      
     WHERE ID = @min      
      
     IF NOT EXISTS (      
       SELECT 1      
       FROM T_LNK_Tag_AssignedQuestionsTags WITH (NOLOCK)      
       WHERE LinkedTagID = @LinkedTagID          AND TagID = @TagID      
        AND IsDeleted = 0      
       )      
     BEGIN      
      INSERT INTO T_LNK_Tag_AssignedQuestionsTags (      
       TagID      
       ,LinkedTagID      
       )      
      VALUES (      
       @TagID      
       ,@LinkedTagID      
       )      
      
      SELECT @TableName_Trigger = 'AssignedQuestionsTags'      
       ,@ActionType = 'I'      
       ,@Input_Ids_Trigger = SCOPE_IDENTITY();      
      
      EXEC [USP_TAG_HISTORY] @PlantID = @PlantID      
       ,@CurrentUserNTID = @CurrentUserNTID      
       ,@TableName = @TableName_Trigger      
       ,@TagHistoryID = @TagHistoryID      
       ,@ActionType = @ActionType      
       ,@INPUT_IDS = @Input_Ids_Trigger;      
     END      
      
     SET @min = @min + 1 --Increment of current row number      
    END      
   END      
      
   DECLARE @TagModeID INT;      
      
   SELECT *      
   INTO #TmpT_LNK_TagMode_Tags      
   FROM (      
    SELECT ROW_NUMBER() OVER (      
      ORDER BY TagModeTagsID      
      ) AS RowNum      
     ,*      
    FROM [T_LNK_TagMode_Tags] WITH (NOLOCK)      
    WHERE TagID = @TagID      
     AND (IsDeleted = 0)      
    ) AS t      
      
   IF EXISTS (      
     SELECT 1      
     FROM #TmpT_LNK_TagMode_Tags      
     )      
   BEGIN      
    SET @min = (      
      SELECT Min(RowNum)      
      FROM #TmpT_LNK_TagMode_Tags      
      );--Get minimum row number from temp table      
    SET @max = (      
      SELECT Max(RowNum)      
      FROM #TmpT_LNK_TagMode_Tags      
      );--Get maximum row number from temp table      
      
    WHILE (@min <= @max)      
    BEGIN      
     SET @TagModeID = (      
       SELECT TagModeID      
       FROM #TmpT_LNK_TagMode_Tags      
       WHERE RowNum = @min      
       )      
      
     DELETE      
     FROM [T_LNK_TagMode_Questions]      
     WHERE TagModeID = @TagModeID      
      
     EXEC USP_AddQuestionsByTagModeID @PlantID      
      ,@TagModeID      
      ,@CurrentUserNTID;      
      
     SET @min = @min + 1 --Increment of current row number      
    END      
   END      
      
   DECLARE @CustomModeID INT;      
   DECLARE @CustomQuestionTagsID INT;      
      
   SELECT *      
   INTO #TmpT_LNK_Custom_QuestionsTags      
   FROM (      
    SELECT ROW_NUMBER() OVER (      
      ORDER BY CustomQuestionTagsID      
      ) AS RowNum      
     ,*      
    FROM T_LNK_Custom_QuestionsTags WITH (NOLOCK)      
    WHERE TagID = @TagID      
     AND (IsDeleted = 0)      
 ) AS t      
      
   IF EXISTS (      
     SELECT 1      
     FROM #TmpT_LNK_Custom_QuestionsTags      
     )      
   BEGIN      
    SET @min = (      
      SELECT Min(RowNum)      
      FROM #TmpT_LNK_Custom_QuestionsTags      
      );--Get minimum row number from temp table      
    SET @max = (      
      SELECT Max(RowNum)      
      FROM #TmpT_LNK_Custom_QuestionsTags      
      );--Get maximum row number from temp table      
      
    WHILE (@min <= @max)      
    BEGIN      
     SET @CustomModeID = (      
       SELECT CustomModeID      
       FROM #TmpT_LNK_Custom_QuestionsTags      
       WHERE RowNum = @min      
       )      
     SET @CustomQuestionTagsID = (      
       SELECT CustomQuestionTagsID      
       FROM #TmpT_LNK_Custom_QuestionsTags      
       WHERE RowNum = @min      
       )      
      
     DELETE      
     FROM T_LNK_Custom_QuestionsTags      
     WHERE CustomQuestionTagsID = @CustomQuestionTagsID      
      
     DELETE      
     FROM T_LNK_Custom_Questions      
     WHERE CustomQuestionTagsID = @CustomQuestionTagsID      
      
     EXEC USP_AddQuestionsByCustomModeID @PlantID      
      ,@CustomModeID      
      ,@TagID      
      ,@CurrentUserNTID;      
      
     SET @min = @min + 1 --Increment of current row number      
    END      
   END      
      
   EXEC [USP_UpdateAuditAnsweredQuestionsByTagID] @PlantID      
    ,@TagID      
    ,@CurrentUserNTID;      
      
 EXEC [USP_UpdateAuditAssessorsbyTagID] @plantID,  
 @TagID  
 ,@CurrentUserNTID  
 ,@Assessors  
  
   SET @InsertOrUpdated = 1;      
  END      
      
  IF (      
    @IsMandatoryAssessorsDefined = 0      
    AND @InsertOrUpdated = 1      
    )      
  BEGIN      
   UPDATE [T_LNK_Tag_AssignedAssessors]      
   SET IsMandatoryAssessor = 0      
   WHERE TagID = @TagID      
      
   DELETE      
   FROM @Scope_Identity_Table_Trigger      
      
   INSERT INTO @Scope_Identity_Table_Trigger      
   SELECT ID      
   FROM [T_LNK_Tag_AssignedAssessors] WITH (NOLOCK)      
   WHERE TagID = @TagID      
      
   SELECT @TableName_Trigger = 'AssignedAssessors'      
    ,@ActionType = 'U'      
    ,@Input_Ids_Trigger = (      
     SELECT CAST(id AS VARCHAR(MAX)) + ', '      
     FROM @Scope_Identity_Table_Trigger      
     FOR XML PATH('')      
     );      
      
   EXEC [USP_TAG_HISTORY] @PlantID = @PlantID      
    ,@CurrentUserNTID = @CurrentUserNTID      
    ,@TableName = @TableName_Trigger      
    ,@TagHistoryID = @TagHistoryID      
    ,@ActionType = @ActionType      
    ,@INPUT_IDS = @Input_Ids_Trigger;      
  END      
      
  ----to avoid entries from Lock settings update, it is enabled/disabled       
  SELECT TagID      
   ,PlantID      
   ,TagDisplayID      
   ,TagName      
   ,IsSingleQuestionSuppressed      
   ,SuppressedDateRangeFrom      
   ,SuppressedDateRangeTo      
   ,IsTargetFrequencyDefined      
   ,TargetFrequencyTypeID      
   ,TargetFrequencyValue      
   ,Tag_PriorityID      
   ,TagTypeID      
   ,IsLocked      
   ,AnonymizeUserDataSettingID      
   ,IsBranchLogicToBeFollowed      
   ,IsMandatoryAssessorsDefined      
   ,IsDeleted      
   ,CreatedAt      
   ,ModifiedAt      
   ,CreatedBy_NTID      
   ,ModifiedBy_NTID      
   ,IsSearchableTag    
   ,IsSkipQuestionDefined  
   ,IsQuestionOverviewDefined  
   ,IsProgressPercentageDefined  
   ,IsResultOverviewDefined  
   ,IsResumeTagDefined  
   ,IsReportingEmailDefined  
  -- ,Assigned_ValueStreamTemplateID      
  -- ,Assigned_ValueStreamCategoryID      
  -- ,Assigned_AssessorTemplateID      
  FROM T_TRN_Tag WITH (NOLOCK)      
  WHERE TagID = @TagID      
   AND PlantID = @PlantID;      
      
       
 IF @isSaveTag = 1      
 BEGIN      
  set @Save = 1      
 END      
  --branch logic changes      
 IF @Save = 1      
 BEGIN      
  DELETE      
  FROM T_LNK_Tag_AssignedQuestionsTags      
  WHERE tagid = @tagid      
   AND LinkedTagID IS NULL       
      
  --UPDATE T_LNK_Tag_AssignedQuestionsTags      
  --SET RandomQuestionOrder = 1000      
  --WHERE tagid = @tagid      
  -- AND QuestionId IS NULL        
      
  --update T_LNK_Tag_AssignedQuestionsTags set IsDeleted=1 where tagid=@TagID      
  --SELECT distinct QuestionID into #NestedTagQuestions FROM [FN_GetNestedQuestionsByTagID](@tagid,@PlantID)      
       
   INSERT INTO T_LNK_Tag_AssignedQuestionsTags (      
   TagID      
   ,QuestionID      
   ,RandomQuestionOrder      
   ,QuestionType      
   )      
  OUTPUT inserted.ID      
  INTO @Scope_Identity_Table_Trigger      
  SELECT @TagID AS TagID      
   ,FinalQuestionOrder.value('(QuestionID/text())[1]', 'int') AS QuestionId      
   ,FinalQuestionOrder.value('(QuestionIndex/text())[1]', 'int') AS QuestionIndex      
   ,FinalQuestionOrder.value('(QuestionType/text())[1]', 'int') AS QuestionType      
  FROM @FinalQuestionOrder.nodes('/ArrayOfRandomQuestion/RandomQuestion') AS TEMPTABLE1(FinalQuestionOrder)      
 --delete from T_LNK_Tag_AssignedQuestionsTags where tagid=@tagid and linkedtagid=0       
      
 -- SELECT DISTINCT QuestionID      
 -- INTO #nestedtagQuestionIDs      
 -- FROM [FN_GetNestedQuestionsByTagID](@tagid, @PlantID)      
      
 -- DECLARE @count INT;      
      
 -- SELECT @count = (      
 --   SELECT count(*)      
 --   FROM #nestedtagQuestionIDs      
 --   ) - (      
 --   SELECT count(*)      
 --   FROM T_LNK_Tag_AssignedQuestionsTags      
 --   WHERE tagid = @tagid      
 --    AND QuestionID IS NOT NULL AND Isdeleted=0       
 --   )      
      
 -- SELECT @count      
      
 -- DECLARE @i INT = 0      
      
 -- WHILE @i < @count      
 -- BEGIN      
 --  SET @i = @i + 1      
      
 --  INSERT INTO T_LNK_Tag_AssignedQuestionsTags (      
 --   tagid      
 --   ,QuestionID      
 --   ,LinkedTagID      
 --   ,IsDeleted      
 --   ,RandomQuestionOrder      
 --   )      
 --  VALUES (      
 --   @tagid      
 --   ,(      
 --    SELECT TOP 1 Questionid      
 --    FROM #nestedtagQuestionIDs      
 --    WHERE QuestionId NOT IN (      
 --      SELECT QuestionID      
 --      FROM T_LNK_Tag_AssignedQuestionsTags      
 --      WHERE tagid = @tagid      
 --       AND QuestionID IS NOT NULL      
 --      )      
 --    )      
 --   ,NULL      
 --   ,0      
 --   ,999      
 --   )      
 -- END      
 END      
 IF @Save =0      
 BEGIN      
 update T_LNK_Tag_AssignedQuestionsTags set RandomQuestionOrder=0 where tagid=@TagID      
 END      
 SET @Counter = @Counter + 1      
  SET @TagID = null      
  CONTINUE      
  END      
  COMMIT TRANSACTION TRNADDEDITTAG;      
 END TRY      
      
 BEGIN CATCH      
  ROLLBACK TRANSACTION TRNADDEDITTAG;      
      
  EXEC USP_LogError @PlantID      
   ,@CurrentUserNTID;      
 END CATCH      
END      
 GO   