/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_HintImagesByAuditDeviationID] 
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING HINT IMMAGES BY AUDIT DEVIATION ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			Rajasekar S					PlantId,CurrentUserNTID added

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_HintImagesByAuditDeviationID] 1
*/
CREATE PROCEDURE [USP_HintImagesByAuditDeviationID] @PlantID INT
	,@AuditDeviationID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	SET NOCOUNT ON;

	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = 0
		,@Mode = 'AUDIT'
		,@CurrentUserNTID = @CurrentUserNTID

	SELECT ADA.DeviationAttachmentsID
		,ADA.AuditDeviationID
		,ADA.ImagePath
		,ADA.ImageTitle
		,ADA.FileContent AS ByteData
		,ADA.DisplayFileName
	FROM [T_TRN_AuditDeviationAttachments] ADA WITH (NOLOCK)
	INNER JOIN T_TRN_Question Q WITH (NOLOCK) ON Q.QuestionID = ADA.QuestionID
	WHERE ADA.AuditDeviationID = @AuditDeviationID
		AND Q.PlantID = @PlantID
		AND (ADA.IsDeleted = 0)
END
GO


