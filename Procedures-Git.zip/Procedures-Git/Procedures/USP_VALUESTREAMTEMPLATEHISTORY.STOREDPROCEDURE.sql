/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_ValueStreamTemplateHistory]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING VALUESTREAM TEMPLATE HISTORY
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					18-MAR-2021			Rajasekar S					PlantId, DisplayId, 'set NOCOUNT ON' added. * expanded

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_ValueStreamTemplateHistory] 1
*/
CREATE PROCEDURE [USP_ValueStreamTemplateHistory] @ValueStreamTemplateID INT
	,@PlantID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = @ValueStreamTemplateID
		,@Mode = 'VALUESTREAMTEMPLATE'
		,@CurrentUserNTID = @CurrentUserNTID

	SET NOCOUNT ON;

	SELECT VH.ValueStreamTemplateHistoryID
		,VH.ValueStreamTemplateHistoryDisplayID
		,VH.ValueStreamTemplateID
		,VH.ModifiedBy_NTID
		,(TU.UserName) AS ModifiedBy
		,VH.ValueStreamTemplateName
		,VH.ModifiedAt
		,VH.CreatedAt
	FROM [T_HST_ValueStreamTemplateHistory] VH WITH (NOLOCK)
	INNER JOIN T_MST_User TU WITH (NOLOCK) ON VH.ModifiedBy_NTID = TU.NTID
	WHERE VH.PlantID = @PlantID
		AND ValueStreamTemplateID = @ValueStreamTemplateID
		AND TU.PlantID = @PlantID
	ORDER BY VH.ValueStreamTemplateHistoryDisplayID DESC;
END
GO

