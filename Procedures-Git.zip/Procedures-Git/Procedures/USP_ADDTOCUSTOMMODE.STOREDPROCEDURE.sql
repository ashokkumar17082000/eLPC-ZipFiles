/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_AddToCustomMode]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR ADDING CUSTOM MODE
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_AddToCustomMode] 'OSP4KOR', 1
*/
CREATE PROCEDURE [USP_AddToCustomMode] @QuestionID INT
	,@PlantID INT
	,@CurrentUserNTID NVARCHAR(20) NULL
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION TRNADDTOCUSTOM

		DECLARE @CustomModeID INT;
		DECLARE @CreatedAt DATETIME;

		SET @CreatedAt = (
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				);
		SET @CustomModeID = (
				SELECT CustomModeID
				FROM [T_TRN_CustomMode] WITH(NOLOCK)
				WHERE CreatedBy_NTID = @CurrentUserNTID
					AND PlantID = @PlantID
				)

		IF NOT EXISTS (
				SELECT CustomModeID
				FROM [T_TRN_CustomMode] WITH(NOLOCK)
				WHERE CreatedBy_NTID = @CurrentUserNTID
					AND PlantID = @PlantID
				) --when there is no any records in custom mode and trying to add questions from shuffle mode
		BEGIN
			INSERT INTO T_TRN_CustomMode (
				CreatedAt
				,CreatedBy_NTID
				,PlantID
				)
			VALUES (
				@CreatedAt
				,@CurrentUserNTID
				,@PlantID
				)

			SET @CustomModeID = scope_Identity();
		END

		DECLARE @customQuestionTagsID INT = (
				SELECT CustomQuestionTagsID
				FROM [T_LNK_Custom_QuestionsTags] WITH(NOLOCK)
				WHERE QuestionID = @QuestionID
					AND CustomModeID = @CustomModeID
				);

		IF (@customQuestionTagsID IS NOT NULL)
		BEGIN
			UPDATE [T_LNK_Custom_QuestionsTags]
			SET IsDeleted = 0
			WHERE QuestionID = @QuestionID
				AND CustomModeID = @CustomModeID

			UPDATE [T_LNK_Custom_Questions]
			SET IsDeleted = 0
				,IsCustomMode = 1
			WHERE CustomQuestionTagsID = @customQuestionTagsID
				AND CustomModeID = @CustomModeID
		END
		ELSE
		BEGIN
			INSERT INTO [T_LNK_Custom_QuestionsTags] (
				CustomModeID
				,QuestionID
				)
			VALUES (
				@CustomModeID
				,@QuestionID
				)

			SET @CustomQuestionTagsID = SCOPE_IDENTITY();

			DECLARE @tmpAnswerTypeID INT = (
					SELECT AnswerType_AnswerTypeID
					FROM [T_TRN_Question] WITH(NOLOCK)
					WHERE QuestionID = @QuestionID
						AND PlantID = @PlantID
					)

			INSERT INTO [T_LNK_Custom_Questions] (
				CustomModeID
				,QuestionID
				,AnswerTypeID
				,IsCustomMode
				,CustomQuestionTagsID
				)
			VALUES (
				@CustomModeID
				,@QuestionID
				,@tmpAnswerTypeID
				,1
				,@CustomQuestionTagsID
				)
		END

		COMMIT TRANSACTION TRNADDTOCUSTOM;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNADDTOCUSTOM;

		EXEC [USP_LogError] @PlantID
			,@CurrentUserNTID;
	END CATCH
END
GO


