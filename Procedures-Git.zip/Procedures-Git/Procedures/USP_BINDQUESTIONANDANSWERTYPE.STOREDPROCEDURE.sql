/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_BindQuestionAndAnswerType]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE TO BIND QUESTION AND ANSWER TYPE
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					27-MAR-2021			VENKATESH GOVINDARAJ		PLANTID & CODE CLEANUP
ELPC_LH_002_CR05			06-Dec-2021			VENKATESH GOVINDARAJ		QUESTION ORDER BY LOGIC CHANGED 
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
EXEC uatgrp2.USP_BindQuestionAndAnswerType @ValueStreamID=0,@AssessorID=0,@NTID=N'FSM1COB',@PlantID=5,@CurrentUserNTID=N'FSM1COB',@AnsweredAndSkippedQueestionIDs='',@SessionID =''
*/
CREATE PROCEDURE [USP_BindQuestionAndAnswerType] @ValueStreamID INT
	,@AssessorID INT
	,@NTID NVARCHAR(20)
	,@PlantID INT
	,@CurrentUserNTID NVARCHAR(20) NULL
	,@SelectedQuestionID INT = 0
	,@AnsweredAndSkippedQueestionIDs XML NULL
	,@SessionID NVARCHAR(MAX) NULL
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @RowExists BIT = 0;
	DECLARE @ValidRows BIT = 0;
--insert into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('40_(1_Shuffle)',@PlantID,@CurrentUserNTID, getdate(),1)

	-- Starts ****** Combing & forming VS & AS for filtering Questions belongs to available combination *****************
	SELECT *
	INTO #VSASCombination
	FROM (
		SELECT vsc.ValueStreamTemplateID
			,vsc.ValueStreamID
			,ac.AssessorTemplateID
			,ac.AssessorID
			,vsc.IsForgotValueStream
			,ac.IsForgotAssessor
			,vsc.SessionID AS VSSessionID
			,ac.SessionID AS ASSessionID
		FROM [T_TRN_ValueStreamConfig] vsc WITH (NOLOCK)
		CROSS JOIN [T_TRN_AssessorConfig] ac WITH (NOLOCK)
		WHERE vsc.IsDeleted = 0
			AND ac.IsDeleted = 0
			AND vsc.PlantID = @PlantID
			AND ac.PlantID = @PlantID
			AND vsc.User_NTID = @CurrentUserNTID
			AND ac.User_NTID = @CurrentUserNTID
			AND vsc.ValueStreamID IN (
				SELECT c.ValueStreamID
				FROM [T_TRN_ValueStreamConfig] c WITH (NOLOCK)
				INNER JOIN T_TRN_ValueStreamTemplate vst WITH (NOLOCK) ON vst.PlantID = @PlantID
					AND vst.ValueStreamTemplateID = c.ValueStreamTemplateID
					AND vst.IsDeleted = 0
				INNER JOIN T_TRN_ValueStream vs WITH (NOLOCK) ON vs.ValueStreamID = c.ValueStreamID
					AND vs.IsDeleted = 0
				INNER JOIN T_TRN_ValueStreamCategory cat WITH (NOLOCK) ON c.ValueStreamTemplateID = cat.ValueStreamTemplateID
					AND cat.IsDeleted = 0
				WHERE c.PlantID = @PlantID
					AND c.User_NTID = @CurrentUserNTID
					AND c.IsDeleted = 0
				)
			AND ac.AssessorID IN (
				SELECT DISTINCT c.AssessorID
				FROM T_TRN_AssessorConfig c WITH (NOLOCK)
				INNER JOIN T_TRN_AssessorTemplate ast WITH (NOLOCK) ON ast.PlantID = @PlantID
					AND ast.AssessorTemplateID = c.AssessorTemplateID
					AND ast.IsDeleted = 0
				INNER JOIN T_TRN_Assessor a WITH (NOLOCK) ON a.AssessorID = c.AssessorID
					AND a.IsDeleted = 0
				WHERE c.PlantID = @PlantID
					AND c.User_NTID = @CurrentUserNTID
					AND c.IsDeleted = 0
				)
		) AS VSASCombination
	-- Ends ****** Combing & forming VS & AS for filtering Questions belongs to available combination *****************
	
	-- Check Rows exists or not in profile
	IF EXISTS (
			SELECT TOP 1 1
			FROM #VSASCombination WITH (NOLOCK)
			)
	BEGIN
		SET @RowExists = 1
	END

	-- Check Rows are Valid in Profile
	IF NOT EXISTS (
			SELECT TOP 1 1
			FROM #VSASCombination WITH (NOLOCK)
			WHERE (
					(
						IsForgotValueStream = 1
						AND VSSessionID IS NOT NULL
						AND VSSessionID <> @SessionID
						)
					OR (
						IsForgotAssessor = 1
						AND ASSessionID IS NOT NULL
						AND ASSessionID <> @SessionID
						)
					)
			)
	BEGIN
		SET @ValidRows = 1
	END
	--insert into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('120_(2_Shuffle)',@PlantID,@CurrentUserNTID, getdate(),1)

	-- Question Fetch logic 
	IF (
			@RowExists = 1
			AND @ValidRows = 1
			)
	BEGIN
		BEGIN TRY
			BEGIN TRANSACTION BINDQUESTIONANDANSWERTYPE

			SELECT *
			INTO #AnsweredAndSkippedQueestionIDs
			FROM (
				SELECT AnsweredAndSkippedQueestionIDs.value('.', 'int') AS QuestionID
				FROM @AnsweredAndSkippedQueestionIDs.nodes('/ArrayOfInt/int') AS TEMPTABLE(AnsweredAndSkippedQueestionIDs)
				) AS AnsweredAndSkippedQueestionIDs

			-- Starts ****** Preparing Questionlist by applying VS & AS available combination *****************
			SELECT *
			INTO #FilteredQuestion
			FROM (
				SELECT Q.QuestionID
					,VS.ValueStreamTemplateID
					,LVS.ValueStreamID
					,A.AssessorTemplateID
					,LAS.AssessorID
					,VSAS.IsForgotValueStream
					,VSAS.IsForgotAssessor
					,VSAS.VSSessionID
					,VSAS.ASSessionID
					,DS.AnswerCount
					,DS.NegativeAnswerCount
					,(select FullFilmentPercentage from [FN_GetTargetFreqPercentage](@PlantID, Q.QuestionID, LVS.ValueStreamID)) As TargetPercentage
				FROM  #VSASCombination VSAS WITH (NOLOCK) 
				INNER JOIN T_LNK_AssignedValueStreams LVS WITH (NOLOCK) ON VSAS.ValueStreamID = LVS.ValueStreamID
					AND LVS.IsDeleted = 0
				INNER JOIN T_LNK_AssignedAssessors LAS WITH (NOLOCK) ON VSAS.AssessorID = LAS.AssessorID
					AND LAS.IsDeleted = 0
					AND LVS.QuestionID = LAS.QuestionID
				INNER JOIN T_TRN_ValueStream VS WITH (NOLOCK) ON VS.ValueStreamID = LVS.ValueStreamID 
					AND VSAS.ValueStreamTemplateID = VS.ValueStreamTemplateID
					AND VS.IsDeleted = 0
				INNER JOIN T_TRN_Assessor A WITH (NOLOCK) ON A.AssessorID = LAS.AssessorID
					AND VSAS.AssessorTemplateID = A.AssessorTemplateID
					AND A.IsDeleted = 0
				INNER JOIN T_TRN_Question Q WITH (NOLOCK) ON Q.QuestionID = LVS.QuestionID
					AND Q.PlantID = @PlantID
					AND Q.QuestionID NOT IN (
						SELECT QuestionID
						FROM #AnsweredAndSkippedQueestionIDs
						)
					AND Q.QuestionID = IIF(@SelectedQuestionID = 0, Q.QuestionID, @SelectedQuestionID)
					AND Q.IsDeleted = 0
					AND (
						(Q.IsQuestionAlwaysActive = 1)
						OR (
							Q.IsQuestionAlwaysActive = 0
							AND (
								CAST((
										SELECT FormattedDateTime
										FROM fnGetDateTime(@PlantID)
										) AS DATE) >= CAST(Q.ActiveDateRangeFrom AS DATE)
								)
							AND (
								CAST((
										SELECT FormattedDateTime
										FROM fnGetDateTime(@PlantID)
										) AS DATE) <= CAST(Q.ActiveDateRangeTo AS DATE)
								)
							)
						)
					LEFT JOIN T_TRN_DataPool_Summary DS WITH (NOLOCK) ON DS.QuestionID = Q.QuestionID
								AND DS.ValueStreamID = LVS.ValueStreamID
					ORDER BY TargetPercentage ASC,
						 Q.Question_PriorityID ASC
						,IIF(ISNULL(Q.TargetFrequencyTypeID, 0) > 0 ,Q.TargetFrequencyTypeID ,99) ASC
						,Q.TargetFrequencyValue DESC
						,DS.AnswerCount ASC
						,DS.NegativeAnswerCount DESC
						,NEWID()
					OFFSET 0 ROWS 
				) AS QuestionList
--insert into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('203_(3_Shuffle)',@PlantID,@CurrentUserNTID, getdate(),1)

			--select * from #FilteredQuestion
			-- Ends ****** Filter the question in sorted order *****************
			-- Starts ****** Identifying the custome mode questions *****************
			DECLARE @CustomModeID INT;
			DECLARE @myCustomTableVariable TABLE (QuestionID INT)

			SET @CustomModeID = (
					SELECT CustomModeID
					FROM [T_TRN_CustomMode] WITH (NOLOCK)
					WHERE CreatedBy_NTID = @NTID
						AND PlantID = @PlantID
					);

			INSERT INTO @myCustomTableVariable (QuestionID)
			SELECT QuestionID
			FROM (
				SELECT QuestionID
				FROM [T_LNK_Custom_Questions] WITH (NOLOCK)
				WHERE CustomModeID = @CustomModeID
					AND IsCustomMode = 1
					AND IsDeleted = 0
				) AS tmpCusttbl
--insert into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('227_(4_Shuffle)',@PlantID,@CurrentUserNTID, getdate(),1)

			-- Ends ****** Identifying the custome mode questions *****************
			-- Starts ****** Send Back the result in sorted order *****************
			SELECT *
			INTO #ResultQuestions
			FROM (
				SELECT TQ.QuestionID
					,TQ.QuestionDisplayID
					,@CurrentUserNTID AS CurrentUserNTID
					,TVT.Delimiter
					,TV.ResponsibleEmployee
					,QL.ValueStreamTemplateID
					,TVT.ValueStreamTemplateName
					,TV.ValueStreamCategoryID
					,TVC.valueStreamCategoryName
					,QL.ValueStreamID
					,TV.ValueStreamName
					,QL.AssessorTemplateID
					,TRA.AssessorTemplateName
					,QL.AssessorID
					,TTA.AssessorName
					,QL.IsForgotValueStream
					,CASE 
						WHEN (QL.IsForgotValueStream = 1)
							THEN QL.VSSessionID
						ELSE NULL
						END AS VSSessionID
					,QL.IsForgotAssessor
					,CASE 
						WHEN (QL.IsForgotAssessor = 1)
							THEN QL.ASSessionID
						ELSE NULL
						END AS ASSessionID
					,(
						SELECT MAX(DataPoolID) AS DataPoolID
						FROM [t_trn_datapool] WITH (NOLOCK)
						WHERE answeredby_ntid = @NTID
							AND (IsDeleted = 0)
							AND AuditID IS NULL
							AND QuestionID = TQ.QuestionID
							AND PlantID = @PlantID
						) DataPoolID
					,TQ.QuestionText
					--,'' as QuestionHintText
					,TQ.QuestionHintText
					,TQ.AnswerType_AnswerTypeID
					,TQ.ChoiceDisplayTypeID
					,TQ.IsFilledInChoiceAllowed
					,TQ.IsUniqueAnswerRequired
					,TQ.IsAnswerRequired
					,TQ.DefaultChoiceID
					,TQ.IsQuestionAlwaysActive
					,TQ.ActiveDateRangeFrom
					,TQ.ActiveDateRangeTo
					,TQ.IsTargetFrequencyDefined
					,TQ.TargetFrequencyTypeID
					,TQ.TargetFrequencyValue
					,TQ.Question_PriorityID
					,TQ.IsDeleted
					,TQ.IsDefaultAnswerRequired
					,TQ.IsAnswered
					,TQ.CreatedAt
					,TQ.ModifiedAt
					,(
						SELECT STRING_AGG(cast(HyperLinkURL AS NVARCHAR(MAX)), ',')
						FROM [T_TRN_HintHyperLink] WITH (NOLOCK)
						WHERE QuestionID = TQ.QuestionID
							AND (IsDeleted = 0)
						) AS HyperLinkURL
					,(
						SELECT STRING_AGG(cast(ImageTitle AS NVARCHAR(MAX)), ',')
						FROM [T_TRN_HintImage] WITH (NOLOCK)
						WHERE QuestionID = TQ.QuestionID
							AND (IsDeleted = 0)
						) AS ImageTitle
					,(
						SELECT STRING_AGG(cast(DisplayFileName AS NVARCHAR(MAX)), ',')
						FROM [T_TRN_HintImage] WITH (NOLOCK)
						WHERE QuestionID = TQ.QuestionID
							AND (IsDeleted = 0)
						) AS DisplayFileName
					,(
						SELECT ListTag
						FROM [FN_GetNestedTagsByQuestionID](TQ.QuestionID, 'strTagName')
						WHERE ListTag IS NOT NULL
						) AS TagNameList
					,(
						SELECT ListTag
						FROM [FN_GetNestedTagsByQuestionID](TQ.QuestionID, 'strTagID')
						WHERE ListTag IS NOT NULL
						) AS TagIDList
					,CASE 
						WHEN TQ.QuestionID IN (
								SELECT QuestionID
								FROM @myCustomTableVariable
								)
							THEN 1
						ELSE 0
						END AS IsCustomMode
					,'' AS SessionID
				FROM T_TRN_Question TQ WITH (NOLOCK)
				LEFT JOIN #FilteredQuestion QL WITH (NOLOCK) ON TQ.QuestionID = QL.QuestionID
					AND TQ.IsDeleted = 0
				INNER JOIN [T_TRN_ValueStream] TV WITH (NOLOCK) ON TV.ValueStreamID = QL.ValueStreamID
				INNER JOIN [T_TRN_ValueStreamTemplate] TVT WITH (NOLOCK) ON TVT.ValueStreamTemplateID = TV.ValueStreamTemplateID
					AND TVT.PlantID = @PlantID
				INNER JOIN [T_TRN_ValueStreamCategory] TVC WITH (NOLOCK) ON TVC.ValueStreamCategoryID = TV.ValuestreamCategoryID
				INNER JOIN [T_TRN_Assessor] TTA WITH (NOLOCK) ON TTA.AssessorID = QL.AssessorID
				INNER JOIN [T_TRN_AssessorTemplate] TRA WITH (NOLOCK) ON TRA.AssessorTemplateID = TTA.AssessorTemplateID
					AND TRA.PlantID = @PlantID
				WHERE TV.Responsible_UserID IS NOT NULL -- and  TQ.QuestionID not in(select QuestionID from #Temp) 
					AND (TQ.IsDeleted = 0)
					AND TQ.PlantID = @PlantID
				) AS t2

	--insert into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('342_(5_Shuffle)',@PlantID,@CurrentUserNTID, getdate(),1)

			SELECT *
			FROM #ResultQuestions

			--drop table #VSASCombination 
			--drop table #AnsweredAndSkippedQueestionIDs
			--drop table #FilteredQuestion
			--drop table #ResultQuestions
			-- Ends ****** Send Back the result in sorted order *****************
			COMMIT TRANSACTION BINDQUESTIONANDANSWERTYPE;
		END TRY

		BEGIN CATCH
			ROLLBACK TRANSACTION BINDQUESTIONANDANSWERTYPE;

			EXEC [USP_LogError] @PlantID
				,@CurrentUserNTID;
		END CATCH
	END
	ELSE
	BEGIN
		SELECT - 1 AS QuestionID
	END
END
GO