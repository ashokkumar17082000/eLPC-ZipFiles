/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_ADDEDITASSESSORTEMPLATE]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE TO ADD AND EDIT ASSESSOR TEMPLATE DETAILS 
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					12-MAR-2021			KARTHIKEYAN KANDASAMY		PLANTID ADDED
ELPC_LH_003					17-MAR-2021			RAJASEKAR S					REPLACED TRIGGERS
ELPC_LH_004					17-MAR-2021			KARTHIKEYAN KANDASAMY		ERROR LOG ADDED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
EXEC [USP_AddEditAssessorTemplate] <<>>
*/
CREATE PROCEDURE [USP_AddEditAssessorTemplate] (
	@PlantID INT
	,@AssessorTemplateName NVARCHAR(50)
	,@IsLocked BIT NULL
	,@ModifiedAt DATETIME NULL
	,@CreatedAt DATETIME NULL
	,@IsTargetFrequencyDefined BIT NULL
	,@AssessorCategories XML NULL
	,@Assessors XML NULL
	,@AssessorTemplateID INT NULL
	,@IsDeleted BIT NULL
	,@CurrentUserNTID NVARCHAR(20)
	)
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION TRNADDEDITASSESSOR

		--to avoid entries from Lock settings update, it is enabled/disabled 
		--ALTER TABLE [T_TRN_AssessorTemplate] ENABLE TRIGGER [TR_HISTORYFOR_T_TRN_AssessorTemplate];
		--ALTER TABLE [T_TRN_Assessor] ENABLE TRIGGER [TR_HISTORYFOR_T_TRN_Assessor];
		DECLARE @min INT = 0
			,@max INT = 0
			,@AssessorName NVARCHAR(100)
			,@TargetFrequencyValue INT
			,@TargetFrequencyTypeID INT
			,@Category NVARCHAR(200)
			,@TargetFrequencyLowLimit INT
		--Inputs filed variable for triggers
		DECLARE @Scope_Identity_Table_Trigger TABLE (id INT);--Scope identities for all inserted rows
		DECLARE @Input_Ids_Trigger VARCHAR(MAX);
		DECLARE @TableName_Trigger VARCHAR(100);
		DECLARE @ActionType VARCHAR(10);
		DECLARE @AssessorTemplateHistoryID INT;

		IF (
				(
					@AssessorTemplateID IS NULL
					OR @AssessorTemplateID = 0
					)
				AND NOT EXISTS (
					SELECT TOP 1 1
					FROM [T_TRN_AssessorTemplate] WITH (NOLOCK)
					WHERE AssessorTemplateID = @AssessorTemplateID
						AND PlantID = @PlantID
					)
				)
		BEGIN
			INSERT INTO [T_TRN_AssessorTemplate] (
				PlantID
				,AssessorTemplateDisplayID
				,AssessorTemplateName
				,IsLocked
				,ModifiedAt
				,ModifiedBy_NTID
				,CreatedAt
				,CreatedBy_NTID
				,IsTargetFrequencyDefined
				,IsDeleted
				)
			VALUES (
				@PlantID
				,(
					SELECT DisplayID
					FROM [FN_GetNextDisplayID](@PlantID, 'T_TRN_AssessorTemplate')
					)
				,@AssessorTemplateName
				,@IsLocked
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
				,@CurrentUserNTID
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
				,@CurrentUserNTID
				,@IsTargetFrequencyDefined
				,@IsDeleted
				);

			SET @AssessorTemplateID = SCOPE_IDENTITY();

			SELECT @TableName_Trigger = 'AssessorTemplate'
				,@ActionType = 'I'
				,@Input_Ids_Trigger = @AssessorTemplateID;

			EXEC [USP_ASSESSOR_HISTORY] @PlantID = @PlantID
				,@CurrentUserNTID = @CurrentUserNTID
				,@TableName = @TableName_Trigger
				,@AssessorTemplateHistoryID = @AssessorTemplateHistoryID OUTPUT
				,@ActionType = @ActionType
				,@INPUT_IDS = @Input_Ids_Trigger;

			DELETE
			FROM @Scope_Identity_Table_Trigger

			INSERT INTO T_TRN_Assessor (
				AssessorTemplateID
				,AssessorName
				,TargetFrequencyValue
				,TargetFrequencyTypeID
				,Category
				,TargetFrequencyLowLimit
				)
			OUTPUT inserted.AssessorID
			INTO @Scope_Identity_Table_Trigger
			SELECT SCOPE_IDENTITY() AS AssessorTemplateID
				,Assessor.value('(AssessorName/text())[1]', 'NVARCHAR(50)') AS AssessorName
				,Assessor.value('(TargetFrequencyValue/text())[1]', 'INT') AS TargetFrequencyValue
				,Assessor.value('(TargetFrequencyTypeID/text())[1]', 'INT') AS TargetFrequencyTypeID
				,Assessor.value('(Category/text())[1]', 'NVARCHAR(100)') AS Category
				,Assessor.value('(TargetFrequencyLowLimit/text())[1]', 'INT') AS TargetFrequencyLowLimit
			FROM @Assessors.nodes('/ArrayOfAssessor/Assessor') AS TEMPTABLE(Assessor)

			SELECT @TableName_Trigger = 'Assessor'
				,@ActionType = 'I'
				,@Input_Ids_Trigger = (
					SELECT CAST(id AS VARCHAR(MAX)) + ', '
					FROM @Scope_Identity_Table_Trigger
					FOR XML PATH('')
					);

			EXEC [USP_ASSESSOR_HISTORY] @PlantID = @PlantID
				,@CurrentUserNTID = @CurrentUserNTID
				,@TableName = @TableName_Trigger
				,@AssessorTemplateHistoryID = @AssessorTemplateHistoryID
				,@ActionType = @ActionType
				,@INPUT_IDS = @Input_Ids_Trigger;
		END
		ELSE IF (
				@AssessorTemplateID IS NOT NULL
				AND EXISTS (
					SELECT TOP 1 1
					FROM [T_TRN_AssessorTemplate]  WITH (NOLOCK)
					WHERE AssessorTemplateID = @AssessorTemplateID
						AND PlantID = @PlantID
					)
				)
		BEGIN
			UPDATE T_TRN_AssessorTemplate
			SET AssessorTemplateName = @AssessorTemplateName
				,ModifiedAt = (
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
				,ModifiedBy_NTID = @CurrentUserNTID
				,IsLocked = @IsLocked
				,IsTargetFrequencyDefined = @IsTargetFrequencyDefined
			WHERE AssessorTemplateID = @AssessorTemplateID;

			SELECT @TableName_Trigger = 'AssessorTemplate'
				,@ActionType = 'U'
				,@Input_Ids_Trigger = @AssessorTemplateID;

			EXEC [USP_ASSESSOR_HISTORY] @PlantID = @PlantID
				,@CurrentUserNTID = @CurrentUserNTID
				,@TableName = @TableName_Trigger
				,@AssessorTemplateHistoryID = @AssessorTemplateHistoryID OUTPUT
				,@ActionType = @ActionType
				,@INPUT_IDS = @Input_Ids_Trigger;

			SELECT Assessor.value('(AssessorID/text())[1]', 'INT') AS AssessorID
				,Assessor.value('(AssessorName/text())[1]', 'NVARCHAR(50)') AS AssessorName
				,Assessor.value('(TargetFrequencyValue/text())[1]', 'INT') AS TargetFrequencyValue
				,Assessor.value('(TargetFrequencyTypeID/text())[1]', 'INT') AS TargetFrequencyTypeID
				,Assessor.value('(Category/text())[1]', 'NVARCHAR(100)') AS Category
				,Assessor.value('(TargetFrequencyLowLimit/text())[1]', 'INT') AS TargetFrequencyLowLimit
				,@AssessorTemplateID AS AssessorTemplateID
			INTO #T1
			FROM @Assessors.nodes('/ArrayOfAssessor/Assessor') AS TEMPTABLE(Assessor);

			DELETE
			FROM @Scope_Identity_Table_Trigger

			INSERT INTO @Scope_Identity_Table_Trigger
			SELECT AssessorID
			FROM T_TRN_Assessor  WITH (NOLOCK)
			WHERE AssessorID NOT IN (
					SELECT AssessorID
					FROM #T1
					WHERE AssessorID != 0
						OR AssessorID IS NOT NULL
						AND AssessorTemplateID = @AssessorTemplateID
					)
				AND AssessorTemplateID = @AssessorTemplateID;

			UPDATE T_TRN_Assessor
			SET IsDeleted = 1
			WHERE AssessorID IN (
					SELECT id
					FROM @Scope_Identity_Table_Trigger
					)

			SELECT @TableName_Trigger = 'Assessor'
				,@ActionType = 'U'
				,@Input_Ids_Trigger = (
					SELECT CAST(id AS VARCHAR(MAX)) + ', '
					FROM @Scope_Identity_Table_Trigger
					FOR XML PATH('')
					);

			EXEC [USP_ASSESSOR_HISTORY] @PlantID = @PlantID
				,@CurrentUserNTID = @CurrentUserNTID
				,@TableName = @TableName_Trigger
				,@AssessorTemplateHistoryID = @AssessorTemplateHistoryID
				,@ActionType = @ActionType
				,@INPUT_IDS = @Input_Ids_Trigger;

			DELETE
			FROM @Scope_Identity_Table_Trigger

			INSERT INTO T_TRN_Assessor (
				AssessorName
				,TargetFrequencyValue
				,TargetFrequencyTypeID
				,AssessorTemplateID
				,Category
				,TargetFrequencyLowLimit
				)
			OUTPUT inserted.AssessorID
			INTO @Scope_Identity_Table_Trigger
			SELECT AssessorName
				,TargetFrequencyValue
				,TargetFrequencyTypeID
				,AssessorTemplateID
				,Category
				,TargetFrequencyLowLimit
			FROM #T1
			WHERE AssessorID = NULL
				OR AssessorID = 0;

			SELECT @TableName_Trigger = 'Assessor'
				,@ActionType = 'I'
				,@Input_Ids_Trigger = (
					SELECT CAST(id AS VARCHAR(MAX)) + ', '
					FROM @Scope_Identity_Table_Trigger
					FOR XML PATH('')
					);

			EXEC [USP_ASSESSOR_HISTORY] @PlantID = @PlantID
				,@CurrentUserNTID = @CurrentUserNTID
				,@TableName = @TableName_Trigger
				,@AssessorTemplateHistoryID = @AssessorTemplateHistoryID
				,@ActionType = @ActionType
				,@INPUT_IDS = @Input_Ids_Trigger;

			DECLARE CUR_Accessor CURSOR FORWARD_ONLY
			FOR
			SELECT AssessorID
				,AssessorName
				,TargetFrequencyValue
				,AssessorTemplateID
				,TargetFrequencyTypeID
				,Category
				,TargetFrequencyLowLimit
			FROM #T1
			WHERE AssessorTemplateID = @AssessorTemplateID
				AND (
					AssessorID != 0
					AND AssessorID IS NOT NULL
					);

			DECLARE @AssessorID INT = 0;

			OPEN CUR_Accessor;

			FETCH NEXT
			FROM CUR_Accessor
			INTO @AssessorID
				,@AssessorName
				,@TargetFrequencyValue
				,@AssessorTemplateID
				,@TargetFrequencyTypeID
				,@Category
				,@TargetFrequencyLowLimit;

			WHILE @@FETCH_STATUS = 0
			BEGIN
				IF EXISTS (
						SELECT TOP(1) 1
						FROM T_TRN_Assessor WITH (NOLOCK)
						WHERE AssessorID = @AssessorID
						)
				BEGIN
					-- Update the Assessor data if that exists
					UPDATE T_TRN_Assessor
					SET AssessorName = @AssessorName
						,TargetFrequencyValue = @TargetFrequencyValue
						,AssessorTemplateID = @AssessorTemplateID
						,TargetFrequencyTypeID = @TargetFrequencyTypeID
						,Category = @Category
						,TargetFrequencyLowLimit = @TargetFrequencyLowLimit
					WHERE AssessorID = @AssessorID;

					SELECT @TableName_Trigger = 'Assessor'
						,@ActionType = 'U'
						,@Input_Ids_Trigger = @AssessorID;

					EXEC [USP_ASSESSOR_HISTORY] @PlantID = @PlantID
						,@CurrentUserNTID = @CurrentUserNTID
						,@TableName = @TableName_Trigger
						,@AssessorTemplateHistoryID = @AssessorTemplateHistoryID
						,@ActionType = @ActionType
						,@INPUT_IDS = @Input_Ids_Trigger;
				END

				FETCH NEXT
				FROM CUR_Accessor
				INTO @AssessorID
					,@AssessorName
					,@TargetFrequencyValue
					,@AssessorTemplateID
					,@TargetFrequencyTypeID
					,@Category
					,@TargetFrequencyLowLimit;
			END

			CLOSE CUR_Accessor;

			DEALLOCATE CUR_Accessor;
		END

		--ALTER TABLE [T_TRN_AssessorTemplate] DISABLE TRIGGER [TR_HISTORYFOR_T_TRN_AssessorTemplate];
		--ALTER TABLE [T_TRN_Assessor] DISABLE TRIGGER [TR_HISTORYFOR_T_TRN_Assessor];
		SELECT AssessorTemplateID
			,PlantID
			,AssessorTemplateDisplayID
			,AssessorTemplateName
			,IsTargetFrequencyDefined
			,IsLocked
			,IsDeleted
			,CreatedAt
			,CreatedBy_NTID
			,ModifiedAt
			,ModifiedBy_NTID
		FROM T_TRN_AssessorTemplate WITH(NOLOCK)
		WHERE AssessorTemplateID = @AssessorTemplateID
			AND PlantID = @PlantID;

		COMMIT TRANSACTION TRNADDEDITASSESSOR;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNADDEDITASSESSOR;

		EXEC [USP_LogError] @PlantID
			,@CurrentUserNTID;
	END CATCH
END
GO

