/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchAssessorTemplateByTemplateID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING ASSESSOR TEMPLATE BY TEMPLATE ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					12-MAR-2021			KARTHIKEYAN KANDASAMY		MODIFIED VERSION
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_FetchAssessorTemplateByTemplateID] @plantID=1, @AssessorTemplateID=1
*/
CREATE PROCEDURE [USP_FetchAssessorTemplateByTemplateID] (
	@PlantID INT
	,@AssessorTemplateID INT
	)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT AssessorTemplateID
		,PlantID
		,AssessorTemplateDisplayID
		,AssessorTemplateName
		,IsTargetFrequencyDefined
		,IsLocked
		,IsDeleted
		,CreatedAt
		,CreatedBy_NTID
		,ModifiedAt
		,ModifiedBy_NTID
	FROM T_TRN_AssessorTemplate WITH (NOLOCK)
	WHERE PlantID = @PlantID
		AND AssessorTemplateID = @AssessorTemplateID;
END
GO


