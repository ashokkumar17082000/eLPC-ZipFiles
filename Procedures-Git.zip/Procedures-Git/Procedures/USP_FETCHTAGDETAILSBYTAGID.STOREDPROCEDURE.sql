 /*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchTagDetailsByTagID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING FULL TAG DETAILS BY TAG ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					22-MAR-2021			KARTHIKEYAN KANDASAMY		PLANTID ADDED
ELPC_LH_006                                     18-AUG-2023                     ASHOK KUMAR R B 
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_FetchTagDetailsByTagID] 1,4643
*/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [USP_FetchTagDetailsByTagID] (
	@PlantID INT
	,@TagID INT
	)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT *
		,PlantID
		,TagDisplayID
		,TagName
		
		,IsSingleQuestionSuppressed
		,SuppressedDateRangeFrom
		,SuppressedDateRangeTo
		,IsTargetFrequencyDefined
		,TargetFrequencyTypeID
		,TargetFrequencyValue
		,Tag_PriorityID
		,TagTypeID
		,IsLocked
		,AnonymizeUserDataSettingID
		,IsBranchLogicToBeFollowed
		,IsMandatoryAssessorsDefined
		,IsDeleted
		,CreatedAt
		,ModifiedAt
		,IsSearchableTag
		,IsSkipQuestionDefined
		,IsQuestionOverviewDefined
		,IsProgressPercentageDefined
		,IsResultOverviewDefined
		,IsResumeTagDefined
		,IsReportingEmailDefined 
		,CreatedBy_NTID
		,ModifiedBy_NTID
		
	-- ,Assigned_ValueStreamTemplateID
	-- ,Assigned_ValueStreamCategoryID
	-- ,Assigned_AssessorTemplateID
	FROM T_TRN_Tag WITH (NOLOCK)
	WHERE TagID = @TagID
		AND PlantID = @PlantID;
END
GO