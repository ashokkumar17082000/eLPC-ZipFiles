/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_AddEditAudit]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR ADD?EDIT AUDIT DETAILS
///MODIFICATION HISTORY         :  
************************************************************************************************************ 
///REF                      DATE                MODIFIED BY                 CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001                 25-NOV-2020         JANARTHANAN KRISHNASAMY     INITIAL VERSION
ELPC_LH_002                 19-MAR-2021         Rajasekar S                 PlantId,CurrentUserNTID added
ELPC_LH_002_CR01            8-JUN-2021          Rajasekar S                 Start,End time added
ELPC_LH_005                 15-Mar-2023         Snehitha Kannaboyina        Added logic for inserting audits in new table-T_LNK_AuditValueStreams
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_AddEditAudit] 
*/
CREATE PROCEDURE [USP_AddEditAudit] @PlantID INT
	,@AuditID INT NULL
	,@StartDate DATETIME NULL
	,@EndDate DATETIME NULL
	,@StartTime TIME(0) NULL
	,@EndTime TIME(0) NULL
	,@IsRecurring BIT NULL
	,@IsAllDay BIT NULL
	,@ValueStreamID INT NULL
	,@ValueStreams XML NULL
	,@Remarks NVARCHAR(max) NULL
	,@IsDeleted BIT NULL
	,@IsAuditCompleted BIT NULL
	,@AssignedTags XML NULL
	,@RequiredAttendees XML NULL
	,@OptionalAttendees XML NULL
	,@TagID INT NULL
	,@Location NVARCHAR(200) NULL
	,@CurrentUserNTID NVARCHAR(20)
	,@Recurrence_TypeId INT NULL
	,@Recurrence_Interval INT NULL
	,@Recurrence_DayOfWeek CHAR(13)
	,@Recurrence_DayOfMonth INT NULL
	,@Recurrence_WeekOfMonth INT NULL
	,@Recurrence_MonthOfYear INT NULL
AS
BEGIN
	BEGIN TRY
		DECLARE @min INT = 0
			,@max INT = 0
			,@NTID NVARCHAR(20)
		DECLARE @ValueStream INT

		BEGIN TRANSACTION TRNADDEDITAUDIT

		EXEC [USP_PlantIDValidation] @PlantID = @PlantID
			,@ID = @AuditID
			,@Mode = 'AUDIT'
			,@CurrentUserNTID = @CurrentUserNTID

		IF (
				(
					@AuditID IS NULL
					OR @AuditID = 0
					)
				AND NOT EXISTS (
					SELECT TOP (1) 1
					FROM T_TRN_Audit WITH (NOLOCK)
					WHERE AuditID = @AuditID
						AND PlantID = @PlantID
					)
				)
		BEGIN
			INSERT INTO [T_TRN_Audit] (
				PlantID
				,StartDate
				,StartTime
				,EndDate
				,EndTime
				,IsRecurring
				,IsAllDay
				,ValueStreamID
				,Remarks
				,CreatedAt
				,ModifiedAt
				,CreatedBy_NTID
				,ModifiedBy_NTID
				,IsDeleted
				,IsAuditCompleted
				,TagID
				,Location
				)
			VALUES (
				@PlantID
				,@StartDate
				,@StartTime
				,@EndDate
				,@EndTime
				,@IsRecurring
				,@IsAllDay
				,@ValueStreamID
				,@Remarks
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
				,@CurrentUserNTID
				,@CurrentUserNTID
				,@IsDeleted
				,@IsAuditCompleted
				,@TagID
				,@Location
				)

			SET @AuditID = SCOPE_IDENTITY()

			--todo, not required since only one tag is assigned for an audit
			INSERT INTO T_LNK_Audit_AssignedTags (
				AuditID
				,TagID
				,CreatedAt
				,ModifiedAt
				,IsDeleted
				,CreatedBy_NTID
				,ModifiedBy_NTID
				)
			SELECT @AuditID AS AuditID
				,Tag.value('(TagID/text())[1]', 'int') AS TagID
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					) AS CreatedAt
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					) AS ModifiedAt
				,@IsDeleted AS FALSE
				,@CurrentUserNTID AS CreatedBy_NTID
				,@CurrentUserNTID AS ModifiedBy_NTID
			FROM @AssignedTags.nodes('/ArrayOfTag/Tag') AS TEMPTABLE(Tag)

			--for valueStreams
			INSERT INTO T_LNK_Audit_ValueStreams (
				AuditID
				,ValueStreams
				,CreatedAt
				,ModifiedAt
				,CreatedBy_NTID
				,ModifiedBy_NTID
				,IsDeleted
				)
			SELECT @AuditID AS AuditID
				,ValueStreams.value('(ValueStreamID/text())[1]', 'int') AS ValueStreams
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					) AS CreatedAt
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					) AS ModifiedAt
				,@CurrentUserNTID AS CreatedBy_NTID
				,@CurrentUserNTID AS ModifiedBy_NTID
				,@IsDeleted AS FALSE
			FROM @ValueStreams.nodes('/ArrayOfValueStream/ValueStream') AS TEMPTABLE(ValueStreams)

			INSERT INTO T_LNK_Audit_RequiredAttendees (
				AuditID
				,NTID
				,CreatedAt
				,ModifiedAt
				,IsDeleted
				,CreatedBy_NTID
				,ModifiedBy_NTID
				)
			SELECT @AuditID AS AuditID
				,ReqUser.value('(NTID/text())[1]', 'nvarchar(20)') AS NTID
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					) AS CreatedAt
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					) AS ModifiedAt
				,@IsDeleted AS FALSE
				,@CurrentUserNTID AS CreatedBy_NTID
				,@CurrentUserNTID AS ModifiedBy_NTID
			FROM @RequiredAttendees.nodes('/ArrayOfUser/User') AS TEMPTABLE(ReqUser)

			INSERT INTO T_LNK_Audit_OptionalAttendees (
				AuditID
				,NTID
				,CreatedAt
				,ModifiedAt
				,IsDeleted
				,CreatedBy_NTID
				,ModifiedBy_NTID
				)
			SELECT @AuditID AS AuditID
				,OptUser.value('(NTID/text())[1]', 'nvarchar(20)') AS NTID
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					) AS CreatedAt
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					) AS ModifiedAt
				,@IsDeleted AS FALSE
				,@CurrentUserNTID AS CreatedBy_NTID
				,@CurrentUserNTID AS ModifiedBy_NTID
			FROM @OptionalAttendees.nodes('/ArrayOfUser/User') AS TEMPTABLE(OptUser)

			IF (
					@IsAllDay = 0
					AND @IsRecurring = 1
					)
			BEGIN
				INSERT INTO [T_TRN_Recurrence] (
					[PlantID]
					,[AuditID]
					,[RecurrenceTypeId]
					,[Interval]
					,[DayOfWeek]
					,[DayOfMonth]
					,[WeekOfMonth]
					,[MonthOfYear]
					,[CreatedAt]
					,[CreatedBy_NTID]
					,[ModifiedAt]
					,[ModifiedBy_NTID]
					)
				VALUES (
					@PlantID
					,@AuditID
					,@Recurrence_TypeId
					,@Recurrence_Interval
					,@Recurrence_DayOfWeek
					,@Recurrence_DayOfMonth
					,@Recurrence_WeekOfMonth
					,@Recurrence_MonthOfYear
					,GETDATE()
					,@CurrentUserNTID
					,GETDATE()
					,@CurrentUserNTID
					)
			END

			EXEC USP_AddQuestionsByAuditID @PlantID
				,@AuditID
				,@ValueStreams
				,@CurrentUserNTID --to group the questions for an audit

			EXEC USP_UpdateAuditAssessorsByAuditID @PlantID
				,@AuditID
				,@CurrentUserNTID --to create Assessors for an audit

			SELECT A.AuditID
				,A.PlantID
				,A.StartDate
				,A.StartTime
				,A.EndDate
				,A.EndTime
				,A.IsRecurring
				,A.IsAllDay
				,A.ValueStreamID
				,A.Remarks
				,A.[Location]
				,A.IsAuditCompleted
				,A.TagID
				,A.CreatedAt
				,A.CreatedBy_NTID
				,A.ModifiedAt
				,A.ModifiedBy_NTID
				,A.IsDeleted
				,R.[RecurrenceTypeId] AS [Recurrence_TypeId]
				,R.[Interval] AS [Recurrence_Interval]
				,R.[DayOfWeek] AS [Recurrence_DayOfWeek]
				,R.[DayOfMonth] AS [Recurrence_DayOfMonth]
				,R.[WeekOfMonth] AS [Recurrence_WeekOfMonth]
				,R.[MonthOfYear] AS [Recurrence_MonthOfYear]
			FROM T_TRN_Audit A WITH (NOLOCK)
			LEFT JOIN [T_TRN_Recurrence] R WITH (NOLOCK) ON A.AuditID = R.AuditID
				AND A.PlantID = R.PlantID
			WHERE A.AuditID = @AuditID
				AND A.PlantID = @PlantID
		END
		ELSE IF (
				@AuditID IS NOT NULL
				AND EXISTS (
					SELECT TOP 1 1
					FROM T_TRN_Audit WITH (NOLOCK)
					WHERE AuditID = @AuditID
						AND PlantID = @PlantID
					)
				)
		BEGIN
			UPDATE T_TRN_Audit
			SET StartDate = @StartDate
				,StartTime = @StartTime
				,EndDate = @EndDate
				,EndTime = @EndTime
				,IsRecurring = @IsRecurring
				,IsAllDay = @IsAllDay
				,ValueStreamID = @ValueStreamID
				,Remarks = @Remarks
				,IsDeleted = @IsDeleted
				,IsAuditCompleted = @IsAuditCompleted
				,TagID = @TagID
				,ModifiedAt = (
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
				,ModifiedBy_NTID = @CurrentUserNTID
				,Location = @Location
			WHERE AuditID = @AuditID
				AND PlantID = @PlantID

			--for Required attendees
			BEGIN
				SELECT @AuditID AS AuditID
					,Identity(INT, 1, 1) AS ID
					,ReqUser.value('(NTID/text())[1]', 'nvarchar(20)') AS NTID
					,(
						SELECT FormattedDateTime
						FROM fnGetDateTime(@PlantID)
						) AS CreatedAt
					,(
						SELECT FormattedDateTime
						FROM fnGetDateTime(@PlantID)
						) AS ModifiedAt
					,@IsDeleted AS FALSE
					,@CurrentUserNTID AS CreatedBy_NTID
					,@CurrentUserNTID AS ModifiedBy_NTID
				INTO #R1
				FROM @RequiredAttendees.nodes('/ArrayOfUser/User') AS TEMPTABLE(ReqUser)

				UPDATE T_LNK_Audit_RequiredAttendees
				SET IsDeleted = 1
				WHERE NTID NOT IN (
						SELECT NTID
						FROM #R1
						)
					AND AuditID = @AuditID --to soft delete the removed attendees
					--for inserting new Required attendees

				SET @min = (
						SELECT min(ID)
						FROM #R1
						)
				SET @max = (
						SELECT max(ID)
						FROM #R1
						)

				WHILE (@min <= @max)
				BEGIN
					SELECT @AuditID = AuditID
						,@NTID = NTID
					FROM #R1
					WHERE ID = @min;

					IF NOT EXISTS (
							SELECT 1
							FROM T_LNK_Audit_RequiredAttendees WITH (NOLOCK)
							WHERE AuditID = @AuditID
								AND NTID = @NTID
								AND IsDeleted = 0
							)
					BEGIN
						INSERT INTO T_LNK_Audit_RequiredAttendees (
							AuditID
							,NTID
							,CreatedBy_NTID
							,CreatedAt
							,ModifiedAt
							,ModifiedBy_NTID
							,IsDeleted
							)
						VALUES (
							@AuditID
							,@NTID
							,@CurrentUserNTID
							,(
								SELECT FormattedDateTime
								FROM fnGetDateTime(@PlantID)
								)
							,(
								SELECT FormattedDateTime
								FROM fnGetDateTime(@PlantID)
								)
							,@CurrentUserNTID
							,0
							)
					END

					SET @min = @min + 1;
				END
			END

			--end
			--for valuestreams
			BEGIN
				SELECT @AuditID AS AuditID
					,Identity(INT, 1, 1) AS ID
					,ValueStreams.value('(ValueStreamID/text())[1]', 'int') AS ValueStreams
					,(
						SELECT FormattedDateTime
						FROM fnGetDateTime(@PlantID)
						) AS CreatedAt
					,(
						SELECT FormattedDateTime
						FROM fnGetDateTime(@PlantID)
						) AS ModifiedAt
					,@IsDeleted AS FALSE
					,@CurrentUserNTID AS CreatedBy_NTID
					,@CurrentUserNTID AS ModifiedBy_NTID
				INTO #v1
				FROM @ValueStreams.nodes('/ArrayOfValueStream/ValueStream') AS TEMPTABLE(ValueStreams)

				UPDATE T_LNK_Audit_ValueStreams
				SET IsDeleted = 1
				WHERE ValueStreams NOT IN (
						SELECT ValueStreams
						FROM #v1
						)
					AND AuditID = @AuditID --to soft delete the valuestreams
					--for inserting new valuestreams

				SET @min = (
						SELECT min(ID)
						FROM #v1
						)
				SET @max = (
						SELECT max(ID)
						FROM #v1
						)

				WHILE (@min <= @max)
				BEGIN
					SELECT @AuditID = AuditID
						,@ValueStream = ValueStreams
					FROM #v1
					WHERE ID = @min;

					IF NOT EXISTS (
							SELECT 1
							FROM T_LNK_Audit_ValueStreams WITH (NOLOCK)
							WHERE AuditID = @AuditID
								AND ValueStreams = @ValueStream
								AND IsDeleted = 0
							)
					BEGIN
						INSERT INTO T_LNK_Audit_ValueStreams (
							AuditID
							,ValueStreams
							,CreatedBy_NTID
							,CreatedAt
							,ModifiedAt
							,ModifiedBy_NTID
							,IsDeleted
							)
						VALUES (
							@AuditID
							,@ValueStream
							,@CurrentUserNTID
							,(
								SELECT FormattedDateTime
								FROM fnGetDateTime(@PlantID)
								)
							,(
								SELECT FormattedDateTime
								FROM fnGetDateTime(@PlantID)
								)
							,@CurrentUserNTID
							,0
							)
					END

					SET @min = @min + 1;
				END
			END

			--for Optional attendees
			BEGIN
				SELECT @AuditID AS AuditID
					,Identity(INT, 1, 1) AS ID
					,OptUser.value('(NTID/text())[1]', 'nvarchar(20)') AS NTID
					,(
						SELECT FormattedDateTime
						FROM fnGetDateTime(@PlantID)
						) AS CreatedAt
					,(
						SELECT FormattedDateTime
						FROM fnGetDateTime(@PlantID)
						) AS ModifiedAt
					,@IsDeleted AS FALSE
					,@CurrentUserNTID AS CreatedBy_NTID
					,@CurrentUserNTID AS ModifiedBy_NTID
				INTO #Optional1
				FROM @OptionalAttendees.nodes('/ArrayOfUser/User') AS TEMPTABLE(OptUser)

				UPDATE T_LNK_Audit_OptionalAttendees
				SET IsDeleted = 1
				WHERE NTID NOT IN (
						SELECT NTID
						FROM #Optional1
						)
					AND AuditID = @AuditID --to soft delete the removed optional attendees
					--for inserting new Optional attendees

				SET @min = (
						SELECT min(ID)
						FROM #Optional1
						)
				SET @max = (
						SELECT max(ID)
						FROM #Optional1
						)

				WHILE (@min <= @max)
				BEGIN
					SELECT @AuditID = AuditID
						,@NTID = NTID
					FROM #Optional1
					WHERE ID = @min;

					IF NOT EXISTS (
							SELECT 1
							FROM T_LNK_Audit_OptionalAttendees WITH (NOLOCK)
							WHERE AuditID = @AuditID
								AND NTID = @NTID
								AND IsDeleted = 0
							)
					BEGIN
						INSERT INTO T_LNK_Audit_OptionalAttendees (
							AuditID
							,NTID
							,CreatedBy_NTID
							,CreatedAt
							,ModifiedAt
							,ModifiedBy_NTID
							,IsDeleted
							)
						VALUES (
							@AuditID
							,@NTID
							,@CurrentUserNTID
							,(
								SELECT FormattedDateTime
								FROM fnGetDateTime(@PlantID)
								)
							,(
								SELECT FormattedDateTime
								FROM fnGetDateTime(@PlantID)
								)
							,@CurrentUserNTID
							,0
							)
					END

					SET @min = @min + 1;
				END
			END

			IF (
					@IsAllDay = 0
					AND @IsRecurring = 1
					)
			BEGIN
				IF EXISTS (
						SELECT 1
						FROM [T_TRN_Recurrence] WITH (NOLOCK)
						WHERE [AuditID] = @AuditID
							AND PlantID = @PlantID
						)
				BEGIN
					UPDATE [T_TRN_Recurrence]
					SET [RecurrenceTypeId] = @Recurrence_TypeId
						,[Interval] = @Recurrence_Interval
						,[DayOfWeek] = @Recurrence_DayOfWeek
						,[DayOfMonth] = @Recurrence_DayOfMonth
						,[WeekOfMonth] = @Recurrence_WeekOfMonth
						,[MonthOfYear] = @Recurrence_MonthOfYear
						,[ModifiedAt] = GETDATE()
						,[ModifiedBy_NTID] = @CurrentUserNTID
					WHERE [AuditID] = @AuditID
						AND PlantID = @PlantID
				END
				ELSE
				BEGIN
					INSERT INTO [T_TRN_Recurrence] (
						[PlantID]
						,[AuditID]
						,[RecurrenceTypeId]
						,[Interval]
						,[DayOfWeek]
						,[DayOfMonth]
						,[WeekOfMonth]
						,[MonthOfYear]
						,[CreatedAt]
						,[CreatedBy_NTID]
						,[ModifiedAt]
						,[ModifiedBy_NTID]
						)
					VALUES (
						@PlantID
						,@AuditID
						,@Recurrence_TypeId
						,@Recurrence_Interval
						,@Recurrence_DayOfWeek
						,@Recurrence_DayOfMonth
						,@Recurrence_WeekOfMonth
						,@Recurrence_MonthOfYear
						,GETDATE()
						,@CurrentUserNTID
						,GETDATE()
						,@CurrentUserNTID
						)
				END
			END
			ELSE
			BEGIN
				DELETE
				FROM [T_TRN_Recurrence]
				WHERE [AuditID] = @AuditID
					AND PlantID = @PlantID
			END

			--end
			EXEC USP_AddQuestionsByAuditID @PlantID
				,@AuditID
				,@ValueStreams
				,@CurrentUserNTID --to group the questions for an audit

			EXEC USP_UpdateAuditAssessorsByAuditID @PlantID
				,@AuditID
				,@CurrentUserNTID --to create Assessors for an audit

			SELECT A.AuditID
				,A.PlantID
				,A.StartDate
				,A.StartTime
				,A.EndDate
				,A.EndTime
				,A.IsRecurring
				,A.IsAllDay
				,A.ValueStreamID
				,A.Remarks
				,A.[Location]
				,A.IsAuditCompleted
				,A.TagID
				,A.CreatedAt
				,A.CreatedBy_NTID
				,A.ModifiedAt
				,A.ModifiedBy_NTID
				,A.IsDeleted
				,R.[RecurrenceTypeId] AS [Recurrence_TypeId]
				,R.[Interval] AS [Recurrence_Interval]
				,R.[DayOfWeek] AS [Recurrence_DayOfWeek]
				,R.[DayOfMonth] AS [Recurrence_DayOfMonth]
				,R.[WeekOfMonth] AS [Recurrence_WeekOfMonth]
				,R.[MonthOfYear] AS [Recurrence_MonthOfYear]
			FROM T_TRN_Audit A WITH (NOLOCK)
			LEFT JOIN [T_TRN_Recurrence] R WITH (NOLOCK) ON A.AuditID = R.AuditID
				AND A.PlantID = R.PlantID
			WHERE A.AuditID = @AuditID
				AND A.PlantID = @PlantID
		END

		EXEC USP_AddEditUsers @PlantID
			,@CurrentUserNTID
			,@RequiredAttendees --to update the new users in User table

		EXEC USP_AddEditUsers @PlantID
			,@CurrentUserNTID
			,@OptionalAttendees

		COMMIT TRANSACTION TRNADDEDITAUDIT
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNADDEDITAUDIT

		EXEC USP_LogError @PlantID
			,@CurrentUserNTID
	END CATCH
END
GO
