/****** Object:  StoredProcedure [USP_AddEditLaunchPadSettings]    Script Date: 08.03.2024 09:10:34 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [USP_AddEditLaunchPadSettings] (@PlantID int
   ,@Assessors [UT_LaunchpadSettings] READONLY)
   
AS
BEGIN
  DECLARE @Scope_Identity_Table_Trigger TABLE (id INT)--Scope identities for all inserted rows
 declare @HistoryID int;
  declare @ID int;
   SET NOCOUNT ON;

--update  [T_TRN_LaunchpadSetting] set IsDeleted=1  where 
select @HistoryID=ISNULL(MAX(HistoryID),0) from T_TRN_LaunchpadSetting where PlantID=@PlantID

set @HistoryID=@HistoryID + 1;

  INSERT INTO [T_TRN_LaunchpadSetting]

        ( [TextName]
		,[ValidURL]
           ,[IsDeleted]
		   ,[ModifiedAt]
		   ,[CreatedAt]
		   ,[PlantID]
		   ,[CreatedBy]
		   ,[ModifiedBy]
		   ,[HistoryID]
		   )
   SELECT   [TextName] 
           ,[ValidURL]
           ,[IsDeleted]
		   ,[ModifiedAt]
		   ,[CreatedAt]
		   ,[PlantID]
		   ,[CreatedBy]
		   ,[ModifiedBy]
		   ,HistoryID=@HistoryID
		    FROM @Assessors


 UPDATE [T_TRN_LaunchpadSetting]
  SET [IsDeleted]=1
  WHERE [HistoryID] NOT IN (@HistoryID) 
  and [PlantID]= @PlantID
/*select @HistoryID=ISNULL(MAX(HistoryID),0) from T_TRN_LaunchpadSetting

set @HistoryID=@HistoryID + 1;
update T_TRN_LaunchpadSetting set HistoryID=@HistoryID;*/
    /* insert into T_TRN_LaunchpadSettings
         ( [TextName]
		,[ValidURL]
           ,[IsDeleted]
		   ,[ModifiedAt]
		   ,[CreatedAt]
		   ,[PlantID]
		   ,[CreatedBy]
		   ,[ModifiedBy]
		   ,[HistoryID]
		   )
   SELECT   [TextName] 
           ,[ValidURL]
           ,[IsDeleted]
		   ,[ModifiedAt]
		   ,[CreatedAt]
		   ,[PlantID]
		   ,[CreatedBy]
		   ,[ModifiedBy]
		   ,HistoryID=@HistoryID
		    FROM @Assessors*/
END

GO