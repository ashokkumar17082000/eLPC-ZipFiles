/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_ValueStreamsByTemplateID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING VALUESTREAMS BY TEMPLATEID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					19-MAR-2021			RAJASEKAR S					Plantid included
ELPC_LH_002					26-MAR-2021			Rajasekar S					@CurrentUserNTID,PlantIDValidation added
ELPC_LH_002					14-JULY-2022		SHUBHAM BARANGE				Data redundacy via ValueStream Datacondition added
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_ValueStreamsByTemplateID] 29 ,325, 'HBA8KOR'
*/
CREATE PROCEDURE [USP_ValueStreamsByTemplateID] @PlantID INT
	,@ValueStreamTemplateID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = @ValueStreamTemplateID
		,@Mode = 'VALUESTREAMTEMPLATE'
		,@CurrentUserNTID = @CurrentUserNTID

	SET NOCOUNT ON;

	SELECT VS.ValueStreamID
		,VS.Responsible_UserID
		,VS.ResponsibleEmployee
		,VS.ValueStreamTemplateID
		,VS.ValueStreamCategoryID
		,VS.ValueStreamData
		,VS.NodeID
		,VS.RowID
		,VST.ValueStreamTemplateName
		,VST.Delimiter
		,VS.ValueStreamName
	FROM T_TRN_ValueStream VS WITH (NOLOCK)
	INNER JOIN T_TRN_ValueStreamTemplate VST WITH (NOLOCK) ON VST.ValueStreamTemplateID = VS.ValueStreamTemplateID
	WHERE VS.ValueStreamTemplateID = @ValueStreamTemplateID
		AND (
			VST.PlantID = @PlantID
			AND VS.IsDeleted = 0
			)
		AND VS.ValueStreamData=''
	ORDER BY VS.ValueStreamName
END
GO
