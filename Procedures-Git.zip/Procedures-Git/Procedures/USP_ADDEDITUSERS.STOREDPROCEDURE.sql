/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_AddEditUsers]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE TO ADD AND EDIT USER DETAILS
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					19-MAR-2020			KARTHIKEYAN KANDASAMY		PLANTID ADDED
ELPC_LH_002					25-MAR-2021			SIKHESH S					STANDARD RULES APPLIED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
EXEC [USP_AddEditUsers] 1,'kkn4cob',<<>>
*/
CREATE PROCEDURE [USP_AddEditUsers] (
	@PlantID INT
	,@CurrentUserNTID NVARCHAR(20)
	,@Users XML NULL
	)
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION ADDEDITUSERS

		DECLARE @CurrentDateTime DATETIME = (
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				)
			,@NTID NVARCHAR(20)

		SELECT Usr.value('(UserName/text())[1]', 'NVARCHAR(200)') AS UserName
			,Usr.value('(EmailAddress/text())[1]', 'NVARCHAR(200)') AS EmailAddress
			,Usr.value('(NTID/text())[1]', 'NVARCHAR(20)') AS NTID
			,Usr.value('(FirstName/text())[1]', 'NVARCHAR(100)') AS FirstName
			,Usr.value('(LastName/text())[1]', 'NVARCHAR(100)') AS LastName
			,Usr.value('(Role_roleID)[1]', 'INT') AS Role_RoleID
		INTO #TempUser
		FROM @Users.nodes('/ArrayOfUser/User') AS TEMPTABLE(Usr)

		--GET NTID OF THE USER FROM THE INPUT USERS LIST #TODO: THIS CHECK TO BE RE-VERIFIED, THIS CAN BE IGNORED,IF @CurrentUserNTID AND USER LIST CONTAINS SAME NTID IN ALL THE CASES
		SELECT TOP 1 @NTID = NTID
		FROM #TempUser

		IF EXISTS (
				SELECT TOP 1 NTID
				FROM #TempUser
				)
		BEGIN
			IF NOT EXISTS (
					SELECT NTID
					FROM T_MST_User WITH(NOLOCK)
					WHERE NTID = @NTID
						AND PlantID = @PlantID
					)
			BEGIN
				INSERT INTO T_MST_User (
					PlantID
					,UserName
					,Role_RoleID
					,EmployeeID
					,EmailAddress
					,NTID
					,FirstName
					,LastName
					,ModifiedAt
					)
				SELECT TOP 1 @PlantID
					,UserName
					,Role_RoleID
					,NULL
					,EmailAddress
					,NTID
					,FirstName
					,LastName
					,@CurrentDateTime
				FROM #TempUser
			END
			ELSE
			BEGIN
				UPDATE USR
				SET UserName = TempUSR.UserName
					,EmailAddress = TempUSR.EmailAddress
					,FirstName = TempUSR.FirstName
					,LastName = TempUSR.LastName
					,Role_RoleID = TempUSR.Role_RoleID
					,ModifiedAt = @CurrentDateTime
				FROM T_MST_User USR
				INNER JOIN #TempUser TempUSR ON USR.NTID = TempUSR.NTID
					AND USR.PlantID = @PlantID
				WHERE USR.NTID = @NTID
					AND USR.PlantID = @PlantID
			END
		END

		COMMIT TRANSACTION ADDEDITUSERS;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION ADDEDITUSERS;

		EXEC [USP_LogError] @PlantID
			,@CurrentUserNTID;
	END CATCH
END
GO


