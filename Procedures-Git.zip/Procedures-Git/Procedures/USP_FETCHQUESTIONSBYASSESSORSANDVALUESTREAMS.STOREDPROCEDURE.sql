/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchQuestionsByAssessorsAndValuestreams]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE TO FETCH QUESTIONS BY ASSESSORS AND VALUESTREAMS
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					22-MAR-2021			KARTHIKEYAN KANDASAMY		PLANTID ADDED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_FetchQuestionsByAssessorsAndValuestreams] 1, '1,2,3','4,5,6'
*/
CREATE PROCEDURE [USP_FetchQuestionsByAssessorsAndValuestreams] (
	@PlantID INT
	,@AssessorIDs NVARCHAR(MAX)
	,@ValueStreamIDs NVARCHAR(MAX)
	)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT QuestionID
		,PlantID
		,QuestionDisplayID
		,QuestionText
		,QuestionHintText
		,AnswerType_AnswerTypeID
		,ChoiceDisplayTypeID
		,IsFilledInChoiceAllowed
		,IsUniqueAnswerRequired
		,IsAnswerRequired
		,DefaultChoiceID
		,IsQuestionAlwaysActive
		,ActiveDateRangeFrom
		,ActiveDateRangeTo
		,IsTargetFrequencyDefined
		,TargetFrequencyTypeID
		,TargetFrequencyValue
		,Question_PriorityID
		,IsLocked
		-- ,Assigned_ValueStreamTemplateID
		-- ,Assigned_ValueStreamCategoryID
		-- ,Assigned_AssessorTemplateID
		,IsDeleted
		,CreatedAt
		,ModifiedAt
		,IsDefaultAnswerRequired
		,Assigned_AssessorID
		,IsAnswered
		,CreatedBy_NTID
		,ModifiedBy_NTID
		,DefaultChoice
	FROM T_TRN_Question Q WITH (NOLOCK)
	WHERE PlantID = @PlantID
		AND QuestionID IN (
			SELECT DISTINCT (AR.QuestionID)
			FROM T_LNK_AssignedAssessors AR WITH (NOLOCK)
			INNER JOIN T_LNK_AssignedValueStreams VS WITH (NOLOCK) ON AR.QuestionID = VS.QuestionID
			WHERE VS.ValueStreamID IN (
					(
						SELECT *
						FROM [fnSplit](@ValueStreamIDs)
						)
					)
				AND (
					(@AssessorIDs = '0')
					OR (
						@AssessorIDs <> '0'
						AND AR.AssessorID IN (
							(
								SELECT *
								FROM [fnSplit](@AssessorIDs)
								)
							)
						)
					)
				AND (AR.IsDeleted = 0)
				AND (VS.IsDeleted = 0)
			)
		AND (
			Q.IsDeleted = 0
			OR Q.IsDeleted IS NULL
			);
END
GO

