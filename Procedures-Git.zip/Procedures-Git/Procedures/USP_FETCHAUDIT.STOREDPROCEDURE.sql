/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchAudit]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE TO FETCH AUDIT DETAILS 
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					19-MAR-2021			Rajasekar S					PlantId,CurrentUserNTID added
ELPC_LH_002_CR01				28-JUN-2021			Rajasekar S					Calendar Recurrance option added
ELPC_LH_006					18-AUG-2023			 SUSHANTH					GLOBAL TAG
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_FetchAudit] 1,'FSM1COB'
*/
CREATE PROCEDURE [USP_FetchAudit] @PlantID INT    
 ,@CurrentUserNTID NVARCHAR(20) = NULL    
 ,@FromDate DATETIME = NULL             
 ,@ToDate DATETIME = NULL   
AS    
BEGIN    
 SET NOCOUNT ON;    
 
      select * into #AuditByNTID from (SELECT AuditId
				FROM [T_TRN_Audit] WITH(NOLOCK)
				WHERE CreatedBy_NTID = @CurrentUserNTID
					AND PlantID = @PlantID and IsDeleted=0
					AND  (StartDate Between  @FromDate and  @ToDate OR EndDate Between @FromDate and @ToDate or StartDate <  @FromDate AND EndDate > @ToDate)
				
         union 
		 				SELECT AuditId
				FROM T_TRN_Audit where AuditID in( Select AuditID from  T_LNK_Audit_OptionalAttendees WITH(NOLOCK)
				WHERE NTID = @CurrentUserNTID and IsDeleted=0)
					AND PlantID = @PlantID and IsDeleted=0
					AND  (StartDate Between  @FromDate and  @ToDate OR EndDate Between @FromDate and @ToDate or StartDate < @FromDate AND EndDate > @ToDate)
				
         union 
				SELECT AuditId
				FROM T_TRN_Audit where AuditID in( Select AuditID from  T_LNK_Audit_RequiredAttendees WITH(NOLOCK)
				WHERE NTID = @CurrentUserNTID and isDeleted=0)
					AND PlantID = @PlantID and IsDeleted=0
					AND  (StartDate Between  @FromDate and  @ToDate OR EndDate Between @FromDate and @ToDate or StartDate < @FromDate AND EndDate > @ToDate)
					) as tempq
select * into #filteredAudits from t_trn_Audit A where A.Auditid  in (select auditid from #AuditByNTID)

SELECT *,IIF(AnswerPercentage1 = 1 , 1, 0) AS IsAuditCompleted            
 INTO #tempLNK_Audit_AnsweredQuestions            
 FROM (            
  SELECT DISTINCT LNK.AuditID            
   ,LNK.AuditTemplateID  
   ,LNK.ValueStreamID  
   ,CONVERT(DATE, LNK.ModifiedAt) AS [AnsweredTimeStamp]            
   ,COUNT(QuestionID) AS TotalQuestionCount            
   ,COUNT(IIF(ISNULL(LNK.IsAnswered, 0) = 1, 1, NULL)) AS AnswerdQuestionCount            
   ,COUNT(IIF(ISNULL(LNK.IsAnswered, 0) = 0, 1, NULL)) AS UnAnswerdQuestionCount            
   ,CONVERT(INT, (1.0 * (COUNT(IIF(LNK.IsAnswered = 1, 1, NULL))) / (COUNT(QuestionID))) * 100) AS AnswerPercentage            
   ,LNK.IsAuditCompleted AS AnswerPercentage1  
   ,LNK.CreatedBy_NTID            
  FROM T_LNK_Audit_AnsweredQuestions LNK WITH (NOLOCK)            
  INNER JOIN #filteredAudits A WITH (NOLOCK) ON A.AuditID = LNK.AuditID       
   AND A.IsDeleted = 0            
   AND LNK.IsAuditActive = 1            
   AND A.PlantID = @PlantID            
   AND LNK.IsDeleted = 0            
   AND ((IsRecurring = 0  AND StartDate <= CONVERT(DATE, LNK.ModifiedAt)) OR IsRecurring = 1)            
  GROUP BY LNK.AuditID            
   ,LNK.AuditTemplateID   
   ,LNK.ValueStreamID  
   ,LNK.IsAuditCompleted  
   ,CONVERT(DATE, LNK.ModifiedAt)            
   ,LNK.CreatedBy_NTID            
  ) AS t            
  
 -- select * from #tempLNK_Audit_AnsweredQuestions  

 --EXEC [USP_PlantIDValidation] @PlantID = @PlantID    
 -- ,@ID = @AuditID    
 -- ,@Mode = 'AUDIT'    
 -- ,@CurrentUserNTID = @CurrentUserNTID    
 IF (    
   @CurrentUserNTID IS NULL    
   OR @CurrentUserNTID = ''    
   )    
 BEGIN    
  SELECT (    
    SELECT TOP 1 UserName    
    FROM T_MST_User WITH (NOLOCK)    
    WHERE PlantID = @PlantID    
     AND NTID = A.ModifiedBy_NTID    
    ) AS ModifiedBy    
   ,CASE     
    WHEN TT.TagTypeID = 1    
     THEN COALESCE('#' + TT.TagName, '')    
    WHEN TT.TagTypeID = 2    
     THEN COALESCE('#' + TT.TagName, '')    
    WHEN TT.TagTypeID = 3    
     THEN COALESCE('#' + TT.TagName, '')    
   WHEN TT.TagTypeID = 4    
     THEN COALESCE('#' + TT.TagName, '')    
    END AS TagDisplayName    
   ,(    
    SELECT TOP 1 TagName    
    FROM T_TRN_Tag WITH (NOLOCK)    
    WHERE PlantID = @PlantID    
     AND TT.TagID = A.TagID    
    ) AS TagName    
   ,(    
    SELECT TOP 1 UserName    
    FROM T_MST_User WITH (NOLOCK)    
    WHERE PlantID = @PlantID    
     AND NTID = A.CreatedBy_NTID    
    ) AS CreatedBy    
   ,TT.TagTypeID    
   ,A.AuditID    
   ,A.PlantID    
   ,A.StartDate    
   ,A.StartTime    
   ,A.EndDate    
   ,A.EndTime    
   ,A.IsRecurring    
   ,A.IsAllDay    
   ,A.ValueStreamID    
   ,A.Remarks    
   ,A.Location  
   ,LNK.AnsweredTimeStamp 
   ,LNK.IsAuditCompleted as IsAuditCompleted    
   ,A.TagID    
   ,A.CreatedAt    
   ,A.CreatedBy_NTID    
   ,A.ModifiedAt    
   ,A.ModifiedBy_NTID    
   ,A.IsDeleted    
   ,R.[RecurrenceTypeId] AS [Recurrence_TypeId]    
   ,R.[Interval] AS [Recurrence_Interval]    
   ,R.[DayOfWeek] AS [Recurrence_DayOfWeek]    
   ,R.[DayOfMonth] AS [Recurrence_DayOfMonth]    
   ,R.[WeekOfMonth] AS [Recurrence_WeekOfMonth]    
   ,R.[MonthOfYear] AS [Recurrence_MonthOfYear]    
  FROM #filteredAudits A WITH (NOLOCK)    
  LEFT JOIN #tempLNK_Audit_AnsweredQuestions LNK  WITH(NOLOCK) ON LNK.AuditID = A.AuditID 
  INNER JOIN T_TRN_Tag TT WITH (NOLOCK) ON A.TagID = TT.TagID    
  LEFT JOIN [T_TRN_Recurrence] R WITH (NOLOCK) ON A.AuditID = R.AuditID 
             

   AND A.PlantID = R.PlantID    
  WHERE (    
    A.PlantID = @PlantID    
    AND TT.PlantID = @PlantID    
    AND A.IsDeleted = 0    
    )    
 END    
 ELSE    
 BEGIN    
  SELECT (    
    SELECT TOP 1 UserName    
    FROM T_MST_User WITH (NOLOCK)    
    WHERE PlantID = @PlantID    
     AND NTID = A.ModifiedBy_NTID    
    ) AS ModifiedBy    
   ,CASE     
    WHEN TT.TagTypeID = 1    
     THEN COALESCE('#' + TT.TagName, '')    
    WHEN TT.TagTypeID = 2    
     THEN COALESCE('#' + TT.TagName, '')    
    WHEN TT.TagTypeID = 3    
     THEN COALESCE('#' + TT.TagName, '')    
  WHEN TT.TagTypeID = 4   
     THEN COALESCE('#' + TT.TagName, '')    
    END AS TagDisplayName    
   ,(    
    SELECT TOP 1 TagName    
    FROM T_TRN_Tag WITH (NOLOCK)    
    WHERE PlantID = @PlantID    
     AND TT.TagID = A.TagID    
    ) AS TagName    
   ,(    
    SELECT TOP 1 UserName    
    FROM T_MST_User WITH (NOLOCK)    
    WHERE PlantID = @PlantID    
     AND NTID = A.CreatedBy_NTID    
    ) AS CreatedBy    
   ,TT.TagTypeID    
   ,A.AuditID    
   ,A.PlantID    
   ,A.StartDate    
   ,A.StartTime    
   ,A.EndDate    
   ,A.EndTime    
   ,A.IsRecurring    
   ,A.IsAllDay    
   ,A.ValueStreamID    
   ,A.Remarks    
   ,A.Location   
   ,LNK.AnsweredTimeStamp   
   ,LNK.IsAuditCompleted as IsAuditCompleted   
   ,A.TagID    
   ,A.CreatedAt    
   ,A.CreatedBy_NTID     
   ,A.ModifiedAt    
   ,A.ModifiedBy_NTID    
   ,A.IsDeleted    
   ,R.[RecurrenceTypeId] AS [Recurrence_TypeId]    
   ,R.[Interval] AS [Recurrence_Interval]    
   ,R.[DayOfWeek] AS [Recurrence_DayOfWeek]    
   ,R.[DayOfMonth] AS [Recurrence_DayOfMonth]    
   ,R.[WeekOfMonth] AS [Recurrence_WeekOfMonth]    
   ,R.[MonthOfYear] AS [Recurrence_MonthOfYear]    
  FROM #filteredAudits A WITH (NOLOCK)    
  LEFT JOIN #tempLNK_Audit_AnsweredQuestions LNK  WITH(NOLOCK) ON LNK.AuditID = A.AuditID
  INNER JOIN T_TRN_Tag TT WITH (NOLOCK) ON A.TagID = TT.TagID    
  LEFT JOIN [T_TRN_Recurrence] R WITH (NOLOCK) ON A.AuditID = R.AuditID    
              

   AND A.PlantID = R.PlantID    
  WHERE (    
    A.PlantID = @PlantID    
    AND TT.PlantID = @PlantID    
    AND A.IsDeleted = 0   
    )    
   AND A.AuditID IN (    
    SELECT AuditID    
    FROM T_TRN_Audit WITH (NOLOCK)    
    WHERE PlantID = @PlantID    
     AND (    
      CreatedBy_NTID = @CurrentUserNTID    
      OR ModifiedBy_NTID = @CurrentUserNTID    
      )    
        
    UNION    
        
    SELECT RA.AuditID    
    FROM T_LNK_Audit_RequiredAttendees RA WITH (NOLOCK)    
    INNER JOIN T_TRN_Audit A WITH (NOLOCK) ON RA.AuditID = A.AuditID    
    WHERE A.PlantID = @PlantID    
     AND RA.NTID = @CurrentUserNTID    
     AND RA.IsDeleted = 0    
        
    UNION    
        
    SELECT OA.AuditID    
    FROM T_LNK_Audit_OptionalAttendees OA WITH (NOLOCK)    
    INNER JOIN T_TRN_Audit A WITH (NOLOCK) ON OA.AuditID = A.AuditID    
    WHERE A.PlantID = @PlantID    
     AND OA.NTID = @CurrentUserNTID    
     AND OA.IsDeleted = 0    
    )    
 END    
END 
GO