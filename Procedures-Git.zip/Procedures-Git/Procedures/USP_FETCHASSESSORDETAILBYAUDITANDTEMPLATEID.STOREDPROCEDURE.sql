/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchAssessorDetailByAuditAndTemplateID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING ASSESSOR DETAIL BY AUDIT AND TEMPLATE ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			Rajasekar S					PlantId,CurrentUserNTID added

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_FetchAssessorDetailByAuditAndTemplateID] 1,1,1,'OSP4KOR'
*/
CREATE PROCEDURE [USP_FetchAssessorDetailByAuditAndTemplateID] @PlantID INT
	,@AuditID INT
	,@TemplateID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	SET NOCOUNT ON;

	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = @AuditID
		,@Mode = 'AUDIT'
		,@CurrentUserNTID = @CurrentUserNTID

	SELECT AD.AssessorName
		,AD.UserName
		,AD.NTID
		,AD.IsMandatoryAssessor
		,AD.IsDeleted
		,AD.AuditID
		,AD.AuditTemplateID
	FROM T_LNK_AuditTemplate_AssessorDetail AD WITH (NOLOCK)
	INNER JOIN T_TRN_Audit A WITH (NOLOCK) ON A.AuditID = AD.AuditID
	WHERE AD.AuditID = @AuditID
		AND A.PlantID = @PlantID
		AND AD.AuditTemplateID = @TemplateID
		AND AD.IsDeleted = 0
END
GO


