SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [USP_FetchTag]
AS
BEGIN
	SELECT (
			SELECT TOP 1 UserName
			FROM T_MST_User
			WHERE NTID = TT.ModifiedBy_NTID
			) AS ModifiedBy
		,(
			SELECT TOP 1 UserName
			FROM T_MST_User
			WHERE NTID = TT.CreatedBy_NTID
			) AS CreatedBy
		,CASE 
			WHEN TT.TagTypeID = 1
				THEN COALESCE('#' + TT.TagName, '')
			WHEN TT.TagTypeID = 2
				THEN COALESCE('@' + TT.TagName, '')
			WHEN TT.TagTypeID = 3
				THEN COALESCE('$' + TT.TagName, '')
			END AS TagDisplayName
		,*
	FROM T_TRN_Tag TT
	FULL JOIN [T_LNK_Custom_QuestionsTags] CQ ON CQ.TagID = TT.TagID
		AND CQ.IsDeleted = 0
	WHERE TT.TagID IS NOT NULL
		AND (TT.IsDeleted = 0)
	ORDER BY ModifiedAt DESC
END
GO


