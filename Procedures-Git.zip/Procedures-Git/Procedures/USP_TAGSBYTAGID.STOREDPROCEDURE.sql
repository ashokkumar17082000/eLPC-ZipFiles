/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_TagsByTagID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING TAGS BY TAGID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					22-MAR-2021			KARTHIKEYAN KANDASAMY		PLANTID ADDED
ELPC_LH_003					18-AUG-2023			SUSHANTH 		GLOBAL TAG
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_TagsByTagID] 1, 1
*/
CREATE PROCEDURE [USP_TagsByTagID] (    
 @PlantID INT    
 ,@TagID INT    
 )    
AS    
BEGIN    
 SET NOCOUNT ON;    
    
 SELECT LNK.LinkedTagID AS TagID    
  ,CASE     
   WHEN TT.TagTypeID = 1    
    THEN COALESCE('#' + TT.TagName, '')    
   WHEN TT.TagTypeID = 2    
    THEN COALESCE('#' + TT.TagName, '')    
   WHEN TT.TagTypeID = 3    
    THEN COALESCE('#' + TT.TagName, '')  
	WHEN TT.TagTypeID = 4    
    THEN COALESCE('#' + TT.TagName, '') 
    END AS TagDisplayName    
  ,(    
   SELECT TOP 1 TagName    
   FROM T_TRN_Tag T    
   WHERE T.TagID = LNK.LinkedTagID    
    AND T.PlantID = @PlantID    
   ) AS TagName    
 FROM T_LNK_Tag_AssignedQuestionsTags LNK WITH (NOLOCK)    
 INNER JOIN T_TRN_Tag TT WITH (NOLOCK) ON LNK.LinkedTagID = TT.TagID    
  AND TT.PlantID = @PlantID    
 WHERE (    
   LNK.TagID = @TagID    
   AND LNK.LinkedTagID IS NOT NULL    
   AND LNK.IsDeleted = 0    
   );    
END    

GO