/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchAuditQuestionsByCurrentAssessorAndTemplateID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING QUESTIONS BY CURRENT ASSESSOR AND TEMPLATE ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY				INITIAL VERSION
ELPC_LH_002					23-MAR-2021			Rajasekar S					PlantId,CurrentUserNTID added
ELPC_LH_002					24-AUG-2022			ASHOK KUMAR R B					Question Load logic changed based on T_LNK_Tag_AssignedQuestionsTags 
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_FetchAuditQuestionsByCurrentAssessorAndTemplateID] 1,161,'FSM1COB'
*/
CREATE PROCEDURE [USP_FetchAuditQuestionsByCurrentAssessorAndTemplateID] @PlantID INT
	,@AuditID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	SET NOCOUNT ON;

	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = @AuditID
		,@Mode = 'AUDIT'
		,@CurrentUserNTID = @CurrentUserNTID

	DECLARE @TemplateID INT;
	DECLARE @tagid INT;

	SELECT @tagid = tagid
	FROM T_TRN_Audit
	WHERE auditid = @AuditID AND PlantID=@PlantID

	--select @tagid
	SET @TemplateID = (
			SELECT Max(AQ.AuditTemplateID)
			FROM T_LNK_Audit_AnsweredQuestions AQ WITH (NOLOCK)
			INNER JOIN T_TRN_Audit A WITH (NOLOCK) ON A.AuditID = AQ.AuditID
			WHERE AQ.AuditID = @AuditID
				AND A.PlantID = @PlantID
				AND AQ.CreatedBy_NTID = @CurrentUserNTID
				AND (
					AQ.IsAuditCompleted = 0
					OR AQ.IsAuditCompleted IS NULL
					)
			)

	SELECT AQ.AuditID
		,AQ.QuestionID
		,Q.QuestionDisplayID
		,AQ.CreatedAt
		,AQ.ModifiedAt
		,AQ.AnswerTypeID
		,AQ.IsAnswered
		,AQ.Answer
		,AQ.CreatedBy_NTID
		,AQ.ModifiedBy_NTID
		,AQ.IsAnswerRequired
		,AQ.AuditTemplateID
		,AQ.ID
		,Q.QuestionText
		,Q.QuestionHintText
		,Q.IsAnswerRequired
		,Q.IsDefaultAnswerRequired
		,Q.DefaultChoiceID
	FROM T_LNK_Audit_AnsweredQuestions AQ WITH (NOLOCK)
	INNER JOIN T_TRN_Question Q WITH (NOLOCK) ON AQ.QuestionID = Q.QuestionID
	INNER JOIN T_TRN_Audit A WITH (NOLOCK) ON A.AuditID = AQ.AuditID
	LEFT JOIN T_LNK_Audit_AssignedQuestions AAQ WITH (NOLOCK) ON AAQ.QuestionID = Q.QuestionID
		AND AAQ.AuditID = AQ.AuditID
	LEFT JOIN T_LNK_Tag_AssignedQuestionsTags RQ WITH (NOLOCK) ON Q.QuestionID = RQ.QuestionID
		AND RQ.TagID = @tagid and RQ.IsDeleted=0
	WHERE AQ.AuditID = @AuditID
		AND Q.PlantID = @PlantID
		AND (
			AQ.IsAuditCompleted = 0
			OR AQ.IsAuditCompleted IS NULL
			)
		AND AQ.AuditTemplateID = @TemplateID
	ORDER BY case when RQ.RandomQuestionOrder  is null then 998  end, RQ.RandomQuestionOrder
,Question_PriorityID 
	,TargetFrequencyTypeID
	,ChoiceDisplayTypeID DESC
	,QuestionID
END
GO