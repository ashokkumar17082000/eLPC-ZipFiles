/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_Restore_T_TRN_AssessorHistory]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RESTORING ASSESSOR HISTORY
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					18-MAR-2021			KARTHIKEYAN KANDASAMY		PLANTID ADDED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_Restore_T_TRN_AssessorHistory] 1,3,'kkn4cob'
*/
CREATE PROCEDURE [USP_Restore_T_TRN_AssessorHistory] (
	@PlantID INT
	,@AssessorTemplateHistoryID INT
	,@CurrentUserNTID NVARCHAR(20)
	)
AS
BEGIN
	SET NOCOUNT ON;
	SET LOCK_TIMEOUT 10000;

	BEGIN TRY
		BEGIN TRANSACTION TRNRESTOREASHISTORY

		--to disable trigger during history/restore
		--ALTER TABLE [T_TRN_AssessorTemplate] DISABLE TRIGGER [TR_HISTORYFOR_T_TRN_AssessorTemplate]
		--ALTER TABLE [T_TRN_Assessor] DISABLE TRIGGER [TR_HISTORYFOR_T_TRN_Assessor]
		IF EXISTS (
				SELECT 1
				FROM T_TRN_AssessorTemplateHistory WITH(NOLOCK)
				WHERE AssessorTemplateHistoryID = @AssessorTemplateHistoryID
					AND PlantID = @PlantID
				)
		BEGIN
			-- Update [T_TRN_AssessorTemplate]
			DECLARE @AssessorTemplateID INT = NULL;
			DECLARE @AssessorTemplateName NVARCHAR(50) = NULL;
			DECLARE @IsLocked BIT = NULL;
			DECLARE @CreatedAt DATETIME = NULL;
			DECLARE @IsTargetFrequencyDefined BIT = NULL;
			DECLARE @IsDeleted BIT = NULL;
			DECLARE @AssessorTemplateDisplayID INT = NULL;
			DECLARE @CreatedBy_NTID NVARCHAR(20);
			DECLARE @Plant_ID INT = NULL;
			DECLARE @Modified_At DATETIME = (
					SELECT FormattedDateTime
					FROM [fnGetDateTime](@PlantID)
					);

			SELECT TOP 1 @AssessorTemplateID = AssessorTemplateID
				,@AssessorTemplateDisplayID = AssessorTemplateDisplayID
				,@AssessorTemplateName = AssessorTemplateName
				,@IsLocked = IsLocked
				,@CreatedAt = CreatedAt
				,@IsTargetFrequencyDefined = IsTargetFrequencyDefined
				,@IsDeleted = IsDeleted
				,@AssessorTemplateDisplayID = AssessorTemplateDisplayID
				,@CreatedBy_NTID = CreatedBy_NTID
				,@Plant_ID = PlantID
			FROM T_TRN_AssessorTemplateHistory WITH(NOLOCK)
			WHERE AssessorTemplateHistoryID = @AssessorTemplateHistoryID
				AND PlantID = @PlantID;

			UPDATE T_TRN_AssessorTemplate
			SET AssessorTemplateName = @AssessorTemplateName
				,AssessorTemplateDisplayID = @AssessorTemplateDisplayID
				,IsLocked = @IsLocked
				,CreatedAt = @CreatedAt
				,IsTargetFrequencyDefined = @IsTargetFrequencyDefined
				,IsDeleted = @IsDeleted
				,CreatedBy_NTID = @CreatedBy_NTID
				,ModifiedBy_NTID = @CurrentUserNTID
				,ModifiedAt = @Modified_At
				,PlantID = @Plant_ID
			WHERE AssessorTemplateID = @AssessorTemplateID
				AND PlantID = @PlantID;

			--END - Update [T_TRN_AssessorTemplate]
			-- Update [T_TRN_Assessor]
			DECLARE @AssessorID INT = NULL;
			DECLARE @AssessorName NVARCHAR(50) = NULL;
			DECLARE @TargetFrequencyValue NVARCHAR(50) = NULL;
			DECLARE @TargetFrequencyTypeID INT = NULL;
			DECLARE @TargetFrequencyLowLimit INT = NULL;
			DECLARE @Category NVARCHAR(100) = NULL;

			SET @IsDeleted = NULL;

			-- Remove the data if that not exists(may be not available on that time)
			UPDATE T_TRN_Assessor
			SET IsDeleted = 1
			WHERE AssessorTemplateID = @AssessorTemplateID
				AND AssessorID NOT IN (
					SELECT AssessorID
					FROM T_TRN_AssessorHistory WITH(NOLOCK)
					WHERE IsDeleted = 0
						AND AssessorTemplateHistoryID = @AssessorTemplateHistoryID
					);

			DECLARE CUR_Accessor CURSOR FORWARD_ONLY
			FOR
			SELECT AssessorID
				,AssessorName
				,TargetFrequencyValue
				,AssessorTemplateID
				,TargetFrequencyTypeID
				,TargetFrequencyLowLimit
				,IsDeleted
				,Category
			FROM T_TRN_AssessorHistory WITH(NOLOCK)
			WHERE AssessorTemplateHistoryID = @AssessorTemplateHistoryID
				AND (IsDeleted = 0);

			OPEN CUR_Accessor;

			FETCH NEXT
			FROM CUR_Accessor
			INTO @AssessorID
				,@AssessorName
				,@TargetFrequencyValue
				,@AssessorTemplateID
				,@TargetFrequencyTypeID
				,@TargetFrequencyLowLimit
				,@IsDeleted
				,@Category;

			WHILE @@FETCH_STATUS = 0
			BEGIN
				IF EXISTS (
						SELECT 1
						FROM T_TRN_Assessor WITH(NOLOCK)
						WHERE AssessorID = @AssessorID
						)
				BEGIN
					-- Update the Assessor data if that exists
					UPDATE T_TRN_Assessor
					SET AssessorName = @AssessorName
						,TargetFrequencyValue = @TargetFrequencyValue
						,AssessorTemplateID = @AssessorTemplateID
						,TargetFrequencyTypeID = @TargetFrequencyTypeID
						,TargetFrequencyLowLimit = @TargetFrequencyLowLimit
						,IsDeleted = @IsDeleted
						,Category = @Category
						,ModifiedAt = @Modified_At
					WHERE AssessorID = @AssessorID;
				END

				FETCH NEXT
				FROM CUR_Accessor
				INTO @AssessorID
					,@AssessorName
					,@TargetFrequencyValue
					,@AssessorTemplateID
					,@TargetFrequencyTypeID
					,@TargetFrequencyLowLimit
					,@IsDeleted
					,@Category;
			END

			CLOSE CUR_Accessor;

			DEALLOCATE CUR_Accessor;

			--END - Update [T_TRN_Assessor]
			COMMIT TRANSACTION TRNRESTOREASHISTORY;
		END
		ELSE
		BEGIN
			ROLLBACK TRANSACTION TRNRESTOREASHISTORY;
		END
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNRESTOREASHISTORY;

		EXEC [USP_LogError] @PlantID
			,@CurrentUserNTID;
	END CATCH
END
GO


