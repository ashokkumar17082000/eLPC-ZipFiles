SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [USP_SaveEmployee] (
	@ID VARCHAR(50)
	,@Name VARCHAR(50)
	,@Dept VARCHAR(50)
	,@Address VARCHAR(50)
	)
AS
BEGIN
	INSERT INTO tblTestDB (
		ID
		,Name
		,Dept
		,Address
		)
	VALUES (
		@ID
		,@Name
		,@Dept
		,@Address
		)
END
GO


