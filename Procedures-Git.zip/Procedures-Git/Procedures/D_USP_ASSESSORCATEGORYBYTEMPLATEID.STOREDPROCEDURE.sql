SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [USP_AssessorCategoryByTemplateID] @AssessorTemplateID INT
AS
BEGIN
	SELECT *
	FROM T_TRN_AssessorTemplate
	WHERE AssessorTemplateID = @AssessorTemplateID
END
GO


