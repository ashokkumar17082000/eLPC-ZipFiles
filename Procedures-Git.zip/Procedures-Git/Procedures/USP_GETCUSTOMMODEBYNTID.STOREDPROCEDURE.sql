/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_GetCustomModeByNTID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE TO GET CUSTOM MODE BY NTID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					28-MAR-2021			SIKHESH S					ADDITIONAL INPUT PARAMATERS INCLUDED, OUTPUT PARAMETERS REVISED, STANDARD RULES APPLIED
ELPC_LH_006					18-AUG-2023			ASHOK KUMAR R B					GLOBAL TAG ADDITIONAL PARAMETERS

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_GetCustomModeByNTID] 1, 'OSP4KOR'
*/
CREATE PROCEDURE [USP_GetCustomModeByNTID] (
	@PlantID INT
	,@CurrentUserNTID NVARCHAR(20)
	)
AS
BEGIN
	SET NOCOUNT ON;

	--FOR TAGS
	SELECT TT.TagID
		,TT.TagDisplayID
		,TT.TagName
		,*
		,CASE 
			WHEN TT.TagTypeID = 1
				THEN COALESCE('#' + TT.TagName, '')
			WHEN TT.TagTypeID = 2
				THEN COALESCE('#' + TT.TagName, '')
			WHEN TT.TagTypeID = 3
				THEN COALESCE('#' + TT.TagName, '')
		    WHEN TT.TagTypeID = 4
				THEN COALESCE('#' + TT.TagName, '')
			END AS TagDisplayName
		,CQ.CustomQuestionTagsID
		,TC.CreatedBy_NTID
	FROM [T_TRN_Tag] TT WITH (NOLOCK)
	INNER JOIN [T_LNK_Custom_QuestionsTags] CQ WITH (NOLOCK) ON CQ.TagID = TT.TagID
	INNER JOIN [T_TRN_CustomMode] TC WITH (NOLOCK) ON TC.CustomModeID = CQ.CustomModeID
		AND TC.PlantID = @PlantID
	WHERE CQ.TagID IS NOT NULL
		AND TC.CreatedBy_NTID = @CurrentUserNTID
		AND CQ.IsDeleted <> 1
		AND TT.PlantID = @PlantID
		AND TT.IsDeleted <> 1

	--FOR QUESTIONS
	SELECT DISTINCT TQ.QuestionID
		,TQ.QuestionDisplayID
		,TQ.QuestionText
		,CQ.CustomQuestionTagsID
		,TC.CreatedBy_NTID
		,(
			SELECT DISTINCT abc = STUFF((
						SELECT ',' + HyperLinkURL
						FROM [T_TRN_HintHyperLink] WITH (NOLOCK)
						WHERE QuestionID = TQ.QuestionID
							AND IsDeleted = 0
						FOR XML PATH('')
						, TYPE).value('.', 'NVARCHAR(MAX)'), 1, 1, '') 
			) AS HyperLinkURL
		,TQ.QuestionHintText
	FROM T_TRN_Question TQ WITH (NOLOCK)
	INNER JOIN [T_LNK_Custom_QuestionsTags] CQ WITH (NOLOCK) ON CQ.QuestionID = TQ.QuestionID
	INNER JOIN [T_TRN_CustomMode] TC WITH (NOLOCK) ON TC.CustomModeID = CQ.CustomModeID
		AND TC.PlantID = @PlantID
	LEFT JOIN [T_TRN_HintHyperLink] TTH WITH (NOLOCK) ON TTH.QuestionID = TQ.QuestionID
		AND TTH.IsDeleted <> 1
	WHERE CQ.QuestionID IS NOT NULL
		AND TC.CreatedBy_NTID = @CurrentUserNTID
		AND CQ.IsDeleted <> 1
		AND TQ.PlantID = @PlantID
		AND TQ.IsDeleted <> 1
END
GO