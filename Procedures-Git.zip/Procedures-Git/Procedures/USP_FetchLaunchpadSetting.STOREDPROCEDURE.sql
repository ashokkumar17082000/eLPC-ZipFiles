/****** Object:  StoredProcedure [USP_FetchLaunchpadSetting]    Script Date: 08.03.2024 09:12:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--exec [dbo].[USP_FetchLaunchpadSetting] 2
CREATE PROCEDURE [USP_FetchLaunchpadSetting] (@PlantID INT)
AS

BEGIN
declare @HistoryID int;
	SET NOCOUNT ON;
	
select @HistoryID=ISNULL(MAX(HistoryID),0) from T_TRN_LaunchpadSetting

	
   SELECT   [TextName] as reportTextName
           ,[ValidURL] as reportTextURL
           ,[IsDeleted]
		   ,[ModifiedAt]
		   ,[CreatedAt]
		   ,[PlantID]
		   ,(SELECT TOP 1 UserName
			FROM T_MST_User WITH (NOLOCK)
			WHERE NTID =CreatedBy
				AND PlantID = @PlantID
			 )AS CreatedBy
		   FROM T_TRN_LaunchpadSetting WITH (NOLOCK)
	
	WHERE (
			PlantID = @PlantID
		   AND IsDeleted = 0
		  -- AND HistoryID=@HistoryID
			);
/* SELECT   [TextName] as reportTextName
           ,[ValidURL] as reportTextURL
           ,[IsDeleted]
		   ,[ModifiedAt]
		   ,[CreatedAt]
		   ,[PlantID]
		   ,[HistoryID]
		   ,(SELECT TOP 1 UserName
			FROM T_MST_User WITH (NOLOCK)
			WHERE NTID =CreatedBy
				AND PlantID = @PlantID
			 )AS CreatedBy
		   FROM T_TRN_LaunchpadSettings WITH (NOLOCK)
	
	WHERE (
			PlantID = @PlantID
		   AND IsDeleted = 0);*/
		
END
GO
