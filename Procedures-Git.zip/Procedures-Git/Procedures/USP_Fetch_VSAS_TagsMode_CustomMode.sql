/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_Fetch_VSAS_TagsMode_CustomMode]
///AUTHOR                       : Venkatesh and ASHOK KUMAR R B
///CREATED DATE                 : 14-july-2022
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING VSAS Combi,Tag,Question based on userprofile
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					14-July-2022			 Venkatesh and ASHOK KUMAR R B		INITIAL VERSION
************************************************************************************************************ 
///</SUMMARY>5
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_Fetch_VSAS_TagsMode_CustomMode] 2,1,'EGV1COB'
*/
CREATE PROCEDURE [USP_Fetch_VSAS_TagsMode_CustomMode] (
	@Condition INT
	,@PlantID INT
	,@CurrentUserNTID NVARCHAR(20)
	)
AS
BEGIN
	-- VSAS_Combination		==> VSASCombination
	-- VSAS_QuesttionIDs	==> VSASCombination +  Matching TagIDs
	-- VSAS_TagIDs			==> VSASCombination +  Matching QuestionIDs
	-- Starts ****** Combining & forming VS & AS for fetching available combination *****************
	SELECT *
	INTO #VSASCombination
	FROM (
		SELECT vsc.ValueStreamTemplateID
			,vsc.ValueStreamID
			,ac.AssessorTemplateID
			,ac.AssessorID
			,vsc.IsForgotValueStream
			,ac.IsForgotAssessor
			,vsc.SessionID AS VSSessionID
			,ac.SessionID AS ASSessionID
		FROM [T_TRN_ValueStreamConfig] vsc WITH (NOLOCK)
		CROSS JOIN [T_TRN_AssessorConfig] ac WITH (NOLOCK)
		WHERE vsc.IsDeleted = 0
			AND ac.IsDeleted = 0
			AND vsc.PlantID = @PlantID
			AND ac.PlantID = @PlantID
			AND vsc.User_NTID = @CurrentUserNTID
			AND ac.User_NTID = @CurrentUserNTID
			AND vsc.ValueStreamID IN (
				SELECT c.ValueStreamID
				FROM [T_TRN_ValueStreamConfig] c WITH (NOLOCK)
				INNER JOIN T_TRN_ValueStreamTemplate vst WITH (NOLOCK) ON vst.PlantID = @PlantID
					AND vst.ValueStreamTemplateID = c.ValueStreamTemplateID
					AND vst.IsDeleted = 0
				INNER JOIN T_TRN_ValueStream vs WITH (NOLOCK) ON vs.ValueStreamID = c.ValueStreamID
					AND vs.IsDeleted = 0
				INNER JOIN T_TRN_ValueStreamCategory cat WITH (NOLOCK) ON c.ValueStreamTemplateID = cat.ValueStreamTemplateID
					AND cat.IsDeleted = 0
				WHERE c.PlantID = @PlantID
					AND c.User_NTID = @CurrentUserNTID
					AND c.IsDeleted = 0
				)
			AND ac.AssessorID IN (
				SELECT DISTINCT c.AssessorID
				FROM T_TRN_AssessorConfig c WITH (NOLOCK)
				INNER JOIN T_TRN_AssessorTemplate ast WITH (NOLOCK) ON ast.PlantID = @PlantID
					AND ast.AssessorTemplateID = c.AssessorTemplateID
					AND ast.IsDeleted = 0
				INNER JOIN T_TRN_Assessor a WITH (NOLOCK) ON a.AssessorID = c.AssessorID
					AND a.IsDeleted = 0
				WHERE c.PlantID = @PlantID
					AND c.User_NTID = @CurrentUserNTID
					AND c.IsDeleted = 0
				)
		) AS VSASCombination
END

-- Ends ****** Combing & forming VS & AS for fetching available combination *****************
IF @Condition = 1 --'VSAS_Combination'
BEGIN
	SELECT *
	FROM #VSASCombination
END
ELSE IF @Condition = 2 --'VSASCombination +  Matching TagIDs'
BEGIN
	--print 'Inside condition 2 tag in Custom mode'
	-- Starts ****** Preparing Tag List by applying VS & AS available combination *****************
	SELECT *
	INTO #MyTags
	FROM (
		SELECT DISTINCT T.TagID
		FROM #VSASCombination VSAS WITH (NOLOCK)
		INNER JOIN T_LNK_Tag_AssignedValueStreams LVS WITH (NOLOCK) ON VSAS.ValueStreamID = LVS.ValueStreamID
			AND LVS.IsDeleted = 0
		INNER JOIN T_LNK_Tag_AssignedAssessors LAS WITH (NOLOCK) ON VSAS.AssessorID = LAS.AssessorID
			AND LAS.IsDeleted = 0
			AND LVS.TagID = LAS.TagID
		INNER JOIN T_TRN_ValueStream VS WITH (NOLOCK) ON VS.ValueStreamID = LVS.ValueStreamID
			AND VSAS.ValueStreamTemplateID = VS.ValueStreamTemplateID
			AND VS.IsDeleted = 0
		INNER JOIN T_TRN_Assessor A WITH (NOLOCK) ON A.AssessorID = LAS.AssessorID
			AND VSAS.AssessorTemplateID = A.AssessorTemplateID
			AND A.IsDeleted = 0
		INNER JOIN T_TRN_Tag T WITH (NOLOCK) ON T.TagID = LVS.TagID
			AND T.PlantID = @PlantID
			AND T.IsDeleted = 0
		) AS MyTags

	--ORDER BY Q.Question_PriorityID ASC
	--	,ISNULL(Q.TargetFrequencyTypeID, 99) ASC
	--	,Q.TargetFrequencyValue DESC
	--	,DS.AnswerCount ASC
	--	,DS.NegativeAnswerCount DESC
	--	,NEWID()
	--OFFSET 0 ROWS 
	SELECT *
	FROM #MyTags
END
ELSE IF @Condition = 4 --'VSASCombination +  Matching TagIDs'
BEGIN
	--print 'Inside condition 2 tag in Custom mode'
	-- Starts ****** Preparing Tag List by applying VS & AS available combination *****************
	SELECT *
	INTO #MyTags1
	FROM (
		SELECT DISTINCT T.TagID
		FROM #VSASCombination VSAS WITH (NOLOCK)
		INNER JOIN T_LNK_Tag_AssignedValueStreams LVS WITH (NOLOCK) ON VSAS.ValueStreamID  IN (SELECT valuestreamid from T_TRN_ValueStream where valuestreamtemplateID=vsas.ValueStreamTemplateID and isdeleted=0)
			AND LVS.IsDeleted = 0
		INNER JOIN T_LNK_Tag_AssignedAssessors LAS WITH (NOLOCK) ON VSAS.AssessorID IN (SELECT assessorid from T_TRN_Assessor where AssessorID=vsas.AssessorID and isdeleted=0)
			AND LAS.IsDeleted = 0
			AND LVS.TagID = LAS.TagID
		INNER JOIN T_TRN_ValueStream VS WITH (NOLOCK) ON VS.ValueStreamID = LVS.ValueStreamID
			AND VSAS.ValueStreamTemplateID = VS.ValueStreamTemplateID
			AND VS.IsDeleted = 0
		INNER JOIN T_TRN_Assessor A WITH (NOLOCK) ON A.AssessorID = LAS.AssessorID
			AND VSAS.AssessorTemplateID = A.AssessorTemplateID
			AND A.IsDeleted = 0
		INNER JOIN T_TRN_Tag T WITH (NOLOCK) ON T.TagID = LVS.TagID
			AND T.PlantID = @PlantID
			AND T.IsDeleted = 0
		) AS MyTags1

	--ORDER BY Q.Question_PriorityID ASC
	--	,ISNULL(Q.TargetFrequencyTypeID, 99) ASC
	--	,Q.TargetFrequencyValue DESC
	--	,DS.AnswerCount ASC
	--	,DS.NegativeAnswerCount DESC
	--	,NEWID()
	--OFFSET 0 ROWS 
	SELECT *
	FROM #MyTags1
END


ELSE IF @Condition = 3 --'VSASCombination +  Matching QuestionIDs'
BEGIN
	-- Starts ****** Preparing Questionlist by applying VS & AS available combination *****************
	SELECT *
	INTO #FilteredQuestion
	FROM (
		SELECT Q.QuestionID
		FROM #VSASCombination VSAS WITH (NOLOCK)
		INNER JOIN T_LNK_AssignedValueStreams LVS WITH (NOLOCK) ON VSAS.ValueStreamID = LVS.ValueStreamID
			AND LVS.IsDeleted = 0
		INNER JOIN T_LNK_AssignedAssessors LAS WITH (NOLOCK) ON VSAS.AssessorID = LAS.AssessorID
			AND LAS.IsDeleted = 0
			AND LVS.QuestionID = LAS.QuestionID
		INNER JOIN T_TRN_ValueStream VS WITH (NOLOCK) ON VS.ValueStreamID = LVS.ValueStreamID
			AND VSAS.ValueStreamTemplateID = VS.ValueStreamTemplateID
			AND VS.IsDeleted = 0
		INNER JOIN T_TRN_Assessor A WITH (NOLOCK) ON A.AssessorID = LAS.AssessorID
			AND VSAS.AssessorTemplateID = A.AssessorTemplateID
			AND A.IsDeleted = 0
		INNER JOIN T_TRN_Question Q WITH (NOLOCK) ON Q.QuestionID = LVS.QuestionID
			AND Q.PlantID = @PlantID
			AND Q.IsDeleted = 0
			AND (
				(Q.IsQuestionAlwaysActive = 1)
				OR (
					Q.IsQuestionAlwaysActive = 0
					AND (
						CAST((
								SELECT FormattedDateTime
								FROM fnGetDateTime(@PlantID)
								) AS DATE) >= CAST(Q.ActiveDateRangeFrom AS DATE)
						)
					AND (
						CAST((
								SELECT FormattedDateTime
								FROM fnGetDateTime(@PlantID)
								) AS DATE) <= CAST(Q.ActiveDateRangeTo AS DATE)
						)
					)
				)
		) AS QuestionList

	SELECT *
	FROM #FilteredQuestion
		
END

GO


