/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_AuditByAuditID]   
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING AUDIT BY AUDIT ID
///MODIFICATION HISTORY            :  
************************************************************************************************************ 
///REF                        DATE                MODIFIED BY                    CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001                    25-NOV-2020            JANARTHANAN KRISHNASAMY        INITIAL VERSION
ELPC_LH_002                    23-MAR-2021            Rajasekar S                    PlantId,CurrentUserNTID added, logic change for audit deletion
ELPC_LH_002_CR01            8-JUN-2021            Rajasekar S                    Start, End time included
ELPC_LH_005                    15-MAR-2023            Snehitha Kannaboyina        Added logic for fetching old and new AUDITs 
ELPC_LH_005                    18-AUG-2023            Ashok Kumar R B			  Global Tag additionalcolumn select  
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_AuditByAuditID]   1,1343,'znn1kor'
*/
CREATE PROCEDURE [USP_AuditByAuditID] @PlantID INT
    ,@AuditID INT
    ,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
    SET NOCOUNT ON;

 

    EXEC [USP_PlantIDValidation] @PlantID = @PlantID
        ,@ID = @AuditID
        ,@Mode = 'AUDIT'
        ,@CurrentUserNTID = @CurrentUserNTID

 

    DECLARE @ValueStreamName NVARCHAR(max)
    DECLARE @ValueStreamID INT

 

    SELECT TOP (1) @ValueStreamID = [ValueStreamID]
    FROM T_TRN_Audit WITH (NOLOCK)
    WHERE AuditID = @AuditID
        AND PlantID = @PlantID;

 

    SET @ValueStreamName = (
            SELECT TOP 1 ValueStreamName
            FROM T_TRN_ValueStream WITH (NOLOCK)
            WHERE ValueStreamID = @ValueStreamID
            );

 

    SELECT T.TagName AS TagName
        ,TU.UserName AS Organizer
        ,T.TagTypeID
		,T.IsSearchableTag
		,T.IsSkipQuestionDefined
		,T.IsQuestionOverviewDefined
		,T.IsProgressPercentageDefined
		,T.IsResultOverviewDefined
		,T.IsResumeTagDefined
		,T.IsReportingEmailDefined 
		,T.IsMandatoryAssessorsDefined
        ,CASE 
            WHEN T.TagTypeID = 1
                THEN COALESCE('#' + T.TagName, '')
            WHEN T.TagTypeID = 2
                THEN COALESCE('#' + T.TagName, '')
            WHEN T.TagTypeID = 3
                THEN COALESCE('#' + T.TagName, '')
            WHEN T.TagTypeID = 4    
                THEN COALESCE('#' + T.TagName, '')
            END AS TagDisplayName
        ,(
            CASE 
                WHEN V.ValueStreamName IS NULL
                    THEN @ValueStreamName
                ELSE V.ValueStreamName
                END
            ) AS ValueStreamName
        --,V.ValueStreamName AS ValueStreamName
        ,A.AuditID
        ,A.PlantID
        ,A.StartDate
        ,A.StartTime
        ,A.EndDate
        ,A.EndTime
        ,A.IsRecurring
        ,A.IsAllDay
        ,(
            CASE 
                WHEN LV.ValueStreams IS NULL
                    THEN A.ValueStreamID
                ELSE LV.ValueStreams
                END
            ) AS ValueStreamID
        --,LV.ValueStreams as ValueStreamID
        ,A.Remarks
        ,A.Location
        ,A.IsAuditCompleted
        ,A.TagID
        ,A.CreatedAt
        ,A.CreatedBy_NTID
        ,A.ModifiedAt
        ,A.ModifiedBy_NTID
        ,A.IsDeleted
        --,LV.ValueStreams as ValueStreams
        ,R.[RecurrenceTypeId] AS [Recurrence_TypeId]
        ,R.[Interval] AS [Recurrence_Interval]
        ,R.[DayOfWeek] AS [Recurrence_DayOfWeek]
        ,R.[DayOfMonth] AS [Recurrence_DayOfMonth]
        ,R.[WeekOfMonth] AS [Recurrence_WeekOfMonth]
        ,R.[MonthOfYear] AS [Recurrence_MonthOfYear]
    FROM T_TRN_Audit A WITH (NOLOCK)
    INNER JOIN T_TRN_Tag T WITH (NOLOCK) ON A.TagID = T.TagID
        AND T.PlantID = @PlantID
    LEFT JOIN [T_LNK_Audit_ValueStreams] LV WITH (NOLOCK) ON A.Auditid = LV.auditid
        AND LV.IsDeleted = 0
        OR LV.AuditID IS NULL
    LEFT JOIN T_TRN_ValueStream V WITH (NOLOCK) ON LV.ValueStreams = V.ValueStreamID
    INNER JOIN T_MST_User TU WITH (NOLOCK) ON A.CreatedBy_NTID = TU.NTID
        AND TU.PlantID = @PlantID
    LEFT JOIN [T_TRN_Recurrence] R WITH (NOLOCK) ON A.AuditID = R.AuditID
        AND A.PlantID = R.PlantID
    WHERE A.AuditID = @AuditID
        --and A.PlantID = @PlantID   
        AND A.PlantID = @PlantID
END
GO