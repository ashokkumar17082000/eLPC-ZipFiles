/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_AssessorTemplateHistory]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING ASSESSOR TEMPLATE HISTORY
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					15-MAR-2021			KARTHIKEYAN KANDASAMY		MODIFIED VERSION
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_AssessorTemplateHistory] @PlantID=1, @AssessorTemplateID=1
*/
CREATE PROCEDURE [USP_AssessorTemplateHistory] (
	@PlantID INT
	,@AssessorTemplateID INT
	)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT (TU.UserName) AS ModifiedBy
		,AH.AssessorTemplateHistoryID
		,AH.AssessorTemplateID
		,AH.PlantID
		,AH.AssessorTemplateDisplayID
		,AH.AssessorTemplateHistoryDisplayID
		,AH.AssessorTemplateName
		,AH.IsTargetFrequencyDefined
		,AH.IsLocked
		,AH.IsDeleted
		,AH.ActionType
		,AH.ActionDate
		,AH.ModifiedAt
		,AH.ModifiedBy_NTID
		,AH.CreatedAt
		,AH.CreatedBy_NTID
		,TU.UserID
		,TU.UserName
		,TU.Role_RoleID
		,TU.EmployeeID
		,TU.EmailAddress
		,TU.NTID
		,TU.FirstName
		,TU.LastName
	FROM [T_TRN_AssessorTemplateHistory] AH WITH (NOLOCK)
	INNER JOIN T_MST_User TU WITH (NOLOCK) ON AH.ModifiedBy_NTID = TU.NTID
	WHERE AH.PlantID = @PlantID
		AND TU.PlantID = @PlantID
		AND AssessorTemplateID = @AssessorTemplateID
	ORDER BY AH.AssessorTemplateHistoryDisplayID DESC
END
GO
