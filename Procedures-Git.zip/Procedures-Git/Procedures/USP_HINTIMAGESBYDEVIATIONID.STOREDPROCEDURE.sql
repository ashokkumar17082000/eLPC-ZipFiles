/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_HintImagesByDeviationID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING HINT IMAGES BY DEVIATION ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					25-MAR-2021			SIKHESH S					ADDITIONAL INPUT PARAMATERS INCLUDED, STANDARD RULES APPLIED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_HintImagesByDeviationID] 1, 1
*/
CREATE PROCEDURE [USP_HintImagesByDeviationID] (
	@DeviationID INT
	,@PlantID INT
	,@CurrentUserNTID NVARCHAR(20) = NULL
	)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT DeviationAttachmentsID
		,DeviationID
		,ImagePath
		,ImageTitle
		,FileContent AS ByteData
		,DisplayFileName
	FROM [T_TRN_DeviationAttachments] WITH (NOLOCK)
	WHERE DeviationID = @DeviationID
		AND (IsDeleted = 0)
END
GO


