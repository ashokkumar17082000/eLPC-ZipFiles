/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchAuditQuestionsByAuditAndTemplateID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING AUDIT QUESTIONS BY AUDIT AND TEMPLATE ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			Rajasekar S					PlantId,CurrentUserNTID added
ELPC_LH_005					15-MAR-2023	        Snehitha Kannaboyina        Added ValueStreamID parameter and one Update query
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
EXEC [USP_FetchAuditQuestionsByAuditAndTemplateID] 1,1279,2,null,ZNN1KOR
*/
CREATE PROCEDURE [USP_FetchAuditQuestionsByAuditAndTemplateID] @PlantID INT
	,@AuditID INT
	,@AuditTemplateID INT
	,@ValueStreamID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	SET NOCOUNT ON;

	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = @AuditID
		,@Mode = 'AUDIT'
		,@CurrentUserNTID = @CurrentUserNTID

	DECLARE @tagid INT;

	SELECT @tagid = tagid
	FROM T_TRN_Audit
	WHERE auditid = @AuditID
		AND plantID = @PlantID

	SELECT (
			SELECT QuestionText
			FROM T_TRN_Question WITH (NOLOCK)
			WHERE QuestionID = AQ.QuestionID
				AND PlantID = @PlantID
			) AS QuestionText
		,AQ.AuditID
		,AQ.QuestionID
		,Q.QuestionDisplayID
		,AQ.CreatedAt
		,AQ.ModifiedAt
		,AQ.AnswerTypeID
		,AQ.IsAnswered
		,AQ.Answer
		,AQ.CreatedBy_NTID
		,AQ.ModifiedBy_NTID
		,AQ.IsAnswerRequired
		,AQ.AuditTemplateID
		,AQ.ID
		,A.PlantID
	FROM T_LNK_Audit_AnsweredQuestions AQ WITH (NOLOCK)
	INNER JOIN T_TRN_Audit A WITH (NOLOCK) ON A.AuditID = AQ.AuditID
	INNER JOIN T_TRN_Question Q WITH (NOLOCK) ON AQ.QuestionID = Q.QuestionID
	LEFT JOIN T_LNK_Audit_AssignedQuestions AAQ WITH (NOLOCK) ON AAQ.QuestionID = Q.QuestionID
		AND AAQ.AuditID = AQ.AuditID
	LEFT JOIN T_LNK_Tag_AssignedQuestionsTags RQ WITH (NOLOCK) ON Q.QuestionID = RQ.QuestionID
		AND RQ.TagID = @tagid
		AND RQ.IsDeleted = 0
	WHERE AQ.AuditID = @AuditID
		AND A.PlantID = @PlantID
		AND (
			AQ.IsAuditCompleted = 0
			OR AQ.IsAuditCompleted IS NULL
			)
		AND AQ.AuditTemplateID = @AuditTemplateID
	ORDER BY CASE 
			WHEN RQ.RandomQuestionOrder IS NULL
				THEN 998
			END
		,RQ.RandomQuestionOrder
		,Question_PriorityID
		,TargetFrequencyTypeID
		,ChoiceDisplayTypeID DESC
		,QuestionID

	UPDATE T_TRN_Audit
	SET ValueStreamID = @ValueStreamID
	WHERE AuditID = @AuditID
END
GO