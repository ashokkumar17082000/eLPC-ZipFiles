
/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_InsertIntoDeviation]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR INSERTING IN TO DEVIATION [T_TRN_Deviation] TABLE
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					25-MAR-2021			SIKHESH S					ADDITIONAL PARAMATERS INCLUDED AND RELEATED CHANGES, STANDARD RULES APPLIED
ELPC_LH_005                 15-MAR-2023         GOPIKA P G                  INCLUDED ADDITIONAL EMPLOYEE AND TAG FOR DEVIATION
ELPC_LH_006                 15-JUN-2024         Shubham						PIC upload changes
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_InsertIntoDeviation] 
*/
CREATE PROCEDURE [USP_InsertIntoDeviation] (
	 @ValueStreamID INT
	,@DeviationDescription NVARCHAR(500)
	,@ResponsibleEmployee NVARCHAR(200)
	,@HintImages XML NULL
	,@PlantID INT
	,@AdditionalEmployee XML NULL
	,@TagName XML NULL
	,@IsDeleted BIT NULL
	,@CurrentUserNTID NVARCHAR(20)
	)
AS
BEGIN
	DECLARE @DeviationID INT;

	BEGIN TRY
		BEGIN TRANSACTION INSERTINTODEVIATION;

		INSERT INTO [T_TRN_Deviation] (
			PlantID
			,DeviationDisplayID
			,ValueStreamID
			,DeviationDescription
			,ResponsibleEmployee
			,CreatedBy_NTID
			,CreatedAt
			,ModifiedAt
			)
		VALUES (
			@PlantID
			,(
				SELECT DisplayID
				FROM [FN_GetNextDisplayID](@PlantID, 'T_TRN_Deviation')
				)
			,@ValueStreamID
			,@DeviationDescription
			,@ResponsibleEmployee
			,@CurrentUserNTID
			,(
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				)
			,(
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				)
			)

		SET @DeviationID = Scope_Identity();

		INSERT INTO T_LNK_Deviation_AdditionalEmployee (
			DeviationID
			,NTID
			,CreatedAt
			,ModifiedAt
			,IsDeleted
			,CreatedBy_NTID
			,ModifiedBy_NTID
			,UserName
			)
		SELECT @DeviationID AS DeviationID
			,Emp.value('(NTID/text())[1]', 'NVARCHAR(100)') AS NTID
			,(
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				) AS CreatedAt
			,(
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				) AS ModifiedAt
			,@IsDeleted AS FALSE
			,@CurrentUserNTID AS CreatedBy_NTID
			,@CurrentUserNTID AS ModifiedBy_NTID
			,Emp.value('(UserName/text())[1]', 'NVARCHAR(100)') AS UserName
		FROM @AdditionalEmployee.nodes('/ArrayOfUser/User') AS TEMPTABLE(Emp)

		INSERT INTO T_LNK_Deviation_AssignedTags (
			DeviationID
			,TagID
			,IsDeleted
			,CreatedAt
			,ModifiedAt
			,CreatedBy_NTID
			,ModifiedBy_NTID
			,TagName
			)
		SELECT @DeviationID AS DeviationID
			,TagName.value('(TagID/text())[1]', 'int') AS TagID
			,@IsDeleted AS FALSE
			,(
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				) AS CreatedAt
			,(
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				) AS ModifiedAt
			,@CurrentUserNTID AS CreatedBy_NTID
			,@CurrentUserNTID AS ModifiedBy_NTID
			,TagName.value('(FormattedTag/text())[1]', 'nvarchar(100)') AS TagName
		FROM @TagName.nodes('/ArrayOfTag1/Tag1') AS TEMPTABLE(TagName)

		--INSERT INTO [T_TRN_DeviationAttachments] (
		--	ImagePath
		--	,ImageTitle
		--	,FileContent
		--	,DisplayFileName
		--	,CreatedBy_NTID
		--	,DeviationID
		--	)
		--SELECT HintImage.value('(ImagePath/text())[1]', 'NVARCHAR(50)') AS ImagePath
		--	,HintImage.value('(ImageTitle/text())[1]', 'NVARCHAR(100)') AS ImageTitle
		--	,HintImage.value('(ByteData/text())[1]', 'varbinary(max)') AS FileContent
		--	,HintImage.value('(DisplayFileName/text())[1]', 'NVARCHAR(100)') AS DisplayFileName
		--	,@CurrentUserNTID
		--	,@DeviationID AS DeviationID
		--FROM @HintImages.nodes('/ArrayOfHintImage/HintImage') AS TEMPTABLE(HintImage)
		--select @HintImages.value('count(/ArrayOfHintImage/HintImage/*)', 'int')

		UPDATE [T_TRN_DeviationAttachments]
		SET DeviationID = @DeviationID  ,IsDeleted=0
		WHERE IsDeleted=1 and CreatedBy_NTID=@CurrentUserNTID
			

		COMMIT TRANSACTION INSERTINTODEVIATION;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION INSERTINTODEVIATION;

		EXEC USP_LogError @PlantID
			,@CurrentUserNTID;
	END CATCH

	SELECT @DeviationID AS DeviationID
END
GO