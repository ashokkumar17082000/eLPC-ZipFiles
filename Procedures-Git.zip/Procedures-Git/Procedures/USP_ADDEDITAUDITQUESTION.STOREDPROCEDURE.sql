/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_AddEditAuditQuestion]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE TO ADD AND EDIT AUDIT QUESTION
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY				CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY INITIAL VERSION
ELPC_LH_002					22-MAR-2021			Rajasekar S				PlantId,CurrentUserNTID added
ELPC_LH_002					02-DEC-2021			VENKATESH GOVINDARAJ	CHANGED QUESTION LOAD LOGIC
ELPC_LH_005                 15-Mar-2023	        Snehitha Kannaboyina    Added new column to T_LNK_Audit_AnsweredQuestions table 
ELPC_LH_005                 15-jun-2024	        Gopika                  4.6 Assessor id change

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_AddEditAuditQuestion]
*/
CREATE PROCEDURE [USP_AddEditAuditQuestion] @PlantID INT  
 ,@ID INT  
 ,@AuditTemplateID INT  
 ,@AuditID INT  
 ,@QuestionID INT  
 ,@IsDeleted BIT  
 ,@AnswerTypeID INT  
 ,@IsAnswered BIT  
 ,@Answer NVARCHAR(max) NULL  
 ,@IsAnswerRequired BIT NULL  
 ,@Assessors XML NULL  
 ,@Others XML NULL  
 ,@CurrentUserNTID NVARCHAR(20)  
AS  
BEGIN  
DECLARE @NotAnswered INT  
  ,@CreatedAt DATETIME  
  ,@ModifiedAt DATETIME  
  ,@NTID NVARCHAR(20)  
  ,@AssessorName NVARCHAR(100)  
  ,@AssessorID INT
  ,@IsMandatoryAssessor BIT  
  ,@ValueStreamID INT  
  --,@ValueStreamName VARCHAR(MAX)  
  ,@TagID INT  
  ,@min INT = 0  
  ,@max INT = 0  
  ,@UserName NVARCHAR(200);  
  
 BEGIN TRY  
  EXEC [USP_PlantIDValidation] @PlantID = @PlantID  
   ,@ID = @AuditID  
   ,@Mode = 'AUDIT'  
   ,@CurrentUserNTID = @CurrentUserNTID  
  
  BEGIN TRANSACTION TRNADDEDITQUESTION  

	  IF (  
		@Answer IS NULL  
		OR @Answer = ''  
		)  
	  BEGIN  
	   SET @IsAnswered = 0  
	  END  
	  ELSE  
	  BEGIN  
	   SET @IsAnswered = 1  
	  END  
  
  --to insert new Audit  
  IF (  
    @AuditTemplateID = 0  
    OR @AuditTemplateID IS NULL  
    )  
  BEGIN  
   IF EXISTS (  
     SELECT 1  
     FROM T_LNK_Audit_AnsweredQuestions WITH (NOLOCK)  
     WHERE AuditID = @AuditID  
     )  
   BEGIN  
    SET @AuditTemplateID = (  
      SELECT Max(AuditTemplateID)  
      FROM T_LNK_Audit_AnsweredQuestions WITH (NOLOCK)  
      WHERE AuditID = @AuditID  
      ) + 1  
   END  
   ELSE  
   BEGIN  
    SET @AuditTemplateID = 1  
   END  
  
   SELECT TOP (1) @TagID = [TagID]  
    ,@ValueStreamID = [ValueStreamID]  
   FROM T_TRN_Audit WITH (NOLOCK)  
   WHERE AuditID = @AuditID  
    AND PlantID = @PlantID; 
	
   SET @AssessorID = (  
   SELECT  TOP (1) AssessorID 
   FROM T_TRN_Assessor WITH (NOLOCK)  
   WHERE AssessorName in (SELECT @Assessors.value('(/ArrayOfAuditAssessor/AuditAssessor/AssessorName[1]/text())[1]', 'nvarchar(100)')))
  
  /*SET @ValueStreamName = (  
   SELECT TOP 1 ValueStreamName  
   FROM T_TRN_ValueStream WITH (NOLOCK)  
   WHERE ValueStreamID = @ValueStreamID);*/  

  
  SELECT DISTINCT QuestionID  
   INTO #questionIDs  
   FROM [FN_GetNestedQuestionsByTagID](@TagID, @PlantID)  
   
   /*insert into  #TempAssessorID(ID,AssessorName,AuditID)
   values 
   (@AssessorID,
   (SELECT  @Assessors.value('(/ArrayOfAuditAssessor/AuditAssessor/AssessorName/text())[1]', 'nvarchar(100)')) 
   ,(Select @Assessors.value('(/ArrayOfAuditAssessor/AuditAssessor/AuditID/text())[1]', 'INT')) )*/
 
  
  INSERT INTO T_LNK_Audit_AnsweredQuestions (  
    ID  
    ,AuditID  
    ,QuestionID  
    ,CreatedAt  
    ,ModifiedAt  
    ,AnswerTypeID  
    ,CreatedBy_NTID  
    ,ModifiedBy_NTID  
    ,AuditTemplateID  
    ,IsAnswerRequired  
    ,ValueStreamID
	,AssessorID
    )  
   SELECT ROW_NUMBER() OVER (  
     ORDER BY QT.QuestionID  
     ) AS ID  
    ,@AuditID  
    ,Q.QuestionID  
    ,(  
     SELECT FormattedDateTime  
     FROM fnGetDateTime(@PlantID)  
     )  
    ,(  
     SELECT FormattedDateTime  
     FROM fnGetDateTime(@PlantID)  
     )  
    ,Q.AnswerType_AnswerTypeID AS AnswerTypeID  
    ,@CurrentUserNTID  
    ,@CurrentUserNTID  
    ,@AuditTemplateID  
    ,IsAnswerRequired  
    ,@ValueStreamID 
	,@AssessorID
   FROM #questionIDs QT  
   INNER JOIN T_TRN_Question Q WITH (NOLOCK) ON Q.QuestionID = QT.QuestionID  
    AND Q.PlantID = @PlantID  
    AND Q.IsDeleted = 0  
    AND Q.QuestionID IN (  
     (  
      SELECT q.QuestionID  
      FROM #questionIDs q  
      INNER JOIN (  
       SELECT DISTINCT (QuestionID)  
       FROM T_LNK_AssignedValueStreams WITH (NOLOCK)  
       WHERE IsDeleted = 0  
        AND ValueStreamID = @ValueStreamID  
       ) AS vs ON vs.QuestionID = q.QuestionID  
      )  
     )  
  IF EXISTS (  
     SELECT 1  
     FROM T_LNK_Audit_AnsweredQuestions WITH (NOLOCK)  
     WHERE AuditID = @AuditID  
    AND QuestionID = @QuestionID  
    AND AuditTemplateID = @AuditTemplateID )
	 BEGIN

   UPDATE T_LNK_Audit_AnsweredQuestions  
   SET AuditID = @AuditID  
    ,QuestionID = @QuestionID  
    ,ModifiedAt = (  
     SELECT FormattedDateTime  
     FROM fnGetDateTime(@PlantID)  
     )  
    ,IsDeleted = @IsDeleted  
    ,ModifiedBy_NTID = @CurrentUserNTID  
    ,IsAnswered = @IsAnswered  
    ,Answer = @Answer 
    ,IsAnswerRequired = @IsAnswerRequired  
   WHERE AuditID = @AuditID  
    AND QuestionID = @QuestionID  
    AND AuditTemplateID = @AuditTemplateID  
   
	 END
   --AND ID = @ID;  
   INSERT INTO T_LNK_AuditTemplate_AssessorDetail ( 
    AssessorName  
    ,UserName  
    ,NTID  
    ,IsMandatoryAssessor  
    ,AuditID  
    ,AuditTemplateID  
    )  
   SELECT Asr.value('(AssessorName/text())[1]', 'nvarchar(100)') AS AssessorName  
    ,Asr.value('(UserName/text())[1]', 'nvarchar(200)') AS UserName  
    ,Asr.value('(NTID/text())[1]', 'nvarchar(20)') AS NTID  
    ,Asr.value('(IsMandatoryAssessor/text())[1]', 'bit') AS IsMandatoryAssessor  
    ,Asr.value('(AuditID)[1]', 'INT') AS AuditID 
    ,@AuditTemplateID AS AuditTemplateID  
   FROM @Assessors.nodes('/ArrayOfAuditAssessor/AuditAssessor') AS TEMPTABLE(Asr)  
  
   INSERT INTO T_LNK_AuditTemplate_OtherAssessorDetail (  
    AssessorName  
    ,UserName  
    ,NTID  
    ,AuditID  
    ,AuditTemplateID  
    )  
   SELECT Asr.value('(AssessorName/text())[1]', 'nvarchar(100)') AS AssessorName  
    ,Asr.value('(UserName/text())[1]', 'nvarchar(200)') AS UserName  
    ,Asr.value('(NTID/text())[1]', 'nvarchar(20)') AS NTID  
    ,Asr.value('(AuditID)[1]', 'INT') AS AuditID  
    ,@AuditTemplateID AS AuditTemplateID  
   FROM @Others.nodes('/ArrayOfAuditAssessor/AuditAssessor') AS TEMPTABLE(Asr)  
  END  
  ELSE  
   --to update the answers for the existing audit and audit template  
  BEGIN  
  IF EXISTS (  
     SELECT 1  
     FROM T_LNK_Audit_AnsweredQuestions WITH (NOLOCK)  
     WHERE AuditID = @AuditID  
    AND QuestionID = @QuestionID  
    AND AuditTemplateID = @AuditTemplateID )
	 BEGIN 
   UPDATE T_LNK_Audit_AnsweredQuestions  
   SET AuditID = @AuditID  
    ,QuestionID = @QuestionID  
    ,ModifiedAt = (  
     SELECT FormattedDateTime  
     FROM fnGetDateTime(@PlantID)  
     )  
    ,IsDeleted = @IsDeleted  
    ,ModifiedBy_NTID = @CurrentUserNTID  
    ,IsAnswered = @IsAnswered  
    ,Answer = @Answer  
    ,IsAnswerRequired = @IsAnswerRequired  
   WHERE AuditID = @AuditID  
    AND QuestionID = @QuestionID  
    AND AuditTemplateID = @AuditTemplateID  
  END
   --AND ID = @ID;  
   --for Required attendees  
   BEGIN  
    SELECT @AuditID AS AuditID  
     ,Identity(INT, 1, 1) AS ID  
     ,Asr.value('(AssessorName/text())[1]', 'nvarchar(100)') AS AssessorName  
     ,Asr.value('(UserName/text())[1]', 'nvarchar(200)') AS UserName  
     ,Asr.value('(NTID/text())[1]', 'nvarchar(20)') AS NTID  
     ,Asr.value('(IsMandatoryAssessor/text())[1]', 'bit') AS IsMandatoryAssessor  
     ,@AuditTemplateID AS AuditTemplateID  
    INTO #R1  
    FROM @Assessors.nodes('/ArrayOfAuditAssessor/AuditAssessor') AS TEMPTABLE(Asr)  
  IF EXISTS (  
     SELECT 1  
     FROM T_LNK_AuditTemplate_AssessorDetail WITH (NOLOCK)  
     WHERE NTID NOT IN (  
      SELECT NTID  
      FROM #R1  
      )  
     AND AuditID = @AuditID  
     AND AuditTemplateID = @AuditTemplateID)
	 BEGIN 
    UPDATE T_LNK_AuditTemplate_AssessorDetail  
    SET IsDeleted = 1  
    WHERE NTID NOT IN (  
      SELECT NTID  
      FROM #R1  
      )  
     AND AuditID = @AuditID  
     AND AuditTemplateID = @AuditTemplateID --to soft delete the removed attendees  
  END
    --for inserting new Required attendees  
    SET @min = (  
      SELECT min(ID)  
      FROM #R1  
      )  
    SET @max = (  
      SELECT max(ID)  
      FROM #R1  
      )  
  
    WHILE (@min <= @max)  
    BEGIN  
     SELECT @AuditID = AuditID  
      ,@AuditTemplateID = AuditTemplateID  
      ,@AssessorName = AssessorName  
      ,@NTID = NTID  
      ,@UserName = UserName  
     FROM #R1  
     WHERE ID = @min;  
  
     IF EXISTS (  
       SELECT 1  
       FROM T_LNK_AuditTemplate_AssessorDetail WITH (NOLOCK)  
       WHERE AssessorName = @AssessorName  
        AND AuditTemplateID = @AuditTemplateID  
        AND AuditID = @AuditID  
       )  
     BEGIN  
      UPDATE T_LNK_AuditTemplate_AssessorDetail  
      SET NTID = @NTID  
       ,IsDeleted = 0  
       ,UserName = @UserName  
      WHERE AssessorName = @AssessorName  
       AND AuditTemplateID = @AuditTemplateID  
       AND AuditID = @AuditID  
  
      SET @min = @min + 1;  
     END  
    END  
   END  
  
   --end  
   --for other attendees  
   BEGIN  
    SELECT @AuditID AS AuditID  
     ,Identity(INT, 1, 1) AS ID  
     ,Asr.value('(AssessorName/text())[1]', 'nvarchar(100)') AS AssessorName  
     ,Asr.value('(UserName/text())[1]', 'nvarchar(200)') AS UserName  
     ,Asr.value('(NTID/text())[1]', 'nvarchar(20)') AS NTID  
     ,Asr.value('(IsMandatoryAssessor/text())[1]', 'bit') AS IsMandatoryAssessor  
     ,@AuditTemplateID AS AuditTemplateID  
    INTO #R2  
    FROM @Others.nodes('/ArrayOfAuditAssessor/AuditAssessor') AS TEMPTABLE(Asr)  
  
    UPDATE T_LNK_AuditTemplate_OtherAssessorDetail  
    SET IsDeleted = 1  
    WHERE NTID NOT IN (  
      SELECT NTID  
      FROM #R2  
      )  
     AND AuditID = @AuditID  
     AND AuditTemplateID = @AuditTemplateID --to soft delete the removed attendees  
  
    --for inserting new Required attendees  
    SET @min = (  
      SELECT min(ID)  
      FROM #R2  
      )  
    SET @max = (  
      SELECT max(ID)  
      FROM #R2  
      )  
  
    WHILE (@min <= @max)  
    BEGIN  
     SELECT @AuditID = AuditID  
      ,@AuditTemplateID = AuditTemplateID  
      ,@UserName = UserName  
      ,@NTID = NTID  
     FROM #R2  
     WHERE ID = @min;  
  
     IF NOT EXISTS (  
       SELECT 1  
       FROM T_LNK_AuditTemplate_OtherAssessorDetail WITH (NOLOCK)  
       WHERE AuditID = @AuditID  
        AND NTID = @NTID  
        AND AuditTemplateID = @AuditTemplateID  
       )  
     BEGIN  
      INSERT INTO T_LNK_AuditTemplate_OtherAssessorDetail (  
       AuditID  
       ,AuditTemplateID  
       ,NTID  
       ,UserName  
       ,IsDeleted  
       )  
      VALUES (  
       @AuditID  
       ,@AuditTemplateID  
       ,@NTID  
       ,@UserName  
       ,0  
       )  
     END  
  
     SET @min = @min + 1;  
    END  
   END  
    --end  
  END  
  
  SET @NotAnswered = (  
    SELECT Count(ID)  
    FROM T_LNK_Audit_AnsweredQuestions WITH (NOLOCK)  
    WHERE (IsAnswered IS NULL)  
     AND AuditID = @AuditID  
     AND AuditTemplateID = @AuditTemplateID  
    )  
  
  IF (  
    @NotAnswered = 0  
    OR @NotAnswered IS NULL  
    )  
  BEGIN  
   SET @ValueStreamID = (  
     SELECT TOP 1 ValueStreamID  
     FROM T_TRN_Audit WITH (NOLOCK)  
     WHERE AuditID = @AuditID  
      AND PlantID = @PlantID  
     )  
   SET @TagID = (  
     SELECT TOP 1 TagID  
     FROM T_TRN_Audit WITH (NOLOCK)  
     WHERE AuditID = @AuditID  
      AND PlantID = @PlantID  
     )  
  END  
  
  SELECT @NotAnswered AS PendingCount  
   ,(  
    SELECT TOP 1 [AuditAnsweredQuestionID]  
    FROM [T_LNK_Audit_AnsweredQuestions] WITH (NOLOCK)  
    WHERE AuditID = @AuditID  
     AND QuestionID = @QuestionID  
     AND AuditTemplateID = @AuditTemplateID  
     --AND ID = @ID  
    ) AS [AuditAnsweredQuestionID]  
  
  COMMIT TRANSACTION TRNADDEDITQUESTION  
 END TRY  
  
 BEGIN CATCH  
  ROLLBACK TRANSACTION TRNADDEDITQUESTION  
  
  EXEC USP_LogError @PlantID  
   ,@CurrentUserNTID  
 END CATCH  
END  
 GO