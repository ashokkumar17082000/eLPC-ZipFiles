/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_TAG_HISTORY]
///AUTHOR                       : RAJASEKAR S
///CREATED DATE                 : 16-MAR-2021
///SEE ALSO                     : THIS PROCEDURE TO ADD TAG HISTORY DETAILS 
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_002					10-MAR-2021			RAJASEKAR S					INITIAL VERSION
ELPC_LH_002					28-MAR-2021			RAJASEKAR S					PlantID, CurrentUserNTID added
************************************************************************************************************ 
///</SUMMARY>

EXEC [USP_TAG_HISTORY] 1,'RSB4COB','TAG',1,'I','1'
*/
CREATE PROCEDURE [USP_TAG_HISTORY] @PlantID INT
	,@CurrentUserNTID NVARCHAR(20) NULL
	,@TableName VARCHAR(100)
	,@TagHistoryID INT OUTPUT
	,@ActionType VARCHAR(10)
	,@INPUT_IDS VARCHAR(MAX)
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION TRNTAGHISTORY

		IF (@TableName = 'Tag')
		BEGIN
			INSERT INTO [T_TRN_TagHistory] (
				PlantID
				,TagID
				,TagDisplayID
				,TagHistoryDisplayID
				,TagName
				,IsSingleQuestionSuppressed
				,SuppressedDateRangeFrom
				,SuppressedDateRangeTo
				,IsTargetFrequencyDefined
				,TargetFrequencyTypeID
				,TargetFrequencyValue
				,Tag_PriorityID
				,TagTypeID
				,IsLocked
				,AnonymizeUserDataSettingID
				,IsBranchLogicToBeFollowed
				,IsMandatoryAssessorsDefined
				,IsDeleted
				,CreatedAt
				,ModifiedAt
				,ActionType
				,ActionAt
				-- ,Assigned_ValueStreamTemplateID
				-- ,Assigned_ValueStreamCategoryID
				-- ,Assigned_AssessorTemplateID
				,CreatedBy_NTID
				,ModifiedBy_NTID
				)
			SELECT PlantID
				,TagID
				,TagDisplayID
				,(
					SELECT DisplayID
					FROM [FN_GetNextHistoryDisplayID](@PlantID, 'T_TRN_TagHistory', TagID)
					)
				,TagName
				,IsSingleQuestionSuppressed
				,SuppressedDateRangeFrom
				,SuppressedDateRangeTo
				,IsTargetFrequencyDefined
				,TargetFrequencyTypeID
				,TargetFrequencyValue
				,Tag_PriorityID
				,TagTypeID
				,IsLocked
				,AnonymizeUserDataSettingID
				,IsBranchLogicToBeFollowed
				,IsMandatoryAssessorsDefined
				,IsDeleted
				,CreatedAt
				,ModifiedAt
				,@ActionType
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
				-- ,Assigned_ValueStreamTemplateID
				-- ,Assigned_ValueStreamCategoryID
				-- ,Assigned_AssessorTemplateID
				,CreatedBy_NTID
				,ModifiedBy_NTID
			FROM [T_TRN_Tag] WITH (NOLOCK)
			WHERE [TagID] = @INPUT_IDS
				AND PlantID = @PlantID;--Always single value

			SET @TagHistoryID = SCOPE_IDENTITY();
		END
		ELSE IF (@TableName = 'AssignedQuestionsTags')
		BEGIN
			INSERT INTO [T_LNK_Tag_AssignedQuestionsTagsHistory] (
				[TagHistoryID]
				,[ID]
				,[TagID]
				,[QuestionID]
				,[LinkedTagID]
				,[IsDeleted]
				,[ActionType]
				,[ActionAt]
				)
			SELECT @TagHistoryID
				,[ID]
				,[TagID]
				,[QuestionID]
				,[LinkedTagID]
				,[IsDeleted]
				,@ActionType
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
			FROM [T_LNK_Tag_AssignedQuestionsTags] WITH (NOLOCK)
			WHERE ID IN (
					SELECT *
					FROM fnSplit(@INPUT_IDS)
					)
		END
		ELSE IF (@TableName = 'AssignedValueStreams')
		BEGIN
			INSERT INTO [T_LNK_Tag_AssignedValueStreamsHistory] (
				[TagHistoryID]
				,[ID]
				,[ValueStreamID]
				,[TagID]
				,[IsDeleted]
				,[ActionType]
				,[ActionAt]
				)
			SELECT @TagHistoryID
				,[ID]
				,[ValueStreamID]
				,[TagID]
				,[IsDeleted]
				,@ActionType
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
			FROM [T_LNK_Tag_AssignedValueStreams] WITH (NOLOCK)
			WHERE ID IN (
					SELECT *
					FROM fnSplit(@INPUT_IDS)
					)
		END
		ELSE IF (@TableName = 'AssignedAssessors')
		BEGIN
			INSERT INTO [T_LNK_Tag_AssignedAssessorsHistory] (
				[TagHistoryID]
				,[ID]
				,[AssessorID]
				,[TagID]
				,[TargetFrequencyValue]
				,[TargetFrequencyTypeID]
				,[IsDeleted]
				,[IsMandatoryAssessor]
				,[ActionType]
				,[ActionAt]
				)
			SELECT @TagHistoryID
				,[ID]
				,[AssessorID]
				,[TagID]
				,[TargetFrequencyValue]
				,[TargetFrequencyTypeID]
				,[IsDeleted]
				,[IsMandatoryAssessor]
				,@ActionType
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
			FROM [T_LNK_Tag_AssignedAssessors] WITH (NOLOCK)
			WHERE ID IN (
					SELECT *
					FROM fnSplit(@INPUT_IDS)
					)
		END
		ELSE IF (@TableName = 'AssignedTags')
		BEGIN
			INSERT INTO [T_LNK_QN_AssignedTagsHistory] (
				[QuestionHistoryID]
				,[ID]
				,[TagID]
				,[QuestionID]
				,[IsDeleted]
				,[ActionType]
				,[ActionDate]
				)
			SELECT @TagHistoryID
				,[ID]
				,[TagID]
				,[QuestionID]
				,[IsDeleted]
				,@ActionType
				,(
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					)
			FROM [T_LNK_QN_AssignedTags] WITH (NOLOCK)
			WHERE ID IN (
					SELECT *
					FROM fnSplit(@INPUT_IDS)
					)
		END

		COMMIT TRANSACTION TRNTAGHISTORY;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNTAGHISTORY;

		EXEC [USP_LogError] @PlantID
			,@CurrentUserNTID;
	END CATCH
END
GO

