/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_GetDataPool_old]
///AUTHOR                       : VENKATESH GOVINDARAJ
///CREATED DATE                 : 21-JAN-2021
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING DATA POOL
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  

ELPC_LH_005                 15-MAR-2023         GOPIKA P G                  INCLUDED ADDITIONAL PARAMETERS FOR INFORMATION TO  AND TAG
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_GetDataPool_old] 80,'FSM1COB',NULL,NULL
*/

CREATE  PROCEDURE [USP_GetDataPool_old] (
	@PlantID INT
	,@CurrentUserNTID NVARCHAR(20) = NULL
	,@FromDate DATETIME = NULL
	,@ToDate DATETIME = NULL
	)
AS
BEGIN
	SET NOCOUNT ON;

	IF (
			@ToDate IS NOT NULL
			AND @ToDate != '1900-01-01 00:00:00.000'
			)
	BEGIN
		SET @ToDate = DATEADD(DAY, 1, @ToDate)
	END

	SELECT q.QuestionID
		,(
			SELECT ListTag
			FROM [FN_GetNestedTagsByQuestionID](Q.QuestionID, 'strTagID')
			WHERE ListTag IS NOT NULL
			) AS TagIDList
	INTO #LinkedTagsByQuestionID
	FROM T_TRN_Question Q WITH (NOLOCK)
	WHERE PlantID = @PlantID

	SELECT DISTINCT DP.AuditID
		,DP.AuditTemplateID
	INTO #LinkedAuditID
	FROM T_TRN_DataPool DP WITH (NOLOCK)
	WHERE PlantID = @PlantID
		AND AuditID > 0

	SELECT LNK.AuditID
		,LNK.AuditTemplateID
		,(
			SELECT STRING_AGG(cast(AssessorName AS NVARCHAR(MAX)), ',')
			FROM T_LNK_AuditTemplate_AssessorDetail WITH (NOLOCK)
			WHERE AuditID = LNK.AuditID
				AND AuditTemplateID = LNK.AuditTemplateID
				AND IsDeleted = 0
			) AS AssessorName
	INTO #LinkedAssessorByAuditID
	FROM #LinkedAuditID LNK WITH (NOLOCK)

	SELECT PN.DataPoolID
		,PN.DataPoolDisplayID
		,PN.TIMESTAMP
		,TU.UserName
		,CONCAT (
			TVS.ValueStreamTemplateName
			,TVS.Delimiter
			,VS.ValueStreamName
			) AS ValueStreamName
		,(
			CASE 
				WHEN (PN.AuditID > 0)
					THEN (
							SELECT AssessorName
							FROM #LinkedAssessorByAuditID WITH (NOLOCK)
							WHERE AuditID = PN.AuditID
								AND AuditTemplateID = PN.AuditTemplateID
							)
				ELSE TA.AssessorName
				END
			) AS AssessorName
		,Q.QuestionID
		,Q.QuestionDisplayID
		,Q.QuestionText
	    ,IIF(PN.Answer IS NULL , 'Question Skipped',PN.Answer ) AS Answer
		,PN.ChoiceID
		,PN.ObtainedScore
		,PN.answerType_AnswerTypeID
		,PN.ValueStreamID
		,PN.AssessorID
		,PN.DeviationID
		,PN.TagID
		,PN.AuditID
		,PN.AuditTemplateID
		,PN.AnsweredBy_NTID
		,LTQ.TagIDList
		,(
			SELECT TOP 1 TagName
			FROM T_TRN_Tag WITH (NOLOCK)
			WHERE PlantID = @PlantID
				AND TagID = PN.TagID
			) AS OriginTag
		,(
			SELECT TOP 1 SuperOPLURL
			FROM T_TRN_Deviation WITH (NOLOCK)
			WHERE PlantID = @PlantID
				AND DeviationID = PN.DeviationID
			) AS OPLURL
		,(
			SELECT DISTINCT abc = STUFF((
						SELECT ',' + convert(VARCHAR, UserName)
						FROM T_LNK_Deviation_AdditionalEmployee WITH (NOLOCK)
						WHERE DeviationID = PN.DeviationID
							AND (
								IsDeleted IS NULL
								OR IsDeleted = 0
								)
						FOR XML PATH('')
							,TYPE
						).value('.', 'NVARCHAR(MAX)'), 1, 1, '')
			) AS EmpList
		,(
			SELECT DISTINCT abc = STUFF((
						SELECT ',' + convert(VARCHAR, TagName)
						FROM T_LNK_Deviation_AssignedTags WITH (NOLOCK)
						WHERE DeviationID = PN.DeviationID
							AND (
								IsDeleted IS NULL
								OR IsDeleted = 0
								)
						FOR XML PATH('')
							,TYPE
						).value('.', 'NVARCHAR(MAX)'), 1, 1, '')
			) AS MultiTagList
		,(
			SELECT DISTINCT abc = STUFF((
						SELECT ',' + convert(VARCHAR, TagID)
						FROM T_LNK_Deviation_AssignedTags WITH (NOLOCK)
						WHERE DeviationID = PN.DeviationID
							AND (
								IsDeleted IS NULL
								OR IsDeleted = 0
								)
						FOR XML PATH('')
							,TYPE
						).value('.', 'NVARCHAR(MAX)'), 1, 1, '')
			) AS MultiTagID
			,(
			SELECT TOP 1 AnonymizeUserDataSettingID
			FROM T_TRN_Tag WITH (NOLOCK)
			WHERE PlantID = @PlantID
				AND TagID = PN.TagID
			) AS AnonymizeUserDataSettingID
	FROM [T_TRN_DataPool] PN WITH (NOLOCK)
	INNER JOIN [T_TRN_ValueStream] VS WITH (NOLOCK) ON PN.ValueStreamID = VS.ValueStreamID
	LEFT JOIN T_TRN_Assessor TA WITH (NOLOCK) ON PN.AssessorID = TA.AssessorID --left join because of audit part also coming in datapool
	INNER JOIN T_MSt_User TU WITH (NOLOCK) ON PN.AnsweredBy_NTID = TU.NTID
		AND TU.PlantID = @PlantID
	INNER JOIN T_TRN_Question Q WITH (NOLOCK) ON PN.QuestionID = Q.QuestionID
		AND Q.PlantID = @PlantID
	--for naming with valuestream and template with category .also assessor and assessortemplate
	INNER JOIN T_TRN_ValueStreamTemplate TVS WITH (NOLOCK) ON TVS.ValueStreamTemplateID = VS.ValueStreamTemplateID
		AND TVS.PlantID = @PlantID
	INNER JOIN #LinkedTagsByQuestionID LTQ WITH (NOLOCK) ON LTQ.QuestionID = Q.QuestionID
	WHERE PN.PlantID = @PlantID
		AND TU.UserName IS NOT NULL
		AND (PN.IsDeleted = 0)
		AND PN.TIMESTAMP >= IIF(@FromDate IS NULL
			OR @FromDate = '1900-01-01 00:00:00.000', PN.TIMESTAMP, @FromDate)
		AND PN.TIMESTAMP <= IIF(@ToDate IS NULL
			OR @ToDate = '1900-01-01 00:00:00.000', PN.TIMESTAMP, @ToDate)
	ORDER BY PN.TIMESTAMP DESC
END
		--drop table #LinkedAuditID
		--drop table #LinkedAssessorByAuditID
		--drop table #LinkedTagsByQuestionID
		
GO	