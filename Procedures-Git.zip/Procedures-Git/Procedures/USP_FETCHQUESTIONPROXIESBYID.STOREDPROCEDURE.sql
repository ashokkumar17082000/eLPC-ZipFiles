/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchQuestionProxiesByID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING QUESTION PROXIES BY ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			VENKATESH GOVINDARAJ		PlantID & Code Cleanup
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_FetchQuestionProxiesByID] 1, 1
*/
CREATE PROCEDURE [USP_FetchQuestionProxiesByID] @QuestionID INT
	,@PlantID INT
AS
BEGIN
	SET NOCOUNT ON;

	SELECT (
			SELECT TOP 1 UR.NTID
			) AS NTID
		,(
			SELECT TOP 1 UR.UserName
			) AS UserName
		,LNK.ID
		,LNK.QuestionID
		,LNK.Proxy
		,LNK.IsDeleted
		,LNK.CreatedAt
		,LNK.ModifiedAt
		,LNK.CreatedBy_NTID
		,LNK.ModifiedBy_NTID
	FROM T_LNK_Question_Proxy LNK WITH (NOLOCK)
	INNER JOIN T_MST_User UR WITH (NOLOCK) ON LNK.Proxy = UR.NTID
		AND UR.PlantID = @PlantID
	INNER JOIN T_TRN_QUESTION Q WITH (NOLOCK) ON Q.QuestionID = LNK.QuestionID
	WHERE LNK.QuestionID = @QuestionID
		AND LNK.IsDeleted = 0
		AND Q.PlantID = @PlantID
END
GO


