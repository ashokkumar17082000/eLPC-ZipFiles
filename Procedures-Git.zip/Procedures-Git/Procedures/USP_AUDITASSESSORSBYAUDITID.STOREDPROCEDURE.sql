/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_AuditAssessorsByAuditID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING AUDIT ASSESSORS BY AUDIT ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			Rajasekar S					PlantId,CurrentUserNTID added

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_AuditAssessorsByAuditID] 1
*/
CREATE PROCEDURE [USP_AuditAssessorsByAuditID] @PlantID INT
	,@AuditID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	SET NOCOUNT ON;

	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = @AuditID
		,@Mode = 'AUDIT'
		,@CurrentUserNTID = @CurrentUserNTID

	SELECT ASS.AuditAssessorID
		,ASS.AuditID
		,ASS.AssessorName
		,ASS.IsMandatoryAssessor
		,ASS.NTID
		,ASS.IsActive
	FROM T_TRN_AuditAssessor ASS WITH (NOLOCK)
	INNER JOIN T_TRN_Audit A WITH (NOLOCK) ON A.AuditID = ASS.AuditID
	WHERE ASS.AuditID = @AuditID
		AND A.PlantID = @PlantID
		AND IsActive = 1
END
GO


