/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_ValueStreamByValueStreamID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVEING VALUESTREAM BY VALUESTREAM ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					19-MAR-2021			RAJASEKAR S					Plantid included
ELPC_LH_002					26-MAR-2021			Rajasekar S					@CurrentUserNTID,PlantIDValidation added
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_ValueStreamByValueStreamID] 1,1
*/
CREATE PROCEDURE [USP_ValueStreamByValueStreamID] @PlantID INT
	,@ValueStreamID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = 0
		,@Mode = 'VALUESTREAMTEMPLATE'
		,@CurrentUserNTID = @CurrentUserNTID

	SET NOCOUNT ON;

	SELECT VS.ValueStreamID
		,VS.Responsible_UserID
		,VS.ResponsibleEmployee
		,VS.ValueStreamTemplateID
		,VS.ValueStreamCategoryID
		,VS.ValueStreamData
		,VS.NodeID
		,VS.RowID
		,VST.ValueStreamTemplateName
		,VST.Delimiter
		,VS.ValueStreamName
	FROM T_TRN_ValueStream VS WITH (NOLOCK)
	INNER JOIN T_TRN_ValueStreamTemplate VST WITH (NOLOCK) ON VST.ValueStreamTemplateID = VS.ValueStreamTemplateID
	WHERE VST.PlantID = @PlantID
		AND VS.ValueStreamID = @ValueStreamID
END
GO


