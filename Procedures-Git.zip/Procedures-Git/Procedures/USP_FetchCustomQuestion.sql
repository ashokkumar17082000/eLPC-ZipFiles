/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchCustomQuestion] 
///AUTHOR                       : Venkatesh and Ashok kumar
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING QUESTION Based on VSAS Combination in UserProfile
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					14-JULY-2022			Venkatesh and Ashok kumar		        INITIAL VERSION
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_FetchCustomQuestion] 1,'EGV1COB'
*/
CREATE PROCEDURE [USP_FetchCustomQuestion] @PlantID AS INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	CREATE TABLE #MyVSASCOMBIQues (QuestionId INT)

	INSERT INTO #MyVSASCOMBIQues
	EXEC [USP_Fetch_VSAS_TagsMode_CustomMode] 3
		,@PlantID
		,@CurrentUserNTID

	SET NOCOUNT ON;

	SELECT Q.QuestionID
		,Q.QuestionText
		,Q.QuestionDisplayID
		,Q.QuestionHintText
		,CASE 
			WHEN Q.IsLocked = 1
				THEN IIF((
							SELECT COUNT(*)
							FROM T_LNK_Question_Proxy
							WHERE QuestionID = Q.QuestionID
								AND (
									Proxy = @CurrentUserNTID
									OR CreatedBy_NTID = @CurrentUserNTID
									OR ModifiedBy_NTID = @CurrentUserNTID
									)
								AND IsDeleted = 0
							) > 0, 1, 0)
			ELSE 1
			END AS IsAccessible
	FROM T_TRN_Question Q WITH (NOLOCK)
	INNER JOIN #MyVSASCOMBIQues Combi ON combi.QuestionId = Q.QuestionID
	WHERE Q.QuestionID IS NOT NULL
		AND Q.IsDeleted = 0
		AND Q.PlantID = @PlantID
	ORDER BY ModifiedAt DESC
END
GO