/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_ValueStreamsByCategoryID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING VALUESTREAMS BY CATEGORY ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					18-MAR-2021			RAJASEKAR S					Plantid included
ELPC_LH_002					26-MAR-2021			Rajasekar S					@CurrentUserNTID,PlantIDValidation added
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_ValueStreamsByCategoryID] 1,1
*/
CREATE PROCEDURE [USP_ValueStreamsByCategoryID] @PlantID INT
	,@ValueStreamCategoryID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = 0
		,@Mode = 'VALUESTREAMTEMPLATE'
		,@CurrentUserNTID = @CurrentUserNTID

	SET NOCOUNT ON;

	SELECT VS.ValueStreamID
		,VS.Responsible_UserID
		,VS.ResponsibleEmployee
		,VS.ValueStreamTemplateID
		,VS.ValueStreamCategoryID
		,VS.ValueStreamData
		,VS.NodeID
		,VS.RowID
		,VST.ValueStreamTemplateName
		,VST.Delimiter
		,VS.ValueStreamName
	FROM T_TRN_ValueStream VS WITH (NOLOCK)
	INNER JOIN T_TRN_ValueStreamTemplate VST WITH (NOLOCK) ON VST.ValueStreamTemplateID = VS.ValueStreamTemplateID
	WHERE VS.ValueStreamCategoryID = @ValueStreamCategoryID
		AND (
			VST.PlantID = @PlantID
			AND VS.IsDeleted = 0
			)
END
GO


