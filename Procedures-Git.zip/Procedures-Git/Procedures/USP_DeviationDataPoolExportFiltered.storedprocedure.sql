/****** Object:  StoredProcedure [dbo].[USP_DeviationDataPoolExportFiltered]    Script Date: 4/5/2024 6:02:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_DEVIATIONDATAPOOLEXPORTFILTERED]
///AUTHOR                       : VENKATESH GOVINDARAJ
///CREATED DATE                 : 05-FEB-2022
///SEE ALSO                     : THIS PROCEDURE TO EXPORT DEVIATION DATA POOL
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 

ELPC_LH_005                 15-MAR-2023         ASHOK						INITIAL VESRION
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [dbo].[USP_DeviationDataPoolExport] 1,'FSM1COB','2024-02-01','2024-04-01'
*/
CREATE  PROCEDURE [USP_DeviationDataPoolExportFiltered] (
	@PlantID INT
	,@CurrentUserNTID NVARCHAR(20) = NULL
	,@FromDate DATETIME = NULL
	,@ToDate DATETIME = NULL
	)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @temp TABLE (
		DeviationID INT
		,DeviationDisplayID INT
		,PlantID INT
		,TIMESTAMP DATETIME
		,UserName NVARCHAR(200)
		,ValueStreamID INT
		,ValueStreamName NVARCHAR(MAX)
		,QuestionID INT
		,QuestionDisplayID INT
		,QuestionText NVARCHAR(MAX)
		,Answer NVARCHAR(MAX)
		,ChoiceID NVARCHAR(MAX)
		,ObtainedScore DECIMAL(10, 2)
		,DeviationDescription NVARCHAR(MAX)
		,ResponsibleEmployee NVARCHAR(MAX)
		,DeviationAttachmentID NVARCHAR(MAX)
		,UploadedFileName NVARCHAR(MAX)
		,DisplayFileName NVARCHAR(MAX)
		,InfoEmployee NVARCHAR(MAX)
		,TagName NVARCHAR(MAX)
		,TagID NVARCHAR(MAX)
		,CreatedBy_NTID NVARCHAR(MAX)
		,SuperOPLURL NVARCHAR(MAX)
		);

	INSERT INTO @temp
	EXEC [USP_GetDeviationDataPool_old] @PlantID
		,@CurrentUserNTID
		,@FromDate
		,@ToDate
		

	SELECT DeviationID
		,DeviationDisplayID
		,TIMESTAMP
		,UserName
		,ValueStreamName
		,SuperOPLURL AS OPLURL
		,QuestionID
		,QuestionDisplayID
		,QuestionText
		,Answer
		,ObtainedScore
		,DeviationDescription
		,ResponsibleEmployee
		,DisplayFileName AS Attachments
		,InfoEmployee AS InformationTo
		,TagName AS DeviationAssignedTag
	FROM @temp t
END
GO