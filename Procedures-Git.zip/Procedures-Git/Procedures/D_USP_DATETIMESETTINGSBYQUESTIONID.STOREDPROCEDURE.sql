/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_DateTimeSettingsByQuestionID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING DATETIME SETTINGS BY QUESTION ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_DateTimeSettingsByQuestionID] 1
*/
CREATE PROCEDURE [USP_DateTimeSettingsByQuestionID] @QuestionID INT
AS
BEGIN
	SELECT *
	FROM T_TRN_AnswerTypeDateTime
	WHERE QuestionID = @QuestionID
		AND (IsDeleted = 0)
END
GO


