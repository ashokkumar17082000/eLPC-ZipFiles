/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_UPDATEDATAPOOL_PERCENTAGESUMMARYBYDATAPOOLID]
///AUTHOR                       : VENKATESH GOVINDARAJ
///CREATED DATE                 : 01-DEC-2021
///SEE ALSO                     : THIS PROCEDURE FOR UPDATING DATAPOOL PERCENATAGE SUMMARY BY DATAPOOLID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_002					01-DEC-2021			VENKATESH GOVINDARAJ		INITIAL VERSION

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_UpdateDataPool_PercentageSummaryByDataPoolID] 1	
*/
ALTER PROCEDURE [USP_UpdateDataPool_PercentageSummaryByDataPoolID] @PlantID INT
AS
BEGIN

	----GET TOTAL LINK QUESTIONS
	--SELECT DISTINCT ValueStreamID, QuestionID, IsDeleted FROM T_LNK_AssignedValueStreams WHERE IsDeleted = 0
	--AND QuestionID IN (SELECT QuestionID FROM T_TRN_Question where IsDeleted = 0 AND PlantID = @PlantID)


	--GET TARGET FREQUNCEY DETAILS BY QUESTIONID
	SELECT *
	INTO #QuestionFrequencyMaster
	FROM (
	SELECT DISTINCT Q.QuestionID
	,LNKVS.ValueStreamID
	,ISNULL(TF.TargetFrequencyTypeID, 99) AS TargetFrequencyTypeID
	,TF.TargetFrequencyTypeName
	,Q.TargetFrequencyValue
	,VShift.ShiftName
	,VShift.FromTime
	,VShift.ToTime
	,VShift.IsMonday
	,VShift.IsTuesDay
	,VShift.IsWednesday
	,VShift.IsThursday
	,VShift.IsFriday
	,VShift.IsSaturday
	,VShift.IsSunday
	FROM T_TRN_Question Q 

	INNER JOIN T_LNK_AssignedValueStreams LNKVS ON LNKVS.QuestionID = Q.QuestionID
		AND LNKVS.IsDeleted = 0 AND Q.PlantID = @PlantID AND Q.IsDeleted = 0 
	INNER JOIN T_TRN_ValueStream VS ON VS.ValueStreamID = LNKVS.ValueStreamID
		AND VS.IsDeleted = 0
		AND Q.IsDeleted = 0
	INNER JOIN T_TRN_ValueStreamTemplate VST ON VS.ValueStreamTemplateID = VST.ValueStreamTemplateID
		AND VST.IsDeleted = 0
		--AND CAST(ISNULL(Q.TargetFrequencyValue,0) AS INT) > 1
	LEFT JOIN T_MST_TargetFrequencyType TF ON TF.TargetFrequencyTypeID = Q.TargetFrequencyTypeID
		AND TF.IsDeleted = 0
	LEFT JOIN T_LNK_ValueStream_Shift VShift ON VShift.ValueStreamTemplateID = VS.ValueStreamTemplateID
		AND VShift.RowID = vs.RowID
		AND TF.TargetFrequencyTypeID = 1
		AND VShift.IsDeleted = 0
		AND VS.IsDeleted = 0

	ORDER BY TargetFrequencyTypeID
	,QuestionID
	,ValueStreamID
	OFFSET 0 ROWS
	) as QuestionFrequencyMaster
	
	--SELECT * FROM #QuestionFrequencyMaster ORDER BY TargetFrequencyTypeID
	--,QuestionID
	--,ValueStreamID
	
	SELECT DISTINCT FM.*, PS.* FROM T_TRN_Question Q
		LEFT JOIN T_TRN_DataPool_PercentageSummary PS  ON Q.QuestionID = PS.QuestionID AND Q.IsDeleted = 0 AND Q.PlantID = @PlantID
		LEFT JOIN #QuestionFrequencyMaster FM ON FM.QuestionID = Q.QuestionID AND Q.IsDeleted = 0 AND Q.PlantID = @PlantID
	WHERE Q.IsDeleted = 0 AND Q.PlantID = @PlantID
	ORDER BY FM.TargetFrequencyTypeID
	,FM.QuestionID
	,FM.ValueStreamID
	OFFSET 0 ROWS

	---- Fetch AnswerCount, NegativeAnswerCount from DataPool by QuestionID & ValueStreamID
	--SELECT *
	--INTO #CurrentQuestion
	--FROM (
	--	SELECT DP.DataPoolID
	--		,PlantID
	--		,DP.QuestionID
	--		,ValueStreamID
	--		,[TimeStamp]
	--		,cast(replace(cast(TIMESTAMP AS DATE), '-', '') AS INT) AS DateKey
	--		,cast(TIMESTAMP AS TIME) TIME
	--	FROM T_TRN_DataPool DP
	--	WHERE DP.PlantID = @PlantID
	--		AND DP.IsDeleted = 0
	--		AND DP.DataPoolID IN (
	--			SELECT max(DataPoolID) AS DataPoolID
	--			FROM T_TRN_DataPool
	--			WHERE QuestionID = DP.QuestionID
	--				AND PlantID = @PlantID
	--				AND IsDeleted = 0
	--			GROUP BY QuestionID
	--				,ValueStreamID
	--			)
	--	) AS CurrentQuestion

	--SELECT * FROM #CurrentQuestion order by QuestionID, ValueStreamID,DataPoolID

	--select * from T_LNK_ValueStream_Shift


	--select * from T_TRN_DataPool_PercentageSummary

	--SELECT s1.ShiftID,s2.IsMonday FROM T_LNK_ValueStream_Shift s1

	--CROSS JOIN T_LNK_ValueStream_Shift s2 where s1.IsMonday = 1
	


	--select * from

	--select * from T_TRN_DataPool_PercentageSummary

	--select * from T_TRN_DataPool_Summary

	--IF NOT EXISTS (
	--		SELECT TOP 1 1
	--		FROM #CurrentQuestion WITH (NOLOCK)
	--		)
	--BEGIN
	--	DELETE
	--	FROM T_TRN_DataPool_Summary
	--	WHERE QuestionID = @DataPoolID
	--END
	--ELSE
	--BEGIN
	--	--select * from #CurrentQuestion
	--	MERGE T_TRN_DataPool_Summary AS Target
	--	USING #CurrentQuestion AS Source
	--		ON Source.QuestionID = Target.QuestionID
	--			AND Source.ValueStreamID = Target.ValueStreamID

	--	-- For Updates
	--	WHEN MATCHED
	--		THEN
	--			UPDATE
	--			SET Target.AnswerCount = Source.AnswerCount
	--				,Target.NegativeAnswerCount = Source.NegativeAnswerCount

	--	-- For Inserts
	--	WHEN NOT MATCHED BY Target
	--		THEN
	--			INSERT (
	--				QuestionID
	--				,PlantID
	--				,ValueStreamID
	--				,AnswerCount
	--				,NegativeAnswerCount
	--				,Percentage
	--				)
	--			VALUES (
	--				Source.QuestionID
	--				,Source.PlantID
	--				,Source.ValueStreamID
	--				,Source.AnswerCount
	--				,Source.NegativeAnswerCount
	--				,NULL
	--				);
	--	-- For Deletes
	--	--WHEN NOT MATCHED BY Source THEN
	--	--DELETE;
	--	---- Checking the actions by MERGE statement
	--	--OUTPUT $action, 
	--	--INSERTED.QuestionID AS SourceQuestionID, 
	--	--INSERTED.ValueStreamID AS SourceValueStreamID, 
	--	--INSERTED.AnswerCount AS SourceAnswerCount;
	--END
END
