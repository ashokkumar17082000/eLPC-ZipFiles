/****** Object:  StoredProcedure [USP_FetchAuditAnswersCalendar]    Script Date: 08.03.2024 09:09:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
EXEC [USP_FetchAuditAnswersCalendar] 1,'JSD2KOR','2023-10-01','2023-10-30'
*/
CREATE PROCEDURE [USP_FetchAuditAnswersCalendar] @PlantID INT            
 ,@CurrentUserNTID NVARCHAR(20) = NULL            
 ,@FromDate DATETIME =NULL-- '2023-10-01'           
 ,@ToDate DATETIME = NULL --'2023-10-31'              
AS            
BEGIN            
 SET NOCOUNT ON;            
  
  
  select * into #AuditByNTID from (SELECT AuditId
				FROM [T_TRN_Audit] WITH(NOLOCK)
				WHERE CreatedBy_NTID = @CurrentUserNTID
					AND PlantID = @PlantID and IsDeleted=0
					AND  (StartDate Between  @FromDate and  @ToDate OR EndDate Between @FromDate and @ToDate or StartDate <  @FromDate AND EndDate > @ToDate)
				
         union 
		 				SELECT AuditId
				FROM T_TRN_Audit where AuditID in( Select AuditID from  T_LNK_Audit_OptionalAttendees WITH(NOLOCK)
				WHERE NTID = @CurrentUserNTID and IsDeleted=0)
					AND PlantID = @PlantID and IsDeleted=0
					AND  (StartDate Between  @FromDate and  @ToDate OR EndDate Between @FromDate and @ToDate or StartDate < @FromDate AND EndDate > @ToDate)
				
         union 
				SELECT AuditId
				FROM T_TRN_Audit where AuditID in( Select AuditID from  T_LNK_Audit_RequiredAttendees WITH(NOLOCK)
				WHERE NTID = @CurrentUserNTID and isDeleted=0)
					AND PlantID = @PlantID and IsDeleted=0
					AND  (StartDate Between  @FromDate and  @ToDate OR EndDate Between @FromDate and @ToDate or StartDate < @FromDate AND EndDate > @ToDate)
					) as tempq
  			
IF NOT exists ( select 1 from #AuditByNTID)

	Select NULL as TagDisplayName,
			NULL as AuditID,
			NULL as AuditTemplateID,
			NULL as CreatedBy_NTID,
			NULL as ValueStreamName,
			NULL as AssessorName,
			NULL as AnsweredTimeStamp ,           
			NULL as IsAuditCompleted,
			NULL as AnswerPercentage,
			NULL as AnswerdQuestionCount,
			NULL as UnAnswerdQuestionCount,
			NULL as AnswerStartDate,
			NULL as AnswerEndDate,
			NULL as StartDate,
			NULL as StartTime,
			NULL as EndDate,
			NULL as EndTime,
			NULL  as RequiredAttendeeStr,
			NULL as OptionalAttendeeStr,
			NULL as IsRecurring,
			NULL asRemarks,
			NULL as TagID,
			NULL as IsAllDay,
			NULL as Recurrence_TypeId,
			NULL as Recurrence_Interval,
			NULL asRecurrence_DayOfWeek,
			NULL as Recurrence_DayOfMonth,
			NULL as Recurrence_WeekOfMonth,
			NULL as Recurrence_MonthOfYear,
			NULL as AnonymizeUserDataSettingID
            
 SELECT DISTINCT DP.AuditID            
  ,DP.AuditTemplateID            
 INTO #LinkedAuditID            
 FROM T_TRN_DataPool DP WITH (NOLOCK)            
 WHERE PlantID = @PlantID AND AuditID in (select AuditID from  #AuditByNTID)   
   
            
 SELECT LNK.AuditID            
  ,LNK.AuditTemplateID            
  ,(SELECT STRING_AGG(cast(AssessorName AS NVARCHAR(MAX)), ';') FROM T_LNK_AuditTemplate_AssessorDetail WITH (NOLOCK)            
    WHERE AuditID = LNK.AuditID            
     AND AuditTemplateID = LNK.AuditTemplateID            
     AND IsDeleted = 0)            
   AS AssessorName            
 INTO #LinkedAssessorByAuditID            
 FROM #LinkedAuditID LNK WITH (NOLOCK)            
            
 SELECT AuditID            
 ,(            
  SELECT STRING_AGG(cast(UserName AS NVARCHAR(MAX)), ';') AS UserName            
  FROM (            
   SELECT DISTINCT Usr.UserName            
   FROM T_LNK_Audit_RequiredAttendees Req WITH (NOLOCK)            
   INNER JOIN T_MST_User Usr ON Usr.NTID = Req.NTID  AND Usr.PlantID = @PlantID            
   WHERE AuditID = A.AuditID      
   AND Req.ntid=@CurrentUserNTID     
    AND Usr.UserName IS NOT NULL
	           
   ) AS Req            
  ) AS RequiredAttendees            
 ,(            
  SELECT STRING_AGG(cast(UserName AS NVARCHAR(MAX)), ';') AS UserName            
  FROM (            
   SELECT DISTINCT Usr.UserName            
   FROM T_LNK_Audit_OptionalAttendees Req WITH (NOLOCK)            
   INNER JOIN T_MST_User Usr ON Usr.NTID = Req.NTID AND Usr.PlantID = @PlantID            
   WHERE AuditID = A.AuditID          
  AND req.ntid=@CurrentUserNTID 
    AND Usr.UserName IS NOT NULL            
   ) AS Opt            
  ) AS OptionalAttendees    
 INTO #Attendees																		            
 FROM #AuditByNTID as A            

          
            
 --Find Recurrance Answer status & details based on AuditID, AuditTemplateID            
 -- 0 Partial Answer completed for audit             
 -- 1 Audit Answer completed for all questions in audit            
 -- NULL not started            
 SELECT *,IIF(AnswerPercentage1 = 1 , 1, 0) AS IsAuditCompleted            
 INTO #tempLNK_Audit_AnsweredQuestions            
 FROM (            
  SELECT DISTINCT LNK.AuditID            
   ,LNK.AuditTemplateID  
   ,LNK.ValueStreamID  
   ,CONVERT(DATE, LNK.ModifiedAt) AS [AnsweredTimeStamp]            
   ,COUNT(QuestionID) AS TotalQuestionCount            
   ,COUNT(IIF(ISNULL(LNK.IsAnswered, 0) = 1, 1, NULL)) AS AnswerdQuestionCount            
   ,COUNT(IIF(ISNULL(LNK.IsAnswered, 0) = 0, 1, NULL)) AS UnAnswerdQuestionCount            
   ,CONVERT(INT, (1.0 * (COUNT(IIF(LNK.IsAnswered = 1, 1, NULL))) / (COUNT(QuestionID))) * 100) AS AnswerPercentage            
   ,LNK.IsAuditCompleted AS AnswerPercentage1  
   ,LNK.CreatedBy_NTID            
  FROM T_LNK_Audit_AnsweredQuestions LNK WITH (NOLOCK)            
  INNER JOIN T_TRN_Audit A WITH (NOLOCK) ON A.AuditID = LNK.AuditID       
   AND A.IsDeleted = 0            
   AND LNK.IsAuditActive = 1            
   AND A.PlantID = @PlantID            
   AND LNK.IsDeleted = 0            
   AND ((IsRecurring = 0  AND StartDate <= CONVERT(DATE, LNK.ModifiedAt)) OR IsRecurring = 1)            
  GROUP BY LNK.AuditID            
   ,LNK.AuditTemplateID   
   ,LNK.ValueStreamID  
   ,LNK.IsAuditCompleted  
   ,CONVERT(DATE, LNK.ModifiedAt)            
   ,LNK.CreatedBy_NTID            
  ) AS t            
             
 create nonclustered index idx on #tempLNK_Audit_AnsweredQuestions (AuditID)            
 


If Exists(Select 1 from #AuditByNTID)
 SELECT  DISTINCT             
  CASE             
    WHEN T.TagTypeID = 1            
     THEN COALESCE('#' + T.TagName, '')            
    WHEN T.TagTypeID = 2            
     THEN COALESCE('#' + T.TagName, '')            
    WHEN T.TagTypeID = 3            
     THEN COALESCE('#' + T.TagName, '')    
 WHEN T.TagTypeID = 4          
  THEN COALESCE('#' + T.TagName, '')  
    END AS TagDisplayName             
  ,A.AuditID            
	 ,LNK.AuditTemplateID 
 --,(SELECT TOP 1 UserName  from T_MST_user where NTID = LNK.CreatedBy_NTID) AS CreatedBy_NTID           
       ,LNK.CreatedBy_NTID
  ,(SELECT TOP 1 CONCAT (            
   TVS.ValueStreamTemplateName            
   ,TVS.Delimiter            
   ,VS.ValueStreamName            
   )             
   FROM T_TRN_ValueStream VS WITH (NOLOCK)            
   INNER JOIN T_TRN_ValueStreamTemplate TVS WITH (NOLOCK) ON VS.ValueStreamTemplateID = TVS.ValueStreamTemplateID AND VS.ValueStreamID = A.ValueStreamID            
   ) AS ValueStreamName    

	,LNKAss.AssessorName             
  ,LNK.AnsweredTimeStamp            
  ,(case when 
  (select top 1 IsResumeTagDefined from T_TRN_Tag where Tagid=A.TagID)= 0 and lnk.IsAuditCompleted=0
   then  
    iif (lnk.AnswerPercentage is not null ,0,null)
  -- when (select top 1 IsResumeTagDefined from T_TRN_Tag where Tagid=A.TagID)= 1 and LNK.Answerpercentage is not null then 0 
   else lnk.IsAuditCompleted end )  AS IsAuditCompleted            
  ,case 
  when  LNK.IsAuditCompleted =1 then 100
  else LNK.AnswerPercentage     
  END AnswerPercentage         
  ,LNK.AnswerdQuestionCount            
  ,LNK.UnAnswerdQuestionCount            
  ,( SELECT TOP 1 CreatedAt            
    FROM T_LNK_Audit_AnsweredQuestions WITH (NOLOCK)            
    WHERE AuditID = LNK.AuditID            
     AND AuditTemplateID = LNK.AuditTemplateID            
   ) AS AnswerStartDate            
   ,( SELECT TOP 1 ModifiedAt            
    FROM T_LNK_Audit_AnsweredQuestions WITH (NOLOCK)            
    WHERE AuditID = LNK.AuditID            
     AND AuditTemplateID = LNK.AuditTemplateID            
   ) AS AnswerEndDate            
  ,A.StartDate            
  ,A.StartTime            
  ,A.EndDate            
  ,A.EndTime            
  --,Usr.RequiredAttendees AS RequiredAttendeeStr            
  --,Usr.OptionalAttendees AS OptionalAttendeeStr            
  ,A.IsRecurring            
  --,A.Remarks            
  ,A.TagID            
  ,A.IsAllDay            
  ,R.RecurrenceTypeId AS Recurrence_TypeId            
  ,R.Interval AS Recurrence_Interval            
  ,R.DayOfWeek AS Recurrence_DayOfWeek            
  ,R.DayOfMonth AS Recurrence_DayOfMonth            
  ,R.WeekOfMonth AS Recurrence_WeekOfMonth            
  ,R.MonthOfYear AS Recurrence_MonthOfYear 
  ,T.AnonymizeUserDataSettingID
 ,A.createdBy_NTID
  FROM T_TRN_Audit A WITH(NOLOCK)
 -- INNER JOIN #AuditByNTID abid  WITH(NOLOCK) ON  abid.AuditID = A.AuditID         
 INNER JOIN T_TRN_Tag T  WITH(NOLOCK) ON T.TagID = A.TagID      
     
 LEFT JOIN T_TRN_Recurrence R  WITH(NOLOCK) ON R.AuditID = A.AuditID            
 LEFT JOIN #tempLNK_Audit_AnsweredQuestions LNK  WITH(NOLOCK) ON LNK.AuditID = A.AuditID            
  AND LNK.AuditTemplateID > 0          
          
 --LEFT JOIN T_TRN_DataPool DP  WITH(NOLOCK) ON A.AuditID = DP.AuditID             
          
  --AND DP.IsDeleted = 0            
  AND A.IsDeleted = 0            
 -- AND DP.PlantID = @PlantID            
  --AND A.TagID = DP.TagID            
 -- AND DP.AuditTemplateID = LNK.AuditTemplateID            
-- LEFT JOIN #Attendees Usr  WITH(NOLOCK) ON Usr.AuditID = A.AuditID            
 LEFT JOIN #LinkedAssessorByAuditID  LNKAss  WITH(NOLOCK) ON            
       LNKAss.AuditID = LNK.AuditID            
       AND LNKAss.AuditTemplateID = LNK.AuditTemplateID     
 WHERE A.PlantID = @PlantID 
AND  (A.StartDate Between  @FromDate and  @ToDate OR A.EndDate Between @FromDate and @ToDate or A.StartDate <  @FromDate AND A.EndDate > @ToDate)

--AND  (A.StartDate Between  @FromDate and @ToDate OR A.EndDate Between  @FromDate and @ToDate)

 Drop table #AuditByNTID
 Drop table #Attendees
 Drop table #LinkedAssessorByAuditID
 Drop table #LinkedAuditID
 Drop table #tempLNK_Audit_AnsweredQuestions
END     
GO