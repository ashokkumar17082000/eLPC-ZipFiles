/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_AddEditCustomMode]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR ADDING/EDITING CUSTOM MODE
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					28-MAR-2021			SIKHESH S					ADDITIONAL PARAMATERS INCLUDED AND RELEATED CHANGES, STANDARD RULES APPLIED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_AddEditCustomMode] 
*/
CREATE PROCEDURE [USP_AddEditCustomMode] (
	@CustomModeID INT NULL
	,@CreatedAt DATETIME NULL
	,@IsDeleted BIT NULL
	,@AssignedTags XML NULL
	,@AssignedQuestions XML NULL
	,@IsCompleted BIT NULL
	,@PlantID INT
	,@CurrentUserNTID NVARCHAR(20)
	)
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION ADDEDITCUSTOMMODE;

		SELECT ROW_NUMBER() OVER (
				ORDER BY Question.value('(QuestionID/text())[1]', 'int')
				) AS RowID
			,Question.value('(QuestionID/text())[1]', 'int') AS QuestionID
			,Question.value('(CustomQuestionTagsID/text())[1]', 'int') AS CustomQuestionTagsID
		INTO #TmpQuestions
		FROM @AssignedQuestions.nodes('/ArrayOfQuestion/Question') AS TEMPTABLE(Question)

		SELECT ROW_NUMBER() OVER (
				ORDER BY Tag.value('(TagID/text())[1]', 'int')
				) AS RowID
			,Tag.value('(TagID/text())[1]', 'int') AS TagID
			,Tag.value('(CustomQuestionTagsID/text())[1]', 'int') AS CustomQuestionTagsID
		INTO #TmpTags
		FROM @AssignedTags.nodes('/ArrayOfTag/Tag') AS TEMPTABLE(Tag)

		--DECLARATION
		DECLARE @totalQuestionRows INT = (
				SELECT count(*)
				FROM #TmpQuestions
				)
		DECLARE @totalTagRows INT = (
				SELECT count(*)
				FROM #TmpTags
				)
		DECLARE @CustomQuestionTagsID INT;
		DECLARE @tmpQusetionID INT;
		DECLARE @currentQuestionRow INT;
		DECLARE @tmpAnswerTypeID INT
		DECLARE @currentTagRow INT
		DECLARE @tmpTagID INT
		DECLARE @TagID INT;

		SET @CreatedAt = (
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				);
		SET @IsCompleted = 0;
		SET @IsDeleted = 0;

		DECLARE @min INT = 0
			,@max INT = 0

		SET @CustomModeID = (
				SELECT TOP 1 CustomModeID
				FROM T_TRN_CustomMode WITH (NOLOCK)
				WHERE CreatedBy_NTID = @CurrentUserNTID
					AND PlantID = @PlantID
				)

		IF (
				@CustomModeID IS NULL
				OR @CustomModeID = 0
				)
		BEGIN
			INSERT INTO T_TRN_CustomMode (
				PlantID
				,CreatedAt
				,IsCompleted
				,CreatedBy_NTID
				)
			VALUES (
				@PlantID
				,@CreatedAt
				,@IsCompleted
				,@CurrentUserNTID
				)

			SET @CustomModeID = SCOPE_IDENTITY()
		END

		SET @currentQuestionRow = 1

		WHILE @currentQuestionRow <= @totalQuestionRows
		BEGIN
			SET @tmpQusetionID = (
					SELECT TOP 1 QuestionID
					FROM #TmpQuestions
					WHERE RowID = @currentQuestionRow
					);
			SET @customQuestionTagsID = (
					SELECT TOP 1 CustomQuestionTagsID
					FROM [T_LNK_Custom_QuestionsTags] WITH (NOLOCK)
					WHERE QuestionID = @tmpQusetionID
						AND CustomModeID = @CustomModeID
					);

			IF (@customQuestionTagsID IS NOT NULL)
			BEGIN
				--Update Question      
				UPDATE [T_LNK_Custom_QuestionsTags]
				SET IsDeleted = 0
				WHERE QuestionID = @tmpQusetionID
					AND CustomModeID = @CustomModeID

				UPDATE [T_LNK_Custom_Questions]
				SET IsDeleted = 0
					,IsCustomMode = 1
				WHERE CustomQuestionTagsID = @customQuestionTagsID
					AND CustomModeID = @CustomModeID
			END
			ELSE
			BEGIN
				--INSERT Question      
				INSERT INTO [T_LNK_Custom_QuestionsTags] (
					CustomModeID
					,QuestionID
					)
				VALUES (
					@CustomModeID
					,@tmpQusetionID
					)

				SET @CustomQuestionTagsID = SCOPE_IDENTITY();
				SET @tmpAnswerTypeID = (
						SELECT AnswerType_AnswerTypeID
						FROM [T_TRN_Question] WITH (NOLOCK)
						WHERE QuestionID = @tmpQusetionID
							AND PlantID = @PlantID
						)

				INSERT INTO [T_LNK_Custom_Questions] (
					CustomModeID
					,QuestionID
					,AnswerTypeID
					,IsCustomMode
					,CustomQuestionTagsID
					)
				VALUES (
					@CustomModeID
					,@tmpQusetionID
					,@tmpAnswerTypeID
					,1
					,@CustomQuestionTagsID
					)
			END

			SET @currentQuestionRow = @currentQuestionRow + 1
		END

		SET @currentTagRow = 1

		WHILE @currentTagRow <= @totalTagRows
		BEGIN
			SET @tmpTagID = (
					SELECT Tagid
					FROM #TmpTags
					WHERE RowID = @currentTagRow
					);

			EXEC [USP_AddQuestionsByCustomModeID] @CustomModeID
				,@tmpTagID
				,@PlantID
				,@CurrentUserNTID

			SET @currentTagRow = @currentTagRow + 1
		END

		COMMIT TRANSACTION INSERTINTODEVIATION;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION INSERTINTODEVIATION;

		EXEC USP_LogError @PlantID
			,@CurrentUserNTID;
	END CATCH
END
GO


