/****** Object:  StoredProcedure [uatgrp1].[USP_DeletetempAttachment]    Script Date: 4/30/2024 3:59:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [USP_DeletetempAttachment] (
	-- @ValueStreamID INT
	--,@DeviationDescription NVARCHAR(500)
	--,@ResponsibleEmployee NVARCHAR(200)
	--,@HintImages XML NULL
	--,@PlantID INT
	--,@AdditionalEmployee XML NULL
	--,@TagName XML NULL
	--,@IsDeleted BIT NULL
	  @CurrentUserNTID NVARCHAR(20)
	  ,@Displayfilename NVARCHAR(500)
	)
AS
IF @Displayfilename != NULL and  @Displayfilename !='TEMP'
BEGIN

	BEGIN TRY
		BEGIN TRANSACTION DeletetempAttachment;

		DELETE FROM [T_TRN_DeviationAttachments] 
		WHERE IsDeleted=1 and CreatedBy_NTID=@CurrentUserNTID
				


		COMMIT TRANSACTION DeletetempAttachment;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION DeletetempAttachment;


	END CATCH



END
ELSE 
BEGIN

	BEGIN TRY
		BEGIN TRANSACTION DeletetempAttachment;


		IF (@Displayfilename='TEMP')
		BEGIN 
		DELETE FROM [T_TRN_DeviationAttachments] 
		WHERE IsDeleted=1 and CreatedBy_NTID=@CurrentUserNTID
		END 
		ELSE
		BEGIN 
		DELETE FROM [T_TRN_DeviationAttachments] 
		WHERE IsDeleted=1 and CreatedBy_NTID=@CurrentUserNTID 
		and DisplayFileName=@Displayfilename
		END 
		COMMIT TRANSACTION DeletetempAttachment;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION DeletetempAttachment;


	END CATCH


END
GO