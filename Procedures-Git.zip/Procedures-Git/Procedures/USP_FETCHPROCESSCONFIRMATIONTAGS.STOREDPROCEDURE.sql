/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchProcessConfirmationTags]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING PROCESS CONFIRMATION TAGS
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					22-MAR-2021			KARTHIKEYAN KANDASAMY		PLANTID ADDED
ELPC_LH_002					25-MAY-2022			SHUBHAM BARANGE		        Added Is Accessible Column for Merge 
ELPC_LH_006					18-AUG-2023 			SUSHANTH		        Global Tag 
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_FetchProcessConfirmationTags] 1
*/
CREATE PROCEDURE [USP_FetchProcessConfirmationTags] (@PlantID INT    
,@CurrentUserNTID NVARCHAR(20))    
AS    
BEGIN    
 SET NOCOUNT ON;    
    
 SELECT TagID    
  ,PlantID    
  ,TagDisplayID    
  ,TagName    
  ,IsSingleQuestionSuppressed    
  ,SuppressedDateRangeFrom    
  ,SuppressedDateRangeTo    
  ,IsTargetFrequencyDefined    
  ,TargetFrequencyTypeID    
  ,TargetFrequencyValue    
  ,Tag_PriorityID    
  ,TagTypeID    
  ,IsLocked    
  ,AnonymizeUserDataSettingID    
  ,IsBranchLogicToBeFollowed    
  ,IsMandatoryAssessorsDefined    
  ,IsDeleted    
  ,CreatedAt    
  ,ModifiedAt    
  ,CreatedBy_NTID    
  ,ModifiedBy_NTID    
  -- ,Assigned_ValueStreamTemplateID    
  -- ,Assigned_ValueStreamCategoryID    
  -- ,Assigned_AssessorTemplateID    
  ,CASE     
   WHEN TagTypeID = 1    
    THEN COALESCE('#' + TagName, '')    
   WHEN TagTypeID = 2    
    THEN COALESCE('#' + TagName, '')    
   WHEN TagTypeID = 3    
    THEN COALESCE('#' + TagName, '')    
 WHEN TagTypeID = 4    
    THEN COALESCE('#' + TagName, '')    
   END AS TagDisplayName    
  ,CASE     
   WHEN IsLocked = 1    
    THEN IIF((    
       SELECT COUNT(*)    
       FROM T_LNK_Tag_Proxy    
       WHERE TagID = T_TRN_TAG.TagID    
        AND (    
         Proxy = @CurrentUserNTID    
         OR CreatedBy_NTID = @CurrentUserNTID    
         OR ModifiedBy_NTID = @CurrentUserNTID    
         )    
        AND IsDeleted=0    
       ) > 0, 1, 0)    
   ELSE 1    
   END AS IsAccessible    
 FROM T_TRN_TAG WITH (NOLOCK)    
 WHERE (    
   PlantID = @PlantID    
   --AND TagTypeID = 1    
   AND IsDeleted = 0    
   );    
END 
GO