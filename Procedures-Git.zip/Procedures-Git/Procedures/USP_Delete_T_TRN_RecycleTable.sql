/*///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_Delete_T_TRN_RecycleTable]
///AUTHOR                       : SHUBHAM BARANGE
///CREATED DATE                 : 15-NOV-2023
///SEE ALSO                     : THIS PROCEDURE FOR Permanently Deleting Data from Recycle Bin or RECYCLE TABLE
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_002_CR05			15-NOV-2023			SHUBHAM 				  Restore Recylebin/linkages 
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_Delete_T_TRN_RecycleTable] 1, 'GGP1COB'
*/
CREATE PROCEDURE [USP_Delete_T_TRN_RecycleTable] @recycleTable [RecycleTable] READONLY
	,@PlantID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	DECLARE @resultCode INT;
	DECLARE @resultMessage NVARCHAR(50);
	DECLARE @DatapoolID INT
	DECLARE @AuditID INT
	DECLARE @AuditTemplateID INT

	BEGIN TRANSACTION [Restore]

	BEGIN TRY
		DELETE
		FROM [T_TRN_ValueStream]
		WHERE ValueStreamTemplateID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Value Stream Template'
				)

	DELETE
		FROM [T_TRN_ValueStreamCategory]
		WHERE ValueStreamTemplateID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Value Stream Template'
				)

	DELETE
		FROM [T_HST_ValueStreamTemplateHistory]
		WHERE ValueStreamTemplateID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Value Stream Template'
				)

		DELETE
		FROM [T_TRN_ValueStreamTemplate]
		WHERE ValueStreamTemplateID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Value Stream Template'
				)
			AND PlantID = @PlantID

			DELETE
		FROM [T_TRN_Assessor]
		WHERE AssessorTemplateID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Assessor'
				)

		DELETE
		FROM [T_TRN_AssessorTemplate]
		WHERE AssessorTemplateID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Assessor'
				)
			AND PlantID = @PlantID;

		DELETE
		FROM [T_lnk_Audit_AssignedQuestions]
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		DELETE
		FROM [T_TRN_SingleLineText]
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)
				DELETE
		FROM [T_TRN_Choice]
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

        
        DELETE
		FROM [T_TRN_Question]
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)
			AND PlantID = @PlantID;

		DELETE
		FROM T_LNK_QN_AssignedTags
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		DELETE
		FROM [T_LNK_AssignedAssessorsHistory]
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		DELETE
		FROM [T_LNK_AssignedAssessors]
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		DELETE
		FROM [T_LNK_AssignedValueStreamsHistory]
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		DELETE
		FROM [T_TRN_HintImageHistory]
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		DELETE
		FROM [T_TRN_HintImage]
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		DELETE
		FROM [T_TRN_HintHyperLinkHistory]
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		DELETE
		FROM [T_TRN_HintHyperLink]
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		DELETE
		FROM [T_TRN_ChoiceHistory]
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		

		DELETE
		FROM [T_TRN_MultipleLinesTextHistory]
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		DELETE
		FROM [T_TRN_MultipleLinesText]
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		DELETE
		FROM [T_TRN_SingleLineTextHistory]
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		

		DELETE
		FROM [T_LNK_Question_Proxy]
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		DELETE
		FROM [T_TRN_QuestionHistory]
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

				DELETE
		FROM [T_LNK_Audit_AssignedTags]
		WHERE TagID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Tag'
				)
				DELETE
		FROM [T_LNK_QN_AssignedTags]
		WHERE TagID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Tag'
				)

				DELETE
		FROM [T_LNK_QN_AssignedTagsHistory]
		WHERE TagID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Tag'
				)

		DELETE
		FROM [T_LNK_Tag_AssignedQuestionsTagsHistory]
		WHERE TagID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Tag'
				);

				DELETE
		FROM [T_LNK_Tag_AssignedQuestionsTags]
		WHERE TagID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Tag'
				);
				DELETE
		FROM [T_LNK_Tag_AssignedAssessorsHistory]
		WHERE TagID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Tag'
				);

		DELETE
		FROM [T_LNK_Tag_AssignedAssessors]
		WHERE TagID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Tag'
				)

		DELETE
		FROM [T_LNK_Tag_AssignedValueStreamsHistory]
		WHERE TagID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Tag'
				)

		DELETE
		FROM [T_LNK_Tag_AssignedValueStreams]
		WHERE TagID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Tag'
				)

		DELETE
		FROM [T_LNK_Tag_Proxy]
		WHERE TagID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Tag'
				)

		DELETE
		FROM [T_TRN_TagHistory]
		WHERE TagID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Tag'
				)

		DELETE
		FROM [T_TRN_Tag]
		WHERE TagID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Tag'
				)
			AND PlantID = @PlantID;

			DELETE
		FROM [T_TRN_DataPool]
		WHERE DataPoolID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Data Pool'
				)
			AND PlantID = @PlantID;

		SET @DatapoolID = (
				SELECT TOP 1 ID
				FROM @recycleTable
				WHERE ItemType = 'Data Pool'
				)

		DECLARE @QuestionID INT = (
				SELECT QuestionID
				FROM [T_TRN_DataPool] WITH (NOLOCK)
				WHERE DatapoolID = @DatapoolID
				)

		IF @QuestionID IS NOT NULL
			AND @QuestionID > 0
		BEGIN
			EXEC [USP_UpdateDataPool_SummaryByQuestionID] @QuestionID
		END

		IF @DatapoolID IS NOT NULL
		BEGIN
			SET @AuditID = (
					SELECT AuditID
					FROM T_TRN_DataPool WITH (NOLOCK)
					WHERE DataPoolID = @DataPoolID
						AND PlantID = @PlantID
					)
			SET @AuditTemplateID = (
					SELECT AuditTemplateID
					FROM T_TRN_DataPool WITH (NOLOCK)
					WHERE DataPoolID = @DataPoolID
						AND PlantID = @PlantID
					)

			DELETE
			FROM [T_TRN_DataPool]
			WHERE AuditID = @AuditID
				AND AuditTemplateID = @AuditTemplateID
				AND PlantID = @PlantID;
		END

		SET @resultCode = 0;
		SET @resultMessage = 'Success';

		COMMIT TRANSACTION [Restore]

		SELECT @resultCode AS resultCode
			,@resultMessage AS resultMessage
	END TRY

	BEGIN CATCH
		SET @resultCode = 1;
		SET @resultMessage = 'Fail';

		ROLLBACK TRANSACTION [Restore]

		EXEC USP_LogError @PlantID
			,@CurrentUserNTID;

		SELECT @resultCode AS resultCode
			,@resultMessage AS resultMessage
	END CATCH
END
GO
