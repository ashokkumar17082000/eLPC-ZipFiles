/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE -  [USP_DeleteAssessorTemplate]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR DELETING ASSESSOR TEMPLATE
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					17-MAR-2021			KARTHIKEYAN KANDASAMY		PLANTID ADDED
ELPC_LH_002					18-MAR-2021			RAJASEKAR S					REPLACED TRIGGERS
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC  [USP_DeleteAssessorTemplate] 1,1,'2020-11-15 14:18:21.720','OSP4KOR'
*/
CREATE PROCEDURE [USP_DeleteAssessorTemplate] (
	@PlantID INT
	,@AssessorTemplateID INT
	,@ModifiedAt DATETIME
	,@CurrentUserNTID NVARCHAR(20)
	)
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION TRNDELETEASSTEMP

		SET @ModifiedAt = (
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				);

		UPDATE T_TRN_AssessorTemplate
		SET IsDeleted = 1
			,ModifiedBy_NTID = @CurrentUserNTID
			,ModifiedAt = @ModifiedAt
		WHERE AssessorTemplateID = @AssessorTemplateID
			AND PlantID = @PlantID;

		COMMIT TRANSACTION TRNDELETEASSTEMP;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNDELETEASSTEMP;

		EXEC [USP_LogError] @PlantID
			,@CurrentUserNTID;
	END CATCH
END
GO


