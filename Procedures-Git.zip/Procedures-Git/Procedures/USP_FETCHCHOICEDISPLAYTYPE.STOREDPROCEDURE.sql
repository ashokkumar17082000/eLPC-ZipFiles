/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchChoiceDisplayType]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING CHOICE DISPLAY TYPE
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			VENKATESH GOVINDARAJ		Code Cleanup

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_FetchChoiceDisplayType] 
*/
CREATE PROCEDURE [USP_FetchChoiceDisplayType]
AS
BEGIN
	SET NOCOUNT ON;

	SELECT ChoiceDisplayTypeID
		,ChoiceDisplayTypeName
		,IsDeleted
	FROM T_MST_ChoiceDisplayType WITH (NOLOCK)
	WHERE (IsDeleted = 0)
END
GO


