/*
EXEC [USP_FetchAuditAnswers_old] 1,'FSM1COB','2024-04-01','2024-04-04'
*/
CREATE  PROCEDURE [USP_FetchAuditAnswers_old] @PlantID INT              
 ,@CurrentUserNTID NVARCHAR(20) = NULL              
 ,@FromDate DATETIME = NULL             
 ,@ToDate DATETIME = NULL                
AS              
BEGIN              
 SET NOCOUNT ON;              
              
 SELECT DISTINCT DP.AuditID              
  ,DP.AuditTemplateID              
 INTO #LinkedAuditID              
 FROM T_TRN_DataPool DP WITH (NOLOCK)              
 WHERE PlantID = @PlantID AND AuditID > 0              
 create nonclustered index idxLA on #LinkedAuditID (AuditID)              
 SELECT LNK.AuditID              
  ,LNK.AuditTemplateID              
  ,(SELECT STRING_AGG(cast(AssessorName AS NVARCHAR(MAX)), ';') FROM T_LNK_AuditTemplate_AssessorDetail WITH (NOLOCK)              
    WHERE AuditID = LNK.AuditID              
     AND AuditTemplateID = LNK.AuditTemplateID              
     AND IsDeleted = 0)              
   AS AssessorName              
 INTO #LinkedAssessorByAuditID              
 FROM #LinkedAuditID LNK WITH (NOLOCK)              
 create nonclustered index idxLAB on #LinkedAssessorByAuditID (AuditID)              
 SELECT AuditID              
 ,(              
  SELECT STRING_AGG(cast(UserName AS NVARCHAR(MAX)), ';') AS UserName              
  FROM (              
   SELECT DISTINCT Usr.UserName              
   FROM T_LNK_Audit_RequiredAttendees Req WITH (NOLOCK)              
   INNER JOIN T_MST_User Usr ON Usr.NTID = Req.NTID  AND Usr.PlantID = @PlantID              
   WHERE AuditID = A.AuditID              
    AND Usr.UserName IS NOT NULL              
   ) AS Req              
  ) AS RequiredAttendees              
 ,(              
  SELECT STRING_AGG(cast(UserName AS NVARCHAR(MAX)), ';') AS UserName              
  FROM (              
   SELECT DISTINCT Usr.UserName              
   FROM T_LNK_Audit_OptionalAttendees Req WITH (NOLOCK)              
   INNER JOIN T_MST_User Usr ON Usr.NTID = Req.NTID AND Usr.PlantID = @PlantID              
   WHERE AuditID = A.AuditID              
    AND Usr.UserName IS NOT NULL              
   ) AS Opt              
  ) AS OptionalAttendees              
 INTO #Attendees              
 FROM T_TRN_Audit A WITH (NOLOCK)              
 WHERE A.PlantID = @PlantID              
              
 create nonclustered index idxAT on #Attendees (AuditID)              
              
 --Find Recurrance Answer status & details based on AuditID, AuditTemplateID              
 -- 0 Partial Answer completed for audit               
 -- 1 Audit Answer completed for all questions in audit              
 -- NULL not started              
 SELECT *,IIF(AnswerPercentage1 = 1 , 1, 0) AS IsAuditCompleted              
 INTO #tempLNK_Audit_AnsweredQuestions              
 FROM (              
  SELECT DISTINCT LNK.AuditID              
   ,LNK.AuditTemplateID    
   ,LNK.ValueStreamID    
   ,CONVERT(DATE, LNK.ModifiedAt) AS [AnsweredTimeStamp]              
   ,COUNT(QuestionID) AS TotalQuestionCount              
   ,COUNT(IIF(ISNULL(LNK.IsAnswered, 0) = 1, 1, NULL)) AS AnswerdQuestionCount              
   ,COUNT(IIF(ISNULL(LNK.IsAnswered, 0) = 0, 1, NULL)) AS UnAnswerdQuestionCount              
   ,CONVERT(INT, (1.0 * (COUNT(IIF(LNK.IsAnswered = 1, 1, NULL))) / (COUNT(QuestionID))) * 100) AS AnswerPercentage              
   ,LNK.IsAuditCompleted AS AnswerPercentage1    
   ,LNK.CreatedBy_NTID              
  FROM T_LNK_Audit_AnsweredQuestions LNK WITH (NOLOCK)              
  INNER JOIN T_TRN_Audit A WITH (NOLOCK) ON A.AuditID = LNK.AuditID         
   AND A.IsDeleted = 0              
   AND LNK.IsAuditActive = 1              
   AND A.PlantID = @PlantID              
   AND LNK.IsDeleted = 0              
   AND ((IsRecurring = 0  AND StartDate <= CONVERT(DATE, LNK.ModifiedAt)) OR IsRecurring = 1)              
  GROUP BY LNK.AuditID              
   ,LNK.AuditTemplateID     
   ,LNK.ValueStreamID    
   ,LNK.IsAuditCompleted    
   ,CONVERT(DATE, LNK.ModifiedAt)              
   ,LNK.CreatedBy_NTID              
  ) AS t              
  
 create nonclustered index idx on #tempLNK_Audit_AnsweredQuestions (AuditID)              
 --SELECT * FROM #tempLNK_Audit_AnsweredQuestions              
              
 -- Answer Status with necessary reccurance details              
 -- 0 Partial Answer completed for audit               
 -- 1 Audit Answer completed for all questions in audit              
 -- NULL not started              
 SELECT DISTINCT               
  CASE               
    WHEN T.TagTypeID = 1              
     THEN COALESCE('#' + T.TagName, '')              
    WHEN T.TagTypeID = 2              
     THEN COALESCE('#' + T.TagName, '')              
    WHEN T.TagTypeID = 3              
     THEN COALESCE('#' + T.TagName, '')      
 WHEN T.TagTypeID = 4            
  THEN COALESCE('#' + T.TagName, '')    
    END AS TagDisplayName               
  ,A.AuditID    
  ,A.IsDeleted
  ,LNK.AuditTemplateID   
 ,(SELECT TOP 1 UserName  from T_MST_user where NTID = LNK.CreatedBy_NTID) AS CreatedBy_NTID             
 -- ,(  
 --CASE   
 -- WHEN (SELECT TOP 1 AnonymizeUserDataSettingID  
 --   FROM T_TRN_Tag WITH (NOLOCK)    
 --   WHERE PlantID = @PlantID    
 --   AND TagID = T.TagID) = 1 THEN NULL  
 -- WHEN (SELECT TOP 1 AnonymizeUserDataSettingID  
 --   FROM T_TRN_Tag WITH (NOLOCK)    
 --   WHERE PlantID = @PlantID    
 --   AND TagID = T.TagID) = 2 THEN NULL  
 -- ELSE   
 --  (SELECT TOP 1 UserName  from T_MST_user where NTID = LNK.CreatedBy_NTID)  
 -- END  
 --  ) AS CreatedBy_NTID              
  ,(SELECT TOP 1 CONCAT (              
   TVS.ValueStreamTemplateName              
   ,TVS.Delimiter              
   ,VS.ValueStreamName              
   )               
   FROM T_TRN_ValueStream VS WITH (NOLOCK)              
   INNER JOIN T_TRN_ValueStreamTemplate TVS WITH (NOLOCK) ON VS.ValueStreamTemplateID = TVS.ValueStreamTemplateID AND VS.ValueStreamID = A.ValueStreamID              
   ) AS ValueStreamName      
 -- ,(  
 --CASE   
 -- WHEN (SELECT TOP 1 AnonymizeUserDataSettingID  
 --   FROM T_TRN_Tag WITH (NOLOCK)    
 --   WHERE PlantID = @PlantID    
 --   AND TagID = T.TagID) = 1 THEN NULL  
 -- WHEN (SELECT TOP 1 AnonymizeUserDataSettingID  
 --   FROM T_TRN_Tag WITH (NOLOCK)    
 --   WHERE PlantID = @PlantID    
 --   AND TagID = T.TagID) = 2 THEN   
 --   (SELECT DISTINCT CONCAT (TVS.ValueStreamTemplateName,TVS.Delimiter,VS.ValueStreamName) FROM T_TRN_ValueStream VS WITH (NOLOCK)����������������  
--� �    INNER JOIN T_TRN_ValueStreamTemplate TVS WITH (NOLOCK) ON VS.ValueStreamTemplateID = TVS.ValueStreamTemplateID  where VS.ValueStreamID = LNK.ValueStreamID and LNK.AuditID = A.AuditID)  
 -- ELSE   
 --  (SELECT DISTINCT CONCAT (TVS.ValueStreamTemplateName,TVS.Delimiter,VS.ValueStreamName) FROM T_TRN_ValueStream VS WITH (NOLOCK)����������������  
--� �    INNER JOIN T_TRN_ValueStreamTemplate TVS WITH (NOLOCK) ON VS.ValueStreamTemplateID = TVS.ValueStreamTemplateID  where VS.ValueStreamID = LNK.ValueStreamID and LNK.AuditID = A.AuditID)  
 -- END  
 --  ) AS ValueStreamName     
 -- ,(  
 --CASE   
 -- WHEN (SELECT TOP 1 AnonymizeUserDataSettingID  
 --   FROM T_TRN_Tag WITH (NOLOCK)    
 --   WHERE PlantID = @PlantID    
 --   AND TagID = T.TagID) = 1 THEN NULL  
 -- WHEN (SELECT TOP 1 AnonymizeUserDataSettingID  
 --   FROM T_TRN_Tag WITH (NOLOCK)    
 --   WHERE PlantID = @PlantID    
 --   AND TagID = T.TagID) = 2 THEN LNKAss.AssessorName  
 -- ELSE   
 --  LNKAss.AssessorName  
 -- END  
 --  ) AS AssessorName     
 ,LNKAss.AssessorName               
  ,LNK.AnsweredTimeStamp              
  ,(case when   
  (select top 1 IsResumeTagDefined from T_TRN_Tag where Tagid=A.TagID)= 0 and lnk.IsAuditCompleted=0  
   then    
    iif (lnk.AnswerPercentage is not null ,0,null)  
  -- when (select top 1 IsResumeTagDefined from T_TRN_Tag where Tagid=A.TagID)= 1 and LNK.Answerpercentage is not null then 0   
   else lnk.IsAuditCompleted end )  AS IsAuditCompleted              
  ,case   
  when  LNK.IsAuditCompleted =1 then 100  
  else LNK.AnswerPercentage       
  END AnswerPercentage           
  ,LNK.AnswerdQuestionCount              
  ,LNK.UnAnswerdQuestionCount              
  ,( SELECT TOP 1 CreatedAt              
    FROM T_LNK_Audit_AnsweredQuestions WITH (NOLOCK)              
    WHERE AuditID = LNK.AuditID              
     AND AuditTemplateID = LNK.AuditTemplateID              
   ) AS AnswerStartDate              
   ,( SELECT TOP 1 ModifiedAt              
    FROM T_LNK_Audit_AnsweredQuestions WITH (NOLOCK)              
    WHERE AuditID = LNK.AuditID              
     AND AuditTemplateID = LNK.AuditTemplateID              
   ) AS AnswerEndDate              
  ,A.StartDate              
  ,A.StartTime              
  ,A.EndDate              
  ,A.EndTime              
  ,Usr.RequiredAttendees AS RequiredAttendeeStr              
  ,Usr.OptionalAttendees AS OptionalAttendeeStr              
  ,A.IsRecurring              
  ,A.Remarks              
  ,A.TagID              
  ,A.IsAllDay              
  ,R.RecurrenceTypeId AS Recurrence_TypeId              
  ,R.Interval AS Recurrence_Interval              
  ,R.DayOfWeek AS Recurrence_DayOfWeek              
  ,R.DayOfMonth AS Recurrence_DayOfMonth              
  ,R.WeekOfMonth AS Recurrence_WeekOfMonth              
  ,R.MonthOfYear AS Recurrence_MonthOfYear   
  ,T.AnonymizeUserDataSettingID  
  FROM T_TRN_Audit A              
 INNER JOIN T_TRN_Tag T ON T.TagID = A.TagID              
 LEFT JOIN T_TRN_Recurrence R ON R.AuditID = A.AuditID              
 LEFT JOIN #tempLNK_Audit_AnsweredQuestions LNK ON LNK.AuditID = A.AuditID              
  AND LNK.AuditTemplateID > 0            
  --AND A.CreatedBy_NTID = @CurrentUserNTID              
 LEFT JOIN T_TRN_DataPool DP ON A.AuditID = DP.AuditID               
 --and DP.[TimeStamp] >= @FromDate               
 --and DP.[TimeStamp] <= @Todate              
  AND DP.IsDeleted = 0              
  AND A.IsDeleted = 0              
  AND DP.PlantID = @PlantID              
  AND A.TagID = DP.TagID              
  AND DP.AuditTemplateID = LNK.AuditTemplateID              
 LEFT JOIN #Attendees Usr ON Usr.AuditID = A.AuditID              
 LEFT JOIN #LinkedAssessorByAuditID  LNKAss ON              
       LNKAss.AuditID = LNK.AuditID              
       AND LNKAss.AuditTemplateID = LNK.AuditTemplateID              
 WHERE A.PlantID = @PlantID         
 AND A.StartDate >= IIF(@FromDate IS NULL OR @FromDate= '1900-01-01 00:00:00.000', A.StartDate, @FromDate)   
          AND A.EndDate <= IIF(@ToDate IS NULL OR @ToDate = '1900-01-01 00:00:00.000', A.EndDate, @ToDate)
 -- AND  (A.StartDate Between  @FromDate and  @ToDate OR A.EndDate Between @FromDate and @ToDate or A.StartDate <  @FromDate AND A.EndDate > @ToDate)
   		  AND A.IsDeleted=0
  --AND  ((A.StartDate  >=  @FromDate AND A.StartDate <= @ToDate)             
  --OR  (A.EndDate >= @FromDate AND A.EndDate <=  @ToDate ))             
  --AND DP.AnsweredBy_NTID = @CurrentUserNTID              
  --AND GetDATE() BETWEEN DATEADD(Year,-1,GETDATE()) AND DATEADD(yy, DATEDIFF(yy, 0, GETDATE()) + 1, -1)                
  ---- FROM Current date of previous year to last date of current year              
  ---- Sample Today May 5 2022 == > From  = May 5 2021 AND To = Dec 31 2022              
END 

GO