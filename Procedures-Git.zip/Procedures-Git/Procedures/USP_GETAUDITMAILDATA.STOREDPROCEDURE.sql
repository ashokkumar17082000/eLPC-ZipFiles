/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_GetAuditMailData]
///AUTHOR                       : RAJASEKAR S
///CREATED DATE                 : 26-JUL-2021
///SEE ALSO                     : THIS PROCEDURE TO GET AUDIT MAIL CONTENT 
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_003					26-JUL-2021			RAJASEKAR S					INITIAL VERSION
ELPC_LH_006					18-AUG-2023			ASHOK KUMAR R B					Ordering the answer mail data in randomquestionorder

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
EXEC [USP_GetAuditMailData] 77,6,''
*/

CREATE PROCEDURE [USP_GetAuditMailData] (    
 @AuditID INT    
 ,@AuditTemplateID INT    
 ,@CurrentUserNTID NVARCHAR(20)    
 ,@PlantID INT    
 )    
AS    
BEGIN    
 DECLARE @NtIdTable TABLE (NTID VARCHAR(20));    
 DECLARE @From VARCHAR(MAX);    
 DECLARE @To VARCHAR(MAX);    
 DECLARE @Cc VARCHAR(MAX);    
 DECLARE @Subject NVARCHAR(MAX);    
 DECLARE @Body NVARCHAR(MAX);    
 DECLARE @TagName VARCHAR(MAX);    
 DECLARE @LeadAuditor VARCHAR(MAX);    
 DECLARE @Attendees VARCHAR(MAX);    
 DECLARE @ValueStreamText NVARCHAR(MAX);    
 DECLARE @TagID INT = 0  
  
 SELECT TOP (1) @TagID = [TagID]  
 FROM T_TRN_Audit WITH (NOLOCK)  
 WHERE AuditID = @AuditID  
  AND PlantID = @PlantID;  
 --FROM    
 INSERT INTO @NtIdTable    
 SELECT CreatedBy_NTID    
 FROM T_TRN_Audit WITH(NOLOCK)    
 WHERE AuditID = @AuditID    
    
 SELECT @From = STUFF((    
    SELECT DISTINCT ';' + EmailAddress    
    FROM T_MST_User    
    WHERE NTID IN (    
      SELECT NTID    
      FROM @NtIdTable    
      )    
    FOR XML PATH('')    
    ), 1, 1, '')    
    
 DELETE    
 FROM @NtIdTable    
    
 --To    
 INSERT INTO @NtIdTable    
 SELECT NTID    
 FROM T_LNK_AuditTemplate_AssessorDetail WITH(NOLOCK)    
 WHERE AuditID = @AuditID    
  AND AuditTemplateID = @AuditTemplateID    
  AND NTID IS NOT NULL --Lead Auditor, Assessors    
     
 UNION    
     
 SELECT NTID    
 FROM T_LNK_AuditTemplate_OtherAssessorDetail WITH(NOLOCK)    
 WHERE AuditID = @AuditID    
  AND AuditTemplateID = @AuditTemplateID    
  AND NTID IS NOT NULL --Other Assessors    
    
 SELECT @To = STUFF((    
    SELECT DISTINCT ';' + EmailAddress    
    FROM T_MST_User WITH(NOLOCK)    
    WHERE NTID IN (    
      SELECT NTID    
      FROM @NtIdTable    
      )    
    FOR XML PATH('')    
    ), 1, 1, '')    
    
 --SELECT @Attendees = STUFF((    
 --   SELECT DISTINCT ';' + UserName    
 --   FROM T_MST_User    
 --   WHERE NTID IN (    
 --     SELECT NTID    
 --     FROM @NtIdTable    
 --     )    
 --   FOR XML PATH('')    
 --   ), 1, 1, '')    
 SELECT @Attendees = STRING_AGG(cast(Assessors AS NVARCHAR(MAX)), '    
')    
 FROM (    
  SELECT '<b>' + LNK.AssessorName + ':</b>    
 ' + (    
    SELECT STRING_AGG(cast('<span style="white-space: pre;"> ' + UserName + '</span>' AS NVARCHAR(MAX)), '    
   ') WITHIN    
    GROUP (    
      ORDER BY UserName    
      ) AS UserName    
    FROM T_MST_User WITH(NOLOCK)    
    WHERE NTID IN (    
      SELECT DISTINCT NTID    
      FROM T_LNK_AuditTemplate_AssessorDetail WITH(NOLOCK)    
      WHERE AuditID = @AuditID    
       AND AuditTemplateID = @AuditTemplateID    
       AND NTID IS NOT NULL    
       AND LNK.AssessorName = AssessorName    
       AND IsDeleted = 0    
      )    
     AND PlantID = @PlantID    
    ) AS Assessors    
  FROM T_LNK_AuditTemplate_AssessorDetail LNK WITH(NOLOCK)    
  WHERE AuditID = @AuditID    
   AND AuditTemplateID = @AuditTemplateID    
   AND NTID IS NOT NULL    
   AND IsDeleted = 0    
   AND AssessorName <> 'LeadAuditor'    
  GROUP BY LNK.AssessorName    
      
  UNION    
      
  SELECT ISNULL(LNK.AssessorName, '<b>Other Assessor</b>') + ':    
       ' + (    
    SELECT STRING_AGG(cast('<span style="white-space: pre;"> ' + UserName + '</span>' AS NVARCHAR(MAX)), '    
         ') WITHIN    
    GROUP (    
      ORDER BY UserName    
      ) AS UserName    
    FROM T_MST_User WITH(NOLOCK)    
    WHERE NTID IN (    
      SELECT DISTINCT NTID    
      FROM T_LNK_AuditTemplate_OtherAssessorDetail WITH(NOLOCK)    
      WHERE AuditID = @AuditID    
       AND AuditTemplateID = @AuditTemplateID    
       AND NTID IS NOT NULL    
       AND IsDeleted = 0    
      )    
     AND PlantID = @PlantID    
    ) AS Assessors    
  FROM T_LNK_AuditTemplate_OtherAssessorDetail LNK WITH(NOLOCK)    
  WHERE AuditID = @AuditID    
   AND AuditTemplateID = @AuditTemplateID    
   AND NTID IS NOT NULL    
   AND IsDeleted = 0    
  GROUP BY LNK.AssessorName    
  ) AS t    
    
 DELETE    
 FROM @NtIdTable    
    
 --CC    
 INSERT INTO @NtIdTable    
 SELECT CreatedBy_NTID    
 FROM T_TRN_Audit WITH(NOLOCK)    
 WHERE AuditID = @AuditID    
     
 UNION    
     
 SELECT Responsible_UserID    
 FROM T_TRN_ValueStream V WITH(NOLOCK)    
 INNER JOIN T_TRN_Audit A ON A.ValueStreamID = V.ValueStreamID    
 WHERE A.AuditID = @AuditID    
     
 UNION    
     
 SELECT NTID    
 FROM T_LNK_Audit_RequiredAttendees WITH(NOLOCK)    
 WHERE AuditID = @AuditID    
     
 UNION    
     
 SELECT NTID    
 FROM T_LNK_Audit_OptionalAttendees WITH(NOLOCK)    
 WHERE AuditID = @AuditID    
    
 --SELECT NTID FROM @NtIdTable    
 --SELECT EmailAddress from T_MST_User where NTID IN (SELECT NTID FROM @NtIdTable)    
 SELECT @Cc = STUFF((    
    SELECT DISTINCT ';' + EmailAddress    
    FROM T_MST_User WITH(NOLOCK)    
    WHERE NTID IN (    
      SELECT NTID    
      FROM @NtIdTable    
      )    
    FOR XML PATH('')    
    ), 1, 1, '')    
    
 --Subject    
 SELECT @Subject = T.TagName    
 FROM T_TRN_Audit A WITH(NOLOCK)    
 INNER JOIN T_TRN_Tag T WITH(NOLOCK) ON A.TagID = T.TagID    
 WHERE A.AuditID = @AuditID --AuditorSurvey Type>> (Audit / Survey)    
    
 --Body    
 SELECT @LeadAuditor = U.UserName    
 FROM T_LNK_AuditTemplate_AssessorDetail AD WITH(NOLOCK)    
 INNER JOIN T_MST_User U  WITH(NOLOCK) ON AD.NTID = U.NTID    
 WHERE AD.AuditID = @AuditID    
  AND AD.AuditTemplateID = @AuditTemplateID    
  AND AD.AssessorName = 'LeadAuditor'    
  AND AD.NTID IS NOT NULL    
    
 SET @ValueStreamText=(  
SELECT  ValueStreamName  
 FROM T_TRN_Audit A WITH(NOLOCK)    
 INNER JOIN T_TRN_ValueStream V WITH(NOLOCK) ON A.ValueStreamID = V.ValueStreamID    
 WHERE A.AuditID = @AuditID )  
    
 SELECT @From [From]    
  ,@To [To]    
  ,@Cc Cc    
  ,@Subject [Subject]    
  ,@LeadAuditor LeadAuditor    
  ,@Attendees Attendees    
  ,@ValueStreamText ValueStreamText    
  ,(    
   SELECT FormattedDateTime    
   FROM [fnGetDateTime](@PlantID)    
   ) AS AnsweredTime    
    
 SELECT D.QuestionID    
  ,'Q' + CAST(Q.QuestionDisplayID AS VARCHAR) AS QuestionDisplayID    
  ,Q.QuestionText   
  ,RQ.RandomQuestionOrder   
  ,(
  
  CASE   
  
   WHEN D.answerType_AnswerTypeID = 3 and D.choiceID IS NULL 
	 THEN 'Question Skipped'
	   
   WHEN D.answerType_AnswerTypeID = 3    
    THEN (    
      SELECT TOP 1 ChoiceName    
      FROM T_TRN_Choice WITH(NOLOCK)    
      WHERE choiceID = D.ChoiceID    
      )   
	

	 WHEN D.Answer IS NULL 
	 THEN 'Question Skipped' 
   ELSE Answer    
   END) AS Answer   
  ,CASE     
   WHEN D.IsDeviation = 1    
    THEN (    
      SELECT TOP 1 DV.DeviationDescription    
      FROM T_TRN_Deviation DV WITH(NOLOCK)    
      WHERE DV.DeviationID = D.DeviationID    
      )    
    
   ELSE NULL    
   END AS DeviationDescription    
 FROM T_TRN_DataPool D WITH(NOLOCK)    
 LEFT JOIN T_TRN_Question Q WITH(NOLOCK) ON Q.QuestionID = D.QuestionID    
 LEFT JOIN T_LNK_Tag_AssignedQuestionsTags RQ WITH (NOLOCK) ON RQ.QuestionID = Q.QuestionID  
  AND RQ.TagID = @tagid and RQ.IsDeleted=0  
 WHERE AuditID = @AuditID   
  AND AuditTemplateID = @AuditTemplateID    
  ORDER BY  case when RQ.RandomQuestionOrder  is null then 998  end, RQ.RandomQuestionOrder  
  ,Question_PriorityID   
 ,TargetFrequencyTypeID  
 ,ChoiceDisplayTypeID DESC  
 ,QuestionID  
END    
    
GO