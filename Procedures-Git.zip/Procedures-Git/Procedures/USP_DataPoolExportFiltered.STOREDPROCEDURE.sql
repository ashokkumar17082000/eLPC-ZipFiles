/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_DataPoolExport]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE TO EXPORT DATA POOL
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					25-MAR-2021			SIKHESH S					ADDITIONAL INPUT PARAMATERS INCLUDED, STANDARD RULES APPLIED
Phase2-eLPC_LH_003		    22-JUL-2021			MONASH CHHETRI				REPLACED QUESTION ID WITH QUESTION TEXT IN THE LAST SELECT QUERY
ELPC_LH_005                 15-MAR-2023         GOPIKA P G                  ADDITIONAL PARAMETERS INCLUDED FOR INFO EMPLOYEE AND TAG
ELPC_LH_005                 21-FEB-2024         ASHOK						Standard User parameter change 
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_DataPoolExportFiltered] 1,'FSM1COB','2024-02-01','2024-04-01'
*/
CREATE  PROCEDURE [USP_DataPoolExportFiltered] (
	@PlantID INT
	,@CurrentUserNTID NVARCHAR(20) = NULL
	,@FromDate DATETIME =NULL
	,@ToDate DATETIME =NULL
	)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT  q.QuestionID
		,(
			SELECT ListTag
			FROM [FN_GetNestedTagsByQuestionID](Q.QuestionID, 'strTagName')
			WHERE ListTag IS NOT NULL
			) AS TagNameList
	INTO #LinkedTagsByQuestionID
	FROM T_TRN_Question Q WITH (NOLOCK)
	WHERE PlantID = @PlantID
	
		DECLARE @temp TABLE (
		DataPoolID INT
		,DataPoolDisplayID INT
		,TIMESTAMP DATETIME
		,UserName NVARCHAR(200)
		,ValueStreamData NVARCHAR(MAX)
		,AssessorName NVARCHAR(MAX)
		,QuestionID INT
		,QuestionDisplayID INT
		,QuestionText NVARCHAR(MAX)
		,Answer NVARCHAR(MAX)
		,ChoiceID NVARCHAR(MAX)
		,ObtainedScore DECIMAL(10, 2)
		,answerType_AnswerTypeID INT
		,ValueStreamID INT
		,AssessorID INT
		,DeviationID INT
		,TagID INT
		,AuditID INT
		,AuditTemplateID INT
		,AnsweredBy_NTID NVARCHAR(20)
		,TagIDList NVARCHAR(MAX)
		,OriginTag NVARCHAR(MAX)
		,OPLURL NVARCHAR(MAX)
		,InfoEmployee NVARCHAR(MAX)
		,TagName NVARCHAR(MAX)
		,Tag NVARCHAR(MAX)
		,AnonymizeUserDataSettingID NVARCHAR (MAX)
		);

	INSERT INTO @temp
	EXEC [USP_GetDataPool_old] @PlantID
		,@CurrentUserNTID
		,@FromDate
		,@ToDate
		

	SELECT  DataPoolID
		,DataPoolDisplayID
		,TIMESTAMP
		,UserName
		,ValueStreamData
		,AssessorName
		,OriginTag
		,OPLURL
		,QuestionDisplayID
		,QuestionText
		,Answer
		,ObtainedScore
		,lnk.TagNameList AS TagName
		,InfoEmployee AS InformationTo
		,TagName AS DeviationAssignedTag
		,AnonymizeUserDataSettingID As AnonymizeUserDataSetting
	FROM @temp t
	INNER JOIN #LinkedTagsByQuestionID lnk ON lnk.QuestionID = t.QuestionID
	ORDER BY 1 DESC;
END
GO