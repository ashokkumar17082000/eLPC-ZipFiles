/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchValueStreamsByTagID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING VALUESTREAMS BY TAG ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			Rajasekar S					PlantId,CurrentUserNTID added

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_FetchValueStreamsByTagID] 1,1,'OSP4KOR'
*/
CREATE PROCEDURE [USP_FetchValueStreamsByTagID] @PlantID INT
	,@TagID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	SET NOCOUNT ON;

	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = 0
		,@Mode = 'VALUESTREAM'
		,@CurrentUserNTID = @CurrentUserNTID

	SELECT VS.ValueStreamID
		,VS.Responsible_UserID
		,VS.ValueStreamTemplateID
		,VS.ValueStreamCategoryID
		,VS.ValueStreamData
		,VS.RowID
		,VS.NodeID
		,VS.ResponsibleEmployee
		,VS.ValueStreamName
		,VS.ParentId
	FROM T_TRN_ValueStream VS WITH (NOLOCK)
	INNER JOIN T_TRN_ValueStreamTemplate VST WITH (NOLOCK) ON VST.ValueStreamTemplateID = VS.ValueStreamTemplateID
	WHERE VS.ValueStreamID IN (
			SELECT ValueStreamID
			FROM T_LNK_Tag_AssignedValueStreams WITH(NOLOCK)
			WHERE TagID = @TagID
				AND (IsDeleted = 0)
			)
		AND (
			VS.IsDeleted = 0
			AND VST.PlantID = @PlantID
			)
	ORDER BY vs.ValueStreamName
END
GO

