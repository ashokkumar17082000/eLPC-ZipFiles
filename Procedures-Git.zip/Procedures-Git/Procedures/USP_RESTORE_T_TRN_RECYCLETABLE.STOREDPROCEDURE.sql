/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_Restore_T_TRN_RecycleTable]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RESTORING RECYCLE TABLE
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			VENKATESH GOVINDARAJ		PLANTID & CODE CLEANUP
ELPC_LH_002_CR05			06-Dec-2021			VENKATESH GOVINDARAJ		QUESTION ORDER BY LOGIC CHANGED
ELPC_LH_002_CR05			15-NOV-2023			Ashok /shubham 				Restore Recylebin/linkages 
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_Restore_T_TRN_RecycleTable] 
*/
CREATE PROCEDURE [USP_Restore_T_TRN_RecycleTable] @recycleTable [RecycleTable] READONLY
	, @PlantID INT
	, @CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	DECLARE @resultCode INT;
	DECLARE @resultMessage NVARCHAR(50);
	DECLARE @DatapoolID INT
	DECLARE @AuditID INT
	DECLARE @AuditTemplateID INT

	BEGIN TRANSACTION [Restore]

	BEGIN TRY
		UPDATE [T_TRN_ValueStreamTemplate]
		SET IsDeleted = 0
		WHERE ValueStreamTemplateID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Value Stream Template'
				)
			AND PlantID = @PlantID

		UPDATE [T_TRN_AssessorTemplate]
		SET IsDeleted = 0
		WHERE AssessorTemplateID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Assessor'
				)
			AND PlantID = @PlantID;

		UPDATE [T_TRN_Question]
		SET IsDeleted = 0
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)
			AND PlantID = @PlantID;

		UPDATE T_LNK_QN_AssignedTags
		SET IsDeleted = 0
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		UPDATE [T_LNK_AssignedAssessorsHistory]
		SET IsDeleted = 0
			, ActionType = 'U'
			, ActionDate = getdate()
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		UPDATE [T_LNK_AssignedAssessors]
		SET IsDeleted = 0
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		UPDATE [T_LNK_AssignedValueStreamsHistory]
		SET IsDeleted = 0
			, ActionType = 'U'
			, ActionDate = getdate()
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		UPDATE [T_TRN_HintImageHistory]
		SET IsDeleted = 0
			, ModifiedBy_NTID = @CurrentUserNTID
			, ActionType = 'U'
			, ActionDate = getdate()
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		UPDATE [T_TRN_HintImage]
		SET IsDeleted = 0
			, ModifiedBy_NTID = @CurrentUserNTID
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		UPDATE [T_TRN_HintHyperLinkHistory]
		SET IsDeleted = 0
			, ActionType = 'U'
			, ActionDate = getdate()
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		UPDATE [T_TRN_HintHyperLink]
		SET IsDeleted = 0
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		UPDATE [T_TRN_ChoiceHistory]
		SET IsDeleted = 0
			, ActionType = 'U'
			, ActionDate = getdate()
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		UPDATE [T_TRN_Choice]
		SET IsDeleted = 0
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		UPDATE [T_TRN_MultipleLinesTextHistory]
		SET IsDeleted = 0
			, ActionType = 'U'
			, ActionDate = getdate()
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		UPDATE [T_TRN_MultipleLinesText]
		SET IsDeleted = 0
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		UPDATE [T_TRN_SingleLineTextHistory]
		SET IsDeleted = 0
			, ActionType = 'U'
			, ActionDate = getdate()
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		UPDATE [T_TRN_SingleLineText]
		SET IsDeleted = 0
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		UPDATE [T_LNK_Question_Proxy]
		SET IsDeleted = 0
			, ModifiedBy_NTID = @CurrentUserNTID
			, ModifiedAt = getdate()
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		UPDATE [T_TRN_QuestionHistory]
		SET IsDeleted = 0
			, ModifiedBy_NTID = @CurrentUserNTID
			, ModifiedAt = getdate()
		WHERE QuestionID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Question'
				)

		UPDATE [T_TRN_Tag]
		SET IsDeleted = 0
		WHERE TagID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Tag'
				)
			AND PlantID = @PlantID;

		UPDATE [T_LNK_QN_AssignedTagsHistory]
		SET IsDeleted = 0
			, ActionType = 'U'
		--,ModifiedAt = @ModifiedAt
		WHERE TagID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Tag'
				)

		UPDATE [T_LNK_QN_AssignedTags]
		SET IsDeleted = 0
		WHERE TagID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Tag'
				)

		UPDATE [T_LNK_Tag_AssignedQuestionsTagsHistory]
		SET IsDeleted = 0
			, ActionType = 'U'
		WHERE TagID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Tag'
				);

		UPDATE [T_LNK_Tag_AssignedQuestionsTags]
		SET IsDeleted = 0
		WHERE TagID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Tag'
				);

		UPDATE [T_LNK_Tag_AssignedAssessorsHistory]
		SET IsDeleted = 0
			, ActionType = 'U'
		WHERE TagID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Tag'
				);

		UPDATE [T_LNK_Tag_AssignedAssessors]
		SET IsDeleted = 0
		WHERE TagID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Tag'
				)

		UPDATE [T_LNK_Tag_AssignedValueStreamsHistory]
		SET IsDeleted = 0
			, ActionType = 'U'
		WHERE TagID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Tag'
				)

		UPDATE [T_LNK_Tag_AssignedValueStreams]
		SET IsDeleted = 0
		WHERE TagID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Tag'
				)

		UPDATE [T_LNK_Tag_Proxy]
		SET IsDeleted = 0
			, ModifiedBy_NTID = @CurrentUserNTID
		WHERE TagID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Tag'
				)

		UPDATE [T_TRN_TagHistory]
		SET IsDeleted = 0
			, ModifiedBy_NTID = @CurrentUserNTID
		WHERE TagID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Tag'
				)

		UPDATE [T_TRN_DataPool]
		SET IsDeleted = 0
		WHERE DataPoolID IN (
				SELECT ID
				FROM @recycleTable
				WHERE ItemType = 'Data Pool'
				)
			AND PlantID = @PlantID;

		SET @DatapoolID = (
				SELECT TOP 1 ID
				FROM @recycleTable
				WHERE ItemType = 'Data Pool'
				)

		DECLARE @QuestionID INT = (
				SELECT QuestionID
				FROM [T_TRN_DataPool] WITH (NOLOCK)
				WHERE DatapoolID = @DatapoolID
				)

		IF @QuestionID IS NOT NULL
			AND @QuestionID > 0
		BEGIN
			EXEC [USP_UpdateDataPool_SummaryByQuestionID] @QuestionID
		END

		IF @DatapoolID IS NOT NULL
		BEGIN
			SET @AuditID = (
					SELECT AuditID
					FROM T_TRN_DataPool WITH (NOLOCK)
					WHERE DataPoolID = @DataPoolID
						AND PlantID = @PlantID
					)
			SET @AuditTemplateID = (
					SELECT AuditTemplateID
					FROM T_TRN_DataPool WITH (NOLOCK)
					WHERE DataPoolID = @DataPoolID
						AND PlantID = @PlantID
					)

			UPDATE [T_TRN_DataPool]
			SET IsDeleted = 0
			WHERE AuditID = @AuditID
				AND AuditTemplateID = @AuditTemplateID
				AND PlantID = @PlantID;
		END

		SET @resultCode = 0;
		SET @resultMessage = 'Success';

		COMMIT TRANSACTION [Restore]

		SELECT @resultCode AS resultCode
			, @resultMessage AS resultMessage
	END TRY

	BEGIN CATCH
		SET @resultCode = 1;
		SET @resultMessage = 'Fail';

		ROLLBACK TRANSACTION [Restore]

		EXEC USP_LogError @PlantID
			, @CurrentUserNTID;

		SELECT @resultCode AS resultCode
			, @resultMessage AS resultMessage
	END CATCH
END

GO
