/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_AddEditTagProxy]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE TO ADD AND EDIT TAG PROXY
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY				CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY INITIAL VERSION
ELPC_LH_002					23-MAR-2021			KARTHIKEYAN K			PLANTID ADDED
ELPC_LH_002					08-JUNE-2022	    SHUBHAM BARANGE			FOR PROXY MERGE
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
EXEC [USP_AddEditTagProxy] 
*/
CREATE PROCEDURE [USP_AddEditTagProxy] (
	@PlantID INT
	,@ID INT
	,@TagID INT
	,@Proxies XML NULL
	,@CurrentUserNTID NVARCHAR(20)
    ,@IsProxyMerge BIT = 0
	)
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION TRNADDEDITTAGPROXY

		SELECT @ID AS ID
			,@TagID AS TagID
			,@CurrentUserNTID AS ModifiedBy_NTID
			,@CurrentUserNTID AS CreatedBy_NTID
			,Proxie.value('(NTID/text())[1]', 'NVARCHAR(20)') AS Proxy
		INTO #T1
		FROM @Proxies.nodes('/ArrayOfUser/User') AS TEMPTABLE(Proxie)
		WHERE (
				@ID IS NOT NULL
				AND @ID != 0
				);

	    IF(@IsProxyMerge = 0)
		BEGIN
		UPDATE T_LNK_Tag_Proxy
		SET IsDeleted = 1
		WHERE ID NOT IN (
				SELECT ID
				FROM #T1
				)
			AND TagID = @TagID;
		END

		UPDATE T_TRN_Tag
		SET IsLocked = 1
		WHERE TagID = @TagID
			AND PlantID = @PlantID;

		INSERT INTO T_LNK_Tag_Proxy (
			TagID
			,ModifiedBy_NTID
			,CreatedBy_NTID
			,Proxy
			)
		SELECT @TagID AS TagID
			,@CurrentUserNTID AS ModifiedBy_NTID
			,@CurrentUserNTID AS CreatedBy_NTID
			,Proxie.value('(NTID/text())[1]', 'NVARCHAR(20)') AS Proxy
		FROM @Proxies.nodes('/ArrayOfUser/User') AS TEMPTABLE(Proxie);

		EXEC USP_AddEditUsers @PlantID
			,@CurrentUserNTID
			,@Proxies;

		COMMIT TRANSACTION TRNADDEDITTAGPROXY;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNADDEDITTAGPROXY;

		EXEC USP_LogError @PlantID
			,@CurrentUserNTID;
	END CATCH
END

GO

