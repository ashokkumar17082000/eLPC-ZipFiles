/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchAssessorTemplate]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING ASSESSOR TEMPLATE
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					12-MAR-2021			KARTHIKEYAN KANDASAMY		MODIFIED VERSION
ELPC_LH_002					25-MAY-2022			SHUBHAM BARANGE		        Added Is Accessible Column for Merge
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_FetchAssessorTemplate] @plantID=1
*/
CREATE PROCEDURE [USP_FetchAssessorTemplate] (@PlantID INT
	,@CurrentUserNTID NVARCHAR(20))
AS
BEGIN
	SET NOCOUNT ON;

	SELECT (
			SELECT TOP 1 UserName
			FROM T_MST_User WITH (NOLOCK)
			WHERE NTID = ModifiedBy_NTID
				AND PlantID = @PlantID
			) AS ModifiedBy
		,(
			SELECT TOP 1 UserName
			FROM T_MST_User WITH (NOLOCK)
			WHERE NTID = CreatedBy_NTID
				AND PlantID = @PlantID
			) AS CreatedBy
		,AssessorTemplateID
		,PlantID
		,AssessorTemplateDisplayID
		,AssessorTemplateName
		,IsTargetFrequencyDefined
		,IsLocked
		,IsDeleted
		,CreatedAt
		,CreatedBy_NTID
		,ModifiedAt
		,ModifiedBy_NTID
		,CASE 
			WHEN IsLocked = 1
				THEN IIF((
							SELECT COUNT(*)
							FROM T_LNK_Assessor_Proxy  WITH (NOLOCK)
							WHERE AssessorTemplateID = T_TRN_AssessorTemplate.AssessorTemplateID
								AND (
									Proxy = @CurrentUserNTID
									OR CreatedBy_NTID = CreatedBy_NTID
									OR ModifiedBy_NTID = CreatedBy_NTID
									)
								AND IsDeleted=0
							) > 0, 1, 0)
			ELSE 1
			END AS IsAccessible
	FROM T_TRN_AssessorTemplate WITH (NOLOCK)
	WHERE (
			PlantID = @PlantID
			AND IsDeleted = 0
			)
	ORDER BY ModifiedAt DESC;
END
GO

