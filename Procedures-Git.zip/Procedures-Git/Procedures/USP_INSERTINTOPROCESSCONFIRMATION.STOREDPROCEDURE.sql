 /*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_InsertIntoProcessConfirmation]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE TO INSERT IN TO PROCESS CONFIRMATION
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			VENKATESH GOVINDARAJ		PLANTID & CODE CLEANUP
ELPC_LH_002					27-MAR-2021			RAJASEKAR S					HISTORY LOGIC ADDED
ELPC_LH_002_CR05			06-DEC-2021			VENKATESH GOVINDARAJ		QUESTION ORDER BY LOGIC CHANGED
ELPC_LH_005                 15-MAR-2023        		 GOPIKA P G                  INCLUDED ADDITIONAL EMPLOYEE AND TAG FOR DEVIATION
ELPC_LH_006                 18-AUG-2023        ASHOK KUMAR R B                globaltag
ELPC_LH_007                7-DEC-2023        ASHOK KUMAR R B               4.2 Changes
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_InsertIntoProcessConfirmation] 
*/
CREATE PROCEDURE [USP_InsertIntoProcessConfirmation] @ModeTypeID INT
	,@ValueStreamID INT
	,@AssessorID INT
	,@QuestionID INT
	,@Answer NVARCHAR(MAX)
	,@AnswerType_AnswerTypeID INT
	,@CreatedAt DATETIME
	,@ModifiedAt DATETIME
	,@TagId INT
	,@AnsweredBy_NTID NVARCHAR(20)
	,@IsDeviation BIT
	,@ObtainedSCore DECIMAL(10, 2)
	,@DeviationDescription NVARCHAR(MAX)
	,@ResponsibleEmployee NVARCHAR(50)
	,@HintImages XML NULL
	,@ChoiceID INT
	,@IsSHowVsAs BIT
	,@SessionID NVARCHAR(20) NULL
	,@PlantID INT
	,@AdditionalEmployee XML NULL
	,@TagName XML NULL
	,@IsDeleted BIT NULL
	,@CurrentUserNTID NVARCHAR(20) NULL
	,@TagmodeID INT 
	,@CustomModeID INT
AS
BEGIN
	DECLARE @DeviationID INT;
	DECLARE @TimeStamp DATETIME;

	BEGIN TRY
	 --declare @date1 datetime = (select  getdate())
		insert into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('63_(1)',@PlantID,@CurrentUserNTID, getdate(),@ModeTypeID)
		--Inputs filed variable for triggers
		DECLARE @Input_Ids_Trigger VARCHAR(MAX);
		DECLARE @TableName_Trigger VARCHAR(100);
		DECLARE @ActionType VARCHAR(10);

		BEGIN TRANSACTION TRNINSERTPC

		SET @TimeStamp = (
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				);
		if @ModeTypeID is null
		SET @ModeTypeID = 1;

		SET @TimeStamp = (
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				);
		SET @CreatedAt = (
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				);
		SET @ModifiedAt = (
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				);
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;
	insert into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('94_(2)',@PlantID,@CurrentUserNTID, getdate(),@ModeTypeID)
		IF (
				@DeviationDescription <> NULL
				OR @DeviationDescription <> ''
				)
		BEGIN
			INSERT INTO [T_TRN_Deviation] (
				DeviationDescription
				,ValueStreamID
				,ResponsibleEmployee
				,QuestionID
				,CreatedBy_NTID
				,CreatedAt
				,ModifiedAt
				,PlantID
				,DeviationDisplayID
				)
			VALUES (
				@DeviationDescription
				,@ValueStreamID
				,@ResponsibleEmployee
				,@QuestionID
				,@AnsweredBy_NTID
				,@CreatedAt
				,@ModifiedAt
				,@PlantID
				,(
					SELECT DisplayID
					FROM [FN_GetNextDisplayID](@PlantID, 'T_TRN_Deviation')
					)
				)
		END

		SET @DeviationID = Scope_Identity();

	insert into tempinsertprocesstiming(linenum,plantid,ntid,currtime,modetype) values('128_(3)',@PlantID,@CurrentUserNTID, getdate(),@ModeTypeID)

		--***************insert TagAnsweredQuestions Table**********************
		IF @ModeTypeID =3
		BEGIN
		INSERT INTO T_LNK_Tag_AnsweredQuestions (
			TagID
			,QuestionID
			,CreatedAt
			,ModifiedAt
			,IsDeleted
			,AnswerTypeID
			,IsAnswered
			,Answer
			,CreatedBy_NTID
			,ModifiedBy_NTID
			,IsTagCompleted
			,IsTagActive
			,ValueStreamID
			,TagModeID
			,PlantID
			,DeviationDescription
			,ChoiceID
			--,DeviationID		
			)
		VALUES (
			@TagId
			,@QuestionID
			,@CreatedAt
			,@ModifiedAt
			,0
			,@AnswerType_AnswerTypeID
			,1
			,@Answer
			,@AnsweredBy_NTID
			,@AnsweredBy_NTID
			,0
			,1
			,@ValueStreamID
			,@TagmodeID
			,@PlantID	
			,@DeviationDescription
			,@ChoiceID
			--@DeviationID		
			)
		END

		--***************insert CustomAnsweredQuestions Table**********************
		
		 
		IF @ModeTypeID =2
		BEGIN
		INSERT INTO [T_LNK_Custom_AnsweredQuestions] (
			TagID
			,QuestionID
			,CreatedAt
			,ModifiedAt
			,IsDeleted
			,AnswerTypeID
			,IsAnswered
			,Answer
			,CreatedBy_NTID
			,ModifiedBy_NTID
			,IsCustomModeCompleted
			--,IsTagActive
			,ValueStreamID
			,CustomModeID
			,PlantID
			,ChoiceID
			,DeviationDescription
			
			--,DeviationID		
			)
		VALUES (
			@TagId
			,@QuestionID
			,@CreatedAt
			,@ModifiedAt
			,0
			,@AnswerType_AnswerTypeID
			,1
			,@Answer
			,@AnsweredBy_NTID
			,@AnsweredBy_NTID
			,0
			--,1
			,@ValueStreamID
			,@CustomModeID
			,@PlantID				
			,@ChoiceID
			,@DeviationDescription
			--@DeviationID		
			)
		END


	insert into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('224_(4)',@PlantID,@CurrentUserNTID, getdate(),@ModeTypeID)

		--***************insert additional employee**********************
		INSERT INTO T_LNK_Deviation_AdditionalEmployee (
			DeviationID
			,NTID
			,CreatedAt
			,ModifiedAt
			,IsDeleted
			,CreatedBy_NTID
			,UserName
			)
		SELECT @DeviationID AS DeviationID
			,Emp.value('(NTID/text())[1]', 'NVARCHAR(100)') AS NTID
			,(
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				) AS CreatedAt
			,(
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				) AS ModifiedAt
			,@IsDeleted AS FALSE
			,@AnsweredBy_NTID
			,Emp.value('(UserName/text())[1]', 'NVARCHAR(100)') AS UserName
		FROM @AdditionalEmployee.nodes('/ArrayOfUser/User') AS TEMPTABLE(Emp)


	insert into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('252_(5)',@PlantID,@CurrentUserNTID, getdate(),@ModeTypeID)

		--*****************insert tag int deviation****************************
		INSERT INTO T_LNK_Deviation_AssignedTags (
			DeviationID
			,TagID
			,IsDeleted
			,CreatedAt
			,ModifiedAt
			,CreatedBy_NTID
			,TagName
			)
		SELECT @DeviationID AS DeviationID
			,TagName.value('(TagID/text())[1]', 'int') AS TagID
			,@IsDeleted AS FALSE
			,(
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				) AS CreatedAt
			,(
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				) AS ModifiedAt
			,@AnsweredBy_NTID
			,TagName.value('(FormattedTag/text())[1]', 'nvarchar(100)') AS TagName
		FROM @TagName.nodes('/ArrayOfTag1/Tag1') AS TEMPTABLE(TagName)


		insert into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('280_(6)',@PlantID,@CurrentUserNTID, getdate(),@ModeTypeID)
		--*******************insert Deviation Images and files**************************
		INSERT INTO [T_TRN_DeviationAttachments] (
			QuestionID
			,ImagePath
			,ImageTitle
			,FileContent
			,DisplayFileName
			,CreatedBy_NTID
			,DeviationID
			)
		SELECT @QuestionID AS QuestionID
			,HintImage.value('(ImagePath/text())[1]', 'NVARCHAR(50)') AS ImagePath
			,HintImage.value('(ImageTitle/text())[1]', 'NVARCHAR(100)') AS ImageTitle
			,HintImage.value('(ByteData/text())[1]', 'varbinary(max)') AS FileContent
			,HintImage.value('(DisplayFileName/text())[1]', 'NVARCHAR(100)') AS DisplayFileName
			,@AnsweredBy_NTID AS CreatedBy_NTID
			,@DeviationID AS DeviationID
		FROM @HintImages.nodes('/ArrayOfHintImage/HintImage') AS TEMPTABLE(HintImage)

	insert into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('301_(7)',@PlantID,@CurrentUserNTID, getdate(),@ModeTypeID)

		--******************************iamge ends************************
		INSERT INTO [T_TRN_DataPool] (
			TIMESTAMP
			,ValueStreamID
			,AssessorID
			,QuestionID
			,Answer
			,AnswerType_AnswerTypeID
			,AnsweredBy_NTID
			,CreatedAt
			,ModifiedBy_NTID
			,ModifiedAt
			,TagId
			,IsDeviation
			,ObtainedSCore
			,ChoiceID
			,DeviationID
			,IsSHowVsAs
			,SessionID
			,PlantID
			)
		VALUES (
			@TimeStamp
			,@ValueStreamID
			,@AssessorID
			,@QuestionID
			,@Answer
			,@AnswerType_AnswerTypeID
			,@AnsweredBy_NTID
			,@CreatedAt
			,@AnsweredBy_NTID
			,@ModifiedAt
			,@TagId
			,@IsDeviation
			,@ObtainedSCore
			,@ChoiceID
			,@DeviationID
			,@IsSHowVsAs
			,@SessionID
			,@PlantID
			)


insert into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('345_(8)',@PlantID,@CurrentUserNTID, getdate(),@ModeTypeID)

		SELECT @TableName_Trigger = 'DATAPOOL'
			,@ActionType = 'I'
			,@Input_Ids_Trigger = Scope_Identity();
			
		EXEC [USP_DATAPOOL_HISTORY] @PlantID = @PlantID
			,@CurrentUserNTID = @CurrentUserNTID
			,@TableName = @TableName_Trigger
			,@ActionType = @ActionType
			,@INPUT_IDS = @Input_Ids_Trigger;
insert into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('356_(9)',@PlantID,@CurrentUserNTID, getdate(),@ModeTypeID)

		--EXEC [USP_UpdateDataPool_SummaryByQuestionID] @QuestionID
insert into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('359_(10)',@PlantID,@CurrentUserNTID, getdate(),@ModeTypeID)


		COMMIT TRANSACTION TRNINSERTPC;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNINSERTPC;

		EXEC [USP_LogError] @PlantID
			,@CurrentUserNTID;
	END CATCH

	SELECT @DeviationID AS DeviationID;
END
GO
SET QUOTED_IDENTIFIER ON
GO

