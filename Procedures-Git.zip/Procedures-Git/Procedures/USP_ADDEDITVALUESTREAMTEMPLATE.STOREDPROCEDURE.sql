/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_AddEditValueStreamTemplate]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE TO ADD AND EDIT VALUE STREAM TEMPLATE DETAILS 
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					10-MAR-2021			RAJASEKAR S					Trigger login included
ELPC_LH_002					18-MAR-2021			RAJASEKAR S					PlantId related changes
ELPC_LH_002					25-MAR-2021			RAJASEKAR S					CurrentUserNTID related changes
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_AddEditValueStreamTemplate]
*/
CREATE PROCEDURE [USP_AddEditValueStreamTemplate] @ValueStreamTemplateID INT
	,@ValueStreamTemplateName NVARCHAR(50)
	,@IsLocked BIT
	,@ModifiedAt DATETIME
	,@CreatedAt DATETIME
	,@Delimiter NVARCHAR(5)
	,@IsOperatedInShifts BIT
	,@VisualizationViewModeID INT
	,@ValueStreamCategories XML NULL
	,@ValueStreams XML NULL
	,@Shifts XML NULL
	,@PlantID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	BEGIN TRY
		EXEC [USP_PlantIDValidation] @PlantID = @PlantID
			,@ID = @ValueStreamTemplateID
			,@Mode = 'VALUESTREAMTEMPLATE'
			,@CurrentUserNTID = @CurrentUserNTID

		DECLARE @ValueStreamTemplateHistoryID INT = 0;

		BEGIN TRANSACTION TRNADDEDITVS

		--to avoid entries from Lock settings update, it is enabled/disabled   
		--ALTER TABLE [T_TRN_ValueStreamTemplate] ENABLE TRIGGER [TR_HISTORYFOR_T_TRN_ValueStreamTemplate]
		--ALTER TABLE [T_TRN_ValueStreamCategory] ENABLE TRIGGER [TR_HISTORYFOR_T_TRN_ValueStreamCategory]
		--ALTER TABLE [T_TRN_ValueStream] ENABLE TRIGGER [TR_HISTORYFOR_T_TRN_ValueStream]
		--ALTER TABLE [T_LNK_ValueStream_Shift] ENABLE TRIGGER [TR_HISTORYFOR_T_LNK_ValueStream_Shift]
		DECLARE @min INT = 0
			,@max INT = 0
			,@ValueStreamCategoryName NVARCHAR(50)
			,@IsDataRequired BIT
			,@TypeOfInput_InputTypeID INT
			,@IsDataRequiredToFitSpecLength BIT
			,@MinimumNoOfCharacters INT
			,@MaximumNoOfCharacters INT
			,@ValueStreamData NVARCHAR(50)
			,@NodeID INT = 0
			,@ShiftName NVARCHAR(50)
			,@RowID INT = 0
			,@FromTime DATETIME
			,@ToTime DATETIME
			,@IsMonday BIT
			,@IsTuesDay BIT
			,@IsWednesday BIT
			,@IsThursday BIT
			,@IsFriday BIT
			,@IsSaturday BIT
			,@IsSunday BIT
			,@DisplayName NVARCHAR(200)
			,@Responsible_UserID NVARCHAR(50)
			,@ResponsibleEmployee NVARCHAR(200)
			,@IsColumnRequired BIT
			,@ValueStreamName NVARCHAR(max)
			,@ValueStreamFullName NVARCHAR(max)
			,@InputType NVARCHAR(100)
		--Inputs filed variable for triggers
		DECLARE @Scope_Identity_Table_Trigger TABLE (id INT);--Scope identities for all inserted rows
		DECLARE @Input_Ids_Trigger VARCHAR(MAX);
		DECLARE @TableName_Trigger VARCHAR(100);
		DECLARE @ActionType VARCHAR(10);

		--*****************************************************************INITIAL INSERTION if ValueStreamTemplateID is NULL************************************************************************************************************  
		IF (
				(
					@ValueStreamTemplateID IS NULL
					OR @ValueStreamTemplateID = 0
					)
				AND NOT EXISTS (
					SELECT TOP 1 1
					FROM [T_TRN_ValueStreamTemplate] WITH(NOLOCK)
					WHERE ValueStreamTemplateID = @ValueStreamTemplateID
						AND PlantID = @PlantID
					)
				)
		BEGIN
			SET @ModifiedAt = (
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					);
			SET @CreatedAt = (
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					);

			INSERT INTO [T_TRN_ValueStreamTemplate] (
				PlantID
				,ValueStreamTemplateDisplayID
				,ValueStreamTemplateName
				,IsLocked
				,ModifiedAt
				,ModifiedBy_NTID
				,CreatedAt
				,CreatedBy_NTID
				,Delimiter
				,IsOperatedInShifts
				,VisualizationViewModeID
				)
			VALUES (
				@PlantID
				,(
					SELECT DisplayID
					FROM [FN_GetNextDisplayID](@plantID, 'T_TRN_ValueStreamTemplate')
					)
				,@ValueStreamTemplateName
				,@IsLocked
				,@ModifiedAt
				,@CurrentUserNTID
				,@CreatedAt
				,@CurrentUserNTID
				,@Delimiter
				,@IsOperatedInShifts
				,@VisualizationViewModeID
				)

			SET @ValueStreamTemplateID = SCOPE_IDENTITY()

			SELECT @TableName_Trigger = 'ValueStreamTemplate'
				,@ActionType = 'I'

			EXEC [USP_VALUESTREAM_HISTORY] @PlantID = @plantID
				,@CurrentUserNTID = @CurrentUserNTID
				,@TableName = @TableName_Trigger
				,@ValueStreamTemplateHistoryID = @ValueStreamTemplateHistoryID OUTPUT
				,@ActionType = @ActionType
				,@INPUT_IDS = @ValueStreamTemplateID

			DELETE
			FROM @Scope_Identity_Table_Trigger

			INSERT INTO T_TRN_ValueStreamCategory (
				ValueStreamTemplateID
				,ValueStreamCategoryName
				,IsDataRequired
				,TypeOfInput_InputTypeID
				,IsDataRequiredToFitSpecLength
				,MinimumNoOfCharacters
				,MaximumNoOfCharacters
				,NodeID
				,IsColumnRequired
				,InputType
				)
			OUTPUT inserted.ValueStreamCategoryID
			INTO @Scope_Identity_Table_Trigger
			SELECT @ValueStreamTemplateID AS ValueStreamTemplateID
				,Category.value('(ValueStreamCategoryName)[1]', 'NVARCHAR(50)') AS ValueStreamCategoryName
				,Category.value('(IsDataRequired/text())[1]', 'bit') AS IsDataRequired
				,Category.value('(TypeOfInput_InputTypeID/text())[1]', 'INT') AS TypeOfInput_InputTypeID
				,Category.value('(IsDataRequiredToFitSpecLength/text())[1]', 'bit') AS IsDataRequiredToFitSpecLength
				,Category.value('(MinimumNoOfCharacters/text())[1]', 'INT') AS MinimumNoOfCharacters
				,Category.value('(MaximumNoOfCharacters/text())[1]', 'INT') AS MaximumNoOfCharacters
				,Category.value('(NodeID)[1]', 'INT') AS NodeID
				,Category.value('(IsColumnRequired/text())[1]', 'bit') AS IsColumnRequired
				,Category.value('(InputType/text())[1]', 'NVARCHAR(100)') AS InputType
			FROM @ValueStreamCategories.nodes('/ArrayOfValueStreamCategory/ValueStreamCategory') AS TEMPTABLE(Category);

			SELECT @TableName_Trigger = 'ValueStreamCategory'
				,@ActionType = 'I'
				,@Input_Ids_Trigger = (
					SELECT CAST(id AS VARCHAR(MAX)) + ', '
					FROM @Scope_Identity_Table_Trigger
					FOR XML PATH('')
					);

			EXEC [USP_VALUESTREAM_HISTORY] @PlantID = @plantID
				,@CurrentUserNTID = @CurrentUserNTID
				,@TableName = @TableName_Trigger
				,@ValueStreamTemplateHistoryID = @ValueStreamTemplateHistoryID
				,@ActionType = @ActionType
				,@INPUT_IDS = @Input_Ids_Trigger;

			--for valuestream category  
			SELECT @ValueStreamTemplateID AS ValueStreamTemplateID
				,ValueStream.value('(ValueStreamCategoryName)[1]', 'NVARCHAR(50)') AS ValueStreamCategoryName
				,ValueStream.value('(ValueStreamData)[1]', 'NVARCHAR(50)') AS ValueStreamName
				,ValueStream.value('(NodeID)[1]', 'INT') AS NodeID
				,ValueStream.value('(Responsible_UserID/text())[1]', 'NVARCHAR(50)') AS Responsible_UserID
				,ValueStream.value('(ResponsibleEmployee/text())[1]', 'VARCHAR(200)') AS ResponsibleEmployee
				,ValueStream.value('(RowID)[1]', 'INT') AS RowID
				,ValueStream.value('(ValueStreamName)[1]', 'nvarchar(max)') AS ValueStreamFullName
				,ValueStream.value('(ParentId)[1]', 'nvarchar(500)') AS ParentId
				,NULL AS ValueStreamCategoryID
			INTO #T3
			FROM @ValueStreams.nodes('/ArrayOfValueStream/ValueStream') AS TEMPTABLE(ValueStream)

			UPDATE #T3
			SET ValueStreamCategoryID = (
					SELECT ValueStreamCategoryID
					FROM T_TRN_ValueStreamCategory t1 WITH(NOLOCK)
					WHERE #T3.ValueStreamCategoryName = t1.ValueStreamCategoryName
						AND t1.ValueStreamTemplateID = @ValueStreamTemplateID
					)

			DELETE
			FROM @Scope_Identity_Table_Trigger

			INSERT INTO T_TRN_ValueStream (
				ValueStreamCategoryID
				,ValueStreamTemplateID
				,ValueStreamData
				,NodeID
				,RowID
				,Responsible_UserID
				,ResponsibleEmployee
				,ValueStreamName
				,ParentId
				)
			OUTPUT inserted.ValueStreamID
			INTO @Scope_Identity_Table_Trigger
			SELECT ValueStreamCategoryID
				,ValueStreamTemplateID
				,ValueStreamName
				,NodeID
				,RowID
				,Responsible_UserID
				,ResponsibleEmployee
				,ValueStreamFullName
				,ParentId
			FROM #T3

			SELECT @TableName_Trigger = 'VALUESTREAM'
				,@ActionType = 'I'
				,@Input_Ids_Trigger = (
					SELECT CAST(id AS VARCHAR(MAX)) + ', '
					FROM @Scope_Identity_Table_Trigger
					FOR XML PATH('')
					);

			EXEC [USP_VALUESTREAM_HISTORY] @PlantID = @plantID
				,@CurrentUserNTID = @CurrentUserNTID
				,@TableName = @TableName_Trigger
				,@ValueStreamTemplateHistoryID = @ValueStreamTemplateHistoryID
				,@ActionType = @ActionType
				,@INPUT_IDS = @Input_Ids_Trigger;

			--for Shift  
			DELETE
			FROM @Scope_Identity_Table_Trigger

			INSERT INTO T_LNK_ValueStream_Shift (
				ValueStreamTemplateID
				,ShiftName
				,RowID
				,FromTime
				,ToTime
				,IsMonday
				,IsTuesDay
				,IsWednesday
				,IsThursday
				,IsFriday
				,IsSaturday
				,IsSunday
				,DisplayName
				)
			OUTPUT inserted.ShiftID
			INTO @Scope_Identity_Table_Trigger
			SELECT @ValueStreamTemplateID AS ValueStreamTemplateID
				,Shift.value('(ShiftName)[1]', 'NVARCHAR(50)') AS ShiftName
				,Shift.value('(RowID)[1]', 'INT') AS RowID
				,Shift.value('(FromTime)[1]', 'DATETIME') AS FromTime
				,Shift.value('(ToTime)[1]', 'DATETIME') AS ToTime
				,Shift.value('(IsMonday/text())[1]', 'bit') AS IsMonday
				,Shift.value('(IsTuesday/text())[1]', 'bit') AS IsTuesDay
				,Shift.value('(IsWednesday/text())[1]', 'bit') AS IsWednesday
				,Shift.value('(IsThursday/text())[1]', 'bit') AS IsThursday
				,Shift.value('(IsFriday/text())[1]', 'bit') AS IsFriday
				,Shift.value('(IsSaturday/text())[1]', 'bit') AS IsSaturday
				,Shift.value('(IsSunday/text())[1]', 'bit') AS IsSunday
				,Shift.value('(DisplayName)[1]', 'NVARCHAR(200)') AS DisplayName
			FROM @Shifts.nodes('/ArrayOfShift/Shift') AS TEMPTABLE(Shift)

			SELECT @TableName_Trigger = 'VALUESTREAM_SHIFT'
				,@ActionType = 'I'
				,@Input_Ids_Trigger = (
					SELECT CAST(id AS VARCHAR(MAX)) + ', '
					FROM @Scope_Identity_Table_Trigger
					FOR XML PATH('')
					);

			EXEC [USP_VALUESTREAM_HISTORY] @PlantID = @plantID
				,@CurrentUserNTID = @CurrentUserNTID
				,@TableName = @TableName_Trigger
				,@ValueStreamTemplateHistoryID = @ValueStreamTemplateHistoryID
				,@ActionType = @ActionType
				,@INPUT_IDS = @Input_Ids_Trigger;

			-------------------------------  
			IF (@VisualizationViewModeID = 2)
			BEGIN
				EXEC USP_UpdateResponsibleEmployee @PlantID
					,@ValueStreamTemplateID
					,@CurrentUserNTID
			END
		END
				--**********************************END of IF and Initial Insertion************************  
		ELSE IF (
				@ValueStreamTemplateID IS NOT NULL
				AND EXISTS (
					SELECT TOP 1 1
					FROM [T_TRN_ValueStreamTemplate] WITH(NOLOCK)
					WHERE ValueStreamTemplateID = @ValueStreamTemplateID
						AND PlantID = @PlantID
					)
				) ---if ValueStreamtemplateID is not null or zero...updating valuestreamtemplate  
		BEGIN
			SET @ModifiedAt = (
					SELECT FormattedDateTime
					FROM fnGetDateTime(@PlantID)
					);

			UPDATE [T_TRN_ValueStreamTemplate]
			SET ValueStreamTemplateName = @ValueStreamTemplateName
				,IsLocked = @IsLocked
				,ModifiedAt = @ModifiedAt
				,ModifiedBy_NTID = @CurrentUserNTID
				,CreatedAt = @CreatedAt
				--,CreatedBy_NTID = @CurrentUserNTID
				,Delimiter = @Delimiter
				,IsOperatedInShifts = @IsOperatedInShifts
				,VisualizationViewModeID = @VisualizationViewModeID
			WHERE ValueStreamTemplateID = @ValueStreamTemplateID
				AND PlantID = @PlantID

			SELECT @TableName_Trigger = 'ValueStreamTemplate'
				,@ActionType = 'U'

			EXEC [USP_VALUESTREAM_HISTORY] @PlantID = @plantID
				,@CurrentUserNTID = @CurrentUserNTID
				,@TableName = @TableName_Trigger
				,@ValueStreamTemplateHistoryID = @ValueStreamTemplateHistoryID OUTPUT
				,@ActionType = @ActionType
				,@INPUT_IDS = @ValueStreamTemplateID;

			--**************************************************UPDATE  VALUESTREAMCATEGORY**************************************************************************************************  
			SELECT @ValueStreamTemplateID AS ValueStreamTemplateID
				,--ATTRIBUTE  
				Category.value('(ValueStreamCategoryID)[1]', 'INT') AS ValueStreamCategoryID
				,Category.value('(ValueStreamCategoryName)[1]', 'NVARCHAR(50)') AS ValueStreamCategoryName
				,Category.value('(IsDataRequired/text())[1]', 'bit') AS IsDataRequired
				,Category.value('(TypeOfInput_InputTypeID/text())[1]', 'INT') AS TypeOfInput_InputTypeID
				,Category.value('(IsDataRequiredToFitSpecLength/text())[1]', 'bit') AS IsDataRequiredToFitSpecLength
				,Category.value('(MinimumNoOfCharacters/text())[1]', 'INT') AS MinimumNoOfCharacters
				,Category.value('(MaximumNoOfCharacters/text())[1]', 'INT') AS MaximumNoOfCharacters
				,Category.value('(NodeID)[1]', 'INT') AS NodeID
				,Category.value('(IsColumnRequired/text())[1]', 'bit') AS IsColumnRequired
				,Category.value('(InputType/text())[1]', 'nVARCHAR(100)') AS InputType
			INTO #T4
			FROM @ValueStreamCategories.nodes('/ArrayOfValueStreamCategory/ValueStreamCategory') AS TEMPTABLE(Category)

			--for Deleting the valuestream category  
			DELETE
			FROM @Scope_Identity_Table_Trigger

			INSERT INTO @Scope_Identity_Table_Trigger
			SELECT ValueStreamCategoryID
			FROM T_TRN_ValueStreamCategory WITH(NOLOCK)
			WHERE ValueStreamCategoryID NOT IN (
					SELECT ValueStreamCategoryID
					FROM #T4
					WHERE ValueStreamCategoryID != 0
						OR ValueStreamCategoryID IS NOT NULL
					)
				AND ValueStreamTemplateID = @ValueStreamTemplateID

			UPDATE T_TRN_ValueStreamCategory
			SET IsDeleted = 1
			WHERE ValueStreamCategoryID IN (
					SELECT id
					FROM @Scope_Identity_Table_Trigger
					) -- removes the deleted valuestream categories  

			SELECT @TableName_Trigger = 'ValueStreamCategory'
				,@ActionType = 'U'
				,@Input_Ids_Trigger = (
					SELECT CAST(id AS VARCHAR(MAX)) + ', '
					FROM @Scope_Identity_Table_Trigger
					FOR XML PATH('')
					);

			EXEC [USP_VALUESTREAM_HISTORY] @PlantID = @plantID
				,@CurrentUserNTID = @CurrentUserNTID
				,@TableName = @TableName_Trigger
				,@ValueStreamTemplateHistoryID = @ValueStreamTemplateHistoryID
				,@ActionType = @ActionType
				,@INPUT_IDS = @Input_Ids_Trigger;

			DELETE
			FROM @Scope_Identity_Table_Trigger

			INSERT INTO T_TRN_ValueStreamCategory (
				ValueStreamTemplateID
				,ValueStreamCategoryName
				,IsDataRequired
				,TypeOfInput_InputTypeID
				,IsDataRequiredToFitSpecLength
				,MinimumNoOfCharacters
				,MaximumNoOfCharacters
				,NodeID
				,IsColumnRequired
				,InputType
				)
			OUTPUT inserted.ValueStreamCategoryID
			INTO @Scope_Identity_Table_Trigger
			SELECT ValueStreamTemplateID
				,ValueStreamCategoryName
				,IsDataRequired
				,TypeOfInput_InputTypeID
				,IsDataRequiredToFitSpecLength
				,MinimumNoOfCharacters
				,MaximumNoOfCharacters
				,NodeID
				,IsColumnRequired
				,InputType
			FROM #T4
			WHERE ValueStreamCategoryID = NULL
				OR ValueStreamCategoryID = 0

			SELECT @TableName_Trigger = 'ValueStreamCategory'
				,@ActionType = 'I'
				,@Input_Ids_Trigger = (
					SELECT CAST(id AS VARCHAR(MAX)) + ', '
					FROM @Scope_Identity_Table_Trigger
					FOR XML PATH('')
					);

			EXEC [USP_VALUESTREAM_HISTORY] @PlantID = @plantID
				,@CurrentUserNTID = @CurrentUserNTID
				,@TableName = @TableName_Trigger
				,@ValueStreamTemplateHistoryID = @ValueStreamTemplateHistoryID
				,@ActionType = @ActionType
				,@INPUT_IDS = @Input_Ids_Trigger;

			SET @min = (
					SELECT MIN(ValueStreamCategoryID)
					FROM #T4
					);
			SET @max = (
					SELECT Max(ValueStreamCategoryID)
					FROM #T4
					);

			WHILE (@min <= @max)
			BEGIN
				SELECT @ValueStreamCategoryName = ValueStreamCategoryName
					,@IsDataRequired = IsDataRequired
					,@TypeOfInput_InputTypeID = TypeOfInput_InputTypeID
					,@IsDataRequiredToFitSpecLength = IsDataRequiredToFitSpecLength
					,@MinimumNoOfCharacters = MinimumNoOfCharacters
					,@MaximumNoOfCharacters = MaximumNoOfCharacters
					,@NodeID = NodeID
					,@IsColumnRequired = IsColumnRequired
					,@InputType = InputType
				FROM #T4
				WHERE ValueStreamCategoryID = @min

				DELETE
				FROM @Scope_Identity_Table_Trigger

				INSERT INTO @Scope_Identity_Table_Trigger
				SELECT ValueStreamCategoryID
				FROM T_TRN_ValueStreamCategory WITH(NOLOCK)
				WHERE ValueStreamCategoryID = @min
					AND ValueStreamTemplateID = @ValueStreamTemplateID

				UPDATE T_TRN_ValueStreamCategory
				SET ValueStreamCategoryName = @ValueStreamCategoryName
					,IsDataRequired = @IsDataRequired
					,TypeOfInput_InputTypeID = @TypeOfInput_InputTypeID
					,IsDataRequiredToFitSpecLength = @IsDataRequiredToFitSpecLength
					,MinimumNoOfCharacters = @MinimumNoOfCharacters
					,MaximumNoOfCharacters = @MaximumNoOfCharacters
					,@NodeID = NodeID
					,IsColumnRequired = @IsColumnRequired
					,InputType = @InputType
				WHERE ValueStreamCategoryID IN (
						SELECT id
						FROM @Scope_Identity_Table_Trigger
						)

				SET @min = @min + 1

				SELECT @TableName_Trigger = 'ValueStreamCategory'
					,@ActionType = 'U'
					,@Input_Ids_Trigger = (
						SELECT CAST(id AS VARCHAR(MAX)) + ', '
						FROM @Scope_Identity_Table_Trigger
						FOR XML PATH('')
						);

				EXEC [USP_VALUESTREAM_HISTORY] @PlantID = @plantID
					,@CurrentUserNTID = @CurrentUserNTID
					,@TableName = @TableName_Trigger
					,@ValueStreamTemplateHistoryID = @ValueStreamTemplateHistoryID
					,@ActionType = @ActionType
					,@INPUT_IDS = @Input_Ids_Trigger;
			END

			--******************************************************UPDATE  VALUESTREAMCATEGORY END****************************************************************************************************  
			--**************************************************UPDATE  Shift**************************************************************************************************  
			SELECT @ValueStreamTemplateID AS ValueStreamTemplateID
				,--ATTRIBUTE  
				Shift.value('(ShiftName)[1]', 'NVARCHAR(50)') AS ShiftName
				,Shift.value('(RowID)[1]', 'INT') AS RowID
				,Shift.value('(ShiftID)[1]', 'INT') AS ShiftID
				,Shift.value('(FromTime)[1]', 'DATETIME') AS FromTime
				,Shift.value('(ToTime)[1]', 'DATETIME') AS ToTime
				,Shift.value('(IsMonday/text())[1]', 'bit') AS IsMonday
				,Shift.value('(IsTuesday/text())[1]', 'bit') AS IsTuesDay
				,Shift.value('(IsWednesday/text())[1]', 'bit') AS IsWednesday
				,Shift.value('(IsThursday/text())[1]', 'bit') AS IsThursday
				,Shift.value('(IsFriday/text())[1]', 'bit') AS IsFriday
				,Shift.value('(IsSaturday/text())[1]', 'bit') AS IsSaturday
				,Shift.value('(IsSunday/text())[1]', 'bit') AS IsSunday
				,Shift.value('(DisplayName)[1]', 'NVARCHAR(200)') AS DisplayName
			INTO #S1
			FROM @Shifts.nodes('/ArrayOfShift/Shift') AS TEMPTABLE(Shift)

			--for Deleting the Shifts category
			DELETE
			FROM @Scope_Identity_Table_Trigger

			INSERT INTO @Scope_Identity_Table_Trigger
			SELECT ShiftID
			FROM T_LNK_ValueStream_Shift WITH(NOLOCK)
			WHERE ShiftID NOT IN (
					SELECT ShiftID
					FROM #S1
					WHERE ShiftID != 0
						OR ShiftID IS NOT NULL
					)
				AND ValueStreamTemplateID = @ValueStreamTemplateID

			UPDATE T_LNK_ValueStream_Shift
			SET IsDeleted = 1
			WHERE ShiftID IN (
					SELECT id
					FROM @Scope_Identity_Table_Trigger
					)

			SELECT @TableName_Trigger = 'VALUESTREAM_SHIFT'
				,@ActionType = 'U'
				,@Input_Ids_Trigger = (
					SELECT CAST(id AS VARCHAR(MAX)) + ', '
					FROM @Scope_Identity_Table_Trigger
					FOR XML PATH('')
					);

			EXEC [USP_VALUESTREAM_HISTORY] @PlantID = @plantID
				,@CurrentUserNTID = @CurrentUserNTID
				,@TableName = @TableName_Trigger
				,@ValueStreamTemplateHistoryID = @ValueStreamTemplateHistoryID
				,@ActionType = @ActionType
				,@INPUT_IDS = @Input_Ids_Trigger;

			DELETE
			FROM @Scope_Identity_Table_Trigger

			INSERT INTO T_LNK_ValueStream_Shift (
				ValueStreamTemplateID
				,ShiftName
				,RowID
				,FromTime
				,ToTime
				,IsMonday
				,IsTuesDay
				,IsWednesday
				,IsThursday
				,IsFriday
				,IsSaturday
				,IsSunday
				,DisplayName
				)
			OUTPUT inserted.ShiftID
			INTO @Scope_Identity_Table_Trigger
			SELECT ValueStreamTemplateID
				,ShiftName
				,RowID
				,FromTime
				,ToTime
				,IsMonday
				,IsTuesDay
				,IsWednesday
				,IsThursday
				,IsFriday
				,IsSaturday
				,IsSunday
				,DisplayName
			FROM #S1
			WHERE ShiftID = NULL
				OR ShiftID = 0

			SELECT @TableName_Trigger = 'VALUESTREAM_SHIFT'
				,@ActionType = 'I'
				,@Input_Ids_Trigger = (
					SELECT CAST(id AS VARCHAR(MAX)) + ', '
					FROM @Scope_Identity_Table_Trigger
					FOR XML PATH('')
					);

			EXEC [USP_VALUESTREAM_HISTORY] @PlantID = @plantID
				,@CurrentUserNTID = @CurrentUserNTID
				,@TableName = @TableName_Trigger
				,@ValueStreamTemplateHistoryID = @ValueStreamTemplateHistoryID
				,@ActionType = @ActionType
				,@INPUT_IDS = @Input_Ids_Trigger;

			SET @min = (
					SELECT MIN(ShiftID)
					FROM #S1
					WHERE ValueStreamTemplateID = @ValueStreamTemplateID
					);
			SET @max = (
					SELECT Max(ShiftID)
					FROM #S1
					WHERE ValueStreamTemplateID = @ValueStreamTemplateID
					);

			WHILE (@min <= @max)
			BEGIN
				SELECT @ValueStreamTemplateID = ValueStreamTemplateID
					,@ShiftName = ShiftName
					,@RowID = RowID
					,@FromTime = FromTime
					,@ToTime = ToTime
					,@IsMonday = IsMonday
					,@IsTuesDay = IsTuesDay
					,@IsWednesday = IsWednesday
					,@IsThursday = IsThursday
					,@IsFriday = IsFriday
					,@IsSaturday = IsSaturday
					,@IsSunday = IsSunday
					,@DisplayName = DisplayName
				FROM #S1
				WHERE ShiftID = @min

				DELETE
				FROM @Scope_Identity_Table_Trigger

				INSERT INTO @Scope_Identity_Table_Trigger
				SELECT ShiftID
				FROM T_LNK_ValueStream_Shift WITH(NOLOCK)
				WHERE ShiftID = @min
					AND ValueStreamTemplateID = @ValueStreamTemplateID

				UPDATE T_LNK_ValueStream_Shift
				SET ValueStreamTemplateID = @ValueStreamTemplateID
					,ShiftName = @ShiftName
					,RowID = @RowID
					,FromTime = @FromTime
					,ToTime = @ToTime
					,IsMonday = @IsMonday
					,IsTuesDay = @IsTuesDay
					,IsWednesday = @IsWednesday
					,IsThursday = @IsThursday
					,IsFriday = @IsFriday
					,IsSaturday = @IsSaturday
					,IsSunday = @IsSunday
					,DisplayName = @DisplayName
				WHERE ShiftID IN (
						SELECT id
						FROM @Scope_Identity_Table_Trigger
						)

				SELECT @TableName_Trigger = 'VALUESTREAM_SHIFT'
					,@ActionType = 'U'
					,@Input_Ids_Trigger = (
						SELECT CAST(id AS VARCHAR(MAX)) + ', '
						FROM @Scope_Identity_Table_Trigger
						FOR XML PATH('')
						);

				EXEC [USP_VALUESTREAM_HISTORY] @PlantID = @plantID
					,@CurrentUserNTID = @CurrentUserNTID
					,@TableName = @TableName_Trigger
					,@ValueStreamTemplateHistoryID = @ValueStreamTemplateHistoryID
					,@ActionType = @ActionType
					,@INPUT_IDS = @Input_Ids_Trigger;

				SET @min = @min + 1
			END

			--******************************************************UPDATE  Shift END****************************************************************************************************  
			--******************************************************UPDATE VALUESTREAM*****************************************************************************************************************  
			SELECT @ValueStreamTemplateID AS ValueStreamTemplateID
				,--ATTRIBUTE  
				ValueStream.value('(ValueStreamCategoryID)[1]', 'INT') AS ValueStreamCategoryID
				,ValueStream.value('(ValueStreamID)[1]', 'INT') AS ValueStreamID
				,ValueStream.value('(ValueStreamCategoryName)[1]', 'NVARCHAR(50)') AS ValueStreamCategoryName
				,ValueStream.value('(ValueStreamData)[1]', 'NVARCHAR(50)') AS ValueStreamName
				,ValueStream.value('(Responsible_UserID/text())[1]', 'NVARCHAR(50)') AS Responsible_UserID
				,ValueStream.value('(ResponsibleEmployee/text())[1]', 'VARCHAR(200)') AS ResponsibleEmployee
				,ValueStream.value('(NodeID)[1]', 'INT') AS NodeID
				,ValueStream.value('(RowID)[1]', 'INT') AS RowID
				,ValueStream.value('(ValueStreamName)[1]', 'nvarchar(max)') AS ValueStreamFullName
				,ValueStream.value('(ParentId)[1]', 'nvarchar(max)') AS ParentId
			INTO #T5
			FROM @ValueStreams.nodes('/ArrayOfValueStream/ValueStream') AS TEMPTABLE(ValueStream)

			UPDATE #T5
			SET ValueStreamCategoryID = (
					SELECT TOP 1 ValueStreamCategoryID
					FROM T_TRN_ValueStreamCategory t1 WITH(NOLOCK)
					WHERE #T5.ValueStreamCategoryName = t1.ValueStreamCategoryName
						AND t1.ValueStreamTemplateID = @ValueStreamTemplateID
					)

			--for Deleting the valuestream   
			DELETE
			FROM @Scope_Identity_Table_Trigger

			INSERT INTO @Scope_Identity_Table_Trigger
			SELECT ValueStreamID
			FROM T_TRN_ValueStream WITH(NOLOCK)
			WHERE ValueStreamID NOT IN (
					SELECT ValueStreamID
					FROM #T5
					WHERE ValueStreamID != 0
						OR ValueStreamID IS NOT NULL
					)
				AND ValueStreamTemplateID = @ValueStreamTemplateID

			UPDATE T_TRN_ValueStream
			SET IsDeleted = 1
			WHERE ValueStreamID IN (
					SELECT id
					FROM @Scope_Identity_Table_Trigger
					) -- removes the deleted valuestreams  

			SELECT @TableName_Trigger = 'VALUESTREAM'
				,@ActionType = 'U'
				,@Input_Ids_Trigger = (
					SELECT CAST(id AS VARCHAR(MAX)) + ', '
					FROM @Scope_Identity_Table_Trigger
					FOR XML PATH('')
					);

			EXEC [USP_VALUESTREAM_HISTORY] @PlantID = @plantID
				,@CurrentUserNTID = @CurrentUserNTID
				,@TableName = @TableName_Trigger
				,@ValueStreamTemplateHistoryID = @ValueStreamTemplateHistoryID
				,@ActionType = @ActionType
				,@INPUT_IDS = @Input_Ids_Trigger;

			DELETE
			FROM @Scope_Identity_Table_Trigger

			INSERT INTO T_TRN_ValueStream (
				ValueStreamCategoryID
				,ValueStreamTemplateID
				,ValueStreamData
				,NodeID
				,RowID
				,Responsible_UserID
				,ResponsibleEmployee
				,ValueStreamName
				,ParentId
				)
			OUTPUT inserted.ValueStreamID
			INTO @Scope_Identity_Table_Trigger
			SELECT ValueStreamCategoryID
				,ValueStreamTemplateID
				,ValueStreamName
				,NodeID
				,RowID
				,Responsible_UserID
				,ResponsibleEmployee
				,ValueStreamFullName
				,ParentId
			FROM #T5
			WHERE ValueStreamID = NULL
				OR ValueStreamID = 0

			SELECT @TableName_Trigger = 'VALUESTREAM'
				,@ActionType = 'I'
				,@Input_Ids_Trigger = (
					SELECT CAST(id AS VARCHAR(MAX)) + ', '
					FROM @Scope_Identity_Table_Trigger
					FOR XML PATH('')
					);

			EXEC [USP_VALUESTREAM_HISTORY] @PlantID = @plantID
				,@CurrentUserNTID = @CurrentUserNTID
				,@TableName = @TableName_Trigger
				,@ValueStreamTemplateHistoryID = @ValueStreamTemplateHistoryID
				,@ActionType = @ActionType
				,@INPUT_IDS = @Input_Ids_Trigger;

			SET @min = (
					SELECT MIN(ValueStreamID)
					FROM #T5
					WHERE ValueStreamTemplateID = @ValueStreamTemplateID
					);--Get minimum row number from temp table  
			SET @max = (
					SELECT Max(ValueStreamID)
					FROM #T5
					WHERE ValueStreamTemplateID = @ValueStreamTemplateID
					);--Get maximum row number from temp table  

			WHILE (@min <= @max)
			BEGIN
				SELECT @ValueStreamData = ValueStreamName
					,@Responsible_UserID = Responsible_UserID
					,@ResponsibleEmployee = ResponsibleEmployee
					,@ValueStreamFullName = ValueStreamFullName
					,@RowID = RowID
				FROM #T5
				WHERE ValueStreamID = @min

				DELETE
				FROM @Scope_Identity_Table_Trigger

				INSERT INTO @Scope_Identity_Table_Trigger
				SELECT ValueStreamID
				FROM T_TRN_ValueStream WITH(NOLOCK)
				WHERE ValueStreamID = @min
					AND ValueStreamTemplateID = @ValueStreamTemplateID

				UPDATE T_TRN_ValueStream
				SET ValueStreamData = @ValueStreamData
					,Responsible_UserID = @Responsible_UserID
					,ResponsibleEmployee = @ResponsibleEmployee
					,RowID = @RowID
					,ValueStreamName = @ValueStreamFullName
				WHERE ValueStreamID IN (
						SELECT id
						FROM @Scope_Identity_Table_Trigger
						)
						and IsDeleted = 0
				SELECT @TableName_Trigger = 'VALUESTREAM'
					,@ActionType = 'U'
					,@Input_Ids_Trigger = (
						SELECT CAST(id AS VARCHAR(MAX)) + ', '
						FROM @Scope_Identity_Table_Trigger
						FOR XML PATH('')
						);

				EXEC [USP_VALUESTREAM_HISTORY] @PlantID = @plantID
					,@CurrentUserNTID = @CurrentUserNTID
					,@TableName = @TableName_Trigger
					,@ValueStreamTemplateHistoryID = @ValueStreamTemplateHistoryID
					,@ActionType = @ActionType
					,@INPUT_IDS = @Input_Ids_Trigger;

				SET @min = @min + 1 --Increment of current row number  
			END

			--********************************************************UPDATE VALUESTREAM END*****************************************************************************************************************  
			IF (@VisualizationViewModeID = 2)
			BEGIN
				EXEC USP_UpdateResponsibleEmployee @PlantID
					,@ValueStreamTemplateID
					,@CurrentUserNTID
			END
					-----------------------------  
		END

		--ALTER TABLE [T_TRN_ValueStreamTemplate] DISABLE TRIGGER [TR_HISTORYFOR_T_TRN_ValueStreamTemplate]
		--ALTER TABLE [T_TRN_ValueStreamCategory] DISABLE TRIGGER [TR_HISTORYFOR_T_TRN_ValueStreamCategory]
		--ALTER TABLE [T_TRN_ValueStream] DISABLE TRIGGER [TR_HISTORYFOR_T_TRN_ValueStream]
		--ALTER TABLE [T_LNK_ValueStream_Shift] DISABLE TRIGGER [TR_HISTORYFOR_T_LNK_ValueStream_Shift]
		SELECT ValueStreamTemplateID
			,PlantID
			,ValueStreamTemplateDisplayID
			,ValueStreamTemplateName
			,IsLocked
			,Delimiter
			,IsOperatedInShifts
			,VisualizationViewModeID
			,CreatedAt
			,CreatedBy_NTID
			,ModifiedAt
			,ModifiedBy_NTID
		FROM [T_TRN_ValueStreamTemplate] WITH(NOLOCK)
		WHERE ValueStreamTemplateID = @ValueStreamTemplateID
			AND PlantID = @plantID;

		COMMIT TRANSACTION TRNADDEDITVS
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNADDEDITVS

		EXEC USP_LogError @PlantID
			,@CurrentUserNTID
	END CATCH
END
GO

