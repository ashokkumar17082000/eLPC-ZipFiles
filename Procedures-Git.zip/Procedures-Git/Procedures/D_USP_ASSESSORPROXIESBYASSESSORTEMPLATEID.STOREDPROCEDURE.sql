SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [USP_AssessorProxiesByAssessorTemplateID] @AssessorTemplateID INT
AS
BEGIN
	SELECT DISTINCT (UR.UserName)
		,AP.AssessorTemplateID
		,AP.Proxy
	FROM T_LNK_Assessor_Proxy AP
	INNER JOIN T_MST_User UR ON AP.Proxy = UR.NTID
	WHERE AssessorTemplateID = @AssessorTemplateID
END
GO


