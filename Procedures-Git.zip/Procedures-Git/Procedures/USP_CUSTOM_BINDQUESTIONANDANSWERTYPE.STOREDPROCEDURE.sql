/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_Custom_BindQuestionAndAnswerType] 
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE TO CUSTOM BIND QUESTION AND ANSWER TYPE
///MODIFICATION HISTORY         :  
************************************************************************************************************ 
///REF                      DATE                MODIFIED BY                 CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001                 25-NOV-2020         JANARTHANAN KRISHNASAMY     INITIAL VERSION
ELPC_LH_002                 27-MAR-2021         VENKATESH GOVINDARAJ        PLANTID & CODE CLEANUP
ELPC_LH_002                 27-MAR-2021         ASHOK KUMAR R B             QuestionLoad Based on RandomOrder
ELPC_LH_006                 18-AUG-2023         ASHOK KUMAR R B             Globaltag Changes Resume 
************************************************************************************************************ 

--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
exec [USP_Custom_BindQuestionAndAnswerType] @ValueStreamID=0,@AssessorID=0,@NTID=N'FSM1COB',@PlantID=1,@CurrentUserNTID=N'FSM1COB',@AnsweredAndSkippedQueestionIDs='',@SessionID ='',@ResumeTag=1
*/
CREATE PROCEDURE [USP_Custom_BindQuestionAndAnswerType] @ValueStreamID INT
	,@AssessorID INT
	,@NTID NVARCHAR(20)
	,@PlantID INT
	,@CurrentUserNTID NVARCHAR(20) NULL
	,@SelectedQuestionID INT = 0
	,@AnsweredAndSkippedQueestionIDs XML NULL
	,@SessionID NVARCHAR(MAX) NULL
	,@ResumeTag BIT 
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @RowExists BIT = 0;
	DECLARE @ValidRows BIT = 0;
 --insert into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('46_(1_customBind)',@PlantID,@CurrentUserNTID, getdate(),2)

	IF EXISTS (
			SELECT TOP 1 1
			FROM [T_TRN_ValueStreamConfig] vsc WITH (NOLOCK)
			CROSS JOIN [T_TRN_AssessorConfig] ac WITH (NOLOCK)
			WHERE vsc.IsDeleted = 0
				AND ac.IsDeleted = 0
				AND vsc.PlantID = @PlantID
				AND ac.PlantID = @PlantID
				AND vsc.User_NTID = @CurrentUserNTID
				AND ac.User_NTID = @CurrentUserNTID
				AND vsc.ValueStreamID IN (
					SELECT c.ValueStreamID
					FROM [T_TRN_ValueStreamConfig] c
					INNER JOIN T_TRN_ValueStreamTemplate vst WITH (NOLOCK) ON vst.ValueStreamTemplateID = c.ValueStreamTemplateID
					INNER JOIN T_TRN_ValueStream vs WITH (NOLOCK) ON vs.ValueStreamID = c.ValueStreamID
					INNER JOIN T_TRN_ValueStreamCategory cat WITH (NOLOCK) ON c.ValueStreamTemplateID = cat.ValueStreamTemplateID
					WHERE c.PlantID = @PlantID
						AND c.User_NTID = @CurrentUserNTID
						AND c.IsDeleted = 0
						AND vst.IsDeleted = 0
						AND vs.IsDeleted = 0
						AND cat.IsDeleted = 0
					)
				AND ac.AssessorID IN (
					SELECT DISTINCT c.AssessorID
					FROM T_TRN_AssessorConfig c WITH (NOLOCK)
					INNER JOIN T_TRN_AssessorTemplate ast WITH (NOLOCK) ON ast.AssessorTemplateID = c.AssessorTemplateID
					INNER JOIN T_TRN_Assessor a WITH (NOLOCK) ON a.AssessorID = c.AssessorID
					WHERE c.PlantID = @PlantID
						AND c.User_NTID = @CurrentUserNTID
						AND c.IsDeleted = 0
						AND ast.IsDeleted = 0
						AND a.IsDeleted = 0
					)
			)
	BEGIN
		SET @RowExists = 1
	END

	IF NOT EXISTS (
			SELECT TOP 1 1
			FROM [T_TRN_ValueStreamConfig] vsc WITH (NOLOCK)
			CROSS JOIN [T_TRN_AssessorConfig] ac WITH (NOLOCK)
			WHERE vsc.IsDeleted = 0
				AND ac.IsDeleted = 0
				AND vsc.PlantID = @PlantID
				AND ac.PlantID = @PlantID
				AND vsc.User_NTID = @CurrentUserNTID
				AND ac.User_NTID = @CurrentUserNTID
				AND vsc.ValueStreamID IN (
					SELECT c.ValueStreamID
					FROM [T_TRN_ValueStreamConfig] c
					INNER JOIN T_TRN_ValueStreamTemplate vst WITH (NOLOCK) ON vst.ValueStreamTemplateID = c.ValueStreamTemplateID
					INNER JOIN T_TRN_ValueStream vs WITH (NOLOCK) ON vs.ValueStreamID = c.ValueStreamID
					INNER JOIN T_TRN_ValueStreamCategory cat WITH (NOLOCK) ON c.ValueStreamTemplateID = cat.ValueStreamTemplateID
					WHERE c.PlantID = @PlantID
						AND c.User_NTID = @CurrentUserNTID
						AND c.IsDeleted = 0
						AND vst.IsDeleted = 0
						AND vs.IsDeleted = 0
						AND cat.IsDeleted = 0
					)
				AND ac.AssessorID IN (
					SELECT DISTINCT c.AssessorID
					FROM T_TRN_AssessorConfig c WITH (NOLOCK)
					INNER JOIN T_TRN_AssessorTemplate ast WITH (NOLOCK) ON ast.AssessorTemplateID = c.AssessorTemplateID
					INNER JOIN T_TRN_Assessor a WITH (NOLOCK) ON a.AssessorID = c.AssessorID
					WHERE c.PlantID = @PlantID
						AND c.User_NTID = @CurrentUserNTID
						AND c.IsDeleted = 0
						AND ast.IsDeleted = 0
						AND a.IsDeleted = 0
					)
				AND (
					(
						vsc.IsForgotValueStream = 1
						AND vsc.SessionID IS NOT NULL
						AND vsc.SessionID <> @SessionID
						)
					OR (
						ac.IsForgotAssessor = 1
						AND ac.SessionID IS NOT NULL
						AND ac.SessionID <> @SessionID
						)
					)
			)
	BEGIN
		SET @ValidRows = 1
	END

--insert into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('138_(2_customBind)',@PlantID,@CurrentUserNTID, getdate(),2)

	IF (
			@RowExists = 1
			AND @ValidRows = 1
			)
	BEGIN
		BEGIN TRY
			BEGIN TRANSACTION CUSTOM_BINDQUESTIONANDANSWERTYPE

			-- Starts ****** Identifying the custome mode questions *****************
			DECLARE @CustomModeID INT;
			DECLARE @myCustomTableVariable TABLE (QuestionID INT)

			SET @CustomModeID = (
					SELECT CustomModeID
					FROM [T_TRN_CustomMode] WITH (NOLOCK)
					WHERE CreatedBy_NTID = @NTID
						AND PlantID = @PlantID
					);

			INSERT INTO @myCustomTableVariable (QuestionID)
			SELECT QuestionID
			FROM (
				SELECT QuestionID
				FROM [T_LNK_Custom_Questions] WITH (NOLOCK)
				WHERE CustomModeID = @CustomModeID
					AND IsCustomMode = 1
					AND IsDeleted = 0
				) AS tmpCusttbl

			-- Ends ****** Identifying the custome mode questions *****************
			-- Starts ****** Combing & forming VS & AS for filtering Questions belongs to available combination *****************
			SELECT *
			INTO #VSASCombination
			FROM (
				SELECT vsc.User_NTID
					,vsc.ValueStreamTemplateID
					,vsc.ValueStreamID
					,ac.AssessorTemplateID
					,ac.AssessorID
					,vsc.IsForgotValueStream
					,ac.IsForgotAssessor
					,vsc.SessionID AS VSSessionID
					,ac.SessionID AS ASSessionID
				FROM [T_TRN_ValueStreamConfig] vsc WITH (NOLOCK)
				CROSS JOIN [T_TRN_AssessorConfig] ac WITH (NOLOCK)
				WHERE vsc.IsDeleted = 0
					AND ac.IsDeleted = 0
					AND vsc.PlantID = @PlantID
					AND ac.PlantID = @PlantID
					AND vsc.User_NTID = @CurrentUserNTID
					AND ac.User_NTID = @CurrentUserNTID
				) AS VSASCombination

			-- Ends ****** Combing & forming VS & AS for filtering Questions belongs to available combination *****************
			SELECT *
			INTO #AnsweredAndSkippedQueestionIDs
			FROM (
				SELECT AnsweredAndSkippedQueestionIDs.value('.', 'int') AS QuestionID
				FROM @AnsweredAndSkippedQueestionIDs.nodes('/ArrayOfInt/int') AS TEMPTABLE(AnsweredAndSkippedQueestionIDs)
				) AS AnsweredAndSkippedQueestionIDs
--insert into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('200_(3_customBind)',@PlantID,@CurrentUserNTID, getdate(),2)

			-- Starts ****** Preparing Questionlist by applying VS & AS available combination *****************
			SELECT *
			INTO #CombinationQuestionList
			FROM (
				SELECT DISTINCT LVS.QuestionID
					,VS.ValueStreamTemplateID
					,LVS.ValueStreamID
					,A.AssessorTemplateID
					,LAS.AssessorID
					,VSAS.IsForgotValueStream
					,VSAS.IsForgotAssessor
					,VSAS.VSSessionID
					,VSAS.ASSessionID
						,
					--(
					--	SELECT IIF(MAX(DataPoolID) IS NULL, NULL, 1) AS DataPoolID
					--	FROM [t_trn_datapool] WITH (NOLOCK)
					--	WHERE answeredby_ntid = @NTID
					--		AND (IsDeleted = 0)
					--		AND AuditID IS NULL
					--		AND QuestionID = Q.QuestionID
					--		AND PlantID = @PlantID
					--	) 
					1 AS DataPoolID					
				FROM T_LNK_AssignedValueStreams LVS WITH (NOLOCK)
				INNER JOIN T_LNK_AssignedAssessors LAS WITH (NOLOCK) ON LVS.QuestionID = LAS.QuestionID
					AND LVS.IsDeleted = 0
					AND LAS.IsDeleted = 0
				INNER JOIN T_TRN_ValueStream VS WITH (NOLOCK) ON VS.ValueStreamID = LVS.ValueStreamID
					AND VS.IsDeleted = 0
				INNER JOIN T_TRN_Assessor A WITH (NOLOCK) ON A.AssessorID = LAS.AssessorID
					AND A.IsDeleted = 0
				INNER JOIN T_TRN_Question Q WITH (NOLOCK) ON Q.QuestionID = LVS.QuestionID
					AND Q.QuestionID NOT IN (
						SELECT QuestionID
						FROM #AnsweredAndSkippedQueestionIDs
						)
					AND Q.QuestionID = IIF(@SelectedQuestionID = 0, Q.QuestionID, @SelectedQuestionID)
					AND Q.IsDeleted = 0
					AND Q.PlantID = @PlantID
					AND (
						(Q.IsQuestionAlwaysActive = 1)
						OR (
							Q.IsQuestionAlwaysActive = 0
							AND (
								CAST((
										SELECT FormattedDateTime
										FROM fnGetDateTime(@PlantID)
										) AS DATE) >= CAST(Q.ActiveDateRangeFrom AS DATE)
								)
							AND (
								CAST((
										SELECT FormattedDateTime
										FROM fnGetDateTime(@PlantID)
										) AS DATE) <= CAST(Q.ActiveDateRangeTo AS DATE)
								)
							)
						)
				INNER JOIN #VSASCombination VSAS WITH (NOLOCK) ON VSAS.ValueStreamTemplateID = VS.ValueStreamTemplateID
					AND VSAS.ValueStreamID = VS.ValueStreamID
					AND VSAS.AssessorTemplateID = A.AssessorTemplateID
					AND VSAS.AssessorID = A.AssessorID
				) AS QuestionList

			--select * from #CombinationQuestionList
			-- Ends ****** Preparing Questionlist by applying VS & AS available combination *****************
			SELECT Identity(INT, 1, 1) AS OrderByID
				,TQ.QuestionID
				,CQL.DataPoolID
			INTO #QuestionAndDataPoolList
			FROM #CombinationQuestionList CQL WITH (NOLOCK)
			INNER JOIN T_TRN_Question TQ WITH (NOLOCK) ON TQ.QuestionID = CQL.QuestionID

			--select * from #QuestionAndDataPoolList
			-- Starts ****** Filter the question in sorted order *****************
			SELECT Identity(INT, 1, 1) AS OrderByID
				,CQL.*
				,RQ.RandomQuestionOrder
				,RQ.QuestionType
				,CT.CustomQuestionTagsID
			--,DP.DataPoolID
			INTO #FilteredQuestion
			FROM #CombinationQuestionList CQL WITH (NOLOCK)
			LEFT JOIN #QuestionAndDataPoolList DP WITH (NOLOCK) ON DP.QuestionID = CQL.QuestionID
			INNER JOIN T_TRN_Question TQ WITH (NOLOCK) ON TQ.QuestionID = CQL.QuestionID
			INNER JOIN T_LNK_Custom_Questions CQ WITH (NOLOCK) ON CQ.QuestionID = CQL.QuestionID
				--AND CQ.IsCustomMode = 1
				AND CQ.IsDeleted = 0
				AND CQ.CustomModeID = @CustomModeID
			LEFT JOIN T_LNK_Custom_QuestionsTags CT WITH (NOLOCK) ON CT.CustomQuestionTagsID = cq.CustomQuestionTagsID
				AND CT.QuestionID IS NULL
				AND CT.IsDeleted = 0
				AND CQ.CustomModeID = @CustomModeID
			LEFT JOIN T_LNK_Tag_AssignedQuestionsTags RQ WITH (NOLOCK) ON RQ.QuestionID = CQ.QuestionID	AND RQ.TagID = CT.TagID	AND RQ.IsDeleted = 0
				ORDER BY CT.CustomQuestionTagsID ASC
				,case when RQ.RandomQuestionOrder  is null then 998  end, RQ.RandomQuestionOrder
				,TQ.Question_PriorityID
				,TargetFrequencyTypeID
				,CASE 
					WHEN (
							(
								SELECT count(*)
								FROM #QuestionAndDataPoolList
								WHERE DataPoolID IS NOT NULL
								) <> (
								SELECT count(*)
								FROM #CombinationQuestionList
								)
							)
						THEN DP.DataPoolID
					END
				,CQL.QuestionID
				,ChoiceDisplayTypeID DESC

	--	insert into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('316_(4_customBind)',@PlantID,@CurrentUserNTID, getdate(),2)

				--select * from #FilteredQuestion
			--Ends ****** Filter the question in sorted order *****************
			--Starts ****** Send Back the result in sorted order *****************
			SELECT *
			INTO #ResultQuestions
			FROM (
				SELECT TQ.QuestionID
					,TQ.QuestionDisplayID
					,CASE
					 WHEN @ResumeTag =1 THEN TAQ.Answer
					 ELSE NULL
					 END AS Answer
					,CASE
					 WHEN @ResumeTag =1 THEN TAQ.DeviationDescription
					 ELSE NULL
					 END AS DeviationDescription
					,@CurrentUserNTID AS CurrentUserNTID
					,TV.ResponsibleEmployee 
					,QL.CustomQuestionTagsID
					,QL.RandomQuestionOrder
					,QL.QuestionType
					,TVT.Delimiter
					,QL.ValueStreamTemplateID
					,TVT.ValueStreamTemplateName
					,TV.ValueStreamCategoryID
					,TVC.valueStreamCategoryName
					,QL.ValueStreamID
					,TV.ValueStreamName
					,QL.AssessorTemplateID
					,TRA.AssessorTemplateName
					,QL.AssessorID					
					,TTA.AssessorName
					,QL.IsForgotValueStream
					,CASE 
						WHEN (QL.IsForgotValueStream = 1)
							THEN QL.VSSessionID
						ELSE NULL
						END AS VSSessionID
					,QL.IsForgotAssessor
					,CASE 
						WHEN (QL.IsForgotAssessor = 1)
							THEN QL.ASSessionID
						ELSE NULL
						END AS ASSessionID
					,(
						SELECT MAX(DataPoolID) AS DataPoolID
						FROM [t_trn_datapool] WITH (NOLOCK)
						WHERE answeredby_ntid = @NTID
							AND (IsDeleted = 0)
							AND AuditID IS NULL
							AND QuestionID = TQ.QuestionID
							AND PlantID = @PlantID
						) AS DataPoolID
					,TQ.QuestionText
					,TQ.QuestionHintText
					,TQ.AnswerType_AnswerTypeID
					,TQ.ChoiceDisplayTypeID
					,TQ.IsFilledInChoiceAllowed
					,TQ.IsUniqueAnswerRequired
					,TQ.IsAnswerRequired
					,CASE
					 WHEN @ResumeTag =1 THEN TAQ.ChoiceID
					 ELSE TQ.DefaultChoiceID
					 END AS DefaultChoiceID
					,TQ.IsQuestionAlwaysActive
					,TQ.ActiveDateRangeFrom
					,TQ.ActiveDateRangeTo
					,TQ.IsTargetFrequencyDefined
					,TQ.TargetFrequencyTypeID
					,TQ.TargetFrequencyValue
					,TQ.Question_PriorityID
					,TQ.IsDeleted
					,TQ.IsDefaultAnswerRequired
					,TQ.IsAnswered
					,TQ.CreatedAt
					,TQ.ModifiedAt
					,(
						SELECT DISTINCT abc = STUFF((
									SELECT ',' + HyperLinkURL
									FROM [T_TRN_HintHyperLink] WITH (NOLOCK)
									WHERE QuestionID = TQ.QuestionID
										AND (IsDeleted = 0)
									FOR XML PATH('')
										,TYPE
									).value('.', 'NVARCHAR(MAX)'), 1, 1, '')
						) AS HyperLinkURL
					,(
						SELECT DISTINCT abc = STUFF((
									SELECT ',' + ImageTitle
									FROM T_TRN_HintImage WITH (NOLOCK)
									WHERE QuestionID = TQ.QuestionID
										AND (IsDeleted = 0)
									FOR XML PATH('')
										,TYPE
									).value('.', 'NVARCHAR(MAX)'), 1, 1, '')
						) AS ImageTitle
					,(
						SELECT DISTINCT abc = STUFF((
									SELECT ',' + DisplayFileName
									FROM T_TRN_HintImage WITH (NOLOCK)
									WHERE QuestionID = TQ.QuestionID
										AND (IsDeleted = 0)
									FOR XML PATH('')
										,TYPE
									).value('.', 'NVARCHAR(MAX)'), 1, 1, '')
						) AS DisplayFileName
					,(
						SELECT ListTag
						FROM [FN_GetNestedTagsByQuestionID](TQ.QuestionID, 'strTagName')
						WHERE ListTag IS NOT NULL
						) AS TagNameList
					,(
						SELECT ListTag
						FROM [FN_GetNestedTagsByQuestionID](TQ.QuestionID, 'strTagID')
						WHERE ListTag IS NOT NULL
						) AS TagIDList
					,CASE 
						WHEN TQ.QuestionID IN (
								SELECT QuestionID
								FROM @myCustomTableVariable
								)
							THEN 1
						ELSE 0
						END AS IsCustomMode
					,'' AS SessionID
				FROM T_TRN_Question TQ WITH (NOLOCK)
				LEFT JOIN #FilteredQuestion QL WITH (NOLOCK) ON TQ.QuestionID = QL.QuestionID
				INNER JOIN [T_TRN_ValueStream] TV WITH (NOLOCK) ON TV.ValueStreamID = QL.ValueStreamID
				INNER JOIN [T_TRN_ValueStreamTemplate] TVT WITH (NOLOCK) ON TVT.ValueStreamTemplateID = TV.ValueStreamTemplateID
					AND TVT.PlantID = @PlantID
				INNER JOIN [T_TRN_ValueStreamCategory] TVC WITH (NOLOCK) ON TVC.ValueStreamCategoryID = TV.ValuestreamCategoryID
				INNER JOIN [T_TRN_Assessor] TTA WITH (NOLOCK) ON TTA.AssessorID = QL.AssessorID
				INNER JOIN [T_TRN_AssessorTemplate] TRA WITH (NOLOCK) ON TRA.AssessorTemplateID = TTA.AssessorTemplateID
					AND TRA.PlantID = @PlantID
				LEFT JOIN [T_TRN_HintHyperLink] TTH WITH (NOLOCK) ON TTH.QuestionID = TQ.QuestionID
				LEFT JOIN  (select * from (select ROW_NUMBER() over( partition by  QuestionID order by CustomAnsweredQuestionID desc ) AS ROWID ,* from T_LNK_Custom_AnsweredQuestions ) AS T where rowid=1 and CustomModeID=@CustomModeID and ModifiedBy_NTID= @CurrentUserNTID and plantid=@PlantID) AS TAQ   ON TAQ.QuestionID = QL.QuestionID
				WHERE TV.Responsible_UserID IS NOT NULL -- and  TQ.QuestionID not in(select QuestionID from #Temp) 
					AND (TQ.IsDeleted = 0)
					AND TQ.PlantID = @PlantID
				) AS t2

				update #ResultQuestions set RandomQuestionOrder=9999 where RandomQuestionOrder is null


			SELECT DISTINCT *
            FROM #ResultQuestions
            ORDER BY CustomQuestionTagsID ASC
                ,RandomQuestionOrder 
                ,Question_PriorityID
                ,TargetFrequencyTypeID
                ,ChoiceDisplayTypeID DESC
                ,QuestionID
	
	--insert into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('470_(5_customBind)',@PlantID,@CurrentUserNTID, getdate(),2)

			
			--inner join #FilteredQuestionNew QL on  QL.CustomQuestionTagsID=ResQ.CustomQuestionTagsID order by QL.CustomQuestionTagsID ASC
			-- Ends ****** Send Back the result in sorted order *****************
			COMMIT TRANSACTION CUSTOM_BINDQUESTIONANDANSWERTYPE;
		END TRY

		BEGIN CATCH
			ROLLBACK TRANSACTION CUSTOM_BINDQUESTIONANDANSWERTYPE;

			EXEC [USP_LogError] @PlantID
				,@CurrentUserNTID;
		END CATCH
	END
	ELSE
	BEGIN
		SELECT - 1 AS QuestionID
	END
END
GO
