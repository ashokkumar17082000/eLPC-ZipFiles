/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_Restore_T_TRN_DataPoolHistory]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RESTORING DATA POOL HISTORY
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					25-MAR-2021			SIKHESH S					ADDITIONAL PARAMATERS INCLUDED AND RELEATED CHANGES, STANDARD RULES APPLIED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_Restore_T_TRN_DataPoolHistory] 1, 1
*/
CREATE PROCEDURE [USP_Restore_T_TRN_DataPoolHistory] (
	@DataPoolHistoryID INT
	,@PlantID INT
	,@CurrentUserNTID NVARCHAR(20)
	)
AS
BEGIN
	SET NOCOUNT ON;
	SET LOCK_TIMEOUT 5000;

	BEGIN TRY
		BEGIN TRANSACTION RESTORE_DATAPOOLHISTORY;

		IF EXISTS (
				SELECT TOP 1 DataPoolHistoryID
				FROM T_TRN_DataPoolHistory WITH(NOLOCK)
				WHERE DataPoolHistoryID = @DataPoolHistoryID
					AND PlantID = @PlantID
				)
		BEGIN
			-- Update [T_TRN_DataPool]
			DECLARE @DataPoolID INT;
			DECLARE @DataPoolDisplayID INT;
			DECLARE @TimeStamp DATETIME;
			DECLARE @ValueStreamID INT;
			DECLARE @AssessorID INT;
			DECLARE @QuestionID INT;
			DECLARE @Answer NVARCHAR(MAX);
			DECLARE @answerType_AnswerTypeID INT;
			DECLARE @CreatedAt DATETIME;
			DECLARE @AnsweredBy_NTID VARCHAR(50);
			DECLARE @ModifiedAt DATETIME;
			DECLARE @ModifiedBy_NTID VARCHAR(50);
			DECLARE @TagID INT;
			DECLARE @IsDeviation BIT;
			DECLARE @IsAnswered BIT;
			DECLARE @ObtainedScore DECIMAL(10, 2);
			DECLARE @ChoiceID INT;
			DECLARE @DeviationID INT;
			DECLARE @AuditID INT;
			DECLARE @AuditTemplateID INT;
			DECLARE @IsShowVsAs BIT;
			DECLARE @IsDeleted BIT;

			SELECT TOP 1 @DataPoolID = DataPoolID
				,@DataPoolDisplayID = DataPoolDisplayID
				,@TimeStamp = [TimeStamp]
				,@ValueStreamID = ValueStreamID
				,@AssessorID = AssessorID
				,@QuestionID = QuestionID
				,@Answer = Answer
				,@answerType_AnswerTypeID = answerType_AnswerTypeID
				,@CreatedAt = CreatedAt
				,@AnsweredBy_NTID = AnsweredBy_NTID
				,@ModifiedAt = ModifiedAt
				,@ModifiedBy_NTID = ModifiedBy_NTID
				,@TagID = TagID
				,@IsDeviation = IsDeviation
				,@IsAnswered = IsAnswered
				,@ObtainedScore = ObtainedScore
				,@ChoiceID = ChoiceID
				,@DeviationID = DeviationID
				,@AuditID = AuditID
				,@AuditTemplateID = AuditTemplateID
				,@IsShowVsAs = IsShowVsAs
				,@IsDeleted = IsDeleted
			FROM T_TRN_DataPoolHistory WITH(NOLOCK)
			WHERE @DataPoolHistoryID = DataPoolHistoryID
				AND PlantID = @PlantID;

			IF EXISTS (
					SELECT DataPoolID
					FROM T_TRN_DataPool WITH(NOLOCK)
					WHERE DataPoolID = @DataPoolID
						AND PlantID = @PlantID
					)
			BEGIN
				UPDATE [T_TRN_DataPool]
				SET DataPoolDisplayID = @DataPoolDisplayID
					,[TimeStamp] = @TimeStamp
					,ValueStreamID = @ValueStreamID
					,AssessorID = @AssessorID
					,QuestionID = @QuestionID
					,Answer = @Answer
					,answerType_AnswerTypeID = @answerType_AnswerTypeID
					,CreatedAt = @CreatedAt
					,AnsweredBy_NTID = @AnsweredBy_NTID
					,ModifiedAt = (
						SELECT FormattedDateTime
						FROM fnGetDateTime(@PlantID)
						)
					,ModifiedBy_NTID = @CurrentUserNTID
					,TagID = @TagID
					,IsDeviation = @IsDeviation
					,IsAnswered = @IsAnswered
					,ObtainedScore = @ObtainedScore
					,ChoiceID = @ChoiceID
					,DeviationID = @DeviationID
					,AuditID = @AuditID
					,AuditTemplateID = @AuditTemplateID
					,IsShowVsAs = @IsShowVsAs
					,IsDeleted = @IsDeleted
				WHERE DataPoolID = @DataPoolID
					AND PlantID = @PlantID;
			END
			ELSE --THIS CASE MAY BE USED IN CASE OF RESTORE FROM RECYCLEBIN
			BEGIN
				INSERT INTO [T_TRN_DataPool] (
					PlantID
					,DataPoolDisplayID
					,[TimeStamp]
					,ValueStreamID
					,AssessorID
					,QuestionID
					,Answer
					,answerType_AnswerTypeID
					,CreatedAt
					,AnsweredBy_NTID
					,ModifiedAt
					,ModifiedBy_NTID
					,TagID
					,IsDeviation
					,IsAnswered
					,ObtainedScore
					,ChoiceID
					,DeviationID
					,AuditID
					,AuditTemplateID
					,IsShowVsAs
					,IsDeleted
					)
				VALUES (
					@PlantID
					,(
						SELECT DisplayID
						FROM [FN_GetNextDisplayID](@PlantID, 'T_TRN_DataPool')
						)
					,@TimeStamp
					,@ValueStreamID
					,@AssessorID
					,@QuestionID
					,@Answer
					,@answerType_AnswerTypeID
					,@CreatedAt
					,@AnsweredBy_NTID
					,(
						SELECT FormattedDateTime
						FROM fnGetDateTime(@PlantID)
						)
					,@CurrentUserNTID
					,@TagID
					,@IsDeviation
					,@IsAnswered
					,@ObtainedScore
					,@ChoiceID
					,@DeviationID
					,@AuditID
					,@AuditTemplateID
					,@IsShowVsAs
					,@IsDeleted
					);
			END

			--END - Update [T_TRN_DataPool]
			COMMIT TRANSACTION RESTORE_DATAPOOLHISTORY;
		END
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION RESTORE_DATAPOOLHISTORY;

		EXEC USP_LogError @PlantID
			,@CurrentUserNTID;
	END CATCH
END
GO


