/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_FetchValueStreamCategory]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING VALUESTREAM CATEGORY
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					26-MAR-2021			Rajasekar S					PlantId,currentuserNTID, DisplayId, 'set NOCOUNT ON' added. * expanded

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_FetchValueStreamCategory]
*/
CREATE PROCEDURE [USP_FetchValueStreamCategory] @PlantID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = 0
		,@Mode = 'VALUESTREAMTEMPLATE'
		,@CurrentUserNTID = @CurrentUserNTID

	SET NOCOUNT ON;

	SELECT VSC.ValueStreamCategoryID
		,VSC.ValueStreamCategoryName
		,VSC.ValueStreamTemplateID
		,VSC.IsDataRequired
		,VSC.TypeOfInput_InputTypeID
		,VSC.IsDataRequiredToFitSpecLength
		,VSC.MinimumNoOfCharacters
		,VSC.MaximumNoOfCharacters
		,VSC.InputType
		,VSC.NodeID
		,VSC.IsColumnRequired
	FROM T_TRN_ValueStreamCategory VSC WITH (NOLOCK)
	INNER JOIN T_TRN_ValueStreamTemplate VST WITH (NOLOCK) ON VSC.ValueStreamTemplateID = VST.ValueStreamTemplateID
	WHERE (
			VST.PlantID = @PlantID
			AND VSC.IsDeleted = 0
			)
END
GO


