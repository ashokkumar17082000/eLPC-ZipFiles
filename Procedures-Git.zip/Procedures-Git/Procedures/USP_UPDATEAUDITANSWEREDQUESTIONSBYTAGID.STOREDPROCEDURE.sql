/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_UpdateAuditAnsweredQuestionsByTagID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR UPDATING AUDIT ANSWERED QUESTIONS BY TAG ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			Rajasekar S					PlantId,CurrentUserNTID added

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_UpdateAuditAnsweredQuestionsByTagID] 1,1,'RSB4COB'
*/
CREATE PROCEDURE [USP_UpdateAuditAnsweredQuestionsByTagID] @PlantID INT
	,@TagID INT
	,@CurrentUserNTID NVARCHAR(20)
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION TRNUPATEAUDITANSWER

		EXEC [USP_PlantIDValidation] @PlantID = @PlantID
			,@ID = 0
			,@Mode = 'AUDIT'
			,@CurrentUserNTID = @CurrentUserNTID

		DECLARE @ID INT

		SELECT AuditID AS ID
		INTO #T1
		FROM T_TRN_Audit WITH(NOLOCK)
		WHERE TagID = @TagID
			AND PlantID = @PlantID


		DECLARE MY_CURSOR CURSOR FORWARD_ONLY
		FOR
		SELECT ID
		FROM #T1

		OPEN MY_CURSOR

		FETCH NEXT
		FROM MY_CURSOR
		INTO @ID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			UPDATE T_LNK_Audit_AnsweredQuestions
			SET IsAuditActive = 0 
			WHERE AuditID = @ID  and CAST(ModifiedAt As Date) = CAST(GETDATE() As Date)

			FETCH NEXT
			FROM MY_CURSOR
			INTO @ID
		END

		CLOSE MY_CURSOR

		DEALLOCATE MY_CURSOR

		COMMIT TRANSACTION TRNUPATEAUDITANSWER
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNUPATEAUDITANSWER

		EXEC USP_LogError @PlantID
			,@CurrentUserNTID
	END CATCH
END
GO