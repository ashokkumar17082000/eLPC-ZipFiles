SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [USP_UpdateValueStreamID] @ValueStreamTemplateID INT
	,@RowID INT
AS
BEGIN TRY
	DECLARE @NodeID INT = 0;
	DECLARE @NewValueStreamID INT = 0;

	SET @NodeID = (
			SELECT Max(NodeID)
			FROM T_TRN_ValueStream
			WHERE ValueStreamTemplateID = @ValueStreamTemplateID
				AND RowID = @RowID
			)
	SET @NewValueStreamID = (
			SELECT TOP 1 ValueStreamID
			FROM T_TRN_ValueStream
			WHERE ValueStreamTemplateID = @ValueStreamTemplateID
				AND RowID = @RowID
				AND NodeID = @NodeID
			)

	UPDATE T_LNK_AssignedValueStreams
	SET ValueStreamID = @NewValueStreamID
	WHERE ValueStreamID IN (
			SELECT ValueStreamID
			FROM T_TRN_ValueStream
			WHERE ValueStreamTemplateID = @ValueStreamTemplateID
				AND RowID = @RowID
				AND ValueStreamID != @NewValueStreamID
			)

	UPDATE T_LNK_Tag_AssignedValueStreams
	SET ValueStreamID = @NewValueStreamID
	WHERE ValueStreamID IN (
			SELECT ValueStreamID
			FROM T_TRN_ValueStream
			WHERE ValueStreamTemplateID = @ValueStreamTemplateID
				AND RowID = @RowID
				AND ValueStreamID != @NewValueStreamID
			)

	UPDATE T_TRN_Audit
	SET ValueStreamID = @NewValueStreamID
	WHERE ValueStreamID IN (
			SELECT ValueStreamID
			FROM T_TRN_ValueStream
			WHERE ValueStreamTemplateID = @ValueStreamTemplateID
				AND RowID = @RowID
				AND ValueStreamID != @NewValueStreamID
			)

	UPDATE T_TRN_Datapool
	SET ValueStreamID = @NewValueStreamID
	WHERE ValueStreamID IN (
			SELECT ValueStreamID
			FROM T_TRN_ValueStream
			WHERE ValueStreamTemplateID = @ValueStreamTemplateID
				AND RowID = @RowID
				AND ValueStreamID != @NewValueStreamID
			)
END TRY

BEGIN CATCH
	ROLLBACK TRANSACTION
END CATCH
GO


