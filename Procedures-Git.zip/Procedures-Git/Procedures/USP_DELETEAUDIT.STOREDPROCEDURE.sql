/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_DeleteAudit]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR DELETING AUDIT
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					22-MAR-2021			Rajasekar S					PlantId,CurrentUserNTID added, logic change for audit deletion
ELPC_LH_002_CR01			8-JUL-2021			Rajasekar S					Calendar Recurrance option added
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_DeleteAudit] 1, 'OSP4KOR' , 'OSP4KOR'
*/
CREATE PROCEDURE [USP_DeleteAudit] (
	@PlantID INT
	,@AuditID INT NULL
	,@CurrentUserNTID NVARCHAR(20)
	)
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION TRNDELETEAUDIT

		EXEC [USP_PlantIDValidation] @PlantID = @PlantID
			,@ID = @AuditID
			,@Mode = 'AUDIT'
			,@CurrentUserNTID = @CurrentUserNTID

		IF EXISTS (
				SELECT 1
				FROM T_TRN_Audit WITH(NOLOCK)
				WHERE AuditID = @AuditID
					AND PlantID = @PlantID
					AND CreatedBy_NTID = @CurrentUserNTID
				)
		BEGIN
			UPDATE T_TRN_Audit
			SET IsDeleted = 1
				,IsRecurring = 0
				,IsAllDay = 0
			WHERE AuditID = @AuditID
				AND PlantID = @PlantID

			DELETE
			FROM [T_TRN_Recurrence]
			WHERE [AuditID] = @AuditID
				AND PlantID = @PlantID
		END
		ELSE
		BEGIN
			UPDATE T_LNK_Audit_RequiredAttendees
			SET IsDeleted = 1
			WHERE AuditID = @AuditID
				AND NTID = @CurrentUserNTID

			UPDATE T_LNK_Audit_OptionalAttendees
			SET IsDeleted = 1
			WHERE AuditID = @AuditID
				AND NTID = @CurrentUserNTID
		END

		COMMIT TRANSACTION TRNDELETEAUDIT
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNDELETEAUDIT

		EXEC USP_LogError @PlantID
			,@CurrentUserNTID
	END CATCH
END
GO

