/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_Custom_BindQuestionAndAnswerType] 
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE TO CUSTOM BIND QUESTION AND ANSWER TYPE
///MODIFICATION HISTORY         :  
************************************************************************************************************ 
///REF                      DATE                MODIFIED BY                 CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_006                 18-AUG-2023         SUSHANTH             PERFOMANCE IMPROVEMENT  
************************************************************************************************************ 


/****** Object:  StoredProcedure [dbo].[USP_fetchVSASDetailsByID]    Script Date: 8/21/2023 5:18:44 PM ******/
*/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [USP_fetchVSASDetailsByID] 
(@Type varchar(50) = null
,@Mode varchar(50) = null
,@QuestionID int = null
,@TagID int = null)
  AS
  BEGIN
  IF(@Type='Question' and @Mode='ValueStream')
  BEGIN
  SELECT STRING_AGG(CONVERT(NVARCHAR(MAX), ValueStreamID), ',') AS IDList
   FROM T_TRN_ValueStream WITH (NOLOCK)  
   WHERE ValueStreamID IN (  
     SELECT DISTINCT ValueStreamID  
     FROM T_LNK_AssignedValueStreams WITH (NOLOCK)  
     WHERE IsDeleted = 0
      AND QuestionID = @QuestionID)     
    AND IsDeleted = 0 
  END
   ELSE IF(@Type='Question' and @Mode='Assessor')
  BEGIN
   SELECT STRING_AGG(CONVERT(NVARCHAR(MAX), AssessorID), ',')  AS IDList
   FROM T_TRN_Assessor WITH (NOLOCK)  
   WHERE AssessorID IN (  
     SELECT DISTINCT AssessorID  
     FROM T_LNK_AssignedAssessors WITH (NOLOCK)  
     WHERE IsDeleted = 0 
      AND QuestionID = @QuestionID)      
    AND IsDeleted = 0 
	END
	ELSE IF(@Type='Tag' and @Mode='ValueStream')
	BEGIN
	SELECT STRING_AGG(CONVERT(NVARCHAR(MAX), ValueStreamID), ',')  AS IDList         
   FROM T_TRN_ValueStream WITH (NOLOCK)            
   WHERE ValueStreamID IN (            
     SELECT DISTINCT ValueStreamID            
     FROM T_LNK_Tag_AssignedValueStreams WITH (NOLOCK)            
     WHERE IsDeleted = 0        
      AND TagID = @TagID)           
    AND IsDeleted = 0
	END
	ELSE IF(@Type='Tag' and @Mode='Assessor')
	BEGIN
	 SELECT STRING_AGG(CONVERT(NVARCHAR(MAX), AssessorID), ',')  AS IDList          
   FROM T_TRN_Assessor WITH (NOLOCK)            
   WHERE AssessorID IN (            
     SELECT DISTINCT AssessorID            
     FROM T_LNK_Tag_AssignedAssessors WITH (NOLOCK)            
     WHERE IsDeleted = 0           
      AND TagID = @TagID)            
    AND IsDeleted = 0     
	END	
  END
  GO







   

 