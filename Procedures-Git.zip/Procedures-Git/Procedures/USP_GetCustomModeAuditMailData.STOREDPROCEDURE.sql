/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_GetCustomModeAuditMailData]
///AUTHOR                       : RAJASEKAR S
///CREATED DATE                 : 26-JUL-2021
///SEE ALSO                     : THIS PROCEDURE TO GET AUDIT MAIL CONTENT 
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 

ELPC_LH_006					18-AUG-2023			ASHOK KUMAR R B					INITIAL VERSION

************************************************************************************************************ 
*/
/****** Object:  StoredProcedure [uatgrp1].[USP_GetCustomModeAuditMailData]    Script Date: 8/4/2023 12:53:36 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
exec [USP_GetCustomModeAuditMailData] 4614,13,1,'FSM1COB',57081
*/
/*
exec [USP_GetCustomModeAuditMailData] 0,7,5,'FSM1COB',105264
*/
CREATE PROCEDURE [USP_GetCustomModeAuditMailData] (    
 @TagID INT    
 ,@CustomModeID INT    
 ,@PlantID INT 
 ,@CurrentUserNTID NVARCHAR(20)   
 ,@ValueStreamID INT
    
 )    
AS    
BEGIN    
 DECLARE @NtIdTable TABLE (NTID VARCHAR(20));    
 DECLARE @From VARCHAR(MAX);    
 DECLARE @To VARCHAR(MAX);    
 DECLARE @Cc VARCHAR(MAX);    
 DECLARE @Subject NVARCHAR(MAX);    
 DECLARE @Body NVARCHAR(MAX);    
 DECLARE @TagName VARCHAR(MAX);    
 DECLARE @LeadAuditor VARCHAR(MAX);    
 DECLARE @Attendees VARCHAR(MAX);    
 DECLARE @ValueStreamText NVARCHAR(MAX);    
 
  

 --FROM    
 INSERT INTO @NtIdTable    
 SELECT @CurrentUserNTID    
    
    
 SELECT @From = STUFF((    
    SELECT DISTINCT ';' + EmailAddress    
    FROM T_MST_User    
    WHERE NTID IN (    
      SELECT NTID    
      FROM @NtIdTable    
      )    
    FOR XML PATH('')    
    ), 1, 1, '')    
    
 
    
 SELECT @To = STUFF((    
    SELECT DISTINCT ';' + EmailAddress    
    FROM T_MST_User WITH(NOLOCK)    
    WHERE NTID IN (    
      SELECT NTID    
      FROM @NtIdTable    
      )    
    FOR XML PATH('')    
    ), 1, 1, '')    
    
   
 
 SELECT @Cc = STUFF((    
    SELECT DISTINCT ';' + EmailAddress    
    FROM T_MST_User WITH(NOLOCK)    
    WHERE NTID IN (    
      SELECT NTID    
      FROM @NtIdTable    
      )    
    FOR XML PATH('')    
    ), 1, 1, '')    
    
 --Subject    
 SELECT @Subject = T.TagName    
 FROM T_TRN_Audit A WITH(NOLOCK)    
 INNER JOIN T_TRN_Tag T WITH(NOLOCK) ON A.TagID = T.TagID    
 WHERE A.TagID = @TagID --AuditorSurvey Type>> (Audit / Survey)    
    
 --Body    
 SELECT @LeadAuditor = STUFF((    
    SELECT DISTINCT ';' + EmailAddress    
    FROM T_MST_User WITH(NOLOCK)    
    WHERE NTID IN (    
      SELECT NTID    
      FROM @NtIdTable    
      )    
    FOR XML PATH('')    
    ), 1, 1, '')    
    

    
 SET @ValueStreamText= (  
SELECT  ValueStreamName  
 FROM T_TRN_Valuestream where valuestreamid=@valuestreamID)
    
	--select @plantid
	--select @tagmodeid
	--select @tagid
	--select @currentuserntid
 SELECT @From [From]    
  ,@To [To]    
  ,@Cc Cc    
  ,@Subject [Subject]    
  ,@LeadAuditor LeadAuditor    
  ,@Attendees Attendees    
  ,@ValueStreamText ValueStreamText    
  ,(    
   SELECT FormattedDateTime    
   FROM [fnGetDateTime](@PlantID)    
   ) AS AnsweredTime    
    
	SET NOCOUNT ON;

	DECLARE @RowExists BIT = 0;
	DECLARE @ValidRows BIT = 0;
	DECLARE @SelectedQuestionID INT =0;
	IF EXISTS (
			SELECT TOP 1 1
			FROM [T_TRN_ValueStreamConfig] vsc WITH (NOLOCK)
			CROSS JOIN [T_TRN_AssessorConfig] ac WITH (NOLOCK)
			WHERE vsc.IsDeleted = 0
				AND ac.IsDeleted = 0
				AND vsc.PlantID = @PlantID
				AND ac.PlantID = @PlantID
				AND vsc.User_NTID = @CurrentUserNTID
				AND ac.User_NTID = @CurrentUserNTID
				AND vsc.ValueStreamID IN (
					SELECT c.ValueStreamID
					FROM [T_TRN_ValueStreamConfig] c
					INNER JOIN T_TRN_ValueStreamTemplate vst WITH (NOLOCK) ON vst.ValueStreamTemplateID = c.ValueStreamTemplateID
					INNER JOIN T_TRN_ValueStream vs WITH (NOLOCK) ON vs.ValueStreamID = c.ValueStreamID
					INNER JOIN T_TRN_ValueStreamCategory cat WITH (NOLOCK) ON c.ValueStreamTemplateID = cat.ValueStreamTemplateID
					WHERE c.PlantID = @PlantID
						AND c.User_NTID = @CurrentUserNTID
						AND c.IsDeleted = 0
						AND vst.IsDeleted = 0
						AND vs.IsDeleted = 0
						AND cat.IsDeleted = 0
					)
				AND ac.AssessorID IN (
					SELECT DISTINCT c.AssessorID
					FROM T_TRN_AssessorConfig c WITH (NOLOCK)
					INNER JOIN T_TRN_AssessorTemplate ast WITH (NOLOCK) ON ast.AssessorTemplateID = c.AssessorTemplateID
					INNER JOIN T_TRN_Assessor a WITH (NOLOCK) ON a.AssessorID = c.AssessorID
					WHERE c.PlantID = @PlantID
						AND c.User_NTID = @CurrentUserNTID
						AND c.IsDeleted = 0
						AND ast.IsDeleted = 0
						AND a.IsDeleted = 0
					)
			)
	BEGIN
		SET @RowExists = 1
	END

	IF NOT EXISTS (
			SELECT TOP 1 1
			FROM [T_TRN_ValueStreamConfig] vsc WITH (NOLOCK)
			CROSS JOIN [T_TRN_AssessorConfig] ac WITH (NOLOCK)
			WHERE vsc.IsDeleted = 0
				AND ac.IsDeleted = 0
				AND vsc.PlantID = @PlantID
				AND ac.PlantID = @PlantID
				AND vsc.User_NTID = @CurrentUserNTID
				AND ac.User_NTID = @CurrentUserNTID
				AND vsc.ValueStreamID IN (
					SELECT c.ValueStreamID
					FROM [T_TRN_ValueStreamConfig] c
					INNER JOIN T_TRN_ValueStreamTemplate vst WITH (NOLOCK) ON vst.ValueStreamTemplateID = c.ValueStreamTemplateID
					INNER JOIN T_TRN_ValueStream vs WITH (NOLOCK) ON vs.ValueStreamID = c.ValueStreamID
					INNER JOIN T_TRN_ValueStreamCategory cat WITH (NOLOCK) ON c.ValueStreamTemplateID = cat.ValueStreamTemplateID
					WHERE c.PlantID = @PlantID
						AND c.User_NTID = @CurrentUserNTID
						AND c.IsDeleted = 0
						AND vst.IsDeleted = 0
						AND vs.IsDeleted = 0
						AND cat.IsDeleted = 0
					)
				AND ac.AssessorID IN (
					SELECT DISTINCT c.AssessorID
					FROM T_TRN_AssessorConfig c WITH (NOLOCK)
					INNER JOIN T_TRN_AssessorTemplate ast WITH (NOLOCK) ON ast.AssessorTemplateID = c.AssessorTemplateID
					INNER JOIN T_TRN_Assessor a WITH (NOLOCK) ON a.AssessorID = c.AssessorID
					WHERE c.PlantID = @PlantID
						AND c.User_NTID = @CurrentUserNTID
						AND c.IsDeleted = 0
						AND ast.IsDeleted = 0
						AND a.IsDeleted = 0
					)
				AND (
					(
						vsc.IsForgotValueStream = 1
						
						)
					OR (
						ac.IsForgotAssessor = 1
						
						)
					)
			)
	BEGIN
		SET @ValidRows = 1
	END

	IF (
			@RowExists = 1
			AND @ValidRows = 1
			)
	
		
			

			-- Starts ****** Identifying the custome mode questions *****************
			
			DECLARE @myCustomTableVariable TABLE (QuestionID INT)

			SET @CustomModeID = (
					SELECT CustomModeID
					FROM [T_TRN_CustomMode] WITH (NOLOCK)
					WHERE CreatedBy_NTID = @CurrentUserNTID
						AND PlantID = @PlantID
					);

			INSERT INTO @myCustomTableVariable (QuestionID)
			SELECT QuestionID
			FROM (
				SELECT QuestionID
				FROM [T_LNK_Custom_Questions] WITH (NOLOCK)
				WHERE CustomModeID = @CustomModeID
					AND IsCustomMode = 1
					AND IsDeleted = 0
				) AS tmpCusttbl

			-- Ends ****** Identifying the custome mode questions *****************
			-- Starts ****** Combing & forming VS & AS for filtering Questions belongs to available combination *****************
			SELECT *
			INTO #VSASCombination
			FROM (
				SELECT vsc.User_NTID
					,vsc.ValueStreamTemplateID
					,vsc.ValueStreamID
					,ac.AssessorTemplateID
					,ac.AssessorID
					,vsc.IsForgotValueStream
					,ac.IsForgotAssessor
					,vsc.SessionID AS VSSessionID
					,ac.SessionID AS ASSessionID
				FROM [T_TRN_ValueStreamConfig] vsc WITH (NOLOCK)
				CROSS JOIN [T_TRN_AssessorConfig] ac WITH (NOLOCK)
				WHERE vsc.IsDeleted = 0
					AND ac.IsDeleted = 0
					AND vsc.PlantID = @PlantID
					AND ac.PlantID = @PlantID
					AND vsc.User_NTID = @CurrentUserNTID
					AND ac.User_NTID = @CurrentUserNTID
				) AS VSASCombination

			-- Ends ****** Combing & forming VS & AS for filtering Questions belongs to available combination *****************
			
			-- Starts ****** Preparing Questionlist by applying VS & AS available combination *****************
			SELECT *
			INTO #CombinationQuestionList
			FROM (
				SELECT DISTINCT LVS.QuestionID
					,VS.ValueStreamTemplateID
					,LVS.ValueStreamID
					,A.AssessorTemplateID
					,LAS.AssessorID
					,VSAS.IsForgotValueStream
					,VSAS.IsForgotAssessor
					,VSAS.VSSessionID
					,VSAS.ASSessionID
					
					,(
						SELECT IIF(MAX(DataPoolID) IS NULL, NULL, 1) AS DataPoolID
						FROM [t_trn_datapool] WITH (NOLOCK)
						WHERE answeredby_ntid = @CurrentUserNTID
							AND (IsDeleted = 0)
							AND AuditID IS NULL
							AND QuestionID = Q.QuestionID
							AND PlantID = @PlantID
						) AS DataPoolID
				FROM T_LNK_AssignedValueStreams LVS WITH (NOLOCK)
				INNER JOIN T_LNK_AssignedAssessors LAS WITH (NOLOCK) ON LVS.QuestionID = LAS.QuestionID
					AND LVS.IsDeleted = 0
					AND LAS.IsDeleted = 0
				INNER JOIN T_TRN_ValueStream VS WITH (NOLOCK) ON VS.ValueStreamID = LVS.ValueStreamID
					AND VS.IsDeleted = 0
				INNER JOIN T_TRN_Assessor A WITH (NOLOCK) ON A.AssessorID = LAS.AssessorID
					AND A.IsDeleted = 0
				INNER JOIN T_TRN_Question Q WITH (NOLOCK) ON Q.QuestionID = LVS.QuestionID
					
					AND Q.QuestionID = IIF(@SelectedQuestionID = 0, Q.QuestionID, @SelectedQuestionID)
					AND Q.IsDeleted = 0
					AND Q.PlantID = @PlantID
					AND (
						(Q.IsQuestionAlwaysActive = 1)
						OR (
							Q.IsQuestionAlwaysActive = 0
							AND (
								CAST((
										SELECT FormattedDateTime
										FROM fnGetDateTime(@PlantID)
										) AS DATE) >= CAST(Q.ActiveDateRangeFrom AS DATE)
								)
							AND (
								CAST((
										SELECT FormattedDateTime
										FROM fnGetDateTime(@PlantID)
										) AS DATE) <= CAST(Q.ActiveDateRangeTo AS DATE)
								)
							)
						)
				INNER JOIN #VSASCombination VSAS WITH (NOLOCK) ON VSAS.ValueStreamTemplateID = VS.ValueStreamTemplateID
					AND VSAS.ValueStreamID = VS.ValueStreamID
					AND VSAS.AssessorTemplateID = A.AssessorTemplateID
					AND VSAS.AssessorID = A.AssessorID
				) AS QuestionList

			--select * from #CombinationQuestionList
			-- Ends ****** Preparing Questionlist by applying VS & AS available combination *****************
			SELECT Identity(INT, 1, 1) AS OrderByID
				,TQ.QuestionID
				,CQL.DataPoolID
			INTO #QuestionAndDataPoolList
			FROM #CombinationQuestionList CQL WITH (NOLOCK)
			INNER JOIN T_TRN_Question TQ WITH (NOLOCK) ON TQ.QuestionID = CQL.QuestionID

			--select * from #QuestionAndDataPoolList
			-- Starts ****** Filter the question in sorted order *****************
			SELECT Identity(INT, 1, 1) AS OrderByID
				,CQL.*
				,RQ.RandomQuestionOrder
				,CT.CustomQuestionTagsID
			--,DP.DataPoolID
			INTO #FilteredQuestion
			FROM #CombinationQuestionList CQL WITH (NOLOCK)
			LEFT JOIN #QuestionAndDataPoolList DP WITH (NOLOCK) ON DP.QuestionID = CQL.QuestionID
			INNER JOIN T_TRN_Question TQ WITH (NOLOCK) ON TQ.QuestionID = CQL.QuestionID
			INNER JOIN T_LNK_Custom_Questions CQ WITH (NOLOCK) ON CQ.QuestionID = CQL.QuestionID
				--AND CQ.IsCustomMode = 1
				AND CQ.IsDeleted = 0
				AND CQ.CustomModeID = @CustomModeID
			LEFT JOIN T_LNK_Custom_QuestionsTags CT WITH (NOLOCK) ON CT.CustomQuestionTagsID = cq.CustomQuestionTagsID
				AND CT.QuestionID IS NULL
				AND CT.IsDeleted = 0
				AND CQ.CustomModeID = @CustomModeID
			LEFT JOIN T_LNK_Tag_AssignedQuestionsTags RQ WITH (NOLOCK) ON RQ.QuestionID = CQ.QuestionID	AND RQ.TagID = CT.TagID	AND RQ.IsDeleted = 0
				ORDER BY CT.CustomQuestionTagsID ASC
				,case when RQ.RandomQuestionOrder  is null then 998  end, RQ.RandomQuestionOrder
				,TQ.Question_PriorityID
				,TargetFrequencyTypeID
				,CASE 
					WHEN (
							(
								SELECT count(*)
								FROM #QuestionAndDataPoolList
								WHERE DataPoolID IS NOT NULL
								) <> (
								SELECT count(*)
								FROM #CombinationQuestionList
								)
							)
						THEN DP.DataPoolID
					END
				,CQL.QuestionID
				,ChoiceDisplayTypeID DESC


				--select * from #FilteredQuestion
 select * from (
 select DISTINCT TMQ.QuestionID
  ,'Q' + CAST(Q.QuestionDisplayID AS VARCHAR) AS QuestionDisplayID
 ,Q.QuestionText
 , CASE 
	 WHEN TAQ.Answer is null then 'Question Skipped'
	 ELSE TAQ.Answer
	 END AS Answer   
 ,TAQ.DeviationDescription
 ,TMQ.CustomModeID  from [T_LNK_Custom_Questions] TMQ 
 INNER JOIN #FilteredQuestion FQ WITH(NOLOCK) ON FQ.QuestionID = TMQ.QuestionID
 LEFT JOIN  (select * from (select ROW_NUMBER() over( partition by  QuestionID order by CustomAnsweredQuestionID desc ) AS ROWID ,* from T_LNK_Custom_AnsweredQuestions ) AS T where rowid=1 and CustomModeID=@CustomModeID and ModifiedBy_NTID= @CurrentUserNTID and plantid=@PlantID) AS TAQ   ON TAQ.QuestionID = TMQ.QuestionID and TAQ.isdeleted =0
 --left  join [T_LNK_Custom_AnsweredQuestions]  TAQ ON TMQ.QuestionID= TAQ.QuestionID  and TAQ.isdeleted =0 
 left join T_TRN_Question Q WITH(NOLOCK) ON Q.QuestionID = TMQ.QuestionID ) 
 as temp 
 where temp.CustomModeID=@CustomModeID

UPDATE  [T_LNK_Custom_AnsweredQuestions] SET IsDeleted=1 where CustomModeID =@CustomModeId AND PlantID=@Plantid AND ModifiedBy_NTID=@CurrentUserNTID 

END    
GO