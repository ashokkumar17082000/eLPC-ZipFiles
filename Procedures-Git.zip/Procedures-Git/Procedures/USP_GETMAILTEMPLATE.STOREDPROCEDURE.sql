/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_GetMailTemplate]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING EMAIL TEMPLTE BY TEMPLATEID OR BY (LANGUAGECODE AND TEMPLATE NAME)
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			RAJASEKAR S					PLANTID,CURRENTUSERNTID ADDED
ELPC_LH_002-CR02			20-SEP-2021			VENKATESH GOVINDARAJ		IF TEMPLATE NOT AVALIABLE RETURN ENGLISH LANGUAGE TEMPLATE
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_GetMailTemplate] 1,NULL,'DE','Deviation','EGV1COB'
*/
CREATE PROCEDURE [USP_GetMailTemplate] (
	@PlantID INT
	,@TempID INT = 0
	,@Language NVARCHAR(10) = NULL
	,@Template NVARCHAR(20) = NULL
	,@CurrentUserNTID NVARCHAR(20)
	)
AS
BEGIN
	SET NOCOUNT ON;

	EXEC [USP_PlantIDValidation] @PlantID = @PlantID
		,@ID = 0
		,@Mode = '*'
		,@CurrentUserNTID = @CurrentUserNTID

	IF EXISTS (
			SELECT 1
			FROM T_MST_EmailTemplate WITH(NOLOCK)
			WHERE LanguageCode = @Language
				AND Template = @Template
			)
	BEGIN
		SELECT LanguageCode
			,Template
			,Subject
			,Content
		FROM T_MST_EmailTemplate WITH(NOLOCK)
		WHERE EmailTemplateID = @TempID
			OR (
				LanguageCode = @Language
				AND Template = @Template
				)
	END
	ELSE
	BEGIN
		SELECT LanguageCode
			,Template
			,Subject
			,Content
		FROM T_MST_EmailTemplate WITH(NOLOCK)
		WHERE EmailTemplateID = @TempID
			OR (
				LanguageCode = 'EN'
				AND Template = @Template
				)
	END
END
GO


