/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_DataCleanupByPlantID]
///AUTHOR                       : KARTHIKEYAN KANDASAMY
///CREATED DATE                 : 25-APR-2021
///SEE ALSO                     : THIS PROCEDURE FOR PLANT WISE DATA CLEAN
///MODIFICATION HISTORY		:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					12-APR-2021			KARTHIKEYAN KANDASAMY		INITIAL VERSION
ELPC_LH_003					26-JUL-2021			VENKATESH GOVINDARAJ		VS & AS PROFILE, CALENDAR RECURSSION CLEANUP SCRIPT ADDED
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_DataCleanupByPlantID] 200,'EGV1COB';
*/
CREATE PROCEDURE [USP_DataCleanupByPlantID] (
	@PlantID INT
	,@CurrentUserNTID NVARCHAR(20)
	)
AS
BEGIN
	BEGIN TRY
		-- START - TagMode
		PRINT ('START - TagMode');

		DELETE
		FROM [T_LNK_TagMode_Tags]
		WHERE TagID IN (
				SELECT TagID
				FROM [T_TRN_Tag]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_LNK_TagMode_Questions]
		WHERE TagModeID IN (
				SELECT TagModeID
				FROM [T_TRN_TagMode]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_TRN_TagMode]
		WHERE PlantID = @PlantID;

		PRINT ('END - TagMode');
		-- END - TagMode
		-- START - CustomMode
		PRINT ('START - CustomMode');

		DELETE
		FROM [T_LNK_Custom_QuestionsTags]
		WHERE CustomModeID IN (
				SELECT CustomModeID
				FROM [T_TRN_CustomMode]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_LNK_Custom_Questions]
		WHERE CustomModeID IN (
				SELECT CustomModeID
				FROM [T_TRN_CustomMode]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_TRN_CustomMode]
		WHERE PlantID = @PlantID;

		PRINT ('END - CustomMode');
		-- END - CustomMode
		-- START - Audit
		PRINT ('START - Audit');

		DELETE
		FROM [T_TRN_Recurrence]
		WHERE AuditID IN (
				SELECT AuditID
				FROM [T_TRN_Audit]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_LNK_Audit_AssignedQuestions]
		WHERE AuditID IN (
				SELECT AuditID
				FROM [T_TRN_Audit]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_LNK_Audit_AnsweredQuestions]
		WHERE AuditID IN (
				SELECT AuditID
				FROM [T_TRN_Audit]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_LNK_AuditTemplate_OtherAssessorDetail]
		WHERE AuditID IN (
				SELECT AuditID
				FROM [T_TRN_Audit]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_LNK_AuditTemplate_AssessorDetail]
		WHERE AuditID IN (
				SELECT AuditID
				FROM [T_TRN_Audit]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_TRN_AuditDeviationAttachments]
		WHERE AuditDeviationID IN (
				SELECT AuditDeviationID
				FROM [T_TRN_AuditDeviation]
				WHERE AuditID IN (
						SELECT AuditID
						FROM [T_TRN_Audit]
						WHERE PlantID = @PlantID
						)
				);

		DELETE
		FROM [T_TRN_AuditDeviation]
		WHERE AuditID IN (
				SELECT AuditID
				FROM [T_TRN_Audit]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_LNK_Audit_OptionalAttendees]
		WHERE AuditID IN (
				SELECT AuditID
				FROM [T_TRN_Audit]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_LNK_Audit_RequiredAttendees]
		WHERE AuditID IN (
				SELECT AuditID
				FROM [T_TRN_Audit]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_LNK_Audit_AssignedTags]
		WHERE AuditID IN (
				SELECT AuditID
				FROM [T_TRN_Audit]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_TRN_AuditAssessor]
		WHERE AuditID IN (
				SELECT AuditID
				FROM [T_TRN_Audit]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_TRN_Audit]
		WHERE PlantID = @PlantID;

		PRINT ('END - Audit');
		-- END - Audit
		-- START - DataPool
		PRINT ('START - DataPool');

		DELETE
		FROM [T_TRN_DataPoolHistory]
		WHERE PlantID = @PlantID;

		DELETE
		FROM [T_TRN_DataPool]
		WHERE PlantID = @PlantID;

		PRINT ('END - DataPool');
		-- END - DataPool
		-- START - Tag
		PRINT ('START - Tag');

		DELETE
		FROM [T_LNK_QN_AssignedTagsHistory]
		WHERE TagID IN (
				SELECT TagID
				FROM [T_TRN_Tag]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_LNK_QN_AssignedTags]
		WHERE TagID IN (
				SELECT TagID
				FROM [T_TRN_Tag]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_LNK_Tag_AssignedQuestionsTagsHistory]
		WHERE TagID IN (
				SELECT TagID
				FROM [T_TRN_Tag]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_LNK_Tag_AssignedQuestionsTags]
		WHERE TagID IN (
				SELECT TagID
				FROM [T_TRN_Tag]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_LNK_Tag_AssignedAssessorsHistory]
		WHERE TagID IN (
				SELECT TagID
				FROM [T_TRN_Tag]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_LNK_Tag_AssignedAssessors]
		WHERE TagID IN (
				SELECT TagID
				FROM [T_TRN_Tag]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_LNK_Tag_AssignedValueStreamsHistory]
		WHERE TagID IN (
				SELECT TagID
				FROM [T_TRN_Tag]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_LNK_Tag_AssignedValueStreams]
		WHERE TagID IN (
				SELECT TagID
				FROM [T_TRN_Tag]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_LNK_Tag_Proxy]
		WHERE TagID IN (
				SELECT TagID
				FROM [T_TRN_Tag]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_TRN_TagHistory]
		WHERE TagID IN (
				SELECT TagID
				FROM [T_TRN_Tag]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_TRN_Tag]
		WHERE PlantID = @PlantID;

		PRINT ('END - Tag');
		-- END - Tag
		-- START - Deviation
		PRINT ('START - Deviation');

		DELETE
		FROM [T_TRN_DeviationAttachments]
		WHERE DeviationID IN (
				SELECT DeviationID
				FROM [T_TRN_Deviation]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_TRN_Deviation]
		WHERE PlantID = @PlantID
		

		PRINT ('END - Deviation');
		-- END - Deviation
		-- START - Question
		PRINT ('START - Question');

		DELETE
		FROM [T_LNK_AssignedAssessorsHistory]
		WHERE QuestionID IN (
				SELECT QuestionID
				FROM [T_TRN_Question]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_LNK_AssignedAssessorsHistory]
		WHERE AssessorID IN (
				SELECT AssessorID
				FROM [T_TRN_AssessorHistory]
				WHERE AssessorTemplateID IN (
						SELECT AssessorTemplateID
						FROM [T_TRN_AssessorTemplateHistory]
						WHERE PlantID = @PlantID
						)
				);

		DELETE
		FROM [T_LNK_AssignedAssessors]
		WHERE QuestionID IN (
				SELECT QuestionID
				FROM [T_TRN_Question]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_LNK_AssignedAssessors]
		WHERE AssessorID IN (
				SELECT AssessorID
				FROM [T_TRN_Assessor]
				WHERE AssessorTemplateID IN (
						SELECT AssessorTemplateID
						FROM [T_TRN_AssessorTemplate]
						WHERE PlantID = @PlantID
						)
				);

		DELETE
		FROM [T_LNK_AssignedValueStreamsHistory]
		WHERE QuestionID IN (
				SELECT QuestionID
				FROM [T_TRN_Question]
				WHERE PlantID = @PlantID
				);
		DELETE
		FROM [T_LNK_AssignedValueStreamsHistory]
		WHERE ValueStreamID IN (
				SELECT ValueStreamID
				FROM [T_TRN_ValueStreamHistory]
				WHERE ValueStreamTemplateID IN (
						SELECT ValueStreamTemplateID
						FROM [T_TRN_ValueStreamTemplate]
						WHERE PlantID = @PlantID
						)
				);

		DELETE
		FROM [T_LNK_AssignedValueStreams]
		WHERE QuestionID IN (
				SELECT QuestionID
				FROM [T_TRN_Question]
				WHERE PlantID = @PlantID
				);
		
		DELETE
		FROM [T_LNK_AssignedValueStreams]
		WHERE ValueStreamID IN (
				SELECT ValueStreamID
				FROM [T_TRN_ValueStream]
				WHERE ValueStreamTemplateID IN (
						SELECT ValueStreamTemplateID
						FROM [T_TRN_ValueStreamTemplate]
						WHERE PlantID = @PlantID
						)
				);

		DELETE
		FROM [T_TRN_HintImageHistory]
		WHERE QuestionID IN (
				SELECT QuestionID
				FROM [T_TRN_Question]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_TRN_HintImage]
		WHERE QuestionID IN (
				SELECT QuestionID
				FROM [T_TRN_Question]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_TRN_HintHyperLinkHistory]
		WHERE QuestionID IN (
				SELECT QuestionID
				FROM [T_TRN_Question]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_TRN_HintHyperLink]
		WHERE QuestionID IN (
				SELECT QuestionID
				FROM [T_TRN_Question]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_TRN_ChoiceHistory]
		WHERE QuestionID IN (
				SELECT QuestionID
				FROM [T_TRN_Question]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_TRN_Choice]
		WHERE QuestionID IN (
				SELECT QuestionID
				FROM [T_TRN_Question]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_TRN_MultipleLinesTextHistory]
		WHERE QuestionID IN (
				SELECT QuestionID
				FROM [T_TRN_Question]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_TRN_MultipleLinesText]
		WHERE QuestionID IN (
				SELECT QuestionID
				FROM [T_TRN_Question]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_TRN_SingleLineTextHistory]
		WHERE QuestionID IN (
				SELECT QuestionID
				FROM [T_TRN_Question]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_TRN_SingleLineText]
		WHERE QuestionID IN (
				SELECT QuestionID
				FROM [T_TRN_Question]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_LNK_Question_Proxy]
		WHERE QuestionID IN (
				SELECT QuestionID
				FROM [T_TRN_Question]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_TRN_QuestionHistory]
		WHERE PlantID = @PlantID;

		DELETE
		FROM [T_TRN_Question]
		WHERE PlantID = @PlantID;

		PRINT ('END - Question');
		-- END - Question
		-- START - Assessor
		PRINT ('START - Assessor');

		DELETE
		FROM [T_LNK_Assessor_ProxyHistory]
		WHERE AssessorTemplateID IN (
				SELECT AssessorTemplateID
				FROM [T_TRN_AssessorTemplate]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_LNK_Assessor_Proxy]
		WHERE AssessorTemplateID IN (
				SELECT AssessorTemplateID
				FROM [T_TRN_AssessorTemplate]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_TRN_AssessorHistory]
		WHERE AssessorTemplateID IN (
				SELECT AssessorTemplateID
				FROM [T_TRN_AssessorTemplate]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_TRN_Assessor]
		WHERE AssessorTemplateID IN (
				SELECT AssessorTemplateID
				FROM [T_TRN_AssessorTemplate]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_TRN_AssessorTemplateHistory]
		WHERE PlantID = @PlantID;

		DELETE
		FROM [T_TRN_AssessorTemplate]
		WHERE PlantID = @PlantID;

		PRINT ('END - Assessor');
		-- END - Assessor
		-- START - ValueStream
		PRINT ('START - ValueStream');

		DELETE
		FROM [T_LNK_ValueStream_Proxy]
		WHERE ValueStreamTemplateID IN (
				SELECT ValueStreamTemplateID
				FROM [T_TRN_ValueStreamTemplate]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_TRN_ValueStreamHistory]
		WHERE ValueStreamTemplateID IN (
				SELECT ValueStreamTemplateID
				FROM [T_TRN_ValueStreamTemplate]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_TRN_ValueStream]
		WHERE ValueStreamTemplateID IN (
				SELECT ValueStreamTemplateID
				FROM [T_TRN_ValueStreamTemplate]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_LNK_ValueStream_ShiftHistory]
		WHERE ValueStreamTemplateID IN (
				SELECT ValueStreamTemplateID
				FROM [T_TRN_ValueStreamTemplate]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_LNK_ValueStream_Shift]
		WHERE ValueStreamTemplateID IN (
				SELECT ValueStreamTemplateID
				FROM [T_TRN_ValueStreamTemplate]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_TRN_ValueStreamCategoryHistory]
		WHERE ValueStreamTemplateID IN (
				SELECT ValueStreamTemplateID
				FROM [T_TRN_ValueStreamTemplate]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_TRN_ValueStreamCategory]
		WHERE ValueStreamTemplateID IN (
				SELECT ValueStreamTemplateID
				FROM [T_TRN_ValueStreamTemplate]
				WHERE PlantID = @PlantID
				);

		DELETE
		FROM [T_HST_ValueStreamTemplateHistory]
		WHERE PlantID = @PlantID;

		DELETE
		FROM [T_TRN_ValueStreamTemplate]
		WHERE PlantID = @PlantID;

		DELETE
		FROM [T_TRN_ValueStreamConfig]
		WHERE PlantID = @PlantID;

		DELETE
		FROM [T_TRN_AssessorConfig]
		WHERE PlantID = @PlantID;

		PRINT ('END - ValueStream');
		-- END - ValueStream

		-- START - LogError
		PRINT ('START - LogError');

		DELETE
		FROM [T_TRN_LogError]
		WHERE PlantID = @PlantID;

		PRINT ('END - LogError');

		INSERT [T_TRN_LogError] (
			PlantID
			,ErrorNumber
			,ErrorSeverity
			,ErrorState
			,ErrorProcedure
			,ErrorLine
			,ErrorMessage
			,CreatedOn
			,CreatedBy
			)
		VALUES (
			@PlantID
			,NULL
			,NULL
			,NULL
			,NULL
			,NULL
			,'PLANT DATA CLEANUP'
			,(
				SELECT FormattedDateTime
				FROM [fnGetDateTime](@PlantID)
				)
			,@CurrentUserNTID
			);
			-- END - LogError
	END TRY

	BEGIN CATCH
		EXEC [USP_LogError] @PlantID
			,@CurrentUserNTID;

		SELECT ERROR_NUMBER() AS ErrorNumber
			,ERROR_MESSAGE() AS ErrorMessage;
	END CATCH
END
GO