/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_SetScheduleCompleted]
///AUTHOR                       : KARTHIKEYAN KANDASAMY
///CREATED DATE                 : 01-OCT-2021  
///SEE ALSO                     : THIS PROCEDURE FOR UPDATE RETRY COMPLETED FOR SUPER-OPL CREATION ENTRY
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_002					01-OCT-2021			KARTHIKEYAN KANDASAMY		INITIAL VERSION
ELPC_LH_002					13-OCT-2021			KARTHIKEYAN KANDASAMY		ADDED MAXEXECUTIONCOUNT

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_SetScheduleCompleted] 1,1,''
*/
CREATE PROCEDURE [USP_SetScheduleCompleted]
(
	@ScheduleId INT,
	@MaxExecutionCount INT,
	@ModifiedBy_NTID NVARCHAR(20)
)
AS BEGIN
	SET LOCK_TIMEOUT 5000;

	IF (EXISTS(SELECT * FROM [T_TRN_Scheduler] WHERE [ScheduleId] = @ScheduleId AND [IsDeleted] = 0 AND [IsCompleted] = 0 AND ([MaxExecutionCount] IS NULL OR [MaxExecutionCount] = -1)) 
				AND @MaxExecutionCount > 0)
	BEGIN
		UPDATE [T_TRN_Scheduler] SET [MaxExecutionCount] = @MaxExecutionCount 
			WHERE [ScheduleId] = @ScheduleId AND [IsDeleted] = 0 AND [IsCompleted] = 0;
	END

	UPDATE [T_TRN_Scheduler]  SET [IsCompleted] = 1, [ExecutionCount] = ([ExecutionCount]+1), [LastRunAt] = GETDATE(), [ModifiedAt] = GETDATE()
		WHERE [ScheduleId] = @ScheduleId AND [IsDeleted] = 0 AND [IsCompleted] = 0;
END
GO