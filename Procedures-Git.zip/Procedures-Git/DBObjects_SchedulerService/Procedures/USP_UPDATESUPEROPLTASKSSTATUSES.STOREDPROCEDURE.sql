/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_UpdateSuperOPLTasksStatuses]
///AUTHOR                       : KARTHIKEYAN KANDASAMY
///CREATED DATE                 : 15-NOV-2021  
///SEE ALSO                     : THIS PROCEDURE TO UPDATE ALL SUPER-OPL NON-COMPLETED TASK STATUSES
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					15-NOV-2021			KARTHIKEYAN KANDASAMY		INITIAL VERSION
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_UpdateSuperOPLTasksStatuses] 1, N'[{"taskId":5003670, "statusId":1}]'
*/
CREATE PROCEDURE [USP_UpdateSuperOPLTasksStatuses]
(
	@PlantId INT,
	@TaskStatuses NVARCHAR(MAX)
)
AS BEGIN
	SET LOCK_TIMEOUT 5000;

	BEGIN TRY
		IF(ISJSON(@TaskStatuses)<>1)
		BEGIN
			RAISERROR('Error in JSON format', 16, 1);
		END
		
		BEGIN TRAN

		MERGE [T_TRN_Deviation] AS SuperOPLTask
		USING (SELECT * FROM OPENJSON (@TaskStatuses)  
				WITH (
					taskId   INT	'$.taskId',
					statusId INT	'$.statusId'
					)
				) AS NewTaskStatus
		ON SuperOPLTask.SuperOPLTaskID = NewTaskStatus.taskId AND SuperOPLTask.PlantID = @PlantId
		WHEN MATCHED THEN
			UPDATE SET SuperOPLTask.SuperOPLStatus = NewTaskStatus.statusId;


		COMMIT TRAN;
	END TRY
	BEGIN CATCH
		-- Transaction uncommittable State
		IF (XACT_STATE()) = -1
			ROLLBACK TRAN
 
		-- Transaction committable State
		IF (XACT_STATE()) = 1
			ROLLBACK TRAN

		DECLARE @ErrorMessage NVARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState INT;  
  
		SELECT   
			@ErrorMessage = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState = ERROR_STATE();  
  
		-- Use RAISERROR inside the CATCH block to return error  
		-- information about the original error that caused  
		-- execution to jump to the CATCH block.  
		RAISERROR (@ErrorMessage, -- Message text.  
				   @ErrorSeverity, -- Severity.  
				   @ErrorState -- State.  
				   ); 
	END CATCH
END
GO