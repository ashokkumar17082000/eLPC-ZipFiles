/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_AddSchedule]
///AUTHOR                       : KARTHIKEYAN KANDASAMY
///CREATED DATE                 : 01-OCT-2021  
///SEE ALSO                     : THIS PROCEDURE FOR ADD FAILED SUPER-OPL CREATION ENTRIES
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_002					01-OCT-2021			KARTHIKEYAN KANDASAMY		INITIAL VERSION

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_AddSchedule] 1,'SuperOPL','','',''
*/
CREATE PROCEDURE [USP_AddSchedule]
(
	@PlantId INT,
	@ScheduleName NVARCHAR(250),
	@DataObj NVARCHAR(MAX) NULL,
	@ErrorDetail NVARCHAR(MAX) NULL,	
	@CreatedBy_NTID NVARCHAR(20)
)
AS BEGIN
	SET LOCK_TIMEOUT 5000;

	INSERT INTO [T_TRN_Scheduler] (
						[PlantId],
						[ScheduleName],
						[DataObj],
						[ErrorDetail],
						[CreatedAt],
						[CreatedBy_NTID])
	VALUES
			(@PlantId,
			@ScheduleName,
			@DataObj,
			@ErrorDetail,
			GETDATE(),
			@CreatedBy_NTID);

	SELECT SCOPE_IDENTITY() AS ScheduleId;
END
GO
