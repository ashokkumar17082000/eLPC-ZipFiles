/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_GetAllSuperOPLStatusPendingTasks]
///AUTHOR                       : KARTHIKEYAN KANDASAMY
///CREATED DATE                 : 15-NOV-2021  
///SEE ALSO                     : THIS PROCEDURE TO GET ALL SUPER-OPL NON-COMPLETED TASKS
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					15-NOV-2021			KARTHIKEYAN KANDASAMY		INITIAL VERSION
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_GetAllSuperOPLStatusPendingTasks] 1
*/
CREATE PROCEDURE [USP_GetAllSuperOPLStatusPendingTasks]
(
	@PlantId INT
)
AS BEGIN
	SET LOCK_TIMEOUT 5000;

	SELECT SuperOPLTaskID FROM [T_TRN_Deviation] WITH(NOLOCK)
	WHERE PlantID = @PlantId 
		AND SuperOPLTaskID IS NOT NULL
		AND (SuperOPLStatus IS NULL OR SuperOPLStatus NOT IN (1,4));

	--	Except 1=>Closed, 4=>Closed Overdue
END
GO