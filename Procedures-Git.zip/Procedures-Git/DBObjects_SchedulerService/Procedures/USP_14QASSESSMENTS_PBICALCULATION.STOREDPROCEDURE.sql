/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_14QAssessments_PBICalculation]
///AUTHOR                       : VENKATESH GOVINDARAJ
///CREATED DATE                 : 15-FEB-2022
///SEE ALSO                     : THIS PROCEDURE TO UPDATE ALL 14Q ASSESSMENT POWERBI TABLE
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					15-FEB-2022			VENKATESH GOVINDARAJ		INITIAL VERSION
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_14QAssessments_PBICalculation]
*/
CREATE PROCEDURE [USP_14QAssessments_PBICalculation]
AS

BEGIN

DROP TABLE IF EXISTS #tmp1
DROP TABLE IF EXISTS #tmp2
DROP TABLE IF EXISTS #tmp3
DROP TABLE IF EXISTS #tmp_datapool

DELETE T_PBI_14QAssessment   ----final values from this table reflected to dashboard

----------------------------------------Filtering child ids for a particular principles and considering for max timestamp-------------------------------------------------

;with cte3 as(
select DataPoolID
,PlantID
,DataPoolDisplayID
,TimeStamp
,ValueStreamID
,AssessorID
,QuestionID
,Answer
,answerType_AnswerTypeID
,CreatedAt
,AnsweredBy_NTID
,ModifiedAt
,ModifiedBy_NTID
,(select top 1 tagid from T_LNK_Tag_AssignedQuestionsTags WITH (NOLOCK) 
 where questionid=dp.questionid and  isdeleted=0
 and tagid in ( select tagid from T_TRN_Tag WITH (NOLOCK) where TagName in ( select Tagname from T_MST_PRINCIPLENAMES WITH (NOLOCK) ) )) as Tagid 
,IsDeviation
,IsAnswered
,ObtainedScore
,ChoiceID
,DeviationID
,AuditID
,AuditTemplateID
,IsShowVsAs
,IsDeleted
,SessionID from T_TRN_Datapool dp WITH (NOLOCK) where tagid > 0)

select * into #tmp_datapool from cte3 where Tagid is not null

;with cte as(
select PlantID,ValueStreamID,tagid,ChoiceID,max([TimeStamp]) as [timestamp] 
from #tmp_datapool
group by PlantID,ValueStreamID,Tagid,ChoiceID
)
select * into #tmp3 from cte


----------------------------------------------Check if a tag is +ve or -ve and assign 1 or 0--------------------------------------------------------------------
;with cte4 as(
select dp.ValueStreamID, dp.tagid,tg.tagname, case when count(distinct(tg.tagid))<>1 and answercategory='negative'  then 0 when count(distinct(tg.tagid))=1 
and answercategory='negative' then 0 when count(distinct(tg.tagid))=1 and answercategory='positive' then 1 when answercategory='neutral' then 1  end as score
from #tmp3 dp
inner join T_TRN_Tag tg WITH (NOLOCK) on tg.tagid=dp.tagid
inner join T_TRN_Choice CH WITH (NOLOCK) on DP.ChoiceID=CH.ChoiceID 
--WHERE DP.PlantID =1 
group by dp.Valuestreamid,dp.tagid,tagname,ch.answercategory,valuestreamid
)
select * into #tmp1 from cte4

;WITH CTE1 AS(
select t.ValueStreamID,t.TagID,t.TagName,min(score) as final_score
from #tmp1 t
group by t.ValueStreamID,t.TagID,t.TagName 
),

CTE2 AS(
select  VST.ValueStreamTemplateName,VS.ValueStreamID,VS.ValueStreamName 
,cte1.tagname,final_score,PrincipleDisplayName,OrderBY
from cte1 
INNER JOIN T_TRN_ValueStream vs WITH (NOLOCK) on cte1.ValueStreamID=vs.ValueStreamID
inner JOIN T_TRN_ValueStreamTemplate vst WITH (NOLOCK) on  VS.ValueStreamTemplateID = VST.ValueStreamTemplateID
INNER JOIN T_MST_PRINCIPLENAMES PN WITH (NOLOCK) ON PN.TAGNAME=cte1.TAGNAME
)

select * into #tmp2 from CTE2

-------------------------------------------------------------Principle Score Calculation----------------------------------------------------------------------------
declare @vs nvarchar(100)
declare @pd nvarchar(5)

DECLARE @P INT=1;
WHILE @P<=14
BEGIN

set @pd=CONCAT('P',@P)

declare cur cursor scroll for 

select distinct ValueStreamID from #tmp2
where PrincipleDisplayName=@pd
order by Valuestreamid--, orderby

open cur
fetch next from cur into @vs

while @@FETCH_STATUS=0

begin

declare @ordby int;
declare @fscore int;
declare @final int;

	select @ordby=count(distinct(OrderBy)) from #tmp2 where ValueStreamId=@vs
	and PrincipleDisplayName=@pd

	if (@ordby=3)
		begin
		insert into T_PBI_14QAssessment
			select distinct(#tmp2.valuestreamid), case when (select sum(final_score) from  #tmp2 where ValueStreamId=@vs and PrincipleDisplayName=@pd)=3 then 3 
			else  (select min(orderby)-1 from #tmp2 where final_score=0 and ValueStreamId=@vs and PrincipleDisplayName=@pd) end as FINAL,PrincipleDisplayName,VST.PlantID
			,VST.ValueStreamTemplateName,VS.ValueStreamName, GETDATE()
			from #tmp2 inner join T_TRN_ValueStream VS WITH(NOLOCK) on VS.ValueStreamID=#tmp2.ValueStreamID
			inner join T_TRN_ValueStreamTemplate VST WITH(NOLOCK) ON VST.ValueStreamTemplateID = VS.ValueStreamTemplateID			
			where #tmp2.ValueStreamId=@vs and PrincipleDisplayName=@pd
		end

	if (@ordby<>3)
		begin
		INSERT INTO T_PBI_14QAssessment
			select distinct(#tmp2.valuestreamid),	case when (select min(orderby) from #tmp2 where ValueStreamId=@vs and PrincipleDisplayName=@pd)<>1 then 0
			when (select min(orderby) from #tmp2 where ValueStreamId=@vs and PrincipleDisplayName=@pd)=1 and  
			(select orderby from #tmp2 where ValueStreamId=@vs and PrincipleDisplayName=@pd AND ORDERBY=3)=3 then 
			(select final_score from #tmp2 where ValueStreamId=@vs and PrincipleDisplayName=@pd and orderby=1)
		     when (select min(orderby) from #tmp2 where ValueStreamId=@vs and PrincipleDisplayName=@pd)=1 and  
			(select orderby from #tmp2 where ValueStreamId=@vs and PrincipleDisplayName=@pd AND ORDERBY=2)=2 and
			(select final_score from #tmp2 where ValueStreamId=@vs and PrincipleDisplayName=@pd and orderby=1)=0 then 0
			when (select min(orderby) from #tmp2 where ValueStreamId=@vs and PrincipleDisplayName=@pd)=1 and  
			(select orderby from #tmp2 where ValueStreamId=@vs and PrincipleDisplayName=@pd AND ORDERBY=2)=2 and
			(select final_score from #tmp2 where ValueStreamId=@vs and PrincipleDisplayName=@pd and orderby=1)<>0 and
			(select final_score from #tmp2 where ValueStreamId=@vs and PrincipleDisplayName=@pd and orderby=2)=0 then 
			(select final_score from #tmp2 where ValueStreamId=@vs and PrincipleDisplayName=@pd and orderby=1) 
			when (select min(orderby) from #tmp2 where ValueStreamId=@vs and PrincipleDisplayName=@pd)=1 and  
			(select orderby from #tmp2 where ValueStreamId=@vs and PrincipleDisplayName=@pd AND ORDERBY=2)=2 and
			(select final_score from #tmp2 where ValueStreamId=@vs and PrincipleDisplayName=@pd and orderby=1)<>0 and
			(select final_score from #tmp2 where ValueStreamId=@vs and PrincipleDisplayName=@pd and orderby=2)=1 then 2
			when (select orderby from #tmp2 where ValueStreamId=@vs and PrincipleDisplayName=@pd and orderby=1)=1 then
			(select final_score from #tmp2 where ValueStreamId=@vs and PrincipleDisplayName=@pd and orderby=1) end as FINAL ,PrincipleDisplayName,VST.PlantID
			,VST.ValueStreamTemplateName,VS.ValueStreamName, GETDATE()
			from #tmp2 inner join T_TRN_ValueStream VS WITH(NOLOCK) on VS.ValueStreamID=#tmp2.ValueStreamID
			inner join T_TRN_ValueStreamTemplate VST WITH(NOLOCK) ON VST.ValueStreamTemplateID = VS.ValueStreamTemplateID			
			where #tmp2.ValueStreamId=@vs and PrincipleDisplayName=@pd
			
			
	end

fetch next from cur into @vs

end
close cur 
deallocate cur

SET @P=@P+1;
END

drop table #tmp1
drop table #tmp2
drop table #tmp3
drop table #tmp_datapool

end
GO