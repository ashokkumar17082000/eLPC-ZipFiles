/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_GetAllActiveSchedules]
///AUTHOR                       : KARTHIKEYAN KANDASAMY
///CREATED DATE                 : 01-OCT-2021  
///SEE ALSO                     : THIS PROCEDURE TO GET ALL FAILED SUPER-OPL ENTRIES TO RETRY
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_002					01-OCT-2021			KARTHIKEYAN KANDASAMY		INITIAL VERSION
ELPC_LH_002					13-OCT-2021			KARTHIKEYAN KANDASAMY		ADDED MAXEXECUTIONCOUNT CHECK

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_GetAllActiveSchedules]
*/
CREATE PROCEDURE [USP_GetAllActiveSchedules]
	@OnlyMaxExecuted BIT = NULL
AS BEGIN
	SET LOCK_TIMEOUT 5000;

	SELECT * FROM [T_TRN_Scheduler] 
		WHERE [IsDeleted] = 0 
				AND [IsCompleted] = 0
				AND 
				(
					(@OnlyMaxExecuted = 1 AND ([ExecutionCount] = [MaxExecutionCount]))
					OR
					(@OnlyMaxExecuted IS NULL AND ([MaxExecutionCount] = -1 OR [ExecutionCount] < [MaxExecutionCount]))
				);
END
GO