/*  
///<SUMMARY>  
///DESCRIPTION                  : TABLE - [T_MST_QuarantineStores]
///AUTHOR                       : VENKATESH GOVINDARAJ
///CREATED DATE                 : 15-FEB-2022  
///SEE ALSO                     : THIS TABLE USED TO FOR POWERBI REPORTS
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					15-FEB-2022			VENKATESH GOVINDARAJ		INITIAL VERSION
************************************************************************************************************
--SAMPLE EXECUTION
SELECT * FROM [T_MST_QuarantineStores] WITH (NOLOCK) 
*/

CREATE TABLE [T_MST_QuarantineStores](
	[TagName] [nvarchar](255) NULL,
	[OrderBy] [float] NULL,
	[Color Code] [nvarchar](255) NULL
) ON [PRIMARY]
GO

--MASTER DATA
/*
INSERT [T_MST_QuarantineStores] ([TagName], [OrderBy], [Color Code]) VALUES (N'Quarantine-Stores-Max_Storage_Time', 11, N'#b90276')
GO
INSERT [T_MST_QuarantineStores] ([TagName], [OrderBy], [Color Code]) VALUES (N'Quarantine-Stores-SAP', 10, N'#50237f')
GO
INSERT [T_MST_QuarantineStores] ([TagName], [OrderBy], [Color Code]) VALUES (N'Quarantine-Stores-Engineering_change_level', 9, N'#006249')
GO
INSERT [T_MST_QuarantineStores] ([TagName], [OrderBy], [Color Code]) VALUES (N'Quarantine-Stores-Four-Eyes_Principle', 8, N'#78be20')
GO
INSERT [T_MST_QuarantineStores] ([TagName], [OrderBy], [Color Code]) VALUES (N'Quarantine-Stores-Monitoring', 7, N'#00a8b0')
GO
INSERT [T_MST_QuarantineStores] ([TagName], [OrderBy], [Color Code]) VALUES (N'Quarantine-Stores-Planed_Unloading_Date', 6, N'#008ecf')
GO
INSERT [T_MST_QuarantineStores] ([TagName], [OrderBy], [Color Code]) VALUES (N'Quarantine-Stores-Inventory_List', 5, N'#005691')
GO
INSERT [T_MST_QuarantineStores] ([TagName], [OrderBy], [Color Code]) VALUES (N'Quarantine-Stores-Documents', 4, N'#ea0016')
GO
INSERT [T_MST_QuarantineStores] ([TagName], [OrderBy], [Color Code]) VALUES (N'Quarantine-Stores-Labeling', 3, N'#b90276')
GO
INSERT [T_MST_QuarantineStores] ([TagName], [OrderBy], [Color Code]) VALUES (N'Quarantine-Stores-Quarantine_Store_Identification', 2, N'#50237f')
GO
INSERT [T_MST_QuarantineStores] ([TagName], [OrderBy], [Color Code]) VALUES (N'Quarantine-Stores-Storage_Conditions', 1, N'#006249')
GO
INSERT [T_MST_QuarantineStores] ([TagName], [OrderBy], [Color Code]) VALUES (N'Quarantine-Stores-Nr_of_Storage_Positions', 0, N'none')
GO
INSERT [T_MST_QuarantineStores] ([TagName], [OrderBy], [Color Code]) VALUES (N'Quarantine-Stores-Remarks', -1, N'none')
GO
*/