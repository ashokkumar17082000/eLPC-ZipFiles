
/*  
///<SUMMARY>  
///DESCRIPTION                  : TABLE - [T_TRN_Scheduler]
///AUTHOR                       : KARTHIKEYAN KANDASAMY
///CREATED DATE                 : 01-OCT-2021  
///SEE ALSO                     : THIS TABLE USED TO STORE FAILED SUPER-OPL CREATION ENTRIES
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_002					01-OCT-2021			KARTHIKEYAN KANDASAMY		INITIAL VERSION
ELPC_LH_002					13-OCT-2021			KARTHIKEYAN KANDASAMY		ADDED RECENTERRORDETAIL AND MAXEXECUTIONCOUNT
************************************************************************************************************
--SAMPLE EXECUTION
SELECT * FROM [T_TRN_Scheduler] WITH (NOLOCK) 
*/
CREATE TABLE [T_TRN_Scheduler]
(
	[ScheduleId] [INT] IDENTITY(1,1) NOT NULL PRIMARY KEY
	,[PlantId] [INT] NOT NULL
	,[ScheduleName] NVARCHAR(250) NOT NULL
	,[DataObj] [NVARCHAR](MAX) NULL
	,[ExecutionCount] [INT] NOT NULL DEFAULT(0)
	,[MaxExecutionCount] [INT] NOT NULL DEFAULT(-1)
	,[IsCompleted] [BIT] NOT NULL DEFAULT(0)
	,[LastRunAt] [DATETIME] NULL
	,[ErrorDetail] [NVARCHAR](MAX) NULL
	,[RecentErrorDetail] [NVARCHAR](MAX) NULL
	,[CreatedAt] [DATETIME] NOT NULL DEFAULT(GETDATE())
	,[ModifiedAt] [DATETIME] NULL DEFAULT(GETDATE())
	,[IsDeleted] [BIT] NOT NULL DEFAULT(0)
	,[CreatedBy_NTID] [NVARCHAR](20) NOT NULL
	,[ModifiedBy_NTID] [NVARCHAR](20) NULL
);
GO
