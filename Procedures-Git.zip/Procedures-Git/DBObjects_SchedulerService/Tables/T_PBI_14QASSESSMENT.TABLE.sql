/*  
///<SUMMARY>  
///DESCRIPTION                  : TABLE - [T_PBI_14QAssessment]
///AUTHOR                       : VENKATESH GOVINDARAJ
///CREATED DATE                 : 15-FEB-2022  
///SEE ALSO                     : THIS TABLE USED TO STORE FAILED SUPER-OPL CREATION ENTRIES
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					15-FEB-2022			VENKATESH GOVINDARAJ		INITIAL VERSION
************************************************************************************************************
--SAMPLE EXECUTION
SELECT * FROM [T_PBI_14QAssessment] WITH (NOLOCK) 
*/
CREATE TABLE [T_PBI_14QAssessment](
	[Valuestreamid] [nvarchar](100) NULL,
	[Final] [int] NULL,
	[PRINCIPLE] [nvarchar](5) NULL,
	[PlantID] [int] NULL,
	[ValueStreamTemplateName] [nvarchar](max) NULL,
	[ValueStreamName] [nvarchar](max) NULL,
	[CreatedAt] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [T_PBI_14QAssessment] ADD  DEFAULT (getdate()) FOR [CreatedAt]
GO