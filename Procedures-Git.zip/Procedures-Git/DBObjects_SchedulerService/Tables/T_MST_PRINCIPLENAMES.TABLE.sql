/*  
///<SUMMARY>  
///DESCRIPTION                  : TABLE - [T_MST_Principlenames]
///AUTHOR                       : VENKATESH GOVINDARAJ
///CREATED DATE                 : 15-FEB-2022  
///SEE ALSO                     : THIS TABLE USED TO FOR POWERBI REPORTS
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					15-FEB-2022			VENKATESH GOVINDARAJ		INITIAL VERSION
************************************************************************************************************
--SAMPLE EXECUTION
SELECT * FROM [T_MST_Principlenames] WITH (NOLOCK) 
*/
CREATE TABLE [T_MST_Principlenames](
	[ID] [int] NULL,
	[PrincipleDisplayName] [nvarchar](5) NULL,
	[TagName] [nvarchar](100) NULL,
	[OrderBY] [int] NULL
) ON [PRIMARY]
GO

--MASTER DATA
/*
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (1, N'P1', N'14Q-Assessment-P01-L1', 1)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (2, N'P1', N'14Q-Assessment-P01-L2', 2)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (3, N'P1', N'14Q-Assessment-P01-L3', 3)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (4, N'P2', N'14Q-Assessment-P02-L1', 1)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (5, N'P2', N'14Q-Assessment-P02-L2', 2)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (6, N'P2', N'14Q-Assessment-P02-L3', 3)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (7, N'P3', N'14Q-Assessment-P03-L1', 1)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (8, N'P3', N'14Q-Assessment-P03-L2', 2)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (9, N'P3', N'14Q-Assessment-P03-L3', 3)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (10, N'P4', N'14Q-Assessment-P04-L1', 1)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (11, N'P4', N'14Q-Assessment-P04-L2', 2)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (12, N'P4', N'14Q-Assessment-P04-L3', 3)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (13, N'P5', N'14Q-Assessment-P05-L1', 1)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (14, N'P5', N'14Q-Assessment-P05-L2', 2)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (15, N'P5', N'14Q-Assessment-P05-L3', 3)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (16, N'P6', N'14Q-Assessment-P06-L1', 1)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (17, N'P6', N'14Q-Assessment-P06-L2', 2)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (18, N'P6', N'14Q-Assessment-P06-L3', 3)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (19, N'P7', N'14Q-Assessment-P07-L1', 1)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (20, N'P7', N'14Q-Assessment-P07-L2', 2)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (21, N'P7', N'14Q-Assessment-P07-L3', 3)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (22, N'P8', N'14Q-Assessment-P08-L1', 1)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (23, N'P8', N'14Q-Assessment-P08-L2', 2)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (24, N'P8', N'14Q-Assessment-P08-L3', 3)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (25, N'P9', N'14Q-Assessment-P09-L1', 1)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (26, N'P9', N'14Q-Assessment-P09-L2', 2)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (27, N'P9', N'14Q-Assessment-P09-L3', 3)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (28, N'P10', N'14Q-Assessment-P10-L1', 1)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (29, N'P10', N'14Q-Assessment-P10-L2', 2)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (30, N'P10', N'14Q-Assessment-P10-L3', 3)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (31, N'P11', N'14Q-Assessment-P11-L1', 1)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (32, N'P11', N'14Q-Assessment-P11-L2', 2)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (33, N'P11', N'14Q-Assessment-P11-L3', 3)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (34, N'P12', N'14Q-Assessment-P12-L1', 1)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (35, N'P12', N'14Q-Assessment-P12-L2', 2)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (36, N'P12', N'14Q-Assessment-P12-L3', 3)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (37, N'P13', N'14Q-Assessment-P13-L1', 1)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (38, N'P13', N'14Q-Assessment-P13-L2', 2)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (39, N'P13', N'14Q-Assessment-P13-L3', 3)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (40, N'P14', N'14Q-Assessment-P14-L1', 1)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (41, N'P14', N'14Q-Assessment-P14-L2', 2)
GO
INSERT [T_MST_Principlenames] ([ID], [PrincipleDisplayName], [TagName], [OrderBY]) VALUES (42, N'P14', N'14Q-Assessment-P14-L3', 3)
GO
*/