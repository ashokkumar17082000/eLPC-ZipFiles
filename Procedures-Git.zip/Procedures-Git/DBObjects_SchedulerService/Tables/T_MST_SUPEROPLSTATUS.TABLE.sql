/*  
///<SUMMARY>  
///DESCRIPTION                  : TABLE - [T_MST_SuperOPLStatus]
///AUTHOR                       : VENKATESH GOVINDARAJ
///CREATED DATE                 : 15-FEB-2022  
///SEE ALSO                     : THIS TABLE USED TO FOR POWERBI REPORTS
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					15-FEB-2022			VENKATESH GOVINDARAJ		INITIAL VERSION
************************************************************************************************************
--SAMPLE EXECUTION
SELECT * FROM [T_MST_SuperOPLStatus] WITH (NOLOCK) 
*/
CREATE TABLE [T_MST_SuperOPLStatus](
	[StatusID] [int] NOT NULL,
	[Status] [nvarchar](100) NOT NULL,
	[Remarks] [nvarchar](200) NULL,
	[CreatedAt] [datetime] NOT NULL,
	[IsDeleted] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[StatusID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 95, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

--MASTER DATA
/*
INSERT [T_MST_SuperOPLStatus] ([StatusID], [Status], [Remarks], [CreatedAt], [IsDeleted]) VALUES (1, N'Closed', N'Closed, within due date ( Closing date <= Due date)', CAST(N'2021-11-11T11:30:34.663' AS DateTime), 0)
GO
INSERT [T_MST_SuperOPLStatus] ([StatusID], [Status], [Remarks], [CreatedAt], [IsDeleted]) VALUES (2, N'Open', N'Open, within due date ( Closing date = null && TODAY() <= Due date)', CAST(N'2021-11-11T11:30:34.647' AS DateTime), 0)
GO
INSERT [T_MST_SuperOPLStatus] ([StatusID], [Status], [Remarks], [CreatedAt], [IsDeleted]) VALUES (3, N'Overdue', N'Open, overdue ( Closing date = null && TODAY() > Due date)', CAST(N'2021-11-11T11:30:34.663' AS DateTime), 0)
GO
INSERT [T_MST_SuperOPLStatus] ([StatusID], [Status], [Remarks], [CreatedAt], [IsDeleted]) VALUES (4, N'Closed Overdue', N'Closed after due date ( Closing date > Due date)', CAST(N'2021-11-11T11:30:34.663' AS DateTime), 0)
GO
INSERT [T_MST_SuperOPLStatus] ([StatusID], [Status], [Remarks], [CreatedAt], [IsDeleted]) VALUES (5, N'Awaiting manager validation', N'Awaiting manager validation ( SEL1 name = null ) --> what if the manager check is set to "No" ? Does the Task have to be closed?', CAST(N'2021-11-11T11:30:34.663' AS DateTime), 0)
GO
*/
