SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_HST_ValueStreamTemplateHistory](
	[ValueStreamTemplateHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[PlantID] [int] NOT NULL,
	[ValueStreamTemplateID] [int] NOT NULL,
	[ValueStreamTemplateDisplayID] [int] NULL,
	[ValueStreamTemplateHistoryDisplayID] [int] NULL,
	[ValueStreamTemplateName] [nvarchar](50) NULL,
	[IsLocked] [bit] NULL,
	[Delimiter] [nvarchar](5) NULL,
	[IsOperatedInShifts] [bit] NULL,
	[VisualizationViewModeID] [int] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[CreatedAt] [datetime] NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[ModifiedAt] [datetime] NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	[ActionType] [varchar](1) NULL,
	[ActionDate] [datetime] NULL,
 CONSTRAINT [PK_T_HST_ValueStreamTemplateHistory] PRIMARY KEY CLUSTERED 
(
	[ValueStreamTemplateHistoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_Assessor_Proxy](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[AssessorTemplateID] [int] NULL,
	[Proxy] [nvarchar](20) NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[CreatedAt] [datetime] NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[ModifiedAt] [datetime] NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_Assessor_ProxyHistory](
	[AssessorProxyHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[ID] [int] NULL,
	[AssessorTemplateID] [int] NULL,
	[Proxy] [nvarchar](20) NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[CreatedAt] [datetime] NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[ModifiedAt] [datetime] NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	[ActionType] [varchar](1) NULL,
	[ActionDate] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[AssessorProxyHistoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_AssignedAssessors](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[AssessorID] [int] NULL,
	[QuestionID] [int] NULL,
	[TargetFrequencyValue] [nvarchar](50) NULL,
	[TargetFrequencyTypeID] [int] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0))
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_AssignedAssessorsHistory](
	[AssignedAssessorsHistory] [int] IDENTITY(1,1) NOT NULL,
	[QuestionHistoryID] [int] NOT NULL,
	[ID] [int] NOT NULL,
	[AssessorID] [int] NULL,
	[QuestionID] [int] NULL,
	[TargetFrequencyValue] [nvarchar](50) NULL,
	[TargetFrequencyTypeID] [int] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[ActionType] [varchar](1) NULL,
	[ActionDate] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[AssignedAssessorsHistory] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_AssignedTargetFrequency](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[QuestionID] [int] NULL,
	[TargetFrequencyValue] [nvarchar](50) NULL,
	[TargetFrequencyTypeID] [int] NULL,
	[IsDeleted] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_AssignedTargetFrequencyHistory](
	[AssignedTargetFrequencyHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[QuestionHistoryID] [int] NOT NULL,
	[ID] [int] NOT NULL,
	[QuestionID] [int] NULL,
	[TargetFrequencyValue] [nvarchar](50) NULL,
	[TargetFrequencyTypeID] [int] NULL,
	[IsDeleted] [bit] NULL,
	[ActionType] [varchar](1) NULL,
	[ActionDate] [datetime] NULL
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_AssignedValueStreams](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ValueStreamID] [int] NULL,
	[QuestionID] [int] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_AssignedValueStreamsHistory](
	[AssignedValueStreamsHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[QuestionHistoryID] [int] NOT NULL,
	[ID] [int] NOT NULL,
	[ValueStreamID] [int] NULL,
	[QuestionID] [int] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[ActionType] [varchar](1) NULL,
	[ActionDate] [datetime] NULL
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_Audit_AnsweredQuestions](
	[AuditAnsweredQuestionID] [int] IDENTITY(1,1) NOT NULL,
	[AuditID] [int] NULL,
	[QuestionID] [int] NULL,
	[CreatedAt] [datetime] NULL,
	[ModifiedAt] [datetime] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[AnswerTypeID] [int] NULL,
	[IsAnswered] [bit] NULL,
	[Answer] [nvarchar](max) NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	[IsAuditCompleted] [bit] NULL,
	[IsAnswerRequired] [bit] NULL,
	[AuditTemplateID] [int] NULL,
	[ID] [int] NULL,
	[IsAuditActive] [bit] NULL DEFAULT ((1))
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_Audit_AssignedQuestions](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[AuditID] [int] NULL,
	[QuestionID] [int] NULL,
	[AnswerTypeID] [int] NULL,
	[Answer] [nvarchar](max) NULL,
	[IsAnswered] [bit] NULL,
	[IsAnswerRequired] [bit] NULL,
	[CreatedAt] [datetime] NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[ModifiedAt] [datetime] NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_Audit_AssignedTags](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[AuditID] [int] NULL,
	[TagID] [int] NULL,
	[CreatedAt] [datetime] NULL,
	[ModifiedAt] [datetime] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_Audit_OptionalAttendees](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[AuditID] [int] NULL,
	[UserID] [int] NULL,
	[CreatedAt] [datetime] NULL,
	[ModifiedAt] [datetime] NULL,
	[NTID] [nvarchar](20) NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_Audit_RequiredAttendees](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[AuditID] [int] NULL,
	[UserID] [int] NULL,
	[CreatedAt] [datetime] NULL,
	[ModifiedAt] [datetime] NULL,
	[NTID] [nvarchar](20) NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_AuditTemplate_AssessorDetail](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[AssessorName] [nvarchar](100) NULL,
	[UserName] [nvarchar](200) NULL,
	[NTID] [nvarchar](20) NULL,
	[IsMandatoryAssessor] [bit] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[AuditID] [int] NULL,
	[AuditTemplateID] [int] NULL,
 CONSTRAINT [PK_T_LNK_AuditTemplate_AssessorDetail] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_AuditTemplate_OtherAssessorDetail](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[AssessorName] [nvarchar](100) NULL,
	[UserName] [nvarchar](200) NULL,
	[NTID] [nvarchar](20) NULL,
	[IsDeleted] [bit] NULL,
	[AuditID] [int] NULL,
	[AuditTemplateID] [int] NULL,
 CONSTRAINT [PK_T_LNK_AuditTemplate_OtherAssessorDetail] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_Custom_Questions](
	[CustomQuestionID] [int] IDENTITY(1,1) NOT NULL,
	[CustomModeID] [int] NULL,
	[QuestionID] [int] NULL,
	[CustomQuestionTagsID] [int] NULL,
	[AnswerTypeID] [int] NULL,
	[IsCustomMode] [bit] NOT NULL DEFAULT ((0)),
	[Answer] [nvarchar](max) NULL,
	[IsAnswered] [bit] NULL,
	[CreatedAt] [date] NULL,
	[ModifiedAt] [date] NULL,
	[AnsweredBy_NTID] [nvarchar](20) NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
PRIMARY KEY CLUSTERED 
(
	[CustomQuestionID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_Custom_QuestionsTags](
	[CustomQuestionTagsID] [int] IDENTITY(1,1) NOT NULL,
	[CustomModeID] [int] NULL,
	[TagID] [int] NULL,
	[QuestionID] [int] NULL,
	[IsDeleted] [bit] NOT NULL DEFAULT ((0)),
PRIMARY KEY CLUSTERED 
(
	[CustomQuestionTagsID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_QN_AssignedTags](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[TagID] [int] NULL,
	[QuestionID] [int] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_QN_AssignedTagsHistory](
	[AssignedTagsHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[QuestionHistoryID] [int] NOT NULL,
	[ID] [int] NOT NULL,
	[TagID] [int] NULL,
	[QuestionID] [int] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[ActionType] [varchar](1) NULL,
	[ActionDate] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[AssignedTagsHistoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_Question_Proxy](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[QuestionID] [int] NULL,
	[Proxy] [nvarchar](20) NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[CreatedAt] [datetime] NULL,
	[ModifiedAt] [datetime] NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_Tag_AssignedAssessors](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[AssessorID] [int] NULL,
	[TagID] [int] NULL,
	[TargetFrequencyValue] [nvarchar](50) NULL,
	[TargetFrequencyTypeID] [int] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[IsMandatoryAssessor] [bit] NULL
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_Tag_AssignedAssessorsHistory](
	[AssignedAssessorsHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[TagHistoryID] [int] NOT NULL,
	[ID] [int] NOT NULL,
	[AssessorID] [int] NULL,
	[TagID] [int] NULL,
	[TargetFrequencyValue] [nvarchar](50) NULL,
	[TargetFrequencyTypeID] [int] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[IsMandatoryAssessor] [bit] NULL,
	[ActionType] [varchar](1) NULL,
	[ActionAt] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[AssignedAssessorsHistoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_Tag_AssignedQuestionsTags](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[TagID] [int] NULL,
	[QuestionID] [int] NULL,
	[LinkedTagID] [int] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_Tag_AssignedQuestionsTagsHistory](
	[AssignedQuesTagHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[TagHistoryID] [int] NOT NULL,
	[ID] [int] NOT NULL,
	[TagID] [int] NULL,
	[QuestionID] [int] NULL,
	[LinkedTagID] [int] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[ActionType] [varchar](1) NULL,
	[ActionAt] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[AssignedQuesTagHistoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_Tag_AssignedValueStreams](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ValueStreamID] [int] NULL,
	[TagID] [int] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_Tag_AssignedValueStreamsHistory](
	[AssignedValueStreamsHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[TagHistoryID] [int] NOT NULL,
	[ID] [int] NOT NULL,
	[ValueStreamID] [int] NULL,
	[TagID] [int] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[ActionType] [varchar](1) NULL,
	[ActionAt] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[AssignedValueStreamsHistoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_Tag_Proxy](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[TagID] [int] NULL,
	[Proxy] [nvarchar](20) NULL,
	[IsDeleted] [bit] NULL,
	[CreatedAt] [datetime] NULL,
	[ModifiedAt] [datetime] NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_TagMode_Questions](
	[TagModeQuestionID] [int] IDENTITY(1,1) NOT NULL,
	[TagModeID] [int] NULL,
	[QuestionID] [int] NULL,
	[AnswerTypeID] [int] NULL,
	[Answer] [nvarchar](max) NULL,
	[IsAnswered] [bit] NULL,
	[TagModeTagsID] [int] NULL,
	[CreatedAt] [date] NULL,
	[ModifiedAt] [date] NULL,
	[AnsweredBy_NTID] [nvarchar](20) NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0))
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_TagMode_Tags](
	[TagModeTagsID] [int] IDENTITY(1,1) NOT NULL,
	[TagModeID] [int] NULL,
	[TagID] [int] NULL,
	[QuestionID] [int] NULL,
	[IsDeleted] [bit] NOT NULL DEFAULT ((0))
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_ValueStream_Proxy](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ValueStreamTemplateID] [int] NULL,
	[Proxy] [nvarchar](20) NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[CreatedAt] [datetime] NULL,
	[ModifiedAt] [datetime] NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_ValueStream_Shift](
	[ShiftID] [int] IDENTITY(1,1) NOT NULL,
	[ShiftName] [nvarchar](50) NULL,
	[RowID] [int] NULL,
	[ValueStreamTemplateID] [int] NULL,
	[FromTime] [datetime] NULL,
	[ToTime] [datetime] NULL,
	[IsMonday] [bit] NULL,
	[IsTuesDay] [bit] NULL,
	[IsWednesday] [bit] NULL,
	[IsThursday] [bit] NULL,
	[IsFriday] [bit] NULL,
	[IsSaturday] [bit] NULL,
	[IsSunday] [bit] NULL,
	[DisplayName] [nvarchar](200) NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
PRIMARY KEY CLUSTERED 
(
	[ShiftID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_LNK_ValueStream_ShiftHistory](
	[ShiftHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[ValueStreamTemplateHistoryID] [int] NOT NULL,
	[ShiftID] [int] NOT NULL,
	[ShiftName] [nvarchar](50) NULL,
	[RowID] [int] NULL,
	[ValueStreamTemplateID] [int] NULL,
	[FromTime] [datetime] NULL,
	[ToTime] [datetime] NULL,
	[IsMonday] [bit] NULL,
	[IsTuesDay] [bit] NULL,
	[IsWednesday] [bit] NULL,
	[IsThursday] [bit] NULL,
	[IsFriday] [bit] NULL,
	[IsSaturday] [bit] NULL,
	[IsSunday] [bit] NULL,
	[DisplayName] [nvarchar](200) NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[ActionType] [varchar](1) NULL,
	[ActionDate] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[ShiftHistoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_MST_AnswerType](
	[AnswerTypeID] [int] IDENTITY(1,1) NOT NULL,
	[AnswerTypeName] [nvarchar](200) NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[IsDefault] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[AnswerTypeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_MST_ChoiceDisplayType](
	[ChoiceDisplayTypeID] [int] IDENTITY(1,1) NOT NULL,
	[ChoiceDisplayTypeName] [nvarchar](50) NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
PRIMARY KEY CLUSTERED 
(
	[ChoiceDisplayTypeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_MST_EmailTemplate](
	[EmailTemplateID] [int] IDENTITY(1,1) NOT NULL,
	[LanguageCode] [nvarchar](10) NULL,
	[Template] [nvarchar](20) NULL,
	[Subject] [nvarchar](max) NULL,
	[Content] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[EmailTemplateID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_MST_PowerBI](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[Language] [nvarchar](50) NULL,
	[LanguageCode] [nvarchar](5) NULL,
	[EnglishTitle] [nvarchar](max) NULL,
	[TranslatedTitle] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_MST_Priority](
	[PriorityID] [int] IDENTITY(1,1) NOT NULL,
	[PriorityName] [nvarchar](50) NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
PRIMARY KEY CLUSTERED 
(
	[PriorityID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_MST_Role](
	[RoleID] [int] IDENTITY(1,1) NOT NULL,
	[RoleName] [nvarchar](50) NOT NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0))
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_MST_TargetFrequencyType](
	[TargetFrequencyTypeID] [int] IDENTITY(1,1) NOT NULL,
	[TargetFrequencyTypeName] [nvarchar](50) NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
PRIMARY KEY CLUSTERED 
(
	[TargetFrequencyTypeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_MST_User] (
	[UserID] [int] IDENTITY(1, 1) NOT NULL
	,[PlantID] [int] NOT NULL 
	,[UserName] [nvarchar](200) NULL
	,[Role_RoleID] [int] NOT NULL
	,[EmployeeID] [int] NULL
	,[EmailAddress] [nvarchar](200) NULL
	,[NTID] [nvarchar](20) NULL
	,[FirstName] [nvarchar](100) NULL
	,[LastName] [nvarchar](100) NULL
	,[ModifiedAt] [datetime] NULL
	,[CustomIConID] [int] DEFAULT 0
	,CONSTRAINT [PK_T_MST_User] PRIMARY KEY CLUSTERED ([UserID] ASC) WITH (
		PAD_INDEX = OFF
		,STATISTICS_NORECOMPUTE = OFF
		,IGNORE_DUP_KEY = OFF
		,ALLOW_ROW_LOCKS = ON
		,ALLOW_PAGE_LOCKS = ON
		) ON [PRIMARY]
	) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_MST_VisualizationViewMode](
	[VisualizationViewModeID] [int] IDENTITY(1,1) NOT NULL,
	[VisualizationViewModeName] [nvarchar](50) NULL,
 CONSTRAINT [PK_T_MST_VisualizationViewMode] PRIMARY KEY CLUSTERED 
(
	[VisualizationViewModeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_Assessor](
	[AssessorID] [int] IDENTITY(1,1) NOT NULL,
	[AssessorName] [nvarchar](50) NULL,
	[TargetFrequencyValue] [nvarchar](50) NULL,
	[AssessorTemplateID] [int] NULL,
	[TargetFrequencyTypeID] [int] NULL,
	[Category] [nvarchar](100) NULL,
	[TargetFrequencyLowLimit] [int] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[ModifiedAt] [datetime] NULL,
	[CreatedAt] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[AssessorID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_AssessorHistory](
	[AssessorHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[AssessorTemplateHistoryID] [int] NOT NULL,
	[AssessorID] [int] NOT NULL,
	[AssessorName] [nvarchar](50) NULL,
	[TargetFrequencyValue] [nvarchar](50) NULL,
	[AssessorTemplateID] [int] NULL,
	[TargetFrequencyTypeID] [int] NULL,
	[Category] [nvarchar](100) NULL,
	[TargetFrequencyLowLimit] [int] NULL,
	[ActionType] [varchar](1) NOT NULL,
	[ActionDate] [datetime] NOT NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[ModifiedAt] [datetime] NULL,
	[CreatedAt] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[AssessorHistoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_AssessorTemplate](
	[AssessorTemplateID] [int] IDENTITY(1,1) NOT NULL,
	[PlantID] [int] NOT NULL,
	[AssessorTemplateDisplayID] [int] NULL,
	[AssessorTemplateName] [nvarchar](50) NULL,
	[IsTargetFrequencyDefined] [bit] NULL,
	[IsLocked] [bit] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[CreatedAt] [datetime] NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[ModifiedAt] [datetime] NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[AssessorTemplateID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_AssessorTemplateHistory](
	[AssessorTemplateHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[AssessorTemplateID] [int] NOT NULL,
	[PlantID] [int] NOT NULL,
	[AssessorTemplateDisplayID] [int] NULL,
	[AssessorTemplateHistoryDisplayID] [int] NULL,
	[AssessorTemplateName] [nvarchar](50) NULL,
	[IsTargetFrequencyDefined] [bit] NULL,
	[IsLocked] [bit] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[ActionType] [varchar](1) NOT NULL,
	[ActionDate] [datetime] NOT NULL,
	[ModifiedAt] [datetime] NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	[CreatedAt] [datetime] NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[AssessorTemplateHistoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_Audit](
	[AuditID] [int] IDENTITY(1,1) NOT NULL,
	[PlantID] [int] NOT NULL,
	[StartDate] [date] NULL,
	[EndDate] [date] NULL,
	[IsRecurring] [bit] NULL,
	[ValueStreamID] [int] NULL,
	[Remarks] [nvarchar](max) NULL,
	[Location] [nvarchar](200) NULL,
	[IsAuditCompleted] [bit] NULL,
	[TagID] [int] NULL,
	[CreatedAt] [datetime] NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[ModifiedAt] [datetime] NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[StartTime] time(0) NULL,
	[EndTime] time(0) NULL,
	[IsAllDay] bit default(0) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[AuditID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_AuditAssessor](
	[AuditAssessorID] [int] IDENTITY(1,1) NOT NULL,
	[AuditID] [int] NULL,
	[AssessorName] [nvarchar](200) NULL,
	[IsMandatoryAssessor] [bit] NULL,
	[NTID] [nvarchar](20) NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	[CreatedAt] [datetime] NULL,
	[ModifiedAt] [datetime] NULL,
	[IsActive] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[AuditAssessorID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_AuditDeviation](
	[AuditDeviationID] [int] IDENTITY(1,1) NOT NULL,
	[AuditTemplateID] [int] NULL,
	[AuditID] [int] NULL,
	[ValueStreamID] [int] NULL,
	[DeviationDescription] [nvarchar](max) NULL,
	[ResponsibleEmployee] [nvarchar](200) NULL,
	[QuestionID] [int] NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	[CreatedAt] [datetime] NULL,
	[ModifiedAt] [datetime] NULL,
	[ManagerEmailAddress] [nvarchar](100) NULL,
	[ResponsibleEmployeeEmailAddress] [nvarchar](100) NULL,
	[ValueStreamName] [nvarchar](max) NULL,
	[UserEmailAddress] [nvarchar](100) NULL,
	[DeviationTypeID] [int] NULL,
	[QuestionText] [nvarchar](max) NULL,
	[ResponsibleEmpNTID] [nvarchar](20) NULL,
	[Owner] [nvarchar](100) NULL,
	[OwnerNTID] [nvarchar](20) NULL,
	[CreatedBy_Name] [nvarchar](100) NULL,
	[AuditAnsweredQuestionID] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[AuditDeviationID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_AuditDeviationAttachments](
	[DeviationAttachmentsID] [int] IDENTITY(1,1) NOT NULL,
	[AuditDeviationID] [int] NULL,
	[QuestionID] [int] NULL,
	[ImageTitle] [nvarchar](max) NULL,
	[ImagePath] [nvarchar](max) NULL,
	[FileContent] [varbinary](max) NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	[IsDeleted] [bit] NULL,
	[DisplayFileName] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[DeviationAttachmentsID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_Choice](
	[ChoiceID] [int] IDENTITY(1,1) NOT NULL,
	[QuestionID] [int] NULL,
	[ChoiceName] [nvarchar](500) NULL,
	[ChoiceScore] [decimal](10, 2) NULL,
	[IsDeviationEntryRequired] [bit] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[DeviationTypeID] [int] NULL,
	[AnswerCategory] [nvarchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[ChoiceID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_ChoiceHistory](
	[ChoiceHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[QuestionHistoryID] [int] NOT NULL,
	[ChoiceID] [int] NOT NULL,
	[QuestionID] [int] NULL,
	[ChoiceName] [nvarchar](500) NULL,
	[ChoiceScore] [decimal](10, 2) NULL,
	[IsDeviationEntryRequired] [bit] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[ActionType] [varchar](1) NULL,
	[ActionDate] [datetime] NULL,
	[DeviationTypeID] [int] NULL,
	[AnswerCategory] [nvarchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[ChoiceHistoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_CustomMode](
	[CustomModeID] [int] IDENTITY(1,1) NOT NULL,
	[PlantID] [int] NOT NULL,
	[CreatedAt] [date] NULL,
	[IsCompleted] [bit] NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[CustomModeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_DataPool](
	[DataPoolID] [int] IDENTITY(1,1) NOT NULL,
	[PlantID] [int] NOT NULL,
	[DataPoolDisplayID] [int] NULL,
	[TimeStamp] [datetime] NULL,
	[ValueStreamID] [int] NULL,
	[AssessorID] [int] NULL,
	[QuestionID] [int] NULL,
	[Answer] [nvarchar](max) NULL,
	[answerType_AnswerTypeID] [int] NULL,
	[CreatedAt] [datetime] NULL,
	[AnsweredBy_NTID] [nvarchar](20) NULL,
	[ModifiedAt] [datetime] NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	[TagID] [int] NULL,
	[IsDeviation] [bit] NULL,
	[IsAnswered] [bit] NULL,
	[ObtainedScore] [decimal](10, 2) NULL,
	[ChoiceID] [int] NULL,
	[DeviationID] [int] NULL,
	[AuditID] [int] NULL,
	[AuditTemplateID] [int] NULL,
	[IsShowVsAs] [bit] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[SessionID] [nvarchar](20) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_DataPoolHistory](
	[DataPoolHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[PlantID] [int] NOT NULL,
	[DataPoolHistoryDisplayID] [int] NULL,
	[DataPoolID] [int] NOT NULL,
	[DataPoolDisplayID] [int] NULL,
	[TimeStamp] [datetime] NULL,
	[ValueStreamID] [int] NULL,
	[AssessorID] [int] NULL,
	[QuestionID] [int] NULL,
	[Answer] [nvarchar](max) NULL,
	[answerType_AnswerTypeID] [int] NULL,
	[CreatedAt] [datetime] NULL,
	[AnsweredBy_NTID] [nvarchar](20) NULL,
	[ModifiedAt] [datetime] NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	[TagID] [int] NULL,
	[IsDeviation] [bit] NULL,
	[IsAnswered] [bit] NULL,
	[ObtainedScore] [decimal](10, 2) NULL,
	[ChoiceID] [int] NULL,
	[DeviationID] [int] NULL,
	[AuditID] [int] NULL,
	[AuditTemplateID] [int] NULL,
	[IsShowVsAs] [bit] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[ActionType] [varchar](1) NOT NULL,
	[ActionDate] [datetime] NOT NULL,
	[SessionID] [nvarchar](20) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_Deviation](
	[DeviationID] [int] IDENTITY(1,1) NOT NULL,
	[PlantID] [int] NOT NULL,
	[DeviationDisplayID] [int] NULL,
	[ValueStreamID] [int] NULL,
	[DeviationDescription] [nvarchar](max) NULL,
	[ResponsibleEmployee] [nvarchar](200) NULL,
	[QuestionID] [int] NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	[CreatedAt] [datetime] NULL,
	[ModifiedAt] [datetime] NULL,
	[SuperOPLURL] [nvarchar](max) NULL,
	[SuperOPLTaskID] [nvarchar](MAX) NULL,
	[SuperOPLStatus] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[DeviationID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_DeviationAttachments](
	[DeviationAttachmentsID] [int] IDENTITY(1,1) NOT NULL,
	[DeviationID] [int] NULL,
	[QuestionID] [int] NULL,
	[ImageTitle] [nvarchar](max) NULL,
	[ImagePath] [nvarchar](max) NULL,
	[FileContent] [varbinary](max) NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[DisplayFileName] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[DeviationAttachmentsID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_HintHyperLink](
	[QuestionID] [int] NULL,
	[HyperLinkTitle] [nvarchar](50) NULL,
	[HyperLinkURL] [nvarchar](500) NULL,
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_HintHyperLinkHistory](
	[HintHyperLinkHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[QuestionHistoryID] [int] NOT NULL,
	[ID] [int] NOT NULL,
	[QuestionID] [int] NULL,
	[HyperLinkTitle] [nvarchar](50) NULL,
	[HyperLinkURL] [nvarchar](500) NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[ActionType] [varchar](1) NULL,
	[ActionDate] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[HintHyperLinkHistoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_HintImage](
	[QuestionID] [int] NULL,
	[ImageTitle] [nvarchar](max) NULL,
	[ImagePath] [nvarchar](max) NULL,
	[FileContent] [varbinary](max) NULL,
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[DisplayFileName] [nvarchar](max) NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
 CONSTRAINT [PK__T_TRN_Hi__3214EC270138D503] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_HintImageHistory](
	[HintImageHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[QuestionHistoryID] [int] NOT NULL,
	[ID] [int] NOT NULL,
	[QuestionID] [int] NULL,
	[ImageTitle] [nvarchar](max) NULL,
	[ImagePath] [nvarchar](max) NULL,
	[FileContent] [varbinary](max) NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[ActionType] [varchar](1) NULL,
	[ActionDate] [datetime] NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[DisplayFileName] [nvarchar](max) NULL,
 CONSTRAINT [PK__T_TRN_Hi__F4D42F7D92BFFF93] PRIMARY KEY CLUSTERED 
(
	[HintImageHistoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_LogError](
	[LogID] [int] IDENTITY(1,1) NOT NULL,
	[PlantID] [int] NOT NULL,
	[ErrorNumber] [int] NULL,
	[ErrorSeverity] [nvarchar](50) NULL,
	[ErrorState] [nvarchar](100) NULL,
	[ErrorProcedure] [nvarchar](200) NULL,
	[ErrorLine] [nvarchar](50) NULL,
	[ErrorMessage] [nvarchar](max) NULL,
	[CreatedOn] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](20) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_MultipleLinesText](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[MaxLines] [int] NULL,
	[IsPlaintText] [bit] NULL,
	[QuestionID] [int] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_MultipleLinesTextHistory](
	[MultipleLinesTextHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[QuestionHistoryID] [int] NOT NULL,
	[ID] [int] NOT NULL,
	[MaxLines] [int] NULL,
	[IsPlaintText] [bit] NULL,
	[QuestionID] [int] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[ActionType] [varchar](1) NULL,
	[ActionDate] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[MultipleLinesTextHistoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_Question](
	[QuestionID] [int] IDENTITY(1,1) NOT NULL,
	[PlantID] [int] NOT NULL,
	[QuestionDisplayID] [int] NULL,
	[QuestionText] [nvarchar](max) NULL,
	[QuestionHintText] [nvarchar](max) NULL,
	[AnswerType_AnswerTypeID] [int] NULL,
	[ChoiceDisplayTypeID] [int] NULL,
	[IsFilledInChoiceAllowed] [bit] NULL,
	[IsUniqueAnswerRequired] [bit] NULL,
	[IsAnswerRequired] [bit] NULL,
	[DefaultChoiceID] [int] NULL,
	[IsQuestionAlwaysActive] [bit] NULL,
	[ActiveDateRangeFrom] [datetime] NULL,
	[ActiveDateRangeTo] [datetime] NULL,
	[IsTargetFrequencyDefined] [bit] NULL,
	[TargetFrequencyTypeID] [int] NULL,
	[TargetFrequencyValue] [nvarchar](50) NULL,
	[Question_PriorityID] [int] NULL,
	[IsLocked] [bit] NULL,
	[Assigned_ValueStreamTemplateID] [int] NULL,
	[Assigned_ValueStreamCategoryID] [int] NULL,
	[Assigned_AssessorTemplateID] [int] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[CreatedAt] [datetime] NULL,
	[ModifiedAt] [datetime] NULL,
	[IsDefaultAnswerRequired] [bit] NULL,
	[Assigned_AssessorID] [int] NULL,
	[IsAnswered] [bit] NULL DEFAULT ((0)),
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	[DefaultChoice] [nvarchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[QuestionID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_QuestionHistory](
	[QuestionHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[PlantID] [int] NOT NULL,
	[QuestionHistoryDisplayID] [int] NULL,
	[QuestionID] [int] NULL,
	[QuestionDisplayID] [int] NULL,
	[QuestionText] [nvarchar](max) NULL,
	[QuestionHintText] [nvarchar](max) NULL,
	[AnswerType_AnswerTypeID] [int] NULL,
	[ChoiceDisplayTypeID] [int] NULL,
	[IsFilledInChoiceAllowed] [bit] NULL,
	[IsUniqueAnswerRequired] [bit] NULL,
	[IsAnswerRequired] [bit] NULL,
	[DefaultChoiceID] [int] NULL,
	[IsQuestionAlwaysActive] [bit] NULL,
	[ActiveDateRangeFrom] [datetime] NULL,
	[ActiveDateRangeTo] [datetime] NULL,
	[IsTargetFrequencyDefined] [bit] NULL,
	[TargetFrequencyTypeID] [int] NULL,
	[TargetFrequencyValue] [nvarchar](50) NULL,
	[Question_PriorityID] [int] NULL,
	[IsLocked] [bit] NULL,
	[Assigned_ValueStreamTemplateID] [int] NULL,
	[Assigned_ValueStreamCategoryID] [int] NULL,
	[Assigned_AssessorTemplateID] [int] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[CreatedAt] [datetime] NULL,
	[ModifiedAt] [datetime] NULL,
	[IsDefaultAnswerRequired] [bit] NULL,
	[Assigned_AssessorID] [int] NULL,
	[IsAnswered] [bit] NULL DEFAULT ((0)),
	[ActionType] [varchar](1) NULL,
	[ActionAt] [datetime] NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[DefaultChoice] [nvarchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[QuestionHistoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_RatingScale](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[NumberRange] [nvarchar](10) NULL,
	[RangeText1] [nvarchar](50) NULL,
	[RangeText2] [nvarchar](50) NULL,
	[RangeText3] [nvarchar](50) NULL,
	[ShowNA] [bit] NULL,
	[TextNA] [nvarchar](10) NULL,
	[QuestionID] [int] NULL,
	[IsDeleted] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_RatingScaleHistory](
	[RatingScaleHistoryHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[QuestionHistoryID] [int] NOT NULL,
	[ID] [int] NOT NULL,
	[NumberRange] [nvarchar](10) NULL,
	[RangeText1] [nvarchar](50) NULL,
	[RangeText2] [nvarchar](50) NULL,
	[RangeText3] [nvarchar](50) NULL,
	[ShowNA] [bit] NULL,
	[TextNA] [nvarchar](10) NULL,
	[QuestionID] [int] NULL,
	[IsDeleted] [bit] NULL,
	[ActionType] [varchar](1) NULL,
	[ActionDate] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[RatingScaleHistoryHistoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_SingleLineText](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[MaxCharacters] [int] NULL,
	[IsCalculated] [bit] NULL,
	[DefaultValue] [nvarchar](max) NULL,
	[QuestionID] [int] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_SingleLineTextHistory](
	[SingleLineTextHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[QuestionHistoryID] [int] NOT NULL,
	[ID] [int] NOT NULL,
	[MaxCharacters] [int] NULL,
	[IsCalculated] [bit] NULL,
	[DefaultValue] [nvarchar](max) NULL,
	[QuestionID] [int] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[ActionType] [varchar](1) NULL,
	[ActionDate] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[SingleLineTextHistoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_SubQuestion](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](200) NULL,
	[QuestionID] [int] NULL,
	[IsDeleted] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_SubQuestionHistory](
	[SubQuestionHistoryHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[QuestionHistoryID] [int] NOT NULL,
	[ID] [int] NOT NULL,
	[Name] [nvarchar](200) NULL,
	[QuestionID] [int] NULL,
	[IsDeleted] [bit] NULL,
	[ActionType] [varchar](1) NULL,
	[ActionDate] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[SubQuestionHistoryHistoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_Tag](
	[TagID] [int] IDENTITY(1,1) NOT NULL,
	[PlantID] [int] NOT NULL,
	[TagDisplayID] [int] NULL,
	[TagName] [nvarchar](MAX) NULL,
	[IsSingleQuestionSuppressed] [bit] NULL,
	[SuppressedDateRangeFrom] [datetime] NULL,
	[SuppressedDateRangeTo] [datetime] NULL,
	[IsTargetFrequencyDefined] [bit] NULL,
	[TargetFrequencyTypeID] [int] NULL,
	[TargetFrequencyValue] [nvarchar](50) NULL,
	[Tag_PriorityID] [int] NULL,
	[TagTypeID] [int] NULL,
	[IsLocked] [bit] NULL,
	[AnonymizeUserDataSettingID] [int] NULL,
	[IsBranchLogicToBeFollowed] [bit] NULL,
	[IsMandatoryAssessorsDefined] [bit] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[CreatedAt] [datetime] NULL,
	[ModifiedAt] [datetime] NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	[Assigned_ValueStreamTemplateID] [int] NULL,
	[Assigned_ValueStreamCategoryID] [int] NULL,
	[Assigned_AssessorTemplateID] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[TagID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_TagHistory](
	[TagHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[PlantID] [int] NOT NULL,
	[TagID] [int] NULL,
	[TagDisplayID] [int] NOT NULL,
	[TagHistoryDisplayID] [int] NULL,
	[TagName] [nvarchar](MAX) NULL,
	[IsSingleQuestionSuppressed] [bit] NULL,
	[SuppressedDateRangeFrom] [datetime] NULL,
	[SuppressedDateRangeTo] [datetime] NULL,
	[IsTargetFrequencyDefined] [bit] NULL,
	[TargetFrequencyTypeID] [int] NULL,
	[TargetFrequencyValue] [nvarchar](50) NULL,
	[Tag_PriorityID] [int] NULL,
	[TagTypeID] [int] NULL,
	[IsLocked] [bit] NULL,
	[AnonymizeUserDataSettingID] [int] NULL,
	[IsBranchLogicToBeFollowed] [bit] NULL,
	[IsMandatoryAssessorsDefined] [bit] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[CreatedAt] [datetime] NULL,
	[ModifiedAt] [datetime] NULL,
	[ActionType] [varchar](1) NULL,
	[ActionAt] [datetime] NULL,
	[Assigned_ValueStreamTemplateID] [int] NULL,
	[Assigned_ValueStreamCategoryID] [int] NULL,
	[Assigned_AssessorTemplateID] [int] NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[TagHistoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_TagMode](
	[TagModeID] [int] IDENTITY(1,1) NOT NULL,
	[PlantID] [int] NOT NULL,
	[CreatedAt] [date] NULL,
	[IsCompleted] [bit] NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_ValueStream](
	[ValueStreamID] [int] IDENTITY(1,1) NOT NULL,
	[Responsible_UserID] [nvarchar](20) NULL,
	[ValueStreamTemplateID] [int] NOT NULL,
	[ValueStreamCategoryID] [int] NOT NULL,
	[ValueStreamData] [nvarchar](50) NULL,
	[RowID] [int] NULL,
	[NodeID] [int] NULL,
	[ResponsibleEmployee] [nvarchar](200) NULL,
	[ValueStreamName] [nvarchar](max) NULL,
	[ParentId] [nvarchar](500) NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
 CONSTRAINT [PK_T_TRN_ValueStream] PRIMARY KEY CLUSTERED 
(
	[ValueStreamID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_ValueStreamCategory](
	[ValueStreamCategoryID] [int] IDENTITY(1,1) NOT NULL,
	[ValueStreamCategoryName] [nvarchar](50) NOT NULL,
	[ValueStreamTemplateID] [int] NULL,
	[IsDataRequired] [bit] NULL,
	[TypeOfInput_InputTypeID] [int] NULL,
	[IsDataRequiredToFitSpecLength] [bit] NULL,
	[MinimumNoOfCharacters] [int] NULL,
	[MaximumNoOfCharacters] [int] NULL,
	[NodeID] [int] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[IsColumnRequired] [bit] NULL,
	[InputType] [nvarchar](100) NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
 CONSTRAINT [PK_T_TRN_ValueStreamCategory] PRIMARY KEY CLUSTERED 
(
	[ValueStreamCategoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_ValueStreamCategoryHistory](
	[ValueStreamCategoryHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[ValueStreamTemplateHistoryID] [int] NOT NULL,
	[ValueStreamCategoryID] [int] NOT NULL,
	[ValueStreamCategoryName] [nvarchar](50) NOT NULL,
	[ValueStreamTemplateID] [int] NULL,
	[IsDataRequired] [bit] NULL,
	[TypeOfInput_InputTypeID] [int] NULL,
	[IsDataRequiredToFitSpecLength] [bit] NULL,
	[MinimumNoOfCharacters] [int] NULL,
	[MaximumNoOfCharacters] [int] NULL,
	[NodeID] [int] NULL,
	[ActionType] [varchar](1) NULL,
	[ActionDate] [datetime] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[IsColumnRequired] [bit] NULL,
	[InputType] [nvarchar](100) NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[ValueStreamCategoryHistoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_ValueStreamHistory](
	[ValueStreamHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[ValueStreamTemplateHistoryID] [int] NOT NULL,
	[ValueStreamID] [int] NOT NULL,
	[Responsible_UserID] [nvarchar](20) NULL,
	[ValueStreamTemplateID] [int] NOT NULL,
	[ValueStreamCategoryID] [int] NOT NULL,
	[ValueStreamData] [nvarchar](50) NULL,
	[RowID] [int] NULL,
	[NodeID] [int] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
	[ResponsibleEmployee] [nvarchar](200) NULL,
	[ValueStreamName] [nvarchar](max) NULL,
	[ParentId] [nvarchar](500) NULL,
	[ActionType] [varchar](1) NULL,
	[ActionDate] [datetime] NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[ValueStreamHistoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [T_TRN_ValueStreamTemplate](
	[ValueStreamTemplateID] [int] IDENTITY(1,1) NOT NULL,
	[PlantID] [int] NOT NULL,
	[ValueStreamTemplateDisplayID] [int] NULL,
	[ValueStreamTemplateName] [nvarchar](50) NULL,
	[IsLocked] [bit] NULL,
	[Delimiter] [nvarchar](5) NULL,
	[IsOperatedInShifts] [bit] NULL,
	[VisualizationViewModeID] [int] NULL,
	[CreatedAt] [datetime] NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[ModifiedAt] [datetime] NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
 CONSTRAINT [PK_T_MST_ValueStreamTemplate] PRIMARY KEY CLUSTERED 
(
	[ValueStreamTemplateID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
ALTER TABLE [T_LNK_AssignedTargetFrequency] ADD  DEFAULT ((0)) FOR [IsDeleted]
GO
ALTER TABLE [T_LNK_AssignedTargetFrequencyHistory] ADD  DEFAULT ((0)) FOR [IsDeleted]
GO
ALTER TABLE [T_LNK_AuditTemplate_OtherAssessorDetail] ADD  DEFAULT ((0)) FOR [IsDeleted]
GO
ALTER TABLE [T_LNK_Tag_Proxy] ADD  DEFAULT ((0)) FOR [IsDeleted]
GO
ALTER TABLE [T_TRN_AuditDeviationAttachments] ADD  DEFAULT ((0)) FOR [IsDeleted]
GO
ALTER TABLE [T_TRN_RatingScale] ADD  DEFAULT ((0)) FOR [IsDeleted]
GO
ALTER TABLE [T_TRN_RatingScaleHistory] ADD  DEFAULT ((0)) FOR [IsDeleted]
GO
ALTER TABLE [T_TRN_SubQuestion] ADD  DEFAULT ((0)) FOR [IsDeleted]
GO
ALTER TABLE [T_TRN_SubQuestionHistory] ADD  DEFAULT ((0)) FOR [IsDeleted]
GO
ALTER TABLE [T_HST_ValueStreamTemplateHistory]  WITH CHECK ADD  CONSTRAINT [FK_T_HST_ValueStreamTemplateHistory_T_MST_ValueStreamTemplate] FOREIGN KEY([ValueStreamTemplateID])
REFERENCES [T_TRN_ValueStreamTemplate] ([ValueStreamTemplateID])
GO
ALTER TABLE [T_HST_ValueStreamTemplateHistory] CHECK CONSTRAINT [FK_T_HST_ValueStreamTemplateHistory_T_MST_ValueStreamTemplate]
GO
ALTER TABLE [T_LNK_AssignedAssessors]  WITH CHECK ADD  CONSTRAINT [FK_Assessors_AssessorID] FOREIGN KEY([AssessorID])
REFERENCES [T_TRN_Assessor] ([AssessorID])
GO
ALTER TABLE [T_LNK_AssignedAssessors] CHECK CONSTRAINT [FK_Assessors_AssessorID]
GO
ALTER TABLE [T_LNK_AssignedTargetFrequency]  WITH CHECK ADD  CONSTRAINT [FK_QuestionID] FOREIGN KEY([QuestionID])
REFERENCES [T_TRN_Question] ([QuestionID])
GO
ALTER TABLE [T_LNK_AssignedTargetFrequency] CHECK CONSTRAINT [FK_QuestionID]
GO
ALTER TABLE [T_LNK_AssignedTargetFrequency]  WITH CHECK ADD  CONSTRAINT [FK_TargetFrequencyTypeID] FOREIGN KEY([TargetFrequencyTypeID])
REFERENCES [T_MST_TargetFrequencyType] ([TargetFrequencyTypeID])
GO
ALTER TABLE [T_LNK_AssignedTargetFrequency] CHECK CONSTRAINT [FK_TargetFrequencyTypeID]
GO
ALTER TABLE [T_LNK_AssignedValueStreams]  WITH CHECK ADD  CONSTRAINT [fk_ValueStreams] FOREIGN KEY([ValueStreamID])
REFERENCES [T_TRN_ValueStream] ([ValueStreamID])
GO
ALTER TABLE [T_LNK_AssignedValueStreams] CHECK CONSTRAINT [fk_ValueStreams]
GO
ALTER TABLE [T_LNK_Audit_AssignedQuestions]  WITH CHECK ADD  CONSTRAINT [FK_AuditQuestions_AuditID] FOREIGN KEY([AuditID])
REFERENCES [T_TRN_Audit] ([AuditID])
GO
ALTER TABLE [T_LNK_Audit_AssignedQuestions] CHECK CONSTRAINT [FK_AuditQuestions_AuditID]
GO
ALTER TABLE [T_LNK_Audit_AssignedQuestions]  WITH CHECK ADD  CONSTRAINT [FK_TRN_Question] FOREIGN KEY([QuestionID])
REFERENCES [T_TRN_Question] ([QuestionID])
GO
ALTER TABLE [T_LNK_Audit_AssignedQuestions] CHECK CONSTRAINT [FK_TRN_Question]
GO
ALTER TABLE [T_LNK_Audit_AssignedTags]  WITH CHECK ADD  CONSTRAINT [FK_Audit_AuditID] FOREIGN KEY([AuditID])
REFERENCES [T_TRN_Audit] ([AuditID])
GO
ALTER TABLE [T_LNK_Audit_AssignedTags] CHECK CONSTRAINT [FK_Audit_AuditID]
GO
ALTER TABLE [T_LNK_Audit_AssignedTags]  WITH CHECK ADD  CONSTRAINT [FK_TRN_Tag] FOREIGN KEY([TagID])
REFERENCES [T_TRN_Tag] ([TagID])
GO
ALTER TABLE [T_LNK_Audit_AssignedTags] CHECK CONSTRAINT [FK_TRN_Tag]
GO
ALTER TABLE [T_LNK_Audit_OptionalAttendees]  WITH CHECK ADD  CONSTRAINT [FK_OptionalAttendees_AuditID] FOREIGN KEY([AuditID])
REFERENCES [T_TRN_Audit] ([AuditID])
GO
ALTER TABLE [T_LNK_Audit_OptionalAttendees] CHECK CONSTRAINT [FK_OptionalAttendees_AuditID]
GO
ALTER TABLE [T_LNK_Audit_OptionalAttendees]  WITH CHECK ADD  CONSTRAINT [FK_OptionalAttendees_UserID] FOREIGN KEY([UserID])
REFERENCES [T_MST_User] ([UserID])
GO
ALTER TABLE [T_LNK_Audit_OptionalAttendees] CHECK CONSTRAINT [FK_OptionalAttendees_UserID]
GO
ALTER TABLE [T_LNK_Audit_RequiredAttendees]  WITH CHECK ADD  CONSTRAINT [FK_RequiredAttendees_AuditID] FOREIGN KEY([AuditID])
REFERENCES [T_TRN_Audit] ([AuditID])
GO
ALTER TABLE [T_LNK_Audit_RequiredAttendees] CHECK CONSTRAINT [FK_RequiredAttendees_AuditID]
GO
ALTER TABLE [T_LNK_Audit_RequiredAttendees]  WITH CHECK ADD  CONSTRAINT [FK_RequiredAttendees_UserID] FOREIGN KEY([UserID])
REFERENCES [T_MST_User] ([UserID])
GO
ALTER TABLE [T_LNK_Audit_RequiredAttendees] CHECK CONSTRAINT [FK_RequiredAttendees_UserID]
GO
ALTER TABLE [T_LNK_QN_AssignedTags]  WITH CHECK ADD  CONSTRAINT [fk_Tags] FOREIGN KEY([TagID])
REFERENCES [T_TRN_Tag] ([TagID])
GO
ALTER TABLE [T_LNK_QN_AssignedTags] CHECK CONSTRAINT [fk_Tags]
GO
ALTER TABLE [T_LNK_Tag_AssignedAssessors]  WITH CHECK ADD  CONSTRAINT [FK_Tag_Assessors_AssessorID] FOREIGN KEY([AssessorID])
REFERENCES [T_TRN_Assessor] ([AssessorID])
GO
ALTER TABLE [T_LNK_Tag_AssignedAssessors] CHECK CONSTRAINT [FK_Tag_Assessors_AssessorID]
GO
ALTER TABLE [T_LNK_Tag_AssignedValueStreams]  WITH CHECK ADD  CONSTRAINT [fk_Tag_ValueStreams] FOREIGN KEY([ValueStreamID])
REFERENCES [T_TRN_ValueStream] ([ValueStreamID])
GO
ALTER TABLE [T_LNK_Tag_AssignedValueStreams] CHECK CONSTRAINT [fk_Tag_ValueStreams]
GO
ALTER TABLE [T_TRN_Assessor]  WITH CHECK ADD FOREIGN KEY([AssessorTemplateID])
REFERENCES [T_TRN_AssessorTemplate] ([AssessorTemplateID])
GO
ALTER TABLE [T_TRN_Assessor]  WITH CHECK ADD FOREIGN KEY([TargetFrequencyTypeID])
REFERENCES [T_MST_TargetFrequencyType] ([TargetFrequencyTypeID])
GO
ALTER TABLE [T_TRN_Audit]  WITH CHECK ADD  CONSTRAINT [FK_Audit_ValueStreamID] FOREIGN KEY([ValueStreamID])
REFERENCES [T_TRN_ValueStream] ([ValueStreamID])
GO
ALTER TABLE [T_TRN_Audit] CHECK CONSTRAINT [FK_Audit_ValueStreamID]
GO
ALTER TABLE [T_TRN_Choice]  WITH CHECK ADD FOREIGN KEY([QuestionID])
REFERENCES [T_TRN_Question] ([QuestionID])
GO
ALTER TABLE [T_TRN_Choice]  WITH CHECK ADD FOREIGN KEY([QuestionID])
REFERENCES [T_TRN_Question] ([QuestionID])
GO
ALTER TABLE [T_TRN_HintHyperLink]  WITH CHECK ADD FOREIGN KEY([QuestionID])
REFERENCES [T_TRN_Question] ([QuestionID])
GO
ALTER TABLE [T_TRN_HintImage]  WITH CHECK ADD  CONSTRAINT [FK__T_TRN_Hin__Quest__3DE82FB7] FOREIGN KEY([QuestionID])
REFERENCES [T_TRN_Question] ([QuestionID])
GO
ALTER TABLE [T_TRN_HintImage] CHECK CONSTRAINT [FK__T_TRN_Hin__Quest__3DE82FB7]
GO
ALTER TABLE [T_TRN_MultipleLinesText]  WITH CHECK ADD FOREIGN KEY([QuestionID])
REFERENCES [T_TRN_Question] ([QuestionID])
GO
ALTER TABLE [T_TRN_Question]  WITH CHECK ADD FOREIGN KEY([AnswerType_AnswerTypeID])
REFERENCES [T_MST_AnswerType] ([AnswerTypeID])
GO
ALTER TABLE [T_TRN_Question]  WITH CHECK ADD FOREIGN KEY([ChoiceDisplayTypeID])
REFERENCES [T_MST_ChoiceDisplayType] ([ChoiceDisplayTypeID])
GO
ALTER TABLE [T_TRN_Question]  WITH CHECK ADD FOREIGN KEY([Question_PriorityID])
REFERENCES [T_MST_Priority] ([PriorityID])
GO
ALTER TABLE [T_TRN_SingleLineText]  WITH CHECK ADD FOREIGN KEY([QuestionID])
REFERENCES [T_TRN_Question] ([QuestionID])
GO
ALTER TABLE [T_TRN_ValueStream]  WITH CHECK ADD  CONSTRAINT [FK_T_TRN_ValueStream_T_MST_ValueStreamTemplate] FOREIGN KEY([ValueStreamTemplateID])
REFERENCES [T_TRN_ValueStreamTemplate] ([ValueStreamTemplateID])
GO
ALTER TABLE [T_TRN_ValueStream] CHECK CONSTRAINT [FK_T_TRN_ValueStream_T_MST_ValueStreamTemplate]
GO
ALTER TABLE [T_TRN_ValueStream]  WITH CHECK ADD  CONSTRAINT [FK_T_TRN_ValueStream_T_TRN_ValueStreamCategory] FOREIGN KEY([ValueStreamCategoryID])
REFERENCES [T_TRN_ValueStreamCategory] ([ValueStreamCategoryID])
GO
ALTER TABLE [T_TRN_ValueStream] CHECK CONSTRAINT [FK_T_TRN_ValueStream_T_TRN_ValueStreamCategory]
GO
ALTER TABLE [T_TRN_ValueStreamCategory]  WITH CHECK ADD  CONSTRAINT [FK_T_TRN_ValueStreamCategory_T_MST_ValueStreamTemplate] FOREIGN KEY([ValueStreamTemplateID])
REFERENCES [T_TRN_ValueStreamTemplate] ([ValueStreamTemplateID])
GO
ALTER TABLE [T_TRN_ValueStreamCategory] CHECK CONSTRAINT [FK_T_TRN_ValueStreamCategory_T_MST_ValueStreamTemplate]
GO
ALTER TABLE [T_TRN_ValueStreamTemplate]  WITH CHECK ADD  CONSTRAINT [FK_T_MST_ValueStreamTemplate_T_MST_VisualizationViewMode] FOREIGN KEY([VisualizationViewModeID])
REFERENCES [T_MST_VisualizationViewMode] ([VisualizationViewModeID])
GO
ALTER TABLE [T_TRN_ValueStreamTemplate] CHECK CONSTRAINT [FK_T_MST_ValueStreamTemplate_T_MST_VisualizationViewMode]
GO

/* ELPC_LH_002_CR01 - calenndar recurrence changes */

--Recurrence Master
CREATE TABLE [T_MST_RecurrenceType](
	RecurrenceTypeID [int] PRIMARY KEY NOT NULL,
	ReurrenceName  [varchar](200) NULL,
	Remarks  [nvarchar](200) NULL,
	[CreatedAt] [datetime] NOT NULL,
	[CreatedBy_NTID] [nvarchar](20) NOT NULL,
	[ModifiedAt] [datetime] NOT NULL,
	[ModifiedBy_NTID] [nvarchar](20) NOT NULL,
)
GO

--Recurrence Transcation
CREATE TABLE [T_TRN_Recurrence](
	[RecurrenceID] [bigint] PRIMARY KEY IDENTITY(1,1) NOT NULL,
	[PlantID] [int] NOT NULL,
	[AuditID] [int] NOT NULL,
	[RecurrenceTypeId] [int] NOT NULL,
	[Interval] [int] NULL,
	[DayOfWeek] [char](13) NULL,
	[DayOfMonth] [int] NULL,
	[WeekOfMonth] [int] NULL,
	[MonthOfYear] [int] NULL,
	[CreatedAt] [datetime] NULL,
	[CreatedBy_NTID] [nvarchar](20) NULL,
	[ModifiedAt] [datetime] NULL,
	[ModifiedBy_NTID] [nvarchar](20) NULL,
	CONSTRAINT FK_AuditID FOREIGN KEY (AuditID) REFERENCES T_TRN_Audit (AuditID),
	CONSTRAINT FK_RecurrenceTypeId FOREIGN KEY (RecurrenceTypeId) REFERENCES T_MST_RecurrenceType (RecurrenceTypeID),
	CONSTRAINT UK_PlantID_AuditID UNIQUE(PlantID,AuditID)   
	)
GO

--VALUESTREAM USER PROFILE CONFIGURATION BY NTID
CREATE TABLE [T_TRN_ValueStreamConfig](
	[UserProfileValueStreamID] [int] IDENTITY(1,1) NOT NULL,
	[PlantID] [int] NOT NULL,
	[User_NTID] [nvarchar](20) NULL,
	[RowID] [int] NULL,
	[ValueStreamTemplateID] [int] NULL,
	[ValueStreamCategoryID] [int] NULL,
	[ValueStreamID] [int] NULL,
	[IsForgotValueStream] [bit] NULL DEFAULT ((0)),
	[SessionID] [nvarchar](20) NULL,
	[CreatedAt] [datetime] NULL,
	[ModifiedAt] [datetime] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
PRIMARY KEY CLUSTERED 
(
	[UserProfileValueStreamID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

--ASSESSOR USER PROFILE CONFIGURATION BY NTID
CREATE TABLE [T_TRN_AssessorConfig](
	[UserProfileAssessorID] [int] IDENTITY(1,1) NOT NULL,
	[PlantID] [int] NOT NULL,
	[User_NTID] [nvarchar](20) NULL,
	[RowID] [int] NULL,
	[AssessorTemplateID] [int] NULL,
	[AssessorID] [int] NULL,
	[IsForgotAssessor] [bit] NULL DEFAULT ((0)),
	[SessionID] [nvarchar](20) NULL,
	[CreatedAt] [datetime] NULL,
	[ModifiedAt] [datetime] NULL,
	[IsDeleted] [bit] NULL DEFAULT ((0)),
PRIMARY KEY CLUSTERED 
(
	[UserProfileAssessorID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

CREATE TABLE [T_TRN_DataPool_Summary] (
	[ID] [int] IDENTITY(1, 1) NOT NULL
	,[PlantID] [int] NOT NULL
	,[QuestionID] [int] NULL
	,[ValueStreamID] [int] NULL
	,[AnswerCount] [int] NULL
	,[NegativeAnswerCount] [int] NULL
	,[Percentage] [decimal](18, 0) NULL
	) ON [PRIMARY]
GO


CREATE TABLE [T_TRN_Scheduler]
(
	[ScheduleId] [INT] IDENTITY(1,1) NOT NULL PRIMARY KEY
	,[PlantId] [INT] NOT NULL
	,[ScheduleName] NVARCHAR(250) NOT NULL
	,[DataObj] [NVARCHAR](MAX) NULL
	,[ExecutionCount] [INT] NOT NULL DEFAULT(0)
	,[MaxExecutionCount] [INT] NOT NULL DEFAULT(-1)
	,[IsCompleted] [BIT] NOT NULL DEFAULT(0)
	,[LastRunAt] [DATETIME] NULL
	,[ErrorDetail] [NVARCHAR](MAX) NULL
	,[RecentErrorDetail] [NVARCHAR](MAX) NULL
	,[CreatedAt] [DATETIME] NOT NULL DEFAULT(GETDATE())
	,[ModifiedAt] [DATETIME] NULL DEFAULT(GETDATE())
	,[IsDeleted] [BIT] NOT NULL DEFAULT(0)
	,[CreatedBy_NTID] [NVARCHAR](20) NOT NULL
	,[ModifiedBy_NTID] [NVARCHAR](20) NULL
);
GO


CREATE TABLE [T_MST_PrincipleImage](
	[Principle] [nvarchar](255) NULL,
	[ImageURL] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [T_MST_Principlenames](
	[ID] [int] NULL,
	[PrincipleDisplayName] [nvarchar](5) NULL,
	[TagName] [nvarchar](100) NULL,
	[OrderBY] [int] NULL
) ON [PRIMARY]
GO

CREATE TABLE [T_MST_SuperOPLStatus](
	[StatusID] [int] NOT NULL,
	[Status] [nvarchar](100) NOT NULL,
	[Remarks] [nvarchar](200) NULL,
	[CreatedAt] [datetime] NOT NULL,
	[IsDeleted] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[StatusID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 95, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

CREATE TABLE [T_PBI_14QAssessment](
	[Valuestreamid] [nvarchar](100) NULL,
	[Final] [int] NULL,
	[PRINCIPLE] [nvarchar](5) NULL,
	[PlantID] [int] NULL,
	[ValueStreamTemplateName] [nvarchar](max) NULL,
	[ValueStreamName] [nvarchar](max) NULL,
	[CreatedAt] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [T_PBI_14QAssessment] ADD  DEFAULT (getdate()) FOR [CreatedAt]
GO