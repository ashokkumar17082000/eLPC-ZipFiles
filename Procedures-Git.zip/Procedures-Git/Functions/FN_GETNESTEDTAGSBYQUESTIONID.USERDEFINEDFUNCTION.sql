/*  
///<SUMMARY>  
///DESCRIPTION                  : FUNCTION - [FN_GetNestedTagsByQuestionID]
///AUTHOR                       : CHHETRI MONASH
///CREATED DATE                 : 01-OCT-2021
///SEE ALSO                     : THIS FUNCTION IS USED FOR SPLITTING/TRIMMING OF INPUT
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_002					01-OCT-2021			CHHETRI MONASH		INITIAL VERSION
ELPC_LH_006					18-AUG-2023			SUSHANTH		GLOBAL TAG
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
SELECT ListTag FROM [FN_GetNestedTagsByQuestionID](1,'strTagName') where ListTag is not null 
SELECT ListTag FROM [FN_GetNestedTagsByQuestionID](1,'strTagID') where ListTag is not null 
SELECT distinct TagID FROM [FN_GetNestedTagsByQuestionID](1,'')
*/
CREATE FUNCTION [FN_GetNestedTagsByQuestionID] (    
 @questionID INT    
 ,@option NVARCHAR(MAX)    
 )    
RETURNS @LnkAssignedTags TABLE (    
 TagID INT    
 ,ListTag NVARCHAR(MAX)    
 )    
AS    
BEGIN    
 DECLARE @tmpTag TABLE (TagName NVARCHAR(max));    
    
 WITH cteLinkedTag    
 AS (    
  SELECT TagID    
   ,LinkedTagID    
   ,0 AS rowCounter    
  FROM [T_LNK_Tag_AssignedQuestionsTags] WITH (NOLOCK)    
  WHERE IsDeleted = 0    
   AND QuestionID = @questionID  
  
      
  UNION ALL    
      
  (    
   SELECT LNK.TagID    
    ,LNK.LinkedTagID   
    ,(rowCounter + 1) AS rowCounter    
   FROM [T_LNK_Tag_AssignedQuestionsTags] LNK WITH (NOLOCK)    
   INNER JOIN cteLinkedTag CTE ON CTE.TagID = LNK.LinkedTagID    
    AND LNK.IsDeleted = 0    
    AND CTE.rowCounter < 5    
   )    
  )    
  
  
 INSERT INTO @LnkAssignedTags (TagID)    
 SELECT DISTINCT TagID    
 FROM cteLinkedTag    
     
 UNION    
     
 (    
  SELECT TagID    
  FROM T_LNK_QN_AssignedTags LNK WITH (NOLOCK)    
  WHERE IsDeleted = 0    
   AND QuestionID = @questionID    
  )    
    
 IF (@option = 'strTagID')    
 BEGIN    
  INSERT INTO @LnkAssignedTags (ListTag)    
  SELECT STRING_AGG(cast(TagID AS NVARCHAR(MAX)), ',') WITHIN    
  FROM (    
   SELECT LNKAT.TagID    
   FROM @LnkAssignedTags LNKAT    
   INNER JOIN T_TRN_Tag T ON T.TagID = LNKAT.TagID    
    AND T.IsDeleted = 0    
   ) AS concatString    
 END    
 ELSE IF (@option = 'strTagName')    
 BEGIN    
  INSERT INTO @tmpTag (TagName) (    
   SELECT CASE     
    WHEN T.TagTypeID = 1    
     THEN COALESCE('#' + T.TagName, '')    
    WHEN T.TagTypeID = 2    
     THEN COALESCE('#' + T.TagName, '')    
    WHEN T.TagTypeID = 3    
     THEN COALESCE('#' + T.TagName, '')    
 WHEN T.TagTypeID = 4   
     THEN COALESCE('#' + T.TagName, '')    
    END AS TagDisplayName FROM T_TRN_Tag T WITH (NOLOCK) INNER JOIN @LnkAssignedTags LNK ON LNK.TagID = T.TagID AND T.IsDeleted = 0    
   )    
    
  INSERT INTO @LnkAssignedTags (ListTag)    
  SELECT STRING_AGG(cast(TagName AS NVARCHAR(MAX)), ',')    
  FROM (    
   SELECT TagName    
   FROM @tmpTag    
   ) AS concatString    
 END    
    
 RETURN    
END
GO 