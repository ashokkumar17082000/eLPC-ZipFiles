/*  
///<SUMMARY>  
///DESCRIPTION                  : FUNCTION - [FN_GetNestedQuestionsByTagID]
///AUTHOR                       : CHHETRI MONASH
///CREATED DATE                 : 01-OCT-2021
///SEE ALSO                     : THIS FUNCTION IS USED FOR SPLITTING/TRIMMING OF INPUT
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_002					01-OCT-2021			CHHETRI MONASH		INITIAL VERSION

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
SELECT distinct QuestionID FROM [FN_GetNestedQuestionsByTagID](3,1)
*/
CREATE FUNCTION [FN_GetNestedQuestionsByTagID] (
	@TagID INT
	,@PlantID INT
	)
RETURNS @NestedQuestions TABLE (QuestionID INT)
AS
BEGIN
	DECLARE @tempCTE TABLE (
		tagID INT
		,lnkTagID INT
		);
	DECLARE @AQ TABLE (questionID INT);
	DECLARE @TRNQ TABLE (questionID INT);;

	WITH CTE
	AS (
		SELECT TAQ.TagID AS tagID
			,TAQ.LinkedTagID AS lnkTagID
			,0 AS rowCounter
		FROM [T_LNK_Tag_AssignedQuestionsTags] TAQ WITH (NOLOCK)
		WHERE TAQ.IsDeleted = 0
			AND TAQ.TagID = @TagID
		
		UNION ALL
		
		SELECT AQT.TagID AS tagID
			,AQT.LinkedTagID AS lnkTagID
			,(rowCounter + 1) AS rowCounter
		FROM CTE
		INNER JOIN [T_LNK_Tag_AssignedQuestionsTags] AQT WITH (NOLOCK) ON CTE.lnkTagID = AQT.TagID
			AND AQT.IsDeleted = 0
			AND AQT.LinkedTagID NOT IN (CTE.TagID)
			AND lnkTagID NOT IN (
				SELECT TagID
				FROM [T_LNK_Tag_AssignedQuestionsTags] WITH (NOLOCK)
				WHERE IsDeleted = 0
					AND TagID = @TagID
				)
			AND CTE.rowCounter < 5
		)
	INSERT INTO @tempCTE (
		tagID
		,lnkTagID
		)
	SELECT tagID
		,lnkTagID
	FROM CTE

	--FETCH LINKED TAG QUESTIONS BASED ON TagID FROM T_LNK_Tag_AssignedQuestionsTags
	INSERT INTO @AQ (questionID)
	SELECT questionID
	FROM (
		SELECT DISTINCT (QuestionID)
		FROM [T_LNK_Tag_AssignedQuestionsTags] WITH (NOLOCK)
		WHERE IsDeleted = 0
			AND LinkedTagID IS NULL
			AND (
				TagID IN (
					SELECT tagID
					FROM @tempCTE
					)
				OR TagID IN (
					SELECT lnkTagID
					FROM @tempCTE
					)
				OR TagID = @TagID 
				)
		) AS Table1
	
	UNION
	
	(
		SELECT DISTINCT (QuestionID)
		FROM T_LNK_QN_AssignedTags WITH (NOLOCK)
		WHERE (
				TagID IN (
					SELECT tagID
					FROM @tempCTE
					)
				OR TagID IN (
					SELECT lnkTagID
					FROM @tempCTE
					)
				OR TagID = @TagID  
				)
			AND (isDeleted = 0)
		)

	--FETCH SUPPRESS QUESTION NOT BASED ON TagID
	DECLARE @IsSingleQuestionSuppressed INT = 0

	SET @IsSingleQuestionSuppressed = (
			SELECT TOP 1 IsSingleQuestionSuppressed
			FROM T_TRN_Tag WITH (NOLOCK)
			WHERE TagID = @TagID
			)

	INSERT INTO @TRNQ (questionID)
	SELECT QuestionID
	FROM (
		SELECT DISTINCT (QuestionID)
		FROM T_TRN_Question WITH (NOLOCK)
		WHERE PlantID = @PlantID
			AND (
				IsQuestionAlwaysActive = 1
				OR (
					@IsSingleQuestionSuppressed = 1
					AND IsQuestionAlwaysActive = 0
					AND (
						(CAST(ActiveDateRangeFrom AS DATE) >= CAST(- 53690 AS DATETIME))
						AND (CAST(ActiveDateRangeTo AS DATE) < = CAST('12/31/9999' AS DATE))
						)
					)
				OR (
					cast(@IsSingleQuestionSuppressed AS INT) <> 1
					AND IsQuestionAlwaysActive = 0
					AND (
						(
							CAST((
									SELECT FormattedDateTime
									FROM fnGetDateTime(@PlantID)
									) AS DATE) >= CAST(ActiveDateRangeFrom AS DATE)
							)
						AND (
							CAST((
									SELECT FormattedDateTime
									FROM fnGetDateTime(@PlantID)
									) AS DATE) <= CAST(ActiveDateRangeTo AS DATE)
							)
						)
					)
				)
		) AS TRNQ;

	INSERT INTO @NestedQuestions (QuestionID)
	SELECT DISTINCT aq.QuestionID
	FROM @AQ aq
	INNER JOIN @TRNQ trnq ON aq.QuestionID = trnq.QuestionID

	RETURN
END
GO

