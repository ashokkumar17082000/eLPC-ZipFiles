/*  
///<SUMMARY>  
///DESCRIPTION                  : FUNCTION - [fnSplit]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS FUNCTION IS USED FOR SPLITTING/TRIMMING OF INPUT
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
EXEC [fnSplit]
*/
CREATE FUNCTION [fnSplit] (
	-- Add the parameters for the function here
	@input NVARCHAR(MAX)
	)
RETURNS @retBigint TABLE ([Value] [BIGINT] NOT NULL)
AS
BEGIN
	DECLARE @int NVARCHAR(MAX);
	DECLARE @pos [INT];

	SET @input = LTRIM(RTRIM(@input)) + ',';-- TRIMMING THE BLANK SPACES
	SET @pos = CHARINDEX(',', @input, 1);-- OBTAINING THE STARTING POSITION OF COMMA IN THE GIVEN STRING

	IF REPLACE(@input, ',', '') <> '' -- CHECK IF THE STRING EXIST FOR US TO SPLIT
	BEGIN
		WHILE @pos > 0
		BEGIN
			SET @int = LTRIM(RTRIM(LEFT(@input, @pos - 1)));-- GET THE 1ST INT VALUE TO BE INSERTED

			IF @int <> ''
			BEGIN
				INSERT INTO @retBigint (Value)
				VALUES (CAST(@int AS int));
			END;

			SET @input = RIGHT(@input, LEN(@input) - @pos);-- RESETTING THE INPUT STRING BY REMOVING THE INSERTED ONES
			SET @pos = CHARINDEX(',', @input, 1);-- OBTAINING THE STARTING POSITION OF COMMA IN THE RESETTED NEW STRING
		END;
	END;

	RETURN;
END;
GO


