/*  
///<SUMMARY>  
///DESCRIPTION                  : FUNCTION - [fnGetDateTime]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS FUNCTION IS USED FOR GET PLANT SPECIFIC DATE AND TIME FORMAT
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					25-JAN-2024			SUSHANT BARDHAN				LATEST ROLL OUT PLANTS UPDATE
ELPC_LH_003					29-APR-2024			SHUBHAM BARANGE 			LATEST ROLL OUT PLANTS UPDATE (APRIL)
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
select FormattedDateTime from [fnGetDateTime](1)
*/
CREATE FUNCTION [fnGetDateTime] (
	@PlantID INT
)
RETURNS @dateTime TABLE (FormattedDateTime DATETIME NOT NULL)
AS
BEGIN
	DECLARE @UTCDateTime DATETIME = GETUTCDATE();
	DECLARE @ConvertedZoneDateTime DATETIME;
	DECLARE @TimeZoneName NVARCHAR(100);
 
SET @TimeZoneName = CASE 
			--BhP, SgmP, BrhP, MlsP, WwP, HlP, HiP, SeP, TbP, WaP, EhP, RtP2, SzP, BaP, BarP, FeP, MagP, MrP, CC, NuP1, RzP, HoP1, PS, RBEF, OfoP, RBCB, FeP2, ZabP, VMSt, EHS, TraP, WeP, LzKa, LolP, EbhP ,KrnP ,Pl ,WoP ,PMQ1, TcP
			WHEN @PlantID IN (1, 4, 16, 37, 64, 5, 6, 55, 61, 63, 23, 53, 60, 11, 12, 24, 36, 38, 66, 41, 54, 29, 45, 51, 42, 48, 158, 159, 161, 163, 164, 165, 169, 170, 171,173,176,178,180,183)
				THEN 'W. Europe Standard Time'
			--Test, HtvP, MoP, RtP1, RBEM, GlnP, Abt, CCL5, BrmP, JhP, MtP, LeP, AnP, FraP, Che, GleP, DCET ,AfP ,HorP ,CCLW, NiP, UdiP, RvP, DCC ,NntP ,NuP2,SwP,Pas,HoP2,EcP,StP,LoP2,Ven,VxP,LoP1,MIIP,Try,RBHM,LoP3,BueP,PciP,RBBE,ITK
			WHEN @PlantID IN (80, 74, 75, 77, 81, 87, 102, 103, 82, 31, 92, 89, 104, 86, 106, 107, 109, 110, 114, 115,93, 99,100, 116 , 120 ,121, 122, 123, 127,128,129,130,133,136,137,138,140,141,144,147,148,153,157)
				THEN 'W. Europe Standard Time'
			--ChP, AdP, FleP, JpP, KwP, FniP ,Chr, LctP ,Bet, AiP, HSE5 ,Wel
			WHEN @PlantID IN (2, 8, 7, 33, 35, 112, 113, 88 ,134, 146, 160 ,181)
				THEN 'Eastern Standard Time'
			--CljP, BljP, BiP
			WHEN @PlantID IN (3, 14, 145)
				THEN 'GTB Standard Time'
			--AguP, QueP, SlpP, WEM ,CyP
			WHEN @PlantID IN (9, 47, 56, 168 ,177)
				THEN 'Central Standard Time (Mexico)'
			--AmaP, HcP, HmjP, RBIY, RBTY
			WHEN @PlantID IN (10, 26, 28, 52, 149)
				THEN 'SE Asia Standard Time'
			--SmrP, Eng2
			WHEN @PlantID IN (57, 85)
				THEN 'Russia Time Zone 3'
			--SzhB, SzhC, CgdP, NjP, JnaP, RBCW, RBCD, HzP, Wuj1, SzhA, PujP, QinP, XiP, Wuj2, PkP,DCEA,Szh5,RBCC,TIP,RBCS,SghP
			WHEN @PlantID IN (67, 68, 69, 70, 32, 50, 49, 72, 79, 78, 98, 46, 117, 118, 119,126,143,150,152,156, 182)
				THEN 'China Standard Time'	
			--CaP, CtP, SrbP, CaPT, PoP
			WHEN @PlantID IN (19, 21, 58, 95, 108)
				THEN 'E. South America Standard Time'
			--NaP, ChkP, BiD1, GanP, JaP, NhP1, ChiP ,PSIN, AhmP,RBDI, GSWH ,NhP2
			WHEN @PlantID IN (40, 20, 13, 25, 30, 76, 83, 131, 132,155, 162,172)
				THEN 'India Standard Time'
			--HigP, MusP, TgP, YhP, YorP ,TscP
			WHEN @PlantID IN (27, 39, 62, 71, 65, 125)
				THEN 'Tokyo Standard Time'
			--JuP1, CeaP
			WHEN @PlantID IN (34, 73)
				THEN 'Mountain Standard Time (Mexico)'
			--PgP1, PgP3, PgP2,RBHP,RBMC ,PgP5
			WHEN @PlantID IN (43, 44, 94 ,142, 151 ,174)
				THEN 'Singapore Standard Time'
			--BuP1, BuP3 ,BuP2, ManP ,TR20
			WHEN @PlantID IN (17, 18 ,124, 166 ,175)
				THEN 'Turkey Standard Time'
			--DaeP,RBKB
			WHEN @PlantID IN (22,154)
				THEN 'Korea Standard Time'
			--BrgP, GtlP ,DCGB, AvP,Owt
			WHEN @PlantID IN (15, 135, 139, 167 ,179)
				THEN 'GMT Standard Time'
			--Dev
			ELSE 'India Standard Time'
			END
 
	SET @ConvertedZoneDateTime = @UTCDateTime AT TIME ZONE 'UTC' AT TIME ZONE @TimeZoneName
 
	INSERT INTO @dateTime (FormattedDateTime)
	VALUES (@ConvertedZoneDateTime);
 
	RETURN;
END;
GO
