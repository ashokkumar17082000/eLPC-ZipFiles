/*  
///<SUMMARY>  
///DESCRIPTION                  : FUNCTION - [FN_GetNextHistoryDisplayID]
///AUTHOR                       : KARTHIKEYAN KANDASAMY
///CREATED DATE                 : 05-APR-2021
///SEE ALSO                     : THIS FUNCTION IS USED FOR GENERATE NEXT DISPLAYID FOR HISTORY ON THE GIVEN TABLE NAME
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_002					05-APR-2021			KARTHIKEYAN KANDASAMY		INITIAL VERSION

************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION
SELECT * from [FN_GetNextHistoryDisplayID] (1,'T_HST_ValueStreamTemplateHistory',1)
*/
CREATE FUNCTION [FN_GetNextHistoryDisplayID] (
	@PlantID INT
	,@TableName VARCHAR(100)
	,@TemplateID INT
	)
RETURNS @DisplayID TABLE ([DisplayID] INT NOT NULL)
AS
BEGIN
	DECLARE @GetDisplayID INT;

	SELECT @GetDisplayID = CASE @TableName
			WHEN 'T_HST_ValueStreamTemplateHistory'
				THEN (
						SELECT TOP 1 ValueStreamTemplateHistoryDisplayID
						FROM T_HST_ValueStreamTemplateHistory WITH(NOLOCK)
						WHERE PlantID = @PlantID
							AND ValueStreamTemplateID = @TemplateID
						ORDER BY ValueStreamTemplateHistoryID DESC
						)
			WHEN 'T_TRN_AssessorTemplateHistory'
				THEN (
						SELECT TOP 1 AssessorTemplateHistoryDisplayID
						FROM T_TRN_AssessorTemplateHistory  WITH(NOLOCK)
						WHERE PlantID = @PlantID
							AND AssessorTemplateID = @TemplateID
						ORDER BY AssessorTemplateHistoryID DESC
						)
			WHEN 'T_TRN_TagHistory'
				THEN (
						SELECT TOP 1 TagHistoryDisplayID
						FROM T_TRN_TagHistory  WITH(NOLOCK)
						WHERE PlantID = @PlantID
							AND TagID = @TemplateID
						ORDER BY TagHistoryID DESC
						)
			WHEN 'T_TRN_QuestionHistory'
				THEN (
						SELECT TOP 1 QuestionHistoryDisplayID
						FROM T_TRN_QuestionHistory  WITH(NOLOCK)
						WHERE PlantID = @PlantID
							AND QuestionID = @TemplateID
						ORDER BY QuestionHistoryID DESC
						)
			WHEN 'T_TRN_DataPoolHistory'
				THEN (
						SELECT TOP 1 DataPoolHistoryDisplayID
						FROM T_TRN_DataPoolHistory  WITH(NOLOCK)
						WHERE PlantID = @PlantID
							AND DataPoolID = @TemplateID
						ORDER BY DataPoolHistoryID DESC
						)
			END

	IF (
			@GetDisplayID IS NULL
			OR @GetDisplayID = 0
			)
	BEGIN
		SET @GetDisplayID = 1;
	END
	ELSE
	BEGIN
		SET @GetDisplayID = @GetDisplayID + 1;
	END

	INSERT INTO @DisplayID ([DisplayID])
	VALUES (@GetDisplayID);

	RETURN;
END
GO
