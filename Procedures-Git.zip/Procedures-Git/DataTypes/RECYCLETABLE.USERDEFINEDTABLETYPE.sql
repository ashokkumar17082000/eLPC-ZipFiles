/*  
///<SUMMARY>  
///DESCRIPTION                  : TABLE - [RecycleTable]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020  
///SEE ALSO                     : THIS TABLE USED TO STORE RECYCLE DETAILS
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY							CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY				INITIAL VERSION
************************************************************************************************************
--SAMPLE EXECUTION
SELECT * FROM [RecycleTable] WITH (NOLOCK)
*/
CREATE TYPE [RecycleTable] AS TABLE (
	[ID] [int] NULL
	,[PlantID] [int] NOT NULL
	,[ItemType] [nvarchar](max) NULL
	,[ItemName] [nvarchar](max) NULL
	,[DeletedBy] [nvarchar](max) NULL
	,[ModifiedBy] [nvarchar](max) NULL
	,[Deleted] [datetime] NULL
	,[Selected] [bit] NULL
	)
GO


