﻿namespace ELPC.Utility
{
    public static class Constants
    {
        //calendar
        public static readonly string USP_FETCHAUDITQUESTIONSBYAUDITANDASSESSORID = "USP_FetchAuditQuestionsByAuditAndAssessorID";
        public static readonly string USP_FETCHAUDITQUESTIONSBYAUDITANDTEMPLATEID = "USP_FetchAuditQuestionsByAuditAndTemplateID";

    }
}
