﻿using ELPC.Core;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;
using System.Xml.Serialization;
using Ical.Net;
using Ical.Net.DataTypes;
using Ical.Net.Serialization;
using System.Data;
using System.Reflection;
using System.DirectoryServices;
using System.Linq;
using System.Globalization;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace ELPC.Utility
{
    public class Utility
    {
        public static string _env;
        public static IConfiguration Configuration { get; set; }

        public static DirectoryEntry CreateActiveDirectoryConnection()
        {
            DirectoryEntry objDirEntry;
            try
            {
                var util = new Utility();

                string adUserName = util.GetConfigValue("ADUserName", null, false, true);
                string adUserPass = util.GetConfigValue("ADUserPass", null, false, true);
                string sActiveDirForest = util.GetConfigValue("ADHost", null, false, true );

                objDirEntry = new DirectoryEntry();
                objDirEntry.Path = $"LDAP://" + sActiveDirForest;
                objDirEntry.Username = adUserName;   //eLPC service account NTID
                objDirEntry.Password = adUserPass;  //eLPC service account Password
                objDirEntry.AuthenticationType = AuthenticationTypes.SecureSocketsLayer | AuthenticationTypes.Secure;
                return objDirEntry;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public string GetConfigValue(string key, string plantName = null, bool isPlantNameReq = true, bool isParentConfig = false)
        {
            try
            {
                var config = new ConfigurationBuilder()
                    .SetBasePath(Directory.GetCurrentDirectory())
                    .AddJsonFile("appsettings.json", false).Build();
                _env = config.GetSection("Environment").Value;

                if(isParentConfig)
                {
                    return config[key];
                }
            }
            catch (Exception ex)
            {
                _env = "DEV";
            }

            try
            {
                var builder = new ConfigurationBuilder()
                                    .SetBasePath(Directory.GetCurrentDirectory())
                                    .AddJsonFile($"appsettings.{_env}.json");

                Configuration = builder.Build();

                //var plantName = Configuration["PlantName"];

                var keyWithPlantName = key + "_" + plantName;
                if (isPlantNameReq && !string.IsNullOrEmpty(plantName))
                {
                    if (key == "ConnectionString")
                    {
                        var plainText = CryptoService.Decrypt(Configuration.GetValue<string>(Configuration[keyWithPlantName]));
                        return plainText.Trim() ?? "";
                    }
                    else
                    {
                        return Configuration[keyWithPlantName];
                    }
                }
                else
                {
                    if (key == "ConnectionString")
                    {
                        var plainText = CryptoService.Decrypt(Configuration.GetValue<string>(Configuration[key]));
                        return plainText.Trim() ?? "";
                    }
                    else
                    {
                        return Configuration[key];
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void AnswerSummaryMail(string subject, string emailtemplate, Dictionary<string, byte[]> emailimage, AuditAnswerSummary summary, List<AuditSummaryQuestionAnswers> answers)
        {
            try
            {

                MailMessage msg = new MailMessage();

                if (!string.IsNullOrEmpty(summary.From))
                {
                    msg.From = new MailAddress(summary.From);
                }
                else
                {
                   // msg.From = new MailAddress("COB_RBEI_eLPC-Support@bcn.bosch.com", "eLPCSupport");
                }


                if (!string.IsNullOrEmpty(summary.To))
                {
                    foreach (var address in summary.To.Split(new[] { ";" }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        AddToEmailAdress(msg, address);
                    }
                }

                if (!string.IsNullOrEmpty(summary.Cc))
                {
                    foreach (var address in summary.Cc.Split(new[] { ";" }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        AddCCEmailAdress(msg, address);
                    }
                }


                msg.Subject = subject.Replace("((TagName))", ConvertToPlainText(summary.TagName)).Replace("((AuditorSurveyType))", string.IsNullOrEmpty(summary.TagTypeName) ? "" : " - " + ConvertToPlainText(summary.TagTypeName));

                msg.IsBodyHtml = true;

                SmtpClient mailobj = new SmtpClient();
                mailobj.Host = new Utility().GetConfigValue("SMTPServerHost", null, false); //"rb-smtp-int.bosch.com";

                emailtemplate = emailtemplate.Replace("((TagName))", ConvertToPlainText(summary.TagName));
                emailtemplate = emailtemplate.Replace("((AuditorSurveyType))", string.IsNullOrEmpty(summary.TagTypeName) ? "" : summary.TagTypeName);
                emailtemplate = emailtemplate.Replace("((PlantCode))", string.IsNullOrEmpty(summary.PlantCode) ? "" : " - " + summary.PlantCode);
                emailtemplate = emailtemplate.Replace("((LeadAuditor))", string.IsNullOrEmpty(summary.LeadAuditor) ? "" : summary.LeadAuditor);
                emailtemplate = emailtemplate.Replace("((Attendees))", string.IsNullOrEmpty(summary.Attendees) ? "" : summary.Attendees?.Replace(Environment.NewLine, "<br>"));
                emailtemplate = emailtemplate.Replace("((ValueStream))", string.IsNullOrEmpty(summary.ValueStreamText) ? "" : summary.ValueStreamText);
                emailtemplate = emailtemplate.Replace("((AnsweredTimestamp))", summary.AnsweredTime.ToString("dd-MM-yyyy hh:mm tt", CultureInfo.InvariantCulture));


                msg.Body = emailtemplate;

                MemoryStream streamBitmap = new MemoryStream(emailimage["header"]);
                var imageToInline = new LinkedResource(streamBitmap, MediaTypeNames.Image.Jpeg);
                imageToInline.ContentId = "headerimg";

                AlternateView alternateView = AlternateView.CreateAlternateViewFromString(emailtemplate, null, "text/html");
                alternateView.LinkedResources.Add(imageToInline);

                msg.AlternateViews.Add(alternateView);

                {
                    byte[] fileContents;

                    using (ExcelPackage pck = new ExcelPackage())
                    {

                        var worksheet_DataPool = pck.Workbook.Worksheets.Add("Answers");

                        var dt = answers.ToDataTable();
                        dt.Columns.Remove("QuestionID");
                        dt.AcceptChanges();

                        worksheet_DataPool.Cells["A1"].LoadFromDataTable(dt, true);


                        var columnCount = dt.Columns.Count;

                        var cellRange = worksheet_DataPool.Cells[1, 1, 1, columnCount];
                        cellRange.Style.Font.Bold = true;
                        cellRange.Style.Fill.PatternType = ExcelFillStyle.Solid;
                        cellRange.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Orange);

                        worksheet_DataPool.Cells[worksheet_DataPool.Dimension.Address].AutoFitColumns();

                        int colNumber = 0;

                        foreach (DataColumn col in dt.Columns)
                        {
                            colNumber++;
                            if (col.DataType == typeof(DateTime))
                            {
                                worksheet_DataPool.Column(colNumber).Style.Numberformat.Format = "dd-MM-yyyy hh:mm tt";
                            }
                        }

                        fileContents = pck.GetAsByteArray();
                        MemoryStream ms = new MemoryStream(fileContents);

                        string fileName = summary.AnsweredTime.ToString("yyyy-MM-dd HH.mm_") + summary.TagName + ".xlsx";
                        System.Net.Mail.Attachment objAtt = new System.Net.Mail.Attachment(ms, fileName);

                        msg.Attachments.Add(objAtt);
                    }
                }

                mailobj.Send(msg);
            }
            catch (Exception ex)
            {
                string userMessage = "subject:" + JsonSerializer.Serialize(subject, new JsonSerializerOptions { WriteIndented = true }) + Environment.NewLine +
                                                  "summary:" + JsonSerializer.Serialize(summary, new JsonSerializerOptions { WriteIndented = true }) + Environment.NewLine +
                                                  "answers:" + JsonSerializer.Serialize(answers, new JsonSerializerOptions { WriteIndented = true }) + Environment.NewLine +
                                                  "emailtemplate:" + JsonSerializer.Serialize(emailtemplate, new JsonSerializerOptions { WriteIndented = true }) + Environment.NewLine;
                ex.Data.Add("UserMessage", userMessage);
                throw ex;
            }
        }

        public static void DeviationMail(string plantCode, Deviation deviation,string ccmail, string fromadd, string recmail, string subject, string emailtemplate, Dictionary<string, byte[]> emailimage)
        {
            try
            {

                MailMessage msg = new MailMessage();
                if (!String.IsNullOrEmpty(ccmail))
                {
                    var emailAddress = ccmail.Split(';');
                    foreach (var email in emailAddress)
                    {
                        msg.CC.Add(email);
                    }
                }

                if (!string.IsNullOrEmpty(fromadd))
                {
                    msg.From = new MailAddress(fromadd);
                }
                else
                {
                   // msg.From = new MailAddress("COB_RBEI_eLPC-Support@bcn.bosch.com", "eLPCSupport");
                }


                if (!string.IsNullOrEmpty(recmail))
                {
                    msg.To.Add(recmail);
                    AddToEmailAdress(msg, deviation.ResponsibleEmployeeEmailAddress);
                }
                else
                {
                    if (!string.IsNullOrEmpty(deviation.ResponsibleEmployeeEmailAddress))
                    {
                        AddToEmailAdress(msg, deviation.ResponsibleEmployeeEmailAddress);
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(deviation.UserEmailAddress))
                        {
                            AddToEmailAdress(msg, deviation.UserEmailAddress);
                        }
                        else
                        {
                           // msg.To.Add("COB_RBEI_eLPC-Support@bcn.bosch.com");
                        }
                    }
                }

                AddCCEmailAdress(msg, fromadd);

                AddCCEmailAdress(msg, deviation.UserEmailAddress);

                AddCCEmailAdress(msg, deviation.ManagerEmailAddress);

                msg.Subject = ConvertToPlainText(subject);

                msg.IsBodyHtml = true;

                SmtpClient mailobj = new SmtpClient();
                mailobj.Host = new Utility().GetConfigValue("SMTPServerHost", null, false); //"rb-smtp-int.bosch.com";

                //StringBuilder str = new StringBuilder();
                //byte[] byteArray = Encoding.ASCII.GetBytes(str.ToString());
                //MemoryStream stream = new MemoryStream(byteArray);
                //string messageTemplate = string.Empty;

                emailtemplate = emailtemplate.Replace("((PlantCode))", string.IsNullOrEmpty(plantCode) ? "" : " - " + plantCode);
                emailtemplate = emailtemplate.Replace("((CreatedBy_Name))", deviation.CreatedBy_Name);
                emailtemplate = emailtemplate.Replace("((CreatedBy_NTID))", deviation.CreatedBy_NTID);
                emailtemplate = emailtemplate.Replace("((ValueStreamName))", deviation.ValueStreamName);
                emailtemplate = emailtemplate.Replace("((TagName))", deviation.TagName);
                emailtemplate = emailtemplate.Replace("((QuestionID))", "Q" + deviation.QuestionDisplayID.ToString());
                if (deviation.selectedtag != null)
                {

                    emailtemplate = emailtemplate.Replace("((selectedtag))", deviation.selectedtag.ToString());
                }
                else
                {
                    emailtemplate = emailtemplate.Replace("((selectedtag))",' '.ToString());
                }
                emailtemplate = emailtemplate.Replace("((QuestionText))", deviation.QuestionText?.Replace(Environment.NewLine, "<br>")?.Replace("\n", "<br>"));
                emailtemplate = emailtemplate.Replace("((ChoiceAnswer))", deviation.QuestionChoiceAnswer?.Replace(Environment.NewLine, "<br>")?.Replace("\n", "<br>"));
                emailtemplate = emailtemplate.Replace("((LinkedTags))", deviation.QuestionLinkedTags);
                emailtemplate = emailtemplate.Replace("((DeviationDescription))", deviation.DeviationDescription?.Replace(Environment.NewLine, "<br>")?.Replace("\n", "<br>"));
                emailtemplate = emailtemplate.Replace("((DetectedByEmployee))", deviation.CreatedByEmployee);
                emailtemplate = emailtemplate.Replace("((StartDate))", deviation.StartDate.ToString("dd-MM-yyyy"));
                emailtemplate = emailtemplate.Replace("((DueDate))", deviation.EndDate.ToString("dd-MM-yyyy"));
                emailtemplate = emailtemplate.Replace("((OwnerName))", deviation.Owner);
                emailtemplate = emailtemplate.Replace("((ResponsibleEmployee))", deviation.ResponsibleEmployee);
                emailtemplate = emailtemplate.Replace("((AdditionalEmployee))", deviation.UserName);
                emailtemplate = emailtemplate.Replace("((AppUrlLink))", deviation.PathUrl);

                string questionID = string.Empty;
              
                if (!string.IsNullOrEmpty(deviation.UserName))
                {
                    emailtemplate = emailtemplate.Replace("span style=\"display:none\"", "span");

                    emailtemplate = emailtemplate.Replace("<tr style=\"height:13.5pt;display: none;\">", "<tr style=\"height:13.5pt;\">");
                }
                else
                {

                    

                    emailtemplate = emailtemplate.Replace("<TagTR>", "<!--[if !mso 9]><!-->");
                    emailtemplate = emailtemplate.Replace("</TagTR>", "<!--<![endif]-->");

                   

                }
                if (!string.IsNullOrEmpty(deviation.TagName))
                {
                    emailtemplate = emailtemplate.Replace("span style=\"display:none\"", "span");

                    emailtemplate = emailtemplate.Replace("<tr style=\"height:13.5pt;display: none;\">", "<tr style=\"height:13.5pt;\">");
                }
                else
                {

                    emailtemplate = emailtemplate.Replace("<EmpTR>", "<!--[if !mso 9]><!-->");
                    emailtemplate = emailtemplate.Replace("</EmpTR>", "<!--<![endif]-->");
                }

                    if (deviation.QuestionID != 0)
                {
                    emailtemplate = emailtemplate.Replace("span style=\"display:none\"", "span");

                    emailtemplate = emailtemplate.Replace("<tr style=\"height:13.5pt;display: none;\">", "<tr style=\"height:13.5pt;\">");
                }
                else
                {
                    emailtemplate = emailtemplate.Replace("<question>", "<!--[if !mso 9]><!-->");
                    emailtemplate = emailtemplate.Replace("</question>", "<!--<![endif]-->");

                    emailtemplate = emailtemplate.Replace("<questionTR>", "<!--[if !mso 9]><!-->");
                    emailtemplate = emailtemplate.Replace("</questionTR>", "<!--<![endif]-->");
                }

                // Direct Deviation & OPL Required - SOPL API infterface communication success
                if (!string.IsNullOrEmpty(deviation.SuperOPLURL))
                {
                    emailtemplate = emailtemplate.Replace("((SuperOPLLink))", deviation.SuperOPLURL);

                    emailtemplate = emailtemplate.Replace("1px; display:none;\">", "1px;\">");

                    emailtemplate = emailtemplate.Replace("<superoplForm>", "<!--[if !mso 9]><!-->");
                    emailtemplate = emailtemplate.Replace("</superoplForm>", "<!--<![endif]-->");
                }
                else
                {
                    // DeviationTypeID 
                    // 99 - Document a deviation page
                    // 1  - No
                    // 2  - Yes, Don't create corrective measure (Email - Yes, SOPL - No)
                    // 3  - Yes, Create corrective measure (Email - Yes, SOPL - Yes)
                    // Direct Deviation & OPL Required - SOPL API infterface communication failure

                    if (deviation.DeviationTypeID == 99 || deviation.DeviationTypeID == 3)
                    {
                        emailtemplate = emailtemplate.Replace("((SuperOPLLink))", deviation.SuperOPLNewTaskURL);
                        emailtemplate = emailtemplate.Replace("((SuperOPLNewTask))", deviation.SuperOPLNewTaskURL + "?do=oplTaskEdit ");

                        emailtemplate = emailtemplate.Replace("0px; display:none;\">", "0px;\">");

                        emailtemplate = emailtemplate.Replace("<superopl>", "<!--[if !mso 9]><!-->");
                        emailtemplate = emailtemplate.Replace("</superopl>", "<!--<![endif]-->");
                    }
                    else
                    {
                        emailtemplate = emailtemplate.Replace("<superoplForm>", "<!--[if !mso 9]><!-->");
                        emailtemplate = emailtemplate.Replace("</superoplForm>", "<!--<![endif]-->");

                        emailtemplate = emailtemplate.Replace("<superopl>", "<!--[if !mso 9]><!-->");
                        emailtemplate = emailtemplate.Replace("</superopl>", "<!--<![endif]-->");
                    }

                }

                //Show retry display message in email content based on schedulerID
                if (deviation.SchedulerID != 0)
                {
                    emailtemplate = emailtemplate.Replace("<schedulerRetryMessage><span style=\"font-size:10.5pt;font-family:Arial,sans-serif; color:#78be20;display:none;\">", "<schedulerRetryMessage><span style=\"font-size:10.5pt;font-family:Arial,sans-serif; color:#78be20;\">");
                }
                else
                {
                    emailtemplate = emailtemplate.Replace("<schedulerRetryMessage>", "<!--[if !mso 9]><!-->");
                    emailtemplate = emailtemplate.Replace("</schedulerRetryMessage>", "<!--<![endif]-->");
                }

                msg.Body = emailtemplate;

                MemoryStream streamBitmap = new MemoryStream(emailimage["header"]);
                var imageToInline = new LinkedResource(streamBitmap, MediaTypeNames.Image.Jpeg);
                imageToInline.ContentId = "headerimg";

                AlternateView alternateView = AlternateView.CreateAlternateViewFromString(emailtemplate, null, "text/html");
                alternateView.LinkedResources.Add(imageToInline);

                msg.AlternateViews.Add(alternateView);

                string folderName = "ElpcUpload";

                string webRootPath = new Utility().GetConfigValue("PathName", plantCode);
                string newPath = Path.Combine(webRootPath, folderName);
                if (deviation.HintImages != null && deviation.HintImages.Count > 0)
                {
                    foreach (var file in deviation.HintImages)
                    {
                        string path = Path.Combine(newPath, file.ImageTitle);
                        System.Net.Mail.Attachment data = new System.Net.Mail.Attachment(path, MediaTypeNames.Application.Octet);
                        msg.Attachments.Add(data);
                    }
                }

                mailobj.Send(msg);

            }
            catch (Exception ex)
            {
                string userMessage = "plantCode:" + JsonSerializer.Serialize(plantCode, new JsonSerializerOptions { WriteIndented = true }) + Environment.NewLine +
                                   "deviation:" + JsonSerializer.Serialize(deviation, new JsonSerializerOptions { WriteIndented = true }) + Environment.NewLine +
                                   "fromadd:" + JsonSerializer.Serialize(fromadd, new JsonSerializerOptions { WriteIndented = true }) + Environment.NewLine +
                                   "recmail:" + JsonSerializer.Serialize(recmail, new JsonSerializerOptions { WriteIndented = true }) + Environment.NewLine +
                                   "subject:" + JsonSerializer.Serialize(subject, new JsonSerializerOptions { WriteIndented = true }) + Environment.NewLine;
                ex.Data.Add("UserMessage", userMessage);
                throw ex;
            }
        }

        private static string AssignTemplateValues(string template, Audit audit)
        {
            template = template.Replace("((Organizer))", audit.Organizer);
            template = template.Replace("((RequiredAttendees))", string.Join(";", audit.RequiredAttendees.AsEnumerable().Select(r => r.UserName)));
            template = template.Replace("((OptionalAttendees))", string.Join(";", audit.OptionalAttendees.AsEnumerable().Select(r => r.UserName)));
            template = template.Replace("((TagName))", ConvertToPlainText(audit.TagName));
            template = template.Replace("((ValueStreamName))", audit.ValueStreamName);
            template = template.Replace("((LocationName))", audit.Location);
            template = template.Replace("((StartDate))", audit.StartDate.ToString("dd-MM-yyyy", CultureInfo.InvariantCulture));
            template = template.Replace("((EndDate))", audit.EndDate.ToString("dd-MM-yyyy", CultureInfo.InvariantCulture));
            template = template.Replace("((Time))", new DateTime().Add(audit.StartTime).ToString("hh:mm tt", CultureInfo.InvariantCulture) + " - " + new DateTime().Add(audit.EndTime).ToString("hh:mm tt", CultureInfo.InvariantCulture));
            template = template.Replace("((CalendarUrl))", audit.CalendarUrl);
            template = template.Replace("((Remarks))", audit.Remarks);
            template = template.Replace("((PlantCode))", string.IsNullOrEmpty(audit.PlantCode) ? "" : " - " + audit.PlantCode);
            template = template.Replace("((AuditorSurveyType))", string.IsNullOrEmpty(audit.TagTypeName) ? "" : " - " + audit.TagTypeName);

            return template;
        }

        public static void SendMail(Audit audit, string fromadd, string recmail, string ccmail, string subjectTemplate, string emailtemplate, string icstemplate, Dictionary<string, byte[]> emailimage)
        {
            try
            {
                MailMessage msg = new MailMessage();
                msg.From = new MailAddress(fromadd);

                if (!String.IsNullOrEmpty(recmail))
                {
                    var emailAddress = recmail.Split(';');
                    foreach (var email in emailAddress)
                    {
                        msg.To.Add(email);
                    }
                }

                if (!String.IsNullOrEmpty(ccmail))
                {
                    var emailAddress = ccmail.Split(';');
                    foreach (var email in emailAddress)
                    {
                        msg.CC.Add(email);
                    }
                }

                if (!msg.To.Contains(msg.From) && !msg.CC.Contains(msg.From))
                {
                    msg.CC.Add(fromadd);
                }

                msg.Subject = subjectTemplate.Replace("((TagName))", ConvertToPlainText(audit.TagName)).Replace("((AuditorSurveyType))", string.IsNullOrEmpty(audit.TagTypeName) ? "" : " - " + ConvertToPlainText(audit.TagTypeName));
                msg.IsBodyHtml = true;

                SmtpClient mailobj = new SmtpClient();
                mailobj.Host = new Utility().GetConfigValue("SMTPServerHost", null, false); //"rb-smtp-int.bosch.com";

                //for audit email template 
                MemoryStream streamBitmap = new MemoryStream(emailimage["header"]);
                var imageToInline = new LinkedResource(streamBitmap, MediaTypeNames.Image.Jpeg);
                imageToInline.ContentId = "headerimg";

                emailtemplate = AssignTemplateValues(emailtemplate, audit);
                icstemplate = AssignTemplateValues(icstemplate, audit);

                //msg.Body = emailtemplate;

                AlternateView alternateView = AlternateView.CreateAlternateViewFromString(emailtemplate, null, "text/html");
                alternateView.LinkedResources.Add(imageToInline);

                msg.AlternateViews.Add(alternateView);

                //for ics 
                //email functionality
                var calendar = new Ical.Net.Calendar();
                var eventObject = GetCalendarEvent(audit, msg.Subject, icstemplate);

                calendar.Events.Add(eventObject);

                var serializer = new CalendarSerializer(new SerializationContext());
                var serializedCalendar = serializer.SerializeToString(calendar);
                //serializedCalendar = serializedCalendar.Replace("X-ALT-DESC:FMTTYPE=text/html", "X-ALT-DESC;FMTTYPE=text/html");
                var bytesCalendar = Encoding.UTF8.GetBytes(serializedCalendar);
                MemoryStream ms = new MemoryStream(bytesCalendar);
                System.Net.Mail.Attachment attachment = new System.Net.Mail.Attachment(ms, "eLPC_Audit.ics", "text/calendar");

                msg.Attachments.Add(attachment);


                mailobj.Send(msg);

            }
            catch (Exception ex)
            {
                string userMessage = "audit:" + JsonSerializer.Serialize(audit, new JsonSerializerOptions { WriteIndented = true }) + Environment.NewLine +
                                   "fromadd:" + JsonSerializer.Serialize(fromadd, new JsonSerializerOptions { WriteIndented = true }) + Environment.NewLine +
                                   "recmail:" + JsonSerializer.Serialize(recmail, new JsonSerializerOptions { WriteIndented = true }) + Environment.NewLine +
                                   "ccmail:" + JsonSerializer.Serialize(ccmail, new JsonSerializerOptions { WriteIndented = true }) + Environment.NewLine +
                                   "subjectTemplate:" + JsonSerializer.Serialize(subjectTemplate, new JsonSerializerOptions { WriteIndented = true }) + Environment.NewLine +
                                   "icstemplate:" + JsonSerializer.Serialize(icstemplate, new JsonSerializerOptions { WriteIndented = true }) + Environment.NewLine;
                ex.Data.Add("UserMessage", userMessage);
                throw ex;
            }
        }


        public static Ical.Net.CalendarComponents.CalendarEvent GetCalendarEvent(Audit audit, string subject, string icstemplate = "")
        {
            //calendar.AddLocalTimeZone(DateTime.Now.AddYears(-2), false);
            //string localTimeZone = TimeZoneInfo.Local.StandardName;

            //audit.StartDate.Date.Add(audit.StartTime);
            //audit.EndDate.Date.Add(audit.EndTime);
            IDateTime endDateTime = null;
            if(audit.IsAllDay)
            {
                endDateTime = new CalDateTime(audit.EndDate.Year, audit.EndDate.Month, audit.EndDate.Day).AddDays(1);
            }
            else if (audit.IsRecurring)
            {
                endDateTime = new CalDateTime(audit.StartDate.Year, audit.StartDate.Month, audit.StartDate.Day, audit.EndTime.Hours, audit.EndTime.Minutes, 0);
            }
            else
            {
                endDateTime = new CalDateTime(audit.EndDate.Year, audit.EndDate.Month, audit.EndDate.Day, audit.EndTime.Hours, audit.EndTime.Minutes, 0);
            }
            var eventObject = new Ical.Net.CalendarComponents.CalendarEvent
            {
                Class = "PUBLIC",
                Summary = subject,
                Created = new CalDateTime(DateTime.Now),
                Description = icstemplate,
                Start = new CalDateTime(audit.StartDate.Year, audit.StartDate.Month, audit.StartDate.Day, audit.StartTime.Hours, audit.StartTime.Minutes, 0),
                End = endDateTime,

                //Start = new CalDateTime(audit.StartDate.Date.Add(audit.StartTime)),
                //End = new CalDateTime(audit.StartDate.Date.Add(audit.EndTime)),
                //Start = new CalDateTime(DateTime.Parse("2021-05-27 8 AM")),
                //End= new CalDateTime(DateTime.Parse("2021-05-27 9 AM")),
                Sequence = 0,
                Uid = Guid.NewGuid().ToString(),
                Location = audit.Location,
                IsAllDay = audit.IsAllDay
            };




            if (audit.IsRecurring && !audit.IsAllDay)
            {
                //If recurring event, the end date time is same day with timing difference
                //eventObject.End = new CalDateTime(audit.StartDate.Year, audit.StartDate.Month, audit.StartDate.Day, audit.EndTime.Hours, audit.EndTime.Minutes, 0);
                //eventObject.RecurrenceRules = new List<RecurrencePattern>();
                var recurrencePattern = new RecurrencePattern
                {
                    Until = new DateTime(audit.EndDate.Year, audit.EndDate.Month, audit.EndDate.Day, audit.EndTime.Hours, audit.EndTime.Minutes, 0),
                    Interval = audit.Recurrence_Interval
                };

                switch ((RecurrenceType)audit.Recurrence_TypeId)
                {
                    case RecurrenceType.Daily_NDays:
                        recurrencePattern.Frequency = FrequencyType.Daily;
                        break;
                    case RecurrenceType.Weekly_XDayofWeek:
                        recurrencePattern.Frequency = FrequencyType.Weekly;
                        recurrencePattern.ByDay = GetRecursiveByDay(audit.Recurrence_DayOfWeek);
                        break;
                    case RecurrenceType.Monthly_DayOfMonth:
                        recurrencePattern.Frequency = FrequencyType.Monthly;
                        recurrencePattern.ByMonthDay = new List<int>() { audit.Recurrence_DayOfMonth };
                        break;
                    case RecurrenceType.Monthly_Nth_DayOfMonth:
                        recurrencePattern.Frequency = FrequencyType.Monthly;
                        recurrencePattern.ByDay = GetRecursiveByDay("1,1,1,1,1,1,1");
                        recurrencePattern.BySetPosition = new List<int>() { audit.Recurrence_WeekOfMonth };
                        break;
                    case RecurrenceType.Monthly_Nth_WeekDayOfMonth:
                        recurrencePattern.Frequency = FrequencyType.Monthly;
                        recurrencePattern.ByDay = GetRecursiveByDay("0,1,1,1,1,1,0");
                        recurrencePattern.BySetPosition = new List<int>() { audit.Recurrence_WeekOfMonth };
                        break;
                    case RecurrenceType.Monthly_Nth_WeekendDayOfMonth:
                        recurrencePattern.Frequency = FrequencyType.Monthly;
                        recurrencePattern.ByDay = GetRecursiveByDay("1,0,0,0,0,0,1");
                        recurrencePattern.BySetPosition = new List<int>() { audit.Recurrence_WeekOfMonth };
                        break;
                    case RecurrenceType.Monthly_Nth_XDayOfMonth:
                        recurrencePattern.Frequency = FrequencyType.Monthly;
                        recurrencePattern.ByDay = GetRecursiveByDay(audit.Recurrence_DayOfWeek, audit.Recurrence_WeekOfMonth);
                        break;
                    case RecurrenceType.Yearly_DayOfMonth:
                        recurrencePattern.Frequency = FrequencyType.Yearly;
                        recurrencePattern.ByMonthDay = new List<int>() { audit.Recurrence_DayOfMonth };
                        break;
                    case RecurrenceType.Yearly_Nth_DayOfMonth:
                        recurrencePattern.Frequency = FrequencyType.Yearly;
                        recurrencePattern.ByDay = GetRecursiveByDay("1,1,1,1,1,1,1");
                        recurrencePattern.ByMonth = new List<int>() { audit.Recurrence_MonthOfYear };
                        recurrencePattern.BySetPosition = new List<int>() { audit.Recurrence_WeekOfMonth };
                        break;
                    case RecurrenceType.Yearly_Nth_WeekDayOfMonth:
                        recurrencePattern.Frequency = FrequencyType.Yearly;
                        recurrencePattern.ByDay = GetRecursiveByDay("0,1,1,1,1,1,0");
                        recurrencePattern.ByMonth = new List<int>() { audit.Recurrence_MonthOfYear };
                        recurrencePattern.BySetPosition = new List<int>() { audit.Recurrence_WeekOfMonth };
                        break;
                    case RecurrenceType.Yearly_Nth_WeekendDayOfMonth:
                        recurrencePattern.Frequency = FrequencyType.Yearly;
                        recurrencePattern.ByDay = GetRecursiveByDay("1,0,0,0,0,0,1");
                        recurrencePattern.ByMonth = new List<int>() { audit.Recurrence_MonthOfYear };
                        recurrencePattern.BySetPosition = new List<int>() { audit.Recurrence_WeekOfMonth };
                        break;
                    case RecurrenceType.Yearly_Nth_XDayOfMonth:
                        recurrencePattern.Frequency = FrequencyType.Yearly;
                        recurrencePattern.ByDay = GetRecursiveByDay(audit.Recurrence_DayOfWeek);
                        recurrencePattern.ByMonth = new List<int>() { audit.Recurrence_MonthOfYear };
                        recurrencePattern.BySetPosition = new List<int>() { audit.Recurrence_WeekOfMonth };
                        break;
                }
                eventObject.RecurrenceRules = new List<RecurrencePattern>() { recurrencePattern };
            }

            return eventObject;

            //// Adding Required Attendees in icalendar
            //audit.RequiredAttendees.ForEach(r => 
            //eventObject.Attendees.Add(new Attendee()
            //{
            //    CommonName = r.UserName ?? "",
            //    Role = ParticipationRole.RequiredParticipant,
            //    Rsvp = true,
            //    Value = new Uri($"mailto:{r.EmailAddress}")
            //}));

            //// Adding Optional Attendees in icalendar
            //audit.OptionalAttendees.ForEach(r =>
            //eventObject.Attendees.Add(new Attendee()
            //{
            //    CommonName = r.UserName ?? "",
            //    Role = ParticipationRole.OptionalParticipant,
            //    Rsvp = true,
            //    Value = new Uri($"mailto:{r.EmailAddress}")
            //}));
        }

        public static void AddToEmailAdress(MailMessage msg, string emailID)
        {
            if (!string.IsNullOrEmpty(emailID) && !msg.To.Contains(new MailAddress(emailID)) && !msg.CC.Contains(new MailAddress(emailID)))
            {
                msg.To.Add(emailID);
            }
        }

        public static void AddCCEmailAdress(MailMessage msg, string emailID)
        {
            if (!string.IsNullOrEmpty(emailID) && !msg.To.Contains(new MailAddress(emailID)) && !msg.CC.Contains(new MailAddress(emailID)))
            {
                msg.CC.Add(emailID);
            }
        }

        public static List<WeekDay> GetRecursiveByDay(string DayOfTheWeek, int WeekOfTheMonth = 0)
        {
            var weekDays = new List<WeekDay>();
            var selectedDays = DayOfTheWeek.Split(',');


            for (int i = 0; i < selectedDays.Length; i++)
            {
                if (selectedDays[i].Trim() == "1")
                {
                    var d = new WeekDay((DayOfWeek)i);
                    if (WeekOfTheMonth != 0)
                        d.Offset = WeekOfTheMonth;
                    weekDays.Add(d);
                }
            }
            return weekDays;
        }

        //****generic Method to convert into List************
        public static List<T> ConvertDataTable<T>(DataTable dt)
        {
            List<T> data = new List<T>();
            foreach (DataRow row in dt.Rows)
            {
                T item = GetItem<T>(row);
                data.Add(item);
            }
            return data;
        }

        private static T GetItem<T>(DataRow dr)
        {
            Type temp = typeof(T);
            T obj = Activator.CreateInstance<T>();


            foreach (DataColumn column in dr.Table.Columns)
            {
                foreach (PropertyInfo pro in temp.GetProperties())
                {
                    if (pro.Name == column.ColumnName)
                    {
                        //if (pro.PropertyType == typeof(string))
                        //{
                        //    pro.SetValue(obj, Convert.ChangeType(dr[column.ColumnName], pro.PropertyType), null);
                        //}
                        //else if (pro.PropertyType == typeof(bool))
                        //{

                        //    pro.SetValue(obj, Convert.ChangeType(dr[column.ColumnName], pro.PropertyType), false);
                        //}

                        Type t = Nullable.GetUnderlyingType(pro.PropertyType) ?? pro.PropertyType;

                        object safeValue = null;
                        if (dr[column.ColumnName] != DBNull.Value)
                        {
                            if (t.FullName == "System.DateTime")
                                safeValue = (obj == null) ? null : Convert.ChangeType(dr[column.ColumnName], t, CultureInfo.CreateSpecificCulture("de-DE")); //For the format dd.mm.yyyy
                            else
                                safeValue = (obj == null) ? null : Convert.ChangeType(dr[column.ColumnName], t);

                        }

                        pro.SetValue(obj, safeValue, null);



                    }
                    else
                        continue;
                }
            }
            return obj;
        }

        public static DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties by using reflection   
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names  
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {

                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }

        public static String ObjectToXMLGeneric<T>(T filter)
        {

            string xml = null;
            using (StringWriter sw = new StringWriter())
            {

                XmlSerializer xs = new XmlSerializer(typeof(T));
                xs.Serialize(sw, filter);
                try
                {
                    xml = sw.ToString();

                }
                catch (Exception e)
                {
                    throw e;
                }
            }
            return xml;
        }

        public static string ConvertToPlainText(string str)
        {
            if(string.IsNullOrEmpty(str))
            {
                return string.Empty;
            }

            string replacedValue = Regex.Replace(str, @"\r\n|\n\r|\n\t|\t\n|\r|\n|\t", " ");
            return replacedValue;
        }

        //************************************Generic Methods Ends here************

        public static List<Audit> GetCalendarOccurances(List<Audit> auditAnswers, string module, string currentYear, string currentMonth)
        {
            List<Audit> auditAnswersWithStatus = new List<Audit>();

            try
            {
                List<Audit> ExpandedAudits = new List<Audit>();

                var NonRecurrenceEvents = auditAnswers.Where(r => !r.IsRecurring).ToList(); // Fetch nonreccurence events answers from audit answer table
                var RecurrenceEvents = auditAnswers.Where(r => r.IsRecurring).ToList(); // Fetch nonreccurence events answers from audit answer table

                var RecurrenceAuditIDs = RecurrenceEvents.Select(r => r.AuditID).Distinct(); // Get Distinct AuidtIDs for reccurence events

                foreach (var auditID in RecurrenceAuditIDs)
                {
                    var RecurrenceEventsByAuditID = RecurrenceEvents.Where(r => r.AuditID == auditID); // Filter current audit recurrent events

                    var eventObject = GetCalendarEvent(RecurrenceEventsByAuditID.FirstOrDefault(), ""); // Find the reccurence event details based on recurrence pattern
                    var calendar = new Ical.Net.Calendar();
                    calendar.Events.Add(eventObject);
                    if (module == "Calendar")
                    {
                        int month = Int32.Parse(currentMonth);
                        int year = Int32.Parse(currentYear);
                        DateTime firstDay = new DateTime(year, month, 1);
                        //DateTime lastDay = new DateTime(result, month, 31);
                         DateTime date = new DateTime(year, month, 1);
                        var firstDayOfMonth = new DateTime(date.Year, date.Month, 1);
                        var lastDayOfMonth = firstDayOfMonth.AddMonths(1);
                        var calenderOccurrences = calendar.GetOccurrences(firstDay, lastDayOfMonth); // Reccurenc pattern results as indvidual date object

                        foreach (var occurrence in calenderOccurrences)
                        {
                            // Veify any answers made on current occurence date from series
                            // If no answer entry for occurrence date then create a new audit object
                            if (!RecurrenceEventsByAuditID.Any(r => r.AuditID == auditID && r.AnsweredTimeStamp == occurrence.Period.StartTime.Date))
                            {
                                var existingItemsInListByAuditID = RecurrenceEvents.FirstOrDefault(r => r.AuditID == auditID);
                                var json = JsonSerializer.Serialize(existingItemsInListByAuditID);
                                var audit = JsonSerializer.Deserialize<Audit>(json);

                                ExpandedAudits.Add(AuditDataAssignment(audit, occurrence, false));
                            }
                            else
                            {
                                if (module == "Calendar")
                                {
                                    // If answer entry found & avaliable for occurrence date then order by answered rows and take first for status
                                    var sameDateSortedEvent = RecurrenceEvents.Where(r => r.AuditID == auditID && r.AnsweredTimeStamp == occurrence.Period.StartTime.Date).OrderByDescending(r => r.IsAuditCompleted).FirstOrDefault();
                                    ExpandedAudits.Add(AuditDataAssignment(sameDateSortedEvent, occurrence));
                                }
                                else if (module == "Report")
                                {
                                    // If answer entry found & avaliable for occurrence date then take all entries for reporting & status
                                    var SameDateMultipleAnswers = RecurrenceEvents.Where(r => r.AuditID == auditID && r.AnsweredTimeStamp == occurrence.Period.StartTime.Date);
                                    foreach (var item in SameDateMultipleAnswers)
                                    {
                                        ExpandedAudits.Add(AuditDataAssignment(item, occurrence));
                                    }
                                }
                            }
                        }
                    }
                    else 
                    {
                        DateTime FromDate;
                        DateTime ToDate;
                        DateTime.TryParseExact(currentYear, "yyyy-MM-dd", null, System.Globalization.DateTimeStyles.None, out ToDate);
                        DateTime.TryParseExact(currentMonth, "yyyy-MM-dd", null, System.Globalization.DateTimeStyles.None, out FromDate);
                        Console.WriteLine(FromDate + " " + ToDate);
                        var calenderOccurrences= calendar.GetOccurrences(FromDate, ToDate);
                        if (module!= "ReportExportAll")
                        {
                             calenderOccurrences = calendar.GetOccurrences(FromDate, ToDate);
                        }else
                        {
                            calenderOccurrences = calendar.GetOccurrences(DateTime.MinValue, DateTime.MaxValue);
                        }
                       

                        foreach (var occurrence in calenderOccurrences)
                        {
                            // Veify any answers made on current occurence date from series
                            // If no answer entry for occurrence date then create a new audit object
                            if (!RecurrenceEventsByAuditID.Any(r => r.AuditID == auditID && r.AnsweredTimeStamp == occurrence.Period.StartTime.Date))
                            {
                                var existingItemsInListByAuditID = RecurrenceEvents.FirstOrDefault(r => r.AuditID == auditID);
                                var json = JsonSerializer.Serialize(existingItemsInListByAuditID);
                                var audit = JsonSerializer.Deserialize<Audit>(json);

                                ExpandedAudits.Add(AuditDataAssignment(audit, occurrence, false));
                            }
                            else
                            {
                                if (module == "Calendar")
                                {
                                    // If answer entry found & avaliable for occurrence date then order by answered rows and take first for status
                                    var sameDateSortedEvent = RecurrenceEvents.Where(r => r.AuditID == auditID && r.AnsweredTimeStamp == occurrence.Period.StartTime.Date).OrderByDescending(r => r.IsAuditCompleted).FirstOrDefault();
                                    ExpandedAudits.Add(AuditDataAssignment(sameDateSortedEvent, occurrence));
                                }
                                else if (module == "Report" || module == "ReportFiltered" || module == "ReportExportAll")
                                {
                                    // If answer entry found & avaliable for occurrence date then take all entries for reporting & status
                                    var SameDateMultipleAnswers = RecurrenceEvents.Where(r => r.AuditID == auditID && r.AnsweredTimeStamp == occurrence.Period.StartTime.Date);
                                    foreach (var item in SameDateMultipleAnswers)
                                    {
                                        ExpandedAudits.Add(AuditDataAssignment(item, occurrence));
                                    }
                                }
                            }
                        }
                    }            
                }

                auditAnswersWithStatus.AddRange(NonRecurrenceEvents); //Insert Non Recurrence Events into a common list
                auditAnswersWithStatus.AddRange(ExpandedAudits); //Insert resolved Recurrence Events date object as audit type into a common list

                foreach (var item in auditAnswersWithStatus)
                {
                    if (item.AnsweredTimeStamp.HasValue)
                    {
                        item.AnsweredStatus = "Overdue";        //red

                        if ((item.AnsweredTimeStamp == item.StartDate || (item.AnsweredTimeStamp >= item.StartDate && item.AnsweredTimeStamp <= item.EndDate))
                            && item.IsAuditCompleted.HasValue && item.IsAuditCompleted.Value == true)
                        {
                            item.AnsweredStatus = "Completed";   //green
                        }
                        else if ((item.AnsweredTimeStamp == item.StartDate || (item.AnsweredTimeStamp >= item.StartDate && item.AnsweredTimeStamp <= item.EndDate))
                          && item.IsAuditCompleted.HasValue && item.IsAuditCompleted.Value == false)
                        {
                            item.AnswerEndDate = null;
                            item.AnsweredStatus = "In Progress"; //Yellow
                        }
                    }
                    else
                    {
                        item.CreatedBy_NTID = "";
                        item.IsAuditCompleted = false;
                        item.AnswerPercentage = null;
                        item.AnswerdQuestionCount = null;
                        item.UnAnswerdQuestionCount = null;
                        item.AnsweredTimeStamp = null;
                        item.AnswerStartDate = null;
                        item.AnswerEndDate = null;

                        item.AnsweredStatus = "Not yet due";   //grey / Future events
                        if (item.StartDate < DateTime.UtcNow.Date && item.EndDate < DateTime.UtcNow.Date)
                        {
                            item.AnsweredStatus = "Overdue"; //red
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                throw;
            }

            return auditAnswersWithStatus;
        }

        private static Audit AuditDataAssignment(Audit audit, Occurrence occurrence, bool IsAnswerd = true)
        {
            audit.StartDate = occurrence.Period.StartTime.Date;
            audit.StartTime = new TimeSpan(occurrence.Period.StartTime.Hour, occurrence.Period.StartTime.Minute, occurrence.Period.StartTime.Second);
            audit.EndDate = occurrence.Period.EndTime.Date;
            audit.EndTime = new TimeSpan(occurrence.Period.EndTime.Hour, occurrence.Period.EndTime.Minute, occurrence.Period.EndTime.Second);
            audit.AnsweredTimeStamp = occurrence.Period.StartTime.Date;
            if(IsAnswerd == false)
            {
                audit.AnsweredTimeStamp = null;
                audit.IsAuditCompleted = null;
            }

            return audit;
        }
    }
}
