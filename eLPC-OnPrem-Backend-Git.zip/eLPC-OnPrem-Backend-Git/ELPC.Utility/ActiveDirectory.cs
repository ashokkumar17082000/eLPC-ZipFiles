﻿using ELPC.Core;
using System;
using System.Collections.Generic;
using System.DirectoryServices;

namespace ELPC.Utility
{
    public class ActiveDirectory
    {
        public List<User> GetUserList(string givenName)
        {

            List<User> usrList = new List<User>();
            try
            {
                DirectorySearcher objDirsearcher;
                var objDirEntry = Utility.CreateActiveDirectoryConnection();
                if (objDirEntry == null)
                {
                    return new List<User>();
                }
                objDirsearcher = new DirectorySearcher(objDirEntry);
                objDirsearcher.PageSize = 0;
                objDirsearcher.SizeLimit = 10;
                objDirsearcher.CacheResults = true;
                objDirsearcher.ServerPageTimeLimit = TimeSpan.FromSeconds(2);
                objDirsearcher.ReferralChasing = ReferralChasingOption.All;
                objDirsearcher.PropertiesToLoad.Add("givenName");
                objDirsearcher.PropertiesToLoad.Add("sn");
                objDirsearcher.PropertiesToLoad.Add("mail");
                objDirsearcher.PropertiesToLoad.Add("telephoneNumber");
                objDirsearcher.PropertiesToLoad.Add("department");
                objDirsearcher.PropertiesToLoad.Add("userPrincipalName");
                objDirsearcher.PropertiesToLoad.Add("sAMAccountName");
                objDirsearcher.PropertiesToLoad.Add("displayName");
                objDirsearcher.PropertiesToLoad.Add("memberOf");
                objDirsearcher.SearchScope = SearchScope.Subtree;
                objDirsearcher.Filter = "(&(objectClass=user)(displayName=" + givenName + "*))";

                var namelist = objDirsearcher.FindAll();
                usrList = GetADSearchResult(namelist);
            }
            catch (Exception ex)
            {
                throw ex;
                //usrList = null;
            }

            return usrList;
        }


        public static List<User> GetADSearchResult(SearchResultCollection namelist)
        {
            List<User> usrList = new List<User>();
            foreach (SearchResult objResult in namelist)
            {
                try
                {
                    User namObj = new User();
                    var result = new List<string>();
                    if (objResult != null)
                    {
                        for (int i = 0; i < objResult.Properties["memberOf"].Count; i++)
                        {
                            var memberof = objResult.Properties["memberOf"][i].ToString().Split(',');
                            if (!string.IsNullOrEmpty(memberof[0].Substring(3)))
                            {
                                result.Add(memberof[0].Substring(3));
                            }
                        }
                        namObj.Roles = result;
                        namObj.NTID = Convert.ToString(objResult.Properties["samaccountname"][0]);
                        namObj.EmailAddress = Convert.ToString(objResult.Properties["mail"][0]);
                        namObj.Department = Convert.ToString(objResult.Properties["department"][0]);
                        namObj.FirstName = Convert.ToString(objResult.Properties["givenName"][0]);
                        namObj.LastName = namObj.FirstName == Convert.ToString(objResult.Properties["sn"][0]) ? "" : Convert.ToString(objResult.Properties["sn"][0]);
                        if (namObj.LastName != null && namObj.LastName != "")
                        {
                            namObj.UserName = namObj.FirstName + ' ' + namObj.LastName;
                        }
                        namObj.UserName = Convert.ToString(objResult.Properties["displayName"][0]);
                    }
                    usrList.Add(namObj);
                }
                catch (Exception ex)
                {
                    continue;
                }
            }

            return usrList;
        }
    }
}