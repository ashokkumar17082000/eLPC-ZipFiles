﻿namespace ELPC.Utility
{
    public class CommonConstants
    {
        //"bXBEcWxuWTRuN1lXaU1BTi9TSlVNZz09LGh4NUQrV2JtNWRuSlpTaWVuTFlESndnOXFpTXFjRmNXTHJ4ZE5Iai8zcFE9";
        public const string CRYPTO_KEY = "d2Y2ZG9SV1VwL2RBUUJENnBsejAyZz09LGJiZVg1anJzWVFhTUhpSkVlb28rRXZaZzkyRlNtemlvRGRuMzZlNng4S2s9";
    }
}