﻿//using ClosedXML.Excel;
using System;
using System.Data;
using System.IO;


namespace POC.Utility
{

    public static class ReadExcel
    {
        /*
        public static DataTable ReadManager(Stream stream)
        {
            using (XLWorkbook excelWorkbook = new XLWorkbook(stream))
            {
                IXLWorksheet excelRows = excelWorkbook.Worksheet(1);

                DataTable dt = new DataTable();
                bool firstRow = true;
                foreach (IXLRow row in excelRows.Rows())
                {
                    if (firstRow)
                    {
                        foreach (IXLCell cell in row.Cells())
                        {
                            dt.Columns.Add(cell.Value.ToString());
                        }
                        firstRow = false;
                    }
                    else
                    {
                        int i = 0;
                        DataRow dr = dt.NewRow();
                        foreach (IXLCell cell in row.Cells())
                        {
                            dr[i] = cell.Value.ToString().Trim() == string.Empty ? null : cell.Value.ToString().Trim();
                            i++;
                        }
                        if (dr[0].ToString() != "" || dr[1].ToString() != "")
                            dt.Rows.Add(dr);
                        dt.AcceptChanges();
                    }
                }
                dt.TableName = "dtManager";
                return dt;
            }
        }
        */
        //********************************************************
        public static DataSet Read(Stream stream)
        {
            try
            {
                DataSet ds = new DataSet();

             /*   
                using (XLWorkbook excelWorkbook = new XLWorkbook(stream))
                {
                    int rti = excelWorkbook.Worksheets.Count;
                    for (int c = 1; c <= rti; c++)
                    {
                        DataTable dt = new DataTable();
                        IXLWorksheet excelRows = excelWorkbook.Worksheet(c);
                        bool firstRow = true;
                        foreach (IXLRow row in excelRows.Rows())
                        {
                            //Use the first row to add columns to DataTable.
                            if (firstRow)
                            {
                                foreach (IXLCell cell in row.Cells())
                                {
                                    dt.Columns.Add(cell.Value.ToString());
                                }
                                firstRow = false;
                            }
                            else
                            {
                                //Add rows to DataTable.
                                int i = 0;
                                DataRow dr = dt.NewRow();


                                foreach (IXLCell cell in row.Cells())
                                {

                                    dr[i] = cell.Value.ToString().Trim() == string.Empty ? null : cell.Value.ToString().Trim();

                                    i++;
                                }
                                if (dr[0].ToString() != "" || dr[1].ToString() != "")
                                    dt.Rows.Add(dr);
                                dt.AcceptChanges();
                            }
                        }

                        dt.TableName = "dtVTemplate" + c;
                        ds.Tables.Add(dt);
                    }

                }
             */
                return ds;
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        //********************************************************



        //public static DataTable Read(Stream stream)
        //{
        //    using (XLWorkbook excelWorkbook = new XLWorkbook(stream))
        //    {
        //        IXLWorksheet excelRows = excelWorkbook.Worksheet(1);

        //        DataTable dt = new DataTable();
        //        bool firstRow = true;
        //        foreach (IXLRow row in excelRows.Rows())
        //        {
        //            //Use the first row to add columns to DataTable.
        //            if (firstRow)
        //            {
        //                foreach (IXLCell cell in row.Cells())
        //                {
        //                    dt.Columns.Add(cell.Value.ToString());
        //                }
        //                firstRow = false;
        //            }
        //            else
        //            {
        //                //Add rows to DataTable.
        //                //dt.Rows.Add();
        //                int i = 0;
        //                DataRow dr = dt.NewRow();


        //                //foreach (IXLCell cell in row.Cells(row.FirstCellUsed().Address.ColumnNumber, row.LastCellUsed().Address.ColumnNumber))
        //                //{
        //                //    //dt.Rows[dt.Rows.Count - 1][i] = cell.Value.ToString();
        //                //    dr[i] = cell.Value.ToString();
        //                //    i++;
        //                //}
        //                foreach (IXLCell cell in row.Cells())
        //                {
        //                    //if (cell.Value.ToString().ToLower().Trim() == "null")
        //                    //    dr[i] = DBNull.Value;
        //                    //else
        //                    dr[i] = cell.Value.ToString().Trim() == string.Empty ? null : cell.Value.ToString().Trim();
        //                    // dr[i] = cell.Value.ToString();
        //                    i++;
        //                }
        //                if (dr[0].ToString() != "" || dr[1].ToString() != "")
        //                    dt.Rows.Add(dr);
        //                dt.AcceptChanges();
        //            }
        //        }
        //        dt.TableName = "dtVTemplate";
        //        //dt.TableName = "dtEmployee";
        //        //DataSet ds = new DataSet();
        //        //ds.Tables.Add(dt);
        //        //ds.DataSetName = "dsEmployee";
        //        return dt;
        //    }
        //}


    }
}
