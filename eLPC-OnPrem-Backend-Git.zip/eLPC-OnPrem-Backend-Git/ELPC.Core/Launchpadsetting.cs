﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ELPC.Core
{
    public class ReportText
    {
        public int reportTextID { get; set; }
        public string reportTextName { get; set; }

        public string reportTextURL { get; set; }

        public int plantID { get; set; }

        public bool? IsLocked { get; set; }
        public DateTime? ModifiedAt { get; set; }
        public DateTime? CreatedAt { get; set; }
        public string CreatedBy_UserID { get; set; }
        public string ModifiedBy_UserID { get; set; }
        public string CreatedBy_NTID { get; set; }
        public string ModifiedBy_NTID { get; set; }
        public virtual List<Reports> Reports { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public User user { get; set; }

        //for Excel import/export
        public string ErrorMessage { get; set; }

        public bool? IsDeleted { get; set; }
        public bool? IsAccessible { get; set; }
    }
    public class Reportrestore
    {
        public int reportTextID { get; set; }
        public string reportTextName { get; set; }

        public string reportTextURL { get; set; }

        public int plantID { get; set; }

        public int HistoryId { get; set; }

        public int HistId{ get; set; }
        public bool? IsLocked { get; set; }
        public DateTime? ModifiedAt { get; set; }
        public DateTime? CreatedAt { get; set; }
        public string CreatedBy_UserID { get; set; }
        public string ModifiedBy_UserID { get; set; }
        public string CreatedBy_NTID { get; set; }
        public string ModifiedBy_NTID { get; set; }
        public virtual List<Reports> Reports { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public User user { get; set; }

        //for Excel import/export
        public string ErrorMessage { get; set; }

        public bool? IsDeleted { get; set; }
        public bool? IsAccessible { get; set; }
    }

    public class Reports
    {
        public int AssessorID { get; set; }
        public string AssessorName { get; set; }
        public string Category { get; set; }

        public bool Isdeleted { get; set; }


    }
}
