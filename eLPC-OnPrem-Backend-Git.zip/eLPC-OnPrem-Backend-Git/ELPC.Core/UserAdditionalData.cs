﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ELPC.Core
{
    public class UserAdditionalData
    {
        public string AdditionalData { get; set; }
        public string UserNTID { get; set; }
    }
}
