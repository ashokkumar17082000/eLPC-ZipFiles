﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class AssignedTargetFrequency
    {
        public int ID { get; set; }
        public int QuestionID { get; set; }
        public int TargetFrequencyTypeID { get; set; }
        public string TargetFrequencyValue { get; set; }
    }
}
