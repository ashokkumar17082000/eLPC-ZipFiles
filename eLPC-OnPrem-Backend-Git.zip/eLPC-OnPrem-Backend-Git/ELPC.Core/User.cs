﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class User
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
        public int Role_roleID { get; set; }
        public int? EmployeeID { get; set; }
        public string EmailAddress { get; set; }
        public string NTID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Department { get; set; }
        public string RoleName { get; set; }
        public string Location { get; set; }
        public string Office { get; set; }
        public List<string> Roles { get; set; }
        public bool IsValueStream { get; set; } = false;
        public bool IsGroupNameRequired { get; set; } = false;
        public int PlantID { get; set;}

        public int CustomIConID { get; set; } = 0;
    }
}
