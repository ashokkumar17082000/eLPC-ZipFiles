﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class AssessorValuestreamList
    {
        public string AssessorIDs { get; set; }
        public string ValueStreamIDs { get; set; }

    }
}
