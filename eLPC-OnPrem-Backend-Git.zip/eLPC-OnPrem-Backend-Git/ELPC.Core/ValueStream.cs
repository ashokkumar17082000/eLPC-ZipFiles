﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
  public  class ValueStream
    {
        public int ID { get; set; } //for Assigned ValueStream in question
        public int ValueStreamID { get; set; }
        public string Responsible_UserID { get; set; }
        public string ResponsibleEmployee { get; set; }
        public int ValueStreamTemplateID { get; set; }
        public int ValueStreamCategoryID { get; set; }
        public string ValueStreamData { get; set; }
        public string ValueStreamCategoryName { get; set; }

        public int NodeID { get; set; }
        public int RowID { get; set; }
       
        public string valueStreamTemplateName { get; set; }
        public string Delimiter { get; set; }
        public string ResponsibleEmployeeID { get; set; }
        public string ValueStreamName { get; set; }

        //for import/export purpose
        public int TempID { get; set; }

        public int CategoryTempID { get; set; }

        public string ParentId { get; set; }

    }

public class ValueStreamNameAndID
    {
        public int ID { get; set; } //for Assigned ValueStream in question
        public string ValueStreamName { get; set; }
    }
}
