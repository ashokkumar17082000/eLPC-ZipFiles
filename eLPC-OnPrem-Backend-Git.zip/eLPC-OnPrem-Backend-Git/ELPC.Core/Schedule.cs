﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class Schedule
    {
        public int ScheduleId { get; set; }
        public string ScheduleName { get; set; }
        public int PlantId { get; set; }
        public string DataObj { get; set; }
        public int ExecutionCount { get; set; }
        public bool IsCompleted { get; set; }
        public DateTime? LastRunAt { get; set; }
        public string ErrorDetail { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? ModifiedAt { get; set; }
        public bool IsDeleted { get; set; }
    }
}
