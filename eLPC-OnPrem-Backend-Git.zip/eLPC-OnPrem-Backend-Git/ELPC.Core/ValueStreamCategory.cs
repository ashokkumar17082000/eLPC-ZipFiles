﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
  public  class ValueStreamCategory
    {
        public int? ValueStreamCategoryID { get; set; }
        public string ValueStreamCategoryName { get; set; }
        public int ValueStreamTemplateID { get; set; }
        public bool IsDataRequired { get; set; }
        public int? TypeOfInput_InputTypeID { get; set; }
        public bool IsDataRequiredToFitSpecLength { get; set; }
        public int MinimumNoOfCharacters { get; set; }
        public int MaximumNoOfCharacters { get; set; }
        public string InputType { get; set; }

        public int NodeID { get; set; }

        public virtual List<ValueStream> ValueStreams { get; set; }
        public bool IsColumnRequired { get; set; }


        //for bulk import purpose
        public int TempID { get; set; }
        public int CategoryTempID { get; set; }
        public string ParentId { get; set; }
    }
}
