﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class AssessorProxy
    {
        public int ID { get; set; }
        public int AssessorTemplateID { get; set; }
        public List<User> Proxies { get; set; }
        public string Proxy { get; set; }
        public string CreatedBy_NTID { get; set; }
        public string ModifiedBy_NTID { get; set; }

        public string NTID { get; set; }
        public string UserName { get; set; }

        public bool IsLocked { get; set; }
    }
}
