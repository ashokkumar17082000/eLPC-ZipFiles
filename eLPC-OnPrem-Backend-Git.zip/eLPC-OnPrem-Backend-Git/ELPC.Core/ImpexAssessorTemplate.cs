﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class ImpexAssessorTemplate :AssessorTemplate
    {

    }
}
