﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
   public class EditTagList
    {
        public string MyTagID { get; set; }
        public string MyTagName { get; set; }

      

    }
}
