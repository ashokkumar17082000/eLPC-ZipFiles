﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class ProcessConfirmation
    {
        public int ModeTypeID { get; set; }
        public int ValueStreamID { get; set; }
        public int AssessorID { get; set; }
        public int QuestionID { get; set; }
        public int QuestionDisplayID { get; set; }
        public string Answer { get; set; }
        public int AnswerType_AnswerTypeID { get; set; }
        public string AnsweredBy { get; set; }
        public DateTime CreatedAt { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedAt { get; set; }
        public int TargetPercentage { get; set; }
        public int TagModeID { get; set; }
        public int IsBranchLogicToBeFollowed { get; set; }
        public bool QuestionType { get; set; }
        public int PlantID { get; set; }
        public bool resumefrominlinetoclassic { get; set; }
        // public int? CreatedBy_UserID { get; set; }
        public string ModifiedBy_NTID { get; set; }
        public bool IsDeleted { get; set; }
        public int TagID { get; set; }
        public bool ResumeTagProcessConfirmation { get; set; }
        public bool fromunanswerornextinline { get; set; }
        public bool isResumeActivated { get; set; }
        public bool IsSkipMandatory { get; set; }        
        public string QuestionText { get; set; }
        public int AttemptNumber { get; set; }
        public string ChildEventID { get; set; }
        public bool isResumeClickedOnce { get; set; }

        public string QuestionHintText { get; set; }
        public string HyperLinkURL { get; set; }
        public string ImageTitle { get; set; }
        public string DisplayFileName { get; set; }

        public int ProcessConfirmationID { get; set; }
        public DateTime TimeStamp { get; set; }
        public string ValueStreamData { get; set; }
        public string ValueStreamName { get; set; }//added for list view
        public string AssessorName { get; set; }

        public string ModeType { get; set; }
        public string AnsweredBy_NTID { get; set; }

        public bool IsCustomMode { get; set; }
        public int CustomModeID { get; set; }
        public bool isDeviation { get; set; }
        public string UserName { get; set; }
        public decimal ObtainedScore { get; set; }
        public int ChoiceID { get; set; }
        public string OPLURL { get; set; }
    public string task { get; set; }
      public string deviation_item { get; set; }
        public string DeviationDescription { get; set; }
        public string ResponsibleEmployee { get; set; }
        public int DeviationID { get; set; }

        public int DataPoolID { get; set; }
        public virtual List<HintImage> HintImages { get; set; }
        public List<Deviation> Deviations { get; set; }

        public string TagIDList { get; set; }
        public string TagNameList { get; set; }
        public string EmpList { get; set; }
        public string MultiTagList { get; set; }
        public string MultiTagID{ get; set; }
        public List<EditTagList> EditTagList { get; set; }
        public List<AddEmpList>AddEmpList { get; set; }
        public List<TagList>TagList { get; set; }
        public string ValueStreamTemplateName { get; set; }
        public string ValueStreamCategoryName { get; set; }
        public string AssessorTemplateName { get; set; }
        public string Delimiter { get; set; }
        public object[] OnMyformData {get;set;}//may not required
        public bool IsShowVsAs { get; set; }

        public bool IsForgotAssessor { get; set; }
        public bool IsForgotValueStream { get; set; }
        public string VsSessionID { get; set; }
        public string AsSessionID { get; set; }

        public List<AssessorList> AssessorList { get; set; }
        public virtual List<Tag1> selectedTagData { get; set; }
        public List<User> AdditionalEmployee { get; set; }
        public string AssessorIDList { get; set; }
        public string AssessorNameList { get; set; }

        public bool IsDefaultAnswerRequired { get; set; }
        public bool IsAnswerRequired { get; set; }
        public string DefaultChoice { get; set; }
        public int DefaultChoiceID { get; set; }
        public string SessionID { get; set; }
        public int AuditID { get; set; }
        public int AuditTemplateID { get; set; }
        public List<int> AnsweredAndSkippedQuestionID { get; set; }
        public  int isskipmandatoryAnswer { get; set; }
       public string Process_eventID_Starttime { get; set; }

        public string generatedEventID { get; set; }
        public bool IsFirstinsertProcessConfirmation { get; set; }

        public int TaskID { get; set; }
        public string OriginTag { get; set; }

        public string TagName { get; set; }
        public string TagTypeName { get; set; }
        public string LanguageCode { get; set; }
        public int AnonymizeUserDataSettingID { get; set; }
        public bool InLineActivated { get; set; }
        public int Inlinecount { get; set; }
        public bool isInlineInsertProcess { get; set; }
        public bool frominline { get; set; }
    }
    public class AddEmpList
    {
        public String MyUserNmae { get; set; }
        public String MyNTID { get; set; }
    }
    public class  TagList
    {
        public String TagName  { get; set; }
        public String MyTagID { get; set; }
    }

    public class UpdateEventTimeRequest
    {
        public string eventstarttime { get; set; }
        public ProcessConfirmation processConfirmationdata { get; set; }
    }
}
    
