﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class ChoiceDisplayType
    {
        public int ChoiceDisplayTypeID { get; set; }
        public string ChoiceDisplayTypeName { get; set; }
        public bool? IsDeleted { get; set; }
    }
}
