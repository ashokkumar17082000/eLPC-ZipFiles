﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class UserProfileValueStreamAssessor
    {
        public List<UserProfileValueStream> UserProfileValueStream { get; set; }
        public List<UserProfileAssessor> UserProfileAssessor { get; set; }
        public List<UsercustomIcon> UsercustomIcon { get; set; }
        public int UserEmployeeID { get; set; }
    }

    public class UsercustomIcon
    {
        public string customIconName { get; set; }
        public int customeIconID { get; set; }
        public bool customIconEnable { get; set; }
        public bool customIconimgSRCEnable { get; set; }
        public string customIconRoutePath { get; set; }
        public string customIconLogo { get; set; }
    }

    public class UserProfileUpdateVSAS
    {
        public string SessionID { get; set; }

        public int? ValueStreamTemplateID { get; set; }
        public int? ValueStreamID { get; set; }
        public bool IsForgotValueStream { get; set; }

        public int? AssessorTemplateID { get; set; }
        public int? AssessorID { get; set; }
        public bool IsForgotAssessor { get; set; }

    }

    public class UserProfileValueStream
    {
        public int? UserProfileValueStreamID { get; set; }
        public int? PlantID { get; set; }
        public int? RowID { get; set; }

        public int? ValueStreamTemplateID { get; set; }
        public List<ValueStreamTemplate> ValueStreamTemplateArr { get; set; }
        public List<ValueStreamTemplate> SelectedItemValueStreamTemplate { get; set; }

        public int? ValueStreamCategoryID { get; set; }
        public List<ValueStreamCategory> ValueStreamCategoryArr { get; set; }
        public List<ValueStreamCategory> SelectedItemvalueStreamCategory { get; set; }

        public int? ValueStreamID { get; set; }
        public List<ValueStream> ValueStreamArr { get; set; }
        public List<ValueStream> SelectedItemvalueStream { get; set; }

        public bool IsForgotValueStream { get; set; }
        public string SessionID { get; set; }
        public bool IsDeleted { get; set; }

        public string User_NTID { get; set; }
        public DateTime ModifiedAt { get; set; }
        public DateTime CreatedAt { get; set; }

    }


    public class UserProfileAssessor
    {
        public int? UserProfileAssessorID { get; set; }
        public int? PlantID { get; set; }
        public int? RowID { get; set; }

        public int? AssessorTemplateID { get; set; }
        public List<AssessorTemplate> AssessorTemplateArr { get; set; }
        public List<AssessorTemplate> SelectedItemAssessorTemplate { get; set; }

        public int? AssessorID { get; set; }
        public List<Assessor> AssessorArr { get; set; }
        public List<Assessor> SelectedItemAssessor { get; set; }

        public bool IsForgotAssessor { get; set; }
        public string SessionID { get; set; }
        public bool IsDeleted { get; set; }

        public string User_NTID { get; set; }
        public DateTime ModifiedAt { get; set; }
        public DateTime CreatedAt { get; set; }

    }
}
