﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class QuestionHistory
    {
        public int QuestionHistoryID { get; set; }
        public int QuestionHistoryDisplayID { get; set; }
        public int QuestionID { get; set; }
        public string QuestionText { get; set; }
        public string ModifiedBy_NTID { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedAt { get; set; }
        public int ModifiedBy_UserID { get; set; }
        public DateTime CreatedAt { get; set; }
        public int CreatedBy_UserID { get; set; }
    }
}
