﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class AssessorList
    {
        public string AssessorID { get; set; }
        public string AssessorName { get; set; }
    }
}
