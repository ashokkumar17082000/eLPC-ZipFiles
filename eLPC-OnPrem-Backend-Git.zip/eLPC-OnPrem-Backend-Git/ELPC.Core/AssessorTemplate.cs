﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class AssessorTemplate
    {
        public int AssessorTemplateID { get; set; }
        public int AssessorTemplateDisplayID { get; set; }
        public string AssessorTemplateName { get; set; }
        public bool? IsLocked { get; set; }
        public DateTime? ModifiedAt { get; set; }
        public DateTime? CreatedAt { get; set; }
        public bool? IsTargetFrequencyDefined { get; set; }
        public string CreatedBy_UserID { get; set; }
        public string ModifiedBy_UserID { get; set; }
        public string CreatedBy_NTID { get; set; }
        public string ModifiedBy_NTID { get; set; }

        public string TempID { get; set; }
        public virtual List<AssessorCategory> AssessorCategories { get; set; }
        public virtual List<Assessor> Assessors { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public User user { get; set; }

        //for Excel import/export
        public string ErrorMessage { get; set; }

        public bool? IsDeleted { get; set; }
        public bool? IsAccessible { get; set; }
    }
}
