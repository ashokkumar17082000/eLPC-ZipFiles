﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class CustomMode
    {
        public int CustomModeID { get; set; }

        public bool? IsDeleted { get; set; }

        public int? CreatedBy_UserID { get; set; }
        public int? ModifiedBy_UserID { get; set; }
        public DateTime? ModifiedAt { get; set; }
        public DateTime? CreatedAt { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }

        public bool IsCompleted { get; set; }
        public int TagID { get; set; }
        public string TagName { get; set; }

        public string CreatedBy_NTID { get; set; }
       

        public virtual List<Tag> tags { get; set; }
        public virtual List<Question> questions { get; set; }

        public Tag tag { get; set; }
        public Question question { get; set; }

    }
}
