﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
   public class ImportCombinedList
    {
        public List<ValueStreamTemplate> list1 { get; set; }
        public List<ValueStreamCategory> list2 { get; set; }

        public List<ValueStream> list3 { get; set; }

        public List<Shift> list4 { get; set; }
    }
}
