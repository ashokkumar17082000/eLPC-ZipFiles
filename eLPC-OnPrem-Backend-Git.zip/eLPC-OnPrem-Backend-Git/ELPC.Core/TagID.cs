﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class TagID
    {
        public string TagsIDs { get; set; }
    }
}
