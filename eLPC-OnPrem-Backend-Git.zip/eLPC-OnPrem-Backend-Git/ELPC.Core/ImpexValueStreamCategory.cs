﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class ImpexValueStreamCategory
    {
        public string ValueStreamCategoryID { get; set; }
        public string ValueStreamCategoryName { get; set; }
        public string ValueStreamTemplateID { get; set; }
        public bool IsDataRequired { get; set; }
        public string TypeOfInput_InputTypeID { get; set; }
        public bool IsDataRequiredToFitSpecLength { get; set; }
        public string MinimumNoOfCharacters { get; set; }
        public string MaximumNoOfCharacters { get; set; }
        public string InputType { get; set; }

        public string NodeID { get; set; }

        public virtual List<ValueStream> ValueStreams { get; set; }
        public bool IsColumnRequired { get; set; }


        //for bulk import purpose
        public string TempID { get; set; }
        public string CategoryTempID { get; set; }
    }
}
