﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class ValueStreamHistory
    {
        public int ValueStreamTemplateHistoryID { get; set; }
        public int ValueStreamTemplateHistoryDisplayID { get; set; }
        public int ValueStreamTemplateID { get; set; }
        public string ModifiedBy_NTID { get; set; }
        public string ModifiedBy { get; set; }
        public string ValueStreamTemplateName { get; set; }
        public DateTime ModifiedAt { get; set; }
        public int ModifiedBy_UserID { get; set; }
        public DateTime CreatedAt { get; set; }
        public int CreatedBy_UserID { get; set; }
        public string Remarks { get; set; }
    }
}
