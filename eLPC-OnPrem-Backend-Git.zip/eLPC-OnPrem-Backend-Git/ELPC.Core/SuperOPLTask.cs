﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class SuperOPLTask
    {
        public string url { get; set; }

        public string task { get; set; }

        public string deviation { get; set; }

        public int? ScheduleId { get; set; }
    }
}
