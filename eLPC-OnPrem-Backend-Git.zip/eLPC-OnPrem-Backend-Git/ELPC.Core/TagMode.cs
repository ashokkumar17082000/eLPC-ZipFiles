﻿namespace ELPC.Core
{
   public class TagMode : CustomMode
    {
        public int TagModeID { get; set; }
    }
}
