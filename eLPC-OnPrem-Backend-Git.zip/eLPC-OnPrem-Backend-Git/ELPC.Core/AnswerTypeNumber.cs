﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class AnswerTypeNumber
    {
        public int ID { get; set; }
        public int MaxValue { get; set; }
        public int MinValue { get; set; }
        public string NumberOfDecimalPlaces { get; set; }
        public bool IsNumber { get; set; }
        public string DefaultValue { get; set; }
        public bool ShowPercentage { get; set; }
        public int QuestionID { get; set; }
    }
}
