﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class Shift
    {
        public string ShiftName { get; set; }
        public int ShiftID { get; set; }
        public DateTime FromTime { get; set; }
        public DateTime ToTime { get; set; }
        public int RowID { get; set; }
        public bool IsMonday { get; set; }
        public bool IsTuesday { get; set; }
        public bool IsWednesday { get; set; }
        public bool IsThursday { get; set; }
        public bool IsFriday { get; set; }
        public bool IsSaturday { get; set; }
        public bool IsSunday { get; set; }
        public string DisplayName { get; set; }
        public User User { get; set; }
        public int ValueStreamTemplateID { get; set; }
        
    }
}
