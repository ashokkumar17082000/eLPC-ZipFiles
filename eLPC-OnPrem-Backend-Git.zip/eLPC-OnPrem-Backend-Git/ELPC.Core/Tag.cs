﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class Tag
    {

        public int TagID { get; set; }
        public int TagDisplayID { get; set; }
        public string TagName { get; set; }
        public string TagDisplayName { get; set; }
        public bool? IsSingleQuestionSuppressed { get; set; }

        public int? isSaveTag { get; set; }
        public DateTime? SuppressedDateRangeFrom { get; set; }
        public DateTime? SuppressedDateRangeTo { get; set; }
        public bool? IsTargetFrequencyDefined { get; set; }
        public int? TargetFrequencyTypeID { get; set; }
        public string TargetFrequencyValue { get; set; }
        public int? Tag_PriorityID { get; set; }
        public int? TagTypeID { get; set; }
        public bool? IsLocked { get; set; }
        public int? CreatedBy_UserID { get; set; }
        public int? ModifiedBy_UserID { get; set; }
        public int? AnonymizeUserDataSettingID { get; set; }
        public bool? IsBranchLogicToBeFollowed { get; set; }
        public bool? IsMandatoryAssessorsDefined { get; set; }
        public bool? IsDeleted { get; set; }

        public bool? RandomQuestionOrder{ get; set; }

        public DateTime? ModifiedAt { get; set; }
        public DateTime? CreatedAt { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }

        public string CreatedBy_NTID { get; set; }
        public string ModifiedBy_NTID { get; set; }
        public int CustomQuestionTagsID { get; set; }
        public int CustomModeID { get; set; }
        public int TagModeTagsID { get; set; }
        public virtual List<Tag> tags { get; set; }
        public virtual List<Question> questions { get; set; }
        //public int Assigned_ValueStreamTemplateID { get; set; }
        //public int Assigned_ValueStreamCategoryID { get; set; }
        //public int Assigned_AssessorTemplateID { get; set; }
        public virtual List<ValueStream> valueStreams { get; set; }
        public virtual List<Assessor> assessors { get; set; }

        public string ValueStreamNameList { get; set; }
        public string ValueStreamIDList { get; set; }
        public string AssessorIDList { get; set; }
        public string ValueStreamTemplateName { get; set; }
        public string AssessorNameList { get; set; }
        public string AssessorTemplateName { get; set; }
        public bool? IsAccessible { get; set; }
        public virtual List<RandomQuestion> RandomQuestionsOnly { get; set; }
        public virtual List<RandomQuestion> FinalQuestionOrder { get; set; }
        public bool? IsSearchableTag { get; set; }
        public bool? IsSkipQuestionDefined { get; set; }
        public bool? IsQuestionOverviewDefined { get; set; }
        public bool? IsProgressPercentageDefined { get; set; }
        public bool? IsResultOverviewDefined { get; set; }
        public bool? IsResumeTagDefined { get; set; }
        public bool? IsReportingEmailDefined { get; set; }
        public bool? IsInlineModeOn { get; set; }
        public int InlineCount { get; set; }

    }
}
