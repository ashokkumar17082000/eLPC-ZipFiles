﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class Result
    {
        public int ResultCode { get; set; }
        public string ResultMessage { get; set; }
        public string eventID { get; set; }
        public string eventStartTime { get; set; }
        public int Count { get; set; }
        public int AttemptNumber { get; set; }
        public string ChildEventID { get; set; }
        public int InsertedID { get; set; }
    }
}
