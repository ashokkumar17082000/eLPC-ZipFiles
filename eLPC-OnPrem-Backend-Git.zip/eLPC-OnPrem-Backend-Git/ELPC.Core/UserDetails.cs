﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class UserDetails
    {
        public string NTID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Department { get; set; }
        public string EmailAddress { get; set; }
        public string RoleName { get; set; }
        public string DisplayName { get; set; }
        public string UserName { get; set; }
        public Plant Plant { get; set; }
        public List<Plant> AvaliablePlants { get; set; }
        public string AdditionalData { get; set; }
        public int CustomIConID { get; set; }
     
    }
}
