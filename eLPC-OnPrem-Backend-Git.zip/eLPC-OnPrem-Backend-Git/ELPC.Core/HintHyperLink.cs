﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class HintHyperLink
    {
        public int ID { get; set; }

        public int QuestionID { get; set; }

        public string HyperLinkTitle { get; set; }

        public string HyperLinkURL { get; set; }
    }
}
