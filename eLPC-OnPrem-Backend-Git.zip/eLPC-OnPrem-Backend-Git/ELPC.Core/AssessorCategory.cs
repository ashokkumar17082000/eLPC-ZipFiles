﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    [Serializable]
    public class AssessorCategory
    {
        public int AssessorCategoryID { get; set; }
        public string AssessorCategoryName { get; set; }
        public int? AssessorTemplateID { get; set; }
        public bool? IsDataRequired { get; set; }
        public int? TypeOfInput_InputTypeID { get; set; }
        public bool? IsDataRequiredToFitSpecLength { get; set; }
        public int? MinimumNoOfCharacters { get; set; }
        public int? MaximumNoOfCharacters { get; set; }

        public int TempID { get; set; }
    }
}
