﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class SchedulerDataModel
    {
        public List<KeyValuePair<string, string>> Headers { get; set; }
        public string POSTData { get; set; }
    }
}
