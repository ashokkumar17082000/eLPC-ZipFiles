﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class ValueStreamTemplate
    {
        public int ValueStreamTemplateID { get; set; }
        public int ValueStreamTemplateDisplayID { get; set; }
        public string ValueStreamTemplateName { get; set; }
        public bool? IsLocked { get; set; }
        public DateTime? ModifiedAt { get; set; }
        public int ModifiedBy_UserID { get; set; }
        public DateTime? CreatedAt { get; set; }
        public int CreatedBy_UserID { get; set; }
        public string Delimiter { get; set; }
        public bool? IsOperatedInShifts { get; set; }
        public int VisualizationViewModeID { get; set; }

        
        public virtual List<ValueStream> ValueStreams { get; set; }

        public virtual List<ValueStreamCategory> ValueStreamCategories { get; set; }
        public virtual List<Shift> Shifts { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public string CreatedBy_NTID { get; set; }
        public string ModifiedBy_NTID { get; set; }
        public string? UserName { get; set; }
        //for import/export purpose
        public int TempID { get; set; }

        public bool? IsAccessible { get; set; }
    }
}
