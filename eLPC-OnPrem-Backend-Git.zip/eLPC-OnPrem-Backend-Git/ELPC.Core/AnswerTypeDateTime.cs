﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class AnswerTypeDateTime
    {
        public int ID { get; set; }
        public bool IsDateOnly { get; set; }
        public bool IsStandard { get; set; }
        public string DefaultDateType { get; set; }
        public string DefaultValue { get; set; }
        public int QuestionID { get; set; }
    }
}
