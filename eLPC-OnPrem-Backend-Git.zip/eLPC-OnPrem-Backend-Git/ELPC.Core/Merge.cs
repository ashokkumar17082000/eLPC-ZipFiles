﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ELPC.Core
{
    public class Merge
    {
        public virtual List<Question> questions { get; set; }
        public virtual List<ValueStream> valueStreams { get; set; }
        public virtual List<Assessor> assessors { get; set; }
        public virtual List<Tag> tags { get; set; }
    }

    public class MergeProxy : QuestionProxy
    {
        public virtual List<Question> questions { get; set; }
        public virtual List<Tag> tags { get; set; }
    }
}
