﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class DataPoolHistory
    {
        public int DataPoolHistoryID { get; set; }
        public int DataPoolHistoryDisplayID { get; set; }
        public int DataPoolID { get; set; }
        public string ModifiedBy_NTID { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedAt { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
