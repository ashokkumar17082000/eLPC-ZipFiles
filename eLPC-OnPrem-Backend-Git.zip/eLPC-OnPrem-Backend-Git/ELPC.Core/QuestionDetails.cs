﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
   public class QuestionDetail : Question
    {
        public string PriorityName { get; set; }
        public string ValueStreamTemplateName { get; set; }
        public string AssessorNameList { get; set; }
        public string AssessorTemplateName { get; set; }
        public string TagNameList { get; set; }
        public string TagIDList { get; set; }

        public string ValueStreamIDList { get; set; }

        public string AssessorIDList { get; set; }
        public List<EditTagList> EditTagList { get; set; }
        public string TargetFrequencyTypeName { get; set; }
    }
}
