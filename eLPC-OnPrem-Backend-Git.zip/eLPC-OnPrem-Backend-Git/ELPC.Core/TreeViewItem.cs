﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class TreeViewItem
    {
        public int Value { get; set; }
        public string Text { get; set; }
        public virtual List<TreeViewItem> Children { get; set; }
        public int ValueStreamTemplateID { get; set; }
    }
}
