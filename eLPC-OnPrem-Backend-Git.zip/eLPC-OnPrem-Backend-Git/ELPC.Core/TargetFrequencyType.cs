﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class TargetFrequencyType
    {
        public int TargetFrequencyTypeID { get; set; }
        public string TargetFrequencyTypeName { get; set; }
        public bool? IsDeleted { get; set; }
    }
}
