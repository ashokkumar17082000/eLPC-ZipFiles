﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class RecycleBinTemplate
    {
        public int ID { get; set; }
        public int PlantID { get; set; }
        public string ItemType { get; set; }
        public string ItemName { get; set; }
        public string DeletedBy { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? Deleted { get; set; }
        public bool Selected { get; set; }
        public int RowNumber { get; set; }
        public DateTime? deletedAt { get; set; }
        public string UserName { get; set; }
    }
}
