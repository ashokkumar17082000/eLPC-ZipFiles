﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class AnswerTypeCurrency
    {
        public int ID { get; set; }
        public int MaxValue { get; set; }
        public int MinValue { get; set; }
        public string NumberOfDecimalPlaces { get; set; }
        public bool IsCurrency { get; set; }
        public string DefaultValue { get; set; }
        public string CurrencyFormat { get; set; }
        public int QuestionID { get; set; }

    }
}
