﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class ImpexValueStreamTemplate
    {
        public string ValueStreamTemplateID { get; set; }
        public string ValueStreamTemplateName { get; set; }
        public bool? IsLocked { get; set; }
        public DateTime? ModifiedAt { get; set; }
        public DateTime? CreatedAt { get; set; }
        public string Delimiter { get; set; }
        public bool? IsOperatedInShifts { get; set; }
        public string VisualizationViewModeID { get; set; }


        public virtual List<ValueStream> ValueStreams { get; set; }

        public virtual List<ValueStreamCategory> ValueStreamCategories { get; set; }
        public virtual List<Shift> Shifts { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public string CreatedBy_NTID { get; set; }
        public string ModifiedBy_NTID { get; set; }

        //for import/export purpose
        public string TempID { get; set; }
    }
}
