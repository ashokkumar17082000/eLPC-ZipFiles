﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class AnswerType
    {
        public int AnswerTypeID { get; set; }
        public string AnswerTypeName { get; set; }
        public bool? IsDeleted { get; set; }
        public bool? IsDefault { get; set; }

    }
}
