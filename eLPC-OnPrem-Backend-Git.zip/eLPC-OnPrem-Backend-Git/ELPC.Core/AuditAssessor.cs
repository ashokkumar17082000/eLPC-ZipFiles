﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class AuditAssessor
    {
        public int AuditAssessorID { get; set; }
        public int AuditID { get; set; }
        public int AuditTemplateID { get; set; }

        public string AssessorName { get; set; }
        public string UserName { get; set; }
        public string NTID { get; set; }
        public bool IsMandatoryAssessor { get; set; }
        public bool IsDeleted { get; set; }

        //for Tag Mode Questions
        public int TagID { get; set; }
        public int TagTemplateID { get; set; }

    }
}
