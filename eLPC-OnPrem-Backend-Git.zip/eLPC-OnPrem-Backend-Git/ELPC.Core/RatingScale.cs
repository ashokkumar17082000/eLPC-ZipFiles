﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class RatingScale
    {
        public int ID { get; set; }
        public string NumberRange { get; set; }
        public string RangeText1 { get; set; }
        public string RangeText2 { get; set; }
        public string RangeText3 { get; set; }
        public bool ShowNA { get; set; }
        public string TextNA { get; set; }
    }
}
