﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class ImpexValueStream
    {
        public string ID { get; set; } //for Assigned ValueStream in question
        public string ValueStreamID { get; set; }
        public string Responsible_UserID { get; set; }
        public string ResponsibleEmployee { get; set; }
        public string ValueStreamTemplateID { get; set; }
        public string ValueStreamCategoryID { get; set; }
        public string ValueStreamData { get; set; }
        public string ValueStreamCategoryName { get; set; }

        public string NodeID { get; set; }
        public string RowID { get; set; }
        public string valueStreamTemplateName { get; set; }
        public string Delimiter { get; set; }
        public string ResponsibleEmployeeID { get; set; }
        public string ValueStreamName { get; set; }

        //for import/export purpose
        public string TempID { get; set; }

        public string CategoryTempID { get; set; }
    }
}
