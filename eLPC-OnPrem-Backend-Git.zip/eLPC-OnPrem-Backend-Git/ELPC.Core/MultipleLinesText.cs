﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class MultipleLinesText
    {
        public int ID { get; set; }
        public int MaxLines { get; set; }
        public bool IsPlainText { get; set; }
        public int QuestionID { get; set; }
    }
}
