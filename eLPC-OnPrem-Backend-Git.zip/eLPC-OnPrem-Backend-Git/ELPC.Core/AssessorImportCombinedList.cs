﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
   public class AssessorImportCombinedList
    {
        public List<ImpexAssessorTemplate> list1 { get; set; }
          public List<ImpexAssessor> list2 { get; set; }
    }
}
