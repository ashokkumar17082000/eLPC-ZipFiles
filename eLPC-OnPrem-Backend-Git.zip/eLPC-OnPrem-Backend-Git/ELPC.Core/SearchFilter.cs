﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class SearchFilter
    {
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public string ModuleName { get; set; }
        public string USPName { get; set; }
        public List<int> IDs { get; set; }
        public int IsDesigner { get; set; }
    }
}
