﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class ImpexAssessor
    {
        public string ID { get; set; } //for Assigned Assessor in question
        public string AssessorID { get; set; }
        public string AssessorName { get; set; }
        public string AssessorCategoryName { get; set; }
        public string TargetFrequencyValue { get; set; }
        public string AssessorCategoryID { get; set; }
        public string AssessorTemplateID { get; set; }
        public string TargetFrequencyTypeID { get; set; }
        public string TempID { get; set; }
        public bool IsMandatoryAssessor { get; set; }
    }
}
