﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class AssessorStreamHistory
    {
        public int AssessorTemplateHistoryID { get; set; }
        public int AssessorTemplateHistoryDisplayID { get; set; }
        public int AssessorTemplateID { get; set; }
        public string AssessorTemplateName { get; set; }
        public string ModifiedBy_NTID { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedAt { get; set; }
        public int ModifiedBy_UserID { get; set; }
        public DateTime CreatedAt { get; set; }
        public int CreatedBy_UserID { get; set; }
    }
}
