﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class Role
    {
        public int RoleID { get; set; }

        public string RoleName { get; set; }

    }

    public class RoleList
    {
        public List<Role> RolesList { get; set; }

        public int TotalRecords { get; set; }

    }
}
