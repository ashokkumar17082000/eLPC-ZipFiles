﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class Audit
    {
        public int AuditID { get; set; }
        public string TagName { get; set; }
        public string TagDisplayName { get; set; }
        public int TagTypeID { get; set; }
        public int IsSearchableTag { get; set; }
        public int IsSkipQuestionDefined { get; set; }
        public int IsQuestionOverviewDefined { get; set; }
        public int IsProgressPercentageDefined { get; set; }
        public int IsResultOverviewDefined { get; set; }
        public int IsResumeTagDefined { get; set; }
        public int IsReportingEmailDefined { get; set; }
        public int IsMandatoryAssessorsDefined { get; set; }
        public DateTime StartDate { get; set; }
        public TimeSpan StartTime { get; set; }
        public DateTime EndDate { get; set; }
        public TimeSpan EndTime { get; set; }
        public bool IsRecurring { get; set; }
        public bool IsAllDay { get; set; }
        public int ValueStreamID { get; set; }

        public  List<int> ValueStreamIDs { get; set; }

        public string Remarks { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime ModifiedAt { get; set; }
        public int CreatedBy_UserID { get; set; }
        public int ModifiedBy_UserID { get; set; }
        public bool IsDeleted { get; set; }
        public bool? IsAuditCompleted { get; set; }
        public List<Tag> AssignedTags { get; set; }
        public List<User> RequiredAttendees { get; set; }
        public List<User> OptionalAttendees { get; set; }
        public int TagID { get; set; }
        public string CreatedBy_NTID { get; set; }
        public string ModifiedBy_NTID { get; set; }
        public string Location { get; set; }
        public string ValueStreamName { get; set; }
        public List<string> ValueStreamNames { get; set; }
        public List<ValueStreamNameAndID> ValueStreamNameAndID{ get; set; }

        public List<ValueStream> ValueStreams { get; set; }
        public string Organizer { get; set; }
        public string EmailAddress { get; set; }
        public string CalendarUrl { get; set; }
        public string displayName { get; set; }
        public string LanguageCode { get; set; }
        public int Recurrence_TypeId { get; set; }
        public int Recurrence_Interval { get; set; }
        public string Recurrence_DayOfWeek { get; set; }
        public int Recurrence_DayOfMonth { get; set; }
        public int Recurrence_WeekOfMonth { get; set; }
        public int Recurrence_MonthOfYear { get; set; }
        public string TagTypeName { get; set; }
        public string PlantCode { get; set; }
        public int TemplateID { get; set; }

        public DateTime? AnsweredTimeStamp { get; set; }
        public string AnsweredStatus { get; set; }
        public string AssessorName { get; set; }
        public int? AnswerPercentage { get; set; }
        public int? AnswerdQuestionCount { get; set; }
        public int? UnAnswerdQuestionCount { get; set; }
        public DateTime? AnswerStartDate { get; set; }
        public DateTime? AnswerEndDate { get; set; }
        public string RequiredAttendeeStr { get; set; }
        public string OptionalAttendeeStr { get; set; }
        public int AnonymizeUserDataSettingID { get; set; }
    }

    public class Recurrence
    {
        public int RecurrenceType { get; set; }
        public int Interval { get; set; }
        public string DayOfWeek { get; set; }
        public int DayOfMonth { get; set; }
        public int WeekOfMonth { get; set; }
        public int MonthOfYear { get; set; }

    }

    public enum RecurrenceType
    {
        Daily_NDays = 11,
        Weekly_XDayofWeek = 21,
        Monthly_DayOfMonth = 31,
        Monthly_Nth_DayOfMonth = 32,
        Monthly_Nth_WeekDayOfMonth = 33,
        Monthly_Nth_WeekendDayOfMonth = 34,
        Monthly_Nth_XDayOfMonth = 35,
        Yearly_DayOfMonth = 41,
        Yearly_Nth_DayOfMonth = 42,
        Yearly_Nth_WeekDayOfMonth = 43,
        Yearly_Nth_WeekendDayOfMonth = 44,
        Yearly_Nth_XDayOfMonth = 45
    }

    public class AuditAnswerSummary
    {
        public int PlantID { get; set; }
        public int AuditID { get; set; }
        public int AuditTemplateID { get; set; }
        public string LanguageCode { get; set; }
        public string From { get; set; }
        public string To { get; set; }
        public string Cc { get; set; }
        public string Subject { get; set; }
        public string LeadAuditor { get; set; }
        public string Attendees { get; set; }
        public string ValueStreamText { get; set; }
        public DateTime AnsweredTime { get; set; }
        public string TagName { get; set; }
        public string TagTypeName { get; set; }
        public string PlantCode { get; set; }
    }

    public class AuditSummaryQuestionAnswers
    {
        public int QuestionID { get; set; }
        public string QuestionDisplayID { get; set; }
        public string QuestionText { get; set; }
        public string Answer { get; set; }
        public string DeviationDescription { get; set; }
    }

    public class TagDetails
    {
        public int QuestionID { get; set; }
        public string ResponseType { get; set; }
    }
}
