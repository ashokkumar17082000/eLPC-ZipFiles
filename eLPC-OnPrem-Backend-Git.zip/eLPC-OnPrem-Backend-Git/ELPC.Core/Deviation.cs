﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class Deviation
    {

        public int DeviationId { get; set; }
        public int DeviationDisplayId { get; set; }
        public int ValueStreamID { get; set; }
        //public int TagID { get; set; }
        public string DeviationDescription { get; set; }
        public string ResponsibleEmployee { get; set; }
        public int QuestionID { get; set; }
        public int QuestionDisplayID { get; set; }
        public string CreatedBy_NTID { get; set; }
        public string ModifiedBy_NTID { get; set; }
        public int DeviationAttachmentID { get; set; }
        public string ManagerEmailAddress { get; set; }
        public string ResponsibleEmployeeEmailAddress { get; set; }
        public string UserEmailAddress { get; set; }
        public string UserName { get; set; }
        public string ValueStreamName { get; set; }
        public string QuestionText { get; set; }
        public string QuestionChoiceAnswer { get; set; }
        public string QuestionLinkedTags { get; set; }
        public string TagName { get; set; }
        public string Owner { get; set; }
        public string ResponsibleEmployeeID { get; set; }
        public virtual List<HintImage> HintImages { get; set; }
        public virtual List<HintImage> HintTempImages { get; set; }
        public virtual List<Tag1> selectedTagData { get; set; }
        public List<User> AdditionalEmployee { get; set; }
        public bool IsDeleted { get; set; }
        public string CreatedBy_Name { get; set; }
        public string CreatedByEmployee { get; set; }

        public string PathUrl { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int AuditID { get; set; }
        public int AuditTemplateID { get; set; }
        public int DeviationTypeID { get; set; }
        public string ResponsibleEmpNTID { get; set; }
        public string OwnerNTID { get; set; }
        public int AuditDeviationID { get; set; }
        public string SuperOPLURL { get; set; }
        public string SuperOPLNewTaskURL { get; set; }
        public string LanguageCode { get; set; }
        public int SchedulerID { get; set; }

        public string selectedtag { get; set; }
    }
    public class Tag1
    {
        public String FormattedTag { get; set; }
        public int TagID { get; set; }

    }
  

}
