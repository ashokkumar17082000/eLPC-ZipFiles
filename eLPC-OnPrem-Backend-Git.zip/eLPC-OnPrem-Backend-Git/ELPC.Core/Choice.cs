﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class Choice
    {
        public int ChoiceID { get; set; }

        public string ChoiceName { get; set; }

        public decimal ChoiceScore { get; set; }

        public bool IsDeviationEntryRequired { get; set; }

        public int DeviationTypeID { get; set; }

        public string AnswerCategory { get; set; }
    }
}
