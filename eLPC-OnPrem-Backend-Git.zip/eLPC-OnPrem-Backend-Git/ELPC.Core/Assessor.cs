﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class Assessor
    {
        public int? ID { get; set; } //for Assigned Assessor in question
        public int AssessorID { get; set; }
        public string AssessorName { get; set; }
        public string Category { get; set; }
        public string AssessorCategoryName { get; set; }
        public string TargetFrequencyLowLimit { get; set; }
        public string TargetFrequencyValue { get; set; }
        public string AssessorCategoryID { get; set; }
        public int AssessorTemplateID { get; set; }
        public string TargetFrequencyTypeID { get; set; }
        public string TempID { get; set; }
        public bool IsMandatoryAssessor { get; set; }

        public string AssessorTemplateName { get; set; }
        
    }
}
