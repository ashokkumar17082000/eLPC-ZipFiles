﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
  public class SingleLineText
  {
        public int ID { get; set; }
        public int? MaxCharacters { get; set; }
        public bool IsCalculated { get; set; }
        public string DefaultValue { get; set; }
        public int QuestionID { get; set; }
  }
}
