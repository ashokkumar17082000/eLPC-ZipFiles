﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class Plant
    {
        public int PlantID { get; set; }
        public string PlantCode { get; set; }
        public string PlantName { get; set; }
        public string IdMStandardRole { get; set; }
        public string IdMDesignerRole { get; set; }
        public string DefaultLanguage { get; set; }
        public string TimeZone { get; set; }
        public string PowerBISecurityGroup { get; set; }
        public bool IsTranslationFromAPI { get; set; }
        public bool IsActive { get; set; }
        public string GeneralMessage { get; set; }
        public bool IsUnderMaintenance { get; set; }
        public string UnderMaintenanceMessage { get; set; }
        public string NotAuthorizedMessage { get; set; }
        public string PlantAvaliablityMessage { get; set; }
        public int CurrentRoleID { get; set; }
        public string CurrentRole { get; set; }
        public bool IsDefault { get; set; }
        public string MarqueeAlert { get; set; }
        public bool IsMasterDataAvailable { get; set; }
        public bool IsActiveAzurePlant { get; set; }
        public string IdmMor { get; set; }

    }
}
