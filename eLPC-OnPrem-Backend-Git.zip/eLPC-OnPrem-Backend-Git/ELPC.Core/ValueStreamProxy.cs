﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class ValueStreamProxy
    {
        public int ID { get; set; }
        public int ValueStreamTemplateID { get; set; }
        public List<User> Proxies { get; set; }
        public string Proxy { get; set; }
        public string CreatedBy_NTID { get; set; }
        public string ModifiedBy_NTID { get; set; }
        public string NTID { get; set; }
        public string UserName { get; set; }

        public bool IsLocked { get; set; }
    }
}
