﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class AuditDetail
    {
        public int AuditDetailID { get; set; }
        public int AuditID { get; set; }
        public int ValueStreamID { get; set; }
        public User LeadAuditor { get; set; }
        public User HOD { get; set; }
        public User FloorManager { get; set; }
        public User QMM { get; set; }
        public virtual List<User> Others { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime ModifiedAt { get; set; }
        public int ModifiedBy_UserID { get; set; }
        public int CreatedBy_UserID { get; set; }
    }
}
