﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class EmailData
    {
       
        public int id { get; set; }
        public string LanguageCode { get; set; }
        public string Template { get; set; }
        public string Subject { get; set; }
        public string Content { get; set; }
        public byte[] Image { get; set; }
    }
  
}
