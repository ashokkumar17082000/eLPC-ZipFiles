﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace ELPC.Core
{
    public class HintImage
    {
        public int ID { get; set; }

        public int QuestionID { get; set; }

        public string ImageTitle { get; set; }

        public string ImagePath { get; set; }

        public string FileContent { get; set; }

        public byte[] ByteData {get; set; }

        public int DeviationAttachmentsID { get; set; }

        public Object MyformData { get; set; }

        public string DisplayFileName { get; set; }

        public void CopyTo(FileStream stream)
        {
            throw new NotImplementedException();
        }
    }
}
