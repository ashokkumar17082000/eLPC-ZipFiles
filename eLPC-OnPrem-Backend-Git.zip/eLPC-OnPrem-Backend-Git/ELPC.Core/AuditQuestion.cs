﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class AuditQuestion
    {
        public int AuditID { get; set; }
        public int QuestionID { get; set; }
        public int QuestionDisplayID { get; set; }
        public string QuestionText { get; set; }
        public string QuestionHintText { get; set; }
        public int AnswerTypeID { get; set; }
        public string Answer { get; set; }
        public string choiceAnswer { get; set; }        
        public bool IsAnswered { get; set; }
        public bool IsAnswerRequired { get; set; }
        public bool IsDefaultAnswerRequired { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime ModifiedAt { get; set; }
        //public int CreatedBy_UserID { get; set; }
        //public int ModifiedBy_UserID { get; set; }
        public string CreatedBy_NTID { get; set; }
        public string ModifiedBy_NTID { get; set; }
        public int ID { get; set; }
        public int TagID { get; set; }
        public int AuditTemplateID { get; set; }
        public int TagTemplateID { get; set; }
        public virtual List<AuditAssessor> AuditAssessors { get; set; }
        public virtual List<AuditAssessor> Others { get; set; }
        public string ModifiedBy { get; set; }
        public string ValueStreamName { get; set; } //to display in pending audit history

        public string ValueStreamID { get; set; }
       // public int valueStreamID { get; set; }

        public int[] ValueStreamIDs { get; set; }

        public int DefaultChoiceID { get; set; }
        public Deviation Deviation { get; set; }
        public int IsBranchLogicToBeFollowed { get; set; }
        public bool QuestionType { get; set; }

    }
}
