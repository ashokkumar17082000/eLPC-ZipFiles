﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ELPC.Core
{
    public class Question
    {
        public int QuestionID { get; set; }
        public int QuestionDisplayID { get; set; }
        public string QuestionText { get; set; }
        public string QuestionHintText { get; set; }
        public int? AnswerType_AnswerTypeID { get; set; }
        public int? ChoiceDisplayTypeID { get; set; }
        public bool? IsFilledInChoiceAllowed { get; set; }
        public bool? IsUniqueAnswerRequired { get; set; }
        public bool? IsAnswerRequired { get; set; }
        public bool? IsDefaultAnswerRequired { get; set; }
        public int? DefaultChoiceID { get; set; }
        public string DefaultChoice { get; set; }
        public bool? IsQuestionAlwaysActive { get; set; }
        public DateTime? ActiveDateRangeFrom { get; set; }
        public DateTime? ActiveDateRangeTo { get; set; }
        public bool? IsTargetFrequencyDefined { get; set; }
        public int? TargetFrequencyTypeID { get; set; }

        public string TargetFrequencyValue { get; set; }
        public int? Question_PriorityID { get; set; }
        public bool? IsLocked { get; set; }
        public int? CreatedBy_UserID { get; set; }
        public int? ModifiedBy_UserID { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        //public int? Assigned_ValueStreamTemplateID { get; set; }
        //public int? Assigned_ValueStreamCategoryID { get; set; }
        //public int? Assigned_AssessorTemplateID { get; set; }
        public int? Assigned_AssessorID { get; set; }
        public bool? IsDeleted { get; set; }
        public DateTime? ModifiedAt { get; set; }
        public DateTime? CreatedAt { get; set; }
        public Object hintImage { get; set; }
        public virtual HintHyperLink hintHyperLink { get; set; }
        public virtual SingleLineText singleLineText { get; set; }
        public virtual MultipleLinesText multipleLinesText { get; set; }
        public virtual AnswerTypeCurrency answerTypeCurrency { get; set; }
        public virtual AnswerTypeDateTime answerTypeDateTime { get; set; }
        public virtual AnswerTypeNumber answerTypeNumber { get; set; }
        public virtual RatingScale ratingScale { get; set; }
        public virtual List<SubQuestion> subQuestions { get; set; }
        public virtual List<Choice> Choices { get; set; }
        public virtual List<HintHyperLink> HintHyperLinks { get; set; }
        public virtual List<HintImage> HintImages { get; set; }

        public virtual List<ValueStream> valueStreams { get; set; }
        public virtual List<Assessor> assessors { get; set; }
        public virtual List<Tag> tags { get; set; }
        public virtual List<AssignedTargetFrequency> assignedTargetFrequencies { get; set; }
        public string CreatedBy_NTID { get; set; }
        public string ModifiedBy_NTID { get; set; }
        public int CustomQuestionTagsID { get; set; }


        public string HyperLinkUrl { get; set; }

        public string ValueStreamNameList { get; set; }

        public List<QuestionDetail> questionDetail { get; set; }

        public bool? IsAccessible { get; set; }

        public int RandomQuestionOrder { get; set; }

        public int QuestionType { get; set; }
    }

     public class RandomQuestion
    {
        public int QuestionID { get; set; }

        public int QuestionIndex { get; set; }

        public string QuestionText { get; set; }


        public int QuestionType { get; set; }
    }
}
