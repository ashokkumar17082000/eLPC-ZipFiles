﻿using ELPC.BAL.Interfaces;
using ELPC.Core;
using ELPC.DAL.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ELPC.BAL.Implementation
{
    public class MergeService : IMergeService
    {
        public readonly IMergeRepository _mergeRepository;

        public MergeService(IMergeRepository mergeRepository)
        {
            _mergeRepository = mergeRepository;
        }

        public Task<Result> MergeQuestionAssignment(Merge mergeQuestionAssignment)
        {
            var result = _mergeRepository.MergeQuestionAssignment(mergeQuestionAssignment);
            return result;
        }

        public Task<Result> MergeTagAssignment(Merge mergeTagAssignment)
        {
            var result = _mergeRepository.MergeTagAssignment(mergeTagAssignment);
            return result;
        }

        public Task<Result> MergeQuestionRemoval(Merge mergeQuestionRemoval)
        {
            var result = _mergeRepository.MergeQuestionRemoval(mergeQuestionRemoval);
            return result;
        }

        public Task<Result> MergeTagRemoval(Merge mergeTagRemoval)
        {
            var result = _mergeRepository.MergeTagRemoval(mergeTagRemoval);
            return result;
        }

        public Task<Result> MergeQuestionProxy(MergeProxy questionProxy)
        {
            var result = _mergeRepository.MergeQuestionProxy(questionProxy);
            return result;
        }

        public Task<Result> MergeTagProxy(MergeProxy tagProxy)
        {
            var result = _mergeRepository.MergeTagProxy(tagProxy);
            return result;
        }
    }


}
