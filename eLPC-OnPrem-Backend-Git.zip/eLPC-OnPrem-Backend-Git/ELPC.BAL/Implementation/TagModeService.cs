﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using ELPC.BAL.Interfaces;
using ELPC.Core;
using ELPC.DAL.Interfaces;

namespace ELPC.BAL.Implementation
{
    public class TagModeService:ITagModeService
    {
        public readonly ITagModeRepository _tagModeRepository;
        public TagModeService(ITagModeRepository tagModeRepository)
        {
            _tagModeRepository = tagModeRepository;
        }
        public  async Task<List<TagMode>> GetTagModeByNTID(string NTID)
        {
            var x = await _tagModeRepository.GetTagModeByNTID(NTID);
            return x;
        }
        public Task<Result> InsertToTagMode(TagMode TagMode)
        {
            var x = _tagModeRepository.InsertToTagMode(TagMode);
            return x;
        }
        public Task<List<Tag>> GetTagModeTags()
        {
            var x = _tagModeRepository.GetTagModeTags();
            return x;
        }

        public Task<List<Tag>> GetTagModeTagsCalendar()
        {
            var x = _tagModeRepository.GetTagModeTagsCalendar();
            return x;
        }
        public Task<Result> DeleteTagMode(TagMode TagMode)
        {
            var x = _tagModeRepository.DeleteTagMode(TagMode);
            return x;
        }
        public Task<List<Question>> GetInfoQuestionsByTagID(int tagID)
        {
            var x = _tagModeRepository.GetInfoQuestionsByTagID(tagID);
            return x;
        }

        #region TagMode Audit
        public Task<Result> AddEditTagModeQuestion(AuditQuestion auditQuestion)
        {
            var result = _tagModeRepository.AddEditTagModeQuestion(auditQuestion);            
            return result;
        }

        public Task<List<AuditQuestion>> FetchTagModeQuestionsByCurrentAssessorAndTemplateID(int tagID, string NTID)
        {
            var result = _tagModeRepository.FetchTagModeQuestionsByCurrentAssessorAndTemplateID(tagID, NTID);
            return result;
        }

        #endregion

    }
}
