﻿using ELPC.BAL.Interfaces;
using ELPC.Core;
using ELPC.DAL.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using System.Threading;

namespace ELPC.BAL.Implementation
{
    
    public class ProcessConfirmationService: IProcessConfirmationService
    {
        public readonly IProcessConfirmationRepository _processConfirmationRepository;
        private static readonly ThreadLocal<Random> _random = new ThreadLocal<Random>(() => new Random());
        public ProcessConfirmationService(IProcessConfirmationRepository processConfirmationRepository)
        {
            _processConfirmationRepository = processConfirmationRepository;
        }

        //public  async Task<List<ProcessConfirmation>> GetProcessConfirmation(ProcessConfirmation processConfirmation)
        //{
        //    var x = await _processConfirmationRepository.GetProcessConfirmation(processConfirmation);
        //    return x;
        //}

        public async Task<List<ProcessConfirmation>> GetProcessConfirmation(ProcessConfirmation processConfirmation)
        {
            List<ProcessConfirmation> result = new List<ProcessConfirmation>();
            var x = await _processConfirmationRepository.GetProcessConfirmation(processConfirmation);

            if (processConfirmation.ModeType == "tag" || processConfirmation.ModeType == "calendarTag")
            {
                result = RandomLogicForTagMode(x);
            }
            else
            {
                result = x;
            }

            return result;
        }
        private List<ProcessConfirmation> RandomLogicForTagMode(List<ProcessConfirmation> x)
        {
            List<ProcessConfirmation> result = new List<ProcessConfirmation>();

            try
            {
                if (x != null && x.Any())
                {
                    int isBranchOn = x.First().IsBranchLogicToBeFollowed;

                    if (isBranchOn == 0 || isBranchOn == 1)
                    {
                        result = ApplyShuffleLogic(x, isBranchOn == 1);
                    }
                    else
                    {
                        result = x;
                    }
                }
            }
            catch (Exception e)
            {
                //Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));

                // _telemetryClient.TrackTrace("ProcessConfirmationService: " + e.Message, Microsoft.ApplicationInsights.DataContracts.SeverityLevel.Information);
            }

            return result;
        }

        private List<ProcessConfirmation> ApplyShuffleLogic(List<ProcessConfirmation> questions, bool separateQuestionType)
        {
            List<ProcessConfirmation> result;

            var uniqueQuestions = ExtractUniqueQuestions(questions);
            var questionTypeTrue = FilterByQuestionType(uniqueQuestions, true);
            var questionTypeFalse = FilterByQuestionType(uniqueQuestions, false);

            if (separateQuestionType)
            {
                var shuffledQuestions = ShuffleQuestions(questionTypeFalse);
                result = questionTypeTrue.Concat(shuffledQuestions).ToList();
            }
            else
            {
                var shuffledQuestions = ShuffleQuestions(uniqueQuestions);
                result = shuffledQuestions;
            }

            return result;
        }

        private List<ProcessConfirmation> ExtractUniqueQuestions(List<ProcessConfirmation> questions)
        {
            return questions
                .GroupBy(q => q.QuestionID)
                .Select(g => g.First())
                .ToList();
        }

        private List<ProcessConfirmation> FilterByQuestionType(List<ProcessConfirmation> questions, bool questionType)
        {
            return questions
                .Where(q => q.QuestionType == questionType)
                .ToList();
        }

        private List<ProcessConfirmation> ShuffleQuestions(List<ProcessConfirmation> questions)
        {
            var answeredQuestions = questions.Where(q => q.Answer != null).ToList();
            var unansweredQuestions = questions.Where(q => q.Answer == null).ToList();

            ShuffleList(answeredQuestions);
            ShuffleList(unansweredQuestions);

            return answeredQuestions.Concat(unansweredQuestions).ToList();
        }

        private void ShuffleList<T>(List<T> list)
        {
            int n = list.Count;
            Random rng = _random.Value;
            while (n > 1)
            {
                n--;
                int k = rng.Next(n + 1);
                var value = list[k];
                list[k] = list[n];
                list[n] = value;
            }
        }




        public int  pendingTagModeStatus(ProcessConfirmation processConfirmation)
        {
            if (processConfirmation.HintImages != null)
            {
                for (int i = 0; i < processConfirmation.HintImages.Count; i++)
                {
                    if (processConfirmation.HintImages[i] != null && (processConfirmation.HintImages[i].ID == 0))
                    {
                        var temp = processConfirmation.HintImages[i].FileContent.Split(';')[0];
                        var Image = processConfirmation.HintImages[i].FileContent.Replace(temp + ";base64,", string.Empty);
                        processConfirmation.HintImages[i].ByteData = Convert.FromBase64String(Image);
                    }
                }
            }
            var result = _processConfirmationRepository.pendingTagModeStatus(processConfirmation);
            return result;
        }

        public  async Task<Result> InsertProcessConfirmation(ProcessConfirmation processConfirmation)
        {
            if (processConfirmation.HintImages != null)
            {
                for (int i = 0; i < processConfirmation.HintImages.Count; i++)
                {
                    if (processConfirmation.HintImages[i] != null && (processConfirmation.HintImages[i].ID == 0))
                    {
                        var temp = processConfirmation.HintImages[i].FileContent.Split(';')[0];
                        var Image = processConfirmation.HintImages[i].FileContent.Replace(temp + ";base64,", string.Empty);
                        processConfirmation.HintImages[i].ByteData = Convert.FromBase64String(Image);
                    }
                }
            }
            var result = await  _processConfirmationRepository.InsertProcessConfirmation(processConfirmation);
            return result;
        }

        public int updateEventEndTime(String eventstarttime, ProcessConfirmation processConfirmationdata)
        {
            var result = _processConfirmationRepository.updateEventEndTime(eventstarttime,processConfirmationdata);
            return 1;
        }

        public Task<Result> AddToCustomMode(ProcessConfirmation processConfirmation)
        {
            var result = _processConfirmationRepository.AddToCustomMode(processConfirmation);
            return result;
        }
        public Task<Result> DeleteFromCustomMode(ProcessConfirmation processConfirmation)
        {
            var x = _processConfirmationRepository.DeleteFromCustomMode(processConfirmation);
            return x;
        }

        public Task<List<ValueStream>> GetValueStreamByQuestionID(int QuestionID)
        {
            var x = _processConfirmationRepository.GetValueStreamByQuestionID(QuestionID);
            return x;
        }

        public Task<List<Assessor>> GetAssessorsByQuestionID(int QuestionID)
        {
            var x = _processConfirmationRepository.GetAssessorsByQuestionID(QuestionID);
            return x;
        }

        public Task<int> getSelectedLinkedTagQuestionCount(int TagId, Boolean maintablequestioncount = false)
        {
            var x = _processConfirmationRepository.getSelectedLinkedTagQuestionCount(TagId, maintablequestioncount);
            return x;
        }



    }
}
