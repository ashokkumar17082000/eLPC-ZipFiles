﻿using ELPC.BAL.Interfaces;
using ELPC.Core;
using ELPC.DAL.Interfaces;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace ELPC.BAL.Implementation
{
    public class DataPoolService:IDataPoolService
    {
        public readonly IDataPoolRepository _dataPoolRepository;
        public DataPoolService(IDataPoolRepository dataPoolRepository)
        {
            _dataPoolRepository = dataPoolRepository;
        }
        public async Task<List<ProcessConfirmation>> GetDeviationDataPool(SearchFilter filter = null)
        {
            var x = await _dataPoolRepository.GetDeviationDataPool(filter);
            return x;
        }

        public Task<List<HintImage>> GetDeviationFileByAttachmentID(int attachmentID)
        {
            var x = _dataPoolRepository.GetDeviationFileByAttachmentID(attachmentID);
            return x;
        }

        public async Task<List<ProcessConfirmation>> GetDataPool(SearchFilter filter = null)
        {
            var x =await _dataPoolRepository.GetDataPool(filter);
            return x;
        }
        
        public Task<List<ProcessConfirmation>> GetProcessConfirmationByID(int dataPoolID)
        {
            var x = _dataPoolRepository.GetProcessConfirmationByID(dataPoolID);
            return x;
        }
        public Task<List<HintImage>> HintImagesByDeviationID(int deviationID)
        {
            var x = _dataPoolRepository.HintImagesByDeviationID(deviationID);
            return x;
        }
        public Task<Result> UpdateDataPool(ProcessConfirmation processConfirmation)
        {
            if (processConfirmation.HintImages != null)
            {
                for (int i = 0; i < processConfirmation.HintImages.Count; i++)
                {
                    if (processConfirmation.HintImages[i] != null && (processConfirmation.HintImages[i].ID == 0))
                    {
                        var temp = processConfirmation.HintImages[i].FileContent.Split(';')[0];
                        int ix = temp.IndexOf("/");
                        string ext = string.Empty;
                        if (ix != -1)
                        {
                            ix++;
                            ext = temp.Substring(ix).ToLower();
                        }
                        var Image = processConfirmation.HintImages[i].FileContent.Replace(temp + ";base64,", string.Empty);
                        processConfirmation.HintImages[i].ByteData = Convert.FromBase64String(Image);
                    }
                }
            }
            var result = _dataPoolRepository.UpdateDataPool(processConfirmation);
            return result;
        }
        public Task<Result> DeleteDataPool(ProcessConfirmation processConfirmation)
        {
            var x = _dataPoolRepository.DeleteDataPool(processConfirmation);
            return x;
        }


        public  DataSet DataPoolExportExcelTemplate(string UspName, bool IsUserReport, List<int> IDs = default)
        {
            DataSet result = new DataSet();
            result =   _dataPoolRepository.DataPoolExportExcelTemplate(UspName, IsUserReport, IDs);
            return result;
        }

        

        public  DataSet DataPoolExportExcelTemplateFilter(string UspName,string fromDate,string toDate, bool IsUserReport, List<int> IDs = default)
        {
            DataSet result = new DataSet();
            result =   _dataPoolRepository.DataPoolExportExcelTemplateFilter(UspName,fromDate,toDate, IsUserReport, IDs);
            return result;
        }
           
        
        public Task<List<DataPoolHistory>> GetDataPoolHistory(int templateID)
        {
            var x = _dataPoolRepository.GetDataPoolHistory(templateID);
            return x;
        }

        public Task<Result> DataPoolRestoreByTemplateHistoryID(int historyID)
        {
            var x = _dataPoolRepository.DataPoolRestoreByTemplateHistoryID(historyID);
            return x;
        }


    }
}
