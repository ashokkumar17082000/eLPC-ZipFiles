﻿using ELPC.BAL.Interfaces;
using ELPC.Core;
using ELPC.DAL.Interfaces;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ELPC.BAL.Implementation
{
    public class QuestionService: IQuestionService
    {
        public readonly IQuestionRepository _questionRepository;
        public QuestionService(IQuestionRepository questionRepository)
        {
            _questionRepository = questionRepository;
        }
        public Task<List<Question>> GetQuestions()
        {
            var x = _questionRepository.GetQuestions();
            return x;
        }
        public Task<List<Question>> GetCustomQuestions()
        {
            var x = _questionRepository.GetCustomQuestions();
            return x;
        }

        public Task<List<QuestionDetail>> GetQuestionDetail()
        {
            var x = _questionRepository.GetQuestionDetail();
            return x;
        }

        public Task<List<QuestionDetail>> GetQuestionDetailByID(int questionID)
        {
            var x = _questionRepository.GetQuestionDetailByID(questionID);
            return x;
        }

        public Task<List<QuestionHistory>> GetQuestionsHistory(int templateID)
        {
            var x = _questionRepository.GetQuestionsHistory(templateID);
            return x;
        }

        public Task<Result> QuestionRestoreByHistoryID(int historyID)
        {
            var x = _questionRepository.QuestionRestoreByHistoryID(historyID);
            return x;
        }

        public Task<Result> InsertQuestion(Question question)
        {

            if (question.HintImages != null && question.HintImages.Count > 0)
            {

                for (int i = 0; i < question.HintImages.Count; i++)
                {
                    if (question.HintImages[i] != null && (question.HintImages[i].ID == 0))
                    {
                        var temp = question.HintImages[i].FileContent.Split(';')[0];
                        var Image = question.HintImages[i].FileContent.Replace(temp + ";base64,", string.Empty);
                        question.HintImages[i].ByteData = Convert.FromBase64String(Image);
                    }
                }
            }
            var result = _questionRepository.InsertQuestion(question);
            return result;
        }

        /*
        public Task<Result> UpdateQuestion(Question question)
        {
            var result = _questionRepository.UpdateQuestion(question);
            return result;
        }

        public Task<Result> UploadFile(byte[] file)
        {
            var result = _questionRepository.UploadFile(file);
            return result;
        }*/

        public Task<List<HintImage>> HintImagesByQuestionID(int questionID)
        {
            var x = _questionRepository.GetHintImagesByQuestionID(questionID);
            return x;
        }
        public Task<List<HintHyperLink>> HintHyperLinksByQuestionID(int questionID)
        {
            var x = _questionRepository.GetHintHyperLinksByQuestionID(questionID);
            return x;
        }

        public async  Task<List<Choice>> GetChoicesByQuestionID(int questionID)
        {
            var x = await _questionRepository.GetChoicesByQuestionID(questionID);
            return x;
        }

        //public Task<List<SubQuestion>> SubQuestionsByQuestionID(int questionID)
        //{
        //    var x = _questionRepository.SubQuestionsByQuestionID(questionID);
        //    return x;
        //}
        public Task<List<RatingScale>> RatingScaleByQuestionID(int questionID)
        {
            var x = _questionRepository.RatingScaleByQuestionID(questionID);
            return x;
        }
        public Task<List<AnswerTypeCurrency>> CurrencySettingsByQuestionID(int questionID)
        {
            var x = _questionRepository.CurrencySettingsByQuestionID(questionID);
            return x;
        }
        public Task<List<AnswerTypeNumber>> NumberSettingsByQuestionID(int questionID)
        {
            var x = _questionRepository.NumberSettingsByQuestionID(questionID);
            return x;
        }
        public Task<List<AnswerTypeDateTime>> DateTimeSettingsByQuestionID(int questionID)
        {
            var x = _questionRepository.DateTimeSettingsByQuestionID(questionID);
            return x;
        }
        public Task<List<SingleLineText>> SingleLineTextByQuestionID(int questionID)
        {
            var x = _questionRepository.SingleLineTextByQuestionID(questionID);
            return x;
        }
        public Task<List<MultipleLinesText>> MultipleLinesTextByQuestionID(int questionID)
        {
            var x = _questionRepository.MultipleLinesTextByQuestionID(questionID);
            return x;
        }
        public Task<List<Assessor>> AssessorsByQuestionID(int questionID)
        {
            var x = _questionRepository.AssessorsByQuestionID(questionID);
            return x;
        }
        public Task<List<ValueStream>> ValueStreamsByQuestionID(int questionID)
        {
            var x = _questionRepository.ValueStreamsByQuestionID(questionID);
            return x;
        }
        public Task<List<Tag>> TagsByQuestionID(int questionID)
        {
            var x = _questionRepository.TagsByQuestionID(questionID);
            return x;
        }

        public Task<Result> DeleteQuestion(Question question)
        {
            var x = _questionRepository.DeleteQuestion(question);
            return x;
        }

        public Task<Result> InsertQuestionProxy(QuestionProxy questionProxy)
        {
            var result = _questionRepository.InsertQuestionProxy(questionProxy);
            return result;
        }

        public Task<List<QuestionProxy>> QuestionProxiesByQuestionID(int questionID)
        {
            var result = _questionRepository.QuestionProxiesByQuestionID(questionID);
            return result;
        }
        public Task<List<VSASIDList>> FetchVSASListByID(string type, string mode, int questionId, int tagId)
        {
            var result = _questionRepository.FetchVSASListByID(type, mode, questionId, tagId);
            return result;
        }
    }
}
