﻿using ELPC.BAL.Interfaces;
using ELPC.Core;
using ELPC.DAL.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ELPC.BAL.Implementation
{
    public class TagService : ITagService
    {
        public readonly ITagRepository _tagRepository;
        public TagService(ITagRepository tagRepository)
        {
            _tagRepository = tagRepository;
        }
        public Task<List<Tag>> GetTags()
        {
            var x = _tagRepository.GetTags();
            return x;
        }

        public Task<List<Tag>> GetTagsByID(int tagID)
        {
            var x = _tagRepository.GetTagsByID(tagID);
            return x;
        }

        public Task<List<TagHistory>> GetTagHistory(int templateID)
        {
            var x = _tagRepository.GetTagHistory(templateID);
            return x;
        }

        public Task<Result> TagRestoreByTemplateHistoryID(int historyID)
        {
            var result = _tagRepository.TagRestoreByTemplateHistoryID(historyID);
            return result;
        }


        public Task<Result> InsertTag(Tag tag)
        {
            var result = _tagRepository.InsertTag(tag);
            return result;
        }

        public Task<Result> DeleteTag(Tag tag)
        {
            var result = _tagRepository.DeleteTag(tag);
            return result;
        }

        public Task<List<Question>> GetQuestionsByTagID(int tagID)
        {
            var x = _tagRepository.GetQuestionsByTagID(tagID);
            return x;
        }

        public Task<List<Tag>> GetTagsByTagID(int tagID)
        {
            var x = _tagRepository.GetTagsByTagID(tagID);
            return x;
        }

        public Task<List<Assessor>> GetAssessorsByTagIDs(string tagIDs)
        {
            var x = _tagRepository.GetAssessorsByTagIDs(tagIDs);
            return x;
        }


        public Task<Result> InsertTagProxy(TagProxy tagProxy)
        {
            var result = _tagRepository.InsertTagProxy(tagProxy);
            return result;
        }

        public Task<List<Question>> FetchQuestionsByAssessorsAndValuestreams(string assessorIDs, string valueStreamIDs)
        {
            var result = _tagRepository.FetchQuestionsByAssessorsAndValuestreams(assessorIDs, valueStreamIDs);
            return result;
        }

        public Task<List<Tag>> FetchTagsByAssessorsAndValuestreams(string assessorIDs, string valueStreamIDs)
        {
            var result = _tagRepository.FetchTagsByAssessorsAndValuestreams(assessorIDs, valueStreamIDs);
            return result;
        }

        public Task<List<Assessor>> AssessorsByTagID(int tagID)
        {
            var result = _tagRepository.AssessorsByTagID(tagID);
            return result;
        }
        public Task<List<ValueStream>> ValueStreamsByTagID(int tagID)
        {
            var result = _tagRepository.ValueStreamsByTagID(tagID);
            return result;
        }
        public Task<List<TagProxy>> TagProxiesByTagID(int tagID)
        {
            var result = _tagRepository.TagProxiesByTagID(tagID);
            return result;
        }

        public Task<List<Tag>> FetchProcessConfirmationTags()
        {
            var result = _tagRepository.FetchProcessConfirmationTags();
            return result;
        }

        public Task<List<Tag>> FetchTagDetailsByTagID(int tagID)
        {
            var result = _tagRepository.FetchTagDetailsByTagID(tagID);
            return result;
        }

        public Task<Result> UpdateAuditByTagID(int tagID)
        {
            var result = _tagRepository.UpdateAuditByTagID(tagID);
            return result;
        }
    }
}
