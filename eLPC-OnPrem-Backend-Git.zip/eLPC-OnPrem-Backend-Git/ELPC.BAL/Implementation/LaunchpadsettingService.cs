﻿using ELPC.BAL.Interfaces;
using ELPC.Core;
using ELPC.DAL.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ELPC.BAL.Implementation
{
    public class LaunchpadsettingService : ILaunchpadsettingService
    {
        public readonly ILaunchpadsettingRepository _launchpadsettingRepository;

        public LaunchpadsettingService(ILaunchpadsettingRepository launchpadsettingRepository)
        {
            _launchpadsettingRepository = launchpadsettingRepository;
        }
        public Task<Result> InsertLaunchpadURL(ReportText reportText)
        {
            var result = _launchpadsettingRepository.InsertLaunchpadURL(reportText);
            return result;
        }

        public Task<Result> LaunchpadHistoryID(int historyID)
        {
            var x = _launchpadsettingRepository.LaunchpadHistoryID(historyID);
            return x;
        }

        public Task<List<ReportText>> GetLaunchpad()
        {
            var x = _launchpadsettingRepository.GetLaunchpad();
            return x;
        }

        public Task<List<Reportrestore>> GetRestoredata()
        {
            var x = _launchpadsettingRepository.GetRestoredata();
            return x;
        }
    }
}
