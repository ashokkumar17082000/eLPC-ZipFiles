﻿using ELPC.BAL.Interfaces;
using ELPC.Core;
using ELPC.DAL.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Serilog;

namespace ELPC.BAL.Implementation
{
    public class CommonService : ICommonService
    {
        public readonly ICommonRepository _commonRepository;
        public CommonService()
        {
            
        }
        public CommonService(ICommonRepository commonRepository)
        {
            _commonRepository = commonRepository;
        }

        public async Task<List<AnswerType>> GetAnswerTypes()
        {
            var x = _commonRepository.GetAnswerTypes();
            return await x;
        }

        public async Task<List<ChoiceDisplayType>> GetChoiceDisplayTypes()
        {
            var x = _commonRepository.GetChoiceDisplayTypes();
            return await x;
        }

        public async Task<List<User>> GetUsers()
        {
            var x = _commonRepository.GetUsers();
            return await x;
        }
        public async Task<Result> InsertUser(User user)
        {
            var x = _commonRepository.InsertUser(user);
            return await x;
        }

        public async Task<User> GetUserByNTID(string NTID)
        {
            var x = _commonRepository.GetUserByNTID(NTID);
            return await x;
        }

        public  Task<Result> InsertIntoDeviation(Deviation deviation)
        {
            var x =  _commonRepository.InsertIntoDeviation(deviation);
            return x;
        }

        public Task<Result> InsertIntoDeviationAttachments(Deviation deviation)
        {
            Log.Information("InsertInto Attachment Sevice Line 61");
            var x = _commonRepository.InsertIntoDeviationAttachments(deviation);
            Log.Information("InsertInto Attachment Sevice Line 63");
            return x;
        }

        public Task<Result> DeletetempAttachments(Deviation deviation)
        {
            var x = _commonRepository.DeletetempAttachments(deviation);
            return x;
        }
        public Task<Result> InsertIntoAuditDeviation(Deviation deviation)
        {
            var x = _commonRepository.InsertIntoAuditDeviation(deviation);
            return x;
        }

        public Task<Result> AddUsers(List<User> users)
        {
            var result = _commonRepository.AddUsers(users);
            return result;
        }

        public   Task<Result> SendDeviationEmail(Deviation deviation, Dictionary<string, byte[]> emailimage)
        {
            var result =  _commonRepository.SendDeviationEmail(deviation,emailimage);
            return result;
        }

        public async Task<Result> GetConfigByPlantIDAndConfigType(int plantID, string configType)
        {
            var x = _commonRepository.GetConfigByPlantIDAndConfigType(plantID, configType);
            return await x;
        }

        public async Task<UserDetails> FetchUserAccessDetails(User user)
        {
            var x = _commonRepository.FetchUserAccessDetails(user);
            return await x;
        }

        public async Task<Result> SetDefaultPlant(User user)
        {
            var x = _commonRepository.SetDefaultPlant(user);
            return await x;
        }

        public async Task<Result> SetUserAdditionalData(string additionalData, string userNTID)
        {
            var x = _commonRepository.SetUserAdditionalData(additionalData, userNTID);
            return await x;
        }

        public async Task<UserProfileValueStreamAssessor> GetUserProfileVSAS()
        {
            var result = _commonRepository.GetUserProfileVSAS();
            return await result;
        }

       
        public async Task<Result> updateEmpoyeeID()
        {
            var result = _commonRepository.updateEmployeeID();
            return await result;
        }

        public Task<Result> AddEditUserProfileVSAS(UserProfileValueStreamAssessor userProfile)
        {
            var result = _commonRepository.AddEditUserProfileVSAS(userProfile);
            return result;
        }

        public Task<Result> UpdateUserProfileVSAS(UserProfileUpdateVSAS updateVSAS)
        {
            var result = _commonRepository.UpdateUserProfileVSAS(updateVSAS);
            return result;
        }
        
    }
}
