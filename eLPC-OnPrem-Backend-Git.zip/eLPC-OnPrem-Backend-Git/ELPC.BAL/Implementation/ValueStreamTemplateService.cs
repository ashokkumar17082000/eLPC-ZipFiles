﻿using ELPC.BAL.Interfaces;
using ELPC.Core;
using ELPC.DAL.Interfaces;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace ELPC.BAL.Implementation
{
    public class ValueStreamTemplateService : IValueStreamTemplateService
    {
        public readonly IValueStreamTemplateRepository _valuestreamtemplateRepository;
        public ValueStreamTemplateService(IValueStreamTemplateRepository valuestreamRepository)
        {
            _valuestreamtemplateRepository = valuestreamRepository;
        }

        public Task<List<ValueStreamCategory>> GetValueStreamCategoryByTemplateID(int templateID)
        {
            var x = _valuestreamtemplateRepository.GetValueStreamCategoryByTemplateID(templateID);
            return x;
        }

        public Task<List<ValueStream>> GetValueStreamsByCategoryID(int categoryID)
        {
            var x = _valuestreamtemplateRepository.GetValueStreamsByCategoryID(categoryID);
            return x;
        }

        public Task<List<ValueStreamTemplate>> GetValueStreamTemplates()
        {
            var x = _valuestreamtemplateRepository.GetValueStreamTemplates();
            return x;
        }

        public Task<List<RecycleBinTemplate>> GetRecycleBinTemplates()
        {
            var x = _valuestreamtemplateRepository.GetRecycleBinTemplates();
            return x;
        }

        public Task<List<RecycleBinTemplate>> RecycleBinHistory()
        {
            var x = _valuestreamtemplateRepository.RecycleBinHistory();
            return x;
        }

        public Task<Result> RestoreRecycleBin(List<RecycleBinTemplate> recycleTemplate)
        {
            var x = _valuestreamtemplateRepository.RestoreRecycleBin(recycleTemplate);
            return x;
        }

        public Task<Result> DeleteRecycleBin(List<RecycleBinTemplate> recycleTemplate)
        {
            var x = _valuestreamtemplateRepository.DeleteRecycleBin(recycleTemplate);
            return x;
        }

        public async Task<List<ValueStreamCategory>> GetValueStreamCategories()
        {
            var x = _valuestreamtemplateRepository.GetValueStreamCategories();
            return await x;
        }
        public Task<List<ValueStream>> GetValueStreams()
        {
            var x = _valuestreamtemplateRepository.GetValueStreams();
            return x;
        }

        public Task<List<ValueStream>> GetValueStreamsByTemplateID(int valueStreamTemplateID)
        {
            var x = _valuestreamtemplateRepository.GetValueStreamsByTemplateID(valueStreamTemplateID);
            return x;
        }
        public Task<List<Shift>> GetShiftsByTemplateID(int templateID)
        {
            var x = _valuestreamtemplateRepository.GetShiftsByTemplateID(templateID);
            return x;
        }
        public async  Task<Result> InsertValueStreamTemplate(ValueStreamTemplate valuestreamtemplate)
        {
            var result = await _valuestreamtemplateRepository.InsertValueStreamTemplate(valuestreamtemplate);
            return result;
           
        }

        public Task<Result> UpdateValueStreamTemplate(ValueStreamTemplate valuestreamtemplate)
        {
            var result = _valuestreamtemplateRepository.UpdateValueStreamTemplate(valuestreamtemplate);
            return result;
            throw new NotImplementedException();
        }


        public Task<Result> ImportExcel(ImportCombinedList importCombinedList)
        {
            var result = _valuestreamtemplateRepository.ImportExcel(importCombinedList);
            return result;

        }

        public DataSet ExportExcel()
        {
            DataSet result = new DataSet();
            result = _valuestreamtemplateRepository.ExportExcel();
            return result;
        }

        public Task<Result> InsertValueStreamProxy(ValueStreamProxy valueStreamProxy)
        {
            var result = _valuestreamtemplateRepository.InsertValueStreamProxy(valueStreamProxy);
            return result;
        }

        public Task<List<ValueStreamHistory>> GetValueStreamsHistory(int templateID)
        {
            var x = _valuestreamtemplateRepository.GetValueStreamsHistory(templateID);
            return x;
        }

        public Task<Result> ValueStreamRestoreByTemplateHistoryID(int historyID)
        {
            var x = _valuestreamtemplateRepository.ValueStreamRestoreByTemplateHistoryID(historyID);
            return x;
        }
        public Task<Result> DeleteValueStreamTemplate(ValueStreamTemplate valueStreamTemplate)
        {
            var x = _valuestreamtemplateRepository.DeleteValueStreamTemplate(valueStreamTemplate);
            return x;
        }

        public Task<List<ValueStreamProxy>> ValueStreamProxiesByTemplateID(int templateID)
        {
            var x = _valuestreamtemplateRepository.ValueStreamProxiesByTemplateID(templateID);
            return x;
        }

        public Task<List<ValueStream>> ValueStreamByValueStreamID(int valueStreamID)
        {
            var x = _valuestreamtemplateRepository.ValueStreamByValueStreamID(valueStreamID);
            return x;
        }

        public Task<List<ValueStreamTemplate>> FetchValueStreamTemplateByTemplateID(int valueStreamTemplateID)
        {
            var x = _valuestreamtemplateRepository.FetchValueStreamTemplateByTemplateID(valueStreamTemplateID);
            return x;
        }
    }
}
