﻿using ELPC.BAL.Interfaces;
using ELPC.Core;
using ELPC.DAL.Interfaces;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace ELPC.BAL.Implementation
{
    public class AssessorTemplateService : IAssessorTemplateService
    {
        public readonly IAssessorTemplateRepository _assessorTemplateRepository;
        public AssessorTemplateService(IAssessorTemplateRepository assessorTemplateRepository)
        {
            _assessorTemplateRepository = assessorTemplateRepository;
        }
        public Task<List<AssessorTemplate>> GetAssessorTemplates()
        {
            var x = _assessorTemplateRepository.GetAssessorTemplates();
            return x;
        }
        public Task<List<AssessorTemplate>> ValidateAssessorTemplateName(string assessorTemplateName)
        {
            var x = _assessorTemplateRepository.ValidateAssessorTemplateName(assessorTemplateName);
            return x;
        }
        public Task<List<AssessorStreamHistory>> GetAssessorTemplatesHistory(int templateID)
        {
            var x = _assessorTemplateRepository.GetAssessorTemplatesHistory(templateID);
            return x;
        }

        public Task<List<Assessor>> GetAssessors()
        {
            var x = _assessorTemplateRepository.GetAssessors();
            return x;
        }

        public Task<Result> InsertAssessorTemplate(AssessorTemplate assessorTemplate)
        {
            var result = _assessorTemplateRepository.InsertAssessorTemplate(assessorTemplate);
            return result;
        }

        public Task<Result> DeleteAssessorTemplate(AssessorTemplate assessorTemplate)
        {
            var result = _assessorTemplateRepository.DeleteAssessorTemplate(assessorTemplate);
            return result;
        }

        public Task<List<Assessor>> GetAssessorByTemplateID(int templateID)
        {
            var x = _assessorTemplateRepository.GetAssessorsByTemplateID(templateID);
            return x;
        }

        public Task<Result> AssessorsRestoreByTemplateHistoryID(int historyID)
        {
            var x = _assessorTemplateRepository.AssessorsRestoreByTemplateHistoryID(historyID);
            return x;
        }

        public Task<Result> AssessorImportExcel(AssessorImportCombinedList assessorImportCombinedList, string ntid)
        {
            var result = _assessorTemplateRepository.AssessorImportExcel(assessorImportCombinedList, ntid);
            return result;

        }

        public DataSet AssessorExportExcel()
        {
            DataSet result = new DataSet();
            result = _assessorTemplateRepository.AssessorExportExcel();
            return result;
        }

        public Task<Result> InsertAssessorTemplateProxy(AssessorProxy assessorProxy)
        {
            var result = _assessorTemplateRepository.InsertAssessorProxy(assessorProxy);
            return result;
        }

        public Task<List<AssessorProxy>> AssessorProxiesByAssessorTemplateID(int templateID)
        {
            var result = _assessorTemplateRepository.AssessorProxiesByAssessorTemplateID(templateID);
            return result;
        }

        public Task<List<AssessorTemplate>> FetchAssessorTemplateByTemplateID(int templateID){
            var result = _assessorTemplateRepository.FetchAssessorTemplateByTemplateID(templateID);
            return result;
        }
    }
}
