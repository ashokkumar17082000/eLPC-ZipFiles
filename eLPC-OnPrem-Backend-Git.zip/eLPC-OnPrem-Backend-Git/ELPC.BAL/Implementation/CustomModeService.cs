﻿using ELPC.BAL.Interfaces;
using ELPC.Core;
using ELPC.DAL.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ELPC.BAL.Implementation
{
   public class CustomModeService:ICustomModeService
    {
        public readonly ICustomModeRepository _customModeRepository;
        public CustomModeService(ICustomModeRepository customModeRepository)
        {
            _customModeRepository = customModeRepository;
        }
        public Task<List<CustomMode>> GetCustomModeByNTID(string NTID)
        {
            var x = _customModeRepository.GetCustomModeByNTID(NTID);
            return x;
        }
        public Task<Result> InsertCustomMode(CustomMode customMode)
        {
            var x = _customModeRepository.InsertCustomMode(customMode);
            return x;
        }
        public Task<List<Tag>> GetCustomTags()
        {
            var x = _customModeRepository.GetCustomTags();
            return x;
        }
        public Task<Result> RemoveFromCustomModeList(CustomMode customMode)
        {
            var x = _customModeRepository.RemoveFromCustomModeList(customMode);
            return x;
        }
    }
}
