﻿using ELPC.BAL.Interfaces;
using ELPC.Core;
using ELPC.DAL.Interfaces;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using System.Threading;

namespace ELPC.BAL.Implementation
{
    public class AuditService:IAuditService
    {
        public readonly IAuditRepository _auditRepository;
        private static readonly ThreadLocal<Random> _random = new ThreadLocal<Random>(() => new Random());
        public AuditService(IAuditRepository auditRepository)
        {
            _auditRepository = auditRepository;
        }
        //public Task<List<Audit>> GetAudits()
        //{
        //    var x = _auditRepository.GetAudits();
        //    return x;
        //}

        public Task<List<Audit>> FetchAuditsByNTID(string ntid, string currentMonth, string currentYear)
        {
            var x = _auditRepository.FetchAuditsByNTID(ntid,currentMonth, currentYear);
            return x;
        }
        public Task<Audit> InsertAudit(Audit audit)
        {
            var result = _auditRepository.InsertAudit(audit);

            //Utility.Utility.SendMail("fixed-term.Krishnasamy.Janarthanan@in.bosch.com", "fixed-term.Krishnasamy.Janarthanan@in.bosch.com", "ELPC Audit Appointment", "You have been invited for the audit on"+" "+audit.StartDate.ToShortDateString(),audit);

            return result;
        }

        public Task<Result> AddEditAuditQuestion(AuditQuestion auditQuestion)
        {
            var result = _auditRepository.AddEditAuditQuestion(auditQuestion);
            
            // Utility.Utility.SendMail("fixed-term.Krishnasamy.Janarthanan@in.bosch.com", "fixed-term.Krishnasamy.Janarthanan@in.bosch.com", "ELPC Audit Appointment", "You have been invited for the audit on 2/8/2019");

            return result;
        }

        public Task<Result> DeleteAudit(Audit audit)
        {
            var result = _auditRepository.DeleteAudit(audit);
            return result;
        }
        public Task<Audit> AuditByAuditID(int auditID)
        {
            var result = _auditRepository.AuditByAuditID(auditID);
            return result;
        }
        public Task<List<AuditQuestion>> AuditQuestionsByAuditID(int auditID)
        {
            var result = _auditRepository.AuditQuestionsByAuditID(auditID);
            return result;
        }
        //public Task<List<AuditQuestion>> AuditQuestionsByAuditIDSelectedValuestream(int auditID, int valueStreamID)
        //{
        //    var result = _auditRepository.AuditQuestionsByAuditIDSelectedValuestream(auditID,valueStreamID);
        //    return result;
        //}

        public async Task<List<AuditQuestion>> AuditQuestionsByAuditIDSelectedValuestream(int auditID, int valueStreamID)
        {
            var result = await _auditRepository.AuditQuestionsByAuditIDSelectedValuestream(auditID, valueStreamID);

            List<AuditQuestion> auditQuestions = new List<AuditQuestion>();

            if (result.Count > 0)
            {
                auditQuestions = RandomLogicForTagMode(result);
            }

            return auditQuestions;
        }


        private List<AuditQuestion> RandomLogicForTagMode(List<AuditQuestion> x)
        {
            List<AuditQuestion> result = new List<AuditQuestion>();

            try
            {
                if (x != null && x.Any())
                {
                    int isBranchOn = x.First().IsBranchLogicToBeFollowed;

                    if (isBranchOn == 0 || isBranchOn == 1)
                    {
                        result = ApplyShuffleLogic(x, isBranchOn == 1);
                    }
                    else
                    {
                        result = x;
                    }
                }
            }
            catch (Exception e)
            {
                // _telemetryClient.TrackTrace("ProcessConfirmationService: " + e.Message, Microsoft.ApplicationInsights.DataContracts.SeverityLevel.Information);
            }

            return result;
        }


        private List<AuditQuestion> ApplyShuffleLogic(List<AuditQuestion> questions, bool separateQuestionType)
        {
            List<AuditQuestion> result;

            var uniqueQuestions = ExtractUniqueQuestions(questions);
            var questionTypeTrue = FilterByQuestionType(uniqueQuestions, true);
            var questionTypeFalse = FilterByQuestionType(uniqueQuestions, false);

            if (separateQuestionType)
            {
                var shuffledQuestions = ShuffleQuestions(questionTypeFalse);
                result = questionTypeTrue.Concat(shuffledQuestions).ToList();
            }
            else
            {
                var shuffledQuestions = ShuffleQuestions(uniqueQuestions);
                result = shuffledQuestions;
            }

            return result;
        }

        private List<AuditQuestion> ExtractUniqueQuestions(List<AuditQuestion> questions)
        {
            return questions
                .GroupBy(q => q.QuestionID)
                .Select(g => g.First())
                .ToList();
        }

        private List<AuditQuestion> FilterByQuestionType(List<AuditQuestion> questions, bool questionType)
        {
            return questions
                .Where(q => q.QuestionType == questionType)
                .ToList();
        }

        private List<AuditQuestion> ShuffleQuestions(List<AuditQuestion> questions)
        {
            var answeredQuestions = questions.Where(q => q.Answer != null).ToList();
            var unansweredQuestions = questions.Where(q => q.Answer == null).ToList();

            ShuffleList(answeredQuestions);
            ShuffleList(unansweredQuestions);

            return answeredQuestions.Concat(unansweredQuestions).ToList();
        }

        private void ShuffleList<T>(List<T> list)
        {
            int n = list.Count;
            Random rng = _random.Value;
            while (n > 1)
            {
                n--;
                int k = rng.Next(n + 1);
                var value = list[k];
                list[k] = list[n];
                list[n] = value;
            }
        }

        public Task<List<AuditQuestion>> PendingAuditsByAuditID(int auditID)
        {
            var result = _auditRepository.PendingAuditsByAuditID(auditID);
            return result;
        }
        public int resetAuditByAuditID(int auditID)
        {
            var result = _auditRepository.resetAuditByAuditID(auditID);
            return 1;
        }
        public Task<List<AuditQuestion>> AuditQuestionsByAuditAndAssessorID(int auditID, string NTID)
        {
            var result = _auditRepository.AuditQuestionsByAuditAndAssessorID(auditID, NTID);
            return result;
        }
        public Task<List<AuditQuestion>> AuditQuestionsByCurrentAssessorAndTemplateID(int auditID, string NTID)
        {
            var result = _auditRepository.AuditQuestionsByCurrentAssessorAndTemplateID(auditID, NTID);
            return result;
        }

        //public async Task<List<AuditQuestion>> AuditQuestionsByCurrentAssessorAndTemplateID(int auditID, string NTID)
        //{
        //    var result = await _auditRepository.AuditQuestionsByCurrentAssessorAndTemplateID(auditID, NTID);

        //    List<AuditQuestion> auditQuestions = new List<AuditQuestion>();

        //    if (result.Count > 0)
        //    {
        //        auditQuestions = RandomLogicForTagMode(result);
        //    }

        //    return auditQuestions;

        //    //return result;
        //}
        //public Task<List<AuditQuestion>> AuditQuestionsByAuditAndTemplateID(int auditID, int templateID, int ValueStreamID)
        //{
        //    var result = _auditRepository.AuditQuestionsByAuditAndTemplateID(auditID, templateID, ValueStreamID);
        //    return result;
        //}

        public async Task<List<AuditQuestion>> AuditQuestionsByAuditAndTemplateID(int auditID, int templateID, int ValueStreamID)
        {
            // Await the result from the repository
            var result = await _auditRepository.AuditQuestionsByAuditAndTemplateID(auditID, templateID, ValueStreamID);

            List<AuditQuestion> auditQuestions = new List<AuditQuestion>();

            if (result.Count > 0)
            {
                auditQuestions = RandomLogicForTagMode(result);
            }

            return auditQuestions; // This will be returned as a Task<List<AuditQuestion>> due to async
        }

        public Task<Result> CompleteAuditByAuditAndTemplateID(int auditID, int templateID)
        {
            var result = _auditRepository.CompleteAuditByAuditAndTemplateID(auditID, templateID);
            return result;
        }

        public Task<List<AuditAssessor>> AuditAssessorsByAuditID(int auditID)
        {
            var result = _auditRepository.AuditAssessorsByAuditID(auditID);
            return result;
        }
        public Task<Result> UpdateAuditQuestion(AuditQuestion auditQuestion)
        {
            var result = _auditRepository.UpdateAuditQuestion(auditQuestion);
            return result;
        }
        public Task<Result> InsertAuditDetail(AuditDetail auditDetail)
        {
            var result = _auditRepository.InsertAuditDetail(auditDetail);
            return result;
        }
        public Task<List<AuditAssessor>> AuditAssessorsByAuditAndTemplateID(int auditID, int templateID)
        {
            var result = _auditRepository.AuditAssessorsByAuditAndTemplateID(auditID, templateID);
            return result;
        }
        public Task<List<AuditAssessor>> OtherAuditAssessorsByAuditAndTemplateID(int auditID, int templateID)
        {
            var result = _auditRepository.OtherAuditAssessorsByAuditAndTemplateID(auditID, templateID);
            return result;
        }
        public Task<List<ValueStream>> ValueStreamsByTagID(int tagID)
        {
            var result = _auditRepository.ValueStreamsByTagID(tagID);
            return result;
        }

        /// <summary>
        /// To validate the standard user based on audit and NTID
        /// </summary>
        /// <param name="auditID"></param>
        /// <param name="NTID"></param>
        /// <returns></returns>
        public Task<User> ValidateAssessorByAuditAndNTID(int auditID, string NTID)
        {
            var result = _auditRepository.ValidateAssessorByAuditAndNTID(auditID, NTID);
            return result;
        }

        public Task<List<User>> RequiredAttendeesByAuditID(int auditID)
        {
            var result = _auditRepository.RequiredAttendeesByAuditID(auditID);
            return result;

        }
        public Task<List<User>> OptionalAttendeesByAuditID(int auditID)
        {
            var result = _auditRepository.OptionalAttendeesByAuditID(auditID);
            return result;
        }

        public Task<Result> EmailToAttendees(Audit audit, Dictionary<string, byte[]> emailimage)
        {
            var result = _auditRepository.EmailToAttendees(audit, emailimage);
            return result;
        }

        public Task<Result> SendTagModeAnswerSummaryEmail(ProcessConfirmation processConfirmation)
        {
            return _auditRepository.SendTagModeAnswerSummaryEmail(processConfirmation);
        }

        public Task<Result> SendAnswerSummaryEmail(Audit audit)
        {
            return _auditRepository.SendAnswerSummaryEmail(audit);
        }

        public Task<Result> AuditQuestionLinkedTagDetails(TagDetails tagDetails)
        {
            return _auditRepository.AuditQuestionLinkedTagDetails(tagDetails);
        }

        public async Task<List<Audit>> FetchAuditStatusByType(string module, string currentMonth, string currentYear, int IsDesigner , string ntID)
        {
            return await _auditRepository.FetchAuditStatusByType(module, currentMonth, currentYear, IsDesigner, ntID);
        }



       
    } 
}
