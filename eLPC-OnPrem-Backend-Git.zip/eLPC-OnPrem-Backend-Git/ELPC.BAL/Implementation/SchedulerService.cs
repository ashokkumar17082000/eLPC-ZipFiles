﻿using ELPC.BAL.Interfaces;
using ELPC.Core;
using ELPC.DAL.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ELPC.BAL.Implementation
{
    public class SchedulerService : ISchedulerService
    {
        private readonly ISchedulerRepository _schedulerRepository;
        public SchedulerService(ISchedulerRepository schedulerRepository)
        {
            _schedulerRepository = schedulerRepository;
        }
        public async Task<bool> AddSchedular(Schedule schedule)
        {
            return (await _schedulerRepository.AddSchedular(schedule)).InsertedID > 0;
        }

        public async Task<bool> AddCreateOPL(Schedule schedule)
        {
       return (await _schedulerRepository.AddCreateOPL(schedule)).InsertedID > 0;
        }
    }
}
