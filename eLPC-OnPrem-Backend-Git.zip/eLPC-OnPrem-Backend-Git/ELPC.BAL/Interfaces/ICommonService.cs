﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using ELPC.Core;
using System.Threading.Tasks;

namespace ELPC.BAL.Interfaces
{
    public interface ICommonService
    {
        Task<List<AnswerType>> GetAnswerTypes();
        Task<List<ChoiceDisplayType>> GetChoiceDisplayTypes();
        Task<List<User>> GetUsers();
        Task<Result> InsertUser(User user);
        Task<User> GetUserByNTID(string NTID);
        Task<Result> InsertIntoDeviation(Deviation deviation);
        Task<Result> InsertIntoDeviationAttachments(Deviation deviation);
        Task<Result> DeletetempAttachments(Deviation deviation);
        Task<Result> InsertIntoAuditDeviation(Deviation deviation);
        Task<Result> AddUsers(List<User> users);
        Task<Result> SendDeviationEmail(Deviation deviation, Dictionary<string, byte[]> emailimage);
        Task<Result> GetConfigByPlantIDAndConfigType(int plantID, string configType);
        Task<UserDetails> FetchUserAccessDetails(User user);
        Task<Result> SetDefaultPlant(User user);
        Task<Result> SetUserAdditionalData(string additionalData, string userNTID);
        Task<UserProfileValueStreamAssessor> GetUserProfileVSAS();
        Task<Result> updateEmpoyeeID();        
        Task<Result> AddEditUserProfileVSAS(UserProfileValueStreamAssessor userProfile);
        Task<Result> UpdateUserProfileVSAS(UserProfileUpdateVSAS updateVSAS);
    }
}
