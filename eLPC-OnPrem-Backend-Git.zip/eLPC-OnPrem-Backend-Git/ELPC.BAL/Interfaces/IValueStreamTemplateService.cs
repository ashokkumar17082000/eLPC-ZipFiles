﻿using ELPC.Core;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace ELPC.BAL.Interfaces
{
    public interface IValueStreamTemplateService
    {
        Task<List<RecycleBinTemplate>> GetRecycleBinTemplates();
        Task<List<RecycleBinTemplate>> RecycleBinHistory();
        Task<Result> RestoreRecycleBin(List<RecycleBinTemplate> recycleTemplate);
             
        Task<Result> DeleteRecycleBin(List<RecycleBinTemplate> recycleTemplate);
        Task<List<ValueStreamTemplate>> GetValueStreamTemplates();
        Task<List<ValueStreamCategory>> GetValueStreamCategories();
        Task<List<ValueStream>> GetValueStreams();
        Task<List<ValueStreamHistory>> GetValueStreamsHistory(int templateID);
        Task<Result> ValueStreamRestoreByTemplateHistoryID(int historyID);
        Task<List<ValueStream>> GetValueStreamsByTemplateID(int valueStreamTemplateID);
        Task<Result> InsertValueStreamTemplate(ValueStreamTemplate valuestreamtemplate);
        Task<Result> UpdateValueStreamTemplate(ValueStreamTemplate valuestreamtemplate);
        Task<List<ValueStreamCategory>> GetValueStreamCategoryByTemplateID(int templateID);
        Task<List<ValueStream>> GetValueStreamsByCategoryID(int categoryID);

        Task<Result> ImportExcel(ImportCombinedList importCombinedList);

        DataSet ExportExcel();
        Task<Result> InsertValueStreamProxy(ValueStreamProxy valueStreamProxy);
        Task<List<Shift>> GetShiftsByTemplateID(int templateID);
        Task<Result> DeleteValueStreamTemplate(ValueStreamTemplate valueStreamTemplate);
        Task<List<ValueStreamProxy>> ValueStreamProxiesByTemplateID(int templateID);
        Task<List<ValueStream>> ValueStreamByValueStreamID(int valueStreamID);

        Task<List<ValueStreamTemplate>> FetchValueStreamTemplateByTemplateID(int valueStreamTemplateID);
       
    }
}
