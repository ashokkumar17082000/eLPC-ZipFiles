﻿using ELPC.Core;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ELPC.BAL.Interfaces
{
  public  interface ITagModeService
    {
        Task<List<TagMode>> GetTagModeByNTID(string NTID);
      
        Task<Result> InsertToTagMode(TagMode TagMode);
        Task<List<Tag>> GetTagModeTags();
        Task<List<Tag>> GetTagModeTagsCalendar();
        Task<Result> DeleteTagMode(TagMode TagMode);
        Task<List<Question>> GetInfoQuestionsByTagID(int tagID);

        #region tagmode audit
        Task<Result> AddEditTagModeQuestion(AuditQuestion auditQuestion);
        Task<List<AuditQuestion>> FetchTagModeQuestionsByCurrentAssessorAndTemplateID(int tagID, string NTID);
        # endregion
    }
}
