﻿using ELPC.Core;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ELPC.BAL.Interfaces
{
    public interface IQuestionService
    {
        Task<List<Question>> GetQuestions();
        Task<List<Question>> GetCustomQuestions();
        Task<List<QuestionDetail>> GetQuestionDetail();
        Task<List<QuestionDetail>> GetQuestionDetailByID(int questionID);
        Task<List<QuestionHistory>> GetQuestionsHistory(int templateID);
        Task<Result> QuestionRestoreByHistoryID(int historyID);
        Task<Result> InsertQuestion(Question question);
        //Task<Result> UpdateQuestion(Question question);
        //Task<Result> UploadFile(byte[] file);
        Task<List<HintImage>> HintImagesByQuestionID(int questionID);
        Task<List<HintHyperLink>> HintHyperLinksByQuestionID(int questionID);
        Task<List<Choice>> GetChoicesByQuestionID(int questionID);
        Task<List<AnswerTypeCurrency>> CurrencySettingsByQuestionID(int questionID);
        Task<List<AnswerTypeNumber>> NumberSettingsByQuestionID(int questionID);
        Task<List<AnswerTypeDateTime>> DateTimeSettingsByQuestionID(int questionID);
        Task<List<SingleLineText>> SingleLineTextByQuestionID(int questionID);
        Task<List<MultipleLinesText>> MultipleLinesTextByQuestionID(int questionID);
        //Task<List<SubQuestion>> SubQuestionsByQuestionID(int questionID);
        Task<List<RatingScale>> RatingScaleByQuestionID(int questionID);
        Task<List<Assessor>> AssessorsByQuestionID(int questionID);
        Task<List<ValueStream>> ValueStreamsByQuestionID(int questionID);
        Task<List<Tag>> TagsByQuestionID(int questionID);
        Task<Result> DeleteQuestion(Question question);
     
        Task<Result> InsertQuestionProxy(QuestionProxy questionProxy);
        Task<List<QuestionProxy>> QuestionProxiesByQuestionID(int questionID);
        Task<List<VSASIDList>> FetchVSASListByID(string type, string mode, int questionId, int tagId);

    }
}
