﻿using ELPC.Core;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace ELPC.BAL.Interfaces
{
   public interface IDataPoolService
    {
        Task<List<ProcessConfirmation>> GetDataPool(SearchFilter filter = null);
        Task<List<ProcessConfirmation>> GetProcessConfirmationByID(int dataPoolID);
        Task<List<HintImage>> HintImagesByDeviationID(int deviationID);

        Task<Result> UpdateDataPool(ProcessConfirmation processConfirmation);
        Task<Result> DeleteDataPool(ProcessConfirmation processConfirmation);
        Task<List<DataPoolHistory>> GetDataPoolHistory(int templateID);
        Task<Result> DataPoolRestoreByTemplateHistoryID(int historyID);
        Task<List<ProcessConfirmation>> GetDeviationDataPool(SearchFilter filter = null);
        Task<List<HintImage>> GetDeviationFileByAttachmentID(int attachmentID);
        DataSet DataPoolExportExcelTemplate(string uspName, bool IsUserReport, List<int> IDs = default);
        DataSet DataPoolExportExcelTemplateFilter(string uspName, string fromDate,string toDate,bool IsUserReport, List<int> IDs = default);
    }
}
