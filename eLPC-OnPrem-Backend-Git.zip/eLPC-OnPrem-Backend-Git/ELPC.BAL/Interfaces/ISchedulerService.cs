﻿using ELPC.Core;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ELPC.BAL.Interfaces
{
    public interface ISchedulerService
    {
        Task<bool> AddSchedular(Schedule schedule); 
        Task<bool> AddCreateOPL(Schedule schedule);
    }
}
