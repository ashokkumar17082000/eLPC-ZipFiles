﻿using ELPC.Core;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ELPC.BAL.Interfaces
{
    public interface ICustomModeService
    {
        Task<List<CustomMode>> GetCustomModeByNTID(string NTID);
        Task<Result> InsertCustomMode(CustomMode customMode);
        Task<List<Tag>> GetCustomTags();
        Task<Result> RemoveFromCustomModeList(CustomMode customMode);
    }
}
