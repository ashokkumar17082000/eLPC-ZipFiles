﻿using ELPC.Core;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace ELPC.BAL.Interfaces
{
    public interface IAssessorTemplateService
    {
        Task<List<AssessorTemplate>> GetAssessorTemplates();
        Task<List<AssessorStreamHistory>> GetAssessorTemplatesHistory(int templateID);
        Task<List<Assessor>> GetAssessors();
        Task<List<Assessor>> GetAssessorByTemplateID(int templateID);
        Task<Result> AssessorsRestoreByTemplateHistoryID(int historyID);
        Task<Result> InsertAssessorTemplate(AssessorTemplate assessorTemplate);

        Task<Result> AssessorImportExcel(AssessorImportCombinedList assessorImportCombinedList, string ntid);

        DataSet AssessorExportExcel();
        Task<Result>DeleteAssessorTemplate(AssessorTemplate assessorTemplate);
        Task<Result> InsertAssessorTemplateProxy(AssessorProxy assessorProxy);
        Task<List<AssessorTemplate>> ValidateAssessorTemplateName(string assessorTemplateName);
        Task<List<AssessorProxy>> AssessorProxiesByAssessorTemplateID(int templateID);

        Task<List<AssessorTemplate>> FetchAssessorTemplateByTemplateID(int templateID);

    }
}
