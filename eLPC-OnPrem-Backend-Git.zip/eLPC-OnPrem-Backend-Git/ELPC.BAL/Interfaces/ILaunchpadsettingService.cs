﻿using ELPC.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ELPC.BAL.Interfaces
{
    public interface ILaunchpadsettingService
    {

        Task<Result> InsertLaunchpadURL(ReportText reportText);

        Task<List<ReportText>> GetLaunchpad();

        Task<Result> LaunchpadHistoryID(int historyID);

        Task<List<Reportrestore>> GetRestoredata();




    }
}
