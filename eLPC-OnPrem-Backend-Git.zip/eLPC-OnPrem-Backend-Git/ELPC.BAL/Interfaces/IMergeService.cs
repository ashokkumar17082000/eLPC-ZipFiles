﻿using ELPC.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ELPC.BAL.Interfaces
{
    public interface IMergeService
    {
        Task<Result> MergeQuestionAssignment(Merge mergeQuestionAssignment);

        Task<Result> MergeTagAssignment(Merge mergeTagAssignment);

        Task<Result> MergeQuestionRemoval(Merge mergeQuestionRemoval);

        Task<Result> MergeTagRemoval(Merge mergeTagRemoval);

        Task<Result> MergeQuestionProxy(MergeProxy questionProxy);

        Task<Result> MergeTagProxy(MergeProxy tagProxy);
    }
}
