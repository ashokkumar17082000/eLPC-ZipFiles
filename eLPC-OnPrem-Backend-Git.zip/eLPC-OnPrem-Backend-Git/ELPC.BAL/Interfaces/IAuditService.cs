﻿using ELPC.Core;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ELPC.BAL.Interfaces
{
    public interface IAuditService
    {
        //Task<List<Audit>> GetAudits();
        Task<List<Audit>> FetchAuditsByNTID(string ntid, string currentMonth, string currentYear);
        Task<Audit> InsertAudit(Audit audit);
        Task<Result> DeleteAudit(Audit audit);
        Task<Audit> AuditByAuditID(int auditID);
        int resetAuditByAuditID(int auditID);
        Task<List<AuditQuestion>> AuditQuestionsByAuditID(int auditID);
        Task<List<AuditQuestion>> AuditQuestionsByAuditIDSelectedValuestream(int auditID, int valueStreamID);
        Task<List<AuditQuestion>> PendingAuditsByAuditID(int auditID);
        Task<List<AuditQuestion>> AuditQuestionsByAuditAndAssessorID(int auditID, string NTID);
        Task<List<AuditQuestion>> AuditQuestionsByAuditAndTemplateID(int auditID, int templateID, int ValueStreamID);
        Task<Result> CompleteAuditByAuditAndTemplateID(int auditID, int templateID);
        Task<List<AuditQuestion>> AuditQuestionsByCurrentAssessorAndTemplateID(int auditID, string NTID);
        Task<List<AuditAssessor>> AuditAssessorsByAuditID(int auditID);
        Task<Result> UpdateAuditQuestion(AuditQuestion auditQuestion);
        Task<Result> InsertAuditDetail(AuditDetail auditDetail);
        Task<Result> AddEditAuditQuestion(AuditQuestion auditQuestion);
        Task<List<AuditAssessor>> AuditAssessorsByAuditAndTemplateID(int auditID, int templateID);
        Task<List<AuditAssessor>> OtherAuditAssessorsByAuditAndTemplateID(int auditID, int templateID);
        Task<List<ValueStream>> ValueStreamsByTagID(int tagID);
        Task<User> ValidateAssessorByAuditAndNTID(int auditID, string NTID);
        Task<List<User>> RequiredAttendeesByAuditID(int auditID);
        Task<List<User>> OptionalAttendeesByAuditID(int auditID);
        Task<Result> EmailToAttendees(Audit audit, Dictionary<string, byte[]> emailimage);
        Task<Result> SendAnswerSummaryEmail(Audit audit);
        Task<Result> SendTagModeAnswerSummaryEmail(ProcessConfirmation processConfirmation);
        Task<Result> AuditQuestionLinkedTagDetails(TagDetails tagDetails);
        Task<List<Audit>> FetchAuditStatusByType(string module, string currentMonth, string currentYear, int IsDesigner, string ntID);
    }
}
