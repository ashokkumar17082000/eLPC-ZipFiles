﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using ELPC.BAL.Implementation;
using ELPC.DAL.Implementation;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;



namespace ELPC.API
{
    public class ClaimsTransformer:IClaimsTransformation
    {
        readonly CommonRepository _userService = new CommonRepository();
        private string[] name;
        public Task<ClaimsPrincipal> TransformAsync(ClaimsPrincipal principal )
        {
            var claiminfo = (ClaimsIdentity)principal.Identity;
            name = claiminfo.Name.Split("\\");
            var role = _userService.GetUserByNTID(name[1]).Result.Role_roleID;

            var c = new Claim(claiminfo.RoleClaimType, role.ToString());
            claiminfo.AddClaim(c);

            return Task.FromResult(principal);

        }
        public string[] GetUser()
        {

            return name;
        }

    }
}
