﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Serilog;
using System.Net;
using System.Text;

namespace ELPC.API
{
    public class GlobalExceptionFilter: ExceptionFilterAttribute
    {

        public GlobalExceptionFilter()
        {
        }
		
        public override void OnException(ExceptionContext context)
        {
            var loggingBuilder = new StringBuilder();

            if (context.HttpContext.Request.Path.HasValue)
            {
                loggingBuilder.AppendLine($"\tUrl: {context.HttpContext.Request.Path.Value}");
            }

            if (!string.IsNullOrEmpty(context.Exception.Message))
            {

                var statusCode = (context.Exception as WebException != null &&
                       ((HttpWebResponse)(context.Exception as WebException).Response) != null) ?
                        ((HttpWebResponse)(context.Exception as WebException).Response).StatusCode
                        : getErrorCode(context.Exception.GetType());

                loggingBuilder.AppendLine($"\tStatus Code: {statusCode}");
            }

            if (context.HttpContext.Connection.RemoteIpAddress != null)
            {
                loggingBuilder.AppendLine($"\tIp Address: {context.HttpContext.Connection.RemoteIpAddress}");
            }

            foreach (var key in context.HttpContext.Request.Headers.Keys)
            {
                loggingBuilder.AppendLine($"\t{key}: {context.HttpContext.Request.Headers[key]}");
            }

            if (!string.IsNullOrEmpty(context.Exception.Message))
            {
                loggingBuilder.AppendLine($"\tError Message: {context.Exception.Message}");
            }

            if (context.Exception.InnerException != null)
            {
                PrintInnerException(context.Exception.InnerException, loggingBuilder);
            }

            if (!string.IsNullOrEmpty(context.Exception.HelpLink))
            {
                loggingBuilder.AppendLine($"\tError HelpLink: {context.Exception.HelpLink}");
            }

            if (!string.IsNullOrEmpty(context.Exception.StackTrace))
            {
                loggingBuilder.AppendLine($"\tError StackTrace: {Environment.NewLine + context.Exception.StackTrace}");
            }
            if (context.Exception.Data.Contains("UserMessage"))
            {
                loggingBuilder.AppendLine($"\tUser Message: {context.Exception.Data["UserMessage"]?.ToString()}");
            }

            loggingBuilder.AppendLine(Environment.NewLine);
            Log.Error(loggingBuilder.ToString());
            context.ExceptionHandled = true;
        }

        private void PrintInnerException(Exception ex, StringBuilder loggingBuilder)
        {
            loggingBuilder.AppendLine($"\tError InnerMessage: {ex.Message}");
            if (ex.InnerException != null)
            {
                PrintInnerException(ex.InnerException, loggingBuilder);
            }
        }

        private enum Exceptions
        {
            NullReferenceException = 1,
            FileNotFoundException = 2,
            OverflowException = 3,
            OutOfMemoryException = 4,
            InvalidCastException = 5,
            ObjectDisposedException = 6,
            UnauthorizedAccessException = 7,
            NotImplementedException = 8,
            NotSupportedException = 9,
            InvalidOperationException = 10,
            TimeoutException = 11,
            ArgumentException = 12,
            FormatException = 13,
            StackOverflowException = 14,
            SqlException = 15,
            IndexOutOfRangeException = 16,
            IOException = 17
        }

        private HttpStatusCode getErrorCode(Type exceptionType)
        {
            Exceptions tryParseResult;
            if (Enum.TryParse<Exceptions>(exceptionType.Name, out tryParseResult))
            {
                switch (tryParseResult)
                {
                    case Exceptions.NullReferenceException:
                        return HttpStatusCode.LengthRequired;

                    case Exceptions.FileNotFoundException:
                        return HttpStatusCode.NotFound;

                    case Exceptions.OverflowException:
                        return HttpStatusCode.RequestedRangeNotSatisfiable;

                    case Exceptions.OutOfMemoryException:
                        return HttpStatusCode.ExpectationFailed;

                    case Exceptions.InvalidCastException:
                        return HttpStatusCode.PreconditionFailed;

                    case Exceptions.ObjectDisposedException:
                        return HttpStatusCode.Gone;

                    case Exceptions.UnauthorizedAccessException:
                        return HttpStatusCode.Unauthorized;

                    case Exceptions.NotImplementedException:
                        return HttpStatusCode.NotImplemented;

                    case Exceptions.NotSupportedException:
                        return HttpStatusCode.NotAcceptable;

                    case Exceptions.InvalidOperationException:
                        return HttpStatusCode.MethodNotAllowed;

                    case Exceptions.TimeoutException:
                        return HttpStatusCode.RequestTimeout;

                    case Exceptions.ArgumentException:
                        return HttpStatusCode.BadRequest;

                    case Exceptions.StackOverflowException:
                        return HttpStatusCode.RequestedRangeNotSatisfiable;

                    case Exceptions.FormatException:
                        return HttpStatusCode.UnsupportedMediaType;

                    case Exceptions.IOException:
                        return HttpStatusCode.NotFound;

                    case Exceptions.IndexOutOfRangeException:
                        return HttpStatusCode.ExpectationFailed;

                    default:
                        return HttpStatusCode.InternalServerError;
                }
            }
            else
            {
                return HttpStatusCode.InternalServerError;
            }
        }
    }
}
