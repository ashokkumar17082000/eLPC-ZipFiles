﻿using ELPC.BAL.Implementation;
using ELPC.BAL.Interfaces;
using ELPC.DAL.Implementation;
using ELPC.DAL.Interfaces;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.AspNetCore.Server.IISIntegration;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System.IO.Compression;

namespace ELPC.API
{
    public class Startup
    {
        public readonly ILogger _logger;
        public Startup(IConfiguration configuration, ILogger<GlobalExceptionFilter> logger)
        {
            Configuration = configuration;
            _logger = logger;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors(o => o.AddPolicy("AllowOrigin", builder =>
            {
                // Add the required servers host name as string in WithOrigins method for enabling CORS with AllowCredentials
                builder.WithOrigins(
                    "https://si0vm03894.rbesz01.com",
                    "https://localhost:4200",
                    "http://localhost:4200",
                    "http://localhost:5200",
                    "https://rb-wam.bosch.com",
                    "https://fe0vmc2311.de.bosch.com",
                    "http://fe0vmc2311.de.bosch.com",
                    "http://localhost",
                    "https://localhost",
                    "https://bbm-elpc.bosch.tech",
                    "https://bbm-elpc-q.bosch.tech"
                )
                .AllowAnyMethod()
                .AllowAnyHeader()
                .AllowCredentials();
            }));

            services.AddResponseCaching();

            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => false;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });

            services.Configure<IISOptions>(options =>
                options.AutomaticAuthentication = true
            );

            // Gzip Compression
            services.Configure<GzipCompressionProviderOptions>(options =>
            {
                options.Level = CompressionLevel.Optimal;
            });

            services.AddResponseCompression(options =>
            {
                options.EnableForHttps = true;
                options.Providers.Add<GzipCompressionProvider>();
            });

            services.AddAuthentication(IISDefaults.AuthenticationScheme);
            services.AddMvc(options => options.EnableEndpointRouting = false).AddNewtonsoftJson();
            services.AddSingleton<IClaimsTransformation, ClaimsTransformer>();

            services.AddScoped<IAssessorTemplateRepository, AssessorTemplateRepository>();
            services.AddScoped<IAssessorTemplateService, AssessorTemplateService>();

            services.AddTransient<IQuestionRepository, QuestionRepository>();
            services.AddTransient<IQuestionService, QuestionService>();
            services.AddScoped<ICommonRepository, CommonRepository>();
            services.AddScoped<ICommonService, CommonService>();
            services.AddTransient<ITagRepository, TagRepository>();
            services.AddTransient<ITagService, TagService>();
            services.AddScoped<IAuditRepository, AuditRepository>();
            services.AddScoped<IAuditService, AuditService>();

            services.AddTransient<IProcessConfirmationRepository, ProcessConfirmationRepository>();
            services.AddTransient<IProcessConfirmationService, ProcessConfirmationService>();

            services.AddScoped<IDataPoolRepository, DataPoolRepository>();
            services.AddScoped<IDataPoolService, DataPoolService>();

            services.AddScoped<ICustomModeRepository, CustomModeRepository>();
            services.AddScoped<ICustomModeService, CustomModeService>();

            services.AddTransient<ITagModeRepository, TagModeRepository>();
            services.AddTransient<ITagModeService, TagModeService>();

            services.AddScoped<ISchedulerRepository, SchedulerRepository>();
            services.AddScoped<ISchedulerService, SchedulerService>();

            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            services.AddScoped<IMergeRepository, MergeRepository>();
            services.AddScoped<IMergeService, MergeService>();

            services.AddScoped<ILaunchpadsettingRepository, LaunchpadsettingRepository>();
            services.AddScoped<ILaunchpadsettingService, LaunchpadsettingService>();

            // Or you can also register as follows
            services.AddHttpContextAccessor();

            // for CORS
            services.AddScoped<IValueStreamTemplateRepository, ValueStreamTemplateRespository>();
            services.AddScoped<IValueStreamTemplateService, ValueStreamTemplateService>();

            services.Configure<MvcOptions>(options =>
            {
                // options.Filters.Add(new CorsAuthorizationFilterFactory("AllowOrigin"));
                options.Filters.Add(new GlobalExceptionFilter());
            });

            // Ensure static files are served
            services.AddDirectoryBrowser();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            }

            var options = new RequestLocalizationOptions
            {
                DefaultRequestCulture = new RequestCulture("en-US"),
            };

            app.UseRequestLocalization(options);
            app.UseCors("AllowOrigin");

            // Ensure static files are served
            app.UseStaticFiles();
            app.UseDirectoryBrowser();

            // UseResponseCaching should be after "UseCors"
            app.UseResponseCaching();

            app.Use(async (context, next) =>
            {
                context.Response.Headers[Microsoft.Net.Http.Headers.HeaderNames.Pragma] = new string[] { "no-cache" };
                context.Response.GetTypedHeaders().CacheControl = new Microsoft.Net.Http.Headers.CacheControlHeaderValue()
                {
                    NoCache = true,
                    NoStore = true
                };
                await next();
            });

            app.UseAuthentication();
            app.UseMiddleware<OptionsMiddleware>();
            app.UseResponseCompression(); // Gzip Compression
            app.UseRouting();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
