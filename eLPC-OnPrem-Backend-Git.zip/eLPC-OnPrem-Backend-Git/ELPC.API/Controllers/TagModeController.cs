﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ELPC.Core;
using ELPC.BAL.Interfaces;

namespace ELPC.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [GlobalExceptionFilter]
    public class TagModeController : ControllerBase
    {
        public readonly ITagModeService _tagModeService;
        public TagModeController(ITagModeService tagModeService)
        {
            _tagModeService = tagModeService;
        }

        [Route("GetTagModeByNTID/{NTID}")]
        [HttpGet]
        public  async Task<List<TagMode>> GetTagModeByNTID(string NTID)
        {
            var result = await  _tagModeService.GetTagModeByNTID(NTID);
            return result;
        }

        [Route("InsertToTagMode")]
        public Task<Result> InsertToTagMode(TagMode TagMode)
        {
            var result = _tagModeService.InsertToTagMode(TagMode);
            return result;
        }

        [Route("GetTagModeTags")]
        public async Task<List<Tag>> GetTagModeTags()
        {
            var result = await _tagModeService.GetTagModeTags();
            return result;
        }

        [Route("GetTagModeTagsCalendar")]
        public async Task<List<Tag>> GetTagModeTagsCalendar()
        {
            var result = await _tagModeService.GetTagModeTagsCalendar();
            return result;
        }

        [Route("DeleteTagMode")]
        public Task<Result> DeleteTagMode(TagMode TagMode)
        {
            var result = _tagModeService.DeleteTagMode(TagMode);
            return result;
        }

        //fetching the questions related with aprticualt tagID in TagInfo Popup in tagMode
        [Route("GetInfoQuestionsByTagID/{tagID}")]
        public Task<List<Question>> GetInfoQuestionsByTagID(int tagID)
        {
            var result = _tagModeService.GetInfoQuestionsByTagID(tagID);
            return result;
        }

        #region TagMode Audit

        [Route("AddEditTagModeQuestion")]
        public Task<Result> AddEditTagModeQuestion([FromBody]AuditQuestion auditQuestion)
        {
            var result = _tagModeService.AddEditTagModeQuestion(auditQuestion);
            return result;
        }

        [Route("FetchTagModeQuestionsByCurrentAssessorAndTemplateID/{tagID}/{NTID}")]
        public Task<List<AuditQuestion>> FetchTagModeQuestionsByCurrentAssessorAndTemplateID(int tagID, string NTID)
        {
            var result = _tagModeService.FetchTagModeQuestionsByCurrentAssessorAndTemplateID(tagID, NTID);
            return result;
        }
        #endregion 
    }
}