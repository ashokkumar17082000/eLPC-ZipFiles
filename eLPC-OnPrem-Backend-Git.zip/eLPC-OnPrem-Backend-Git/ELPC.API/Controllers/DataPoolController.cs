﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ELPC.Core;
using Microsoft.AspNetCore.Mvc;
using ELPC.BAL.Interfaces;
using System.Data;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.IO;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Http;
using Serilog;
using System.Text.Json;
using System.Text;

namespace ELPC.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [GlobalExceptionFilter]
    public class DataPoolController : ControllerBase
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private Plant userPlantInfo;

        public readonly IDataPoolService _dataPoolService;
        private readonly IConfiguration _iconfiguration;

        public DataPoolController(IDataPoolService dataPoolService, IConfiguration iconfiguration)
        {
            _dataPoolService = dataPoolService;
            _iconfiguration = iconfiguration;

            _httpContextAccessor = new HttpContextAccessor();
            var httpRequest = _httpContextAccessor.HttpContext.Request;
            userPlantInfo = Newtonsoft.Json.JsonConvert.DeserializeObject<Plant>(httpRequest.Headers["CurrentUserInfo"].ToString() ?? "");
        }

        [Route("GetDeviationDataPool")]
        [HttpPost]
        public async Task<List<ProcessConfirmation>> GetDeviationDataPool(SearchFilter filter = null)
        {
            var result = await _dataPoolService.GetDeviationDataPool(filter);
            return result;
        }

        [Route("GetDeviationFileByAttachmentID/{attachmentID}")]
        [HttpGet]
        public Task<List<HintImage>> GetDeviationFileByAttachmentID(int attachmentID)
        {
            var result = _dataPoolService.GetDeviationFileByAttachmentID(attachmentID);
            return result;
        }

        // GET: api/DataPool
        [Route("GetDataPool")]
        [HttpPost]
        public async Task<List<ProcessConfirmation>> GetDataPool(SearchFilter filter = null)
        {
            var result = await _dataPoolService.GetDataPool(filter);
            return result;
        }

        //[Route("GetDeviationDataPoolDownload")]
        //[HttpPost]
        //public async Task<IActionResult> GetDeviationDataPoolDownload(SearchFilter filter = null)
        //{
        //    List<ProcessConfirmation> dataList = await _dataPoolService.GetDataPool(filter);

        //    // Serialize the list to JSON (you can use other formats as needed)
        //    string json = JsonSerializer.Serialize(dataList);
        //    byte[] byteArray = Encoding.UTF8.GetBytes(json);
        //    return File(byteArray, "application/json", "DeviationDatapoolFiltered.json");
        //}

        [Route("GetProcessConfirmationByID/{dataPoolID}")]
        public Task<List<ProcessConfirmation>> GetProcessConfirmationByID(int dataPoolID)
        {

            var result = _dataPoolService.GetProcessConfirmationByID(dataPoolID);
            return result;
        }

        [Route("HintImagesByDeviationID/{deviationID}")]
        public Task<List<HintImage>> HintImagesByDeviationID(int deviationID)
        {

            var result = _dataPoolService.HintImagesByDeviationID(deviationID);

            return result;
        }

        [Route("UpdateDataPool")]
        [HttpPost]
        public Task<Result> UpdateDataPool(ProcessConfirmation processConfirmation)
        {
            string folderName = "ElpcUpload";

            string webRootPath = new Utility.Utility().GetConfigValue("PathName", userPlantInfo.PlantCode);
            string newPath = Path.Combine(webRootPath, folderName);

            if (!Directory.Exists(newPath))
            {
                Directory.CreateDirectory(newPath);
            }
            //************

            byte[] ImageData;
            if (processConfirmation.HintImages != null)
            {
                if (processConfirmation.HintImages.Count > 0 && processConfirmation.HintImages[0] != null)
                {
                    foreach (var file in processConfirmation.HintImages)
                    {
                        var Image = file.FileContent.Split(',').ToList<string>(); //to avoaid file ehaders which casue base64 error

                        ImageData = Convert.FromBase64String(Image[1]);
                        //*******************************newly added**
                        if (ImageData != null)
                        {
                            try
                            {
                                string fileName = file.ImageTitle;
                                string fullPath = Path.Combine(newPath, fileName);
                                //if file already exists
                                FileInfo file1 = new FileInfo(fullPath);
                                if (file1.Exists)
                                {
                                    file1.Delete();
                                    file1 = new FileInfo(fullPath);
                                }
                                //**********
                                using (var imageFile = new FileStream(fullPath, FileMode.CreateNew))
                                {
                                    imageFile.Write(ImageData, 0, ImageData.Length);
                                    imageFile.Flush();
                                }
                            }
                            catch (Exception ex)
                            {
                                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                                continue;
                            }
                        }
                    }
                    //************************************
                }
            }

            var result = _dataPoolService.UpdateDataPool(processConfirmation);
            return result;
        }
        [HttpPost]
        [Route("DeleteDataPool")]
        public Task<Result> DeleteDataPool(ProcessConfirmation processConfirmation)
        {
            var result = _dataPoolService.DeleteDataPool(processConfirmation);
            return result;
        }

        [Route("GetDataPoolHistory/{templateID}")]
        [HttpGet]
        public Task<List<DataPoolHistory>> GetDataPoolHistory(int templateID)
        {
            var result = _dataPoolService.GetDataPoolHistory(templateID);
            return result;
        }

        [Route("DataPoolRestoreByTemplateHistoryID/{historyID}")]
        public Task<Result> DataPoolRestoreByTemplateHistoryID(int historyID)
        {
            var result = _dataPoolService.DataPoolRestoreByTemplateHistoryID(historyID);
            return result;
        }

        //*******************************Export Excel*******************************************************

        public void ResolveTableName(string moduleName , DataSet ds)
        {
            List<string> NameofTable = new List<string>();

            if(moduleName == "DataPool")
            {
                List<string> Tables = new List<string>(){"DataPool"};
                NameofTable.AddRange(Tables);
            }
            else if (moduleName == "ValueStream")
            {
                List<string> Tables = new List<string>() { "VS_TEMPLATE", "VS_CATEGORY", "VS_VALUESTREAMS", "VS_SHIFTS" };
                NameofTable.AddRange(Tables);
            }
            else if (moduleName == "Assessor")
            {
                List<string> Tables = new List<string>() { "A_TEMPLATE", "A_ASSESSORS" };
                NameofTable.AddRange(Tables);
            }
            else if (moduleName == "Question")
            {
                List<string> Tables = new List<string>() { "Q_TEMPLATE", "Q_TEMPLATE_HYPERLINKS", "Q_TEMPLATE_CHOICE", "Q_TEMPLATE_VALUESTREAMS", "Q_TEMPLATE_ASSESSORS", "Q_ASSIGNED_TAGS" };
                NameofTable.AddRange(Tables);
            }
            else if (moduleName == "Tag")
            {
                List<string> Tables = new List<string>() { "TAG", "TAG_TEMPLATE_VALUE_STREAMS", "TAG_TEMPLATE_ASSESSORS", "TAG_ASSIGNED_QUESTIONS" };
                NameofTable.AddRange(Tables);
            }
            else if (moduleName == "PlantReport")
            {
                List<string> Tables = new List<string>() { "DataPool_Answers", "DataPool_Deviation", "VS_VALUESTREAMS", "A_ASSESSORS", "Q_TEMPLATE", "Q_TEMPLATE_VALUESTREAMS", "Q_TEMPLATE_ASSESSORS", "LINKED_TAGS_Q", "TAG", "TAG_TEMPLATE_VALUE_STREAMS", "TAG_TEMPLATE_ASSESSORS" };
                NameofTable.AddRange(Tables);
            }
            else if (moduleName == "PlantReportOneYear")
            {
                List<string> Tables = new List<string>() { "DataPool_Answers", "DataPool_Deviation", "VS_VALUESTREAMS", "A_ASSESSORS", "Q_TEMPLATE", "Q_TEMPLATE_VALUESTREAMS", "Q_TEMPLATE_ASSESSORS", "LINKED_TAGS_Q", "TAG", "TAG_TEMPLATE_VALUE_STREAMS", "TAG_TEMPLATE_ASSESSORS" };
                NameofTable.AddRange(Tables);
            }
            
            else if (moduleName == "UserReport")
            {
                List<string> Tables = new List<string>() { "DataPool_Answers", "DataPool_Deviation", "VS_VALUESTREAMS", "A_ASSESSORS", "Q_TEMPLATE", "Q_TEMPLATE_VALUESTREAMS", "Q_TEMPLATE_ASSESSORS", "LINKED_TAGS_Q", "TAG", "TAG_TEMPLATE_VALUE_STREAMS", "TAG_TEMPLATE_ASSESSORS" };
                NameofTable.AddRange(Tables);
            }
            else if (moduleName == "AuditStatus")
            {
                List<string> Tables = new List<string>() { "ID", "OriginTag", "Status", "UserName", "ValueStreamData", "AssessorName", "Completion", "NumberOfAnsweredQuestions", "NumberOfUnansweredQuestions", "StartDateTime", "EndDateTime", "AppointmentStartDateTime", "AppointmentEndDateTime", "Recurrence", "ReqAttendee", "OptAttendee", "Remarks" };
                NameofTable.AddRange(Tables);
            }

            for (int sheetCount = 0; ((sheetCount < NameofTable.Count) && (sheetCount < ds.Tables.Count)); sheetCount++)
            {
                ds.Tables[sheetCount].TableName = NameofTable[sheetCount];
            }

        }
        
        [Route("DataPoolExportExcelTemplate/{UspName}/{moduleName}")]
        [HttpGet]
        public IActionResult DataPoolExportExcelTemplate(string UspName,string moduleName)
        {
            DataSet ds = new DataSet();
            ds = _dataPoolService.DataPoolExportExcelTemplate(UspName, (moduleName == "UserReport"));
                        
            ResolveTableName(moduleName, ds);

            var fileContents = GenerateExcel(ds);

            if (fileContents == null || fileContents.Length == 0)
            {
                return NotFound();
            }

            return File(
                fileContents: fileContents,
                contentType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                fileDownloadName: "Template.xlsx"
            );
        }

        

        [Route("DataPoolExportExcelTemplateFilter/{UspName}/{fromDate}/{toDate}/{moduleName}")]
        [HttpGet]
        public IActionResult DataPoolExportExcelTemplateFilter(string UspName,string fromDate,string toDate, string moduleName)
        {
            DataSet ds = new DataSet();
            ds = _dataPoolService.DataPoolExportExcelTemplateFilter(UspName, fromDate, toDate,(moduleName == "UserReport"));

            ResolveTableName(moduleName, ds);

            var fileContents = GenerateExcel(ds);

            if (fileContents == null || fileContents.Length == 0)
            {
                return NotFound();
            }

            return File(
                fileContents: fileContents,
                contentType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                fileDownloadName: "Template.xlsx"
            );
        }

        [Route("DeviationDataPoolExportExcelTemplateFilter/{UspName}/{fromDate}/{toDate}/{moduleName}")]
        [HttpGet]
        public IActionResult DeviationDataPoolExportExcelTemplateFilter(string UspName, string fromDate, string toDate, string moduleName)
        {
            DataSet ds = new DataSet();
            ds = _dataPoolService.DataPoolExportExcelTemplateFilter(UspName, fromDate, toDate, (moduleName == "UserReport"));

            ResolveTableName(moduleName, ds);

            var fileContents = GenerateExcel(ds);

            if (fileContents == null || fileContents.Length == 0)
            {
                return NotFound();
            }

            return File(
                fileContents: fileContents,
                contentType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                fileDownloadName: "Template.xlsx"
            );
        }



        [Route("ExportExcelTemplateByInputIDs")]
        [HttpPost]
        public IActionResult ExportExcelTemplateByInputIDs(SearchFilter filter = null)
        {
            DataSet ds = new DataSet();

            ds = _dataPoolService.DataPoolExportExcelTemplate(filter.USPName, (filter.ModuleName == "UserReport"), filter.IDs);

            ResolveTableName(filter.ModuleName, ds);

            var fileContents = GenerateExcel(ds);

            if (fileContents == null || fileContents.Length == 0)
            {
                return NotFound();
            }

            return File(
                fileContents: fileContents,
                contentType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                fileDownloadName: "Template.xlsx"
            );
        }

        [NonAction]
        private byte[] GenerateExcel(DataSet ds)
        {
            byte[] fileContents;

            using (ExcelPackage pck = new ExcelPackage())
            {
                for (int sheetCount = 0; sheetCount < ds.Tables.Count; sheetCount++)

                {
                    var worksheet_DataPool = pck.Workbook.Worksheets.Add(ds.Tables[sheetCount].TableName);


                    worksheet_DataPool.Cells["A1"].LoadFromDataTable(ds.Tables[sheetCount], true);

                    var columnCount = ds.Tables[sheetCount].Columns.Count;

                    var cellRange = worksheet_DataPool.Cells[1, 1, 1, columnCount];
                    cellRange.Style.Font.Bold = true;
                    cellRange.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    cellRange.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Orange);

                    worksheet_DataPool.Cells[worksheet_DataPool.Dimension.Address].AutoFitColumns();

                    int colNumber = 0;

                    foreach (DataColumn col in ds.Tables[sheetCount].Columns)
                    {
                        colNumber++;
                        if (col.DataType == typeof(DateTime))
                        {

                            worksheet_DataPool.Column(colNumber).Style.Numberformat.Format = "MM/dd/yyyy";
                        }
                        else if (col.ColumnName == "OPLURL")
                        {
                            var fromRow = 2;
                            var colIndex = (col.Ordinal + 1);
                            var rowIndex = (ds.Tables[sheetCount].Rows.Count + 1);

                            if (rowIndex > 0)
                            {
                                foreach (var cell in worksheet_DataPool.Cells[fromRow, colIndex, rowIndex, colIndex])
                                {
                                    if(!(string.IsNullOrEmpty(cell.Value?.ToString() ?? "")))
                                    {
                                        cell.Hyperlink = new Uri(cell.Value.ToString());
                                        cell.Value = cell.Value.ToString().Split("/").LastOrDefault();
                                        cell.Style.Font.UnderLine = true;
                                    }
                                }
                            }
                        }
                    }
                }
                fileContents = pck.GetAsByteArray();
                return fileContents;
            }
        }
    }
}