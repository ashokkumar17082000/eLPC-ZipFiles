﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Linq;
using System.Threading.Tasks;
using ELPC.BAL.Interfaces;
using ELPC.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Serilog;

namespace ELPC.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [GlobalExceptionFilter]
    public class ActiveDirectoryController : ControllerBase
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private Plant userPlantInfo;

        public readonly ICommonService _commonService;
        public ActiveDirectoryController(ICommonService commonService)
        {
            _commonService = commonService;

            _httpContextAccessor = new HttpContextAccessor();
            var httpRequest = _httpContextAccessor.HttpContext.Request;
            userPlantInfo = Newtonsoft.Json.JsonConvert.DeserializeObject<Plant>(httpRequest.Headers["CurrentUserInfo"].ToString() ?? "");
        }

        public async Task<User> GetUserByNTID(string ntid)
        {
            var result = _commonService.GetUserByNTID(ntid);
            return await result;
        }

        [HttpGet]
        [Route("GetADUsersByGroupName/{groupName}")]
        public  List<User> GetADUsersByGroupName(string groupName)
        {
            List<User> users = new List<User>();
            try
            {
                int  flagCount = 0;

                groupName = groupName.Replace("/", "_").Trim();
                if (groupName == "CeaP_QMM-P")
                {
                    groupName = "WOM.CeaP_QMM-P-50804647-Mgt";
                }
                else if (groupName == "PS_QMM1-JP")
                {
                    groupName = "WOM.PS_QMM1-JP";
                }
                else if (groupName == "Deap_BPS")
                {
                    groupName = "";
                }

                DirectoryEntry entry = Utility.Utility.CreateActiveDirectoryConnection();
                DirectorySearcher ds = new DirectorySearcher(entry);


            restartLogic:
                ds.Filter = String.Format("(&(cn={0})(objectClass=group))", groupName);
                ds.PropertiesToLoad.Add("member");
                ds.PropertiesToLoad.Add("samaccountname");
                SearchResult sr = ds.FindOne();
                if (sr == null)
                {
                    if (flagCount == 0)
                    {
                        groupName = "WOM." + groupName + "-Mgt";
                        flagCount++;
                        goto restartLogic;
                    }
                    else
                    {
                        User userobj = new User();
                        userobj.EmailAddress = userobj.UserName = userobj.NTID = "NA";
                        return users;
                    }
                }
                else
                {
                    for (int i = 0; i < sr.Properties["member"].Count; i++)
                    {
                        try
                        {

                            string cn = sr.Properties["member"][i].ToString();

                            var NTID = sr.Properties["member"][i].ToString().Split(",")[0].Split("=")[1];

                            //string ntid = (sr.Properties["samaccountname"][0]?.ToString() ?? "NA");

                            GetUserInfo(ds, cn, NTID, users);


                        }
                        catch (Exception)
                        {
                            continue;
                        }
                    }
                }
            }
            catch (Exception)
            {

            }
            return users;
        }

        private void GetUserInfo(DirectorySearcher ds, string cn, string NTID, List<User> users)
        {
            Task<User> result = GetUserByNTID(NTID);

            if (result != null && result.Result != null && !string.IsNullOrEmpty(result.Result.UserName))
            {
                users.Add(result.Result);
            }
            else
            {
                ds.Filter = "(&(distinguishedName=" + cn + "))";
                ds.PropertiesToLoad.Add("samaccountname");
                ds.PropertiesToLoad.Add("displayName");
                ds.PropertiesToLoad.Add("mail");
                SearchResult sr1 = ds.FindOne();
                User us1 = new User();
                us1.NTID = sr1.Properties["samaccountname"][0]?.ToString() ?? "NA";
                us1.UserName = sr1.Properties["displayName"][0]?.ToString() ?? "NA";
                us1.EmailAddress = sr1.Properties["mail"][0]?.ToString() ?? "NA";
                users.Add(us1);
            }
        }

        [Route("SaveActiveDirectoryList")]
        [HttpPost]
        public UserDetails SaveActiveDirectoryList([FromBody]User userObj)
        {
            List<User> UsersList = new List<User>();
            Log.Information("SaveActivedirectry controller Line 145");
            string role = string.Empty;
            UserDetails user = new UserDetails();
            User usrList = userObj;

            if (!string.IsNullOrEmpty(userPlantInfo.CurrentRole))
            {
                usrList.Roles.Add(userPlantInfo.CurrentRole);
            }

            var Utility = new Utility.Utility();

            var desginerRole = Utility.GetConfigValue("DesignerRole", null, false);
            var standardRole = Utility.GetConfigValue("StandardRole", null, false);

            var plantDesginerRole = userPlantInfo.IdMDesignerRole;
            var plantStandardRole = userPlantInfo.IdMStandardRole;

            var SuperUsers = Utility.GetConfigValue("SuperUsers", userPlantInfo.PlantCode).ToUpper().Replace(" ", "").Split(',');
            var StandardUsers = Utility.GetConfigValue("StandardUsers", userPlantInfo.PlantCode).ToUpper().Replace(" ", "").Split(',');

            if (usrList.NTID != null && SuperUsers.Contains(usrList.NTID.ToUpper()))
            {
                role = "Designer";
            }
            else if (usrList.NTID != null && StandardUsers.Contains(usrList.NTID.ToUpper()))
            {
                role = "Standard";
            }
            else
            {
                for (int i = 0; i < usrList.Roles.Count; i++)
                {
                    if (usrList.Roles[i].ToLower() == desginerRole.ToLower() || usrList.Roles[i].ToLower() == plantDesginerRole.ToLower())
                    {
                        role = "Designer";
                        usrList.Role_roleID = 1;
                        break;
                    }
                    else if (usrList.Roles[i].ToLower() == standardRole.ToLower() || usrList.Roles[i].ToLower() == plantStandardRole.ToLower())
                    {
                        role = "Standard";
                        usrList.Role_roleID = 2;
                    }
                }
            }
            user.NTID = usrList.NTID;
            user.FirstName = usrList.FirstName;
            user.LastName = usrList.LastName;
            user.Department = usrList.Department;
            user.EmailAddress = usrList.EmailAddress;
            user.RoleName = role;
            user.DisplayName = usrList.UserName;
            //to update User table
            usrList.RoleName = role;
            // User Specific Custom Icon ~ Dashboard
            var customIconResult = _commonService.GetUserByNTID(usrList.NTID);

            user.CustomIConID = 0;

            if (customIconResult != null && customIconResult.Result != null && customIconResult.Result.CustomIConID > 0)
            {
                user.CustomIConID = customIconResult.Result.CustomIConID;
            }

            if ((!string.IsNullOrEmpty(role)) || usrList.IsValueStream)
            {
                UsersList.Add(usrList);
                _commonService.AddUsers(UsersList);
            }
            return user;
        }

        [HttpGet]
        [Route("GetUserListByNTID")]
        public List<User> GetUserListByNTID(string userId)
        {
            DirectorySearcher objDirsearcher;
            var objDirEntry = Utility.Utility.CreateActiveDirectoryConnection();
            if (objDirEntry == null)
            {
                return new List<User>();
            }

            objDirsearcher = new DirectorySearcher(objDirEntry);
            objDirsearcher.PageSize = 1;
            objDirsearcher.SizeLimit = 10;
            objDirsearcher.CacheResults = true;
            objDirsearcher.ReferralChasing = ReferralChasingOption.All;
            objDirsearcher.PropertiesToLoad.Add("givenName");
            objDirsearcher.PropertiesToLoad.Add("sn");
            objDirsearcher.PropertiesToLoad.Add("mail");
            objDirsearcher.PropertiesToLoad.Add("telephoneNumber");
            objDirsearcher.PropertiesToLoad.Add("department");
            objDirsearcher.PropertiesToLoad.Add("userPrincipalName");
            objDirsearcher.PropertiesToLoad.Add("sAMAccountName");
            objDirsearcher.PropertiesToLoad.Add("displayName");
            //objDirsearcher.PropertiesToLoad.Add("memberOf");
            objDirsearcher.SearchScope = SearchScope.Subtree;

            objDirsearcher.Filter = string.Format("(&(objectClass=user)(sAMAccountName={0}))", userId);

            var namelist = objDirsearcher.FindAll();
            var result = GetADSearchResult(namelist);
            return result;
        }

        [Route("ActiveDirectoryListByName")]
        [HttpPost]
        public List<User> ActiveDirectoryListByName([FromBody] User user)
        {
            string userName = string.Empty;
            if (user.FirstName != null && user.FirstName != " ")
            {
                userName = user.FirstName.ToLower();
              userName = userName.Replace("(", string.Empty).Replace(")", string.Empty);
            }
            var result = GetUserListByName(userName);
           var res = GetUserListByNTID(userName);           
            result.AddRange(res);
            
            if (user.IsGroupNameRequired == true)
            {
                var resultGroupNames = GetUserListByGroupName(userName);
                resultGroupNames = resultGroupNames?.Where(r => !string.IsNullOrEmpty(r.EmailAddress))?.ToList();
                if (resultGroupNames != null && resultGroupNames.Count > 0)
                {
                    result.AddRange(resultGroupNames);
                }
            }
            return result;
        }

        [NonAction]
        public List<User> GetUserListByName(string userName)
        {
            List<User> usrList = new List<User>();
            try
            {
                DirectorySearcher objDirsearcher;
                var objDirEntry = Utility.Utility.CreateActiveDirectoryConnection();
                if (objDirEntry == null)
                {
                    return usrList;
                }
                objDirsearcher = new DirectorySearcher(objDirEntry);
                objDirsearcher.PageSize = 0;
                objDirsearcher.SizeLimit = 10;
                objDirsearcher.CacheResults = true;
                objDirsearcher.ServerPageTimeLimit = TimeSpan.FromSeconds(2);
                objDirsearcher.ReferralChasing = ReferralChasingOption.All;
                objDirsearcher.PropertiesToLoad.Add("givenName");
                objDirsearcher.PropertiesToLoad.Add("sn");
                objDirsearcher.PropertiesToLoad.Add("mail");
                objDirsearcher.PropertiesToLoad.Add("telephoneNumber");
                objDirsearcher.PropertiesToLoad.Add("department");
                objDirsearcher.PropertiesToLoad.Add("userPrincipalName");
                objDirsearcher.PropertiesToLoad.Add("sAMAccountName");
                objDirsearcher.PropertiesToLoad.Add("displayName");
                //objDirsearcher.PropertiesToLoad.Add("memberOf");
                objDirsearcher.SearchScope = SearchScope.Subtree;
                objDirsearcher.Filter = "(&(objectClass=user)(displayName=" + userName.Trim().Replace(" ", "*") + "*))";

                var namelist = objDirsearcher.FindAll();
                usrList = GetADSearchResult(namelist);
            }
            catch (Exception ex)
            {
                usrList = null;
                //Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
            }

            return usrList;
        }

        [NonAction]
        public List<User> GetUserListByGroupName(string groupName)
        {
            List<User> usrList = null;
            try
            {
                DirectorySearcher objDirsearcher;
                var objDirEntry = Utility.Utility.CreateActiveDirectoryConnection();
                if (objDirEntry == null)
                {
                    return usrList;
                }

                objDirsearcher = new DirectorySearcher(objDirEntry);
                objDirsearcher.PageSize = 0;
                objDirsearcher.SizeLimit = 10;
                objDirsearcher.CacheResults = true;
                objDirsearcher.ServerPageTimeLimit = TimeSpan.FromSeconds(2);
                objDirsearcher.ReferralChasing = ReferralChasingOption.All;
                objDirsearcher.PropertiesToLoad.Add("adspath");
                objDirsearcher.PropertiesToLoad.Add("displayName");
                objDirsearcher.PropertiesToLoad.Add("department");
                objDirsearcher.PropertiesToLoad.Add("mail");
                objDirsearcher.PropertiesToLoad.Add("sAMAccountName");
                objDirsearcher.SearchScope = SearchScope.Subtree;
                objDirsearcher.Filter = "(&(objectClass=group)(displayName=" + groupName.Trim().Replace(" ", "*") + "*))";

                var namelist = objDirsearcher.FindAll();
                var result = GetADSearchResult(namelist);
                return result;
            }
            catch (Exception ex)
            {
                return usrList;
            }
        }

        [NonAction]
        public static List<User> GetADSearchResult(SearchResultCollection namelist)
        {
            List<User> usrList = new List<User>();
            foreach (SearchResult objResult in namelist)
            {
                try
                {
                    User namObj = new User();
                    var result = new List<string>();
                    if (objResult != null)
                    {
                        for (int i = 0; i < objResult.Properties["memberOf"].Count; i++)
                        {
                            var memberof = objResult.Properties["memberOf"][i].ToString().Split(',');
                            if (!string.IsNullOrEmpty(memberof[0].Substring(3)))
                            {
                                result.Add(memberof[0].Substring(3));
                            }
                        }
                        namObj.Roles = result;
                        namObj.NTID = ParseValue(objResult.Properties, "samaccountname");
                        namObj.EmailAddress = ParseValue(objResult.Properties, "mail");
                        namObj.Department = ParseValue(objResult.Properties, "department");
                        namObj.FirstName = ParseValue(objResult.Properties, "givenName");
                        namObj.LastName = (namObj.FirstName == ParseValue(objResult.Properties, "sn")) ? "" : ParseValue(objResult.Properties, "sn");
                        if (namObj.LastName != null && namObj.LastName != "")
                        {
                            namObj.UserName = namObj.FirstName + ' ' + namObj.LastName;
                        }
                        namObj.UserName = ParseValue(objResult.Properties, "displayName");
                    }
                    usrList.Add(namObj);
                }
                catch (Exception ex)
                {
                    //Log.Error("API Error-" + "GetADSearchResult" + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                    continue;
                }
            }

            return usrList;
        }

        [NonAction]
        private static string ParseValue(ResultPropertyCollection resultProperty, string propertyName)
        {
            var result = resultProperty[propertyName];
            if (result != null && result.Count > 0)
            {
                if (result[0] != null)
                {
                    return Convert.ToString(result[0]);
                }
            }
            return "";
        }
    }
}