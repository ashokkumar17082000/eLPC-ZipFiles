﻿using ELPC.BAL.Implementation;
using ELPC.BAL.Interfaces;
using ELPC.Core;
using ELPC.DAL.Implementation;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Serilog;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace ELPC.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [GlobalExceptionFilter]
    public class SuperOPLController : ControllerBase
    {
        private readonly ISchedulerService _schedulerService;
        private readonly ICommonService _commonService;
        public readonly IConfiguration _iconfiguration;
        private readonly IHostingEnvironment _hostingEnvironment;

        public SuperOPLController(ISchedulerService schedulerService, ICommonService commonService, IConfiguration iconfiguration, IHostingEnvironment hostingEnvironment)
        {
            _schedulerService = schedulerService;
            _commonService = commonService;
            _iconfiguration = iconfiguration;
            _hostingEnvironment = hostingEnvironment;
        }


        [Route("UpdateOPLTask")]
        [HttpPost]
        public bool UpdateOPLTask([FromBody]SuperOPLTask JSONObject)
        {
            bool result = false;
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add(_iconfiguration["SuperOPLHeaderKey"], _iconfiguration["SuperOPLHeaderValue"]);
                JObject data = JObject.Parse(JSONObject.task);
                Task<HttpResponseMessage> httpResponse = client.PutAsync(JSONObject.url, new StringContent(JSONObject.task, System.Text.Encoding.UTF8, "application/json"));
                httpResponse.Wait();
                var httpresult = httpResponse.Result;
                if (httpresult.IsSuccessStatusCode)
                {
                    JObject responseData = JObject.Parse(httpResponse.Result.Content.ReadAsStringAsync().Result);
                    if (responseData["result"].ToString() == "True")
                    {
                        return true;
                    }
                    else
                    {
                        Log.Error("SuperOPL-" + responseData["errors"].ToString());
                    }
                }
            }
            return result;

        }

        [Route("CreateOPLTask")]
        [HttpPost]
        public string CreateOPLTask([FromBody]SuperOPLTask JSONObject)
        {
            string result = string.Empty;
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add(_iconfiguration["SuperOPLHeaderKey"], _iconfiguration["SuperOPLHeaderValue"]);
                JObject data = JObject.Parse(JSONObject.task);
                try
                {
                    Task<HttpResponseMessage> httpResponse = client.PostAsync(JSONObject.url, new StringContent(JSONObject.task, System.Text.Encoding.UTF8, "application/json"));
                    httpResponse.Wait();
                    var httpresult = httpResponse.Result;
                    if (httpresult.IsSuccessStatusCode)
                    {
                        JObject responseData = JObject.Parse(httpResponse.Result.Content.ReadAsStringAsync().Result);
                        if (responseData["result"].ToString() == "True")
                        {
                            if(JSONObject.ScheduleId > 0 && !string.IsNullOrWhiteSpace(JSONObject.deviation))
                            {
                                var controller = new CommonController(_commonService, _iconfiguration, _hostingEnvironment);
                                Deviation deviation = JsonConvert.DeserializeObject<Deviation>(JSONObject.deviation);
                                deviation.SuperOPLURL += ((JValue)responseData["data"]["taskId"]).Value.ToString();
                                deviation.SchedulerID = JSONObject.ScheduleId.Value;
                                controller.SendDeviationEmail(deviation);
                            }
                            return ((JValue)responseData["data"]["taskId"]).Value.ToString();
                        }
                        else
                        {
                            if (JSONObject.ScheduleId == null)
                            {
                                AddToSchedular(JSONObject,  responseData.ToString());
                            }
                            Log.Error("SuperOPL-" + responseData.ToString());
                        }
                    }
                    else
                    {
                        if (JSONObject.ScheduleId == null)
                        {
                            AddToSchedular(JSONObject, Newtonsoft.Json.JsonConvert.SerializeObject(httpresult, Newtonsoft.Json.Formatting.Indented));
                        }
                        Log.Error("SuperOPL- IsSuccessStatusCode failure: " + Newtonsoft.Json.JsonConvert.SerializeObject(httpresult, Newtonsoft.Json.Formatting.Indented));
                    }
                }
                catch (Exception ex)
                {
                    if (JSONObject.ScheduleId == null)
                    {
                        AddToSchedular(JSONObject, Newtonsoft.Json.JsonConvert.SerializeObject(ex, Newtonsoft.Json.Formatting.Indented));
                    }
                    Log.Error("SuperOPL- Failure: " + Newtonsoft.Json.JsonConvert.SerializeObject(ex, Newtonsoft.Json.Formatting.Indented));
                }
            }
            return result;
        }

        private void AddToSchedular(SuperOPLTask JSONObject, string errorDetail)
        {
            int plantID = 0;
            SchedulerDataModel schedulerDataModel = new SchedulerDataModel() { Headers= new System.Collections.Generic.List<System.Collections.Generic.KeyValuePair<string, string>>() };
            if (Request.Headers != null && Request.Headers.Count > 0)
            {
                if (Request.Headers.ContainsKey("CurrentUserInfo"))
                {
                    schedulerDataModel.Headers.Add(new System.Collections.Generic.KeyValuePair<string, string>("CurrentUserInfo", Request.Headers["CurrentUserInfo"]));
                }
                if (Request.Headers.ContainsKey("Plant"))
                {
                    schedulerDataModel.Headers.Add(new System.Collections.Generic.KeyValuePair<string, string>("Plant", Request.Headers["Plant"]));
                    plantID = Convert.ToInt32(Request.Headers["Plant"]);
                }
            }

            schedulerDataModel.POSTData = JsonConvert.SerializeObject(JSONObject);
            
            _schedulerService.AddSchedular(new Schedule() { ScheduleName = "SuperOPL", DataObj = JsonConvert.SerializeObject(schedulerDataModel), PlantId = plantID, ErrorDetail = errorDetail });
        }

        [Route("GetOPLTasks")]
        [HttpPost]
        public Result GetOPLTasks([FromBody]SuperOPLTask JSONObject)
        {
            Result data = new Result();
            try
            {
                using (var client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Add(_iconfiguration["SuperOPLHeaderKey"], _iconfiguration["SuperOPLHeaderValue"]);
                    Task<HttpResponseMessage> httpResponse = client.GetAsync(JSONObject.url);
                    httpResponse.Wait();
                    var httpresult = httpResponse.Result;
                    if (httpresult.IsSuccessStatusCode)
                    {
                        JObject responseData = JObject.Parse(httpResponse.Result.Content.ReadAsStringAsync().Result);
                        if (responseData["result"].ToString() == "True")
                        {
                            data.ResultCode = 0;
                            data.ResultMessage = responseData["data"].ToString();
                        }
                        else
                        {
                            Log.Error("SuperOPL-" + responseData["errors"].ToString());
                        }
                    }
                }
                return data;
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

    }
}
