﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ELPC.Core;
using ELPC.BAL.Interfaces;
using ELPC.Utility;
using Microsoft.Extensions.Configuration;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Memory;
using Serilog;

namespace ELPC.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [GlobalExceptionFilter]
    public class CommonController : ControllerBase
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private Plant userPlantInfo;

        public readonly ICommonService _commonService;
        public readonly IConfiguration _iconfiguration;
        private readonly IHostingEnvironment _hostingEnvironment;
        public CommonController(ICommonService commonService, IConfiguration iconfiguration, IHostingEnvironment hostingEnvironment)
        {
            _commonService = commonService;
            _iconfiguration = iconfiguration;
            _hostingEnvironment = hostingEnvironment;


            _httpContextAccessor = new HttpContextAccessor();
            var httpRequest = _httpContextAccessor.HttpContext.Request;
            userPlantInfo = Newtonsoft.Json.JsonConvert.DeserializeObject<Plant>(httpRequest.Headers["CurrentUserInfo"].ToString() ?? "");
        }

        [Route("GetChoiceDisplayTypes")]
        [HttpGet]
        public Task<List<ChoiceDisplayType>> GetChoiceDisplayTypes()
        {

            var result = _commonService.GetChoiceDisplayTypes();
            return result;
        }

        [Route("GetAnswerTypes")]
        [HttpGet]
        public Task<List<AnswerType>> GetAnswerTypes()
        {
            var result = _commonService.GetAnswerTypes();
            return result;
        }

        [Route("GetUsers")]
        [HttpGet]
        public Task<List<User>> GetUsers()
        {
            var result = _commonService.GetUsers();
            return result;
        }

        [Route("InsertUser")]
        public Task<Result> InsertUser([FromBody]User user)
        {
            var result = _commonService.InsertUser(user);
            return result;
        }

        //[Route("GetUserByNTID/{ntid}")]
        //public Task<User> GetUserByNTID(string ntid)
        //{
        //    var result = _commonService.GetUserByNTID(ntid);
        //    return result;
        //}

        [Route("GetUserByNTID/{ntid}")]
        public async Task<ActionResult<User>> GetUserByNTID(string ntid)
        {
                var cache = HttpContext.RequestServices.GetService(typeof(IMemoryCache)) as IMemoryCache;
                if (cache == null)
                {
                    // handle case where IMemoryCache service is not available
                    return BadRequest("Memory cache service is not available.");
                }
                var cacheKey = $"UserByNTID_{ntid}";

            // Attempt to retrieve user from cache
            if (!cache.TryGetValue(cacheKey, out ActionResult<User> cachedResult))
            {
                // User not found in cache, fetch from the service
                var result = await _commonService.GetUserByNTID(ntid);

                if (result != null)
                {
                        // Cache the result for 10 minutes (adjust the TimeSpan as needed)
                        cache.Set(cacheKey, result, TimeSpan.FromMinutes(10));
                    }

                return result;
            }

            return cachedResult;
        }

        [Route("InsertIntoDeviation")]
        public  Task<Result> InsertIntoDeviation(Deviation deviation)
        {
            string folderName = "ElpcUpload";
            string webRootPath = new Utility.Utility().GetConfigValue("PathName", userPlantInfo.PlantCode);
            string newPath = Path.Combine(webRootPath, folderName);

            Common.HintImageUpload(newPath, deviation.HintImages);
            if (deviation.HintImages != null && deviation.HintImages.Count > 0)
            {
                for (int i = 0; i < deviation.HintImages.Count; i++)
                {
                    if (deviation.HintImages[i] != null && (deviation.HintImages[i].ID == 0))
                    {
                        var temp = deviation.HintImages[i].FileContent.Split(';')[0];
                        var Image = deviation.HintImages[i].FileContent.Replace(temp + ";base64,", string.Empty);
                        deviation.HintImages[i].ByteData = Convert.FromBase64String(Image);
                    }
                }
            }
            var result =  _commonService.InsertIntoDeviation(deviation);
            return result;
        }

        [Route("InsertIntoDeviationAttachments")]
        public Task<Result> InsertIntoDeviationAttachments(Deviation deviation)
        {

            Log.Information("InsertInto Attachment controller Line 137");
            string folderName = "ElpcUpload";
            string webRootPath = new Utility.Utility().GetConfigValue("PathName", userPlantInfo.PlantCode);
            string newPath = Path.Combine(webRootPath, folderName);
            Log.Information("InsertInto Attachment  controller Line 141");

            Common.HintImageUpload(newPath, deviation.HintImages);
            if (deviation.HintImages != null && deviation.HintImages.Count > 0)
            {
                Log.Information("InsertInto Attachment controller Line 146");
                for (int i = 0; i < deviation.HintImages.Count; i++)
                {
                    if (deviation.HintImages[i] != null && (deviation.HintImages[i].ID == 0))
                    {
                        Log.Information("InsertInto Attachment controller Line 151");
                        var temp = deviation.HintImages[i].FileContent.Split(';')[0];
                        var Image = deviation.HintImages[i].FileContent.Replace(temp + ";base64,", string.Empty);
                        deviation.HintImages[i].ByteData = Convert.FromBase64String(Image);
                    }
                }
                Log.Information("InsertInto Attachment  controller Line 157");
            }
            var result = _commonService.InsertIntoDeviationAttachments(deviation);
            return result;
        }

        [Route("DeletetempAttachments")]
        public Task<Result> DeletetempAttachments(Deviation deviation)
        {
            var result = _commonService.DeletetempAttachments(deviation);
            return result;
        }

        [Route("SendDeviationEmail")]
        public  Task<Result> SendDeviationEmail([FromBody]Deviation deviation)
        {
            Dictionary<string, byte[]> emailimage = new Dictionary<string, byte[]>();
            //byte[] b = System.IO.File.ReadAllBytes(_hostingEnvironment.ContentRootPath + "/Images/header-img.png");
            byte[] b = System.Convert.FromBase64String("iVBORw0KGgoAAAANSUhEUgAABTwAAAAWCAMAAAGtRZPEAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAABjUExURZMiMLAlOK4YFtQTFoozemY4jVg7jkw9j0M/jz5AkCk2hCA4gBo5gSNboi19tS+TwCWjzCikywCmzACemgCdXWCxbYi8bjmfWCmMQHw1hBekyQCcXxGgYTCnZRc7hCeMPwAAAHvN38EAAAAhdFJOU///////////////////////////////////////////AJ/B0CEAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAo+SURBVGhD1ZuLYtu2EgXrxg/Fdpu0jZubuk3+/y8vdncA4m2AJFx1xEiMZDHIcngAkPRPCTfGzz9/KLi9U+6Fi/Dx0fHk+O55dqvyhnzwS+BX+Jzw+8aXmJc/Ay8vPyJoIUw1VFoq7XrWRka81dDfHDRSoInGK610vLz8L4IWwlhDHx7Khgb6DZU2KjRS8E00aKVALQ1aaIR2lg29jRp60ZL6dtJAt9fdvpe/p7ueZma7njYqNNSgjUJ7z9POm0o9P3wLzYwUfXItfe7veVr56ydaWOz4pJ1xPds7nmZWd/w3bag280H3fNpOT7OdvoVAGx20sNzxnSMphjaDc6HW+pJbK7yh/y3H5e5ykRcTRtV2uHAQUdz/tIn7TD+2L8TeB6jDhu60Ckl1EqhUDWqW8uLSiP2cQ/EqUMjAWDk/fKCUilVTcK48XD4264k1CVJHj31hqJ5UD8wyz18UMIPaJaDh35QwJVEygeJVoIww6ucN+WVQTCunxq7W82LF0WI6XL0oYRP7wmA9f8uquJHkYYAK+hKmUMGUv6leCcUroY4wWs7QHzjuo3rKkW6xW5aTkkU8f3e9nCwB+0atnlRxAzFrUL8C6lmB+qW4w70pKNUroZCeiXoSoPdbPaWWVHM73N3BHg53zcgS97Yt/nh/oogRVHGD2pW09Pz9D4pXgQpmvLx8JS5zhuspBaVkfXx3dB/7qdXcuiMVNK4nXqaZGaPVdFDECKq4QfUSuod7W8/X15agre7o/HpSzrSeaXyaoNV6RlghQYvpoIgRVHGDEgKVNGbq2YvP9uF++vFe95Pu3ddTS/NWPQ0r5556UsMECphBBYFCAhXMoHgVqF4JdfSM1jP0R2U9MdTrGdfzrf59Mj+pXgkFzKCQE/07xatA9SagwHWk7ArlPcrN7W0yQRBkP9lKgdtdYWVDEsYPKuy40NcIPQZGcT8dLzp5tQ90uxHs8j5o0MGOt1mQZRScmgO9BpAxUWdY1ALnJkDEBth5lp6SH6JnpKioqXqaiBGmpghpowlPqqcIKm7GgqpdWejw3gheVbYfQMA+ONhmO/ExALnmmPMT3yb5B/kGMDsZBY1yup4IiltnICbe2TkjRfUs0MGtg25PXEVO9Iz8bOmJly3sh3qw/QAC9kHCNm/riZAZiDcGvo1BR+3AvRF2ZOf56Ul8otYJ5F17Q0/18t49ILITPTmj5dipZ4T9fE44ZeNBwD5I2AYHM3Cww0x8dubbAYxMmOje/3z5inMT4NwEaNjA7DzPTzf2NCsDDT0FERQ7Lxc/t806d51D1PWc8LNAv84/4anMPCogYRt8dEaOSBn4/An1RsDAHCTsgXsD/INyM+DcBHhYAzUF7DqIzIxyPRV8jFARtY9n8aicW3R6ENPh3DI/vaVV5AJevFRgywH864ODHabGnhuIN8hIfBbg3Qg69JzPT5ybABWr4Oap4en0zDp4l584GeNMtGeBNwTTM5oZoWYQVNwzBUdwP5osfhPyEZv3IGAfHOyAbrPg3SAINwfqjWB6It04ODcBJtbBztP0dPH5LbMzzNrdmrxsOBc3P3kNI8/LYzI3Snt28yv00mPgp//2qpnRDj21b8e7QRBujvpV3yroyYx8lFVjT+w6Tq1vJz1zOVFTVit6RnZ29ZwR1AiO2sYjMLALDnbAuSF01Gng3SAINwnujSB2fv33TyydrKe//ywm6JkJqlr6V1VTQM949NnXM0M/GmHf4BMHO2DeW2BloHELTJ35oadMi+L7IN9iT3j+F/QszixZ9y6vGW62DpipYKePT1VT/gTELPULH0v007fR7UcMzdxxsAP6dUDIlKneHecG0Sm7MHnZiAHlBDg3ARq2WKJnMfoUG+P0VDHDSU+3usUndsbxOaunR3+qjW18Y72emFhj6rzSuJ54CXO9+xWc91yUntFVo2p6PtizJzrpebhzb6NfirCNb6zUEwk7nJ+eOBkzdVUT5WbAuQnQsIHZ+U5To01QS04vqAvT88aeA+i33VZs64FnDOyCgx0Q0vj0+dPo2XnMGwIB66BijaneHeVmwLkJ8LAOdp6mp5xYys8sVdPTtLQXATcdwc6xE0sHsI1vIGAfHGwTzso7L10mtm9fz5g589mYGeFgD9wbAeOmwLkJELEKcjrQ6yhyWr6mpyiZpKcSde9bBx/03Cj0NLBsN7bxDQTsg4RtRE/MnAT3BnjFRw/uDTDRu2PcFDi3EtSdBtETsPZKkINHkAPIHULZURSQw8k/2SHlnuLsN9xsTh53+uBX3mSGF5bL/eM2Ztn4KA+4JFfHAu54ZAl3LSe47sMdpduBmq7vwrZXXVrQGIWGN+HgPgFS4BAuQf7SHu49IFLWQD6tZ+KSzgRyfiiwYyo+BwG3ErJwByTmBqF1NRCePjeLUUgEyanp2chOe7ILCxKXGpk82aNKHJ4O0iVGxzKy1KOzFp4LCOFZLkBrBGt4G5LvBMi/QxBri9HRnYtpcm4JRNs7MDEqnIDcFJZn53WHZ5GeZNb1oNlpg852bjL2jLOzEp4hImVVhp76jr6lT/aokIVnkZ4am7YMh+cTs8Tn7XE+ITsry1vp+Z3oOw75dwjSbQXFfHjp0HPXXZU7mbgePg7BKbh048r4Iq48PPP4JLKuCMtOG3PaSg2XnD467SFLhqUmj7AiwWkLfy3JwrOYue8JT4vOCu+VprS9DdF3HPLvCDvvFu/QO4W4cuhJri1GTkd+mbocPg7J+R7ZefXhmaQngXVVMPDszdh9eMa52Rh5aoa6FR15+oddYrAQdU+P9hrIR5752PNZInMuPJ+IygGiND0zT2l7G6LvOATgEc4Kz8GrLuuGnksHnnoJJ2LtxF0m7aTcKq4/POP4JK+ui9nwtPgsw/NyJ4ve2OIfKfdygbYy9izCMxt6njryfJsoSw+kKW1vQ/QdhwA8Atm3FzJxHKLufIi5kyEsS5ZM3C0915/wdBBwKyED90JwCsTVVXEjoXnKyFPvVpUbWsjNPDzl/pb0VwCMIjyJF8+O8JwYeQ6wJ0xpexui7zgE4BEIwVGIwL2su2R07sCThOywcOJOvK2FgFsJIbgPYhMIrCvCXy86PvLU2AzhWSbn4/1F0lPuVnpj2k68eHaE5+GbCvsMpCltb0P0HYcAPAKh2MVN7Qm/EyDszobU2wmJOMOy+5VIt8UQcCshBvdAZgZIrOtBr7a7ZNTsbMfnzMjTkrMMT3vLkjMZf+bhSbp47JTnZHguTs+cKE3JU2t7G5LvBAjAA9RPecbvurw7MTonfzl8mD0DT1JwL4tOe77LpP3Kw5PI3CCyrgbNTi6321M9QMdHnrpi+VnDDT3T5HRk4Um6JEyPPN87PXP+s+GpA0xZOTctE9zWibtz+ZL/Kk8NUu8slpz2fKfsvObwJDATCK0rwbJTfoM0hGedU0aeOmN35PGZhifhkrBj5Pkvh2fxy4Q5JN8JkIAHcDnpx5kLIzNhxdDzj9dmeJJ0KyDvzuSdJu0/fvwffpsKlc5rSTkAAAAASUVORK5CYII=");
            emailimage.Add("header", b);
            var result =  _commonService.SendDeviationEmail(deviation, emailimage);
            return result;

        }

        [Route("InsertIntoAuditDeviation")]
        public Task<Result> InsertIntoAuditDeviation(Deviation deviation)
        {
            string folderName = "ElpcUpload";
            string webRootPath = new Utility.Utility().GetConfigValue("PathName", userPlantInfo.PlantCode);
            string newPath = Path.Combine(webRootPath, folderName);

            Common.HintImageUpload(newPath, deviation.HintImages);

            if (deviation.HintImages != null && deviation.HintImages.Count > 0)
            {
                for (int i = 0; i < deviation.HintImages.Count; i++)
                {
                    if (deviation.HintImages[i] != null && (deviation.HintImages[i].ID == 0))
                    {
                        var temp = deviation.HintImages[i].FileContent.Split(';')[0];
                        var Image = deviation.HintImages[i].FileContent.Replace(temp + ";base64,", string.Empty);
                        deviation.HintImages[i].ByteData = Convert.FromBase64String(Image);
                    }
                }
            }

            var result = _commonService.InsertIntoAuditDeviation(deviation);
            return result;
        }


        [Route("GetUserProfileVSAS")]
        [HttpGet]
        public Task<UserProfileValueStreamAssessor> GetUserProfileVSAS()
        {
            var result = _commonService.GetUserProfileVSAS();
            return result;
        }

        [Route("updateEmpoyeeID")]
        [HttpGet]
        public Task<Result> updateEmpoyeeID()
        {
            var result = _commonService.updateEmpoyeeID();
            return result;
        }

        [Route("AddEditUserProfileVSAS")]
        public Task<Result> AddEditUserProfileVSAS([FromBody]UserProfileValueStreamAssessor userProfile)
        {
            var result = _commonService.AddEditUserProfileVSAS(userProfile);
            return result;
        }


        [Route("UpdateUserProfileVSAS")]
        public Task<Result> UpdateUserProfileVSAS([FromBody]UserProfileUpdateVSAS updateVSAS)
        {
            var result = _commonService.UpdateUserProfileVSAS(updateVSAS);
            return result;
        }
        
    }
}