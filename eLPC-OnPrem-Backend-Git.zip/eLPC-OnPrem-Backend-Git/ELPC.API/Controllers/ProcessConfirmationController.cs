﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using ELPC.BAL.Interfaces;
using ELPC.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace ELPC.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [GlobalExceptionFilter]
    public class ProcessConfirmationController : Controller
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private Plant userPlantInfo;
        private readonly ISchedulerService _schedulerService;
        public readonly IProcessConfirmationService _procesConfirmationService;
        private readonly IConfiguration _iconfiguration;

        public ProcessConfirmationController(ISchedulerService schedulerService, IProcessConfirmationService processConfirmationService, IConfiguration iconfiguration)
        
        {
                _procesConfirmationService = processConfirmationService;
                _iconfiguration = iconfiguration;
                _schedulerService = schedulerService;
                _httpContextAccessor = new HttpContextAccessor();
                var httpRequest = _httpContextAccessor.HttpContext.Request;
                userPlantInfo = Newtonsoft.Json.JsonConvert.DeserializeObject<Plant>(httpRequest.Headers["CurrentUserInfo"].ToString() ?? "");
            }

        [Route("GetProcessConfirmation")]
        [HttpPost]
        public async Task<List<ProcessConfirmation>> GetProcessConfirmation(ProcessConfirmation processConfirmation)
        {
            var result = await _procesConfirmationService.GetProcessConfirmation(processConfirmation);
            return result;
        }


        //[Route("GetProcessConfirmation")]
        //[HttpPost]
        //public async Task<IActionResult> GetProcessConfirmation(ProcessConfirmation processConfirmation)
        //{
        //    try
        //    {
        //        var result = await _procesConfirmationService.GetProcessConfirmation(processConfirmation);

        //        // ✅ Explicitly throwing 499 status code
        //        throw new CustomHttpException(499, "Client closed request explicitly.");

        //        return Ok(result);
        //    }
        //    catch (CustomHttpException customEx)
        //    {
        //        return StatusCode(customEx.StatusCode, new
        //        {
        //            StatusCode = customEx.StatusCode,
        //            Message = customEx.Message
        //        });
        //    }
        //    catch (Exception ex)
        //    {
        //        return StatusCode(500, new
        //        {
        //            StatusCode = 500,
        //            Message = "Internal Server Error",
        //            Details = ex.Message
        //        });
        //    }
        //}


        [Route("pendingTagModeStatus")]
            [HttpPost]
            public int InsertTagAnsweredQuestion(ProcessConfirmation processConfirmation)
            {

                string folderName = "ElpcUpload";
                string webRootPath = new Utility.Utility().GetConfigValue("PathName", userPlantInfo.PlantCode);
                string newPath = Path.Combine(webRootPath, folderName);

                Common.HintImageUpload(newPath, processConfirmation.HintImages);

                var result = _procesConfirmationService.pendingTagModeStatus(processConfirmation);
                return result;

            }

        [Route("InsertProcessConfirmation")]
        [HttpPost]
        public async Task<Result> InsertProcessConfirmation(ProcessConfirmation processConfirmation)
        {

            //string folderName = "ElpcUpload";
            //string webRootPath = new Utility.Utility().GetConfigValue("PathName", userPlantInfo.PlantCode);
            //string newPath = Path.Combine(webRootPath, folderName);

            // Common.HintImageUpload(newPath, processConfirmation.HintImages);

            var result = await _procesConfirmationService.InsertProcessConfirmation(processConfirmation);
            if (processConfirmation.isDeviation == true)

            {
                processConfirmation.DeviationID = result.InsertedID;
                JObject jsonObj = JObject.Parse(processConfirmation.deviation_item);
                jsonObj["deviationId"] = processConfirmation.DeviationID;
                processConfirmation.deviation_item = JsonConvert.SerializeObject(jsonObj);
                SuperOPLTask jsonObject = new SuperOPLTask
                {
                    url = processConfirmation.OPLURL,
                    task = processConfirmation.task,
                    deviation = processConfirmation.deviation_item,
                };



                await AddtoOPLTask(jsonObject);


            }
            return result;

        }


        //[Route("InsertProcessConfirmation")]
        //[HttpPost]
        //public async Task<IActionResult> InsertProcessConfirmation(ProcessConfirmation processConfirmation)
        //{
        //    try
        //    {
        //        var result = await _procesConfirmationService.InsertProcessConfirmation(processConfirmation);

        //        if (processConfirmation.isDeviation)
        //        {
        //            processConfirmation.DeviationID = result.InsertedID;
        //            JObject jsonObj = JObject.Parse(processConfirmation.deviation_item);
        //            jsonObj["deviationId"] = processConfirmation.DeviationID;
        //            processConfirmation.deviation_item = JsonConvert.SerializeObject(jsonObj);

        //            SuperOPLTask jsonObject = new SuperOPLTask
        //            {
        //                url = processConfirmation.OPLURL,
        //                task = processConfirmation.task,
        //                deviation = processConfirmation.deviation_item,
        //            };

        //            await AddtoOPLTask(jsonObject);
        //        }

        //        // ✅ Explicitly throwing 499 status code
        //        throw new CustomHttpException(499, "Client closed request explicitly.");
        //    }
        //    catch (CustomHttpException customEx)
        //    {
        //        return StatusCode(customEx.StatusCode, new
        //        {
        //            StatusCode = customEx.StatusCode,
        //            Message = customEx.Message
        //        });
        //    }
        //    catch (Exception ex)
        //    {
        //        return StatusCode(500, new
        //        {
        //            StatusCode = 500,
        //            Message = "Internal Server Error",
        //            Details = ex.Message
        //        });
        //    }
        //}


        [Route("AddtoOPLTask")]
            [HttpPost]
            private async Task AddtoOPLTask([FromBody] SuperOPLTask JSONObject)
            {

                {
                    Deviation deviation = JsonConvert.DeserializeObject<Deviation>(JSONObject.deviation);
                    //deviation.DeviationId=
                    int plantID = 0;

                    SchedulerDataModel schedulerDataModel = new SchedulerDataModel() { Headers = new System.Collections.Generic.List<System.Collections.Generic.KeyValuePair<string, string>>() };
                    if (Request.Headers != null && Request.Headers.Count > 0)
                    {
                        if (Request.Headers.ContainsKey("CurrentUserInfo"))
                        {
                            schedulerDataModel.Headers.Add(new System.Collections.Generic.KeyValuePair<string, string>("CurrentUserInfo", Request.Headers["CurrentUserInfo"]));
                        }
                        if (Request.Headers.ContainsKey("Plant"))
                        {
                            schedulerDataModel.Headers.Add(new System.Collections.Generic.KeyValuePair<string, string>("Plant", Request.Headers["Plant"]));
                            plantID = Convert.ToInt32(Request.Headers["Plant"]);
                        }
                    }

                    schedulerDataModel.POSTData = JsonConvert.SerializeObject(JSONObject);

                    await _schedulerService.AddCreateOPL(new Schedule() { ScheduleName = "OPLCreation", DataObj = JsonConvert.SerializeObject(schedulerDataModel), PlantId = plantID, ErrorDetail = "Taskid to be created" });


                }

            }

            [Route("updateEventEndTime")]
            [HttpPost]
            public int updateEventEndTime([FromBody] UpdateEventTimeRequest request)
            {
                var result = _procesConfirmationService.updateEventEndTime(request.eventstarttime, request.processConfirmationdata);
                return 1;
            }

            [Route("AddToCustomMode")]
            [HttpPost]
            public Task<Result> AddToCustomMode(ProcessConfirmation processConfirmation)
            {
                var result = _procesConfirmationService.AddToCustomMode(processConfirmation);
                return result;
            }

            [HttpPost]
            [Route("DeleteFromCustomMode")]
            public Task<Result> DeleteFromCustomMode(ProcessConfirmation processConfirmation)
            {
                var result = _procesConfirmationService.DeleteFromCustomMode(processConfirmation);
                return result;
            }

            //[Route("GetValueStreamByQuestionID/{QuestionID}")]
            //public Task<List<ValueStream>> GetValueStreamByQuestionID(int QuestionID)
            //{

            //    var result = _procesConfirmationService.GetValueStreamByQuestionID(QuestionID);
            //    return result;
            //}

            [Route("GetValueStreamByQuestionID/{QuestionID}")]
            public async Task<List<ValueStream>> GetValueStreamByQuestionID(int QuestionID)
            {
                var cache = HttpContext.RequestServices.GetService(typeof(IMemoryCache)) as IMemoryCache;
                if (cache == null)
                {
                    // Log the issue

                    // Return null or some default value indicating the failure
                    return null;
                }

                var cacheKey = $"SingleLineTextByQuestionID_{QuestionID}";

                if (!cache.TryGetValue(cacheKey, out List<ValueStream> cachedResult))
                {
                    var result = await _procesConfirmationService.GetValueStreamByQuestionID(QuestionID);
                    if (result != null)
                    {
                        // Cache the result for 10 minutes (adjust the TimeSpan as needed)
                        cache.Set(cacheKey, result, TimeSpan.FromMinutes(10));
                    }
                    return result;
                }

                return cachedResult;
            }


            [Route("getSelectedLinkedTagQuestionCount/{TagId}/{maintablequestioncount:bool?}")]
            public async Task<int> getSelectedLinkedTagQuestionCount(int TagId, Boolean maintablequestioncount = false)
            {
                try
                {
                    var result = await _procesConfirmationService.getSelectedLinkedTagQuestionCount(TagId, maintablequestioncount);
                    if (result != null)
                    {
                        return result;

                    }
                    else
                    {
                        return 0;
                    }
                }
                catch (Exception e)
                {

                    return 0;
                }


            }


            [Route("getCurrentSelectionQuestionsAndTag/{TagId}/{QuestionCount}")]
            public async Task<int> getCurrentSelectionQuestionsAndTag(string TagId, int QuestionCount)
            {
                try
                {
                    var tagidd = TagId.Split(",");
                    // int sam;
                    int resultsetcount = 0;
                    for (int i = 0; i < tagidd.Length; i++)
                    {
                        if (int.TryParse(tagidd[i].ToString(), out int tagid))
                        {
                            var result = await _procesConfirmationService.getSelectedLinkedTagQuestionCount(tagid);
                            if (result != null)
                            {
                                resultsetcount += result;

                            }
                            else
                            {
                                return resultsetcount;
                            }
                        }
                    }
                    //resultsetcount += QuestionCount;
                    //if (resultsetcount == 1000)
                    //{
                    //    resultsetcount = 20;
                    //}
                    //else if (resultsetcount >= 40)
                    //{
                    //    resultsetcount = 20;
                    //}
                    //else
                    //{
                    //    resultsetcount = (int)Math.Round(resultsetcount / 2.0);
                    //    //this.hintInLineCount = res
                    //}
                    return resultsetcount;



                }
                catch (Exception e)
                {

                    return 0;
                }
            }
        public class CustomHttpException : Exception
        {
            public int StatusCode { get; }

            public CustomHttpException(int statusCode, string message) : base(message)
            {
                StatusCode = statusCode;
            }
        }


        [Route("GetAssessorsByQuestionID/{QuestionID}")]
            public Task<List<Assessor>> GetAssessorsByQuestionID(int QuestionID)
            {

                var result = _procesConfirmationService.GetAssessorsByQuestionID(QuestionID);
                return result;
            }
        }


  
}
