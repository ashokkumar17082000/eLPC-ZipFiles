﻿using ELPC.Core;
using Serilog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ELPC.API.Controllers
{
    public static class Common
    {
        public static void HintImageUpload(string newPath, List<HintImage> hintImages)
        {
            if (!Directory.Exists(newPath))
            {
                Directory.CreateDirectory(newPath);
            }

            byte[] ImageData;
            if (hintImages != null && hintImages.Count > 0 && hintImages[0] != null)
            {
                foreach (var file in hintImages)
                {
                    var Image = file.FileContent.Split(',').ToList<string>(); //to avoaid file headers which casue base64 error
                    ImageData = Convert.FromBase64String(Image[1]);
                    if (ImageData != null)
                    {
                        try
                        {
                            string fileName = file.ImageTitle;
                            string fullPath = Path.Combine(newPath, fileName);
                            using (var imageFile = new FileStream(fullPath, FileMode.CreateNew))
                            {
                                imageFile.Write(ImageData, 0, ImageData.Length);
                                imageFile.Flush();
                            }
                        }
                        catch (Exception ex)
                        {
                            Log.Error("API Error-" + "HintImageUpload" + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                        }
                    }
                }
            }
        }


        public static async Task<FileStream> DownloadFilesFromPath(string path, string Dir, string inputFileName)
        {
            try
            {
                if (string.IsNullOrEmpty(path) || !System.Text.RegularExpressions.Regex.IsMatch(inputFileName, @"^[\w,\s-]+\.[A-Za-z0-9]{1,20}$"))
                {
                    return null;
                }

                var file = Path.Combine(Path.Combine(path, Dir), inputFileName);

                if (System.Text.RegularExpressions.Regex.IsMatch(file, @"^\s*$"))
                {
                    return null;
                }
                else
                {
                    if (System.IO.File.Exists(file))
                    {
                        return await Task.Run(() => new FileStream(file, FileMode.Open, FileAccess.Read));
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }

    }
}
