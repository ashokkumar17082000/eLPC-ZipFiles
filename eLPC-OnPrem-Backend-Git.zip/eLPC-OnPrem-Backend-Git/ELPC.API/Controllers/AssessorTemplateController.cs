﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ELPC.Core;
using ELPC.BAL.Interfaces;
using System.Data;
using System.Reflection;
using OfficeOpenXml;
//using ExcelDataReader;
using System.IO;
using OfficeOpenXml.Style;
using Microsoft.AspNetCore.Hosting;

namespace ELPC.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [GlobalExceptionFilter]
    public class AssessorTemplateController : ControllerBase
    {
        public readonly IAssessorTemplateService _assessorTemplateService;
        public readonly IHttpContextAccessor _httpContextAccessor;
        public readonly IHostingEnvironment _hostingEnvironment;

        public AssessorTemplateController(IAssessorTemplateService assessorTemplateService, IHttpContextAccessor httpContextAccessor, IHostingEnvironment hostingEnvironment)
        {
            _assessorTemplateService = assessorTemplateService;
            _httpContextAccessor = httpContextAccessor;
            _hostingEnvironment = hostingEnvironment;
        }

        [HttpGet]
        [Route("GetAssessorTemplates")]
        public Task<List<AssessorTemplate>> GetAssessorTemplates()
        {
            var result = _assessorTemplateService.GetAssessorTemplates();
            return result;
        }

        [HttpGet]
        [Route("ValidateAssessorTemplateName/{assessorTemplateName}")]
        public Task<List<AssessorTemplate>> ValidateAssessorTemplateName(string assessorTemplateName)
        {
            var result = _assessorTemplateService.ValidateAssessorTemplateName(assessorTemplateName);
            return result;
        }

        [HttpGet]
        [Route("GetAssessorTemplatesHistory/{templateID}")]
        public Task<List<AssessorStreamHistory>> GetAssessorTemplatesHistory(int templateID)
        {
            var result = _assessorTemplateService.GetAssessorTemplatesHistory(templateID);
            return result;
        }

        [HttpGet]
        [Route("GetAssessors")]
        public Task<List<Assessor>> GetAssessors()
        {

            var result = _assessorTemplateService.GetAssessors();
            return result;
        }

        [HttpGet]
        [Route("GetAssessorsByTemplateID/{templateID}")]
        public Task<List<Assessor>> GetAssessorsByTemplateID(int templateID)
        {

            var result = _assessorTemplateService.GetAssessorByTemplateID(templateID);
            return result;
        }

        [HttpGet]
        [Route("AssessorsRestoreByTemplateHistoryID/{historyID}")]
        public Task<Result> AssessorsRestoreByTemplateHistoryID(int historyID)
        {
            var result = _assessorTemplateService.AssessorsRestoreByTemplateHistoryID(historyID);
            return result;
        }

        [HttpPost]
        [Route("InsertAssessorTemplate")]
        public Task<Result> InsertAssessorTemplate([FromBody]AssessorTemplate assessorTemplate)
        {
            var result = _assessorTemplateService.InsertAssessorTemplate(assessorTemplate);
            return result;
        }


        //******************************************* Import Excel*************************************************
        [HttpPost]
        [Route("AssessorImportExcel")]
        //public Task<Result> ImportExcel(ImportCombinedList importCombinedList)
        public Task<Result> ImportExcel()
        {

            var result = (dynamic)null;
            /*
            var httpRequest = _httpContextAccessor.HttpContext.Request;

            var file = httpRequest.Form.Files[0];
            var ntid = httpRequest.Form["ntid"].ToString();

            System.Data.DataTable dt = new System.Data.DataTable();
            DataSet ds = new DataSet();
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            using (var fileStream = file.OpenReadStream())
            {

                // ds = ReadExcel.Read(fileStream);
                using (var reader = ExcelReaderFactory.CreateReader(fileStream))
                {
                    ds = reader.AsDataSet(new ExcelDataSetConfiguration()
                    {
                        UseColumnDataType = false,                   //Use excel column datatype to define datatable
                        ConfigureDataTable = (tableReader) => new ExcelDataTableConfiguration()
                        {
                            EmptyColumnNamePrefix = "Column",       //If column name not avaliable the value passed will be appended
                            UseHeaderRow = true                     //Use first row of excel as headers
                        }
                    });
                }
            }


            List<ImpexAssessorTemplate> assessorTemplateList = new List<ImpexAssessorTemplate>();
            List<ImpexAssessor> assessorListStream = new List<ImpexAssessor>();
            AssessorImportCombinedList obj = new AssessorImportCombinedList();

            //var assessorCsv = Utility.Utility.ToCsv(ds.Tables[0]);
            // List<AssessorTemplate> cornerStoneData;
            // using (var reader = new StreamReader(Utility.Utility.GenerateStreamFromString(assessorCsv)))
            // using (var csv = new CsvReader(reader, System.Globalization.CultureInfo.CurrentCulture))
            // {
            //     csv.Configuration.HeaderValidated = null;
            //     csv.Configuration.MissingFieldFound = null;
            //     cornerStoneData = csv.GetRecords<AssessorTemplate>().ToList();
            // }


            assessorTemplateList = Utility.Utility.ConvertDataTable<ImpexAssessorTemplate>(ds.Tables[0]);
            assessorListStream = Utility.Utility.ConvertDataTable<ImpexAssessor>(ds.Tables[1]);

            //convert target frequency type names into type id

            foreach (ImpexAssessor assessor in assessorListStream)
            {

                switch (assessor.TargetFrequencyTypeID)
                {
                    case "Shift":
                        assessor.TargetFrequencyTypeID = "1";
                        break;
                    case "Day":
                        assessor.TargetFrequencyTypeID = "2";
                        break;
                    case "Week":
                        assessor.TargetFrequencyTypeID = "3";
                        break;
                    case "Bi-weekly":
                        assessor.TargetFrequencyTypeID = "4";
                        break;
                    case "Month":
                        assessor.TargetFrequencyTypeID = "5";
                        break;
                    case "Quarter":
                        assessor.TargetFrequencyTypeID = "6";
                        break;
                    case "Year":
                        assessor.TargetFrequencyTypeID = "7";
                        break;
                    default:
                        break;
                }
            }


            //validations 
            //foreach(AssessorTemplate assessorTemplate in assessorTemplateList)
            //{
            //    if(assessorTemplate.IsTargetFrequencyDefined == true)
            //    {
            //        var assessors = assessorListStream.Where(x => x.TempID == assessorTemplate.TempID);
            //        if(assessors != null)
            //        {
            //            foreach(Assessor assessor in assessors)
            //            {
            //                if (String.IsNullOrEmpty(assessor.TargetFrequencyValue))
            //                {
            //                    //result.ResultMessage = "Target Frequency Value should not be empty";
            //                    //result.ResultCode = 0;
            //                    //return result;
            //                    break;
            //                }
            //            }
            //        }
            //    }
            //}

            //

            ValidateAssessorTemplate(ref assessorTemplateList, ref assessorListStream);

            obj.list1 = assessorTemplateList;
            obj.list2 = assessorListStream;


            result = _assessorTemplateService.AssessorImportExcel(obj, ntid);
            */
            return result;

        }

        private void ValidateAssessorTemplate(ref List<ImpexAssessorTemplate> assessorTemplateList, ref List<ImpexAssessor> assessorList)
        {
            byte[] fileContents;

            AssessorImportCombinedList assessorErrorList = new AssessorImportCombinedList();
            assessorErrorList.list1 = new List<ImpexAssessorTemplate>();
            assessorErrorList.list2 = new List<ImpexAssessor>();
            //AssessorImportCombinedList assessorImportCombinedObj = new AssessorImportCombinedList();
            //validations 
            foreach (ImpexAssessorTemplate assessorTemplate in assessorTemplateList)
            {
                ImpexAssessorTemplate assessorTemplateObj = new ImpexAssessorTemplate();

                var name = assessorTemplateList.Where(x => x.AssessorTemplateName == assessorTemplate.AssessorTemplateName && x.TempID != assessorTemplate.TempID && x.IsDeleted == false).ToList();
                var assessors = assessorList.Where(x => x.TempID == assessorTemplate.TempID);

                if (name.Count > 0)
                {
                    assessorTemplate.ErrorMessage = "Assessor Template Name already exists";
                    assessorTemplateList = assessorTemplateList.Where(x => x.TempID != assessorTemplate.TempID).ToList();
                    assessorList = assessorList.Where(x => x.TempID != assessorTemplate.TempID).ToList();
                    assessorTemplateObj = assessorTemplate;
                    assessorErrorList.list1.Add(assessorTemplateObj);

                }
                if (assessorTemplate.IsTargetFrequencyDefined == true)
                {
                    if (assessors != null)
                    {
                        foreach (ImpexAssessor assessor in assessors)
                        {
                            ImpexAssessor assessorObj = new ImpexAssessor();
                            if (String.IsNullOrEmpty(assessor.TargetFrequencyValue) || String.IsNullOrEmpty(assessor.TargetFrequencyTypeID))
                            {
                                if (String.IsNullOrEmpty(assessorTemplate.ErrorMessage))
                                {
                                    assessorTemplate.ErrorMessage = "Target Frequency Value/Type should not be empty";

                                }
                                else
                                {
                                    assessorTemplate.ErrorMessage = assessorTemplate.ErrorMessage + "; Target Frequency Value/Type should not be empty";
                                }

                                assessorTemplateObj = assessorTemplate;
                                assessorErrorList.list1.Add(assessorTemplateObj);
                                assessorObj = assessor;
                                assessorErrorList.list2.Add(assessorObj);
                                assessorTemplateList = assessorTemplateList.Where(x => x.TempID != assessorTemplate.TempID).ToList();
                                assessorList = assessorList.Where(x => x.TempID != assessorTemplate.TempID && x.AssessorName != assessor.AssessorName).ToList();
                            }
                        }
                    }
                }
            }

            System.Data.DataTable assessorTemplateTable = new System.Data.DataTable();
            System.Data.DataTable assessorTable = new System.Data.DataTable();

            if (assessorErrorList.list1.Count > 0)
            {
                assessorTemplateTable = Utility.Utility.ToDataTable(assessorErrorList.list1);
            }
            if (assessorErrorList.list2.Count > 0)
            {
                assessorTable = Utility.Utility.ToDataTable(assessorErrorList.list2);

            }
            string webRootPath = _hostingEnvironment.WebRootPath;
            string folderName = "Elpc_AssessorUpload";
            string newPath = Path.Combine(webRootPath, folderName);
            if (!Directory.Exists(newPath))
            {
                Directory.CreateDirectory(newPath);
            }
            if (assessorErrorList.list1.Count > 0)
            {
                using (ExcelPackage pck = new ExcelPackage())
                {

                    var worksheet_AssessorTemp = pck.Workbook.Worksheets.Add("AssessorTemplate");
                    var worksheeter_Assessor = pck.Workbook.Worksheets.Add("Assessors");

                    worksheet_AssessorTemp.Cells["A1"].LoadFromDataTable(assessorTemplateTable, true);
                    worksheeter_Assessor.Cells["A1"].LoadFromDataTable(assessorTable, true);


                    worksheet_AssessorTemp.Protection.IsProtected = true; //--------Protect whole sheet


                    worksheet_AssessorTemp.Cells[worksheet_AssessorTemp.Dimension.Address].AutoFitColumns();
                    worksheeter_Assessor.Cells[worksheet_AssessorTemp.Dimension.Address].AutoFitColumns();
                    using (var range = worksheet_AssessorTemp.Cells[1, 1, 1, 5])
                    {
                        range.Style.Font.Bold = true; range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                        range.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.DarkBlue); range.Style.Font.Color.SetColor(System.Drawing.Color.White);
                    }


                    int colNumber = 0;

                    foreach (DataColumn col in assessorTemplateTable.Columns)
                    {
                        colNumber++;
                        if (col.DataType == typeof(DateTime))
                        {
                            //worksheet_vTemp.Column(colNumber).Style.Numberformat.Format = "MM/dd/yyyy hh:mm:ss AM/PM";
                            worksheet_AssessorTemp.Column(colNumber).Style.Numberformat.Format = "MM/dd/yyyy";
                        }
                    }

                    fileContents = pck.GetAsByteArray();
                }

                if (fileContents != null || fileContents.Length > 0)
                {
                    string datetimeString = string.Format("{0:yyyy-MM-dd_hh-mm-ss-tt}.txt", DateTime.Now);
                    string fullPath = Path.Combine(newPath, "AssessorTemplate" + datetimeString + ".xlsx");
                    using (var imageFile = new FileStream(fullPath, FileMode.CreateNew))
                    {
                        imageFile.Write(fileContents, 0, fileContents.Length);
                        imageFile.Flush();
                    }

                }
            }

            //return assessorImportCombinedList;
        }


        //**********************************    Import Excel End********************************************




        //*******************************Export Excel*******************************************************
        [Route("AssessorExportExcel")]
        [HttpGet]
        public IActionResult ExportExcel()
        {
            byte[] fileContents;
            DataSet ds = new DataSet();
            ds = _assessorTemplateService.AssessorExportExcel();
            //Set Name of DataTables.
            ds.Tables[0].TableName = "AssessorTemplate";
            ds.Tables[1].TableName = "Assessors";

            // ConvertToExcel(ds);
            //GenerateExcelFile(ds, @"C:\Users\jnk1cob\ELPC_Project\30_Source\ELPC_WebApp\ELPC.API\wwwroot\Elpc_AssessorUpload\AsrTemp.xlsx");
            //ConvertToExcel(ds);

            using (ExcelPackage pck = new ExcelPackage())
            {

                var worksheet_AssessorTemp = pck.Workbook.Worksheets.Add(ds.Tables[0].TableName);
                var worksheeter_Assessor = pck.Workbook.Worksheets.Add(ds.Tables[1].TableName);

                worksheet_AssessorTemp.Cells["A1"].LoadFromDataTable(ds.Tables[0], true);
                //Add a DateTime Validation to column F
                //var val4 = worksheet_AssessorTemp.DataValidations.AddDateTimeValidation("F:F");
                ////For DateTime Validation, you have to set error message to true
                //val4.ShowErrorMessage = true;
                ////Minimum allowed date
                //val4.Formula.Value = new DateTime(2017, 03, 15, 01, 0, 0);
                ////Maximum allowed date
                //val4.Formula2.Value = new DateTime(2020, 03, 16, 12, 0, 0);
                //val4.AllowBlank = true;

                //var validation = worksheet_AssessorTemp.DataValidations.AddIntegerValidation("G1:G15");
                // Alternatively:
                //var validation = sheet.Cells["A1:A2"].DataValidation.AddIntegerDataValidation();
                //validation.ErrorStyle = ExcelDataValidationWarningStyle.stop;
                //validation.PromptTitle = "Enter a integer value here";
                //validation.Prompt = "Value should be between 1 and 5";
                //validation.ShowInputMessage = true;
                //validation.ErrorTitle = "An invalid value was entered";
                //validation.Error = "Value must be between 1 and 5";
                //validation.ShowErrorMessage = true;
                //validation.Operator = ExcelDataValidationOperator.between;
                //validation.Formula.Value = 1;
                //validation.Formula2.Value = 5;


                var assessorFrequencyType = worksheeter_Assessor.DataValidations.AddListValidation("E:E");
                assessorFrequencyType.Formula.Values.Add("Shift");
                assessorFrequencyType.Formula.Values.Add("Day");
                assessorFrequencyType.Formula.Values.Add("Week");
                assessorFrequencyType.Formula.Values.Add("Bi-weekly");
                assessorFrequencyType.Formula.Values.Add("Month");
                assessorFrequencyType.Formula.Values.Add("Quarter");
                assessorFrequencyType.Formula.Values.Add("Year");
                assessorFrequencyType.Validate();

                assessorFrequencyType.ShowErrorMessage = true;
                //var val5 = worksheet_AssessorTemp.DataValidations.AddCustomValidation("E20");


                worksheeter_Assessor.Cells["A1"].LoadFromDataTable(ds.Tables[1], true);


                worksheet_AssessorTemp.Protection.IsProtected = true; //--------Protect whole sheet

                for (int i = 1; i <= 9; i++)
                {
                    worksheet_AssessorTemp.Column(i).Style.Locked = false;
                }

                //worksheet_AssessorTemp.Cells["A11"].Formula = "SUM(A2:A10)";

                /*worksheet_AssessorTemp.Cells["A11"].Formula = "A10+1";*/    //auto incremnt
                                                                              //int z = 1;
                                                                              //foreach (var item in ds.Tables[0].Rows)
                                                                              //{
                                                                              //    worksheet_AssessorTemp.Cells[z, 0].Value = z;
                                                                              //    z++;
                                                                              //}

                worksheet_AssessorTemp.Cells[worksheet_AssessorTemp.Dimension.Address].AutoFitColumns();
                worksheeter_Assessor.Cells[worksheeter_Assessor.Dimension.Address].AutoFitColumns();
                using (var range = worksheet_AssessorTemp.Cells[1, 1, 1, 5])
                {
                    range.Style.Font.Bold = true; range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    range.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.DarkBlue); range.Style.Font.Color.SetColor(System.Drawing.Color.White);
                }

                ////for validations 
                //// Add a date time validation
                //var validation = worksheet_AssessorTemp.DataValidations.AddDateTimeValidation("E:E");
                //// set validation properties
                //validation.ShowErrorMessage = true;
                //validation.ErrorTitle = "An invalid date was entered";
                //validation.Error = "The date must be between 2011-01-31 and 2011-12-31";
                //validation.Prompt = "Enter date here";
                //validation.Formula.Value = DateTime.Parse("2011-01-01");
                //validation.Formula2.Value = DateTime.Parse("2011-12-31");
                //validation.Operator = ExcelDataValidationOperator.between;


                //-------Unlock 3rd column
                // worksheet_AssessorTemp.Column(1).Style.Locked = true;


                int colNumber = 0;

                foreach (DataColumn col in ds.Tables[0].Columns)
                {
                    colNumber++;
                    if (col.DataType == typeof(DateTime))
                    {
                        //worksheet_vTemp.Column(colNumber).Style.Numberformat.Format = "MM/dd/yyyy hh:mm:ss AM/PM";
                        worksheet_AssessorTemp.Column(colNumber).Style.Numberformat.Format = "MM/dd/yyyy";
                    }
                }

                fileContents = pck.GetAsByteArray();
            }
            if (fileContents == null || fileContents.Length == 0)
            {
                return NotFound();
            }

            return File(
                fileContents: fileContents,
                contentType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                fileDownloadName: "AssessorTemplate.xlsx"
            );
        }

        [HttpPost]
        [Route("DeleteAssessorTemplate")]
        public Task<Result> DeleteAssessorTemplate([FromBody]AssessorTemplate assessorTemplate)
        {
            var result = _assessorTemplateService.DeleteAssessorTemplate(assessorTemplate);
            return result;
        }

        [HttpPost]
        [Route("InsertAssessorProxy")]
        public Task<Result> InsertAssessorProxy(AssessorProxy assessorProxy)
        {
            var result = _assessorTemplateService.InsertAssessorTemplateProxy(assessorProxy);
            return result;
        }

        [HttpGet]
        [Route("AssessorProxiesByAssessorTemplateID/{assessorTemplateID}")]
        public Task<List<AssessorProxy>> AssessorProxiesByAssessorTemplateID(int assessorTemplateID)
        {
            var result = _assessorTemplateService.AssessorProxiesByAssessorTemplateID(assessorTemplateID);
            return result;
        }
        [HttpGet]
        [Route("FetchAssessorTemplateByTemplateID/{assessorTemplateID}")]
        public Task<List<AssessorTemplate>> FetchAssessorTemplateByTemplateID(int assessorTemplateID)
        {
            var result = _assessorTemplateService.FetchAssessorTemplateByTemplateID(assessorTemplateID);
            return result;
        }









    }
}