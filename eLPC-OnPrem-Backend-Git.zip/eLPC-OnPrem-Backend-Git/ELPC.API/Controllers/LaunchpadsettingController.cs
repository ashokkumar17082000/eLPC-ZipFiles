﻿using ELPC.BAL.Interfaces;
using ELPC.Core;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ELPC.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [GlobalExceptionFilter]
    public class LaunchpadsettingController : ControllerBase
    {
        public readonly ILaunchpadsettingService _launchpadsettingService;
        public readonly IHttpContextAccessor _httpContextAccessor;
        public readonly IHostingEnvironment _hostingEnvironment;

        public LaunchpadsettingController(ILaunchpadsettingService launchpadsettingService, IHttpContextAccessor httpContextAccessor, IHostingEnvironment hostingEnvironment)
        {
            _launchpadsettingService = launchpadsettingService;
            _httpContextAccessor = httpContextAccessor;
            _hostingEnvironment = hostingEnvironment;
        }



        [HttpPost]
        [Route("insertLaunchpadURL")]
        public Task<Result> InsertLaunchpadURL([FromBody] ReportText reportText)
        {
            var result = _launchpadsettingService.InsertLaunchpadURL(reportText);
            return result;
        }
        [Route("LaunchpadHistoryID/{historyID}")]
        public Task<Result> LaunchpadHistoryID(int historyID)
        {
            var result = _launchpadsettingService.LaunchpadHistoryID(historyID);
            return result;
        }
        [HttpGet]
        [Route("GetLaunchpad")]
        public Task<List<ReportText>> GetLaunchpad()
        {

            var result = _launchpadsettingService.GetLaunchpad();
            return result;
        }
        [HttpGet]
        [Route("GetRestoredata")]
        public Task<List<Reportrestore>> GetRestoredata()
        {

            var result = _launchpadsettingService.GetRestoredata();
            return result;
        }
    }
}
