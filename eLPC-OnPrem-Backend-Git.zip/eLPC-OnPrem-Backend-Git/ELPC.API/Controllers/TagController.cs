﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ELPC.Core;
using ELPC.BAL.Interfaces;
using Microsoft.Extensions.Caching.Memory;
using System;

namespace ELPC.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [GlobalExceptionFilter]
    public class TagController : ControllerBase
    {
        public readonly ITagService _tagService;

        public TagController(ITagService tagService)
        {
            _tagService = tagService;
        }

        [Route("GetTags")]
        public async Task<List<Tag>> GetTags()
        {
            var result = await _tagService.GetTags();
            return result;
        }

        [Route("GetTagsProcessConfirmation")]
        public async Task<List<Tag>> GetTagsProcessConfirmation()
        {
            var cache = HttpContext.RequestServices.GetService(typeof(IMemoryCache)) as IMemoryCache;
            if (cache == null)
            {
                // handle case where IMemoryCache service is not available
                return new List<Tag>();
            }

            var cacheKey =  "TagsCacheKey";

            if (!cache.TryGetValue(cacheKey, out List<Tag> cachedResult))
            {
                var result = await _tagService.GetTags();
                if (result != null)
                {
                    // Cache the result for 10 minutes (adjust the TimeSpan as needed)
                    cache.Set(cacheKey, result, TimeSpan.FromMinutes(10));
                }
                return result;
            }

            return cachedResult;
        }

        [Route("GetTagsByID/{tagID}")]
        public async Task<List<Tag>> GetTagsByID(int tagID)
        {
            var result = await _tagService.GetTagsByID(tagID);
            return result;
        }

        [Route("GetTagHistory/{templateID}")]
        public async Task<List<TagHistory>> GetTagHistory(int templateID)
        {
            var result = await _tagService.GetTagHistory(templateID);
            return result;
        }

        [Route("TagRestoreByTemplateHistoryID/{historyID}")]
        public Task<Result> TagRestoreByTemplateHistoryID(int historyID)
        {
            var result = _tagService.TagRestoreByTemplateHistoryID(historyID);
            return result;
        }

        [Route("InsertTag")]
        public Task<Result> InsertTag([FromBody]Tag tag)
        {
            var result = _tagService.InsertTag(tag);
            return result;
        }

        [Route("DeleteTag")]
        public Task<Result> DeleteTag([FromBody]Tag tag)
        {
            var result = _tagService.DeleteTag(tag);
            return result;
        }

        [Route("GetQuestionsByTagID/{tagID}")]
        public Task<List<Question>> GetQuestionsByTagID(int tagID)
        {
            var result = _tagService.GetQuestionsByTagID(tagID);
            return result;
        }


        [Route("GetTagsByTagID/{tagID}")]
        public Task<List<Tag>> GetTagsByTagID(int tagID)
        {
            var result = _tagService.GetTagsByTagID(tagID);
            return result;
        }

        [Route("GetAssessorsByTagIDs")]
        [HttpPost]
        public Task<List<Assessor>> GetAssessorsByTagIDs([FromBody]TagID _tag)
        {
            var result = _tagService.GetAssessorsByTagIDs(_tag.TagsIDs);
            return result;
        }

        [Route("InsertTagProxy")]
        public Task<Result> InsertTagProxy(TagProxy tagProxy)
        {
            var result = _tagService.InsertTagProxy(tagProxy);
            return result;
        }

        [Route("FetchQuestionsByAssessorsAndValueStreams")]
        public Task<List<Question>> FetchQuestionsByAssessorsAndValueStreams([FromBody] AssessorValuestreamList assessorValuestreamList)
        {
            var result = _tagService.FetchQuestionsByAssessorsAndValuestreams(assessorValuestreamList.AssessorIDs, assessorValuestreamList.ValueStreamIDs);
            return result;
        }

        [Route("FetchTagsByAssessorsAndValueStreams")]
        public Task<List<Tag>> FetchTagsByAssessorsAndValueStreams([FromBody] AssessorValuestreamList assessorValuestreamList)
        {
            var result = _tagService.FetchTagsByAssessorsAndValuestreams(assessorValuestreamList.AssessorIDs, assessorValuestreamList.ValueStreamIDs);
            return result;
        }

        [Route("ValueStreamsByTagID/{tagID}")]
        public Task<List<ValueStream>> ValueStreamsByTagID(int tagID)
        {
            var result = _tagService.ValueStreamsByTagID(tagID);
            return result;
        }

        [Route("AssessorsByTagID/{tagID}")]
        public Task<List<Assessor>> AssessorsByTagID(int tagID)
        {
            var result = _tagService.AssessorsByTagID(tagID);
            return result;
        }

        [HttpGet]
        [Route("TagProxiesByTagID/{tagID}")]
        public Task<List<TagProxy>> TagProxiesByTagID(int tagID)
        {
            var result = _tagService.TagProxiesByTagID(tagID);
            return result;
        }

        [HttpGet]
        [Route("FetchProcessConfirmationTags")]
        public Task<List<Tag>> FetchProcessConfirmationTags()
        {
            var result = _tagService.FetchProcessConfirmationTags();
            return result;
        }

        [HttpGet]
        [Route("FetchTagDetailsByTagID/{tagID}")]
        public Task<List<Tag>> FetchTagDetailsByTagID(int tagID)
        {
            var result = _tagService.FetchTagDetailsByTagID(tagID);
            return result;
        }

        [HttpPost]
        [Route("UpdateAuditByTagID/{tagID}")]
        public Task<Result> UpdateAuditByTagID(int tagID)
        {
            var result = _tagService.UpdateAuditByTagID(tagID);
            return result;
        }
    }
}