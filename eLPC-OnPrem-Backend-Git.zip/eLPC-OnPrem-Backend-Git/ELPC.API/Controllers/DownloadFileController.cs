﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Hosting;
using System.Net.Http.Headers;
using Microsoft.Extensions.Configuration;
using ELPC.Core;
using Serilog;

namespace ELPC.API.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    [GlobalExceptionFilter]
    public class DownloadFileController : ControllerBase
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private Plant userPlantInfo;

        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IConfiguration _iconfiguration;
        public DownloadFileController(IHostingEnvironment environment, IConfiguration iconfiguration)
        {
            _hostingEnvironment = environment;
            _iconfiguration = iconfiguration;

            _httpContextAccessor = new HttpContextAccessor();
            var httpRequest = _httpContextAccessor.HttpContext.Request;
            userPlantInfo = Newtonsoft.Json.JsonConvert.DeserializeObject<Plant>(httpRequest.Headers["CurrentUserInfo"].ToString() ?? "");
        }

        [Route("DownloadFile/{input}")]
        public async Task<FileStream> DownloadFile(string input)
        {
            string path = new Utility.Utility().GetConfigValue("PathName", userPlantInfo.PlantCode);
            return await Common.DownloadFilesFromPath(path, "ElpcUpload", input);
        }

        [Route("DownloadQuestionAttachment/{input}")]
        public async Task<FileStream> DownloadQuestionAttachment(string input)
        {
            string path = new Utility.Utility().GetConfigValue("PathName", userPlantInfo.PlantCode);
            return await Common.DownloadFilesFromPath(path, "ElpcUploadQuestion", input);
        }

        [Route("upload/{input}")]
        public async Task<IActionResult> Upload(IFormFile input)
        {
            var uploads = Path.Combine(_hostingEnvironment.WebRootPath, "Upload");
            if (!Directory.Exists(uploads))
            {
                Directory.CreateDirectory(uploads);
            }
            if (input.Length > 0)
            {
                var filePath = Path.Combine(uploads, input.FileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await input.CopyToAsync(fileStream);
                }
            }
            return Ok();
        }

        [Route("UploadFile")]
        [HttpPost, DisableRequestSizeLimit]
        public async Task<IActionResult> UploadFile()
        {
            try
            {
                string folderName = "Upload";
                string webRootPath = _hostingEnvironment.WebRootPath;
                string newPath = Path.Combine(webRootPath, folderName);
                if (!Directory.Exists(newPath))
                {
                    Directory.CreateDirectory(newPath);
                }

                foreach (var file in Request.Form.Files)
                {

                    if (file.Length > 0)
                    {
                        string fileName = "";

                        try
                        {
                            fileName = System.DateTime.Now.ToString("dd-mm-yyyy hh-mm-ss ") + ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                        }
                        catch (Exception ex)
                        {
                            fileName = System.DateTime.Now.ToString("dd-mm-yyyy hh-mm-ss ") + file.FileName.Trim('"');
                        }

                        string fullPath = Path.Combine(newPath, fileName);
                        using (var stream = new FileStream(fullPath, FileMode.Create))
                        {
                            await file.CopyToAsync(stream);
                        }
                    }
                }
                return Content("Upload Successful.");

            }
            catch (System.Exception ex)
            {
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return Content("Upload Failed: " + ex.Message);
            }
        }

    }
}