﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ELPC.BAL.Interfaces;
using ELPC.Core;
using System.Data;
using POC.Utility;
using System.Reflection;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Linq;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Hosting;

namespace ELPC.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [GlobalExceptionFilter]
    public class ValueStreamTemplateController : Controller
    {
        public readonly ICommonService _commonService;
        public readonly IConfiguration _configuration;
        private readonly IHostingEnvironment _hostingEnvironment;

        public readonly IValueStreamTemplateService _valuestreamtemplateService;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public ValueStreamTemplateController(IValueStreamTemplateService valuestreamtemplateService, IHttpContextAccessor httpContextAccessor, ICommonService commonService, IConfiguration configuration, IHostingEnvironment hostingEnvironment)
        {
            _valuestreamtemplateService = valuestreamtemplateService;
            _httpContextAccessor = httpContextAccessor;
            _configuration = configuration;
            _commonService = commonService;
            _hostingEnvironment = hostingEnvironment;
        }

        [Route("GetValueStreamTemplates")]
        [HttpGet]
        public Task<List<ValueStreamTemplate>> GetValueStreamTemplates()
        {

            var result = _valuestreamtemplateService.GetValueStreamTemplates();
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [Route("GetValueStreamCategories")]
        [HttpGet]
        public Task<List<ValueStreamCategory>> GetValueStreamCategories()
        {
            var result = _valuestreamtemplateService.GetValueStreamCategories();
            return result;
        }

        [Route("GetValueStreams")]
        [HttpGet]
        public Task<List<ValueStream>> GetValueStreams()
        {

            var result = _valuestreamtemplateService.GetValueStreams();
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="templateID"></param>
        /// <returns></returns>
        [Route("GetValueStreamsHistory/{templateID}")]
        [HttpGet]
        public Task<List<ValueStreamHistory>> GetValueStreamsHistory(int templateID)
        {
            var result = _valuestreamtemplateService.GetValueStreamsHistory(templateID);
            return result;
        }

        [Route("ValueStreamRestoreByTemplateHistoryID/{historyID}")]
        public Task<Result> ValueStreamRestoreByTemplateHistoryID(int historyID)
        {
            var result = _valuestreamtemplateService.ValueStreamRestoreByTemplateHistoryID(historyID);
            return result;
        }

        [HttpPost]
        [Route("InsertValueStreamTemplate")]
        public async Task<Result> InsertValueStreamTemplate(ValueStreamTemplate valuestreamtemplate)
        {
            List<User> userList = (new CommonController(_commonService, _configuration, _hostingEnvironment).GetUsers()).Result;
            if (userList != null && userList.Count > 0)
            {
                var newUsers = valuestreamtemplate.ValueStreams.Where(vs => vs.Responsible_UserID != null && !userList.Any(ul => ul.NTID != null && vs.Responsible_UserID == ul.NTID)).Select(r => r.Responsible_UserID).Distinct();
                foreach (var user in newUsers)
                {
                    var ADController = new ActiveDirectoryController(_commonService);
                    var userDetails = ADController.GetUserListByNTID(user);

                    if (userDetails != null && userDetails.Count > 0)
                    {
                        var userObj = userDetails.FirstOrDefault();
                        if (userObj != null)
                        {
                            userObj.IsValueStream = true;
                            ADController.SaveActiveDirectoryList(userObj);
                        }
                    }
                }
            }
            var result = await  _valuestreamtemplateService.InsertValueStreamTemplate(valuestreamtemplate);
            return result;
        }
        [Route("GetValueStreamCategoryByTemplateID/{templateID}")]
        public Task<List<ValueStreamCategory>> GetValueStreamCategoryByTemplateID(int templateID)
        {
            var result = _valuestreamtemplateService.GetValueStreamCategoryByTemplateID(templateID);
            return result;
        }

        [Route("GetValueStreamsByCategoryID/{categoryID}")]
        public Task<List<ValueStream>> GetValueStreamsByCategoryID(int categoryID)
        {
            var result = _valuestreamtemplateService.GetValueStreamsByCategoryID(categoryID);
            return result;
        }

        [Route("GetShiftsByTemplateID/{templateID}")]
        public Task<List<Shift>> GetShiftsByTemplateID(int templateID)
        {
            var result = _valuestreamtemplateService.GetShiftsByTemplateID(templateID);
            return result;
        }

        //******************************************* Import Excel*************************************************
        [HttpPost]
        [Route("ImportExcel")]
        //public Task<Result> ImportExcel(ImportCombinedList importCombinedList)
        public Task<Result> ImportExcel()
        {

            var result = (dynamic)null;

            var httpRequest = _httpContextAccessor.HttpContext.Request;

            var file = httpRequest.Form.Files[0];

            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            using (var fileStream = file.OpenReadStream())
            {

                ds = ReadExcel.Read(fileStream);

            }


            List<ValueStreamTemplate> vTemplateList = new List<ValueStreamTemplate>();
            List<ValueStreamCategory> vTemplateListCat = new List<ValueStreamCategory>();
            List<ValueStream> vStream = new List<ValueStream>();
            ImportCombinedList obj = new ImportCombinedList();


            vTemplateList = Utility.Utility.ConvertDataTable<ValueStreamTemplate>(ds.Tables[0]);
            vTemplateListCat = Utility.Utility.ConvertDataTable<ValueStreamCategory>(ds.Tables[1]);
            vStream = Utility.Utility.ConvertDataTable<ValueStream>(ds.Tables[2]);

            obj.list1 = vTemplateList;
            obj.list2 = vTemplateListCat;
            obj.list3 = vStream;

            result = _valuestreamtemplateService.ImportExcel(obj);

            return result;

        }

        //**********************************    Import Excel End********************************************


        //*******************************Export Excel*******************************************************
        [Route("ExportExcel")]
        [HttpGet]
        public IActionResult ExportExcel()
        {
            byte[] fileContents;
            DataSet ds = new DataSet();
            ds = _valuestreamtemplateService.ExportExcel();
            //Set Name of DataTables.
            ds.Tables[0].TableName = "ValueStreamTemplate";
            ds.Tables[1].TableName = "ValueStreamTemplateCategory";
            ds.Tables[2].TableName = "ValueStream";


            using (ExcelPackage pck = new ExcelPackage())
            {

                var worksheet_vTemp = pck.Workbook.Worksheets.Add(ds.Tables[0].TableName);
                var worksheet_vCat = pck.Workbook.Worksheets.Add(ds.Tables[1].TableName);
                var worksheeter_VStream = pck.Workbook.Worksheets.Add(ds.Tables[2].TableName);
                worksheet_vTemp.Cells["A1"].LoadFromDataTable(ds.Tables[0], true);
                worksheet_vCat.Cells["A1"].LoadFromDataTable(ds.Tables[1], true);
                worksheeter_VStream.Cells["A1"].LoadFromDataTable(ds.Tables[2], true);
                worksheet_vTemp.Cells[1, 10].Style.Font.Bold = true;
                string index = "A1:K1";
                worksheet_vTemp.Cells[index].Style.Font.Bold = true;
                worksheet_vTemp.Cells[index].Style.Fill.PatternType = ExcelFillStyle.Solid;
                worksheet_vTemp.Cells[index].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Orange);


                int colNumber = 0;

                foreach (DataColumn col in ds.Tables[0].Columns)
                {
                    colNumber++;
                    if (col.DataType == typeof(DateTime))
                    {
                        //worksheet_vTemp.Column(colNumber).Style.Numberformat.Format = "MM/dd/yyyy hh:mm:ss AM/PM";
                        worksheet_vTemp.Column(colNumber).Style.Numberformat.Format = "MM/dd/yyyy";
                    }
                }

                fileContents = pck.GetAsByteArray();
            }
            if (fileContents == null || fileContents.Length == 0)
            {
                return NotFound();
            }

            return File(
                fileContents: fileContents,
                contentType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                fileDownloadName: "ValueStream.xlsx"
            );
        }
        //*********************************Export Excel Ends Here********************************************

        [Route("InsertValueStreamProxy")]
        public Task<Result> InsertValueStreamProxy(ValueStreamProxy valueStreamProxy)
        {
            var result = _valuestreamtemplateService.InsertValueStreamProxy(valueStreamProxy);
            return result;
        }

        //tree view logic
        [Route("GetValueStreamTemplateTree")]
        [HttpGet]
        public List<TreeViewItem> GetValueStreamTemplateTree()
        {
            List<TreeViewItem> list = new List<TreeViewItem>();

            var vslist = _valuestreamtemplateService.GetValueStreamTemplates();
            foreach (ValueStreamTemplate vst in vslist.Result)
            {
                TreeViewItem tview = new TreeViewItem();
                tview.Value = vst.ValueStreamTemplateID;
                tview.Text = vst.ValueStreamTemplateName;
                tview.ValueStreamTemplateID = vst.ValueStreamTemplateID;
                list.Add(tview);
            }
            list = list.OrderBy(a => a.Text).ToList();

            List<TreeViewItem> treelist = new List<TreeViewItem>();
            if (list.Count > 0)
            {
                treelist = BuildTree(list);
            }
            return treelist;

        }

        private void CreateTreeview(List<TreeViewItem> list, TreeViewItem current, ref List<TreeViewItem> returnList)
        {
            var childs = _valuestreamtemplateService.GetValueStreamsByTemplateID(current.Value).Result.Where(x => x.NodeID != 0);
            if (childs.Count() > 0)
            {
                var maxlength = childs.Max(x => x.NodeID);

                CreateChildren(childs.ToList(), maxlength, 1, current, ref returnList);
            }

        }


        private void CreateChildren(List<ValueStream> vsList, int maxlength, int minLength, TreeViewItem current, ref List<TreeViewItem> returnList)
        {

            var childs = vsList.Where(x => x.NodeID == minLength && x.Responsible_UserID != "" && x.Responsible_UserID != null && x.ValueStreamData != "" && x.ValueStreamData != null).ToList();
            childs = childs.GroupBy(x => x.ValueStreamData).Select(x => x.First()).ToList();
            current.Children = new List<TreeViewItem>();
            foreach (ValueStream vs in childs)
            {
                var tview = new TreeViewItem();
                tview.Value = vs.ValueStreamID;
                tview.Text = vs.ValueStreamData;
                tview.ValueStreamTemplateID = vs.ValueStreamTemplateID;
                current.Children.Add(tview);
            }
            foreach (var i in current.Children)
            {
                CreateSubChildren(vsList, maxlength, minLength + 1, null, i, ref returnList);
            }
        }

        private void CreateSubChildren(List<ValueStream> vsList, int maxlength, int minLength, List<int> rowLinked, TreeViewItem current, ref List<TreeViewItem> returnList)
        {
            var childs = vsList.Where(x => x.NodeID == minLength && x.Responsible_UserID != "" && x.Responsible_UserID != null && x.ValueStreamData != "" && x.ValueStreamData != null).ToList();
            if (rowLinked == null || rowLinked.Count() == 0)
            {
                rowLinked = vsList.Where(x => x.ValueStreamData == current.Text).Select(x => x.RowID).Distinct().ToList();
            }
            var linkedChilds = from vs in childs
                               where rowLinked.Contains(vs.RowID)
                               select vs;


            linkedChilds = linkedChilds.GroupBy(x => x.ValueStreamData).Select(x => x.First());
            current.Children = new List<TreeViewItem>();
            foreach (ValueStream vs in linkedChilds.ToList())
            {
                var tview = new TreeViewItem();
                tview.Value = vs.ValueStreamID;
                tview.Text = vs.ValueStreamData;
                tview.ValueStreamTemplateID = vs.ValueStreamTemplateID;
                current.Children.Add(tview);
            }
            foreach (var i in current.Children)
            {
                CreateSubChildren(vsList, maxlength, minLength + 1, rowLinked, i, ref returnList);
            }

        }


        public List<TreeViewItem> BuildTree(List<TreeViewItem> list)
        {
            List<TreeViewItem> returnList = new List<TreeViewItem>();
            var topLevels = list;
            returnList.AddRange(topLevels);
            foreach (var i in topLevels)
            {
                CreateTreeview(list, i, ref returnList);
            }
            return returnList;
        }

        [HttpPost]
        [Route("DeleteValueStreamTemplate")]
        public Task<Result> DeleteValueStreamTemplate(ValueStreamTemplate valueStreamTemplate)
        {
            var result = _valuestreamtemplateService.DeleteValueStreamTemplate(valueStreamTemplate);
            return result;
        }
        [HttpGet]
        [Route("ValueStreamProxiesByTemplateID/{valueStreamTemplateID}")]
        public Task<List<ValueStreamProxy>> ValueStreamProxiesByTemplateID(int valueStreamTemplateID)
        {
            var result = _valuestreamtemplateService.ValueStreamProxiesByTemplateID(valueStreamTemplateID);
            return result;
        }

        [Route("GetRecycleBinTemplates")]
        [HttpGet]
        public Task<List<RecycleBinTemplate>> GetRecycleBinTemplates()
        {
            var result = _valuestreamtemplateService.GetRecycleBinTemplates();
            return result;
        }

        
         [HttpGet]
        [Route("RecycleBinHistory")]
        public Task<List<RecycleBinTemplate>> RecycleBinHistory()
        {
            var result = _valuestreamtemplateService.RecycleBinHistory();
            return result;
        }
        [HttpPost]
        [Route("RestoreRecycleBin")]
        public Task<Result> RestoreRecycleBin([FromBody]List<RecycleBinTemplate> recycleTemplate)
        {
            var result = _valuestreamtemplateService.RestoreRecycleBin(recycleTemplate);
            return result;
        }
        [HttpPost]
        [Route("DeleteRecycleBin")]
        public Task<Result> DeleteRecycleBin([FromBody] List<RecycleBinTemplate> recycleTemplate)
        {
            var result = _valuestreamtemplateService.DeleteRecycleBin(recycleTemplate);
            return result;
        }

        [Route("GetValueStreamsByTemplateID/{templateID}")]
        public Task<List<ValueStream>> GetValueStreamsByTemplateID(int templateID)
        {
            var result = _valuestreamtemplateService.GetValueStreamsByTemplateID(templateID);
            return result;
        }

        [Route("ValueStreamByValueStreamID/{valueStreamID}")]
        public Task<List<ValueStream>> ValueStreamByValueStreamID(int valueStreamID)
        {
            var result = _valuestreamtemplateService.ValueStreamByValueStreamID(valueStreamID);
            return result;
        }

        [Route("FetchValueStreamTemplateByTemplateID/{valueStreamTemplateID}")]
        public Task<List<ValueStreamTemplate>> FetchValueStreamTemplateByTemplateID(int valueStreamTemplateID)
        {
            var result = _valuestreamtemplateService.FetchValueStreamTemplateByTemplateID(valueStreamTemplateID);
            return result;
        }
    }


}
