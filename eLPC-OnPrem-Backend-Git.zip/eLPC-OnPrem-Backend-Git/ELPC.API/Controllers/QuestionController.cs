﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ELPC.Core;
using ELPC.BAL.Interfaces;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Http;
using System;
using Microsoft.Extensions.Caching.Memory;

namespace ELPC.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [GlobalExceptionFilter]
    public class QuestionController : ControllerBase
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private Plant userPlantInfo;

        public readonly IQuestionService _questionService;
        public readonly IHostingEnvironment _hostingEnvironment;
        public readonly IConfiguration _iconfiguration;

        public QuestionController(IQuestionService questionService, IHostingEnvironment hostingEnvironment, IConfiguration iconfiguration)
        {
            _questionService = questionService;
            _hostingEnvironment = hostingEnvironment;
            _iconfiguration = iconfiguration;

            _httpContextAccessor = new HttpContextAccessor();
            var httpRequest = _httpContextAccessor.HttpContext.Request;
            userPlantInfo = Newtonsoft.Json.JsonConvert.DeserializeObject<Plant>(httpRequest.Headers["CurrentUserInfo"].ToString() ?? "");
        }

        [Route("GetQuestions")]
        public Task<List<Question>> GetQuestions()
        {

            var result = _questionService.GetQuestions();
            return result;
        }


        [Route("GetCustomQuestions")]
        public Task<List<Question>> GetCustomQuestions()
        {

            var result = _questionService.GetCustomQuestions();
            return result;
        }

        [Route("GetQuestionDetail")]
        public Task<List<QuestionDetail>> GetQuestionDetail()
        {

            var result = _questionService.GetQuestionDetail();
            return result;
        }

        [Route("GetQuestionDetailByID/{questionID}")]
        public Task<List<QuestionDetail>> GetQuestionDetailByID(int questionID)
        {
            var result = _questionService.GetQuestionDetailByID(questionID);
            return result;
        }

        [Route("GetQuestionHistory/{templateID}")]
        public Task<List<QuestionHistory>> GetQuestionsHistory(int templateID)
        {
            var result = _questionService.GetQuestionsHistory(templateID);
            return result;
        }

        [Route("QuestionRestoreByHistoryID/{historyID}")]
        public Task<Result> QuestionRestoreByHistoryID(int historyID)
        {
            var result = _questionService.QuestionRestoreByHistoryID(historyID);
            return result;
        }

        [Route("InsertQuestion")]
        public Task<Result> InsertQuestion([FromBody]Question question)
        {
            string folderName = "ElpcUploadQuestion";

            string webRootPath = new Utility.Utility().GetConfigValue("PathName", userPlantInfo.PlantCode);
            string newPath = Path.Combine(webRootPath, folderName);

            Common.HintImageUpload(newPath, question.HintImages);
            var result = _questionService.InsertQuestion(question);
            return result;
        }

        [Route("GetChoicesByQuestionID/{questionID}")]
        public async Task<List<Choice>> GetChoicesByQuestionID(int questionID)
        {

            var result = await _questionService.GetChoicesByQuestionID(questionID);
            return result;
        }

        //[Route("SingleLineTextByQuestionID/{questionID}")]
        //public Task<List<SingleLineText>> SingleLineTextByQuestionID(int questionID)
        //{

        //    var result = _questionService.SingleLineTextByQuestionID(questionID);
        //    return result;
        //}


        [HttpGet("SingleLineTextByQuestionID/{questionID}")]
        public async Task<ActionResult<List<SingleLineText>>> SingleLineTextByQuestionID(int questionID)
        {
            //var cache = HttpContext.RequestServices.GetService(typeof(IMemoryCache)) as IMemoryCache;
            //if (cache == null)
            //{
            //    // handle case where IMemoryCache service is not available
            //    return BadRequest("Memory cache service is not available.");
            //}

            //var cacheKey = $"SingleLineTextByQuestionID_{questionID}";

            //if (!cache.TryGetValue(cacheKey, out List<SingleLineText> cachedResult))
            //{
            //    var result = await _questionService.SingleLineTextByQuestionID(questionID);
            //    if (result != null)
            //    {
            //        // Cache the result for 10 minutes (adjust the TimeSpan as needed)
            //        cache.Set(cacheKey, result, TimeSpan.FromMinutes(10));
            //    }
            //    return result;
            //}

            //return cachedResult;
            var result = await _questionService.SingleLineTextByQuestionID(questionID);
            return result;
        }


        [Route("MultipleLinesTextByQuestionID/{questionID}")]
        public Task<List<MultipleLinesText>> MultipleLinesTextByQuestionID(int questionID)
        {

            var result = _questionService.MultipleLinesTextByQuestionID(questionID);
            return result;
        }

        [Route("CurrencySettingsByQuestionID/{questionID}")]
        public Task<List<AnswerTypeCurrency>> CurrencySettingsByQuestionID(int questionID)
        {

            var result = _questionService.CurrencySettingsByQuestionID(questionID);
            return result;
        }

        [Route("NumberSettingsByQuestionID/{questionID}")]
        public Task<List<AnswerTypeNumber>> NumberSettingsByQuestionID(int questionID)
        {

            var result = _questionService.NumberSettingsByQuestionID(questionID);
            return result;
        }

        [Route("DateTimeSettingsByQuestionID/{questionID}")]
        public Task<List<AnswerTypeDateTime>> DateTimeSettingsByQuestionID(int questionID)
        {

            var result = _questionService.DateTimeSettingsByQuestionID(questionID);
            return result;
        }

        [Route("HintImagesByQuestionID/{questionID}")]
        public Task<List<HintImage>> HintImagesByQuestionID(int questionID)
        {

            var result = _questionService.HintImagesByQuestionID(questionID);

            return result;
        }

        [Route("HintHyperLinksByQuestionID/{questionID}")]
        public Task<List<HintHyperLink>> HintHyperLinksByQuestionID(int questionID)
        {

            var result = _questionService.HintHyperLinksByQuestionID(questionID);
            return result;
        }

        [Route("RatingScaleByQuestionID/{questionID}")]
        public Task<List<RatingScale>> RatingScaleByQuestionID(int questionID)
        {

            var result = _questionService.RatingScaleByQuestionID(questionID);
            return result;
        }

        [Route("ValueStreamsByQuestionID/{questionID}")]
        public Task<List<ValueStream>> ValueStreamsByQuestionID(int questionID)
        {
            var result = _questionService.ValueStreamsByQuestionID(questionID);
            return result;
        }

        [Route("AssessorsByQuestionID/{questionID}")]
        public Task<List<Assessor>> AssessorsByQuestionID(int questionID)
        {
            var result = _questionService.AssessorsByQuestionID(questionID);
            return result;
        }

        [Route("TagsByQuestionID/{questionID}")]
        public Task<List<Tag>> TagsByQuestionID(int questionID)
        {
            var result = _questionService.TagsByQuestionID(questionID);
            return result;
        }

        [Route("DeleteQuestion")]
        public Task<Result> DeleteQuestion([FromBody]Question question)
        {
            var result = _questionService.DeleteQuestion(question);
            return result;
        }

        [Route("InsertQuestionProxy")]
        public Task<Result> InsertQuestionProxy(QuestionProxy questionProxy)
        {
            var result = _questionService.InsertQuestionProxy(questionProxy);
            return result;
        }

        [HttpGet]
        [Route("QuestionProxiesByQuestionID/{questionID}")]
        public Task<List<QuestionProxy>> QuestionProxiesByQuestionID(int questionID)
        {
            var result = _questionService.QuestionProxiesByQuestionID(questionID);
            return result;
        }

        [Route("FetchVSASListByID/{type}/{mode}/{questionID}/{tagId}")]
        public Task<List<VSASIDList>> FetchVSASListByID(string type, string mode, int questionId, int tagId)
        {
            var result = _questionService.FetchVSASListByID(type, mode, questionId, tagId);
            return result;
        }
    }
}