﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ELPC.Core;
using ELPC.BAL.Interfaces;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Http;

namespace ELPC.API.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    [GlobalExceptionFilter]
    public class MergeController : ControllerBase
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private Plant userPlantInfo;

        public readonly IMergeService _mergeService;
        public readonly IHostingEnvironment _hostingEnvironment;
        public readonly IConfiguration _iconfiguration;

        public MergeController(IMergeService mergeService, IHostingEnvironment hostingEnvironment, IConfiguration iconfiguration)
        {
            _mergeService = mergeService;
            _hostingEnvironment = hostingEnvironment;
            _iconfiguration = iconfiguration;

            _httpContextAccessor = new HttpContextAccessor();
            var httpRequest = _httpContextAccessor.HttpContext.Request;
            userPlantInfo = Newtonsoft.Json.JsonConvert.DeserializeObject<Plant>(httpRequest.Headers["CurrentUserInfo"].ToString() ?? "");
        }

        [Route("QuestionAssignment")]
        public Task<Result> MergeQuestionAssignment(Merge mergeQuestionAssignment)
        {
            var result = _mergeService.MergeQuestionAssignment(mergeQuestionAssignment);
            return result;
        }

        [Route("TagAssignment")]
        public Task<Result> MergeTagAssignment(Merge mergeTagAssignment)
        {
            var result = _mergeService.MergeTagAssignment(mergeTagAssignment);
            return result;
        }

        [Route("QuestionRemoval")]
        public Task<Result> MergeQuestioneRemoval(Merge mergeQuestionRemoval)
        {
            var result = _mergeService.MergeQuestionRemoval(mergeQuestionRemoval);
            return result;
        }

        [Route("TagRemoval")]
        public Task<Result> MergeTagRemoval(Merge mergeTagRemoval)
        {
            var result = _mergeService.MergeTagRemoval(mergeTagRemoval);
            return result;
        }

        [Route("InsertQuestionProxy")]
        public Task<Result> MergeQuestionProxy(MergeProxy questionProxy)
        {
            var result = _mergeService.MergeQuestionProxy(questionProxy);
            return result;
        }

        [Route("InsertTagProxy")]
        public Task<Result> MergeTagProxy(MergeProxy tagProxy)
        {
            var result = _mergeService.MergeTagProxy(tagProxy);
            return result;
        }




    }
}
