﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ELPC.Core;
using ELPC.BAL.Interfaces;

namespace ELPC.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [GlobalExceptionFilter]
    public class CustomModeController : ControllerBase
    {

        public readonly ICustomModeService _customModeService;
        public CustomModeController(ICustomModeService customModeService)
        {
            _customModeService = customModeService;
        }


        [Route("GetCustomModeByNTID/{NTID}")]
        [HttpGet]
        public Task<List<CustomMode>> GetCustomModeByNTID(string NTID)
        {

            var result = _customModeService.GetCustomModeByNTID(NTID);
            return result;

        }

        [Route("InsertCustomMode")]
        public Task<Result> InsertCustomMode(CustomMode customMode)
        {
            var result = _customModeService.InsertCustomMode(customMode);
            return result;
        }

        [Route("GetCustomTags")]
        public async Task<List<Tag>> GetCustomTags()
        {
            var result = await _customModeService.GetCustomTags();
            return result;
        }

        /*[Route("GetCustomQuestions")]
        public async Task<List<Tag>> GetCustomQuestions()
        {
            var result = await _customModeService.GetCustomQuestions();
            return result;
        }*/


        [HttpPost]
        [Route("RemoveFromCustomModeList")]
        public Task<Result> RemoveFromCustomModeList(CustomMode customMode)
        {
            var result = _customModeService.RemoveFromCustomModeList(customMode);
            return result;
        }

    }
}