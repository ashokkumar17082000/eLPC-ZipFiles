﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ELPC.Core;
using ELPC.BAL.Interfaces;
using ELPC.Utility;
using Microsoft.Extensions.Configuration;
using System.IO;
using Microsoft.AspNetCore.Hosting;

namespace ELPC.Common.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    
    public class CommonController : ControllerBase
    {

        public readonly ICommonService _commonService;

        public CommonController(ICommonService commonService)
        {
            _commonService = commonService;
        }

        [Route("SetDefaultPlant")]
        [HttpPost]
        public Task<Result> SetDefaultPlant([FromBody]User user)
        {
            var result = _commonService.SetDefaultPlant(user);
            return result;
        }

        [Route("GetConfigByPlantIDAndConfigType/{plantid}/{configtype}")]
        public Task<Result> GetConfigByPlantIDAndConfigType(int plantid, string configtype)
        {
            var result = _commonService.GetConfigByPlantIDAndConfigType(plantid, configtype);
            return result;
        }

        [Route("FetchUserAccessDetails/{ntid}/{plantid}")]
        
        public Task<UserDetails> FetchUserAccessDetails(string ntid, int plantid)
        {
            
             var ADController = new ActiveDirectoryController();
            var userDetails = ADController.GetUserListByNTID(ntid);
            var userObj = new User();
            if (userDetails != null && userDetails.Count > 0)
            {
                userObj = userDetails.FirstOrDefault();
                if (userObj != null && plantid > 0)
                {
                    userObj.PlantID = plantid;
                }
            }

            if (userObj != null && !string.IsNullOrEmpty(userObj.NTID))
            {
                var result = _commonService.FetchUserAccessDetails(userObj);
                return result;
            }
            else
            {
                UserDetails data = new UserDetails();
                return Task.Run(() =>
                {
                    return data;
                });
            }
        }
        [Route("SetUserAdditionalData")]
        [HttpPost]
        public Task<Result> SetUserAdditionalData([FromBody] UserAdditionalData userAdditionalData)
        {
            var result = _commonService.SetUserAdditionalData(userAdditionalData.AdditionalData, userAdditionalData.UserNTID);
            return result;
        }
    }

}