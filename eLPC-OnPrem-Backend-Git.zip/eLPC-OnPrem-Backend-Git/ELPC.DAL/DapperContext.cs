﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using ELPC.Core;
using Microsoft.AspNetCore.Http;

namespace ELPC.DAL
{
    public class DapperContext: IDisposable
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        public int CommandTimeoutSeconds = 600;
        private SqlConnection connection;
        public DapperContext()
        {
            _httpContextAccessor  = new HttpContextAccessor();
            var httpRequest = _httpContextAccessor.HttpContext.Request;
            userPlantID = Convert.ToInt32(httpRequest.Headers["Plant"].ToString());
            userNTID = httpRequest.Headers["iv-user"].ToString() ?? "";
            userPlantInfo = Newtonsoft.Json.JsonConvert.DeserializeObject<Plant>(httpRequest.Headers["CurrentUserInfo"].ToString());
            if (userPlantInfo != null && !string.IsNullOrEmpty(userPlantInfo.PlantCode))
            {
                ConnectionString = new Utility.Utility().GetConfigValue("ConnectionString", userPlantInfo?.PlantCode);
                ConnectionString  = ConnectionString.Trim(';') + "; Connection Timeout="+ CommandTimeoutSeconds.ToString();
            }
            Dapper.SqlMapper.Settings.CommandTimeout = CommandTimeoutSeconds;
        }

        public DapperContext(bool IsCommonConnectionString)
        {
            ConnectionString = new Utility.Utility().GetConfigValue("ConnectionString", null, false);
            commonShema = new Utility.Utility().GetConfigValue("CommonSchemaName", null, false);
        }

        public async Task<T> WithConnection<T>(Func<IDbConnection, Task<T>> getData)
        {
            try
            {
                using (connection = new SqlConnection(ConnectionString)) // GetConnectionString("DefaultConnection"))
                {
                    await connection.OpenAsync(); // Asynchronously open a connection to the database
                    
                    return await getData(connection); // Asynchronously execute getData, which has been passed in as a Func<IDBConnection, Task<T>>
                }
            }
            catch (TimeoutException ex)
            {
                throw new Exception(string.Format("{0}.WithConnection() experienced a SQL timeout", GetType().FullName), ex);
            }
            catch (SqlException ex)
            {
                throw new Exception(string.Format("{0}.WithConnection() experienced a SQL exception (not a timeout)", GetType().FullName), ex);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("{0}.WithConnection() experienced a Generic exception", GetType().FullName), ex);
            }
        }

        public void Dispose()
        {
            if (connection != null)
            {
                if (connection.State != ConnectionState.Closed)
                {
                    connection.Close();
                }
                connection.Dispose();
                connection = null;
            }
        }

        public Microsoft.Extensions.Configuration.IConfiguration Configuration { get; set; }
        public string ConnectionString { get; set; }
        public int userPlantID { get; set; }
        public string userNTID { get; set; }
        public Plant userPlantInfo { get; set; }
        public static string commonShema { get; set; }
    }


}
