﻿using Dapper;
using ELPC.Core;
using ELPC.DAL.Interfaces;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ELPC.DAL.Implementation
{
    public class QuestionRepository : DapperContext, IQuestionRepository
    {
        public async Task<List<Question>> GetQuestions()
        {
            try
            {


                return await WithConnection(async c =>
                {
                    var x = await c.QueryAsync<Question>(
                         "USP_FetchQuestion", new
                         {
                             @PlantID = userPlantID,
                             @CurrentUserNTID = userNTID
                         },
                        commandType: CommandType.StoredProcedure);
                    return x.ToList();

                });

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }


        public async Task<List<Question>> GetCustomQuestions()
        {
            try
            {


                return await WithConnection(async c =>
                {
                    var res = await c.QueryAsync<Question>(
                         "USP_FetchCustomQuestion", new
                         {
                             @PlantID = userPlantID,
                             @CurrentUserNTID = userNTID
                         },
                        commandType: CommandType.StoredProcedure);
                    res.GroupBy(x => x.QuestionID).Select(group => group.First());
                    Console.WriteLine(res);
                    return res.ToList();

                });

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }


        //***********************Question Details for Question Table********************

        public async Task<List<QuestionDetail>> GetQuestionDetail()
        {
            try
            {
                return await WithConnection(async c =>
                {
                    var questionBindingList = await c.QueryAsync<QuestionDetail>(sql: "USP_GetFullQuestionDetails",
                         new
                         {
                             @PlantID = userPlantID
                         },
                        commandType: System.Data.CommandType.StoredProcedure);
                    return questionBindingList.ToList();
                    //return GetQuestionDeatils(questionBindingList);
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }



        }
        //************************************************************************************

        public async Task<List<QuestionDetail>> GetQuestionDetailByID(int questionID)
        {

            try
            {
                return await WithConnection(async c =>
                {
                    var questionBindingList = await c.QueryAsync<QuestionDetail>(sql: "USP_GetFullQuestionDetailsByID",
                    new
                    {
                        @QuestionID = questionID,
                        @PlantID = userPlantID

                    },
                        commandType: System.Data.CommandType.StoredProcedure);


                    return GetQuestionDeatils(questionBindingList);
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private List<QuestionDetail> GetQuestionDeatils(IEnumerable<QuestionDetail> questionBindingList)
        {
            //List<KeyValuePair<string, string>> dict = new List<KeyValuePair<string, string>>();

            //string TagIDList = "";
            //string TagNameList = "";

            //foreach (var l in questionBindingList.ToList())
            //{
            //    TagIDList = l.TagIDList;
            //    TagNameList = l.TagNameList;

            //    if (!string.IsNullOrEmpty(TagIDList))
            //    {
            //        var items1 = TagIDList.Split(',');
            //        var items2 = TagNameList.Split(',');

            //        for (int i = 0; i < items1.Count(); i++)
            //        {
            //            KeyValuePair<string, string> myItem = new KeyValuePair<string, string>(items1[i].ToString(), items2[i].ToString());
            //            dict.Add(myItem);
            //        }
            //    }


            //}

            var finalList = new List<QuestionDetail>();
            var flist = questionBindingList.ToList();
            foreach (var process in flist)
            {

                var etList = new List<EditTagList>();
                if (!string.IsNullOrEmpty(process.TagIDList))
                {
                    var idList = process.TagIDList.Split(',');
                    var nameList = process.TagNameList.Split(',');
                    etList = nameList.Zip(idList).Select(r => new EditTagList { MyTagName = r.First, MyTagID = r.Second }).ToList();
                }
                process.EditTagList = etList;
                finalList.Add(process);
            }

            return finalList;
        }

        public async Task<List<QuestionHistory>> GetQuestionsHistory(int templateID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<QuestionHistory>(
                    "USP_QuestionHistory", new
                    {
                        @QuestionID = templateID,
                        @PlantID = userPlantID

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<Result> QuestionRestoreByHistoryID(int historyID)
        {
            Result data = new Result();
            try
            {
                return await WithConnection(async c =>
                {
                    var list = await c.QueryAsync<Question>(
                        "USP_Restore_T_TRN_QuestionHistory", new
                        {
                            @QuestionHistoryID = historyID,
                            @PlantID = userPlantID,
                            @CurrentUserNTID = userNTID,
                        },
                       commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        public async Task<Result> InsertQuestion(Question question)
        {
            Result data = new Result();
            try
            {
               if(question != null)
                {
                    question.DefaultChoiceID = question?.IsDefaultAnswerRequired == false ? 0 : question.DefaultChoiceID;
                    question.DefaultChoice = question?.IsDefaultAnswerRequired == false ? null : question.DefaultChoice;
     
                }
                var Choices = Utility.Utility.ObjectToXMLGeneric(question.Choices);
                var hintImages = Utility.Utility.ObjectToXMLGeneric(question.HintImages);
                var hintHyperLinks = Utility.Utility.ObjectToXMLGeneric(question.HintHyperLinks);
                var singleLineText = Utility.Utility.ObjectToXMLGeneric(question.singleLineText);
                var multipleLinesText = Utility.Utility.ObjectToXMLGeneric(question.multipleLinesText);
                var answerTypeNumber = Utility.Utility.ObjectToXMLGeneric(question.answerTypeNumber);
                var answerTypeCurrency = Utility.Utility.ObjectToXMLGeneric(question.answerTypeCurrency);
                var answerTypeDateTime = Utility.Utility.ObjectToXMLGeneric(question.answerTypeDateTime);
                var ratingScale = Utility.Utility.ObjectToXMLGeneric(question.ratingScale);
                var subQuestions = Utility.Utility.ObjectToXMLGeneric(question.subQuestions);
                var valueStreams = Utility.Utility.ObjectToXMLGeneric(question.valueStreams);
                var assessors = Utility.Utility.ObjectToXMLGeneric(question.assessors);
                var assignedTargetFrequencies = Utility.Utility.ObjectToXMLGeneric(question.assignedTargetFrequencies);
                var tags = Utility.Utility.ObjectToXMLGeneric(question.tags);

                return await (new DapperContext()).WithConnection(async c =>
                {
                    var result = await c.QueryAsync<Question>("USP_InsertQuestion", new
                    {
                        @QuestionText = question.QuestionText,
                        @QuestionHintText = question.QuestionHintText,
                        @AnswerType_AnswerTypeID = question.AnswerType_AnswerTypeID,
                        @ChoiceDisplayTypeID = question.ChoiceDisplayTypeID,
                        @IsFilledInChoiceAllowed = question.IsFilledInChoiceAllowed,
                        @IsUniqueAnswerRequired = question.IsUniqueAnswerRequired,
                        @IsAnswerRequired = question.IsAnswerRequired,
                        @IsDefaultAnswerRequired = question.IsDefaultAnswerRequired,
                        @DefaultChoiceID = question.DefaultChoiceID,
                        @IsQuestionAlwaysActive = question.IsQuestionAlwaysActive,
                        @ActiveDateRangeFrom = question.ActiveDateRangeFrom,
                        @ActiveDateRangeTo = question.ActiveDateRangeTo,
                        @IsTargetFrequencyDefined = question.IsTargetFrequencyDefined,
                        @TargetFrequencyTypeID = question.TargetFrequencyTypeID,
                        @TargetFrequencyValue = question.TargetFrequencyValue,
                        @Question_PriorityID = question.Question_PriorityID,
                        @IsLocked = question.IsLocked,
                        @CreatedAt = question.CreatedAt,
                        @CreatedBy_NTID = userNTID,
                        @ModifiedAt = question.ModifiedAt,
                        @ModifiedBy_NTID = userNTID,
                        //@Assigned_ValueStreamTemplateID = 0,
                        //@Assigned_ValueStreamCategoryID =0,
                        //@Assigned_AssessorTemplateID = 0,
                        @Assigned_AssessorID = question.Assigned_AssessorID,
                        @AssignedTargetFrequencies = question.assignedTargetFrequencies,
                        @IsDeleted = question.IsDeleted,
                        @HintImages = hintImages,
                        @HintHyperLinks = hintHyperLinks,
                        @SingleLineText = singleLineText,
                        @MultipleLinesText = multipleLinesText,
                        @Choices = Choices,
                        @SubQuestions = subQuestions,
                        @RatingScale = ratingScale,
                        @AnswerTypeNumber = answerTypeNumber,
                        @AnswerTypeCurrency = answerTypeCurrency,
                        @AnswerTypeDateTime = answerTypeDateTime,
                        @ValueStreams = valueStreams,
                        @Assessors = assessors,
                        @Tags = tags,
                        @QuestionID = question.QuestionID,
                        @DefaultChoice = question.DefaultChoice,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: CommandType.StoredProcedure);
                    //data.ResultCode = 0;
                    if (result.Count() > 0)
                    {
                        data.ResultCode = 0;
                        data.InsertedID = result.FirstOrDefault().QuestionID;
                    }
                    else
                    {
                        data.ResultCode = 9;
                    }
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        public async Task<Result> DeleteQuestion(Question question)
        {
            Result data = new Result();
            try
            {
                IDbConnection db = new SqlConnection(ConnectionString);
                var res = db.Query<int>("USP_ValidateLinkedQuestion", new
                {
                    @QuestionID = question.QuestionID,
                    @PlantID = userPlantID,

                }, commandType: CommandType.StoredProcedure).Count();

                if (res < 1)
                {
                    return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_DeleteQuestion", new
                    {
                        @QuestionID = question.QuestionID,
                        @ModifiedAt = question.ModifiedAt,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
                }
                else
                {
                    data.ResultCode = 1;
                    return data;
                }
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        /*
        public async Task<Result> UpdateQuestion(Question question)
        {
            Result data = new Result();
            try
            {
                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_UpdateQuestion", new
                    {
                        @QuestionID = question.QuestionID,
                        @QuestionName = question.QuestionText

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        public async Task<Result> UploadFile(byte[] file)
        {
            Result data = new Result();
            try
            {
                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_InsertHintImage", new
                    {
                        //@QuestionID = question.QuestionID,
                        @File = file

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }

        }*/


        public async Task<List<Choice>> GetChoicesByQuestionID(int questionID)
        {
            try
            {

                return await WithConnection(async c =>
                {
                    var list = await c.QueryAsync<Choice>(
                        "USP_ChoiceByQuestionID", new
                        {
                            @QuestionID = questionID,
                            @PlantID = userPlantID,

                        },
                       
                       commandType: CommandType.StoredProcedure, 
                       commandTimeout: CommandTimeoutSeconds);
                    return list.ToList();
                });

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        #region Not Used
        public async Task<List<SubQuestion>> SubQuestionsByQuestionID(int questionID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<SubQuestion>(
                    "USP_SubQuestionsByQuestionID", new
                    {
                        @QuestionID = questionID

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<List<RatingScale>> RatingScaleByQuestionID(int questionID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<RatingScale>(
                    "USP_RatingScaleByQuestionID", new
                    {
                        @QuestionID = questionID,
                        @PlantID = userPlantID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<List<AnswerTypeCurrency>> CurrencySettingsByQuestionID(int questionID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<AnswerTypeCurrency>(
                    "USP_CurrencySettingsByQuestionID", new
                    {
                        @QuestionID = questionID,
                        @PlantID = userPlantID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<List<AnswerTypeDateTime>> DateTimeSettingsByQuestionID(int questionID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<AnswerTypeDateTime>(
                    "USP_DateTimeSettingsByQuestionID", new
                    {
                        @QuestionID = questionID

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<List<AnswerTypeNumber>> NumberSettingsByQuestionID(int questionID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<AnswerTypeNumber>(
                    "USP_NumberSettingsByQuestionID", new
                    {
                        @QuestionID = questionID

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        #endregion

        //**********************single Line TExt***************
        public async Task<List<SingleLineText>> SingleLineTextByQuestionID(int questionID)
        {
            try
            {
                return await WithConnection(async c =>
                {
                    var list = await c.QueryAsync<SingleLineText>(
                        "USP_SingleLineTextByQuestionID", new
                        {
                            @QuestionID = questionID,
                            @PlantID = userPlantID,

                        },
                       commandType: CommandType.StoredProcedure);
                    return list.ToList();
                });

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<List<MultipleLinesText>> MultipleLinesTextByQuestionID(int questionID)
        {
            try
            {
                return await WithConnection(async c =>
                {
                    var list = await c.QueryAsync<MultipleLinesText>(
                        "USP_MultipleLinesTextByQuestionID", new
                        {
                            @QuestionID = questionID,
                            @PlantID = userPlantID,

                        },
                       commandType: CommandType.StoredProcedure);
                    return list.ToList();
                });
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<List<HintImage>> GetHintImagesByQuestionID(int questionID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<HintImage>(
                    "USP_HintImagesByQuestionID", new
                    {
                        @QuestionID = questionID,
                        @PlantID = userPlantID,

                    },
                   commandType: CommandType.StoredProcedure);
                foreach (HintImage image in list)
                {
                    image.FileContent = Convert.ToBase64String(image.ByteData);
                    image.FileContent = "data:image/png;base64," + image.FileContent;
                }
                return list.ToList();
            });
        }

        public async Task<List<HintHyperLink>> GetHintHyperLinksByQuestionID(int questionID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<HintHyperLink>(
                    "USP_HintHyperLinksByQuestionID", new
                    {
                        @QuestionID = questionID,
                        @PlantID = userPlantID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<List<Assessor>> AssessorsByQuestionID(int questionID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<Assessor>(
                    "USP_AssessorsByQuestionID", new
                    {
                        @QuestionID = questionID,
                        @PlantID = userPlantID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<List<ValueStream>> ValueStreamsByQuestionID(int questionID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<ValueStream>(
                    "USP_ValueStreamsByQuestionID", new
                    {
                        @QuestionID = questionID,
                        @PlantID = userPlantID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<List<Tag>> TagsByQuestionID(int questionID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<Tag>(
                    "USP_TagsByQuestionID", new
                    {
                        @QuestionID = questionID,
                        @PlantID = userPlantID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<Result> InsertQuestionProxy(QuestionProxy proxy)
        {
            Result data = new Result();

            try
            {
                var Proxies = Utility.Utility.ObjectToXMLGeneric(proxy.Proxies);

                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_AddEditQuestionProxy", new
                    {
                        @ID = proxy.ID,
                        @QuestionID = proxy.QuestionID,
                        @Proxies = Proxies,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        public async Task<List<QuestionProxy>> QuestionProxiesByQuestionID(int questionID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<QuestionProxy>(
                    "USP_FetchQuestionProxiesByID", new
                    {
                        @QuestionID = questionID,
                        @PlantID = userPlantID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<List<VSASIDList>> FetchVSASListByID(string type, string mode, int questionId, int tagId)
        {
            try
            {
                return await WithConnection(async c =>
                {
                    var result = await c.QueryAsync<VSASIDList>(
                       "USP_fetchVSASDetailsByID", new
                       {
                           @Type = type,
                           @Mode = mode,
                           @QuestionID = questionId,
                           @TagID = tagId
                       },
                    commandType: CommandType.StoredProcedure);
                    return result.ToList();
                });
            }
            catch (Exception ex)
            {
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return null;
            }
        }
    }
}
