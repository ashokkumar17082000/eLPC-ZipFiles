﻿using Dapper;
using ELPC.Core;
using ELPC.DAL.Interfaces;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Serilog;

namespace ELPC.DAL.Implementation
{
    public class TagRepository : DapperContext, ITagRepository
    {
        public async Task<List<Tag>> GetTags()
        {
            try
            {
                return await WithConnection(async c =>
                {

                    // Here's all the same data access code,
                    // albeit now it's async, and nicely wrapped
                    // in this handy WithConnection() call.
                    //USP_GetFullTagDetails
                    //USP_FetchTag

                    //USP_GetFullTagDetails
                    
                    var list = await c.QueryAsync<Tag>(
                         "USP_GetFullTagDetails", new
                         {
                             @PlantID = userPlantID,
                             @CurrentUserNTID = userNTID

                         },

                        commandType: CommandType.StoredProcedure);


                    return list.ToList();

                });

            }
            catch (Exception ex)
            {

                throw ex;
            }
       
        }


        public async Task<List<Tag>> GetTagsByID(int tagID)
        {
            try
            {
                return await WithConnection(async c =>
                {
                    var list = await c.QueryAsync<Tag>(
                         "USP_GetFullTagDetailsByID", new
                         {
                             @TagID = tagID,
                             @PlantID = userPlantID,

                         },
                        commandType: CommandType.StoredProcedure);
                    return list.ToList();
                });

            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        public async Task<List<TagHistory>> GetTagHistory(int templateID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<TagHistory>(
                    "USP_TagTemplateHistory", new
                    {
                        @TagID = templateID,
                        @PlantID = userPlantID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<Result> TagRestoreByTemplateHistoryID(int historyID)
        {
            Result data = new Result();
            try
            {
                return await WithConnection(async c =>
                {
                    var list = await c.QueryAsync<ValueStream>(
                        "USP_Restore_T_TRN_TagHistory", new
                        {
                            @TagHistoryID = historyID,
                            @PlantID = userPlantID,
                            @CurrentUserNTID = userNTID,

                        },
                       commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        public async Task<Result> InsertTag(Tag tag)
        {
            Result data = new Result();

            try
            {
                var x = Utility.Utility.ObjectToXMLGeneric(tag.tags);
                var y = Utility.Utility.ObjectToXMLGeneric(tag.questions);
                var z = Utility.Utility.ObjectToXMLGeneric(tag.RandomQuestionsOnly);
                var finalOrder= Utility.Utility.ObjectToXMLGeneric(tag.FinalQuestionOrder);
                var assessors = Utility.Utility.ObjectToXMLGeneric(tag.assessors);
                var valueStreams = Utility.Utility.ObjectToXMLGeneric(tag.valueStreams);
                //Console.WriteLine(tag.isSaveTag);
                // Console.WriteLine(tag.FinalQuestionOrder.Capacity);
                tag.IsSearchableTag = tag.IsSearchableTag == null ? true : tag.IsSearchableTag;
                tag.IsSkipQuestionDefined = tag.IsSkipQuestionDefined == null ? true : tag.IsSkipQuestionDefined;
                tag.IsQuestionOverviewDefined = tag.IsQuestionOverviewDefined == null ? true : tag.IsQuestionOverviewDefined;
                tag.IsProgressPercentageDefined = tag.IsProgressPercentageDefined == null ? true : tag.IsProgressPercentageDefined;
                tag.IsResultOverviewDefined = tag.IsResultOverviewDefined == null ? true : tag.IsResultOverviewDefined;
                tag.IsResumeTagDefined = tag.IsResumeTagDefined == null ? true : tag.IsResumeTagDefined;
                tag.IsReportingEmailDefined = tag.IsReportingEmailDefined == null ? true : tag.IsReportingEmailDefined;

                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync<Tag>("USP_AddEditTag", new
                    {
                        @TagID = tag.TagID,
                        @TagName = tag.TagName,
                        @IsSingleQuestionSuppressed = tag.IsSingleQuestionSuppressed,
                        @SuppressedDateRangeFrom = tag.SuppressedDateRangeFrom,
                        @SuppressedDateRangeTo = tag.SuppressedDateRangeTo,
                        @IsTargetFrequencyDefined = tag.IsTargetFrequencyDefined,
                        @TargetFrequencyTypeID = tag.TargetFrequencyTypeID,
                        @TargetFrequencyValue = tag.TargetFrequencyValue,
                        @Tag_PriorityID = tag.Tag_PriorityID,
                        @TagTypeID = tag.TagTypeID,
                        @IsLocked = tag.IsLocked,
                        @AnonymizeUserDataSettingID = tag.AnonymizeUserDataSettingID,
                        @IsBranchLogicToBeFollowed = tag.IsBranchLogicToBeFollowed,
                        @IsMandatoryAssessorsDefined = tag.IsMandatoryAssessorsDefined,
                        @IsDeleted = tag.IsDeleted,
                        @ModifiedAt = tag.ModifiedAt,
                        @CreatedAt = tag.CreatedAt,
                        @AssignedTags = x,
                        @AssignedQuestions = y,
                        @AddedRandomQuestions = z,
                        @FinalQuestionOrder=finalOrder,
                        @isSaveTag = tag.isSaveTag,
                        //@Assigned_ValueStreamTemplateID = tag.Assigned_ValueStreamTemplateID,
                        //@Assigned_ValueStreamCategoryID = tag.Assigned_ValueStreamCategoryID,
                        //@Assigned_AssessorTemplateID = tag.Assigned_AssessorTemplateID,
                        @ValueStreams = valueStreams,
                        @Assessors = assessors,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,
                        @IsSearchableTag = tag.IsSearchableTag == null ? true : tag.IsSearchableTag,
                        @IsSkipQuestionDefined = tag.IsSkipQuestionDefined == null ? true : tag.IsSkipQuestionDefined,
                        @IsQuestionOverviewDefined = tag.IsQuestionOverviewDefined == null ? true : tag.IsQuestionOverviewDefined,
                        @IsProgressPercentageDefined = tag.IsProgressPercentageDefined == null ? true : tag.IsProgressPercentageDefined,
                        @IsResultOverviewDefined = tag.IsResultOverviewDefined == null ? true : tag.IsResultOverviewDefined,
                        @IsResumeTagDefined = tag.IsResumeTagDefined == null ? true : tag.IsResumeTagDefined,
                        @IsReportingEmailDefined = tag.IsReportingEmailDefined == null ? true : tag.IsReportingEmailDefined,
                        @isInlineModeOn = tag.IsInlineModeOn != null ? tag.IsInlineModeOn : false,
                        @inLineCount = tag.InlineCount != 0 ? tag.InlineCount : 0

                    },
                    commandType: CommandType.StoredProcedure);
                    //data.ResultCode = 0;
                    if (result.Count() > 0)
                    {
                        data.ResultCode = 0;
                        data.InsertedID = result.FirstOrDefault().TagID;
                    }
                    else
                    {
                        data.ResultCode = 9;
                    }
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }





        public async Task<Result> DeleteTag(Tag tag)
        {
            Result data = new Result();
            try
            {
                IDbConnection db = new SqlConnection(ConnectionString);
                var res = db.Query<int>("USP_ValidateLinkedTag", 
                    new
                    {
                        @TagID = tag.TagID,
                        @PlantID = userPlantID,

                    },
                    commandType: CommandType.StoredProcedure).Count();

                if (res < 1)
                {
                    return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_DeleteTag", new
                    {
                        @TagID = tag.TagID,
                        @ModifiedAt = tag.ModifiedAt,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
                }
                else
                {
                    data.ResultCode = 1;
                    return data;
                }
           
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        public async Task<List<Question>> GetQuestionsByTagID(int tagID)
        {
            try
            {
                return await WithConnection(async c =>
                {
                var list = await c.QueryAsync<Question>(
                    "USP_QuestionsByTagID", new
                    {
                        @TagID = tagID,
                        @PlantID = userPlantID,

                    },
                   commandType: CommandType.StoredProcedure);
                Console.WriteLine(list);
                list = list.Where(item => item.RandomQuestionOrder != 999);
                list.GroupBy(x => x.QuestionID).Select(group => group.First()).Distinct().ToList();
                Console.WriteLine(list);
                      
                //list= list.Select(group => group.QuestionID).Distinct().ToList();

                    return list.ToList();
                });
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<List<Tag>> GetTagsByTagID(int tagID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<Tag>(
                    "USP_TagsByTagID", new
                    {
                        @TagID = tagID,
                        @PlantID = userPlantID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<List<Assessor>> GetAssessorsByTagIDs(string tagIDs)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<Assessor>(
                    "USP_FetchAssessorByTagIDs", new
                    {
                        @TagIDs = tagIDs

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<List<Question>> FetchQuestionsByAssessorsAndValuestreams(string assessorIDs, string valueStreamIDs)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<Question>(
                    "USP_FetchQuestionsByAssessorsAndValuestreams", new
                    {
                        @AssessorIDs = assessorIDs,
                        @ValueStreamIDs = valueStreamIDs,
                        @PlantID = userPlantID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<List<Tag>> FetchTagsByAssessorsAndValuestreams(string assessorIDs, string valueStreamIDs)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<Tag>(
                    "USP_FetchTagsByAssessorsAndValuestreams", new
                    {
                        @AssessorIDs = assessorIDs,
                        @ValueStreamIDs = valueStreamIDs,
                        @PlantID = userPlantID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<Result> InsertTagProxy(TagProxy proxy)
        {
            Result data = new Result();

            try
            {
                var x = Utility.Utility.ObjectToXMLGeneric(proxy.Proxies);

                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_AddEditTagProxy", new
                    {
                        @ID = proxy.ID,
                        @TagID = proxy.TagID,
                        @Proxies = x,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        public async Task<List<Assessor>> AssessorsByTagID(int tagID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<Assessor>(
                    "USP_AssessorsByTagID", new
                    {
                        @TagID = tagID,
                        @PlantID = userPlantID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }
        public async Task<List<ValueStream>> ValueStreamsByTagID(int tagID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<ValueStream>(
                    "USP_ValueStreamsByTagID", new
                    {
                        @TagID = tagID,
                        @PlantID = userPlantID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }


        public async Task<List<TagProxy>> TagProxiesByTagID(int tagID)
        {
            try
            {

                return await WithConnection(async c =>
                {
                    var list = await c.QueryAsync<TagProxy>(
                        "USP_FetchTagProxiesByTagID", new
                        {
                            @TagID = tagID,
                            @PlantID = userPlantID,

                        }, commandTimeout: CommandTimeoutSeconds,
                       commandType: CommandType.StoredProcedure);
                    return list.ToList();
                });

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        /// <summary>
        /// To fetch the list of process confirmation tags (to display by default in Questions module)
        /// </summary>
        /// <returns></returns>

        public async Task<List<Tag>> FetchProcessConfirmationTags()
        {
            return await WithConnection(async c =>
            {

                 var list = await c.QueryAsync<Tag>(
                     "USP_FetchProcessConfirmationTags", new
                     {
                         @PlantID = userPlantID,
                         @CurrentUserNTID = userNTID

                     },

                    commandType: CommandType.StoredProcedure);


                return list.ToList();

            });
        }

        public async Task<List<Tag>> FetchTagDetailsByTagID(int tagID)
        {
            try
            {
                return await WithConnection(async c =>
                {
                    var list = await c.QueryAsync<Tag>(
                        "USP_FetchTagDetailsByTagID", new
                        {
                            @TagID = tagID,
                            @PlantID = userPlantID,

                        }, commandTimeout: CommandTimeoutSeconds,
                       commandType: CommandType.StoredProcedure);
                    return list.ToList();
                });
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<Result> UpdateAuditByTagID(int tagID)
        {

            Result data = new Result();
            try
            {
                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_UpdateAuditQuestionsAndValueStreamsByTagID", new
                    {
                        @TagID = tagID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

    }
}
