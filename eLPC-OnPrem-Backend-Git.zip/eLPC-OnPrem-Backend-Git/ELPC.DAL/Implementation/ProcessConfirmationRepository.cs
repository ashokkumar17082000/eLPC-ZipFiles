﻿using Dapper;
using ELPC.Core;
using ELPC.DAL.Interfaces;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;

using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ELPC.DAL.Implementation
{
  public  class ProcessConfirmationRepository: DapperContext, IProcessConfirmationRepository
    {
        public async Task<List<ProcessConfirmation>> GetProcessConfirmation(ProcessConfirmation processConfirmation)
        {
            Result data = new Result();
            try
            {
                string xmlAnsweredAndSkippedQuestionID = Utility.Utility.ObjectToXMLGeneric(processConfirmation.AnsweredAndSkippedQuestionID);

                if (processConfirmation.ModeType == "shuffle" && processConfirmation.TagID == 0)
                {
                    var Mylist = await WithConnection(async c =>
                     {
                         var questionBindingList = await c.QueryMultipleAsync("USP_BindQuestionAndAnswerType", new
                         {
                             @ValueStreamID = processConfirmation.ValueStreamID,
                             @AssessorID = processConfirmation.AssessorID,
                             @NTID = userNTID,
                             @PlantID = userPlantID,
                             @CurrentUserNTID = userNTID,
                             @SelectedQuestionID = processConfirmation.QuestionID,
                             @AnsweredAndSkippedQueestionIDs = xmlAnsweredAndSkippedQuestionID,
                             @SessionID = processConfirmation.SessionID,
                         },  commandTimeout: CommandTimeoutSeconds,
                             commandType: System.Data.CommandType.StoredProcedure);

                         return questionBindingList.Read<ProcessConfirmation>().ToList();
                     });
                    return Mylist;

                }
                if (processConfirmation.ModeType == "custom" && processConfirmation.TagID == 0)
                {
                    try
                    {

                  
                    var Mylist = await WithConnection(async c =>
                    {

                        var questionBindingList = await c.QueryMultipleAsync("USP_Custom_BindQuestionAndAnswerType", new
                        {
                            @ValueStreamID = processConfirmation.ValueStreamID,
                            @AssessorID = processConfirmation.AssessorID,
                            @NTID = userNTID,
                            @PlantID = userPlantID,
                            @CurrentUserNTID = userNTID,
                            @SelectedQuestionID = processConfirmation.QuestionID,
                            @AnsweredAndSkippedQueestionIDs = xmlAnsweredAndSkippedQuestionID,
                            @SessionID = processConfirmation.SessionID,
                            @ResumeTag = processConfirmation.ResumeTagProcessConfirmation,
                        },
                            commandTimeout: CommandTimeoutSeconds,
                            commandType: System.Data.CommandType.StoredProcedure);
                        return questionBindingList.Read<ProcessConfirmation>().ToList();

                    });
                    return Mylist;
                    }
                    catch (Exception ex)
                    {

                        throw ex;
                    }
                }
                if (processConfirmation.TagID != 0 )
                {

                    var Mylist = await WithConnection(async c =>
                    {

                        var questionBindingList = await c.QueryMultipleAsync("USP_ProcessConfirmationByTagID", new
                        {
                            @PCTagID = processConfirmation.TagID,
                            @PlantID = userPlantID,
                        },
                            commandTimeout: CommandTimeoutSeconds,
                            commandType: System.Data.CommandType.StoredProcedure);
                        return questionBindingList.Read<ProcessConfirmation>().ToList();

                    });
                    return Mylist;
                }

                if (processConfirmation.ModeType == "calendarTag")
                {
                    return await WithConnection(async c =>
                    {
                        var questionBindingList = await c.QueryMultipleAsync("USP_Tag_BindQuestionAndAnswerTypeByVS", new
                        {
                            @AuditID = processConfirmation.ValueStreamID,
                            @AssessorID = processConfirmation.AssessorID,
                            @PlantID = userPlantID,
                            @CurrentUserNTID = userNTID,
                            @SelectedQuestionID = processConfirmation.QuestionID,
                            @AnsweredAndSkippedQueestionIDs = xmlAnsweredAndSkippedQuestionID,
                            @SessionID = processConfirmation.SessionID,
                            @ResumeTag = processConfirmation.ResumeTagProcessConfirmation,
                        },  commandTimeout: CommandTimeoutSeconds,
                            commandType: System.Data.CommandType.StoredProcedure);
                        return questionBindingList.Read<ProcessConfirmation>().ToList();
                    });
                }
                else
                {
                    return await WithConnection(async c =>
                    {
                        var questionBindingList = await c.QueryMultipleAsync("USP_Tag_BindQuestionAndAnswerType", new
                        {
                            @ValueStreamID = processConfirmation.ValueStreamID,
                            @AssessorID = processConfirmation.AssessorID,
                            @NTID = userNTID,
                            @PlantID = userPlantID,
                            @CurrentUserNTID = userNTID,
                            @SelectedQuestionID = processConfirmation.QuestionID,
                            @AnsweredAndSkippedQueestionIDs = xmlAnsweredAndSkippedQuestionID,
                            @SessionID = processConfirmation.SessionID,
                            @ResumeTag = processConfirmation.ResumeTagProcessConfirmation

                        }, commandTimeout: CommandTimeoutSeconds,
                            commandType: System.Data.CommandType.StoredProcedure);
                        return questionBindingList.Read<ProcessConfirmation>().ToList();
                    });
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public int pendingTagModeStatus(ProcessConfirmation processConfirmation)
        {
            int data = 0;
            int TagID = processConfirmation.TagID;
            int TagModeID = processConfirmation.TagModeID;// processConfirmation.TagModeID;
            int Plantid = processConfirmation.PlantID;// processConfirmation.PlantID;
            int CustomModeId = processConfirmation.CustomModeID;
            string currUserntid = processConfirmation.AnsweredBy_NTID;
             int TagAssignedQuestionCount = 0;
            int TagAnsweredQuestionCount = 0;
            int CustomAssignedQuestionCount = 0;
            int CustomAnsweredQuestionCount = 0;
            int IsDeleted = 1;
            //string selectQuery = @"SELECT *FROM [T_LNK_Audit_AnsweredQuestions] where TagModeID =@TagModeID AND PlantID=@Plantid";
            if (processConfirmation.TagModeID != 0)
            {
                using (IDbConnection db = new System.Data.SqlClient.SqlConnection(new DapperContext().ConnectionString))
                {
                    string selectQueryTagAssignQuestions = @"SELECT COUNT(*) FROM [T_LNK_TagMode_Questions] where TagModeID =@TagModeID";
                    TagAssignedQuestionCount = (int)db.QueryFirstOrDefault<int?>(selectQueryTagAssignQuestions, new
                    {
                        TagModeID,
                        Plantid

                    });

                    string selectQueryTagAnsweredQuestions = @"SELECT COUNT(*) FROM [T_LNK_Tag_AnsweredQuestions] where TagID=@TagID AND TagModeID =@TagModeID AND PlantID=@Plantid AND ModifiedBy_NTID=@currUserntid and isdeleted=0";
                    TagAnsweredQuestionCount = (int)db.QueryFirstOrDefault<int?>(selectQueryTagAnsweredQuestions, new
                    {
                        TagModeID,
                        Plantid,
                        currUserntid,
                        TagID
                    });
                    //to ahandle the resume inline popoup 
                    if (processConfirmation != null && processConfirmation.isResumeActivated == false)
                    {
                        // delete the already answered question in resume mode
                        string updateQuery = @"UPDATE  [T_LNK_Tag_AnsweredQuestions] SET answer = null , choiceid=0, DeviationDescription=null where IsDeleted=1 and  TagModeID =@TagModeID and TagID=@TagID AND PlantID=@Plantid AND ModifiedBy_NTID=@currUserntid ";

                        var result = db.Execute(updateQuery, new
                        {
                            IsDeleted,
                            TagID,
                            TagModeID,
                            Plantid,
                            currUserntid
                        });
                    }

                    string updateQuery1 = @"UPDATE  [T_LNK_Tag_AnsweredQuestions] SET IsDeleted=1 where TagModeID =@TagModeID and TagID=@TagID AND PlantID=@Plantid AND ModifiedBy_NTID=@currUserntid ";

                    var result1 = db.Execute(updateQuery1, new
                    {
                        TagID,
                        TagModeID,
                        Plantid,
                        currUserntid
                    });
                }
                if (TagAnsweredQuestionCount ==0)
                {
                    data = 0;
                }else
                {
                    data = TagAssignedQuestionCount - TagAnsweredQuestionCount;
                }
                
            } if(processConfirmation.CustomModeID != 0)
            {
                using (IDbConnection db = new System.Data.SqlClient.SqlConnection(new DapperContext().ConnectionString))
                {
                    string selectQueryCustomAssignQuestions = @"SELECT COUNT(distinct QuestionID) FROM [T_LNK_Custom_Questions] where CustomModeID =@CustomModeId ";
                    CustomAssignedQuestionCount = (int)db.QueryFirstOrDefault<int?>(selectQueryCustomAssignQuestions, new
                    {
                        CustomModeId,
                        Plantid

                    });

                    string selectQueryCustomAnsweredQuestions = @"SELECT COUNT(*) FROM [T_LNK_Custom_AnsweredQuestions] where CustomModeID =@CustomModeId AND PlantID=@Plantid AND ModifiedBy_NTID=@currUserntid and isdeleted=0";
                    CustomAnsweredQuestionCount = (int)db.QueryFirstOrDefault<int?>(selectQueryCustomAnsweredQuestions, new
                    {
                        CustomModeId,
                        Plantid,
                        currUserntid,
                        TagID
                    });

                    string updateQuery = @"UPDATE  [T_LNK_Custom_AnsweredQuestions] SET IsDeleted=1 where CustomModeID =@CustomModeId AND PlantID=@Plantid AND ModifiedBy_NTID=@currUserntid ";

                    var result = db.Execute(updateQuery, new
                    {
                        CustomModeId,
                        Plantid,
                        currUserntid
                    });
                }
                if(CustomAnsweredQuestionCount == 0)
                {
                    data = 0;
                }else
                {
                    data = CustomAssignedQuestionCount - CustomAnsweredQuestionCount;

                }

            }

           

            return data;
        }

        public async Task<Result> InsertProcessConfirmation1(ProcessConfirmation processConfirmation)
        {
            Result data = new Result();

            #region original Code
            try
            {
                var hintImages = Utility.Utility.ObjectToXMLGeneric(processConfirmation.HintImages);
                var tagname = Utility.Utility.ObjectToXMLGeneric(processConfirmation.selectedTagData);
                var addemp = Utility.Utility.ObjectToXMLGeneric(processConfirmation.AdditionalEmployee);
                if (processConfirmation.ModeTypeID == 3)
                {
                    // Answer type SIngletext, MutliText and Deviation with out description
                    if (processConfirmation.DeviationID == 0 && processConfirmation.DeviationDescription == "" || processConfirmation.DeviationDescription == null)// insert while answering single line , multi line
                    {
                        return await (new DapperContext()).WithConnection(async c =>
                        {

                            var result = await c.QueryAsync<Deviation>("USP_Insertprocessconfirmation_TagMode_NormalAnswer", new
                            {
                                //@TimeStamp = processConfirmation.TimeStamp,
                                @ModeTypeID = processConfirmation.ModeTypeID,
                                @ValueStreamID = processConfirmation.ValueStreamID,
                                @AssessorID = processConfirmation.AssessorID,
                                @QuestionID = processConfirmation.QuestionID,
                                @Answer = processConfirmation.Answer,
                                @AnswerType_AnswerTypeID = processConfirmation.AnswerType_AnswerTypeID,
                                @AdditionalEmployee = addemp,
                                @TagName = tagname,
                                //@AnsweredBy = processConfirmation.AnsweredBy,
                                @TagmodeID = processConfirmation.TagModeID,
                                @CustomModeID = processConfirmation.CustomModeID,
                                @AnsweredBy_NTID = processConfirmation.AnsweredBy_NTID,
                                @CreatedAt = processConfirmation.CreatedAt,

                                //@ModifiedBy=processConfirmation.ModifiedBy,

                                @ModifiedAt = processConfirmation.ModifiedAt,
                                @TagId = processConfirmation.TagID,
                                @IsDeviation = processConfirmation.isDeviation,
                                @ObtainedSCore = processConfirmation.ObtainedScore,
                                @DeviationDescription = processConfirmation.DeviationDescription,
                                @ResponsibleEmployee = processConfirmation.ResponsibleEmployee,
                                //@ModifiedBy_NTID= processConfirmation.AnsweredBy_NTID
                                @HintImages = hintImages,
                                @ChoiceID = processConfirmation.ChoiceID,
                                @IsSHowVsAs = processConfirmation.IsShowVsAs,
                                @SessionID = processConfirmation.SessionID,
                                @PlantID = userPlantID,
                                @IsDeleted = processConfirmation.IsDeleted,
                                @CurrentUserNTID = userNTID,

                            }, commandTimeout: CommandTimeoutSeconds,
                            commandType: CommandType.StoredProcedure);
                            //var p = new DynamicParameters();
                            //p.Add("id", dbType: DbType.Int32, direction: ParameterDirection.Output);
                            data.ResultCode = 0;
                            data.InsertedID = result.FirstOrDefault().DeviationId;
                            return data;
                        });
                    }
                    // Deviation with Image and with out Additional settings
                    else if (processConfirmation.DeviationDescription != null && processConfirmation.HintImages.Count > 0 && processConfirmation.selectedTagData.Count == 0 && processConfirmation.AdditionalEmployee.Count == 0)
                    {
                        Console.WriteLine("Ashok New Insert  Deviation with Image and with out Additional settings");
                        return await (new DapperContext()).WithConnection(async c =>
                        {

                            var result = await c.QueryAsync<Deviation>("USP_Insertprocessconfirmation_TagMode_onlydeviation_withImage_withoutadditionalsettings", new
                            {
                                //@TimeStamp = processConfirmation.TimeStamp,
                                @ModeTypeID = processConfirmation.ModeTypeID,
                                @ValueStreamID = processConfirmation.ValueStreamID,
                                @AssessorID = processConfirmation.AssessorID,
                                @QuestionID = processConfirmation.QuestionID,
                                @Answer = processConfirmation.Answer,
                                @AnswerType_AnswerTypeID = processConfirmation.AnswerType_AnswerTypeID,
                                @AdditionalEmployee = addemp,
                                @TagName = tagname,
                                //@AnsweredBy = processConfirmation.AnsweredBy,
                                @TagmodeID = processConfirmation.TagModeID,
                                @CustomModeID = processConfirmation.CustomModeID,
                                @AnsweredBy_NTID = processConfirmation.AnsweredBy_NTID,
                                @CreatedAt = processConfirmation.CreatedAt,

                                //@ModifiedBy=processConfirmation.ModifiedBy,

                                @ModifiedAt = processConfirmation.ModifiedAt,
                                @TagId = processConfirmation.TagID,
                                @IsDeviation = processConfirmation.isDeviation,
                                @ObtainedSCore = processConfirmation.ObtainedScore,
                                @DeviationDescription = processConfirmation.DeviationDescription,
                                @ResponsibleEmployee = processConfirmation.ResponsibleEmployee,
                                //@ModifiedBy_NTID= processConfirmation.AnsweredBy_NTID
                                @HintImages = hintImages,
                                @ChoiceID = processConfirmation.ChoiceID,
                                @IsSHowVsAs = processConfirmation.IsShowVsAs,
                                @SessionID = processConfirmation.SessionID,
                                @PlantID = userPlantID,
                                @IsDeleted = processConfirmation.IsDeleted,
                                @CurrentUserNTID = userNTID,

                            }, commandTimeout: CommandTimeoutSeconds,
                            commandType: CommandType.StoredProcedure);
                            //var p = new DynamicParameters();
                            //p.Add("id", dbType: DbType.Int32, direction: ParameterDirection.Output);
                            data.ResultCode = 0;
                            data.InsertedID = result.FirstOrDefault().DeviationId;
                            return data;
                        });
                    }
                    // Deviation without Image and without Additional settings
                    else if (processConfirmation.DeviationDescription != null && processConfirmation.HintImages.Count == 0 && processConfirmation.selectedTagData.Count == 0 && processConfirmation.AdditionalEmployee.Count == 0)
                    {
                        Console.WriteLine("Ashok New Insert Deviation with outImage and with out Additional settings");
                        return await (new DapperContext()).WithConnection(async c =>
                        {

                            var result = await c.QueryAsync<Deviation>("USP_Insertprocessconfirmation_TagMode_onlydeviation_withoutImage_withoutadditionalsettings", new
                            {
                                //@TimeStamp = processConfirmation.TimeStamp,
                                @ModeTypeID = processConfirmation.ModeTypeID,
                                @ValueStreamID = processConfirmation.ValueStreamID,
                                @AssessorID = processConfirmation.AssessorID,
                                @QuestionID = processConfirmation.QuestionID,
                                @Answer = processConfirmation.Answer,
                                @AnswerType_AnswerTypeID = processConfirmation.AnswerType_AnswerTypeID,
                                @AdditionalEmployee = addemp,
                                @TagName = tagname,
                                //@AnsweredBy = processConfirmation.AnsweredBy,
                                @TagmodeID = processConfirmation.TagModeID,
                                @CustomModeID = processConfirmation.CustomModeID,
                                @AnsweredBy_NTID = processConfirmation.AnsweredBy_NTID,
                                @CreatedAt = processConfirmation.CreatedAt,

                                //@ModifiedBy=processConfirmation.ModifiedBy,

                                @ModifiedAt = processConfirmation.ModifiedAt,
                                @TagId = processConfirmation.TagID,
                                @IsDeviation = processConfirmation.isDeviation,
                                @ObtainedSCore = processConfirmation.ObtainedScore,
                                @DeviationDescription = processConfirmation.DeviationDescription,
                                @ResponsibleEmployee = processConfirmation.ResponsibleEmployee,
                                //@ModifiedBy_NTID= processConfirmation.AnsweredBy_NTID
                                @HintImages = hintImages,
                                @ChoiceID = processConfirmation.ChoiceID,
                                @IsSHowVsAs = processConfirmation.IsShowVsAs,
                                @SessionID = processConfirmation.SessionID,
                                @PlantID = userPlantID,
                                @IsDeleted = processConfirmation.IsDeleted,
                                @CurrentUserNTID = userNTID,

                            }, commandTimeout: CommandTimeoutSeconds,
                            commandType: CommandType.StoredProcedure);
                            //var p = new DynamicParameters();
                            //p.Add("id", dbType: DbType.Int32, direction: ParameterDirection.Output);
                            data.ResultCode = 0;
                            data.InsertedID = result.FirstOrDefault().DeviationId;
                            return data;
                        });
                    }
                    //Deviation With Pic Additional settings and deviation
                    else if (processConfirmation.DeviationDescription != null && processConfirmation.HintImages.Count > 0)
                    {

                        Console.WriteLine("Ashok New Insert DeviationWithPicAdditionalsettingsanddeviation");
                        return await (new DapperContext()).WithConnection(async c =>
                        {

                            var result = await c.QueryAsync<Deviation>("USP_Insertprocessconfimration_TagMode_DeviationWithPicAdditionalsettings", new
                            {
                                //@TimeStamp = processConfirmation.TimeStamp,
                                @ModeTypeID = processConfirmation.ModeTypeID,
                                @ValueStreamID = processConfirmation.ValueStreamID,
                                @AssessorID = processConfirmation.AssessorID,
                                @QuestionID = processConfirmation.QuestionID,
                                @Answer = processConfirmation.Answer,
                                @AnswerType_AnswerTypeID = processConfirmation.AnswerType_AnswerTypeID,
                                @AdditionalEmployee = addemp,
                                @TagName = tagname,
                                //@AnsweredBy = processConfirmation.AnsweredBy,
                                @TagmodeID = processConfirmation.TagModeID,
                                @CustomModeID = processConfirmation.CustomModeID,
                                @AnsweredBy_NTID = processConfirmation.AnsweredBy_NTID,
                                @CreatedAt = processConfirmation.CreatedAt,

                                //@ModifiedBy=processConfirmation.ModifiedBy,

                                @ModifiedAt = processConfirmation.ModifiedAt,
                                @TagId = processConfirmation.TagID,
                                @IsDeviation = processConfirmation.isDeviation,
                                @ObtainedSCore = processConfirmation.ObtainedScore,
                                @DeviationDescription = processConfirmation.DeviationDescription,
                                @ResponsibleEmployee = processConfirmation.ResponsibleEmployee,
                                //@ModifiedBy_NTID= processConfirmation.AnsweredBy_NTID
                                @HintImages = hintImages,
                                @ChoiceID = processConfirmation.ChoiceID,
                                @IsSHowVsAs = processConfirmation.IsShowVsAs,
                                @SessionID = processConfirmation.SessionID,
                                @PlantID = userPlantID,
                                @IsDeleted = processConfirmation.IsDeleted,
                                @CurrentUserNTID = userNTID,

                            }, commandTimeout: CommandTimeoutSeconds,
                            commandType: CommandType.StoredProcedure);
                            //var p = new DynamicParameters();
                            //p.Add("id", dbType: DbType.Int32, direction: ParameterDirection.Output);
                            data.ResultCode = 0;
                            data.InsertedID = result.FirstOrDefault().DeviationId;
                            return data;
                        });
                    }
                    //Deviation Without Pic Additional settings and deviation
                    else
                    {
                        Console.WriteLine("Ashok New Insert DeviationWithoutPicAdditionalsettingsanddeviation");
                        return await (new DapperContext()).WithConnection(async c =>
                        {

                            var result = await c.QueryAsync<Deviation>("USP_Insertprocessconfimration_TagMode_DeviationWithoutPicAdditionalsettings", new
                            {
                                //@TimeStamp = processConfirmation.TimeStamp,
                                @ModeTypeID = processConfirmation.ModeTypeID,
                                @ValueStreamID = processConfirmation.ValueStreamID,
                                @AssessorID = processConfirmation.AssessorID,
                                @QuestionID = processConfirmation.QuestionID,
                                @Answer = processConfirmation.Answer,
                                @AnswerType_AnswerTypeID = processConfirmation.AnswerType_AnswerTypeID,
                                @AdditionalEmployee = addemp,
                                @TagName = tagname,
                                //@AnsweredBy = processConfirmation.AnsweredBy,
                                @TagmodeID = processConfirmation.TagModeID,
                                @CustomModeID = processConfirmation.CustomModeID,
                                @AnsweredBy_NTID = processConfirmation.AnsweredBy_NTID,
                                @CreatedAt = processConfirmation.CreatedAt,

                                //@ModifiedBy=processConfirmation.ModifiedBy,

                                @ModifiedAt = processConfirmation.ModifiedAt,
                                @TagId = processConfirmation.TagID,
                                @IsDeviation = processConfirmation.isDeviation,
                                @ObtainedSCore = processConfirmation.ObtainedScore,
                                @DeviationDescription = processConfirmation.DeviationDescription,
                                @ResponsibleEmployee = processConfirmation.ResponsibleEmployee,
                                //@ModifiedBy_NTID= processConfirmation.AnsweredBy_NTID
                                @HintImages = hintImages,
                                @ChoiceID = processConfirmation.ChoiceID,
                                @IsSHowVsAs = processConfirmation.IsShowVsAs,
                                @SessionID = processConfirmation.SessionID,
                                @PlantID = userPlantID,
                                @IsDeleted = processConfirmation.IsDeleted,
                                @CurrentUserNTID = userNTID,

                            }, commandTimeout: CommandTimeoutSeconds,
                            commandType: CommandType.StoredProcedure);
                            //var p = new DynamicParameters();
                            //p.Add("id", dbType: DbType.Int32, direction: ParameterDirection.Output);
                            data.ResultCode = 0;
                            data.InsertedID = result.FirstOrDefault().DeviationId;
                            return data;
                        });
                    }

                }
                else
                {
                    Console.WriteLine("Ashok New Insert else not a tag mode");
                    return await (new DapperContext()).WithConnection(async c =>
                    {

                        var result = await c.QueryAsync<Deviation>("USP_InsertIntoProcessConfirmation", new
                        {
                            //@TimeStamp = processConfirmation.TimeStamp,
                            @ModeTypeID = processConfirmation.ModeTypeID,
                            @ValueStreamID = processConfirmation.ValueStreamID,
                            @AssessorID = processConfirmation.AssessorID,
                            @QuestionID = processConfirmation.QuestionID,
                            @Answer = processConfirmation.Answer,
                            @AnswerType_AnswerTypeID = processConfirmation.AnswerType_AnswerTypeID,
                            @AdditionalEmployee = addemp,
                            @TagName = tagname,
                            //@AnsweredBy = processConfirmation.AnsweredBy,
                            @TagmodeID = processConfirmation.TagModeID,
                            @CustomModeID = processConfirmation.CustomModeID,
                            @AnsweredBy_NTID = processConfirmation.AnsweredBy_NTID,
                            @CreatedAt = processConfirmation.CreatedAt,

                            //@ModifiedBy=processConfirmation.ModifiedBy,

                            @ModifiedAt = processConfirmation.ModifiedAt,
                            @TagId = processConfirmation.TagID,
                            @IsDeviation = processConfirmation.isDeviation,
                            @ObtainedSCore = processConfirmation.ObtainedScore,
                            @DeviationDescription = processConfirmation.DeviationDescription,
                            @ResponsibleEmployee = processConfirmation.ResponsibleEmployee,
                            //@ModifiedBy_NTID= processConfirmation.AnsweredBy_NTID
                            @HintImages = hintImages,
                            @ChoiceID = processConfirmation.ChoiceID,
                            @IsSHowVsAs = processConfirmation.IsShowVsAs,
                            @SessionID = processConfirmation.SessionID,
                            @PlantID = userPlantID,
                            @IsDeleted = processConfirmation.IsDeleted,
                            @CurrentUserNTID = userNTID,

                        }, commandTimeout: CommandTimeoutSeconds,
                        commandType: CommandType.StoredProcedure);
                        //var p = new DynamicParameters();
                        //p.Add("id", dbType: DbType.Int32, direction: ParameterDirection.Output);
                        data.ResultCode = 0;
                        data.InsertedID = result.FirstOrDefault().DeviationId;
                        return data;
                    });
                }

            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            } 
            #endregion
        }

        public async Task<Result> InsertProcessConfirmation(ProcessConfirmation processConfirmation)
        {
            var data = new Result();
            Log.Information("track1: staring the Insertprocessconfirmation --> mohan");
            try
            {
                string formattedDateTime = "";
                string EventID = "";
                string ChildEventID = "";
                int AttemptNumber= 0;
                bool isinlineinsertprocess = false;
                bool frominline = false;
                bool isResumeActivated = false;
                bool resumefrominlinetoclassic = false;

                int TagId = processConfirmation.TagID;
                string userid =  processConfirmation.AnsweredBy_NTID;

                //if (processConfirmation.IsFirstinsertProcessConfirmation==true)
                //{

                //    if (processConfirmation.isResumeActivated == true )
                //    {
                //        using (IDbConnection db = new System.Data.SqlClient.SqlConnection(new DapperContext().ConnectionString))
                //        {
                //            string selectQueryTagAssignQuestions = @"select top 1 EventID_Start_time from  T_TRN_EventId_Maintable where TagID=@TagId and userntid=@userid order by ID desc";

                //            formattedDateTime = (string)db.QueryFirstOrDefault<string?>(selectQueryTagAssignQuestions, new
                //            {
                //                TagId,
                //               userid

                //             });


                //        string selectQueryTagAnsweredQuestions = @"select top 1 EventID from  T_TRN_EventId_Maintable where TagID=@TagId and userntid=@userid order by ID desc";
                //            EventID = (string)db.QueryFirstOrDefault<string?>(selectQueryTagAnsweredQuestions, new
                //            {
                //                TagId,
                //                userid
                //            }
                //        );


                //        string Attempts = @"select top 1 Attempt from T_TRN_Eventid_Childtable where EventID_Start_time = @formattedDateTime order by ID desc";
                //            AttemptNumber = (int)db.QueryFirstOrDefault<int>(Attempts, new
                //        {
                //                formattedDateTime
                //            }
                //        );

                //            if (AttemptNumber == 0)
                //            {
                //                AttemptNumber = 1;
                //                ChildEventID = EventID + '_' + AttemptNumber;
                //            }else
                //            {
                //                AttemptNumber = AttemptNumber + 1;
                //                ChildEventID =EventID+'_'+AttemptNumber;
                //            }

                //        }
                //    }
                //    else
                //    {
                //        DateTime now = DateTime.Now;
                //        formattedDateTime = now.ToString("yyyy-MM-dd HH:mm:ss.fff");
                //        EventID = formattedDateTime + '_' + processConfirmation.ValueStreamID + '_' + processConfirmation.TagID + '_' + userNTID;

                //    }
                //}



                //New Logic below

                //second insertion eventid creation
                if (processConfirmation.isResumeClickedOnce)
                {

                    processConfirmation.isResumeActivated = processConfirmation.isResumeClickedOnce;
                }
                if (processConfirmation.isResumeActivated == true) {
                    //child table entry
                    if(processConfirmation.IsFirstinsertProcessConfirmation == true)
                    {
                        using (IDbConnection db = new System.Data.SqlClient.SqlConnection(new DapperContext().ConnectionString))
                        {
                            string selectQueryTagAssignQuestions = @"select top 1 EventID_Start_time from  T_TRN_EventId_Maintable where TagID=@TagId and userntid=@userid order by ID desc";

                            formattedDateTime = (string)db.QueryFirstOrDefault<string?>(selectQueryTagAssignQuestions, new
                            {
                                TagId,
                                userid

                            });


                            string selectQueryTagAnsweredQuestions = @"select top 1 EventID from  T_TRN_EventId_Maintable where TagID=@TagId and userntid=@userid order by ID desc";
                            EventID = (string)db.QueryFirstOrDefault<string?>(selectQueryTagAnsweredQuestions, new
                            {
                                TagId,
                                userid
                            }
                        );


                            string Attempts = @"select top 1 Attempt from T_TRN_Eventid_Childtable where EventID_Start_time = @formattedDateTime order by ID desc";
                            AttemptNumber = (int)db.QueryFirstOrDefault<int>(Attempts, new
                            {
                                formattedDateTime
                            }
                        );

                            if (AttemptNumber == 0)
                            {
                                AttemptNumber = 1;
                                ChildEventID = EventID + '_' + AttemptNumber;
                            }
                            else
                            {
                                AttemptNumber = AttemptNumber + 1;
                                ChildEventID = EventID + '_' + AttemptNumber;
                            }

                        }
                    }
                    else
                    {
                        EventID = processConfirmation.generatedEventID != null ? processConfirmation.generatedEventID : EventID;
                        formattedDateTime = processConfirmation.Process_eventID_Starttime;
                        ChildEventID = processConfirmation.ChildEventID;
                        AttemptNumber = processConfirmation.AttemptNumber;
                    }
                }
                else
                {
                    //maintableentry

                    if (processConfirmation.IsFirstinsertProcessConfirmation == true && processConfirmation.fromunanswerornextinline==false )
                    {
                        DateTime now = DateTime.Now;
                        formattedDateTime = now.ToString("yyyy-MM-dd HH:mm:ss.fff");
                        EventID = formattedDateTime + '_' + processConfirmation.ValueStreamID + '_' + processConfirmation.TagID + '_' + userNTID;

                    }
                    else
                    {
                        EventID = processConfirmation.generatedEventID != null ? processConfirmation.generatedEventID : EventID;
                        formattedDateTime = processConfirmation.Process_eventID_Starttime;
                        ChildEventID = processConfirmation.ChildEventID;
                        AttemptNumber = processConfirmation.AttemptNumber;
                    }
                }



                //if (processConfirmation.IsFirstinsertProcessConfirmation==false )                {
                //    EventID = processConfirmation.generatedEventID != null? processConfirmation.generatedEventID: EventID;
                //    formattedDateTime = processConfirmation.Process_eventID_Starttime;
                //    ChildEventID = processConfirmation.ChildEventID;
                //    AttemptNumber = processConfirmation.AttemptNumber;
                    
                //}
                
                Console.WriteLine(formattedDateTime);
                Console.WriteLine(EventID); 
                 isinlineinsertprocess = processConfirmation.isInlineInsertProcess;
                frominline = processConfirmation.frominline;
                isResumeActivated = processConfirmation.isResumeActivated;
                resumefrominlinetoclassic = processConfirmation.resumefrominlinetoclassic;
                var hintImages = Utility.Utility.ObjectToXMLGeneric(processConfirmation.HintImages);
                var tagname = Utility.Utility.ObjectToXMLGeneric(processConfirmation.selectedTagData);
                var addemp = Utility.Utility.ObjectToXMLGeneric(processConfirmation.AdditionalEmployee);
                Log.Information("track2: entering the Insertprocessconfirmation --> mohan");
                string storedProcedureName;

                if (processConfirmation.ModeTypeID == 3 || processConfirmation.ModeTypeID == 2 || processConfirmation.ModeTypeID == 1)
                {
                    Log.Information("track3: entering the Mode = 3 --> mohan");
                    // Determine stored procedure based on deviation conditions
                    if (processConfirmation.DeviationID == 0 && string.IsNullOrEmpty(processConfirmation.DeviationDescription))
                        storedProcedureName = "USP_Insertprocessconfirmation_TagMode_NormalAnswer";
                    else if (processConfirmation.DeviationDescription != null && processConfirmation.HintImages.Count > 0 && processConfirmation.selectedTagData == null && processConfirmation.AdditionalEmployee.Count == 0)
                        storedProcedureName = "USP_Insertprocessconfirmation_TagMode_onlydeviation_withImage_withoutadditionalsettings";
                    else if (processConfirmation.DeviationDescription != null && processConfirmation.HintImages.Count == 0 && processConfirmation.selectedTagData == null && processConfirmation.AdditionalEmployee.Count == 0)
                        storedProcedureName = "USP_Insertprocessconfirmation_TagMode_onlydeviation_withoutImage_withoutadditionalsettings";
                    else if (processConfirmation.DeviationDescription != null && processConfirmation.HintImages.Count > 0)
                        storedProcedureName = "USP_Insertprocessconfimration_TagMode_DeviationWithPicAdditionalsettings";
                    else
                        storedProcedureName = "USP_Insertprocessconfimration_TagMode_DeviationWithoutPicAdditionalsettings";
                }
                else
                {
                    Log.Information("track4: entering the Mode != 3 --> mohan");
                    storedProcedureName = "USP_InsertIntoProcessConfirmation";
                }

                // Execute the appropriate stored procedure
                using (var context = new DapperContext())
                {
                    var result = await context.WithConnection(async c =>
                    {
                        return await c.QueryAsync<Deviation>(storedProcedureName, new
                        {
                            @ModeTypeID = processConfirmation.ModeTypeID,
                            @ValueStreamID = processConfirmation.ValueStreamID,
                            @AssessorID = processConfirmation.AssessorID,
                            @QuestionID = processConfirmation.QuestionID,
                            @Answer = processConfirmation.Answer,
                            @AnswerType_AnswerTypeID = processConfirmation.AnswerType_AnswerTypeID,
                            @AdditionalEmployee = addemp,
                            @TagName = tagname,
                            @TagmodeID = processConfirmation.TagModeID,
                            @CustomModeID = processConfirmation.CustomModeID,
                            @AnsweredBy_NTID = processConfirmation.AnsweredBy_NTID,
                            @CreatedAt = processConfirmation.CreatedAt,
                            @ModifiedAt = processConfirmation.ModifiedAt,
                            @TagId = processConfirmation.TagID,
                            @IsDeviation = processConfirmation.isDeviation,
                            @ObtainedSCore = processConfirmation.ObtainedScore,
                            @DeviationDescription = processConfirmation.DeviationDescription,
                            @ResponsibleEmployee = processConfirmation.ResponsibleEmployee,                           
                            //@HintImages = hintImages,
                            @ChoiceID = processConfirmation.ChoiceID,
                            @IsSHowVsAs = processConfirmation.IsShowVsAs,
                            @SessionID = processConfirmation.SessionID,
                            @PlantID = userPlantID, // Ensure userPlantID is defined
                            @IsDeleted = processConfirmation.IsDeleted,
                            @CurrentUserNTID = userNTID ,// Ensure userNTID is defined
                            @IsSkipMandatory = processConfirmation.IsSkipMandatory,
                            @formattedDateTime=formattedDateTime,
                            @EventID =EventID,
                            @ResumeActive=processConfirmation.ResumeTagProcessConfirmation,
                            @AttemptNumber=AttemptNumber,
                            @ChildEventID = ChildEventID,
                            @isinlineinsertprocess= isinlineinsertprocess,
                            @frominline=frominline,
                            @isResumeActivated = isResumeActivated,
                           // @resumefrominlinetoclassic= resumefrominlinetoclassic
                        }, commandTimeout: CommandTimeoutSeconds, commandType: CommandType.StoredProcedure);
                    });

                    data.ResultCode = 0;
                    data.InsertedID = result.FirstOrDefault().DeviationId;
                    data.eventID = EventID;
                    data.eventStartTime = formattedDateTime;
                    data.AttemptNumber = AttemptNumber;
                    data.ChildEventID = ChildEventID;
                    
                    Log.Information("track5: entering the Mode = 3 --> mohan --> result {0}", data.InsertedID);
                }
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error($"API Error-{GetType().FullName}.{System.Reflection.MethodBase.GetCurrentMethod().Name}-{ex.InnerException?.Message ?? ex.Message}");
            }

            return data;
        }



        //public int updateEventEndTime(String eventstarttime)
        //{
        //    int TagAssignedQuestionCount = 0;
        //    int TagAssignedQuestionCount1 = 0;
        //    string currentDateTime = null;
        //    currentDateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");

        //    using (IDbConnection db = new System.Data.SqlClient.SqlConnection(new DapperContext().ConnectionString))
        //    {
        //        string selectQueryTagAssignQuestions = @"update T_TRN_EventId_Maintable set EndTime = @currentDateTime where eventid_start_time = @eventstarttime";
        //        TagAssignedQuestionCount = (int)db.QueryFirstOrDefault<int?>(selectQueryTagAssignQuestions, new
        //        {
        //            eventstarttime,
        //            currentDateTime

        //        });

        //        string selectQueryTagAssignQuestions1 = @"update [T_TRN_Eventid_Childtable] set EndTime = @currentDateTime where eventid_start_time = @eventstarttime";
        //        TagAssignedQuestionCount = (int)db.QueryFirstOrDefault<int?>(selectQueryTagAssignQuestions, new
        //        {
        //            eventstarttime,
        //            currentDateTime

        //        });
        //        return 1;

        //    }
        //}


        public int updateEventEndTime(string eventstarttime, ProcessConfirmation processConfirmationdata)
        {
            int TagAssignedQuestionCount = 0; // Count of updated records
            int TagAssignedQuestionCount1 = 1;
            int TagModeID = processConfirmationdata.TagModeID;
            int TagID = processConfirmationdata.TagID;
            int Plantid = processConfirmationdata.PlantID;
            string ModifiedBy_NTID = userNTID;

            string currentDateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");

            using (IDbConnection db = new System.Data.SqlClient.SqlConnection(new DapperContext().ConnectionString))
            {
                string selectQueryTagAssignQuestions = @"
                UPDATE T_TRN_EventId_Maintable 
                SET EndTime = @currentDateTime 
                WHERE eventid_start_time = @eventstarttime";

                // Execute the first update and get the affected row count
                TagAssignedQuestionCount = db.Execute(selectQueryTagAssignQuestions, new
                {
                    eventstarttime,
                    currentDateTime
                });

                string selectQueryTagAssignQuestions1 = @"
                UPDATE [T_TRN_Eventid_Childtable] 
                SET EndTime = @currentDateTime 
                WHERE eventid_start_time = @eventstarttime";

                // Execute the second update and accumulate the affected row count
                TagAssignedQuestionCount += db.Execute(selectQueryTagAssignQuestions1, new
                {
                    eventstarttime,
                    currentDateTime
                });



                string selectQueryTagAssignQuestionsmailupdate = @"
                        update T_LNK_Tag_AnsweredQuestions  SET IsDeleted = 1 ,  isTagcompleted = 1
                        where TagModeID = @TagModeID AND PlantID = @Plantid AND 
                        TagID = @TagID AND ModifiedBy_NTID = @ModifiedBy_NTID";

                TagAssignedQuestionCount1 = db.Execute(selectQueryTagAssignQuestionsmailupdate, new
                {
                    TagModeID,
                    Plantid,
                    TagID,
                    ModifiedBy_NTID
                });

                //// Execute the first update and get the affected row count
                //TagAssignedQuestionCount = db.Execute(selectQueryTagAssignQuestions, new
                //{
                //    eventstarttime,
                //    currentDateTime
                //});





                return TagAssignedQuestionCount; // Return the total number of updated rows
            }
        }



        public async Task<Result> AddToCustomMode(ProcessConfirmation processConfirmation)
        {
            Result data = new Result();

            try
            {
                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_AddToCustomMode", new
                    {
                       
                        @QuestionID = processConfirmation.QuestionID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        public async Task<Result> DeleteFromCustomMode(ProcessConfirmation processConfirmation)
        {
            Result data = new Result();
            var TagID = processConfirmation.TagID;
            try
            {
                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_DeleteFromCustomMode", new
                    {
                        @QuestionID = processConfirmation.QuestionID,
                        @TagID = processConfirmation.TagID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }


        public async Task<List<ValueStream>> GetValueStreamByQuestionID(int QuestionID)
        {
            try
            {
                return await WithConnection(async c =>
                {
                    var list = await c.QueryAsync<ValueStream>(
                        "USP_GetValueStreamByQuestionID", new
                        {
                            @QuestionID = QuestionID,
                            @PlantID = userPlantID,

                        },
                       commandType: CommandType.StoredProcedure);
                    return list.ToList();
                });
            }
            catch (Exception Ex)
            {

                throw Ex;
            }

        }


        public async Task<int> getSelectedLinkedTagQuestionCount(int TagId, Boolean maintablequestioncount = false)
        {
            try
            {
                return await WithConnection(async c =>
                {
                    // Fetch the result from the stored procedure
                    var list = await c.QueryAsync(
                        "GetTagSetting_InLineQuestionCount_PassingTag_NewTagCreation",
                        new
                        {
                            @enteredTagId = TagId,
                            @MaintableQuestionCount = 1,
                        },
                        commandType: CommandType.StoredProcedure);

                    var row = list.SingleOrDefault();
                    if (maintablequestioncount)
                    {
                        return (row.QuestionCount);
                    }
                    else
                    {
                        return (row.HalfOfUniqueQuestions);
                    }

                    // Return the result (assuming you are expecting a single value)
                    // return list.SingleOrDefault(); // or list.First() if appropriate
                });
            }
            catch (Exception Ex)
            {
                throw Ex; // Consider using throw without Ex to preserve the stack trace
            }
        }

        public async Task<List<Assessor>> GetAssessorsByQuestionID(int QuestionID)
        {
            try
            {
                return await WithConnection(async c =>
                {
                    var list = await c.QueryAsync<Assessor>(
                        "USP_GetAssessorsByQuestionID", new
                        {
                            @QuestionID = QuestionID,
                            @PlantID = userPlantID,

                        },
                       commandType: CommandType.StoredProcedure);
                    return list.ToList();
                });
            }
            catch (Exception Ex)
            {

                throw Ex;
            }

        }


    }
}
