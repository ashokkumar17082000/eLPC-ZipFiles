﻿using Dapper;
using ELPC.Core;
using ELPC.DAL.Interfaces;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ELPC.DAL.Implementation
{
    public class MergeRepository : DapperContext, IMergeRepository
    {

        public async Task<Result> MergeQuestionAssignment(Merge mergeQuestionAssignment)
        {
            Result data = new Result();

            try
            {
                var questions = mergeQuestionAssignment.questions.Select(r => r.QuestionID.ToString()).ToList();
                var valueStreams = mergeQuestionAssignment.valueStreams.Select(r => r.ValueStreamID.ToString()).ToList();
                var assessors = mergeQuestionAssignment.assessors.Select(r => r.AssessorID.ToString()).ToList();
                var tags = mergeQuestionAssignment.tags.Select(r => r.TagID.ToString()).ToList();


                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_MergeQuestionAssignment", new
                    {
                        // @ID = proxy.ID,
                        @questions = string.Join(",",questions),
                        @ValueStreams = string.Join(",",valueStreams),
                        @Assessors = string.Join(",", assessors),
                        @Tags = string.Join(",", tags),
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        public async Task<Result> MergeTagAssignment(Merge mergeTagAssignment)
        {
            Result data = new Result();

            try
            {
                var tags = mergeTagAssignment.tags.Select(r => r.TagID.ToString()).ToList();
                var questions = mergeTagAssignment.questions.Select(r => r.QuestionID.ToString()).ToList();
                var valueStreams = mergeTagAssignment.valueStreams.Select(r => r.ValueStreamID.ToString()).ToList();
                var assessors = mergeTagAssignment.assessors.Select(r => r.AssessorID.ToString()).ToList();

                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_MergeTagAssignment", new
                    {
                        //@ID = proxy.ID,
                        @questions = string.Join(",", questions),
                        @ValueStreams = string.Join(",", valueStreams),
                        @Assessors = string.Join(",", assessors),
                        @Tags = string.Join(",", tags),
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        public async Task<Result> MergeQuestionRemoval(Merge mergeQuestionRemoval)
        {
            Result data = new Result();

            try
            {
                var questions = mergeQuestionRemoval.questions.Select(r => r.QuestionID.ToString()).ToList();
                var valueStreams = mergeQuestionRemoval.valueStreams.Select(r => r.ValueStreamID.ToString()).ToList();
                var assessors = mergeQuestionRemoval.assessors.Select(r => r.AssessorID.ToString()).ToList();
                var tags = mergeQuestionRemoval.tags.Select(r => r.TagID.ToString()).ToList();


                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_MergeQuestionRemoval", new
                    {
                        // @ID = proxy.ID,
                        @questions = string.Join(",", questions),
                        @ValueStreams = string.Join(",", valueStreams),
                        @Assessors = string.Join(",", assessors),
                        @Tags = string.Join(",", tags),
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        public async Task<Result> MergeTagRemoval(Merge mergeTagRemoval)
        {
            Result data = new Result();

            try
            {
                var tags = mergeTagRemoval.tags.Select(r => r.TagID.ToString()).ToList();
                var questions = mergeTagRemoval.questions.Select(r => r.QuestionID.ToString()).ToList();
                var valueStreams = mergeTagRemoval.valueStreams.Select(r => r.ValueStreamID.ToString()).ToList();
                var assessors = mergeTagRemoval.assessors.Select(r => r.AssessorID.ToString()).ToList();

                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_MergeTagRemoval", new
                    {
                        // @ID = proxy.ID,
                        @questions = string.Join(",", questions),
                        @ValueStreams = string.Join(",", valueStreams),
                        @Assessors = string.Join(",", assessors),
                        @Tags = string.Join(",", tags),
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        public async Task<Result> MergeQuestionProxy(MergeProxy mergeQuestionProxy)
        {
            Result data = new Result();

            try
            {
                var questions = mergeQuestionProxy.questions.Select(r => r.QuestionID.ToString()).ToList();
                var Proxies = Utility.Utility.ObjectToXMLGeneric(mergeQuestionProxy.Proxies);


                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_MergeQuestionProxy", new
                    {
                        @ID = mergeQuestionProxy.ID,
                        @questions = string.Join(",", questions),
                        @Proxies = Proxies,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        public async Task<Result> MergeTagProxy(MergeProxy mergeTagProxy)
        {
            Result data = new Result();

            try
            {
                var tags = mergeTagProxy.tags.Select(r => r.TagID.ToString()).ToList();
                //var Proxies = mergeTagProxy.Proxies.Select(r => r.NTID.ToString()).ToList();
                var Proxies = Utility.Utility.ObjectToXMLGeneric(mergeTagProxy.Proxies);




                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_MergeTagProxy", new
                    {
                        @ID = mergeTagProxy.ID,
                        @tags = string.Join(",", tags),
                        @Proxies = Proxies,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }
    }
}
