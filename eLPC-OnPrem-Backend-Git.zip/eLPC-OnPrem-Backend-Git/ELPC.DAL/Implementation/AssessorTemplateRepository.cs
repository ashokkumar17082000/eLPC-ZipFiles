﻿using Dapper;
using ELPC.Core;
using ELPC.DAL.Interfaces;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ELPC.DAL.Implementation
{
    public class AssessorTemplateRepository : DapperContext, IAssessorTemplateRepository
    {

        public async Task<List<AssessorTemplate>> GetAssessorTemplates()
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<AssessorTemplate>(
                     "USP_FetchAssessorTemplate", new
                     {
                         @PlantID = userPlantID,
                         @CurrentUserNTID = userNTID

                     },

                    commandType: CommandType.StoredProcedure);

                return list.ToList();
            });
        }

        public async Task<List<AssessorTemplate>> ValidateAssessorTemplateName(string assessorTemplateName)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<AssessorTemplate>(
                     "USP_ValidateAssessorTemplateName", new
                     {
                         @AssessorTemplateName = assessorTemplateName,
                         @PlantID = userPlantID

                     },

                    commandType: CommandType.StoredProcedure);

                return list.ToList();

            });
        }

        public async Task<List<AssessorStreamHistory>> GetAssessorTemplatesHistory(int templateID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<AssessorStreamHistory>(
                    "USP_AssessorTemplateHistory", new
                    {
                        @AssessorTemplateID = templateID,
                        @PlantID = userPlantID

                    },
                   commandType: CommandType.StoredProcedure);

                return list.ToList();

            });
        }

        public async Task<List<Assessor>> GetAssessors()
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<Assessor>(
                     "USP_FetchAssessor", new
                     {
                         @PlantID = userPlantID
                     },

                    commandType: CommandType.StoredProcedure);

                return list.ToList();

            });
        }

        public async Task<Result> InsertAssessorTemplate(AssessorTemplate assessorTemplate)
        {
            Result data = new Result();

            try
            {
                var x = Utility.Utility.ObjectToXMLGeneric(assessorTemplate.AssessorCategories);
                var y = Utility.Utility.ObjectToXMLGeneric(assessorTemplate.Assessors);

                return await (new DapperContext()).WithConnection(async c =>
                {
                    var result = await c.QueryAsync<AssessorTemplate>("USP_AddEditAssessorTemplate", new
                    {
                        @AssessorTemplateName = assessorTemplate.AssessorTemplateName,
                        @IsLocked = assessorTemplate.IsLocked,
                        @ModifiedAt = assessorTemplate.ModifiedAt,
                        @CreatedAt = assessorTemplate.CreatedAt,
                        @IsTargetFrequencyDefined = assessorTemplate.IsTargetFrequencyDefined,
                        @AssessorCategories = x,
                        @Assessors = y,
                        @AssessorTemplateID = assessorTemplate.AssessorTemplateID,
                        @IsDeleted = false,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,
                    },
                    commandType: CommandType.StoredProcedure);
                    //data.ResultCode = 0;
                    if (result.Count() > 0)
                    {
                        data.ResultCode = 0;
                        data.InsertedID = result.FirstOrDefault().AssessorTemplateID;
                    }
                    else
                    {
                        data.ResultCode = 9;
                    }
                    return data;
                });
            }
            catch (Exception ex)
            {
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                data.ResultCode = 9;
                data.ResultMessage = "Failed";
                return data;
            }
        }

        public async Task<List<Assessor>> GetAssessorsByTemplateID(int templateID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<Assessor>(
                    "USP_AssessorByTemplateID", new
                    {
                        @AssessorTemplateID = templateID,
                        @PlantID = userPlantID
                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<Result> AssessorsRestoreByTemplateHistoryID(int historyID)
        {
            Result data = new Result();
            try
            {
                return await WithConnection(async c =>
                {
                    var list = await c.QueryAsync<Assessor>(
                        "USP_Restore_T_TRN_AssessorHistory", new
                        {
                            @AssessorTemplateHistoryID = historyID,
                            @PlantID = userPlantID,
                            @CurrentUserNTID = userNTID

                        },
                       commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;

                    return data;
                });
            }
            catch (Exception ex)
            {
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                data.ResultCode = 9;
                return data;
            }
        }

        public async Task<Result> DeleteAssessorTemplate(AssessorTemplate assessorTemplate)
        {
            Result data = new Result();
            try
            {
                IDbConnection db = new SqlConnection(new DapperContext().ConnectionString);

                var res = db.Query<int>("USP_ValidateLinkedAssessor", new
                {
                    @AssessorTemplateID = assessorTemplate.AssessorTemplateID,
                    @PlantID = userPlantID,

                }, commandType: CommandType.StoredProcedure).Count();

                if (res < 1)
                {
                    return await (new DapperContext()).WithConnection(async c =>
                    {

                        var result = await c.QueryAsync("USP_DeleteAssessorTemplate", new
                        {
                            @AssessorTemplateID = assessorTemplate.AssessorTemplateID,
                            @ModifiedAt = assessorTemplate.ModifiedAt,
                            @PlantID = userPlantID,
                            @CurrentUserNTID = userNTID,

                        },
                        commandType: CommandType.StoredProcedure);
                        data.ResultCode = 0;
                        return data;
                    });
                }
                else
                {
                    data.ResultCode = 1;
                    return data;
                }
            }
            catch (Exception ex)
            {
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                data.ResultCode = 9;
                return data;
            }
        }

        public async Task<Result> InsertAssessorProxy(AssessorProxy proxy)
        {
            Result data = new Result();

            try
            {
                var x = Utility.Utility.ObjectToXMLGeneric(proxy.Proxies);

                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_AddEditAssessorTemplateProxy", new
                    {
                        @ID = proxy.ID,
                        @AssessorTemplateID = proxy.AssessorTemplateID,
                        @IsLocked = proxy.IsLocked,
                        @Proxies = x,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,
                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                data.ResultCode = 9;
                return data;
            }
        }

        public async Task<List<AssessorProxy>> AssessorProxiesByAssessorTemplateID(int templateID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<AssessorProxy>(
                    "USP_FetchAssessorProxiesByTemplateID", new
                    {
                        @AssessorTemplateID = templateID,
                        @PlantID = userPlantID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<List<AssessorTemplate>> FetchAssessorTemplateByTemplateID(int templateID)
        {
            try
            {
                return await WithConnection(async c =>
                {
                    var list = await c.QueryAsync<AssessorTemplate>(
                        "USP_FetchAssessorTemplateByTemplateID", new
                        {
                            @AssessorTemplateID = templateID,
                            @PlantID = userPlantID
                        },
                       commandType: CommandType.StoredProcedure);
                    return list.ToList();
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        //*************************************Import Excel*******************************************
        public async Task<Result> AssessorImportExcel(AssessorImportCombinedList assessorImportCombinedList, string ntid)
        {
            Result data = new Result();
            try
            {

                for (int i = 0; i < assessorImportCombinedList.list1.Count; i++)
                {
                    var y = (dynamic)null;
                    //var z = (dynamic)null;
                    // List<Assessor> vs3 = new List<Assessor>();

                    assessorImportCombinedList.list1[i].ModifiedBy_NTID = ntid;
                    if (string.IsNullOrEmpty(assessorImportCombinedList.list1[i].CreatedBy_NTID))
                    {
                        assessorImportCombinedList.list1[i].CreatedBy_NTID = ntid;
                    }

                    var x = Utility.Utility.ObjectToXMLGeneric(assessorImportCombinedList.list1[i]);

                    var li2 = assessorImportCombinedList.list2.Where(n => n.TempID.ToString() == assessorImportCombinedList.list1[i].TempID).ToList();



                    y = Utility.Utility.ObjectToXMLGeneric(li2);



                    //for(int j = 0; j < li2.Count; j++)
                    //{
                    //    var x1 = importCombinedList.list3.Where(n => n.CID == li2[j].CID).ToList();
                    //    vs3.AddRange(x1);
                    //}

                    //var li3 = importCombinedList.list3.Where(n => n.CID == li2.CID).ToList();
                    //z = Utility.Utility.ObjectToXMLGeneric(vs3);

                    //**************

                    //validations 
                    //foreach (AssessorTemplate assessorTemplate in x)
                    //{

                    var assessorTemplate = assessorImportCombinedList.list1[i];


                    if (assessorTemplate.IsTargetFrequencyDefined == true)
                    {
                        //var assessors = assessorImportCombinedList.list2.Where(x => x.TempID == assessorTemplate.TempID);
                        if (li2 != null)
                        {
                            foreach (ImpexAssessor assessor in li2)
                            {



                                switch (assessor.TargetFrequencyTypeID)
                                {
                                    case "Shift":
                                        assessor.TargetFrequencyTypeID = "1";
                                        break;
                                    case "Day":
                                        assessor.TargetFrequencyTypeID = "2";
                                        break;
                                    case "Week":
                                        assessor.TargetFrequencyTypeID = "3";
                                        break;
                                    case "Bi-weekly":
                                        assessor.TargetFrequencyTypeID = "4";
                                        break;
                                    case "Month":
                                        assessor.TargetFrequencyTypeID = "5";
                                        break;
                                    case "Quarter":
                                        assessor.TargetFrequencyTypeID = "6";
                                        break;
                                    case "Year":
                                        assessor.TargetFrequencyTypeID = "7";
                                        break;
                                    default:
                                        break;
                                }

                                if (String.IsNullOrEmpty(assessor.TargetFrequencyValue))
                                {
                                    //result.ResultMessage = "Target Frequency Value should not be empty";
                                    //result.ResultCode = 0;
                                    //return result;
                                    break;
                                }
                            }
                        }
                    }
                    //}


                    x = x == null ? " " : x;
                    y = y == null ? " " : y;
                    // z = z == null ? " " : z;
                    using (IDbConnection con = new SqlConnection(ConnectionString))
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();

                        DynamicParameters parameters = new DynamicParameters();
                        parameters.Add("@ImportExcel_AssessorTemplate", x);
                        parameters.Add("@ImportExcel_Assessor", y);
                        data.ResultCode = con.Execute("USP_ImportExcel_AssessorTemplate", parameters, commandType: CommandType.StoredProcedure);

                    }


                }

                return data;
            }
            catch (Exception ex)
            {
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                throw ex;
            }
            throw new NotImplementedException();
        }
        //**************************************Import Excel End********************************************

        //*******************************Export Excel*******************************************************
        public DataSet AssessorExportExcel()
        {
            DataSet ds = new DataSet();

            string query = "SELECT AssessorTemplateID,AssessorTemplateName,IsLocked,IsTargetFrequencyDefined,AssessorTemplateID as TempID" +
                " FROM T_TRN_AssessorTemplate where (IsDeleted =0 or IsDeleted IS NULL);";
            query += "SELECT  AssessorID,AssessorName,TargetFrequencyValue,AssessorTemplateID,TargetFrequencyTypeID,AssessorTemplateID as TempID From T_TRN_Assessor " +
                "where (IsDeleted =0 or IsDeleted IS NULL)";

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.Connection = con;
                        sda.SelectCommand = cmd;

                        sda.Fill(ds);

                    }
                }
            }
            return ds;
        }
        //*********************************Export Excel Ends Here********************************************

    }
}
