﻿using Dapper;
using ELPC.Core;
using ELPC.DAL.Interfaces;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace ELPC.DAL.Implementation
{
    public class CommonRepository : DapperContext, ICommonRepository
    {
        public async Task<List<ChoiceDisplayType>> GetChoiceDisplayTypes()
        {
            return await WithConnection(async c =>
            {
                var Roles = await c.QueryAsync<ChoiceDisplayType>(
                     "USP_FetchChoiceDisplayType", new
                     {

                     },
                    commandType: CommandType.StoredProcedure);
                return Roles.ToList();

            });
        }

        public async Task<List<AnswerType>> GetAnswerTypes()
        {
            return await WithConnection(async c =>
            {

                var Roles = await c.QueryAsync<AnswerType>(
                     "USP_FetchAnswerType", new
                     {

                     },
                    commandType: CommandType.StoredProcedure);
                return Roles.ToList();

            });
        }

        public async Task<List<User>> GetUsers()
        {
            return await WithConnection(async c =>
            {

                // Here's all the same data access code,
                // albeit now it's async, and nicely wrapped
                // in this handy WithConnection() call.

                var Users = await c.QueryAsync<User>(
                     "USP_FetchUser", new
                     {
                         @PlantID = userPlantID,
                         @CurrentUserNTID = userNTID,

                     },
                    commandType: CommandType.StoredProcedure);
                return Users.ToList();

            });
        }

        public async Task<Result> InsertUser(User user)
        {
            Result data = new Result();
            try
            {
                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_InsertUser", new
                    {
                        @UserName = user.UserName,
                        @RoleID = user.Role_roleID,
                        @EmailAddress = user.EmailAddress,
                        @NTID = user.NTID,
                        @FirstName = user.FirstName,
                        @LastName = user.LastName,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        public async Task<User> GetUserByNTID(string NTID)
        {

            return await WithConnection(async c =>
            {

                var list = await c.QueryAsync<User>(
                    "USP_FetchUserByNTID", new
                    {
                        @NTID = NTID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.FirstOrDefault();

            });


        }

        public async Task<Result> InsertIntoDeviation(Deviation deviation)
        {
            Result data = new Result();

            try
            {
                var hintImages = Utility.Utility.ObjectToXMLGeneric(deviation.HintImages);
                var tagname= Utility.Utility.ObjectToXMLGeneric(deviation.selectedTagData);
                var addemp= Utility.Utility.ObjectToXMLGeneric(deviation.AdditionalEmployee);
                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync<Deviation>("USP_InsertIntoDeviation", new
                    {

                        @ValueStreamID = deviation.ValueStreamID,
                        @DeviationDescription = deviation.DeviationDescription,
                        @ResponsibleEmployee = deviation.ResponsibleEmployee,
                        @HintImages = hintImages,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = deviation.CreatedBy_NTID,
                        @AdditionalEmployee = addemp,
                        @TagName=tagname,
                        @IsDeleted = deviation.IsDeleted,


                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    data.InsertedID = result.FirstOrDefault().DeviationId;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        public async Task<Result> InsertIntoDeviationAttachments(Deviation deviation)
        {
            Result data = new Result();

            try
            {
                Log.Information("InsertIntoAttachment Repo Line 170");
                var hintImages = Utility.Utility.ObjectToXMLGeneric(deviation.HintImages);
                Log.Information("InsertIntoAttachment Repo Line 172");
                //var tagname = Utility.Utility.ObjectToXMLGeneric(deviation.selectedTagData);
                //var addemp = Utility.Utility.ObjectToXMLGeneric(deviation.AdditionalEmployee);
                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync<Deviation>("USP_INSERTINTODEVIATIONATTACHMENTS", new
                    {

                        //@ValueStreamID = deviation.ValueStreamID,
                        //@DeviationDescription = deviation.DeviationDescription,
                        //@ResponsibleEmployee = deviation.ResponsibleEmployee,
                        @HintImages = hintImages,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = deviation.CreatedBy_NTID,
                        //@AdditionalEmployee = addemp,
                        //@TagName = tagname,
                        @IsDeleted = deviation.IsDeleted,


                    },
                    commandType: CommandType.StoredProcedure);
                    Log.Information("InsertIntoAttachment Repo Line 194");
                    data.ResultCode = 0;
                    data.InsertedID = result.FirstOrDefault().DeviationId;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        public async Task<Result> DeletetempAttachments(Deviation deviation)
        {
            Result data = new Result();

            try
            {
                    return await (new DapperContext()).WithConnection(async c =>
                    {

                        var result = await c.QueryAsync<Deviation>("USP_DeletetempAttachment", new
                        {
                            @CurrentUserNTID = deviation.CreatedBy_NTID != null ? deviation.CreatedBy_NTID : userNTID,
                            @Displayfilename = deviation.HintTempImages != null ? deviation.HintTempImages[0].DisplayFileName : "TEMP"
                        },

                        commandType: CommandType.StoredProcedure); ;
                            data.ResultCode = 0;
                            data.InsertedID = 1;
                            return data;

                    });
               
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        public async Task<Result> InsertIntoAuditDeviation(Deviation deviation)
        {
            Result data = new Result();

            try
            {
                var hintImages = Utility.Utility.ObjectToXMLGeneric(deviation.HintImages);
                var tagname = Utility.Utility.ObjectToXMLGeneric(deviation.selectedTagData);
                var addemp = Utility.Utility.ObjectToXMLGeneric(deviation.AdditionalEmployee);
                return await (new DapperContext()).WithConnection(async c =>
                {


                    var result = await c.QueryAsync<int>("USP_InsertIntoAuditDeviation", new
                    {

                        @ValueStreamID = deviation.ValueStreamID,
                        @DeviationDescription = deviation.DeviationDescription,
                        @ResponsibleEmployee = deviation.ResponsibleEmployee,
                        @HintImages = hintImages,
                        @AuditID = deviation.AuditID,
                        @AuditTemplateID = deviation.AuditTemplateID,
                        @QuestionID = deviation.QuestionID,
                        @ManagerEmailAddress = deviation.ManagerEmailAddress,
                        @ResponsibleEmployeeEmailAddress = deviation.ResponsibleEmployeeEmailAddress,
                        @ValueStreamName = deviation.ValueStreamName,
                        @UserEmailAddress = deviation.UserEmailAddress,
                        @DeviationTypeID = deviation.DeviationTypeID,
                        @QuestionText = deviation.QuestionText,
                        @ResponsibleEmpNTID = deviation.ResponsibleEmpNTID,
                        @Owner = deviation.Owner,
                        @OwnerNTID = deviation.OwnerNTID,
                        @AdditionalEmployee = addemp,
                        @TagName = tagname,
                        @IsDeleted = deviation.IsDeleted,
                        @CreatedBy_Name = deviation.CreatedBy_Name,
                        @PlantID = userPlantID,
                      
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    data.InsertedID = result.FirstOrDefault();
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        public async Task<Result> AddUsers(List<User> users)
        {
            Result data = new Result();

            try
            {
                var userList = Utility.Utility.ObjectToXMLGeneric(users);

                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_AddEditUsers", new
                    {
                        @Users = userList,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }
        private async Task<List<EmailData>> GetEmailTemplate(string LanguageCode)
        {
            return await WithConnection(async c =>
            {
                var tempcontent = await c.QueryAsync<EmailData>(
                    "USP_GetMailTemplate", new
                    {
                        @Language = LanguageCode,
                        @Template = "Deviation",
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                   commandType: CommandType.StoredProcedure);
                return tempcontent.ToList();
            });
        }

        private void GetDeviationIDFromDataPoolAndUpdateSuperOPLURL(Deviation deviation)
        {
            int? deviationID = 0;
            using (IDbConnection db = new System.Data.SqlClient.SqlConnection(new DapperContext().ConnectionString))
            {
                string selectQuery = @"SELECT DeviationID FROM [T_TRN_DataPool]  WHERE QuestionID = @QuestionID AND AuditID = @AuditID AND AuditTemplateID = @AuditTemplateID";
                deviationID = db.QueryFirstOrDefault<int?>(selectQuery, new
                {
                    deviation.QuestionID,
                    deviation.AuditID,
                    deviation.AuditTemplateID,
                });
                string selQuery = @"SELECT  FROM [T_TRN_DataPool]  WHERE QuestionID = @QuestionID AND AuditID = @AuditID AND AuditTemplateID = @AuditTemplateID";
                deviationID = db.QueryFirstOrDefault<int?>(selectQuery, new
                {
                    deviation.QuestionID,
                    deviation.AuditID,
                    deviation.AuditTemplateID,
                });
            }

            if (deviationID != null && deviationID > 0)
            {
                UpdateSuperOPLURLByDeviationID(deviationID.Value, deviation.SuperOPLURL);
            }
        }


        private void UpdateSuperOPLURLByDeviationID(int DeviationID, string SuperOPLURL)
        {
            var SuperOPLTaskID = SuperOPLURL.Split('/').LastOrDefault();
            using (IDbConnection db =  new System.Data.SqlClient.SqlConnection(new DapperContext().ConnectionString))
            {
                string updateQuery =  @"UPDATE [T_TRN_Deviation] SET [SuperOPLURL] = @SuperOPLURL, [SuperOPLTaskID] = @SuperOPLTaskID ,[IsDeviationEntry]=1 WHERE DeviationID = @DeviationID";

                var result = db.Execute(updateQuery, new
                {
                    SuperOPLURL,
                    SuperOPLTaskID,
                    DeviationID,
                });
            }
        }

        /// <summary>
        /// Sending email for the Required and Optional attendess of an audit
        /// </summary>
        /// <param name="audit"></param>
        /// <returns></returns>
        public async Task<Result> SendDeviationEmail(Deviation deviation, Dictionary<string, byte[]> emailimage)
        {
            if (string.IsNullOrEmpty(deviation.UserEmailAddress) || string.IsNullOrEmpty(deviation.ManagerEmailAddress))
            {
                var deviationMsg = Environment.NewLine + Newtonsoft.Json.JsonConvert.SerializeObject(userPlantInfo, Newtonsoft.Json.Formatting.Indented);
                //+ Environment.NewLine + Newtonsoft.Json.JsonConvert.SerializeObject(deviation, Newtonsoft.Json.Formatting.Indented) + Environment.NewLine;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "- NTID:" + userNTID + deviationMsg);
            }

            string deviationInfo = string.Empty;
            if (deviation.DeviationDescription != null && deviation.DeviationDescription != "")
            {
                if (deviation.DeviationDescription.Length > 50)
                {
                    deviationInfo = deviation.DeviationDescription.Substring(0, 50);
                }
                else
                {
                    deviationInfo = deviation.DeviationDescription;
                }
            }
            var ccmail = "";
            if(deviation.AdditionalEmployee !=null)
            {
                foreach (User usr in deviation.AdditionalEmployee)
                {
                    if (ccmail.Length > 0)
                        ccmail += ";" + usr.EmailAddress;
                    else
                        ccmail += usr.EmailAddress;
                }
            }

            if (deviation.DeviationId > 0)
                 UpdateSuperOPLURLByDeviationID(deviation.DeviationId, deviation.SuperOPLURL);
            else
                GetDeviationIDFromDataPoolAndUpdateSuperOPLURL(deviation);
            if (deviation.DeviationTypeID == 5)
            {
                return new Result { ResultMessage = "Success", ResultCode = 0 };
            }
            else
            {
                var mailTemplate = GetEmailTemplate(deviation.LanguageCode).Result.FirstOrDefault();
                string res = "";
                string response = "";
                if (deviation.selectedTagData != null)
                {
                    foreach (var each in deviation.selectedTagData)
                    {
                        Console.WriteLine(deviation.selectedTagData.Select(r => r.FormattedTag));
                        res += each.FormattedTag + ",";
                    }
                    res = res.Remove(res.Length - 1, 1);
                    Console.WriteLine(res);
                    deviation.TagName = res;
                }
                if (deviation.AdditionalEmployee != null && deviation.AdditionalEmployee.Count != 0)
                {

                    foreach (var each in deviation.AdditionalEmployee)
                    {
                        Console.WriteLine(deviation.AdditionalEmployee.Select(r => r.UserName));
                        response += each.UserName + ",";
                    }
                    response = response.Remove(response.Length - 1, 1);
                    deviation.UserName = response;
                }


                Utility.Utility.DeviationMail(userPlantInfo.PlantCode, deviation, ccmail, deviation.UserEmailAddress, deviation.ManagerEmailAddress, mailTemplate.Subject, mailTemplate.Content, emailimage);
                return new Result { ResultMessage = "Success", ResultCode = 0 };
            }
        }


        public async Task<Result> SetDefaultPlant(User user)
        {
            Result data = new Result();
            try
            {
                var userObject = Utility.Utility.ObjectToXMLGeneric(user);

                return await (new DapperContext(true)).WithConnection(async c =>
                {
                    var result = await c.QueryAsync(commonShema + "USP_SetDefaultPlant", new
                    {
                        @UserDetails = userObject,
                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        public async Task<Result> GetConfigByPlantIDAndConfigType(int plantID, string configType)
        {
            Result data = new Result();
            try
            {

                return await (new DapperContext(true)).WithConnection(async c =>
                {

                    var result = await c.QueryAsync<string>(commonShema + "USP_Fetch_ConfigByPlantIDAndConfigType", new
                    {

                        @PlantID = plantID,
                        @ConfigType = configType

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    data.ResultMessage = result.FirstOrDefault();
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }                   

        public async Task<UserDetails> FetchUserAccessDetails(User user)
        {
            var userObject = Utility.Utility.ObjectToXMLGeneric(user);
            UserDetails UserDetails = new UserDetails();
            try
            {
                return await (new DapperContext(true)).WithConnection(async c =>
                {
                    var result = await c.QueryMultipleAsync(commonShema + "USP_Fetch_UserAccessDetails", new
                    {
                        @UserDetails = userObject
                    },
                    commandType: CommandType.StoredProcedure);
                    //data.ResultMessage = result.FirstOrDefault();

                    UserDetails = result.Read<UserDetails>().FirstOrDefault();
                    if (UserDetails != null && !string.IsNullOrEmpty(UserDetails.NTID))
                    {
                        UserDetails.Plant = result.Read<Plant>().FirstOrDefault();
                        UserDetails.AvaliablePlants = result.Read<Plant>().ToList();
                    }

                    return UserDetails;
                });
            }
            catch (Exception ex)
            {
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return UserDetails;
            }
        }

        public async Task<Result> SetUserAdditionalData(string additionalData, string userNTID)
        {
            Result data = new Result();
            try
            {
                return await (new DapperContext(true)).WithConnection(async c =>
                {
                    _ = await c.QueryAsync(commonShema + "USP_SetAdditionalData", new
                    {
                        @AdditionalData = additionalData,
                        @UserNTID = userNTID
                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        public async Task<UserProfileValueStreamAssessor> GetUserProfileVSAS()
        {
            UserProfileValueStreamAssessor UserProfile = new UserProfileValueStreamAssessor();
            try
            {
                return await WithConnection(async c =>
                {
                    var result = await c.QueryMultipleAsync("USP_FetchUserProfileVSAS", new
                    {
                        @UserNTID = userNTID,
                        @PlantID = userPlantID,
                    },
                    commandType: CommandType.StoredProcedure);

                    UserProfile.UserProfileValueStream = result.Read<UserProfileValueStream>().ToList();
                    //UserProfile.UserProfileValueStream.ForEach(r=>r.)
                    UserProfile.UserProfileAssessor = result.Read<UserProfileAssessor>().ToList();
                    UserProfile.UsercustomIcon = result.Read<UsercustomIcon>().ToList();
                    UserProfile.UserEmployeeID = result.Read<int>().FirstOrDefault();

                    return UserProfile;
                });
            }
            catch (Exception ex)
            {
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return UserProfile;
            }
        }

        

        //    public async Task<Result> updateEmployeeID(UserProfileUpdateVSAS updateVSAS)
        //{
        //    var userProfileVSAS = Utility.Utility.ObjectToXMLGeneric(updateVSAS);

        //    Result UserDetails = new Result();

        //    Result data = new Result();
        //    try
        //    {
        //        return data;
        //    }
        //    catch (Exception ex)
        //    {
        //        data.ResultCode = 9;
        //        Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
        //        return data;
        //    }
        //}

      


        public async Task<Result> AddEditUserProfileVSAS(UserProfileValueStreamAssessor userProfile)
        {
            var userProfileVSXML = Utility.Utility.ObjectToXMLGeneric(userProfile.UserProfileValueStream);
            var userProfileASXML = Utility.Utility.ObjectToXMLGeneric(userProfile.UserProfileAssessor);

            int userProfileCustomIcon = 0;
            int userProfileCustomIcon1 = 0;
            if (userProfile.UsercustomIcon.Count ==1)
            {
                userProfileCustomIcon = userProfile.UsercustomIcon[0].customeIconID;
            }
            if (userProfile.UsercustomIcon.Count == 2)
            {
                userProfileCustomIcon = userProfile.UsercustomIcon[0].customeIconID;
                userProfileCustomIcon1 = userProfile.UsercustomIcon[1].customeIconID;
            }
            Result UserDetails = new Result();

                Result data = new Result();
                try
                {
                    return await (new DapperContext()).WithConnection(async c =>
                    {
                        var result = await c.QueryAsync("USP_AddEditUserProfileVSAS", new
                        {
                            @UserProfileVSXML = userProfileVSXML,
                            @UserProfileASXML = userProfileASXML,
                            @PlantID = userPlantID,
                            @CurrentUserNTID = userNTID,
                            @customeIconID = userProfileCustomIcon,
                            @customeIconID1= userProfileCustomIcon1
                        },
                        commandType: CommandType.StoredProcedure);
                        data.ResultCode = 0;

                        return data;
                    });
                }
                catch (Exception ex)
                {
                    data.ResultCode = 9;
                    Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                    return data;
                }
        }


        public async Task<Result> UpdateUserProfileVSAS(UserProfileUpdateVSAS updateVSAS)
        {
            var userProfileVSAS = Utility.Utility.ObjectToXMLGeneric(updateVSAS);

            Result UserDetails = new Result();

            Result data = new Result();
            try
            {
                return await (new DapperContext()).WithConnection(async c =>
                {
                    var result = await c.QueryAsync("USP_UpdateUserProfileVSAS", new
                    {
                        @UserProfileVSAS = userProfileVSAS,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,
                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;

                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        public async Task<Result> updateEmployeeID()
        {
            Result UserDetails = new Result();

            Result data = new Result();
            try
            {
                using (IDbConnection db = new System.Data.SqlClient.SqlConnection(new DapperContext().ConnectionString))
                {
                    string updateQuery = @"UPDATE [T_MST_User] SET [EmployeeID] =1  WHERE plantid = @PlantID and NTID=@CurrentUserNTID";

                    var result = db.Execute(updateQuery, new
                    {
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,
                    });
                }
                return data;
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }
    }
}
