﻿using Dapper;
using ELPC.Core;
using ELPC.DAL.Interfaces;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using ELPC.Utility;
using Serilog;

namespace ELPC.DAL.Implementation
{
    public class DataPoolRepository : DapperContext, IDataPoolRepository
    {
        public async Task<List<ProcessConfirmation>> GetDeviationDataPool(SearchFilter filter = null)
        {
            try
            {
                var resultDeviationDataPool = await WithConnection(async c =>
                {
                    var resultData = await c.QueryAsync<ProcessConfirmation>(sql: "USP_GetDeviationDataPool", new
                    {
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,
                        @FromDate = filter.FromDate,
                        @ToDate = filter.ToDate,
                        @IsDesigner= filter.IsDesigner,

                    },
                    commandType: System.Data.CommandType.StoredProcedure);
                    return resultData.ToList();
                });

                var finalList = new List<ProcessConfirmation>();
                var flist = resultDeviationDataPool.ToList();
                foreach (var process in flist)
                {

                    var etList = new List<EditTagList>();
                    var uList = new List<AddEmpList>();
                    var tList = new List<TagList>();
                    if(!string.IsNullOrEmpty(process.EmpList))
                    {
                        var List = process.EmpList.Split(',');
                        uList = List.Select(r => new AddEmpList { MyUserNmae = r}).ToList();
                        
                    }
                    if (!string.IsNullOrEmpty(process.MultiTagID))
                    {
                        var Listid = process.MultiTagID.Split(',');
                        
                        var ListName = process.MultiTagList.Split(',');

                        tList = ListName.Zip(Listid).Select(r => new TagList { TagName = r.First, MyTagID = r.Second }).ToList();

                    }


                    if (!string.IsNullOrEmpty(process.TagIDList))
                    {
                        var idList = process.TagIDList.Split(',');

                        var fileNamList = !string.IsNullOrEmpty(process.TagNameList) ? process.TagNameList : process.AssessorNameList;
                        if (string.IsNullOrEmpty(fileNamList))
                        {
                            continue;
                        }
                        var nameList = fileNamList.Split(',');
                        etList = nameList.Zip(idList).Select(r=> new EditTagList { MyTagName = r.First, MyTagID = r.Second}).ToList();
                    }
                    process.EditTagList = etList;
                    process.AddEmpList = uList;
                    process.TagList  = tList;
                    process.TagIDList = "";
                    process.TagNameList = "";
                    process.AssessorIDList = "";
                    process.AssessorNameList = "";
                    finalList.Add(process);
                }

               return finalList;
            }
            catch (Exception ex)
            {
                Log.Error("GetDeviationDataPool-Failure: " + Newtonsoft.Json.JsonConvert.SerializeObject(ex, Newtonsoft.Json.Formatting.Indented));
                throw ex;
            }
        }

        public async Task<List<HintImage>> GetDeviationFileByAttachmentID(int attachmentID)
        {
            try
            {
                return await WithConnection(async c =>
                {
                    var list = await c.QueryAsync<HintImage>(
                        "USP_GetDeviationFileByAttachmentID", new
                        {
                            @DeviationAttachmentsID = attachmentID,
                            @PlantID = userPlantID,
                            @CurrentUserNTID = userNTID,

                        },
                        commandType: CommandType.StoredProcedure);
                    foreach (HintImage image in list)
                    {
                        image.FileContent = Convert.ToBase64String(image.ByteData);
                        //image.FileContent = "data:image/png;base64," + image.FileContent;
                    }
                    return list.ToList();
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<ProcessConfirmation>> GetDataPool(SearchFilter filter = null)
        {
            try
            {
                var dataPoolEntrires = await WithConnection(async c =>
                {
                    var processConfirmationList = await c.QueryAsync<ProcessConfirmation>(sql: "USP_GetDataPool",
                        new
                        {
                            @PlantID = userPlantID,
                            @CurrentUserNTID = userNTID,
                            @FromDate = filter.FromDate,
                            @ToDate = filter.ToDate,
                            @IsDesigner =filter.IsDesigner,
                        },
                        commandType: System.Data.CommandType.StoredProcedure);

                    return processConfirmationList.ToList(); 
                });


                var TagDetailsList = await new TagRepository().GetTags();
                var distinctTagIDList = dataPoolEntrires.Select(r => r.TagIDList).Distinct();
                var distinctTagNameList = new Dictionary<string, List<EditTagList>>();
                foreach (var tagIDList in distinctTagIDList)
                {
                   
                    if (!string.IsNullOrEmpty(tagIDList))
                    {
                        var idList = tagIDList.Split(',');
                        var res = TagDetailsList.Where(r => idList.Contains(r.TagID.ToString())).Select(r => new EditTagList { MyTagName = r.TagName, MyTagID = r.TagID.ToString() }).ToList();
                        distinctTagNameList.Add(tagIDList , res);
                    }
                }


                var AssessorList = await new AssessorTemplateRepository().GetAssessors();
                var distinctAssessorIDList = dataPoolEntrires.Select(r => r.AssessorIDList).Distinct();
                var distinctAssessorNameList = new Dictionary<string, List<AssessorList>>();
                foreach (var assessorIDList in distinctAssessorIDList)
                {
                    if (!string.IsNullOrEmpty(assessorIDList))
                    {
                        var idList = assessorIDList.Split(',');
                        var res = AssessorList.Where(r => idList.Contains(r.AssessorID.ToString())).Select(r => new AssessorList { AssessorName = r.AssessorName, AssessorID = r.AssessorID.ToString() }).ToList();
                        distinctAssessorNameList.Add(assessorIDList, res);
                    }
                }

                var finalList = new List<ProcessConfirmation>();
                foreach (var process in dataPoolEntrires)
                {
                    //for Tag list binding
                    var etList = new List<EditTagList>();
                    var uList = new List<AddEmpList>();
                    var tList = new List<TagList>();
                    if (!string.IsNullOrEmpty(process.EmpList))
                    {
                        var List = process.EmpList.Split(',');
                        uList = List.Select(r => new AddEmpList { MyUserNmae = r }).ToList();

                    }
                    if (!string.IsNullOrEmpty(process.MultiTagID))
                    {
                        var Listid = process.MultiTagID.Split(',');

                        var ListName = process.MultiTagList.Split(',');

                        tList = ListName.Zip(Listid).Select(r => new TagList { TagName = r.First, MyTagID = r.Second }).ToList();

                    }
                    if (!string.IsNullOrEmpty(process.TagIDList) && distinctTagNameList.ContainsKey(process.TagIDList))
                    {
                        etList = distinctTagNameList[process.TagIDList];
                    }
                    process.EditTagList = etList;
                    process.AddEmpList = uList;
                    process.TagList = tList;
                    process.TagIDList = "";
                    process.TagNameList = "";

                    //for Assessor list binding
                    var assessorList = new List<AssessorList>();
                    if (!string.IsNullOrEmpty(process.AssessorIDList) && distinctAssessorNameList.ContainsKey(process.AssessorIDList))
                    {
                        assessorList = distinctAssessorNameList[process.AssessorIDList];
                    }

                    process.AssessorList = assessorList;
                    process.AssessorIDList = "";
                    process.AssessorNameList = "";

                    finalList.Add(process);
                }

                return finalList;
            }
            catch (Exception ex)
            {
                Log.Error("GetDataPool-Failure: " + Newtonsoft.Json.JsonConvert.SerializeObject(ex, Newtonsoft.Json.Formatting.Indented));
                throw ex;
            }
        }

        public async Task<List<ProcessConfirmation>> GetProcessConfirmationByID(int dataPoolID)
        {
            try
            {
                return await WithConnection(async c =>
                {
                    var list = await c.QueryAsync<ProcessConfirmation>(
                        "USP_EditDataPool", new
                        {
                            @DataPoolID = dataPoolID,
                            @PlantID = userPlantID,
                            @CurrentUserNTID = userNTID,

                        },
                       commandType: CommandType.StoredProcedure);
                    return list.ToList();
                });
            }
            catch (Exception Ex)
            {

                throw Ex;
            }

        }

        public async Task<List<HintImage>> HintImagesByDeviationID(int deviationID)
        {
            try
            {


                return await WithConnection(async c =>
                {
                    var list = await c.QueryAsync<HintImage>(
                        "USP_HintImagesByDeviationID", new
                        {
                            @deviationID = deviationID,
                            @PlantID = userPlantID,
                            @CurrentUserNTID = userNTID,

                        },
                       commandType: CommandType.StoredProcedure);
                    foreach (HintImage image in list)
                    {
                        image.FileContent = Convert.ToBase64String(image.ByteData);
                        image.FileContent = "data:image/png;base64," + image.FileContent;
                    }
                    return list.ToList();
                });
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public async Task<Result> UpdateDataPool(ProcessConfirmation processConfirmation)
        {
            Result data = new Result();

            try
            {
                var hintImages = Utility.Utility.ObjectToXMLGeneric(processConfirmation.HintImages);
                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_UpdateDataPool", new
                    {
                        @ModeTypeID = processConfirmation.ModeTypeID,
                        @ValueStreamID = processConfirmation.ValueStreamID,
                        @AssessorID = processConfirmation.AssessorID,
                        @QuestionID = processConfirmation.QuestionID,
                        @Answer = processConfirmation.Answer,
                        @AnswerType_AnswerTypeID = processConfirmation.AnswerType_AnswerTypeID,

                        @TagId = processConfirmation.TagID,
                        @IsDeviation = processConfirmation.isDeviation,
                        @ObtainedSCore = processConfirmation.ObtainedScore,
                        @DeviationDescription = processConfirmation.DeviationDescription,
                        @ResponsibleEmployee = processConfirmation.ResponsibleEmployee,

                        @HintImages = hintImages,
                        @ChoiceID = processConfirmation.ChoiceID,
                        @DataPoolID = processConfirmation.DataPoolID,
                        @DeviationID = processConfirmation.DeviationID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    }, commandTimeout: CommandTimeoutSeconds,
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }
        public async Task<Result> DeleteDataPool(ProcessConfirmation processConfirmation)
        {
            Result data = new Result();
            try
            {
                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_DeleteDataPool", new
                    {
                        @DataPoolID = processConfirmation.DataPoolID,
                        @ModifiedAt = processConfirmation.ModifiedAt,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        public async Task<List<DataPoolHistory>> GetDataPoolHistory(int templateID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<DataPoolHistory>(
                    "USP_DataPoolTemplateHistory", new
                    {
                        @DataPoolID = templateID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<Result> DataPoolRestoreByTemplateHistoryID(int historyID)
        {
            Result data = new Result();
            try
            {
                return await WithConnection(async c =>
                {
                    var list = await c.QueryAsync<ValueStream>(
                        "USP_Restore_T_TRN_DataPoolHistory", new
                        {
                            @DataPoolHistoryID = historyID,
                            @PlantID = userPlantID,
                            @CurrentUserNTID = userNTID,
                        },
                       commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }


        //*******************************Export Excel*******************************************************

        public DataSet DataPoolExportExcelTemplate(string UspName, bool IsUserReport = false, List<int> IDs = default)
        {
            try
            {
                DataSet ds = new DataSet();
                string constr = new Utility.Utility().GetConfigValue("ConnectionString", userPlantInfo.PlantCode);
                string query = UspName;

                using (SqlConnection con = new SqlConnection(constr))
                {
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.CommandTimeout = CommandTimeoutSeconds;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@PlantID", SqlDbType.Int).Value = userPlantID;
                        cmd.Parameters.Add("@CurrentUserNTID", SqlDbType.NVarChar).Value = userNTID;
                        if (UspName == "USP_ExportPlantReport")
                        {
                            cmd.Parameters.Add("@IsUserReport", SqlDbType.Bit).Value = IsUserReport;
                        }
                        if(IDs != null && IDs.Count > 0)
                        {
                            cmd.Parameters.Add(new SqlParameter("@selectedIds", Utility.Utility.ObjectToXMLGeneric(IDs)));
                        }
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(ds);
                        }
                    }
                }
               return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

       

        public DataSet DataPoolExportExcelTemplateFilter(string UspName,string fromDate,string toDate, bool IsUserReport = false, List<int> IDs = default)
        {
            try
            {
                DataSet ds = new DataSet();
                string constr = new Utility.Utility().GetConfigValue("ConnectionString", userPlantInfo.PlantCode);
                string query = UspName;

                using (SqlConnection con = new SqlConnection(constr))
                {
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.CommandTimeout = CommandTimeoutSeconds;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@PlantID", SqlDbType.Int).Value = userPlantID;
                        cmd.Parameters.Add("@CurrentUserNTID", SqlDbType.NVarChar).Value = userNTID;
                        cmd.Parameters.Add("@FromDate", SqlDbType.NVarChar).Value = fromDate;
                        cmd.Parameters.Add("@ToDate", SqlDbType.NVarChar).Value = toDate;

                        if (UspName == "USP_ExportPlantReportOneYear")
                        {
                            cmd.Parameters.Add("@IsUserReport", SqlDbType.Bit).Value = IsUserReport;
                        }
                        if (IDs != null && IDs.Count > 0)
                        {
                            cmd.Parameters.Add(new SqlParameter("@selectedIds", Utility.Utility.ObjectToXMLGeneric(IDs)));
                        }
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(ds);
                        }
                    }
                }
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


    }
        //*********************************Export Excel Ends Here********************************************    
}
