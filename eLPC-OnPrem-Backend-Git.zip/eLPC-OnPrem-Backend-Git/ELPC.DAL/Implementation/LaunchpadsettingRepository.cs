﻿using Dapper;
using ELPC.Core;
using ELPC.DAL.Interfaces;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ELPC.DAL.Implementation
{

    public class LaunchpadsettingRepository : DapperContext, ILaunchpadsettingRepository
    {
        public async Task<Result> InsertLaunchpadURL(ReportText reportText)
        {
            Result data = new Result();

            try
            {

                var x = Utility.Utility.ObjectToXMLGeneric(reportText.Reports);
                //var y = Utility.Utility.ObjectToXMLGeneric(assessorTemplate.Assessors);

                var dt = new DataTable();
                //dt.Columns.Add("Id", typeof(int));
                dt.Columns.Add("Text", typeof(string));
                dt.Columns.Add("URL", typeof(string));
                dt.Columns.Add("IsDeleted", typeof(bool));
                dt.Columns.Add("ModifiedAt", typeof(DateTime));
                dt.Columns.Add("CreatedAt", typeof(DateTime));
                dt.Columns.Add("PlantID", typeof(int));
                dt.Columns.Add("CreatedBy", typeof(string));
                dt.Columns.Add("ModifiedBy", typeof(string));
                dt.Columns.Add("HistoryID", typeof(int));
                //dt.Columns.Add("HistoryID", typeof(int));

                //foreach (var id in reportText.Reports)
                //{
                //    dt.Rows.Add( reportText.Reports[0].AssessorName, reportText.Reports[0].Category, 0, reportText.CreatedAt, reportText.CreatedAt);
                //    dt.Rows.Add( reportText.Reports[1].AssessorName, reportText.Reports[1].Category,0, reportText.CreatedAt, reportText.CreatedAt);
                //}

                for (int i = 0; i < reportText.Reports.Count; i++)
                {
                    dt.Rows.Add(reportText.Reports[i].AssessorName, reportText.Reports[i].Category, reportText.Reports[i].Isdeleted, reportText.CreatedAt, reportText.CreatedAt, userPlantID,userNTID,userNTID);
                    
                }



                return await (new DapperContext()).WithConnection(async c =>
                {
                    var result = await c.QueryAsync<ReportText>("[USP_AddEditLaunchPadSettings]", new
                    {
                        //@AssessorTemplateName = assessorTemplate.AssessorTemplateName,

                        @Assessors = dt,
                        //@IsLocked = reportText.IsLocked,
                        //@ModifiedAt = reportText.ModifiedAt,
                        //@CreatedAt = reportText.CreatedAt,


                        //@IsDeleted = false,
                        @PlantID = userPlantID,
                        //@CurrentUserNTID = userNTID,
                    },
                    commandType: CommandType.StoredProcedure);
                    //data.ResultCode = 0;
                    if (result.Count() > 0)
                    {
                        data.ResultCode = 0;
                        data.InsertedID = result.FirstOrDefault().reportTextID;
                    }
                    else
                    {
                        data.ResultCode = 9;
                    }
                    return data;
                });
            }
            catch (Exception ex)
            {
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                data.ResultCode = 9;
                data.ResultMessage = "Failed";
                return data;
            }
        }
        public async Task<Result> LaunchpadHistoryID(int historyID)
        {
            Result data = new Result();
            try
            {
                return await WithConnection(async c =>
                {
                    var list = await c.QueryAsync<ValueStream>(
                        "USP_RestoreLaunchPadSettings", new
                        {
                            @HistoryID = historyID,
                            @PlantID = userPlantID,
                            @CurrentUserNTID = userNTID,

                        },
                       commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<ReportText>> GetLaunchpad()
        {

            Result data = new Result();
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<ReportText>(
                     "USP_FetchLaunchpadSetting", new
                     {
                         @PlantID = userPlantID
                     },

                    commandType: CommandType.StoredProcedure);

               return list.ToList(); ;

            });
        }

        public async Task<List<Reportrestore>> GetRestoredata()
        {

            Result data = new Result();
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<Reportrestore>(
                     "USP_FetchRestoredata", new
                     {
                         @PlantID = userPlantID
                     },

                    commandType: CommandType.StoredProcedure);

                return list.ToList(); ;

            });
        }
    }

}