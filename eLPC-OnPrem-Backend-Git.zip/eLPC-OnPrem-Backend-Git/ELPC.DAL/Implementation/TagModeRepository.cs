﻿using ELPC.Core;
using ELPC.DAL.Interfaces;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Dapper;
using System.Linq;
using System.Data;
using Serilog;

namespace ELPC.DAL.Implementation
{
    public class TagModeRepository: DapperContext, ITagModeRepository
    {
        public async Task<List<TagMode>> GetTagModeByNTID(string NTID)
        {
            try
            {
                var data = await WithConnection(async c =>
                {
                    var objDetails = await c.QueryMultipleAsync("USP_GetTagModeByNTID", new
                    {
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                        commandType: System.Data.CommandType.StoredProcedure);
                    TagMode ObjMaster = new TagMode();

                    //Assigning each Multiple tables data to specific single model class  
                    ObjMaster.tags = objDetails.Read<Tag>().ToList();
                    ObjMaster.questions = objDetails.Read<Question>().ToList();

                    List<TagMode> TagObj = new List<TagMode>();
                    //Add list of records into MasterDetails list  
                    TagObj.Add(ObjMaster);

                    return TagObj.ToList();

                });

                return data;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task<Result> InsertToTagMode(TagMode tagMode)
        {
            Result data = new Result();

            try
            {
                var x = Utility.Utility.ObjectToXMLGeneric(tagMode.tags);
                var y = Utility.Utility.ObjectToXMLGeneric(tagMode.questions);

                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_AddEditTagMode", new
                    {
                        @TagModeID = tagMode.TagModeID,
                        @CreatedAt = tagMode.CreatedAt,
                        @IsDeleted = tagMode.IsDeleted,
                        @IsCompleted = tagMode.IsCompleted,
                        @AssignedTags = x,
                        @AssignedQuestions = y,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }


        public async Task<List<Tag>> GetTagModeTags()
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<Tag>(
                     "USP_FetchTagModeTags", new
                     {
                         @PlantID = userPlantID,
                         @CurrentUserNTID = userNTID,

                     },

                    commandType: CommandType.StoredProcedure);


                return list.ToList();

            });
        }

        public async Task<List<Tag>> GetTagModeTagsCalendar()
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<Tag>(
                     "USP_FetchTagModeTagsCalendar", new
                     {
                         @PlantID = userPlantID,
                         @CurrentUserNTID = userNTID,

                     },

                    commandType: CommandType.StoredProcedure);


                return list.ToList();

            });
        }


        public async Task<List<Question>> GetTagQuestions()
        {
            return await WithConnection(async c =>
            {
                var x = await c.QueryAsync<Question>(
                     "USP_FetchQuestion", new
                     {

                     },
                    commandType: CommandType.StoredProcedure);
                return x.ToList();

            });
        }


        public async Task<Result> DeleteTagMode(TagMode tagMode)
        {
            Result data = new Result();
            var TagID = tagMode.tag.TagID;
            try
            {
                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_DeleteTagMode", new
                    {
                        @QuestionID = tagMode.question.QuestionID,
                        @TagID = tagMode.tag.TagID,
                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }


        public async Task<List<Question>> GetInfoQuestionsByTagID(int tagID)
        {
            try
            {
                return await WithConnection(async c =>
                {
                    var list = await c.QueryAsync<Question>(
                        "USP_GetInfoQuestionsByTagID", new
                        {
                            @TagID = tagID,
                            @PlantID = userPlantID,

                        },
                       commandType: CommandType.StoredProcedure);
                    return list.ToList();
                });
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }


        public async Task<Result> AddEditTagModeQuestion(AuditQuestion auditQuestion)
        {
            Result data = new Result();
            try
            {
                var x = Utility.Utility.ObjectToXMLGeneric(auditQuestion.AuditAssessors);
                var y = Utility.Utility.ObjectToXMLGeneric(auditQuestion.Others);
                //var z = Utility.Utility.ObjectToXMLGeneric(audit.OptionalAttendees);


                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_AddEditTagModeQuestion", new
                    {
                        @ID = auditQuestion.ID,
                        @TagTemplateID = auditQuestion.TagTemplateID,
                        @TagID = auditQuestion.TagID,
                        @QuestionID = auditQuestion.QuestionID,
                        @IsDeleted = 0,
                        @CreatedBy_NTID = auditQuestion.CreatedBy_NTID,
                        @ModifiedBy_NTID = auditQuestion.ModifiedBy_NTID,
                        @AnswerTypeID = auditQuestion.AnswerTypeID,
                        @Answer = auditQuestion.Answer,
                        @IsAnswered = auditQuestion.IsAnswered,
                        @IsAnswerRequired = auditQuestion.IsAnswerRequired,
                        @Assessors = x,
                        @Others = y
                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }


        public async Task<List<AuditQuestion>> FetchTagModeQuestionsByCurrentAssessorAndTemplateID(int tagID, string NTID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<AuditQuestion>(
                    "USP_FetchTagModeQuestionsByCurrentAssessorAndTemplateID", new
                    {
                        @TagID = tagID,
                        @NTID = NTID
                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }


    }
}
