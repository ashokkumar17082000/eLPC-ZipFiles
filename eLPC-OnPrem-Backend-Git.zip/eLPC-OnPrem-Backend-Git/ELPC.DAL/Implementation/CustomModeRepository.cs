﻿using ELPC.Core;
using ELPC.DAL.Interfaces;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Dapper;
using System.Linq;
using System.Data;
using Serilog;





namespace ELPC.DAL.Implementation
{
   public class CustomModeRepository:DapperContext,ICustomModeRepository
    {
        
        public async Task<List<CustomMode>> GetCustomModeByNTID(string NTID)
        {
            try
            {
                var data= await WithConnection(async c =>
                {
                    var objDetails = await c.QueryMultipleAsync("USP_GetCustomModeByNTID", new
                    {
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                        commandType: System.Data.CommandType.StoredProcedure);
                    CustomMode ObjMaster = new CustomMode();

                    //Assigning each Multiple tables data to specific single model class  
                    ObjMaster.tags = objDetails.Read<Tag>().ToList();
                    ObjMaster.questions = objDetails.Read<Question>().ToList();

                    List < CustomMode > CustomObj = new List<CustomMode>();
                    //Add list of records into MasterDetails list  
                    CustomObj.Add(ObjMaster);

                    return CustomObj.ToList();

                });

                return data;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task<Result> InsertCustomMode(CustomMode customMode)
        {
            Result data = new Result();
            try
            {
                var x = Utility.Utility.ObjectToXMLGeneric(customMode.tags);
                var y = Utility.Utility.ObjectToXMLGeneric(customMode.questions);

                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_AddEditCustomMode", new
                    {
                        @CustomModeID = customMode.CustomModeID,
                        @CreatedAt = customMode.CreatedAt,
                        @IsDeleted = customMode.IsDeleted,
                        @IsCompleted=customMode.IsCompleted,
                        @AssignedTags = x,
                        @AssignedQuestions = y,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }



        public async Task<Result> RemoveFromCustomModeList(CustomMode customMode)
        {
            Result data = new Result();
            try
            {
                return await (new DapperContext()).WithConnection(async c =>
                {
                    var result = await c.QueryAsync("USP_RemoveFromCustomModeList", new
                    {
                        @NTID=customMode.CreatedBy_NTID,
                        @CustomQuestionTagsID =(customMode.tag.TagID == null || customMode.tag.TagID == 0 ) ? customMode.question.CustomQuestionTagsID : customMode.tag.CustomQuestionTagsID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        public async Task<List<Tag>> GetCustomTags()
        {
            return await WithConnection(async c =>
            {

                var list = await c.QueryAsync<Tag>(
                     "USP_FetchCustomTag", new
                     {
                         @PlantID = userPlantID,
                         @CurrentUserNTID = userNTID,

                     },

                    commandType: CommandType.StoredProcedure);


                return list.ToList();

            });
        }

        public async Task<List<Question>> GetCustomQuestions()
        {
            return await WithConnection(async c =>
            {
                var x = await c.QueryAsync<Question>(
                     "USP_FetchQuestion", new
                     {

                     },
                    commandType: CommandType.StoredProcedure);
                return x.ToList();

            });
        }


    }
}
