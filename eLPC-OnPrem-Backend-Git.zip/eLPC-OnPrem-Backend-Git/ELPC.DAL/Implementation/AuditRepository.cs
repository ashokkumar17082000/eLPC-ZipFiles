﻿using Dapper;
using ELPC.Core;
using ELPC.DAL.Interfaces;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Serilog;
using ELPC.Utility;

namespace ELPC.DAL.Implementation
{
    public class AuditRepository : DapperContext, IAuditRepository
    {
        //public async Task<List<Audit>> GetAudits()
        //{
        //    return await WithConnection(async c =>
        //    {
        //        var Audits = await c.QueryAsync<Audit>(
        //             "USP_FetchAudit", new
        //             {
        //             },
        //            commandType: CommandType.StoredProcedure);
        //        return Audits.ToList();

        //    });
        //}

        public async Task<List<Audit>> FetchAuditsByNTID(string ntid, string currentMonth, string currentYear)
        {

            int Year = Convert.ToInt32(currentYear);
            int Month = Convert.ToInt32(currentMonth);
            DateTime date = new DateTime(Year, Month, 1);
            var firstDayOfMonth = new DateTime(date.Year, date.Month, 1);
            var FromDate = firstDayOfMonth.ToString("MMM dd yyyy");
            var ToDate = firstDayOfMonth.AddMonths(1).AddDays(-1).ToString("MMM dd yyyy");
            return await WithConnection(async c =>
            {
                var Audits = await c.QueryAsync<Audit>(
                     "USP_FetchAudit", new
                     {
                         @PlantID = userPlantID,
                         @CurrentUserNTID = ntid,
                         @FromDate= FromDate,
                         @ToDate=ToDate,

                     },
                    commandType: CommandType.StoredProcedure);
                
                try
                {
                    Audits = Utility.Utility.GetCalendarOccurances(Audits.ToList(), "Calendar", currentYear, currentMonth);

                   
                }
                catch (Exception ex)
                {
                    Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                    throw;
                }
                return Audits.ToList();
            });
        }

        public async Task<Audit> InsertAudit(Audit audit)
        {
            Audit data = new Audit();
            try
            {

                var x = Utility.Utility.ObjectToXMLGeneric(audit.AssignedTags);
                var y = Utility.Utility.ObjectToXMLGeneric(audit.RequiredAttendees);
                var z = Utility.Utility.ObjectToXMLGeneric(audit.OptionalAttendees);
                var p = Utility.Utility.ObjectToXMLGeneric(audit.ValueStreams);

                x = x.Replace("encoding=\"utf-16\"", "");
                y = y.Replace("encoding=\"utf-16\"", "");
                z = z.Replace("encoding=\"utf-16\"", "");
                p = p.Replace("encoding=\"utf-16\"", "");

                return await (new DapperContext()).WithConnection(async c =>
                {

                    var list = await c.QueryAsync<Audit>("USP_AddEditAudit", new
                    {

                        @PlantID = userPlantID,
                        @AuditID = audit.AuditID,
                        @StartDate = string.Format("{0:yyyy-MM-dd HH:mm:ss}", audit.StartDate),
                        @EndDate = string.Format("{0:yyyy-MM-dd HH:mm:ss}", audit.EndDate),
                        @StartTime = audit.StartTime,
                        @EndTime = audit.EndTime,
                        @IsRecurring = audit.IsRecurring,
                        @IsAllDay = audit.IsAllDay,
                        @ValueStreamID = audit.ValueStreamID,
                        @ValueStreams = p,
                        @Remarks = audit.Remarks,
                        @IsDeleted = audit.IsDeleted,
                        @IsAuditCompleted = audit.IsAuditCompleted,
                        @AssignedTags = x,
                        @RequiredAttendees = y,
                        @OptionalAttendees = z,
                        @TagID = audit.TagID,
                        @Location = audit.Location,

                        @CurrentUserNTID = userNTID,
                        @Recurrence_TypeId = audit.Recurrence_TypeId,
                        @Recurrence_Interval = audit.Recurrence_Interval,
                        @Recurrence_DayOfWeek = audit.Recurrence_DayOfWeek,
                        @Recurrence_DayOfMonth = audit.Recurrence_DayOfMonth,
                        @Recurrence_WeekOfMonth = audit.Recurrence_WeekOfMonth,
                        @Recurrence_MonthOfYear = audit.Recurrence_MonthOfYear
                    },
                    commandType: CommandType.StoredProcedure);
                    return list.FirstOrDefault();
                });
            }
            catch (Exception ex)
            {
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        public async Task<Result> AddEditAuditQuestion(AuditQuestion auditQuestion)
        {
            Result data = new Result();
            try
            {
                var x = Utility.Utility.ObjectToXMLGeneric(auditQuestion.AuditAssessors);
                var y = Utility.Utility.ObjectToXMLGeneric(auditQuestion.Others);
                //var z = Utility.Utility.ObjectToXMLGeneric(audit.OptionalAttendees);


                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_AddEditAuditQuestion", new
                    {
                        @ID = auditQuestion.ID,
                        @AuditTemplateID = auditQuestion.AuditTemplateID,
                        @AuditID = auditQuestion.AuditID,
                        @QuestionID = auditQuestion.QuestionID,
                        @IsDeleted = 0,
                        @AnswerTypeID = auditQuestion.AnswerTypeID,
                        @Answer = auditQuestion.Answer,
                        @IsAnswered = auditQuestion.IsAnswered,
                        @IsAnswerRequired = auditQuestion.IsAnswerRequired,
                        @Assessors = x,
                        @Others = y,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,
                        // @CreatedAt = auditQuestion.CreatedAt
                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        public async Task<Result> DeleteAudit(Audit audit)
        {
            Result data = new Result();
            try
            {
                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_DeleteAudit", new
                    {
                        @AuditID = audit.AuditID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,
                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                data.ResultCode = 9;
                return data;
            }
        }

        public async Task<Audit> AuditByAuditID(int auditID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<Audit>(
                    "USP_AuditByAuditID", new
                    {
                        @AuditID = auditID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                   commandType: CommandType.StoredProcedure);


                List<String> list1 = new List<String>();


                foreach (var each in list)
                {

                    list1.Add(each.ValueStreamName);

                }
                foreach (var each1 in list)
                {
                    each1.ValueStreamNames = list1;
                }

                List<int> res1 = new List<int>();

                foreach (var each in list)
                {

                    res1.Add(each.ValueStreamID);

                }
                foreach (var each1 in list)
                {
                    each1.ValueStreamIDs = res1;
                }

                return list.FirstOrDefault();
            });
        }

        public async Task<List<AuditQuestion>> AuditQuestionsByAuditID(int auditID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<AuditQuestion>(
                    "USP_AuditQuestionsByAuditID", new
                    {
                        @AuditID = auditID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },

                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<List<AuditQuestion>> AuditQuestionsByAuditIDSelectedValuestream(int auditID, int valueStreamID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<AuditQuestion>(
                    "USP_AuditQuestionsByAuditIDSelectedValuestream", new
                    {
                        @AuditID = auditID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,
                        @valueStreamID = valueStreamID,
                    },
                     commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<List<AuditAssessor>> AuditAssessorsByAuditID(int auditID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<AuditAssessor>(
                    "USP_AuditAssessorsByAuditID", new
                    {
                        @AuditID = auditID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<List<AuditQuestion>> AuditQuestionsByAuditAndAssessorID(int auditID, string NTID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<AuditQuestion>(
                    Constants.USP_FETCHAUDITQUESTIONSBYAUDITANDASSESSORID, new
                    {
                        @AuditID = auditID,
                        @NTID = NTID
                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        /// <summary>
        /// To find out the pending audits by Audit ID
        /// </summary>
        /// <param name="auditID"></param>
        /// <param name="NTID"></param>
        /// <returns></returns>
        public async Task<List<AuditQuestion>> PendingAuditsByAuditID(int auditID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<AuditQuestion>(
                    "USP_PendingAuditsByAuditID", new
                    {
                        @AuditID = auditID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public int resetAuditByAuditID(int auditID)
        {
            Console.WriteLine(auditID);
            using (IDbConnection db = new System.Data.SqlClient.SqlConnection(new DapperContext().ConnectionString))
            {
                string updateQuery = @"UPDATE [T_LNK_Audit_AnsweredQuestions] SET [isauditactive] = 0 WHERE AuditID = @auditID";

                var result = db.Execute(updateQuery, new
                {
                    auditID,
                });
            }
            return 1;

        }

        public async Task<List<AuditQuestion>> AuditQuestionsByCurrentAssessorAndTemplateID(int auditID, string NTID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<AuditQuestion>(
                    "USP_FetchAuditQuestionsByCurrentAssessorAndTemplateID", new
                    {
                        @AuditID = auditID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<List<HintImage>> GetHintImagesByAuditDeviationID(int auditDeviationID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<HintImage>(
                    "USP_HintImagesByAuditDeviationID", new
                    {
                        @AuditDeviationID = auditDeviationID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                   commandType: CommandType.StoredProcedure);
                foreach (HintImage image in list)
                {
                    image.FileContent = Convert.ToBase64String(image.ByteData);
                    image.FileContent = "data:image/png;base64," + image.FileContent;
                }
                return list.ToList();
            });
        }

        public async Task<List<AuditQuestion>> AuditQuestionsByAuditAndTemplateID(int auditID, int templateID, int ValueStreamID)
        {
            return await WithConnection(async c =>
            {
                var questionlist = await c.QueryAsync<AuditQuestion>(Constants.USP_FETCHAUDITQUESTIONSBYAUDITANDTEMPLATEID, new
                {
                    @AuditID = auditID,
                    @AuditTemplateID = templateID,
                    @ValueStreamID = ValueStreamID,
                    @PlantID = userPlantID,
                    @CurrentUserNTID = userNTID,

                }, commandType: CommandType.StoredProcedure);

                var deviationList = await c.QueryAsync<Deviation>("USP_FetchAuditDeviationByAuditAndTemplateID", new
                {
                    @AuditID = auditID,
                    @AuditTemplateID = templateID,
                    @ValueStreamID = ValueStreamID,
                    @PlantID = userPlantID,
                    @CurrentUserNTID = userNTID,

                }, commandType: CommandType.StoredProcedure);

                foreach (var auditDeviation in deviationList)
                {
                    auditDeviation.HintImages = await GetHintImagesByAuditDeviationID(auditDeviation.AuditDeviationID);

                    foreach (var question in questionlist)
                    {
                        if (question.QuestionID == auditDeviation.QuestionID)
                        {
                            question.Deviation = auditDeviation;
                        }
                    }
                }
                return questionlist.ToList();
            });
        }

        public async Task<Result> CompleteAuditByAuditAndTemplateID(int auditID, int templateID)
        {
            Result data = new Result();
            try
            {
                return await (new DapperContext()).WithConnection(async c =>
                {
                    var result = await c.QueryAsync("USP_CompleteAuditByAuditAndTemplateID", new
                    {
                        @AuditID = auditID,
                        @AuditTemplateID = templateID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }
        public async Task<Result> UpdateAuditQuestion(AuditQuestion auditQuestion)
        {
            Result data = new Result();
            try
            {

                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_UpdateAuditQuestion", new
                    {
                        @ID = auditQuestion.ID,
                        @Answer = auditQuestion.Answer,
                        @AuditID = auditQuestion.AuditID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }


        public async Task<List<AuditAssessor>> AuditAssessorsByAuditAndTemplateID(int auditID, int templateID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<AuditAssessor>(
                    "USP_FetchAssessorDetailByAuditAndTemplateID", new
                    {
                        @AuditID = auditID,
                        @TemplateID = templateID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<List<AuditAssessor>> OtherAuditAssessorsByAuditAndTemplateID(int auditID, int templateID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<AuditAssessor>(
                    "USP_FetchOtherAssessorDetailByAuditAndTemplateID", new
                    {
                        @AuditID = auditID,
                        @TemplateID = templateID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<List<ValueStream>> ValueStreamsByTagID(int tagID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<ValueStream>(
                    "USP_FetchValueStreamsByTagID", new
                    {
                        @TagID = tagID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        /// <summary>
        ///  To validate the standard user based on audit and NTID
        /// </summary>
        /// <param name="auditID"></param>
        /// <param name="NTID"></param>
        /// <returns></returns>
        public async Task<User> ValidateAssessorByAuditAndNTID(int auditID, string NTID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<User>(
                    "USP_ValidateAssessorByAuditAndNTID", new
                    {
                        @NTID = NTID,
                        @AuditID = auditID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList().FirstOrDefault();
            });
        }

        public async Task<List<User>> RequiredAttendeesByAuditID(int auditID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<User>(
                    "USP_FetchRequiredAttendeesByAuditID", new
                    {
                        @AuditID = auditID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<List<User>> OptionalAttendeesByAuditID(int auditID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<User>(
                    "USP_FetchOptionalAttendeesByAuditID", new
                    {
                        @AuditID = auditID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        private async Task<List<EmailData>> GetEmailTemplate(string LanguageCode, string TemplateName)
        {
            return await WithConnection(async c =>
            {
                var tempcontent = await c.QueryAsync<EmailData>(
                    "USP_GetMailTemplate", new
                    {
                        @Language = LanguageCode,
                        @Template = TemplateName,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                   commandType: CommandType.StoredProcedure);
                return tempcontent.ToList();
            });
        }
        /// <summary>
        /// Sending email for the Required and Optional attendess of an audit
        /// </summary>
        /// <param name="audit"></param>
        /// <returns></returns>
        public async Task<Result> EmailToAttendees(Audit audit, Dictionary<string, byte[]> emailimage)
        {

            var Tomail = "";
            var ccmail = "";
            foreach (User usr in audit.RequiredAttendees)
            {
                if (Tomail.Length > 0)
                    Tomail += ";" + usr.EmailAddress;
                else
                    Tomail += usr.EmailAddress;
            }
            foreach (User usr in audit.OptionalAttendees)
            {

                if (ccmail.Length > 0)
                    ccmail += ";" + usr.EmailAddress;
                else
                    ccmail += usr.EmailAddress;
            }

            audit.PlantCode = userPlantInfo.PlantCode;
            var mailTemplate = GetEmailTemplate(audit.LanguageCode, "Invitation").Result.FirstOrDefault();
            var icsTemplate = GetEmailTemplate(audit.LanguageCode, "ICS_Invitation").Result.FirstOrDefault();
            String res = "";
            foreach (var each in audit.ValueStreams)
            {

                res += each.ValueStreamName + ",";

            }
            res = res.Remove(res.Length - 1, 1);

            audit.ValueStreamName = res;
            Utility.Utility.SendMail(audit, audit.EmailAddress, Tomail, ccmail, mailTemplate.Subject, mailTemplate.Content, icsTemplate.Content, emailimage);
            return new Result { ResultMessage = "Success", ResultCode = 0 };
        }


        public async Task<Result> InsertAuditDetail(AuditDetail auditDetail)
        {
            Result data = new Result();
            try
            {
                return await (new DapperContext()).WithConnection(async c =>
                {
                    var leadAuditor = Utility.Utility.ObjectToXMLGeneric(auditDetail.LeadAuditor);
                    var hod = Utility.Utility.ObjectToXMLGeneric(auditDetail.HOD);
                    var floorManager = Utility.Utility.ObjectToXMLGeneric(auditDetail.FloorManager);
                    var qmm = Utility.Utility.ObjectToXMLGeneric(auditDetail.QMM);
                    var others = Utility.Utility.ObjectToXMLGeneric(auditDetail.Others);


                    List<User> Users = new List<User>();
                    Users.Add(auditDetail.LeadAuditor);
                    Users.Add(auditDetail.HOD);
                    Users.Add(auditDetail.FloorManager);
                    Users.Add(auditDetail.QMM);
                    Users.AddRange(auditDetail.Others);

                    var users = Utility.Utility.ObjectToXMLGeneric(Users);

                    var result = await c.QueryAsync("USP_AddEditAuditDetail", new
                    {
                        @AuditDetailID = auditDetail.AuditDetailID,
                        @AuditID = auditDetail.AuditID,
                        @ValueStreamID = auditDetail.ValueStreamID,
                        @LeadAuditor = auditDetail.LeadAuditor.NTID,
                        @HOD = auditDetail.HOD.NTID,
                        @FloorManager = auditDetail.FloorManager.NTID,
                        @QMM = auditDetail.QMM.NTID,
                        @CreatedBy_UserID = auditDetail.CreatedBy_UserID,
                        @ModifiedBy_UserID = auditDetail.ModifiedBy_UserID,
                        @Others = "",
                        @Users = users

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        public async Task<Result> AuditQuestionLinkedTagDetails(TagDetails tagDetails)
        {
            Result data = new Result();

            try
            {
                return await (new DapperContext()).WithConnection(async c =>
                {
                    var result = await c.QueryAsync<string>("SELECT ListTag FROM[FN_GetNestedTagsByQuestionID](@questionID, @option) where ListTag is not null", new
                    {
                        questionID = tagDetails.QuestionID,
                        option = tagDetails.ResponseType,
                    },
                    commandType: CommandType.Text);

                    if (result.FirstOrDefault() != null)
                    {
                        data.ResultMessage = result.FirstOrDefault().ToString();
                        return data;
                    }
                    else
                        return data;
                });
            }
            catch (Exception ex)
            {
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }

        }
        //SendTagModeAnswerSummaryEmail

        public async Task<Result> SendTagModeAnswerSummaryEmail(ProcessConfirmation processConfirmation)
        {
            Result data = new Result();
            AuditAnswerSummary summary = new AuditAnswerSummary();
            List<AuditSummaryQuestionAnswers> answers = new List<AuditSummaryQuestionAnswers>();
            if (processConfirmation.TagModeID != 0)
            {
                try
                {
                    await (new DapperContext()).WithConnection(async c =>
                    {
                        var result = await c.QueryMultipleAsync("USP_GetTagModeAuditMailData", new
                        {
                            @TagID = processConfirmation.TagID,
                            @TagModeID = processConfirmation.TagModeID,
                            @PlantID = processConfirmation.PlantID,
                            @CurrentUserNTID = processConfirmation.AnsweredBy_NTID,
                            @ValueStreamID = processConfirmation.ValueStreamID,

                        },
                        commandType: CommandType.StoredProcedure);

                        summary = result.Read<AuditAnswerSummary>().FirstOrDefault();
                        summary.TagName = processConfirmation.TagName; //processConfirmation.TagName;
                        summary.TagTypeName = processConfirmation.TagTypeName;//processConfirmation.TagTypeName;
                        summary.PlantID = userPlantInfo.PlantID;
                        summary.PlantCode = userPlantInfo.PlantCode;
                        answers = result.Read<AuditSummaryQuestionAnswers>().ToList();

                        Dictionary<string, byte[]> emailimage = new Dictionary<string, byte[]>();
                        byte[] b = System.Convert.FromBase64String("iVBORw0KGgoAAAANSUhEUgAABTwAAAAWCAMAAAGtRZPEAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAABjUExURZMiMLAlOK4YFtQTFoozemY4jVg7jkw9j0M/jz5AkCk2hCA4gBo5gSNboi19tS+TwCWjzCikywCmzACemgCdXWCxbYi8bjmfWCmMQHw1hBekyQCcXxGgYTCnZRc7hCeMPwAAAHvN38EAAAAhdFJOU///////////////////////////////////////////AJ/B0CEAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAo+SURBVGhD1ZuLYtu2EgXrxg/Fdpu0jZubuk3+/y8vdncA4m2AJFx1xEiMZDHIcngAkPRPCTfGzz9/KLi9U+6Fi/Dx0fHk+O55dqvyhnzwS+BX+Jzw+8aXmJc/Ay8vPyJoIUw1VFoq7XrWRka81dDfHDRSoInGK610vLz8L4IWwlhDHx7Khgb6DZU2KjRS8E00aKVALQ1aaIR2lg29jRp60ZL6dtJAt9fdvpe/p7ueZma7njYqNNSgjUJ7z9POm0o9P3wLzYwUfXItfe7veVr56ydaWOz4pJ1xPds7nmZWd/w3bag280H3fNpOT7OdvoVAGx20sNzxnSMphjaDc6HW+pJbK7yh/y3H5e5ykRcTRtV2uHAQUdz/tIn7TD+2L8TeB6jDhu60Ckl1EqhUDWqW8uLSiP2cQ/EqUMjAWDk/fKCUilVTcK48XD4264k1CVJHj31hqJ5UD8wyz18UMIPaJaDh35QwJVEygeJVoIww6ucN+WVQTCunxq7W82LF0WI6XL0oYRP7wmA9f8uquJHkYYAK+hKmUMGUv6leCcUroY4wWs7QHzjuo3rKkW6xW5aTkkU8f3e9nCwB+0atnlRxAzFrUL8C6lmB+qW4w70pKNUroZCeiXoSoPdbPaWWVHM73N3BHg53zcgS97Yt/nh/oogRVHGD2pW09Pz9D4pXgQpmvLx8JS5zhuspBaVkfXx3dB/7qdXcuiMVNK4nXqaZGaPVdFDECKq4QfUSuod7W8/X15agre7o/HpSzrSeaXyaoNV6RlghQYvpoIgRVHGDEgKVNGbq2YvP9uF++vFe95Pu3ddTS/NWPQ0r5556UsMECphBBYFCAhXMoHgVqF4JdfSM1jP0R2U9MdTrGdfzrf59Mj+pXgkFzKCQE/07xatA9SagwHWk7ArlPcrN7W0yQRBkP9lKgdtdYWVDEsYPKuy40NcIPQZGcT8dLzp5tQ90uxHs8j5o0MGOt1mQZRScmgO9BpAxUWdY1ALnJkDEBth5lp6SH6JnpKioqXqaiBGmpghpowlPqqcIKm7GgqpdWejw3gheVbYfQMA+ONhmO/ExALnmmPMT3yb5B/kGMDsZBY1yup4IiltnICbe2TkjRfUs0MGtg25PXEVO9Iz8bOmJly3sh3qw/QAC9kHCNm/riZAZiDcGvo1BR+3AvRF2ZOf56Ul8otYJ5F17Q0/18t49ILITPTmj5dipZ4T9fE44ZeNBwD5I2AYHM3Cww0x8dubbAYxMmOje/3z5inMT4NwEaNjA7DzPTzf2NCsDDT0FERQ7Lxc/t806d51D1PWc8LNAv84/4anMPCogYRt8dEaOSBn4/An1RsDAHCTsgXsD/INyM+DcBHhYAzUF7DqIzIxyPRV8jFARtY9n8aicW3R6ENPh3DI/vaVV5AJevFRgywH864ODHabGnhuIN8hIfBbg3Qg69JzPT5ybABWr4Oap4en0zDp4l584GeNMtGeBNwTTM5oZoWYQVNwzBUdwP5osfhPyEZv3IGAfHOyAbrPg3SAINwfqjWB6It04ODcBJtbBztP0dPH5LbMzzNrdmrxsOBc3P3kNI8/LYzI3Snt28yv00mPgp//2qpnRDj21b8e7QRBujvpV3yroyYx8lFVjT+w6Tq1vJz1zOVFTVit6RnZ29ZwR1AiO2sYjMLALDnbAuSF01Gng3SAINwnujSB2fv33TyydrKe//ywm6JkJqlr6V1VTQM949NnXM0M/GmHf4BMHO2DeW2BloHELTJ35oadMi+L7IN9iT3j+F/QszixZ9y6vGW62DpipYKePT1VT/gTELPULH0v007fR7UcMzdxxsAP6dUDIlKneHecG0Sm7MHnZiAHlBDg3ARq2WKJnMfoUG+P0VDHDSU+3usUndsbxOaunR3+qjW18Y72emFhj6rzSuJ54CXO9+xWc91yUntFVo2p6PtizJzrpebhzb6NfirCNb6zUEwk7nJ+eOBkzdVUT5WbAuQnQsIHZ+U5To01QS04vqAvT88aeA+i33VZs64FnDOyCgx0Q0vj0+dPo2XnMGwIB66BijaneHeVmwLkJ8LAOdp6mp5xYys8sVdPTtLQXATcdwc6xE0sHsI1vIGAfHGwTzso7L10mtm9fz5g589mYGeFgD9wbAeOmwLkJELEKcjrQ6yhyWr6mpyiZpKcSde9bBx/03Cj0NLBsN7bxDQTsg4RtRE/MnAT3BnjFRw/uDTDRu2PcFDi3EtSdBtETsPZKkINHkAPIHULZURSQw8k/2SHlnuLsN9xsTh53+uBX3mSGF5bL/eM2Ztn4KA+4JFfHAu54ZAl3LSe47sMdpduBmq7vwrZXXVrQGIWGN+HgPgFS4BAuQf7SHu49IFLWQD6tZ+KSzgRyfiiwYyo+BwG3ErJwByTmBqF1NRCePjeLUUgEyanp2chOe7ILCxKXGpk82aNKHJ4O0iVGxzKy1KOzFp4LCOFZLkBrBGt4G5LvBMi/QxBri9HRnYtpcm4JRNs7MDEqnIDcFJZn53WHZ5GeZNb1oNlpg852bjL2jLOzEp4hImVVhp76jr6lT/aokIVnkZ4am7YMh+cTs8Tn7XE+ITsry1vp+Z3oOw75dwjSbQXFfHjp0HPXXZU7mbgePg7BKbh048r4Iq48PPP4JLKuCMtOG3PaSg2XnD467SFLhqUmj7AiwWkLfy3JwrOYue8JT4vOCu+VprS9DdF3HPLvCDvvFu/QO4W4cuhJri1GTkd+mbocPg7J+R7ZefXhmaQngXVVMPDszdh9eMa52Rh5aoa6FR15+oddYrAQdU+P9hrIR5752PNZInMuPJ+IygGiND0zT2l7G6LvOATgEc4Kz8GrLuuGnksHnnoJJ2LtxF0m7aTcKq4/POP4JK+ui9nwtPgsw/NyJ4ve2OIfKfdygbYy9izCMxt6njryfJsoSw+kKW1vQ/QdhwA8Atm3FzJxHKLufIi5kyEsS5ZM3C0915/wdBBwKyED90JwCsTVVXEjoXnKyFPvVpUbWsjNPDzl/pb0VwCMIjyJF8+O8JwYeQ6wJ0xpexui7zgE4BEIwVGIwL2su2R07sCThOywcOJOvK2FgFsJIbgPYhMIrCvCXy86PvLU2AzhWSbn4/1F0lPuVnpj2k68eHaE5+GbCvsMpCltb0P0HYcAPAKh2MVN7Qm/EyDszobU2wmJOMOy+5VIt8UQcCshBvdAZgZIrOtBr7a7ZNTsbMfnzMjTkrMMT3vLkjMZf+bhSbp47JTnZHguTs+cKE3JU2t7G5LvBAjAA9RPecbvurw7MTonfzl8mD0DT1JwL4tOe77LpP3Kw5PI3CCyrgbNTi6321M9QMdHnrpi+VnDDT3T5HRk4Um6JEyPPN87PXP+s+GpA0xZOTctE9zWibtz+ZL/Kk8NUu8slpz2fKfsvObwJDATCK0rwbJTfoM0hGedU0aeOmN35PGZhifhkrBj5Pkvh2fxy4Q5JN8JkIAHcDnpx5kLIzNhxdDzj9dmeJJ0KyDvzuSdJu0/fvwffpsKlc5rSTkAAAAASUVORK5CYII=");
                        emailimage.Add("header", b);


                        var mailTemplate = GetEmailTemplate(processConfirmation.LanguageCode, "AnswerSummary").Result.FirstOrDefault();
                        Utility.Utility.AnswerSummaryMail(mailTemplate.Subject, mailTemplate.Content, emailimage, summary, answers);
                        return result;
                    });
                    return new Result { ResultMessage = "Success", ResultCode = 0 };
                }
                catch (Exception ex)
                {
                    Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                    return new Result { ResultMessage = "Failure", ResultCode = 0 };
                }

            }
            if (processConfirmation.CustomModeID != 0)
            {
                try
                {
                    await (new DapperContext()).WithConnection(async c =>
                    {
                        var result = await c.QueryMultipleAsync("USP_GetCustomModeAuditMailData", new
                        {
                            @TagID = processConfirmation.TagID,
                            @CustomModeID = processConfirmation.CustomModeID,
                            @PlantID = processConfirmation.PlantID,
                            @CurrentUserNTID = processConfirmation.AnsweredBy_NTID,
                            @ValueStreamID = processConfirmation.ValueStreamID,

                        },
                        commandType: CommandType.StoredProcedure);

                        summary = result.Read<AuditAnswerSummary>().FirstOrDefault();
                        summary.TagName = "CustomMode";
                        summary.TagTypeName = "Custom";
                        summary.PlantID = userPlantInfo.PlantID;
                        summary.PlantCode = userPlantInfo.PlantCode;
                        answers = result.Read<AuditSummaryQuestionAnswers>().ToList();

                        Dictionary<string, byte[]> emailimage = new Dictionary<string, byte[]>();
                        byte[] b = System.Convert.FromBase64String("iVBORw0KGgoAAAANSUhEUgAABTwAAAAWCAMAAAGtRZPEAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAABjUExURZMiMLAlOK4YFtQTFoozemY4jVg7jkw9j0M/jz5AkCk2hCA4gBo5gSNboi19tS+TwCWjzCikywCmzACemgCdXWCxbYi8bjmfWCmMQHw1hBekyQCcXxGgYTCnZRc7hCeMPwAAAHvN38EAAAAhdFJOU///////////////////////////////////////////AJ/B0CEAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAo+SURBVGhD1ZuLYtu2EgXrxg/Fdpu0jZubuk3+/y8vdncA4m2AJFx1xEiMZDHIcngAkPRPCTfGzz9/KLi9U+6Fi/Dx0fHk+O55dqvyhnzwS+BX+Jzw+8aXmJc/Ay8vPyJoIUw1VFoq7XrWRka81dDfHDRSoInGK610vLz8L4IWwlhDHx7Khgb6DZU2KjRS8E00aKVALQ1aaIR2lg29jRp60ZL6dtJAt9fdvpe/p7ueZma7njYqNNSgjUJ7z9POm0o9P3wLzYwUfXItfe7veVr56ydaWOz4pJ1xPds7nmZWd/w3bag280H3fNpOT7OdvoVAGx20sNzxnSMphjaDc6HW+pJbK7yh/y3H5e5ykRcTRtV2uHAQUdz/tIn7TD+2L8TeB6jDhu60Ckl1EqhUDWqW8uLSiP2cQ/EqUMjAWDk/fKCUilVTcK48XD4264k1CVJHj31hqJ5UD8wyz18UMIPaJaDh35QwJVEygeJVoIww6ucN+WVQTCunxq7W82LF0WI6XL0oYRP7wmA9f8uquJHkYYAK+hKmUMGUv6leCcUroY4wWs7QHzjuo3rKkW6xW5aTkkU8f3e9nCwB+0atnlRxAzFrUL8C6lmB+qW4w70pKNUroZCeiXoSoPdbPaWWVHM73N3BHg53zcgS97Yt/nh/oogRVHGD2pW09Pz9D4pXgQpmvLx8JS5zhuspBaVkfXx3dB/7qdXcuiMVNK4nXqaZGaPVdFDECKq4QfUSuod7W8/X15agre7o/HpSzrSeaXyaoNV6RlghQYvpoIgRVHGDEgKVNGbq2YvP9uF++vFe95Pu3ddTS/NWPQ0r5556UsMECphBBYFCAhXMoHgVqF4JdfSM1jP0R2U9MdTrGdfzrf59Mj+pXgkFzKCQE/07xatA9SagwHWk7ArlPcrN7W0yQRBkP9lKgdtdYWVDEsYPKuy40NcIPQZGcT8dLzp5tQ90uxHs8j5o0MGOt1mQZRScmgO9BpAxUWdY1ALnJkDEBth5lp6SH6JnpKioqXqaiBGmpghpowlPqqcIKm7GgqpdWejw3gheVbYfQMA+ONhmO/ExALnmmPMT3yb5B/kGMDsZBY1yup4IiltnICbe2TkjRfUs0MGtg25PXEVO9Iz8bOmJly3sh3qw/QAC9kHCNm/riZAZiDcGvo1BR+3AvRF2ZOf56Ul8otYJ5F17Q0/18t49ILITPTmj5dipZ4T9fE44ZeNBwD5I2AYHM3Cww0x8dubbAYxMmOje/3z5inMT4NwEaNjA7DzPTzf2NCsDDT0FERQ7Lxc/t806d51D1PWc8LNAv84/4anMPCogYRt8dEaOSBn4/An1RsDAHCTsgXsD/INyM+DcBHhYAzUF7DqIzIxyPRV8jFARtY9n8aicW3R6ENPh3DI/vaVV5AJevFRgywH864ODHabGnhuIN8hIfBbg3Qg69JzPT5ybABWr4Oap4en0zDp4l584GeNMtGeBNwTTM5oZoWYQVNwzBUdwP5osfhPyEZv3IGAfHOyAbrPg3SAINwfqjWB6It04ODcBJtbBztP0dPH5LbMzzNrdmrxsOBc3P3kNI8/LYzI3Snt28yv00mPgp//2qpnRDj21b8e7QRBujvpV3yroyYx8lFVjT+w6Tq1vJz1zOVFTVit6RnZ29ZwR1AiO2sYjMLALDnbAuSF01Gng3SAINwnujSB2fv33TyydrKe//ywm6JkJqlr6V1VTQM949NnXM0M/GmHf4BMHO2DeW2BloHELTJ35oadMi+L7IN9iT3j+F/QszixZ9y6vGW62DpipYKePT1VT/gTELPULH0v007fR7UcMzdxxsAP6dUDIlKneHecG0Sm7MHnZiAHlBDg3ARq2WKJnMfoUG+P0VDHDSU+3usUndsbxOaunR3+qjW18Y72emFhj6rzSuJ54CXO9+xWc91yUntFVo2p6PtizJzrpebhzb6NfirCNb6zUEwk7nJ+eOBkzdVUT5WbAuQnQsIHZ+U5To01QS04vqAvT88aeA+i33VZs64FnDOyCgx0Q0vj0+dPo2XnMGwIB66BijaneHeVmwLkJ8LAOdp6mp5xYys8sVdPTtLQXATcdwc6xE0sHsI1vIGAfHGwTzso7L10mtm9fz5g589mYGeFgD9wbAeOmwLkJELEKcjrQ6yhyWr6mpyiZpKcSde9bBx/03Cj0NLBsN7bxDQTsg4RtRE/MnAT3BnjFRw/uDTDRu2PcFDi3EtSdBtETsPZKkINHkAPIHULZURSQw8k/2SHlnuLsN9xsTh53+uBX3mSGF5bL/eM2Ztn4KA+4JFfHAu54ZAl3LSe47sMdpduBmq7vwrZXXVrQGIWGN+HgPgFS4BAuQf7SHu49IFLWQD6tZ+KSzgRyfiiwYyo+BwG3ErJwByTmBqF1NRCePjeLUUgEyanp2chOe7ILCxKXGpk82aNKHJ4O0iVGxzKy1KOzFp4LCOFZLkBrBGt4G5LvBMi/QxBri9HRnYtpcm4JRNs7MDEqnIDcFJZn53WHZ5GeZNb1oNlpg852bjL2jLOzEp4hImVVhp76jr6lT/aokIVnkZ4am7YMh+cTs8Tn7XE+ITsry1vp+Z3oOw75dwjSbQXFfHjp0HPXXZU7mbgePg7BKbh048r4Iq48PPP4JLKuCMtOG3PaSg2XnD467SFLhqUmj7AiwWkLfy3JwrOYue8JT4vOCu+VprS9DdF3HPLvCDvvFu/QO4W4cuhJri1GTkd+mbocPg7J+R7ZefXhmaQngXVVMPDszdh9eMa52Rh5aoa6FR15+oddYrAQdU+P9hrIR5752PNZInMuPJ+IygGiND0zT2l7G6LvOATgEc4Kz8GrLuuGnksHnnoJJ2LtxF0m7aTcKq4/POP4JK+ui9nwtPgsw/NyJ4ve2OIfKfdygbYy9izCMxt6njryfJsoSw+kKW1vQ/QdhwA8Atm3FzJxHKLufIi5kyEsS5ZM3C0915/wdBBwKyED90JwCsTVVXEjoXnKyFPvVpUbWsjNPDzl/pb0VwCMIjyJF8+O8JwYeQ6wJ0xpexui7zgE4BEIwVGIwL2su2R07sCThOywcOJOvK2FgFsJIbgPYhMIrCvCXy86PvLU2AzhWSbn4/1F0lPuVnpj2k68eHaE5+GbCvsMpCltb0P0HYcAPAKh2MVN7Qm/EyDszobU2wmJOMOy+5VIt8UQcCshBvdAZgZIrOtBr7a7ZNTsbMfnzMjTkrMMT3vLkjMZf+bhSbp47JTnZHguTs+cKE3JU2t7G5LvBAjAA9RPecbvurw7MTonfzl8mD0DT1JwL4tOe77LpP3Kw5PI3CCyrgbNTi6321M9QMdHnrpi+VnDDT3T5HRk4Um6JEyPPN87PXP+s+GpA0xZOTctE9zWibtz+ZL/Kk8NUu8slpz2fKfsvObwJDATCK0rwbJTfoM0hGedU0aeOmN35PGZhifhkrBj5Pkvh2fxy4Q5JN8JkIAHcDnpx5kLIzNhxdDzj9dmeJJ0KyDvzuSdJu0/fvwffpsKlc5rSTkAAAAASUVORK5CYII=");
                        emailimage.Add("header", b);


                        var mailTemplate = GetEmailTemplate(processConfirmation.LanguageCode, "AnswerSummary").Result.FirstOrDefault();
                        Utility.Utility.AnswerSummaryMail(mailTemplate.Subject, mailTemplate.Content, emailimage, summary, answers);
                        return result;
                    });
                    return new Result { ResultMessage = "Success", ResultCode = 0 };
                }
                catch (Exception ex)
                {
                    Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                    return new Result { ResultMessage = "Failure", ResultCode = 0 };
                }


            }
            return new Result { ResultMessage = "Success", ResultCode = 0 };
        }

        public async Task<Result> SendAnswerSummaryEmail(Audit audit)
        {
            Result data = new Result();

            AuditAnswerSummary summary = new AuditAnswerSummary();
            List<AuditSummaryQuestionAnswers> answers = new List<AuditSummaryQuestionAnswers>();
            try
            {
                await (new DapperContext()).WithConnection(async c =>
                {
                    var result = await c.QueryMultipleAsync("USP_GetAuditMailData", new
                    {
                        @AuditTemplateID = audit.TemplateID,
                        @AuditID = audit.AuditID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,
                    },
                    commandType: CommandType.StoredProcedure);

                    summary = result.Read<AuditAnswerSummary>().FirstOrDefault();
                    summary.TagName = audit.TagName;
                    summary.TagTypeName = audit.TagTypeName;
                    summary.PlantID = userPlantInfo.PlantID;
                    summary.PlantCode = userPlantInfo.PlantCode;
                    answers = result.Read<AuditSummaryQuestionAnswers>().ToList();

                    Dictionary<string, byte[]> emailimage = new Dictionary<string, byte[]>();
                    byte[] b = System.Convert.FromBase64String("iVBORw0KGgoAAAANSUhEUgAABTwAAAAWCAMAAAGtRZPEAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAABjUExURZMiMLAlOK4YFtQTFoozemY4jVg7jkw9j0M/jz5AkCk2hCA4gBo5gSNboi19tS+TwCWjzCikywCmzACemgCdXWCxbYi8bjmfWCmMQHw1hBekyQCcXxGgYTCnZRc7hCeMPwAAAHvN38EAAAAhdFJOU///////////////////////////////////////////AJ/B0CEAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAo+SURBVGhD1ZuLYtu2EgXrxg/Fdpu0jZubuk3+/y8vdncA4m2AJFx1xEiMZDHIcngAkPRPCTfGzz9/KLi9U+6Fi/Dx0fHk+O55dqvyhnzwS+BX+Jzw+8aXmJc/Ay8vPyJoIUw1VFoq7XrWRka81dDfHDRSoInGK610vLz8L4IWwlhDHx7Khgb6DZU2KjRS8E00aKVALQ1aaIR2lg29jRp60ZL6dtJAt9fdvpe/p7ueZma7njYqNNSgjUJ7z9POm0o9P3wLzYwUfXItfe7veVr56ydaWOz4pJ1xPds7nmZWd/w3bag280H3fNpOT7OdvoVAGx20sNzxnSMphjaDc6HW+pJbK7yh/y3H5e5ykRcTRtV2uHAQUdz/tIn7TD+2L8TeB6jDhu60Ckl1EqhUDWqW8uLSiP2cQ/EqUMjAWDk/fKCUilVTcK48XD4264k1CVJHj31hqJ5UD8wyz18UMIPaJaDh35QwJVEygeJVoIww6ucN+WVQTCunxq7W82LF0WI6XL0oYRP7wmA9f8uquJHkYYAK+hKmUMGUv6leCcUroY4wWs7QHzjuo3rKkW6xW5aTkkU8f3e9nCwB+0atnlRxAzFrUL8C6lmB+qW4w70pKNUroZCeiXoSoPdbPaWWVHM73N3BHg53zcgS97Yt/nh/oogRVHGD2pW09Pz9D4pXgQpmvLx8JS5zhuspBaVkfXx3dB/7qdXcuiMVNK4nXqaZGaPVdFDECKq4QfUSuod7W8/X15agre7o/HpSzrSeaXyaoNV6RlghQYvpoIgRVHGDEgKVNGbq2YvP9uF++vFe95Pu3ddTS/NWPQ0r5556UsMECphBBYFCAhXMoHgVqF4JdfSM1jP0R2U9MdTrGdfzrf59Mj+pXgkFzKCQE/07xatA9SagwHWk7ArlPcrN7W0yQRBkP9lKgdtdYWVDEsYPKuy40NcIPQZGcT8dLzp5tQ90uxHs8j5o0MGOt1mQZRScmgO9BpAxUWdY1ALnJkDEBth5lp6SH6JnpKioqXqaiBGmpghpowlPqqcIKm7GgqpdWejw3gheVbYfQMA+ONhmO/ExALnmmPMT3yb5B/kGMDsZBY1yup4IiltnICbe2TkjRfUs0MGtg25PXEVO9Iz8bOmJly3sh3qw/QAC9kHCNm/riZAZiDcGvo1BR+3AvRF2ZOf56Ul8otYJ5F17Q0/18t49ILITPTmj5dipZ4T9fE44ZeNBwD5I2AYHM3Cww0x8dubbAYxMmOje/3z5inMT4NwEaNjA7DzPTzf2NCsDDT0FERQ7Lxc/t806d51D1PWc8LNAv84/4anMPCogYRt8dEaOSBn4/An1RsDAHCTsgXsD/INyM+DcBHhYAzUF7DqIzIxyPRV8jFARtY9n8aicW3R6ENPh3DI/vaVV5AJevFRgywH864ODHabGnhuIN8hIfBbg3Qg69JzPT5ybABWr4Oap4en0zDp4l584GeNMtGeBNwTTM5oZoWYQVNwzBUdwP5osfhPyEZv3IGAfHOyAbrPg3SAINwfqjWB6It04ODcBJtbBztP0dPH5LbMzzNrdmrxsOBc3P3kNI8/LYzI3Snt28yv00mPgp//2qpnRDj21b8e7QRBujvpV3yroyYx8lFVjT+w6Tq1vJz1zOVFTVit6RnZ29ZwR1AiO2sYjMLALDnbAuSF01Gng3SAINwnujSB2fv33TyydrKe//ywm6JkJqlr6V1VTQM949NnXM0M/GmHf4BMHO2DeW2BloHELTJ35oadMi+L7IN9iT3j+F/QszixZ9y6vGW62DpipYKePT1VT/gTELPULH0v007fR7UcMzdxxsAP6dUDIlKneHecG0Sm7MHnZiAHlBDg3ARq2WKJnMfoUG+P0VDHDSU+3usUndsbxOaunR3+qjW18Y72emFhj6rzSuJ54CXO9+xWc91yUntFVo2p6PtizJzrpebhzb6NfirCNb6zUEwk7nJ+eOBkzdVUT5WbAuQnQsIHZ+U5To01QS04vqAvT88aeA+i33VZs64FnDOyCgx0Q0vj0+dPo2XnMGwIB66BijaneHeVmwLkJ8LAOdp6mp5xYys8sVdPTtLQXATcdwc6xE0sHsI1vIGAfHGwTzso7L10mtm9fz5g589mYGeFgD9wbAeOmwLkJELEKcjrQ6yhyWr6mpyiZpKcSde9bBx/03Cj0NLBsN7bxDQTsg4RtRE/MnAT3BnjFRw/uDTDRu2PcFDi3EtSdBtETsPZKkINHkAPIHULZURSQw8k/2SHlnuLsN9xsTh53+uBX3mSGF5bL/eM2Ztn4KA+4JFfHAu54ZAl3LSe47sMdpduBmq7vwrZXXVrQGIWGN+HgPgFS4BAuQf7SHu49IFLWQD6tZ+KSzgRyfiiwYyo+BwG3ErJwByTmBqF1NRCePjeLUUgEyanp2chOe7ILCxKXGpk82aNKHJ4O0iVGxzKy1KOzFp4LCOFZLkBrBGt4G5LvBMi/QxBri9HRnYtpcm4JRNs7MDEqnIDcFJZn53WHZ5GeZNb1oNlpg852bjL2jLOzEp4hImVVhp76jr6lT/aokIVnkZ4am7YMh+cTs8Tn7XE+ITsry1vp+Z3oOw75dwjSbQXFfHjp0HPXXZU7mbgePg7BKbh048r4Iq48PPP4JLKuCMtOG3PaSg2XnD467SFLhqUmj7AiwWkLfy3JwrOYue8JT4vOCu+VprS9DdF3HPLvCDvvFu/QO4W4cuhJri1GTkd+mbocPg7J+R7ZefXhmaQngXVVMPDszdh9eMa52Rh5aoa6FR15+oddYrAQdU+P9hrIR5752PNZInMuPJ+IygGiND0zT2l7G6LvOATgEc4Kz8GrLuuGnksHnnoJJ2LtxF0m7aTcKq4/POP4JK+ui9nwtPgsw/NyJ4ve2OIfKfdygbYy9izCMxt6njryfJsoSw+kKW1vQ/QdhwA8Atm3FzJxHKLufIi5kyEsS5ZM3C0915/wdBBwKyED90JwCsTVVXEjoXnKyFPvVpUbWsjNPDzl/pb0VwCMIjyJF8+O8JwYeQ6wJ0xpexui7zgE4BEIwVGIwL2su2R07sCThOywcOJOvK2FgFsJIbgPYhMIrCvCXy86PvLU2AzhWSbn4/1F0lPuVnpj2k68eHaE5+GbCvsMpCltb0P0HYcAPAKh2MVN7Qm/EyDszobU2wmJOMOy+5VIt8UQcCshBvdAZgZIrOtBr7a7ZNTsbMfnzMjTkrMMT3vLkjMZf+bhSbp47JTnZHguTs+cKE3JU2t7G5LvBAjAA9RPecbvurw7MTonfzl8mD0DT1JwL4tOe77LpP3Kw5PI3CCyrgbNTi6321M9QMdHnrpi+VnDDT3T5HRk4Um6JEyPPN87PXP+s+GpA0xZOTctE9zWibtz+ZL/Kk8NUu8slpz2fKfsvObwJDATCK0rwbJTfoM0hGedU0aeOmN35PGZhifhkrBj5Pkvh2fxy4Q5JN8JkIAHcDnpx5kLIzNhxdDzj9dmeJJ0KyDvzuSdJu0/fvwffpsKlc5rSTkAAAAASUVORK5CYII=");
                    emailimage.Add("header", b);


                    var mailTemplate = GetEmailTemplate(audit.LanguageCode, "AnswerSummary").Result.FirstOrDefault();
                    Utility.Utility.AnswerSummaryMail(mailTemplate.Subject, mailTemplate.Content, emailimage, summary, answers);
                    return result;
                });
                return new Result { ResultMessage = "Success", ResultCode = 0 };
            }
            catch (Exception ex)
            {
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return new Result { ResultMessage = "Failure", ResultCode = 0 };
            }
        }

        public async Task<List<Audit>> FetchAuditStatusByType(string module, string currentMonth, string currentYear, int IsDesigner, string ntID)
        {
            var resultAuditAnswers = new List<Audit>();
            if (module == "Calendar")
            {
                int Year = Convert.ToInt32(currentYear);
                int Month = Convert.ToInt32(currentMonth);
                DateTime date = new DateTime(Year, Month, 1);
                var firstDayOfMonth = new DateTime(date.Year, date.Month, 1);
                var FromDate = firstDayOfMonth.ToString("MMM dd yyyy");
                var ToDate = firstDayOfMonth.AddMonths(1).AddDays(-1).ToString("MMM dd yyyy");
             


                resultAuditAnswers = await WithConnection(async c =>
                {
                    var AuditAnswers = await c.QueryAsync<Audit>(
                         "USP_FetchAuditAnswersCalendar", new
                         {
                             @PlantID = userPlantID,
                             @CurrentUserNTID = ntID,
                             @FromDate = FromDate,  //new DateTime(Year, Month, 1).ToString("MMM dd yyyy"),
                             @ToDate = ToDate  //new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month)).ToString("MMM dd yyyy")
                         },
                        commandType: CommandType.StoredProcedure);
                    return AuditAnswers.ToList();

                });
            }
            else
            {

               // int Year = Convert.ToInt32(currentYear);
               // int Month = Convert.ToInt32(currentMonth);
              //  DateTime date = new DateTime(Year, Month, 1);
                //var firstDayOfMonth = new DateTime(date.Year, date.Month, 1);
              //  var FromDate = firstDayOfMonth.ToString("MMM dd yyyy");
               // var ToDate = firstDayOfMonth.AddMonths(1).AddDays(-1).ToString("MMM dd yyyy");
                var FromDate1 = currentMonth;
                var ToDate1 = currentYear;
                if (IsDesigner == 1)
                {
                    if (module == "Report")
                    {
                        resultAuditAnswers = await WithConnection(async c =>
                        {
                            var AuditAnswers = await c.QueryAsync<Audit>(
                                 "USP_FetchAuditAnswers", new
                                 {
                                     @PlantID = userPlantID,
                                     @CurrentUserNTID = userNTID,
                                     @FromDate = FromDate1,  //new DateTime(Year, Month, 1).ToString("MMM dd yyyy"),
                                 @ToDate = ToDate1  //new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month)).ToString("MMM dd yyyy")
                             },
                                commandType: CommandType.StoredProcedure);
                            return AuditAnswers.ToList();

                        });
                    }else if( module== "ReportFiltered")
                    {
                        resultAuditAnswers = await WithConnection(async c =>
                        {
                            var AuditAnswers = await c.QueryAsync<Audit>(
                                 "USP_FetchAuditAnswers_old_ExportFiltered", new
                                 {
                                     @PlantID = userPlantID,
                                     @CurrentUserNTID = userNTID,
                                     @FromDate = FromDate1,  //new DateTime(Year, Month, 1).ToString("MMM dd yyyy"),
                                     @ToDate = ToDate1  //new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month)).ToString("MMM dd yyyy")
                                 },
                                commandType: CommandType.StoredProcedure);
                            return AuditAnswers.ToList();

                        });
                    }
                    else if (module == "ReportExportAll")
                    {
                        resultAuditAnswers = await WithConnection(async c =>
                        {
                            var AuditAnswers = await c.QueryAsync<Audit>(
                                 "USP_FetchAuditAnswers_old", new
                                 {
                                     @PlantID = userPlantID,
                                     @CurrentUserNTID = userNTID,
                                    // @FromDate = FromDate1,  //new DateTime(Year, Month, 1).ToString("MMM dd yyyy"),
                                     //@ToDate = ToDate1  //new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month)).ToString("MMM dd yyyy")
                                 },
                                commandType: CommandType.StoredProcedure);
                            return AuditAnswers.ToList();

                        });
                    }
                   
                }else
                {
                    resultAuditAnswers = await WithConnection(async c =>
                    {
                        var AuditAnswers = await c.QueryAsync<Audit>(
                             "USP_FetchAuditAnswersStandard", new
                             {
                                 @PlantID = userPlantID,
                                 @CurrentUserNTID = userNTID,
                                 @FromDate = FromDate1,  //new DateTime(Year, Month, 1).ToString("MMM dd yyyy"),
                                 @ToDate = ToDate1  //new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month)).ToString("MMM dd yyyy")
                             },
                            commandType: CommandType.StoredProcedure);
                        return AuditAnswers.ToList();

                    });

                }
               
            }
            try
            {
                var auditAnswerStatus = Utility.Utility.GetCalendarOccurances(resultAuditAnswers, module, currentYear, currentMonth);

                return auditAnswerStatus;
            }
            catch (Exception ex)
            {
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                throw;
            }
        }

        }
    }

