﻿using Dapper;
using ELPC.Core;
using ELPC.DAL.Interfaces;
using Serilog;
using System;
using System.Data;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;

namespace ELPC.DAL.Implementation
{
    public class SchedulerRepository : DapperContext, ISchedulerRepository
    {
        public async Task<Result> AddSchedular(Schedule schedule)
        {
            Result data = new Result();
            try
            {
                return await (new DapperContext()).WithConnection(async c =>
                {
                    var result = await c.QueryAsync<Schedule>("USP_AddSchedule", new
                    {
                        @PlantId = schedule.PlantId,
                        @ScheduleName = schedule.ScheduleName,
                        @DataObj = schedule.DataObj,
                        @ErrorDetail = schedule.ErrorDetail,
                        @CreatedBy_NTID = userNTID
                    }, commandType: CommandType.StoredProcedure);

                    data.ResultCode = 0;
                    data.InsertedID = result.FirstOrDefault().ScheduleId;

                    return data;
                });
            }
            catch (Exception ex)
            {
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                data.ResultCode = 9;
                return data;
            }
        }


        public async Task<Result> AddCreateOPL(Schedule schedule)
        {
            Result data = new Result();
            try
            {
                return await (new DapperContext()).WithConnection(async c =>
                {
                    var result = await c.QueryAsync<Schedule>("USP_AddCreateOPL", new
                    {
                        @PlantId = schedule.PlantId,
                        @ScheduleName = schedule.ScheduleName,
                        @DataObj = schedule.DataObj,
                        @ErrorDetail = schedule.ErrorDetail,
                        @CreatedBy_NTID = userNTID,

                    }, commandType: CommandType.StoredProcedure);

                    data.ResultCode = 0;
                    data.InsertedID = result.FirstOrDefault().ScheduleId;

                    return data;
                });
            }
            catch (Exception ex)
            {
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                data.ResultCode = 9;
                return data;
            }
        }

    }
}
