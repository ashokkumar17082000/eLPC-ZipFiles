﻿using ELPC.Core;
using ELPC.DAL.Interfaces;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Dapper;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using ELPC.Utility;
using Serilog;

namespace ELPC.DAL.Implementation
{
    public class ValueStreamTemplateRespository : DapperContext, IValueStreamTemplateRepository
    {
        public async Task<List<ValueStreamTemplate>> GetValueStreamTemplates()
        {
            return await WithConnection(async c =>
            {
                var ValueStreamTemplates = await c.QueryAsync<ValueStreamTemplate>(sql: "USP_FetchValuestreamTemplate", new
                {
                    @PlantID = userPlantID,
                    @CurrentUserNTID = userNTID,

                },
                    commandType: System.Data.CommandType.StoredProcedure);
                return ValueStreamTemplates.ToList();
            });
        }

        public async Task<List<RecycleBinTemplate>> GetRecycleBinTemplates()
        {
            return await WithConnection(async c =>
            {
                var ValueStreamTemplates = await c.QueryAsync<RecycleBinTemplate>(sql: "USP_FetchRecycleBinTemplate", new
                {
                    @PlantID = userPlantID,
                    @CurrentUserNTID = userNTID,

                },
                commandType: System.Data.CommandType.StoredProcedure);
                return ValueStreamTemplates.ToList();
            });
        }
        
        public async Task<List<RecycleBinTemplate>> RecycleBinHistory()
        {
            return await WithConnection(async c =>
            {
                var ValueStreamTemplates = await c.QueryAsync<RecycleBinTemplate>(sql: "USP_FetchRecycleBinHistory", new
                {
                    @PlantID = userPlantID,
                    @CurrentUserNTID = userNTID,

                },
                commandType: System.Data.CommandType.StoredProcedure);
                return ValueStreamTemplates.ToList();
            });
        }



        public async Task<Result> RestoreRecycleBin(List<RecycleBinTemplate> recycleTemplate)
        {
            //remove Rownumber properties form the list of object recycleTemplate
            var listWithoutExtraRowNumberColumn = recycleTemplate.Select(x => new { x.ID, x.PlantID, x.ItemType, x.ItemName, x.DeletedBy, x.ModifiedBy, x.Deleted, x.Selected}).ToList();
            DataTable recycleTable = DataTableConverter.ToDataTable(listWithoutExtraRowNumberColumn);
            //DataTable recycleTable = DataTableConverter.ToDataTable(recycleTemplate);
            Result data = new Result();
            try
            {
                return await WithConnection(async c =>
                {
                    var RecyclebinTemplate = await c.QueryAsync<Result>(sql: "USP_Restore_T_TRN_RecycleTable",
                         new
                         {
                             @recycleTable = recycleTable.AsTableValuedParameter(),
                             @PlantID = userPlantID,
                             @CurrentUserNTID = userNTID,

                         }, commandTimeout: CommandTimeoutSeconds,
                        commandType: System.Data.CommandType.StoredProcedure);
                    return RecyclebinTemplate.FirstOrDefault();
                });
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public async Task<Result> DeleteRecycleBin(List<RecycleBinTemplate> recycleTemplate)
        {
            //remove Rownumber properties form the list of object recycleTemplate
            var listWithoutExtraRowNumberColumn = recycleTemplate.Select(x => new { x.ID, x.PlantID, x.ItemType, x.ItemName, x.DeletedBy, x.ModifiedBy, x.Deleted, x.Selected }).ToList();
            DataTable recycleTable = DataTableConverter.ToDataTable(listWithoutExtraRowNumberColumn);
            //DataTable recycleTable = DataTableConverter.ToDataTable(recycleTemplate);
            Result data = new Result();
            try
            {
                return await WithConnection(async c =>
                {
                    var RecyclebinTemplate = await c.QueryAsync<Result>(sql: "USP_Delete_T_TRN_RecycleTable",
                         new
                         {
                             @recycleTable = recycleTable.AsTableValuedParameter(),
                             @PlantID = userPlantID,
                             @CurrentUserNTID = userNTID,

                         }, commandTimeout: CommandTimeoutSeconds,
                        commandType: System.Data.CommandType.StoredProcedure);
                    return RecyclebinTemplate.FirstOrDefault();
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<ValueStreamCategory>> GetValueStreamCategories()
        {
            return await WithConnection(async c =>
            {
                var ValueStreamCategories = await c.QueryAsync<ValueStreamCategory>(sql: "USP_FetchValueStreamCategory",
                    new
                    {
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: System.Data.CommandType.StoredProcedure);
                return ValueStreamCategories.ToList();
            });
        }

        public async Task<List<ValueStream>> GetValueStreams()
        {
            return await WithConnection(async c =>
            {
                var ValueStreams = await c.QueryAsync<ValueStream>(sql: "USP_FetchValueStream",
                     new
                     {
                         @PlantID = userPlantID,
                         @CurrentUserNTID = userNTID,

                     },
                    commandType: System.Data.CommandType.StoredProcedure);
                return ValueStreams.ToList();
            });
        }

        public async Task<List<ValueStreamHistory>> GetValueStreamsHistory(int templateID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<ValueStreamHistory>(
                    "USP_ValueStreamTemplateHistory", new
                    {
                        @ValueStreamTemplateID = templateID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<Result> ValueStreamRestoreByTemplateHistoryID(int historyID)
        {
            Result data = new Result();
            try
            {
                return await WithConnection(async c =>
                {
                    var list = await c.QueryAsync<ValueStream>(
                        "USP_Restore_T_LNK_ValueStreamHistory", new
                        {
                            @ValueStreamTemplateHistoryID = historyID,
                            @PlantID = userPlantID,
                            @CurrentUserNTID = userNTID,

                        },
                       commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<Result> InsertValueStreamTemplate(ValueStreamTemplate valuestreamtemplate)
        {
            Result data = new Result();
            try
            {
                var ValueStreamCategories = Utility.Utility.ObjectToXMLGeneric(valuestreamtemplate.ValueStreamCategories);
                var ValueStreams = Utility.Utility.ObjectToXMLGeneric(valuestreamtemplate.ValueStreams);
                var Shifts = Utility.Utility.ObjectToXMLGeneric(valuestreamtemplate.Shifts);
                return await (new DapperContext()).WithConnection(async c =>
                 {

                     var result = await c.QueryAsync<ValueStreamTemplate>("USP_AddEditValueStreamTemplate", new
                     {
                         @ValueStreamTemplateID = valuestreamtemplate.ValueStreamTemplateID,
                         @ValueStreamTemplateName = valuestreamtemplate.ValueStreamTemplateName,
                         @IsLocked = valuestreamtemplate.IsLocked,
                         @ModifiedAt = valuestreamtemplate.ModifiedAt,
                         @CreatedAt = valuestreamtemplate.CreatedAt,
                         @Delimiter = valuestreamtemplate.Delimiter,
                         @IsOperatedInShifts = valuestreamtemplate.IsOperatedInShifts,
                         @VisualizationViewModeID = valuestreamtemplate.VisualizationViewModeID,
                         @ValueStreamCategories = ValueStreamCategories,
                         @ValueStreams = ValueStreams,
                         @Shifts = Shifts,
                         @PlantID = userPlantID,
                         @CurrentUserNTID = userNTID,

                     },
                     commandType: CommandType.StoredProcedure, commandTimeout: CommandTimeoutSeconds);
                     //data.ResultCode = 0;
                     if (result.Count() > 0 )
                     {
                         data.ResultCode = 0;
                         data.InsertedID = result.FirstOrDefault().ValueStreamTemplateID;
                     }
                     else
                     {
                         data.ResultCode = 9;
                     }
                     return data;
                 });

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public async Task<List<ValueStreamCategory>> GetValueStreamCategoryByTemplateID(int templateID)
        {
            try
            {
                return await WithConnection(async c =>
                {
                    List<ValueStreamCategory> list = new List<ValueStreamCategory>();
                    var z = await c.QueryMultipleAsync(
                        "USP_ValuesStreamCategoryByTemplateID", new
                        {
                            @ValueStreamTemplateID = templateID,
                            @PlantID = userPlantID,
                            @CurrentUserNTID = userNTID,

                        },
                        commandType: CommandType.StoredProcedure);

                    var y = z.Read<ValueStreamCategory>();

                    var x = z.Read<ValueStream>();
                
                foreach (ValueStreamCategory l in y)
                    {
                        l.ValueStreams = x.Where(n => n.ValueStreamCategoryID == l.ValueStreamCategoryID).OrderBy(k =>k.RowID).ToList();
                    }

                    return y.ToList();
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<ValueStream>> GetValueStreamsByCategoryID(int categoryID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<ValueStream>(
                    "USP_ValueStreamsByCategoryID", new
                    {
                        @ValueStreamCategoryID = categoryID,
                        @PlantID =userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public async Task<List<Shift>> GetShiftsByTemplateID(int templateID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<Shift>(
                    "USP_GetShiftsByTemplateID", new
                    {
                        @ValueStreamTemplateID = templateID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }

        public Task<Result> UpdateValueStreamTemplate(ValueStreamTemplate valuestreamtemplate)
        {
            throw new NotImplementedException();
        }


        //*************************************Import Excel*******************************************
        public async Task<Result> ImportExcel(ImportCombinedList ImportCombinedList)
        {
            Result data = new Result();
            try
            {

                for (int i = 0; i < ImportCombinedList.list1.Count; i++)
                {
                    var y = (dynamic)null;
                    var z = (dynamic)null;
                    List<ValueStream> vs3 = new List<ValueStream>();

                    var x = Utility.Utility.ObjectToXMLGeneric(ImportCombinedList.list1[i]);

                    var li2 = ImportCombinedList.list2.Where(n => n.TempID == ImportCombinedList.list1[i].TempID).ToList();
                    y = Utility.Utility.ObjectToXMLGeneric(li2);

                    var li3 = ImportCombinedList.list3.Where(n => n.TempID == ImportCombinedList.list1[i].TempID).ToList();

                    //for(int j = 0; j < li2.Count; j++)
                    //{
                    //    var x1 = importCombinedList.list3.Where(n => n.CID == li2[j].CID).ToList();
                    //    vs3.AddRange(x1);
                    //}

                    //var li3 = importCombinedList.list3.Where(n => n.CID == li2.CID).ToList();
                    z = Utility.Utility.ObjectToXMLGeneric(vs3);

                    //**************
                    x = x == null ? " " : x;
                    y = y == null ? " " : y;
                    z = z == null ? " " : z;
                    using (IDbConnection con = new SqlConnection(ConnectionString))
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();

                        DynamicParameters parameters = new DynamicParameters();
                        parameters.Add("@ImportExcel_ValueStreamTemplate", x);
                        parameters.Add("@ImportExcelCat_ValueStreamTemplate", y);
                        parameters.Add("@ImportExcelValueStream", z);
                        data.ResultCode = con.Execute("USP_ImportExcel_VtreamTemplate", parameters, commandType: CommandType.StoredProcedure);

                    }


                }

                return data;
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
            }
            return data;
        }
        //**************************************Import Excel End********************************************


        //*******************************Export Excel*******************************************************

        public DataSet ExportExcel()
        {
            DataSet ds = new DataSet();
            string query = "SELECT TOP 10 ValueStreamTemplateID,ValueStreamTemplateName,IsLocked,ModifiedAt,ModifiedBy_UserID,CreatedAt,CreatedBy_UserID,Delimiter,IsOperatedInShifts,VisualizationViewModeID,TempID  FROM T_TRN_ValueStreamTemplate;";
            query += "SELECT TOP 10 ValueStreamCategoryID,ValueStreamCategoryName,ValueStreamTemplateID,IsDataRequired,TypeOfInput_InputTypeID,IsDataRequiredToFitSpecLength,MinimumNoOfCharacters,MaximumNoOfCharacters,TempID FROM T_TRN_ValueStreamCategory;";
            query += "select TOP 10 * from T_TRN_ValueStream";

            //string query = "SELECT TOP 10 ValueStreamTemplateID,ValueStreamTemplateName,IsLocked,ModifiedAt,ModifiedBy_UserID,CreatedAt,CreatedBy_UserID,Delimiter,IsOperatedInShifts,VisualizationViewModeID,TempID  FROM T_TRN_ValueStreamTemplate_ImportTest;";
            //query += "SELECT TOP 10 ValueStreamCategoryID,ValueStreamCategoryName,ValueStreamTemplateID,IsDataRequired,TypeOfInput_InputTypeID,IsDataRequiredToFitSpecLength,MinimumNoOfCharacters,MaximumNoOfCharacters,TempID FROM T_TRN_ValueStreamCategory_ImportTest";

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.Connection = con;
                        sda.SelectCommand = cmd;

                        sda.Fill(ds);

                    }
                }
            }
            return ds;
        }


        //*********************************Export Excel Ends Here********************************************

        public async Task<Result> InsertValueStreamProxy(ValueStreamProxy proxy)
        {
            Result data = new Result();

            try
            {
                var Proxies = Utility.Utility.ObjectToXMLGeneric(proxy.Proxies);

                return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_AddEditValueStreamTemplateProxy", new
                    {
                        @ID = proxy.ID,
                        @ValueStreamTemplateID = proxy.ValueStreamTemplateID,
                        @Proxies = Proxies,
                        @IsLocked = proxy.IsLocked,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }

        //for tree view
        public async Task<List<ValueStream>> GetValueStreamsByTemplateID(int templateID)
        {
            try
            {
                return await WithConnection(async c =>
                {
                    var list = await c.QueryAsync<ValueStream>(
                        "USP_ValueStreamsByTemplateID", new
                        {
                            @ValueStreamTemplateID = templateID,
                            @PlantID = userPlantID,
                            @CurrentUserNTID = userNTID,

                        },
                       commandType: CommandType.StoredProcedure);
                    return list.ToList();
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<ValueStreamProxy>> ValueStreamProxiesByTemplateID(int templateID)
        {
            try
            {
                return await WithConnection(async c =>
                {
                    var list = await c.QueryAsync<ValueStreamProxy>(
                        "USP_FetchValueStreamProxiesByTemplateID", new
                        {
                            @ValueStreamTemplateID = templateID,
                            @PlantID = userPlantID,
                            @CurrentUserNTID = userNTID,

                        },
                       commandType: CommandType.StoredProcedure);
                    return list.ToList();
                });

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<Result> DeleteValueStreamTemplate(ValueStreamTemplate valueStreamTemplate)
        {
            Result data = new Result();
            try
            {
                IDbConnection db = new SqlConnection(ConnectionString);
                var res = db.Query<int>("USP_ValidateLinkedValueStream", 
                    new
                    {
                        @ValueStreamTemplateID = valueStreamTemplate.ValueStreamTemplateID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: CommandType.StoredProcedure).Count();

                if (res < 1)
                {
                    return await (new DapperContext()).WithConnection(async c =>
                {

                    var result = await c.QueryAsync("USP_DeleteValueStreamTemplate", new
                    {
                        @ValueStreamTemplateID = valueStreamTemplate.ValueStreamTemplateID,
                        @ModifiedAt = valueStreamTemplate.ModifiedAt,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                    commandType: CommandType.StoredProcedure);
                    data.ResultCode = 0;
                    return data;
                });
                }

                else
                {
                    data.ResultCode = 1;
                    return data;
                }
            }
            catch (Exception ex)
            {
                data.ResultCode = 9;
                Log.Error("API Error-" + GetType().FullName + "." + System.Reflection.MethodBase.GetCurrentMethod().Name + "-" + (ex.InnerException == null ? ex?.Message : ex?.InnerException?.Message));
                return data;
            }
        }


        public async Task<List<ValueStream>> ValueStreamByValueStreamID(int valueStreamID)
        {
            return await WithConnection(async c =>
            {
                var list = await c.QueryAsync<ValueStream>(
                    "USP_ValueStreamByValueStreamID", new
                    {
                        @ValueStreamID = valueStreamID,
                        @PlantID = userPlantID,
                        @CurrentUserNTID = userNTID,

                    },
                   commandType: CommandType.StoredProcedure);
                return list.ToList();
            });
        }
        public async Task<List<ValueStreamTemplate>> FetchValueStreamTemplateByTemplateID(int valueStreamTemplateID)
        {
            try
            {

                return await WithConnection(async c =>
                {
                    var list = await c.QueryAsync<ValueStreamTemplate>(
                       "USP_FetchValueStreamTemplateByTemplateID", new
                       {
                           @ValueStreamTemplateID = valueStreamTemplateID,
                           @PlantID = userPlantID,
                           @CurrentUserNTID = userNTID,

                       },
                       commandType: CommandType.StoredProcedure);
                    return list.ToList();
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
