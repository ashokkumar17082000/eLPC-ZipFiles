﻿using ELPC.Core;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace ELPC.DAL.Interfaces
{
    public interface IAssessorTemplateRepository
    {
        Task<List<AssessorTemplate>> GetAssessorTemplates();
        Task<List<Assessor>> GetAssessors();
        Task<List<AssessorStreamHistory>> GetAssessorTemplatesHistory(int templateID);
        Task<List<Assessor>> GetAssessorsByTemplateID(int templateID);
        Task<Result> AssessorsRestoreByTemplateHistoryID(int historyID);
        Task<Result> InsertAssessorTemplate(AssessorTemplate assessorTemplate);
        Task<Result> DeleteAssessorTemplate(AssessorTemplate assessorTemplate);

        Task<Result> AssessorImportExcel(AssessorImportCombinedList assessorImportCombinedList, string ntid);

        DataSet AssessorExportExcel();
        Task<Result> InsertAssessorProxy(AssessorProxy proxy);
        Task<List<AssessorTemplate>> ValidateAssessorTemplateName(string assessorTemplateName);
        Task<List<AssessorProxy>> AssessorProxiesByAssessorTemplateID(int templateID);
        Task<List<AssessorTemplate>> FetchAssessorTemplateByTemplateID(int templateID);
    }
}
