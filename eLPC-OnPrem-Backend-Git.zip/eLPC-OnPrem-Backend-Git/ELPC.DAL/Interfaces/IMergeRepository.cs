﻿using ELPC.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ELPC.DAL.Interfaces
{
    public interface IMergeRepository
    {
        Task<Result> MergeQuestionAssignment(Merge mergeQuestionAssignment);

        Task<Result> MergeTagAssignment(Merge mergeTagAssignment);

        Task<Result> MergeQuestionRemoval(Merge mergeQuestionRemoval);

        Task<Result> MergeTagRemoval(Merge mergeTagRemoval);

        Task<Result> MergeQuestionProxy(MergeProxy mergeQuestionProxy);

        Task<Result> MergeTagProxy(MergeProxy mergeTagProxy);

    }
}

