﻿using ELPC.Core;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace ELPC.DAL.Interfaces
{
    public interface ILaunchpadsettingRepository
    {
        Task<Result> InsertLaunchpadURL(ReportText reportText);

        Task<List<ReportText>> GetLaunchpad();

        Task<List<Reportrestore>> GetRestoredata();
        Task<Result> LaunchpadHistoryID(int historyID);
       
    }
}
