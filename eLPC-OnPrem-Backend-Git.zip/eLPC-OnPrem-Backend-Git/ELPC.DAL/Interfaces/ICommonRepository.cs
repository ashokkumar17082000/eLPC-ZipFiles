﻿using ELPC.Core;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ELPC.DAL.Interfaces
{
    public interface ICommonRepository
    {
        Task<List<ChoiceDisplayType>> GetChoiceDisplayTypes();
        Task<List<AnswerType>> GetAnswerTypes();
        Task<List<User>> GetUsers();
        Task<Result> InsertUser(User user);
        Task<User> GetUserByNTID(string NTID);
        Task<Result> InsertIntoDeviation(Deviation deviation);
        Task<Result> InsertIntoDeviationAttachments(Deviation deviation);
        Task<Result> DeletetempAttachments(Deviation deviation);
        Task<Result> InsertIntoAuditDeviation(Deviation deviation);
        Task<Result> AddUsers(List<User> users);
        Task<Result> SendDeviationEmail(Deviation deviation, Dictionary<string, byte[]> emailimage);
        Task<Result> GetConfigByPlantIDAndConfigType(int plantID, string configType);
        Task<UserDetails> FetchUserAccessDetails(User use);
        Task<Result> SetDefaultPlant(User user);
        Task<Result> SetUserAdditionalData(string additionalData, string userNTID);
        Task<UserProfileValueStreamAssessor> GetUserProfileVSAS();
        Task<Result> updateEmployeeID(); 
        Task<Result> AddEditUserProfileVSAS(UserProfileValueStreamAssessor userProfile);
        Task<Result> UpdateUserProfileVSAS(UserProfileUpdateVSAS updateVSAS);

    }
}
