﻿using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using ELPC.Core;

namespace ELPC.DAL.Interfaces
{
    public interface IValueStreamTemplateRepository
    {
        Task<List<RecycleBinTemplate>> GetRecycleBinTemplates();
        Task<List<RecycleBinTemplate>> RecycleBinHistory();
        Task<Result> RestoreRecycleBin(List<RecycleBinTemplate> recycleTemplate);        
         Task<Result> DeleteRecycleBin(List<RecycleBinTemplate> recycletemplate);
        Task<List<ValueStreamTemplate>> GetValueStreamTemplates();
        Task<List<ValueStreamCategory>> GetValueStreamCategories();
        Task<List<ValueStream>> GetValueStreams();
        Task<Result> InsertValueStreamTemplate(ValueStreamTemplate valuestreamtemplate);
        Task<Result> UpdateValueStreamTemplate(ValueStreamTemplate valuestreamtemplate);
        Task<List<ValueStreamCategory>> GetValueStreamCategoryByTemplateID(int templateID);
        Task<List<ValueStream>> GetValueStreamsByTemplateID(int templateID);
        Task<Result> ImportExcel(ImportCombinedList ImportCombinedList);
        DataSet ExportExcel();
        Task<List<ValueStream>> GetValueStreamsByCategoryID(int categoryID);
        Task<Result> InsertValueStreamProxy(ValueStreamProxy proxy);
        Task<List<Shift>> GetShiftsByTemplateID(int templateID);
        Task<List<ValueStreamHistory>> GetValueStreamsHistory(int templateID);
        Task<Result> ValueStreamRestoreByTemplateHistoryID(int historyID);
        Task<List<ValueStreamProxy>> ValueStreamProxiesByTemplateID(int templateID);

        Task<Result> DeleteValueStreamTemplate(ValueStreamTemplate valueStreamTemplate);

        Task<List<ValueStream>> ValueStreamByValueStreamID(int valueStreamID);
        Task<List<ValueStreamTemplate>> FetchValueStreamTemplateByTemplateID(int valueStreamTemplateID);

    }
}
