﻿using ELPC.Core;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ELPC.DAL.Interfaces
{
    public interface ITagModeRepository
    {
        Task<List<TagMode>> GetTagModeByNTID(string NTID);
   
        Task<Result> InsertToTagMode(TagMode tagMode);
        Task<List<Tag>> GetTagModeTags();
        Task<List<Tag>> GetTagModeTagsCalendar();
        Task<Result> DeleteTagMode(TagMode tagMode);
        Task<List<Question>> GetInfoQuestionsByTagID(int tagID);

        #region Tag Mode Audit
        Task<Result> AddEditTagModeQuestion(AuditQuestion auditQuestion);

        Task<List<AuditQuestion>> FetchTagModeQuestionsByCurrentAssessorAndTemplateID(int auditID, string NTID);

        #endregion
    }
}
