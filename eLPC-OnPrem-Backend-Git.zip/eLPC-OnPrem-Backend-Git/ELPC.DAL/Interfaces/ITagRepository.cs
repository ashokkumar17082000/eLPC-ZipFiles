﻿using ELPC.Core;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ELPC.DAL.Interfaces
{
    public interface ITagRepository
    {
        Task<List<Tag>> GetTags();
        Task<List<Tag>> GetTagsByID(int tagID);
        Task<List<TagHistory>> GetTagHistory(int templateID);
        Task<Result> TagRestoreByTemplateHistoryID(int historyID);
        Task<Result> InsertTag(Tag tag);
        Task<Result> DeleteTag(Tag tag);
        Task<List<Question>> GetQuestionsByTagID(int tagID);
        Task<List<Tag>> GetTagsByTagID(int tagID);
        Task<List<Assessor>> GetAssessorsByTagIDs(string tagIDs);
        Task<Result> InsertTagProxy(TagProxy proxy);
        Task<List<Question>> FetchQuestionsByAssessorsAndValuestreams(string assessorIDs, string valueStreamIDs);
        Task<List<Tag>> FetchTagsByAssessorsAndValuestreams(string assessorIDs, string valueStreamIDs);
        Task<List<Assessor>> AssessorsByTagID(int tagID);
        Task<List<ValueStream>> ValueStreamsByTagID(int tagID);
        Task<List<TagProxy>> TagProxiesByTagID(int tagID);
        Task<List<Tag>> FetchProcessConfirmationTags();

        Task<List<Tag>> FetchTagDetailsByTagID(int tagID);

        Task<Result> UpdateAuditByTagID(int tagID);

    }
}
