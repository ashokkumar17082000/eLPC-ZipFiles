﻿using ELPC.Core;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ELPC.DAL.Interfaces
{
    public interface ICustomModeRepository
    {
        Task<List<CustomMode>> GetCustomModeByNTID(string NTID);
        Task<Result> InsertCustomMode(CustomMode customMode);
        Task<List<Tag>> GetCustomTags();
        Task<Result> RemoveFromCustomModeList(CustomMode customMode);
    }
}
