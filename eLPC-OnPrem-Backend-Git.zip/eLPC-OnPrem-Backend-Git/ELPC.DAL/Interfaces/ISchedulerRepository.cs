﻿using ELPC.Core;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ELPC.DAL.Interfaces
{
    public interface ISchedulerRepository
    {
        Task<Result> AddSchedular(Schedule schedule);

        Task<Result> AddCreateOPL(Schedule schedule);

    }
}
