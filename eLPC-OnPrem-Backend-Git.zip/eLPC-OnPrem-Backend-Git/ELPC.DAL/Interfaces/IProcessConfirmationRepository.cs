﻿using ELPC.Core;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ELPC.DAL.Interfaces
{
   public interface IProcessConfirmationRepository
    {
        Task<List<ProcessConfirmation>> GetProcessConfirmation(ProcessConfirmation processConfirmation);
        //Task<List<ProcessConfirmation>> GetProcessConfirmation(ProcessConfirmation processConfirmation);
        Task<Result> InsertProcessConfirmation(ProcessConfirmation processConfirmation);
        int pendingTagModeStatus(ProcessConfirmation processConfirmation);
        int updateEventEndTime(String eventstsrttime, ProcessConfirmation processConfirmationdata);
        Task<Result> AddToCustomMode(ProcessConfirmation processConfirmation);
        Task<Result> DeleteFromCustomMode(ProcessConfirmation processConfirmation);
        Task<List<ValueStream>> GetValueStreamByQuestionID(int QuestionID);
        Task<List<Assessor>> GetAssessorsByQuestionID(int QuestionID);
        Task<int> getSelectedLinkedTagQuestionCount(int TagId, Boolean maintablequestioncount = false);
    }
}
