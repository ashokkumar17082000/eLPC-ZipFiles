//DEV
  // var commonApiURL = "http://localhost:62639/api/";
  // var basehref = "";


//SL3 - Quality
// var commonApiURL = "http://fe0vmc2311.de.bosch.com/eLPC_UAT_Common_WebAPI/api/";
// var basehref = "/eLPC_UAT_Common/";

////SL2 - Quality
// var commonApiURL = "https://bbm-elpc-q.bosch.tech/eLPC_UAT_Common_WebAPI/api/";
// var basehref = "/eLPC_UAT_Common/";

// ////SL2 - PROD
// var commonApiURL = "https://bbm-elpc.bosch.tech/eLPC_Common_WebAPI/api/";
// var basehref = "/eLPC/";

//DEV.azure UAT
  var commonApiURL = "https://elpc-common-dev.azurewebsites.net/api/";
  //var commonApiURL = "https://elpc-prod-common-evdjavamgcbnbwfa.germanywestcentral-01.azurewebsites.net/api/";
  var basehref = "";

var apiScopes = "api://3cd19a01-069a-49cf-9dd2-7a117908132e/Files.Read";
//var apiURL = "https://elpc-transaction-dev.azurewebsites.net/api/";
var apiURL = "https://elpc-prod-transaction-gydeacdugje4cscr.germanywestcentral-01.azurewebsites.net/api/";

export var environment: any = null;

environment = {
  plantName: "",
  language: "",
  dateTimeFormat: "",
  powerBIURL: "",
  superopl: "",
  superoplEndDateCount : 0,
  production: true,
  home: "",
  uiUrl: "",
  baseUrl: "",
  fileTypes: "",
  superOPLPortalURL: "",
  commonApiURL: commonApiURL,
  defaultLanguage: "",
  basehref : basehref,
  applicationVersion: "5.3_Azure",
  powerBISharePointURL : "https://bosch.sharepoint.com/:u:/s/msteams_8631616/EaszZZ1QogpMk00dccunnUoB3XySC-0lTFjVrSb_aCl_4Q?e=fhtAJY",
  scopes: "api://3cd19a01-069a-49cf-9dd2-7a117908132e/Files.Read",
  clientId: '5cb603e8-b798-42c9-bd79-229dd7b7a54e',
  authority: 'https://login.microsoftonline.com/0ae51e19-07c8-4e4b-bb6d-648ee58410f4',
  apiScopes: apiScopes,
  apiURL: apiURL
};
