//DEV
var commonApiURL = "http://localhost:62639/api/";
var basehref = "";

//SL3 - Quality
// var commonApiURL = "http://fe0vmc2311.de.bosch.com/eLPC_UAT_Common_WebAPI/api/";
// var basehref = "/eLPC_UAT_Common/";

//SL2 - Quality
// var commonApiURL = "https://bbm-elpc-q.bosch.tech/eLPC_UAT_Common_WebAPI/api/";
// var basehref = "/eLPC_UAT_Common_Dev/";

//Azure_Authentication
var apiScopes = "api://3cd19a01-069a-49cf-9dd2-7a117908132e/Files.Read";
var apiURL = "http://localhost:61468/api/";
//End

export var environment: any = null;

environment = {
  plantName: "",
  language: "",
  dateTimeFormat: "",
  powerBIURL: "",
  superopl: "",
  superoplEndDateCount : 0,
  production: false,
  home: "",
  uiUrl: "",
  baseUrl: "",
  fileTypes: "",
  superOPLPortalURL: "",
  commonApiURL: commonApiURL,
  defaultLanguage:"",
  basehref : basehref,
  applicationVersion: "5.0",
  powerBISharePointURL : "https://bosch.sharepoint.com/:u:/s/msteams_8631616/EaszZZ1QogpMk00dccunnUoB3XySC-0lTFjVrSb_aCl_4Q?e=fhtAJY",
  //Azure_OpenId
  scopes: "api://3cd19a01-069a-49cf-9dd2-7a117908132e/Files.Read",
  clientId: '5cb603e8-b798-42c9-bd79-229dd7b7a54e',
  authority: 'https://login.microsoftonline.com/0ae51e19-07c8-4e4b-bb6d-648ee58410f4',
  apiUrl: "http://localhost:62639/api/",
  apiScopes: apiScopes,
  apiURL: apiURL
  //End
};
