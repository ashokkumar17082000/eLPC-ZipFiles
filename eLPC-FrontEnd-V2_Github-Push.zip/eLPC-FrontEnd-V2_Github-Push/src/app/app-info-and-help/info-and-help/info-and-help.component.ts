import { Component, OnInit } from '@angular/core';
import { LanguageService } from 'src/app/language.service';
import { infoAndHelpService } from 'src/app/service/infoAndHelp.service';
import { SharedService } from 'src/app/service/shared.service';
import { User } from 'src/app/main/body/shared/common';
import { FormControl, FormGroup } from '@angular/forms';



@Component({
  selector: 'app-info-and-help',
  templateUrl: './info-and-help.component.html',
  styleUrls: ['./info-and-help.component.css']
})
export class InfoAndHelpComponent implements OnInit {

  labels:any;
  _subscription:any;

  PlantName:string;

  designerUserList:User[] = [];
  morUserList:User[] = [];
  page: number = 1;
  resultPerPage: number = 10;
  startPage: number;
  endPage: number;
  masterOfRole:string = "";
  UserDetails: any;
  displayName: string | null = "";
  // Define the email properties
   toAddress = 'eLPC Service Mailbox (CC/QMM) <ServiceMailbox.eLPC@de.bosch.com>';
   subject = 'eLPC Support / Service Mailbox';
  filteredItems: any;
  dataPoolList: any;
  filtertext: string;
  totalList: any;
  filterId: boolean;
  headerFilterName: any;
  dataCopy: any;
  settings: { //setting for multiselect dropdown
    singleSelection: boolean; idField: string; textField: any; enableCheckAll: boolean; selectAllText: string; unSelectAllText: string; allowSearchFilter: boolean; limitSelection: number; clearSearchFilter: boolean; maxHeight: number; itemsShowLimit: number; searchPlaceholderText: string; noDataAvailablePlaceholderText: string; closeDropDownOnSelection: boolean; showSelectedItemsAtTop: boolean; defaultOpen: boolean;
  };
  data: any;
  form: FormGroup;
  loadContent: boolean;
  filterPopUp: any;
  
  constructor(private sharedService: SharedService, private infoAndHelpService: infoAndHelpService
              ,private local_label:LanguageService
              ) {this.PlantName = this.sharedService.PlantNameSelected; }

  ngOnInit() {
    console.log("info and help")
    this.displayName = sessionStorage.getItem('displayName');
    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe((value)=>{
      this.labels = value;
    })

    this.getMorUser();
    //this.sharedService.hide();
  }

  public getMorUser(){
    this.sharedService.show();
    //debugger;
    this.masterOfRole = this.sharedService.currentUserInfo.idmMor;
    this.sharedService.getADUsersByGroupName(this.masterOfRole).subscribe(res => {
      //this.sharedService.hide();
      console.log("71",res)
      this.morUserList = res;
      this.getDesignerUser();

    })
  }


  getColumnName(headername: any) {
   console.log(this.totalList)
    if (this.filteredItems == undefined) {
      this.filteredItems = []
    }

    this.dataPoolList = this.totalList;//newly added
    this.filtertext = '';
    this.filterId = false;
 

    if (headername == 'Ntid') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].ntid);
      }
      this.filterId = !this.filterId;
    }
 
    else if (headername == 'Name') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].userName);
      }
    
    }
    else if (headername == 'email') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].email);
      }
     
    }
    this.headerFilterName = headername;
    this.searchFilter();
  }

  searchFilter(num?:number) {
    debugger;
    if(num!=1){
      this.data = [];
    }// ********************************searching
    var prefix = 'Q';
   
    if (this.headerFilterName == "Ntid") {
      for (var dataPoolDet of this.dataPoolList) {
        let newItem = {
          dataPoolID: dataPoolDet.ntid,
          Ntid: dataPoolDet.ntid
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.Ntid === dataPoolDet.ntid)) {//newly added
            this.data.push(newItem);
          }
        }
      }
    }
  
    else if (this.headerFilterName == "Name") {
      for (var dataPoolDet of this.dataPoolList) {
        let newItem = {
          dataPoolID: dataPoolDet.userName,
          Name: dataPoolDet.userName
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.Name === dataPoolDet.userName)) {
            this.data.push(newItem);
          }
        }
      }
    }
    else if (this.headerFilterName == "email") {
      for (var dataPoolDet of this.dataPoolList) {
        let newItem = {
          dataPoolID: dataPoolDet.emailAddress,
          email: dataPoolDet.emailAddress
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.email === dataPoolDet.answer)) {
            this.data.push(newItem);
          }
        }
      }
    }

    
    this.dataCopy=JSON.parse(JSON.stringify(this.data))
  
    this.settings = {//setting for multiselect dropdown
      singleSelection: false,
      idField: 'dataPoolID',
      textField: this.headerFilterName,


      enableCheckAll: true,
      selectAllText: 'Select All',
      unSelectAllText: 'Unselect All',
      allowSearchFilter: true,
      limitSelection: -1,
      clearSearchFilter: true,
      maxHeight: 197,
      itemsShowLimit: 0,
      searchPlaceholderText: 'Search',
      noDataAvailablePlaceholderText: 'No Data Available',
      closeDropDownOnSelection: false,
      showSelectedItemsAtTop: false,
      defaultOpen: false
    };
    this.setForm();
    // ************************************************
  }

  setForm() {
    this.form = new FormGroup({
      name: new FormControl(
        this.dataCopy
      )
    });
    this.loadContent = true;
  }
  onOpenDropdown(){
    console.log("open ")
    console.log("datcopy",this.dataCopy)
    console.log(this.data)
    this.dataCopy = [...this.dataCopy];
    //this.cdr.detectChanges();
  }

  public openAlertModal(popUp: any) {
    this.filterPopUp = popUp;
  }


  onItemSelect(item: any) {
    debugger;
    //if (this.filteredItems == undefined) {
      this.filteredItems = [];
    //}

 if (this.headerFilterName == 'Ntid') {
      if (this.filteredItems.indexOf(item.ntid) < 0) {
        this.filteredItems.push(item.ntid);
      }
      this.designerUserList = this.totalList.filter(f => this.filteredItems.includes(f.ntid));
    }

    else if (this.headerFilterName == 'Name') {
      if (this.filteredItems.indexOf(item.userName) < 0) {
        this.filteredItems.push(item.userName);
      }
      this.designerUserList = this.totalList.filter(f => this.filteredItems.includes(f.userName));
    }
    
    else if (this.headerFilterName == 'email') {
      if (this.filteredItems.indexOf(item.email) < 0) {
        this.filteredItems.push(item.email);
      }
      this.designerUserList = this.totalList.filter(f => this.filteredItems.includes(f.email));
    }
  
  }


  public onDeSelect(item: any) {
    if (this.filteredItems == undefined) {
      this.filteredItems = [];
    }
   if (this.headerFilterName == 'userName') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.userName);
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.userName));
    }
    else if (this.headerFilterName == 'questionID') {
      item.questionID = item.questionID.replace("Q", "");
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.questionID);
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.questionID.toString()));
    }
    else if (this.headerFilterName == 'responsibleEmployee') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.responsibleEmployee);
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.responsibleEmployee));
    }
    
    else if (this.headerFilterName == 'deviationDisplayID') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.deviationDisplayID);
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.deviationDisplayID));
    }

    else if (this.headerFilterName == 'valueStreamName') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.valueStreamName);
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.valueStreamName));
    }
   
    else if (this.headerFilterName == 'deviationDescription') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.deviationDescription);
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.deviationDescription));
    }
    else if (this.headerFilterName == 'obtainedScore') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.obtainedScore);
      this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.obtainedScore));
    }
  }
  
  public closeAlertModal() {
    this.filterPopUp.hide();
    if (this.dataPoolList.length == this.totalList.length) {
    //document.getElementsByTagName("popover-container")[0].parentNode.removeChild(document.getElementsByTagName("popover-container")[0]);
    this.filtertext = '';
    this.filterId = false;
   
    document.querySelector('body').classList.remove('-is-modal');
    }
  }

  public getDesignerUser(){
    //this.sharedService.show();
    let groupName = this.sharedService.currentUserInfo.idMDesignerRole;
    this.sharedService.getADUsersByGroupName(groupName).subscribe(res => {
      //debugger;
      //console.log(res);
      console.log("271",res)
     
      this.sharedService.hide();
      this.sharedService.sharedDesignerUser = res.sort((a,b)=> a.ntid.localeCompare(b.ntid));
      this.designerUserList = res.sort((a,b)=> a.ntid.localeCompare(b.ntid));
      this.totalList= this.sharedService.sharedDesignerUser;
      //this.designerUserList.sort((a,b)=>{return b.ntid - a.ntid;});

    })
  }

  public doFilter = (value: string) => {
    //this.UserDetails = JSON.parse(JSON.stringify(this.designerUserList)).sort();
    this.designerUserList = JSON.parse(JSON.stringify(this.sharedService.sharedDesignerUser)).sort();

    if (value.length > 0) {
      this.designerUserList = this.designerUserList.filter(x =>
        x.ntid.trim().toLowerCase().includes(value.trim().toLowerCase()) ||
        x.userName.trim().toLowerCase().includes(value.trim().toLowerCase()) ||
        x.emailAddress.trim().toLowerCase().includes(value.trim().toLowerCase())
      );
      this.page = 1;
    }
  }

  isFirstPage() {
    if (this.page == 1) {
      return;
    }
    else {
    }

    this.page = 1;
    this.startPage = (this.page - 1) * 4 + 1;
    this.endPage = this.page * this.resultPerPage;
  }

  isLastPage() {
    if (Math.ceil(this.designerUserList.length / this.resultPerPage) <= this.page) {
      return;
    }
    else {

    }

    this.page = Math.ceil(this.designerUserList.length / this.resultPerPage);
    this.startPage = (this.page - 1) * 4 + 1;
    this.endPage = this.page * this.resultPerPage;
  }

  pageChanged(event): void {

    if (event == 0) {
      return;
    }
    else if (Math.ceil(this.designerUserList.length / this.resultPerPage) < event) {
      return;
    }
    else {
      this.page = event;
      this.startPage = (this.page - 1) * 4 + 1;
      this.endPage = this.page * this.resultPerPage;
    }
  }

  eLPC_Service_MailboxClick() {

    let body = `Hello eLPC Support,
    
    I am contacting you because of:
    
    Suggestions for improvement ()
    Occurrence of a bug ()
    Grant access to the tool for Standard / Designer users ()
    Power BI topics ()
    Super OPL topics ()
    Other topics ()
    
    My plant/instance:
    
    Detailed description of the problem:
    
Mit freundlichen Grüßen / Best regards
${this.displayName}
  `;
     // Construct the mailto URL
     const mailtoUrl = `mailto:${this.toAddress}?subject=${encodeURIComponent(this.subject)}&body=${encodeURIComponent(body)}`;

     window.location.href = mailtoUrl;

  }

  Bosch_Connect_eLPC_communityClick() {
    const Bosch_Connect_eLPC_community_url = 'https://connect.bosch.com/communities/service/html/communitystart?communityUuid=f5da04e3-5797-4a8d-ab1b-6a78f6c11727';
    window.open(Bosch_Connect_eLPC_community_url, '_blank');
  }

  eLPC_FAQClick() {
    const eLPC_FAQ_url = 'https://connect.bosch.com/wikis/home?lang=de-de#!/wiki/W3f3fd23546aa_471b_9a42_29a5917fb5fa/page/eLPC%20FAQ';
    window.open(eLPC_FAQ_url, '_blank');
  }

  downloadFile(): void {
    //debugger;
    this.sharedService.downloadServiceMailboxFile().subscribe(
      (response: Blob) => {
       // debugger;
        const blob = new Blob([response], { type: 'application/octet-stream' });
 
        // Create a temporary URL for the blob
        const url = window.URL.createObjectURL(blob);
 
        // Create a link element and trigger the download
        const anchor = document.createElement('a');
        anchor.download = 'eLPC_Support_Service_Mailbox.oft';
        anchor.href = url;
        anchor.style.display = 'none';
        document.body.appendChild(anchor);
 
        anchor.click();
 
        // Clean up after the download
        document.body.removeChild(anchor);
        window.URL.revokeObjectURL(url);
      },
      (error) => {
        console.error('File download error:', error);
        // Handle error gracefully, e.g., display an error message to the user
      }
    );
  }


}
