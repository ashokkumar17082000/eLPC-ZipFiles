import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { SharedService } from 'src/app/service/shared.service';
import { LanguageService } from 'src/app/language.service';
import { RecycleBinService } from 'src/app/service/recycle-bin.service';
import { RecycleBinTemplate } from './recyclebintemplate';
//import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { FormGroup, FormControl } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
//import { RecycleBinService } from 'src/app/service/recycle-bin.service';

@Component({
  selector: 'app-recycle-bin',
  templateUrl: './recycle-bin.component.html',
  styleUrls: ['./recycle-bin.component.css']
})
export class RecycleBinComponent implements OnInit {     
  dateTimeFormat = environment.dateTimeFormat;
  filterdateFormat  = environment.dateTimeFormat.split(" ")[0];

  @ViewChild('successPopup') successModal: TemplateRef<any>;
  @ViewChild('alertPopup') warningModal: TemplateRef<any>;
  @ViewChild('deletePopup') deleteModal: TemplateRef<any>;

  labels: any;
  _subscription: any;
  recyclebinTemplateList: any[];
  totalList: any[];
  recyclebin: any[];
  alertText;

  hidePagination: boolean;
  modalRef: BsModalRef | null;

  filterdeleted = false;
  filteritem = false;
  filteritemType = false;
  filterdeletedBy = false;

  filtertext: string = '';
  filterType: string = "test";
  key: string = 'name';//for sorting
  reverse1: boolean = false;//for sorting
  headerFilterName: string = "";//for filtering
  historyReport: any=[]
  public data = [];
  public settings = {};
  public form: FormGroup;
  public loadContent: boolean = false;


  config = {
    animated: false,
    keyboard: true,
    ignoreBackdropClick: true
  };

  page: number = 1;
  resultPerPage: number = 10;
  startPage: number;
  endPage: number;

  recyclecheckboxAll: any;
  str1: any;
  filterPopUp: any;
  totalListHistory: any;

  constructor(private modalService: BsModalService, private local_label: LanguageService, private sharedService: SharedService,
    private recyclebinService: RecycleBinService, private datePipe: DatePipe,private router: Router) {
    this.recyclebin = [];
  }

  ngOnInit() {
    if(this.sharedService.role !=="Designer")
    {
      this.router.navigate([environment.home +'/accessdenied']);
    }
    this.sharedService.show();
    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
    });
    this.getRecyclebinList();
  }

  getRecyclebinList() {
    this.recyclebinService.getRecycBinTemplate().subscribe(res => {
      //debugger;
      this.recyclebinTemplateList = res;
      this.totalList = this.recyclebinTemplateList
      setTimeout(() => {
        this.sharedService.hide();
      }, 100);
      this.recyclebinTemplateList.forEach(element => {
        element.selected = false;
      });
    }, (err) => {
      console.log(err);
      this.sharedService.hide();
    })
  }

  /** Method is responsible to move to first page of the pagination. */
  isFirstPage() {
    if (this.page == 1) {
      return;
    }
    else {
    }

    this.page = 1;
    this.startPage = (this.page - 1) * 4 + 1;
    this.endPage = this.page * this.resultPerPage;
  }

  /** Method is responsible to move to last page of the pagination. */
  isLastPage() {
    if (Math.ceil(this.recyclebinTemplateList.length / this.resultPerPage) <= this.page) {
      return;
    }

    this.page = Math.ceil(this.recyclebinTemplateList.length / this.resultPerPage);
    this.startPage = (this.page - 1) * 4 + 1;
    this.endPage = this.page * this.resultPerPage;
  }

  /** Method is responsible to change page of the pagination. */
  pageChanged(event): void {
    if (event == 0) {
      return;
    }
    else if (Math.ceil(this.recyclebinTemplateList.length / this.resultPerPage) < event) {
      return;
    }
    else {
      this.page = event;
      this.startPage = (this.page - 1) * 4 + 1;
      this.endPage = this.page * this.resultPerPage;
    }
  }

  recycleAll(event) {
    if (event == true) {
      this.recyclecheckboxAll = true;
    }
    else {
      this.recyclecheckboxAll = false;
    }

    for (var i = 0; i < this.recyclebinTemplateList.length; i++) {
      this.recyclebinTemplateList[i].selected = this.recyclecheckboxAll;
    }

    if (this.recyclecheckboxAll) {
      this.recyclebin = this.recyclebinTemplateList;
    }
    else {
      this.recyclebin = [];
    }
  }

  recycleChange(recyclebinTemp, event) {
    if (event == true) {
      this.recyclebin.push(recyclebinTemp);
    }
    else {
      this.recyclebin = this.recyclebin.filter((element) => {
        if (element.id != recyclebinTemp.id) {
          return element;
        }
      })
    }

    if (this.recyclebin.length === this.recyclebinTemplateList.length) {
      this.recyclecheckboxAll = true;
    }
    else {
      this.recyclecheckboxAll = false;
    }
  }

  //to fix scroll issue after pop up
  public closeAlertModal() {
    if (document.getElementsByTagName("modal-container").length > 1) {
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1]);
    }
    else {
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if (document.getElementsByTagName("bs-modal-backdrop").length > 0) {
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }

  }
  Recyclebinhistory(RecycleHistory: TemplateRef<any>) {
    
    this.modalRef = this.modalService.show(RecycleHistory, this.config);
    this.modalRef.setClass('modal-lg');
    $('.isRestoreDisabled').prop('disabled', true);

    setTimeout(function () {
      $("#valueHistory tbody tr").click(function () {
        $(".selected").removeClass('selected');
        $(this).addClass('selected');
        $('.isRestoreDisabled').prop('disabled', false);
      });
    }, 100);
    this.recyclebinService.recyclebinHistory().subscribe(res => {
      if (res) {
        this.historyReport=res;
        this.totalListHistory=res;
       console.log("213",res)
      }
      else {
        this.closeModal();
        
      }
      });
  

  }
  restoreRecyclebinTemplate() {
    //debugger;
    document.getElementById('restoreModal').style.display = "block";
    if (this.recyclebin.length != 0) {
      this.recyclebinService.restoreTemplate(this.recyclebin).subscribe(res => {
        if (res) {
          this.closeModal();
          this.alertText = this.labels.default.restoreSuccessfully;
          this.modalService.show(this.successModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          this.getRecyclebinList();
        }
        else {
          this.closeModal();
          this.alertText = this.labels.default.insertOpertionFailed;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
        }
        });
    
  }
    else {
      this.closeModal();
      this.alertText = this.labels.default.selectAtleastOne;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
    }
  }

  deleteRecyclebinTemplate() {
    //debugger;
    this.sharedService.show();
    document.getElementById('deleteModal').style.display = "block";
    if (this.recyclebin.length != 0) {
      this.recyclebinService.deleteTemplate(this.recyclebin).subscribe(res => {
        if (res) {
          this.closeModal();
          this.recyclebin=[]
          this.alertText = this.labels.default.deletesuccessfully;
          this.modalService.show(this.successModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          this.getRecyclebinList();
        }
        else {
          this.closeModal();
          this.alertText = this.labels.default.insertOpertionFailed;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
        }
        });
    
  }
    else {
      this.closeModal();
      this.alertText = this.labels.default.selectAtleastOne;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
    }
  }


  closeModal() {
    document.getElementById('restoreModal').style.display = "none";
    document.querySelector('body').classList.remove('-is-modal');
    document.getElementById('deleteModal').style.display = "none";
    this.sharedService.hide();
  }

  showModal() {
    //debugger;
    document.getElementById('restoreModal').style.display = "block";
  }

  showdeleteModal() {
    document.getElementById('deleteModal').style.display = "block";
  }

  // ***********************************filtering************************************************************
  public openAlertModal(popUp: any) {
    this.filterPopUp = popUp;
  }

  public closeModel() {
    this.filterPopUp.hide();
    if (this.recyclebinTemplateList.length == this.totalList.length) {
    //document.getElementsByTagName("popover-container")[0].parentNode.removeChild(document.getElementsByTagName("popover-container")[0]);
    this.filterdeleted = false;
    this.filteritem = false;
    this.filteritemType = false;
    this.filterdeletedBy = false;
    //document.querySelector('body').classList.remove('-is-modal');
    }
  }
  
  //resetting all the filtering and sorting
  resetAll() {
    this.reverse1 = false;

    this.filtertext = "";
  }

  //*********************sorting*********
  sort(key) {

    this.key = this.headerFilterName;;
    this.reverse1 = !this.reverse1;
  }

  getButtonType(buttonname: any): any {

    this.filterType = buttonname;
  }
  // *********************************

  getColumnName(headername: any) {
    //debugger;
    if (this.filteredItems == undefined) {
      this.filteredItems = []
    }
    this.recyclebinTemplateList = this.totalList;//newly added
    this.filtertext = '';
    this.filterdeleted = false;
    this.filteritem = false;
    this.filteritemType = false;
    this.filterdeletedBy = false;
    if (headername == 'deleted') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.datePipe.transform(this.totalList[i].deleted,this.filterdateFormat));
      }
      this.filterdeleted = !this.filterdeleted;
    }
    else if (headername == 'itemName') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].itemName);
      }
      this.filteritem = !this.filteritem;
    }
    else if (headername == 'itemType') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].itemType);
      }
      this.filteritemType = !this.filteritemType;;
    }
    else if (headername == 'deletedBy') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].modifiedBy);
      }
      this.filterdeletedBy = !this.filterdeletedBy;
    }

    this.headerFilterName = headername;
    this.searchFilter();
  }

  setForm() {
    this.form = new FormGroup({
      name: new FormControl(
        this.data
      )
    });
    this.loadContent = true;
  }

  searchFilter() {
    //debugger;
    this.data = [];
    // ********************************searching
    var prefix = 'Q';
    if (this.headerFilterName == "deleted") {
      for (var recyclebinDet of this.recyclebinTemplateList) {
        this.str1 = this.datePipe.transform(recyclebinDet.deleted, this.filterdateFormat);//converting the date format
        let newItem = {
          rowNumber: recyclebinDet.rowNumber,
          deleted: this.str1
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.deleted === this.str1)) {//newly added
            this.data.push(newItem);
          }
        }
      }
    }
    else if (this.headerFilterName == "itemName") {
      for (var recyclebinDet of this.recyclebinTemplateList) {
        let newItem = {
          rowNumber: recyclebinDet.rowNumber,
          itemName: recyclebinDet.itemName
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.itemName === recyclebinDet.itemName)) {//newly added
            this.data.push(newItem);
          }
        }
      }
    }
    else if (this.headerFilterName == "itemType") {
      for (var recyclebinDet of this.recyclebinTemplateList) {
        let newItem = {
          rowNumber: recyclebinDet.rowNumber,
          itemType: recyclebinDet.itemType
        };
        //debugger;
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.itemType === recyclebinDet.itemType)) {//newly added
            this.data.push(newItem);
          }
        }
      }
      // var newArr = this.data.map(el => prefix + el.questionID); //adding character Q as prefix
      // this.data=newArr;
    }
    else if (this.headerFilterName == "deletedBy") {
      for (var recyclebinDet of this.recyclebinTemplateList) {
        let newItem = {
          rowNumber: recyclebinDet.rowNumber,
          deletedBy: recyclebinDet.modifiedBy
        };
        if (!this.data.includes(newItem)) {
          // this.data.push(newItem);
          if (!this.data.some(e => e.deletedBy === recyclebinDet.modifiedBy)) {
            this.data.push(newItem);
          }
        }
      }
    }
    this.settings = {//setting for multiselect dropdown
      singleSelection: false,
      idField: 'rowNumber',
      textField: this.headerFilterName,


      enableCheckAll: true,
      selectAllText: 'Select All',
      unSelectAllText: 'Unselect All',
      allowSearchFilter: true,
      limitSelection: -1,
      clearSearchFilter: true,
      maxHeight: 197,
      itemsShowLimit: 0,
      searchPlaceholderText: 'Search',
      noDataAvailablePlaceholderText: 'No Data Available',
      closeDropDownOnSelection: false,
      showSelectedItemsAtTop: false,
      defaultOpen: false
    };
    this.setForm();
    // ************************************************
  }

  // ************************************filtering ends******************************************************
  // ***********************************Dropdown multiselect filtering**************************
  filteredItems: Array<any>;
  x: any;
  onItemSelect(item: any) {
    //debugger;

    if (this.filteredItems == undefined) {
      this.filteredItems = [];
    }
    if (this.headerFilterName == 'deleted') {
      if (this.filteredItems.indexOf(item.deleted) < 0) {
        this.filteredItems.push(item.deleted);
      }
      // this.recyclebinTemplateList=this.totalList.filter(f => this.filteredItems.includes(f.deleted));
      this.recyclebinTemplateList = this.totalList.filter(f => this.filteredItems.includes(this.datePipe.transform(f.deleted, this.filterdateFormat)));
    }

    else if (this.headerFilterName == 'itemName') {
      if (this.filteredItems.indexOf(item.itemName) < 0) {
        this.filteredItems.push(item.itemName);
      }
      this.recyclebinTemplateList = this.totalList.filter(f => this.filteredItems.includes(f.itemName));
    }

    else if (this.headerFilterName == 'itemType') {
      if (this.filteredItems.indexOf(item.itemType) < 0) {
        this.filteredItems.push(item.itemType);
      }
      this.recyclebinTemplateList = this.totalList.filter(f => this.filteredItems.includes(f.itemType));
    }
    else if (this.headerFilterName == 'deletedBy') {
      if (this.filteredItems.indexOf(item.deletedBy) < 0) {
        this.filteredItems.push(item.deletedBy);
      }
      this.recyclebinTemplateList = this.totalList.filter(f => this.filteredItems.includes(f.deletedBy));
    }
  }

  public onDeSelect(item: any) {
    //debugger;
    if (this.filteredItems == undefined) {
      this.filteredItems = [];
    }
    //console.log(this.filteredItems);
    if (this.headerFilterName == 'deleted') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.deleted);
      // this.recyclebinTemplateList = this.totalList.filter(f => this.filteredItems.includes(f.deleted));
      this.recyclebinTemplateList = this.totalList.filter(f => this.filteredItems.includes(this.datePipe.transform(f.deleted, this.filterdateFormat)));
    }
    else if (this.headerFilterName == 'itemName') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.itemName);
      this.recyclebinTemplateList = this.totalList.filter(f => this.filteredItems.includes(f.itemName));
    }
    else if (this.headerFilterName == 'itemType') {
      //debugger;
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.itemType);
      this.recyclebinTemplateList = this.totalList.filter(f => this.filteredItems.includes(f.itemType));
    }
    else if (this.headerFilterName == 'deletedBy') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.deletedBy);
      this.recyclebinTemplateList = this.totalList.filter(f => this.filteredItems.includes(f.deletedBy));
    }
  }

  onSelectAll(items: any) {
    //debugger;
    if (this.filteredItems == undefined) {
      this.filteredItems = [];
    }
    for (var i = 0; i < items.length; i++) {
      if (this.headerFilterName == 'deleted') {
        this.filteredItems.push(items[i].deleted)
      }
      else if (this.headerFilterName == 'itemName') {
        this.filteredItems.push(items[i].itemName)
      }
      else if (this.headerFilterName == 'itemType') {
        this.filteredItems.push(items[i].itemType)
      }
      else if (this.headerFilterName == 'deletedBy') {
        this.filteredItems.push(items[i].deletedBy)
      }

    }
    this.recyclebinTemplateList = this.totalList;
  }

  searchGridHistory(value: String){
    if (value.length > 0) {
      var searchText = value.trim().toLowerCase();
      this.historyReport = this.totalListHistory;
      //debugger;

      this.historyReport = this.historyReport.filter(x =>
        (x.itemName != null && x.itemName.trim().toLowerCase().includes(searchText))
        || (x.itemType != null && x.itemType.toString().trim().toLowerCase().includes(searchText))
        || (x.deleted != null && this.datePipe.transform(x.deleted, this.filterdateFormat).trim().toLowerCase().includes(searchText))
        || (x.modifiedBy != null && x.modifiedBy.trim().toLowerCase().includes(searchText))
      );
      this.page = 1;
    }
    else {
      this.historyReport = this.totalListHistory;
    }
  }

  searchGrid(value: String){
    if (value.length > 0) {
      var searchText = value.trim().toLowerCase();
      this.recyclebinTemplateList = this.totalList;
      //debugger;

      this.recyclebinTemplateList = this.recyclebinTemplateList.filter(x =>
        (x.itemName != null && x.itemName.trim().toLowerCase().includes(searchText))
        || (x.itemType != null && x.itemType.toString().trim().toLowerCase().includes(searchText))
        || (x.deleted != null && this.datePipe.transform(x.deleted, this.filterdateFormat).trim().toLowerCase().includes(searchText))
        || (x.modifiedBy != null && x.modifiedBy.trim().toLowerCase().includes(searchText))
      );
      this.page = 1;
    }
    else {
      this.recyclebinTemplateList = this.totalList;
    }
  }


  public onDeSelectAll(items: any) {
    this.filteredItems = [];
    this.recyclebinTemplateList = this.totalList;
  }


  //  *******************************************************************************************Dropdown filtering ends here***************
  // ************************************filtering ends******************************************************


}
