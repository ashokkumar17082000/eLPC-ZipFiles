import { NgModule,CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RecyclebinRRoutingModule } from './recyclebin-r-routing.module';
import { RecycleBinComponent } from '../recycle-bin/recycle-bin.component';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { NgxPaginationModule } from 'ngx-pagination';
import { FormsModule,ReactiveFormsModule  } from '@angular/forms';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { SharedModule } from 'src/app/shared/shared.module';
import { OrderModule } from 'ngx-order-pipe';
import { ModalModule } from 'ngx-bootstrap/modal';
import { TooltipModule } from 'ngx-bootstrap/tooltip';

@NgModule({
  declarations: [RecycleBinComponent],
  imports: [
    CommonModule,
    RecyclebinRRoutingModule,
    NgxPaginationModule,
    PaginationModule.forRoot(),
    ReactiveFormsModule,
    FormsModule,
    SharedModule,
    OrderModule,
    ModalModule.forRoot(),
    TooltipModule.forRoot(),
    NgMultiSelectDropDownModule.forRoot(),
    PaginationModule.forRoot(),
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
  
})
export class RecyclebinRModule { }
