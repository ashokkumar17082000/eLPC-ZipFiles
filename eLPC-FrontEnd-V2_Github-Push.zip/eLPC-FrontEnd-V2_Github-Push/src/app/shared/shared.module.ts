import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ColumnFilterPipe } from './column-filter.pipe'; // Adjust the path as necessary

@NgModule({
  declarations: [ColumnFilterPipe],
  imports: [CommonModule],
  exports: [ColumnFilterPipe]
})
export class SharedModule { }