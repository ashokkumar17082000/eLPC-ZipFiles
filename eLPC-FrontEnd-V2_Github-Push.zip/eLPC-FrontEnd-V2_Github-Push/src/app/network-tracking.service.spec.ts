import { TestBed } from '@angular/core/testing';

import { NetworkTrackingService } from './network-tracking.service';

describe('NetworkTrackingService', () => {
  let service: NetworkTrackingService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NetworkTrackingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
