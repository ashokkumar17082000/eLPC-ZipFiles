import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AssessorEditComponent } from '../assessor/assessors.edit.component';
import { AssessorComponent } from '../assessor/assessor.component';
import { AssessorLockComponent } from '../assessor/assessor.lock.component';

const routes: Routes = [
  { path: 'assessor-edit', component: AssessorEditComponent },
  { path: 'assessor-lock', component: AssessorLockComponent},
  { path: '', component: AssessorComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AssessorRRoutingModule { }
