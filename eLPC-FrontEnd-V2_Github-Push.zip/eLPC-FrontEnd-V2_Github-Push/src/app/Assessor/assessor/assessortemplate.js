"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AssessorTemplate = /** @class */ (function () {
    function AssessorTemplate() {
    }
    return AssessorTemplate;
}());
exports.AssessorTemplate = AssessorTemplate;
var AssessorCategory = /** @class */ (function () {
    function AssessorCategory() {
    }
    return AssessorCategory;
}());
exports.AssessorCategory = AssessorCategory;
var Assessor = /** @class */ (function () {
    function Assessor() {
    }
    return Assessor;
}());
exports.Assessor = Assessor;
var AssessorProxy = /** @class */ (function () {
    function AssessorProxy() {
    }
    return AssessorProxy;
}());
exports.AssessorProxy = AssessorProxy;
//# sourceMappingURL=assessortemplate.js.map