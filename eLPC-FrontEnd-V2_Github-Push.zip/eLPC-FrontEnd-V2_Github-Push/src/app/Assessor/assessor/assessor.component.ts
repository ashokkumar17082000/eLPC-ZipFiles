//import { Component, OnInit } from '@angular/core';
import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { SharedService } from 'src/app/service/shared.service';
import { AssessorTemplate, Assessor, AssessorProxy } from './assessortemplate';
import { AssessorTemplateService } from 'src/app/service/assessor/assessortemplate.service';
import { Router } from '@angular/router';
import { ValuestreamTemplateService } from 'src/app/service/common/valuestreamtemplate.service';
//import { text } from '@angular/core/src/render3';
import { LanguageService } from 'src/app/language.service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { environment } from 'src/environments/environment';
import { FormGroup, FormControl } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { IfStmt } from '@angular/compiler';
import { DataPoolService } from 'src/app/service/data-pool.service';

declare var $;
@Component({
  selector: 'app-assessor',
  templateUrl:'./assessor.component.html',
  styleUrls: ['./assessor.component.css']
})
export class AssessorComponent implements OnInit {

  @ViewChild('fileInput') fileInput;
  @ViewChild('lockPopup') lockModal : TemplateRef<any>;
  @ViewChild('alertPopup') warningModal: TemplateRef<any>;
  @ViewChild('successPopup') successModal: TemplateRef<any>;

  dateTimeFormat = environment.dateTimeFormat;
  filterdateFormat  = environment.dateTimeFormat.split(" ")[0];

  filterId = true;
  filterName = true;
  filterLock = true;
  filterModified = true;
  filterModifiedBy = true;
  filterCreated = true;
  filterCreatedBy = true;

  filtertext:string='';
  filterType:string="test";
  key: string = 'name';//for sorting
  reverse1: boolean = false;//for sorting
  headerFilterName:string="";//for filtering

  public data = [];
  public dataCopy=[];
  public settings = {};
  public form: FormGroup;
  public loadContent: boolean = false;

  apiUrl: any;
  assessorTemplateList: AssessorTemplate[] = [];
  totalList: AssessorTemplate[];
  assessorTemplate: AssessorTemplate = new AssessorTemplate();
  isAdd: boolean = false;
  isEdit: boolean = false;
  isTargetFrequencyDefined: boolean = false;

  assessors: Assessor[] = [];
  assessor: Assessor;
  dataTable: any;

  page: number = 1;
  resultPerPage: number = 10;
  startPage: number;
  endPage: number;


  labels: any;
  _subscription: any;
  str1: any;

  assessorObj: AssessorTemplate = new AssessorTemplate();


  //for proxy settings
  proxies: any;
  proxy: any;
  alertText;
  filterPopUp: any;
  asSearchText: string;
  public popUpInstances: any[] = []; // Store all popups


  constructor(private local_label: LanguageService, private assessorTemplateService: AssessorTemplateService, private sharedService: SharedService,
    private modalService: BsModalService,private dataPoolService: DataPoolService,
    private router: Router, private valueStreamService: ValuestreamTemplateService,private datePipe: DatePipe) {

  }

  ngOnInit() {
    if(this.sharedService.role !=="Designer")
    {
      this.router.navigate([environment.home +'/accessdenied']);
    }
    this.sharedService.show();
    this.getAssessorTemplateList();

    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
    });

  }

    /** Method is responsible to move to first page of the pagination. */
    isFirstPage() {
      if (this.page == 1) {
        return;
      }
      else {
      }

      this.page = 1;
      this.startPage = (this.page - 1) * 4 + 1;
      this.endPage = this.page * this.resultPerPage;
    }

    /** Method is responsible to move to last page of the pagination. */
    isLastPage() {
      if (Math.ceil(this.assessorTemplateList.length / this.resultPerPage) <= this.page) {
        return;
      }
      else {

      }

      this.page = Math.ceil(this.assessorTemplateList.length / this.resultPerPage);
      this.startPage = (this.page - 1) * 4 + 1;
      this.endPage = this.page * this.resultPerPage;
    }

    /** Method is responsible to change page of the pagination. */
    pageChanged(event): void {

      if (event == 0) {
        return;
      }
      else if (Math.ceil(this.assessorTemplateList.length / this.resultPerPage) < event) {
        return;
      }
      else {
        this.page = event;
        this.startPage = (this.page - 1) * 4 + 1;
        this.endPage = this.page * this.resultPerPage;
      }
    }


  public getAssessorTemplateList() {
    this.assessorTemplateService.getAssessorTemplates().subscribe(res => {
      this.assessorTemplateList = res;
      this.totalList=this.assessorTemplateList;
      this.sharedService.hide();
      if (this.sharedService.activeDateRange != null && this.sharedService.activeDateRange.asSearchText != null 
          &&  this.sharedService.activeDateRange.asSearchText.length > 0 ) {
        this.asSearchText =this.sharedService.activeDateRange.asSearchText;
        this.searchGrid(this.sharedService.activeDateRange.asSearchText);
      }
    },
      err => {
        console.log(err);
      }
    );

  }

  addAssessor() {
    this.assessorTemplate = new AssessorTemplate();
    this.isAdd = true;
    this.isEdit = false;
    this.assessorTemplate.isTargetFrequencyDefined = false;
    this.router.navigate([environment.home +'/assessors/assessor-edit']);
  }


  editAsessor(assessorTemplate: any) {
    if (assessorTemplate.isLocked) {
      this.assessorTemplateService.assessorProxiesByAssessorTemplateID(assessorTemplate.assessorTemplateID).subscribe(res => {
        this.proxies = res;

        let ProxyCreatedBy = new AssessorProxy();
        ProxyCreatedBy.userName = assessorTemplate.createdBy;
        ProxyCreatedBy.ntid = assessorTemplate.createdBy_NTID;
        ProxyCreatedBy.createdBy_NTID = assessorTemplate.createdBy_NTID;
        ProxyCreatedBy.modifiedBy_NTID = assessorTemplate.modifiedBy_NTID;
        if (!this.proxies.some(e =>  assessorTemplate.createdBy_NTID != null && e.ntid.toLowerCase() === assessorTemplate.createdBy_NTID.toLowerCase())) {
          this.proxies.push(ProxyCreatedBy);
        }

        let ProxyModified = new AssessorProxy();
        ProxyModified.userName = assessorTemplate.modifiedBy;
        ProxyModified.ntid = assessorTemplate.modifiedBy_NTID;
        ProxyModified.createdBy_NTID = assessorTemplate.createdBy_NTID;
        ProxyModified.modifiedBy_NTID = assessorTemplate.modifiedBy_NTID;
        if (!this.proxies.some(e => assessorTemplate.modifiedBy_NTID != null && e.ntid.toLowerCase() === assessorTemplate.modifiedBy_NTID.toLowerCase())) {
          this.proxies.push(ProxyModified);
        }

        if (this.sharedService.ntid && this.proxies && this.proxies.length > 0) {
          this.proxy = this.proxies.filter(x => x.ntid == this.sharedService.ntid
            || (x.createdBy_NTID != null && x.createdBy_NTID.toLowerCase() == this.sharedService.ntid.toLowerCase())
            || (x.modifiedBy_NTID != null && x.modifiedBy_NTID.toLowerCase() == this.sharedService.ntid.toLowerCase()));

        }
        if (this.proxy && this.proxy.length > 0) {
          this.assessorTemplateService.assessorTemplate = assessorTemplate;
          this.router.navigate([environment.home + '/assessors/assessor-edit']);
        }
        else {
          this.alertText = this.labels.default.notAuthorizedToEdit;
          this.modalService.show(this.lockModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          this.router.navigate([environment.home + '/assessors']);
        }
      }, err => console.error(err));
    }
    else {
      this.assessorTemplateService.assessorTemplate = assessorTemplate;
      this.router.navigate([environment.home + '/assessors/assessor-edit']);
    }

  }

  order: string = "displayName";
  reverse: boolean = false;
  setOrder(value: string) {
    if (this.order === value) {
      this.reverse = !this.reverse;
    }

    this.order = value
  }


// ***********************************filtering************************************************************
 //resetting all the filtering and sorting
 resetAll(){
  this.reverse1=false;
  this.filtertext="";
  }

  //#region sorting
 //*********************sorting*********
 sort(key){
    this.key = this.headerFilterName;;
   this.reverse1 = !this.reverse1;
 }
  getButtonType(buttonname:any):any{
   this.filterType=buttonname;
  }
  // *********************************
  //#endregion sorting
  closeAlert()
  {
    if(document.getElementsByTagName("modal-container").length > 1){
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length-1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length-1]);
    }
    else{
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if(document.getElementsByTagName("bs-modal-backdrop").length > 0){
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }
  }

  public openAlertModal(popUp:any) {
    // this.filterPopUp.hide()
    this.closeAllPopups();

    // Store the new popup reference
    this.popUpInstances.push(popUp);
    this.filterPopUp = popUp;
    // this.filterPopUp = popUp;
  }

  
  public closeAlertModal(selectedFilter) {
    debugger;
    this.closeAllPopups();
    this.filterPopUp.hide();
   
  }
  private closeAllPopups() {
    this.popUpInstances.forEach((popUp) => popUp.hide());
    this.popUpInstances = []; // Clear the array
  }

  getColumnName(headername: any) {
  this.reverse = this.reverse;
  if (this.filteredItems == undefined) {
    this.filteredItems = []
  }

  this.assessorTemplateList = this.totalList;//newly added

  // this.filtertext = '';
  // this.filterId = false;
  // this.filterName = false;
  // this.filterLock = false;
  // this.filterModified = false;
  // this.filterModifiedBy = false;
  // this.filterCreated = false;
  // this.filterCreatedBy = false;

  if (headername == 'assessorTemplateDisplayID') {
    for (var i = 0; i < this.totalList.length; i++) {
      this.filteredItems.push(this.totalList[i].assessorTemplateDisplayID);
    }
    //this.filterId = !this.filterId;
  }

  else if (headername == 'assessorTemplateName') {
    for (var i = 0; i < this.totalList.length; i++) {
      this.filteredItems.push(this.totalList[i].assessorTemplateName);
    }
    //this.filterName = !this.filterName;
  }
  else if (headername == 'isLocked') {
    for (var i = 0; i < this.totalList.length; i++) {
      this.filteredItems.push(this.totalList[i].isLocked);
    }
    //this.filterLock = !this.filterLock;
  }
  else if (headername == 'modifiedAt') {
    for (var i = 0; i < this.totalList.length; i++) {
      this.filteredItems.push(this.datePipe.transform(this.totalList[i].modifiedAt,this.filterdateFormat));
    }
    //this.filterModified = !this.filterModified;
  }
  else if (headername == 'modifiedBy') {
    for (var i = 0; i < this.totalList.length; i++) {
      this.filteredItems.push(this.totalList[i].modifiedBy);
    }
   // this.filterModifiedBy = !this.filterModifiedBy;
  }
  else if (headername == 'createdAt') {
    for (var i = 0; i < this.totalList.length; i++) {
      this.filteredItems.push(this.datePipe.transform(this.totalList[i].createdAt,this.filterdateFormat));
    }
    //this.filterCreated = !this.filterCreated;
  }
  else if (headername == 'createdBy') {
    for (var i = 0; i < this.totalList.length; i++) {
      this.filteredItems.push(this.totalList[i].createdBy);
    }
    //this.filterCreatedBy = !this.filterCreatedBy;
  }
  this.headerFilterName = headername;
  this.searchFilter();
}
  setForm() {
    this.form = new FormGroup({
      name: new FormControl(
        this.dataCopy
      )
    });
    this.loadContent = true;
  }
  searchFilter(){

    this.data=[];
     // ********************************searching

  if(this.headerFilterName=="assessorTemplateName"){
      for(var assessorDet of this.assessorTemplateList){
      let newItem={
        assessorTemplateID:assessorDet.assessorTemplateID,
        assessorTemplateName:assessorDet.assessorTemplateName
      };
      if(!this.data.includes(newItem)){
        if (!this.data.some(e => e.assessorTemplateName === assessorDet.assessorTemplateName)) {//newly added
          this.data.push(newItem);
        }
      }
    }
  }
  else if(this.headerFilterName=="isLocked"){

    for(var assessorDet of this.assessorTemplateList){
      let newItem={
        assessorTemplateID:assessorDet.assessorTemplateID,
        isLocked:assessorDet.isLocked
      };
      if(!this.data.includes(newItem)){
        if (!this.data.some(e => e.isLocked === assessorDet.isLocked)) {//newly added
          this.data.push(newItem);
        }
      }
    }
  }
    else if (this.headerFilterName == "modifiedAt") {
      for (var assessorDet of this.assessorTemplateList) {
        this.str1= this.datePipe.transform(assessorDet.modifiedAt,this.filterdateFormat);//converting the date format
        let newItem = {
          assessorTemplateID: assessorDet.assessorTemplateID,
          modifiedAt: this.str1
        };
        if (!this.data.includes(newItem)) {
            if (!this.data.some(e => e.modifiedAt ===  this.str1)) {
              this.data.push(newItem);
            }
        }
      }
    }
    else if (this.headerFilterName == "modifiedBy") {


      for (var assessorDet of this.assessorTemplateList) {
        let newItem = {
          assessorTemplateID: assessorDet.assessorTemplateID,
          modifiedBy: assessorDet.modifiedBy
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.modifiedBy === assessorDet.modifiedBy)) {
            this.data.push(newItem);
          }
        }
      }
    }
  else if(this.headerFilterName=="createdAt"){
    for(var assessorDet of this.assessorTemplateList){
      this.str1= this.datePipe.transform(assessorDet.createdAt,this.filterdateFormat);//converting the date format
      let newItem={
        assessorTemplateID:assessorDet.assessorTemplateID,
        createdAt:this.str1
      };
      if(!this.data.includes(newItem)){
        if (!this.data.some(e => e.createdAt === this.str1)) {
          this.data.push(newItem);
        }
      }
    }
  }
  else if(this.headerFilterName=="createdBy"){
    for(var assessorDet of this.assessorTemplateList){
      let newItem={
        assessorTemplateID:assessorDet.assessorTemplateID,
        createdBy:assessorDet.createdBy
      };
      if(!this.data.includes(newItem)){
        if (!this.data.some(e => e.createdBy === assessorDet.createdBy)) {
          this.data.push(newItem);
        }
      }
    }
  }

  else if (this.headerFilterName == "assessorTemplateDisplayID") {
    for (var assessorDet of this.assessorTemplateList) {
      let newItem = {
        assessorTemplateID:assessorDet.assessorTemplateID,
        assessorTemplateDisplayID: assessorDet.assessorTemplateDisplayID
      };
      if (!this.data.includes(newItem)) {
        if (!this.data.some(e => e.assessorTemplateDisplayID === assessorDet.assessorTemplateDisplayID)) {
          this.data.push(newItem);
        }
      }
    }
    }

    this.dataCopy=JSON.parse(JSON.stringify(this.data))
    this.settings = {//setting for multiselect dropdown
       singleSelection: false,
       idField: 'assessorTemplateID',
       textField: this.headerFilterName,


       enableCheckAll: true,
       selectAllText: 'Select All',
       unSelectAllText: 'Unselect All',
       allowSearchFilter: true,
       limitSelection: -1,
       clearSearchFilter: true,
       maxHeight: 197,
       itemsShowLimit: 0,
       searchPlaceholderText: 'Search',
       noDataAvailablePlaceholderText: 'No Data Available',
       closeDropDownOnSelection: false,
       showSelectedItemsAtTop: false,
       defaultOpen: false
     };
     this.setForm();
     // ************************************************
  }
// ************************************filtering ends******************************************************
// ***********************************Dropdown multiselect filtering**************************
filteredItems: Array<any>;
onItemSelect(item: any) {

    if(this.filteredItems == undefined){
     this.filteredItems = [];
    }
    if(this.headerFilterName=='assessorTemplateName'){
      if(this.filteredItems.indexOf(item.assessorTemplateName)    <0)
      {
        this.filteredItems.push(item.assessorTemplateName);
      }
      this.assessorTemplateList=this.totalList.filter(f => this.filteredItems.includes(f.assessorTemplateName));
    }
    else if(this.headerFilterName=='isLocked'){
      if(this.filteredItems.indexOf(item.isLocked)    <0)
      {
        this.filteredItems.push(item.isLocked);
      }
      this.assessorTemplateList=this.totalList.filter(f => this.filteredItems.includes(f.isLocked));
    }
    else if(this.headerFilterName=='modifiedAt'){
      if(this.filteredItems.indexOf(item.modifiedAt)    <0)
      {
        this.filteredItems.push(item.modifiedAt);
      }
      this.assessorTemplateList=this.totalList.filter(f => this.filteredItems.includes(this.datePipe.transform(f.modifiedAt,this.filterdateFormat)));
    }

    else if(this.headerFilterName=='modifiedBy'){
      if(this.filteredItems.indexOf(item.modifiedBy)    <0)
      {
        this.filteredItems.push(item.modifiedBy);
      }
      this.assessorTemplateList=this.totalList.filter(f => this.filteredItems.includes(f.modifiedBy));
    }
    else if(this.headerFilterName=='createdAt'){
      if(this.filteredItems.indexOf(item.createdAt)    <0)
      {
        this.filteredItems.push(item.createdAt);
      }
      this.assessorTemplateList=this.totalList.filter(f => this.filteredItems.includes(this.datePipe.transform(f.createdAt,this.filterdateFormat)));
    }
    else if(this.headerFilterName=='createdBy'){
      if(this.filteredItems.indexOf(item.createdBy)    <0)
      {
        this.filteredItems.push(item.createdBy);
      }
      this.assessorTemplateList=this.totalList.filter(f => this.filteredItems.includes(f.createdBy));
  }

    else if (this.headerFilterName == 'assessorTemplateDisplayID') {
      if (this.filteredItems.indexOf(item.assessorTemplateDisplayID) < 0) {
        this.filteredItems.push(item.assessorTemplateDisplayID);
      }
      this.assessorTemplateList = this.totalList.filter(f => this.filteredItems.includes(f.assessorTemplateDisplayID));
  }

  }

  public onDeSelect(item: any) {

    if (this.filteredItems == undefined) {
      this.filteredItems = [];
    }

    if (this.headerFilterName == 'assessorTemplateName') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.assessorTemplateName);
      this.assessorTemplateList = this.totalList.filter(f => this.filteredItems.includes(f.assessorTemplateName));
    }
    else if (this.headerFilterName == 'isLocked') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.isLocked);
      this.assessorTemplateList = this.totalList.filter(f => this.filteredItems.includes(f.isLocked));
    }
    else if (this.headerFilterName == 'modifiedAt') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.modifiedAt);
      this.assessorTemplateList=this.totalList.filter(f => this.filteredItems.includes(this.datePipe.transform(f.modifiedAt,this.filterdateFormat)));
    }
    else if (this.headerFilterName == 'modifiedBy') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.modifiedBy);
      this.assessorTemplateList = this.totalList.filter(f => this.filteredItems.includes(f.modifiedBy));
    }
    else if (this.headerFilterName == 'createdAt') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.createdAt);
      // this.assessorTemplateList = this.totalList.filter(f => this.filteredItems.includes(f.createdAt));
      this.assessorTemplateList=this.totalList.filter(f => this.filteredItems.includes(this.datePipe.transform(f.createdAt,this.filterdateFormat)));
    }
    else if (this.headerFilterName == 'createdBy') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.createdBy);
      this.assessorTemplateList = this.totalList.filter(f => this.filteredItems.includes(f.createdBy));
    }
    else if (this.headerFilterName == 'assessorTemplateDisplayID') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.assessorTemplateDisplayID);
      this.assessorTemplateList = this.totalList.filter(f => this.filteredItems.includes(f.assessorTemplateDisplayID));
    }
  }

  onOpenDropdown(){
    console.log("open ")
    console.log("datcopy",this.dataCopy)
    console.log(this.data)
    this.dataCopy = [...this.dataCopy];
   // this.cdr.detectChanges();
  }
  onSelectAll(items: any) {

    if(this.filteredItems == undefined ){
      this.filteredItems = [];
     }
    for(var i=0;i<items.length;i++){
      if(this.headerFilterName=='assessorTemplateName'){
        this.filteredItems.push(items[i].assessorTemplateName)
      }
      else if(this.headerFilterName=='isLocked'){
        this.filteredItems.push(items[i].isLocked)
      }
      else if(this.headerFilterName=='modifiedAt'){
        this.filteredItems.push(items[i].modifiedAt)
      }
      else if(this.headerFilterName=='modifiedBy'){
        this.filteredItems.push(items[i].modifiedBy)
      }
      else if(this.headerFilterName=='createdAt'){
        this.filteredItems.push(items[i].createdAt)
      }
      else if(this.headerFilterName=='createdBy'){
        this.filteredItems.push(items[i].createdBy)
      }
      else if (this.headerFilterName == 'assessorTemplateDisplayID') {
        this.filteredItems.push(items[i].assessorTemplateDisplayID)
      }

    }
    this.assessorTemplateList=this.totalList;
  }
  public onDeSelectAll(items: any) {
    this.filteredItems=[];
    this.assessorTemplateList=this.totalList;
  }
  public onFilterChange(item: any) {


  }

//  *******************************************************************************************Dropdown filtering ends here***************
// ************************************filtering ends******************************************************
  //  *****************Export Import Assessor Excel*************
  AssessorExportExcel() {
    window.location.href = environment.baseUrl + 'AssessorTemplate/AssessorExportExcel';

  }

  AssessorImportExcel(inputFile: File) {

    let formData = new FormData();

    formData.append('upload', inputFile);
    formData.append('ntid', this.sharedService.ntid);
    this.assessorTemplateService.AssessorImportExcel(formData).subscribe(result => {

      this.alertText = this.labels.default.saveSuccessfully;
      this.modalService.show(this.successModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      this.getAssessorTemplateList();
    });

  }
  // ********************************


  //to fix scroll issue after pop up
  public closeInsertModal() {
    if (document.getElementsByTagName("modal-container").length > 1) {
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1]);
    }
    else {
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if (document.getElementsByTagName("bs-modal-backdrop").length > 0) {
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }

  }

  ExportExcelAssessor() {
    this.dataPoolService.GetExcelFile("Assessor");
  }

  exportAsXLSX() {
    debugger;
    var IDs = this.assessorTemplateList.map(r => {
      return r.assessorTemplateID
    });
    this.dataPoolService.GetExcelFileByIDs("Assessor", IDs);
  }

  searchGrid(value: string) {
    if (value.length > 0) {
      var searchText = value.trim().toLowerCase();
      this.assessorTemplateList = this.totalList;
      this.sharedService.activeDateRange.asSearchText = value;

      this.assessorTemplateList = this.assessorTemplateList.filter(x =>
        (x.assessorTemplateName != null && x.assessorTemplateName.trim().toLowerCase().includes(searchText))
        || (x.isLocked != null && x.isLocked.toString().trim().toLowerCase().includes(searchText))
        || (x.modifiedAt != null && this.datePipe.transform(x.modifiedAt, this.filterdateFormat).trim().toLowerCase().includes(searchText))
        || (x.modifiedBy != null && x.modifiedBy.trim().toLowerCase().includes(searchText))
        || (x.createdAt != null && this.datePipe.transform(x.createdAt, this.filterdateFormat).trim().toLowerCase().includes(searchText))
        || (x.createdBy != null && x.createdBy.trim().toLowerCase().includes(searchText))
      );
      this.page = 1;
    }
    else {
      this.assessorTemplateList = this.totalList;
      this.sharedService.activeDateRange.asSearchText = "";
    }
  }

}
