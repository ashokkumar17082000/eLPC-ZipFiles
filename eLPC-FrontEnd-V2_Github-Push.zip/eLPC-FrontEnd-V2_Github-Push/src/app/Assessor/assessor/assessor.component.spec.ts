import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AssessorComponent } from './assessor.component';
import { HttpClientModule } from '@angular/common/http';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { NgxPaginationModule } from 'ngx-pagination';
//import { ColumnFilterPipe } from 'src/app/service/common/column-filter.pipe.spec';
import { OrderPipe } from 'ngx-order-pipe';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { ModalModule, BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { RouterTestingModule } from '@angular/router/testing';
import { DatePipe } from '@angular/common';

describe('AssessorComponent', () => {
  let component:AssessorComponent;
  let fixture: ComponentFixture<AssessorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AssessorComponent,  OrderPipe],
      imports: [HttpClientModule, PaginationModule, NgxPaginationModule, 
                ModalModule.forRoot(),RouterTestingModule.withRoutes([])],
      providers:[BsModalService, BsModalRef, DatePipe],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA], 


    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssessorComponent);
    component = fixture.componentInstance;
    // component.ngOnInit();
    fixture.detectChanges();
  });

  // it('getAssessorTemplateList', () => {
  //   component.getAssessorTemplateList();
  //   fixture.detectChanges();
  // });
  
  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
