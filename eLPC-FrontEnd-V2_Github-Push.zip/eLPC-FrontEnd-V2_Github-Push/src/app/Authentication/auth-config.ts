import { LogLevel, Configuration, BrowserCacheLocation } from '@azure/msal-browser';
import { environment } from 'src/environments/environment';

const isIE = window.navigator.userAgent.indexOf("MSIE ") > -1 || window.navigator.userAgent.indexOf("Trident/") > -1;

let commonApiURL = environment.commonApiURL;
let scopes = environment.scopes;
let apiURL = environment.apiURL;
//alert(commonApiURL + ""+scopes+""+apiURL);
export const msalConfig: Configuration = {
  auth: {
    clientId: '5cb603e8-b798-42c9-bd79-229dd7b7a54e',
    authority: 'https://login.microsoftonline.com/0ae51e19-07c8-4e4b-bb6d-648ee58410f4',
    redirectUri: '/'
  },
  cache: {
    cacheLocation: BrowserCacheLocation.LocalStorage, // Configures cache location. "sessionStorage" is more secure, but "localStorage" gives you SSO between tabs.
    storeAuthStateInCookie: true,
    //storeAuthStateInCookie: isIE, // Set this to "true" if you are having issues on IE11 or Edge

  },
  system: {
    loggerOptions: {
      loggerCallback(logLevel: LogLevel, message: string) {
     //   console.log(message);
      },
      logLevel: LogLevel.Verbose,
      piiLoggingEnabled: false
    }
  }
}
export const protectedResources = {
  todoListApi: {
    endpoint:  commonApiURL,    //"http://localhost:62639/api/",
    scopes:   [scopes]  //["api://3cd19a01-069a-49cf-9dd2-7a117908132e/Files.Read"]
  },
  anotherApi: {
    endpoint:  apiURL,//"http://localhost:61468/api/",
    scopes:   [scopes] //["api://3cd19a01-069a-49cf-9dd2-7a117908132e/Files.Read"]
  },
  graphApi: {
    endpoint: 'https://graph.microsoft.com/v1.0/users',
    scopes: ['User.ReadBasic.All']
  }
}
export const loginRequest = {
  scopes: ['profile', 'openid', 'email', ...protectedResources.todoListApi.scopes, 'User.ReadBasic.All']
};
