import { Component, OnInit,Inject } from "@angular/core";
import { Router } from "@angular/router";
//import { SharedService } from "../service/shared.service";
import { SharedService } from "src/app/service/shared.service";
//import { CommonService } from "../service/common/common.service";
import { CommonService } from "src/app/service/common/common.service";
import { HttpClient } from "@angular/common/http";
//import { User } from "../main/body/shared/common";
import { User,AzureADUserDetails } from "src/app/main/body/shared/common";
import { environment } from "src/environments/environment";

import { MsalService, MsalBroadcastService, MSAL_GUARD_CONFIG, MsalGuardConfiguration } from '@azure/msal-angular';
import { EventMessage, EventType,AuthenticationResult, BrowserAuthError, InteractionRequiredAuthError, InteractionStatus, InteractionType, PopupRequest, RedirectRequest } from '@azure/msal-browser';
import {protectedResources} from './../../auth-config';
import { Observable, Subject, throwError } from 'rxjs';
import { catchError, filter, takeUntil } from 'rxjs/operators';
import {UserDetailsService} from '../../../service/user-details.service';

@Component({
  selector: "app-check-auth",
  templateUrl: "./check-auth.component.html",
  styleUrls: ["./check-auth.component.css"]
})

export class CheckAuthComponent implements OnInit {
  userName: string;
  role: any;
  ntid: any;
  displayName: any;
  user: User = new User();
  isProd: any = environment.production;

  //Azure OpenId
  isIframe = false;
  loginDisplay = false;
  private readonly _destroying$ = new Subject<void>();
  displayedColumns: string[] = ['claim', 'value'];
  dataSource: any =[];
  public azuserdet: AzureADUserDetails;

  constructor(
    private _router: Router,
    private sharedService: SharedService,
    private commonService: CommonService,
    private http: HttpClient,
    @Inject(MSAL_GUARD_CONFIG) private msalGuardConfig: MsalGuardConfiguration,
    private authService: MsalService,
    private msalBroadcastService: MsalBroadcastService,
    private userDetailsService: UserDetailsService
  ){}

 ngOnInit() {
  //alert('hello');
  // Hide the shared service spinner or loader
  this.sharedService.hide();
  this.isIframe = window !== window.parent && !window.opener;

  // Subscribe to MSAL events to update login display
  this.msalBroadcastService.inProgress$
    .pipe(
      filter((status: InteractionStatus) => status === InteractionStatus.None),
      takeUntil(this._destroying$),
      catchError((error) => this.handleError(error)) // Add error handling
    )
    .subscribe(() => {
      this.setLoginDisplay();
    });

  // Handle login success event
  this.msalBroadcastService.msalSubject$
    .pipe(
      filter((msg: EventMessage) => msg.eventType === EventType.LOGIN_SUCCESS),
      takeUntil(this._destroying$),
      catchError((error) => this.handleError(error)) // Add error handling
    )
    .subscribe((result: EventMessage) => {
      try {
        const payload = result.payload as AuthenticationResult;
        this.authService.instance.setActiveAccount(payload.account);
      } catch (error) {
        this.handleError(error); // Fallback error handling
      }
    });

  // Update login display and handle account claims
  this.msalBroadcastService.inProgress$
    .pipe(
      filter((status: InteractionStatus) => status === InteractionStatus.None),
      takeUntil(this._destroying$),
      catchError((error) => this.handleError(error)) // Add error handling
    )
    .subscribe(() => {
      try {
        this.setLoginDisplay();
        this.checkAndSetActiveAccount();
        this.getClaims(this.authService.instance.getActiveAccount()?.idTokenClaims);
      } catch (error) {
        this.handleError(error); // Fallback error handling
      }
    });

  // Attempt login with error handling
  try {
    this.login();
  } catch (error) {
    this.handleError(error); // Handle any login errors
  }
}

// Error handling function
private handleError(error: any): Observable<never> {
  console.error('An error occurred:', error);
  this.sharedService.errorMessage = "<h3>You are not authorized to access eLPC application</h3>";
  this._router.navigate([environment.home + '/appinfo']);
  return throwError(() => new Error('Redirected due to error'));
}

setLoginDisplay() {
  this.loginDisplay = this.authService.instance.getAllAccounts().length > 0;
}

checkAndSetActiveAccount() {
  //debugger;
  /**
   * If no active account set but there are accounts signed in, sets first account to active account
   * To use active account set here, subscribe to inProgress$ first in your component
   * Note: Basic usage demonstrated. Your app may require more complicated account selection logic
   */
  let activeAccount = this.authService.instance.getActiveAccount();

  if (!activeAccount && this.authService.instance.getAllAccounts().length > 0) {
    let accounts = this.authService.instance.getAllAccounts();
    this.authService.instance.setActiveAccount(accounts[0]);
  }
}

getClaims(claims: any) {
  debugger;
  console.log(claims);
  this.dataSource = [
    {id: 1, claim: "Display Name", value: claims ? claims['name'] : null},
    {id: 2, claim: "User Principal Name (UPN)", value: claims ? claims['preferred_username'] : null},
    {id: 2, claim: "OID", value: claims ? claims['oid']: null}
  ];

  this.azuserdet = new AzureADUserDetails();
  this.azuserdet.CustomIConID = 0;
  this.azuserdet.Department = claims ? claims['Department'] : '';
  this.azuserdet.EmailAddress=  claims ? claims['email'] : '';
  this.azuserdet.EmployeeID = null;
  this.azuserdet.FirstName = claims ? claims['surname'] : '';
  this.azuserdet.IsGroupNameRequired = false;
  this.azuserdet.IsValueStream = false;
  this.azuserdet.LastName = claims ? claims['givenname'] : '';
  this.azuserdet.Location = null;
  this.azuserdet.NTID = claims ? claims['SamAccountName'] : '';
  this.azuserdet.Office = null;
  this.azuserdet.PlantID = 0;
  this.azuserdet.RoleName = null;
  this.azuserdet.Role_roleID = 0;
  this.azuserdet.UserID = 0;
  this.azuserdet.UserName = claims ? claims['DisplayName'] : '';
  this.azuserdet.Roles = claims ? claims['groups']: [];
  this.sharedService.azuserdet = this.azuserdet;
  localStorage.setItem("ntid", this.azuserdet.NTID);
  localStorage.setItem("azureuserprofile", JSON.stringify(this.azuserdet));

  this.login();
}

  // login() {
  //   debugger;
  //   console.log(this.user.ntid)
  //   this.sharedService.show();
  //   // var result = this.sharedService.login(this.user.ntid, this._router, environment.home + '/dashboard');
  //   var resultLogin = this.sharedService.GetEnironmentConfigFromDBAndLogin(this.user.ntid, this._router, environment.home + '/dashboard');
  //   {

  //     localStorage.setItem('ntid', this.user.ntid.toString().toUpperCase());
  //   //  this._router.navigate([environment.home + '/dashboard'])
  //   }
  // }

  login() {
    // debugger;
     this.sharedService.show();
     // var result = this.sharedService.login(this.user.ntid, this._router, environment.home + '/dashboard');
     if (this.azuserdet && this.azuserdet.NTID !== undefined && this.azuserdet.NTID !== null)
     {
       var resultLogin = this.sharedService.GetEnironmentConfigFromDBAndLogin(this.azuserdet.NTID, this._router, environment.home + '/dashboard',this.azuserdet);
       {
         if (this.user && this.user.ntid !== undefined && this.user.ntid !== null) {
           localStorage.setItem('ntid', this.user.ntid.toString().toUpperCase());
       }
       }
     }

   }
}
