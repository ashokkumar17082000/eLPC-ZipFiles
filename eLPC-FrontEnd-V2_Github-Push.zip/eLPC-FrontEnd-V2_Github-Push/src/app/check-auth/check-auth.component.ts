import { Component, OnInit,Inject } from "@angular/core";
import { Router } from "@angular/router";
//import { SharedService } from "../service/shared.service";
import { SharedService } from "src/app/service/shared.service";
//import { CommonService } from "../service/common/common.service";
import { CommonService } from "src/app/service/common/common.service";
import { HttpClient } from "@angular/common/http";
//import { User } from "../main/body/shared/common";
import { User,AzureADUserDetails } from "src/app/main/body/shared/common";
import { environment } from "src/environments/environment";

import { MsalService, MsalBroadcastService, MSAL_GUARD_CONFIG, MsalGuardConfiguration } from '@azure/msal-angular';
import { EventMessage, EventType,AuthenticationResult, BrowserAuthError, InteractionRequiredAuthError, InteractionStatus, InteractionType, PopupRequest, RedirectRequest } from '@azure/msal-browser';
import {protectedResources} from './../Authentication/auth-config';
import { Observable, Subject, throwError } from 'rxjs';
import { catchError, filter, takeUntil } from 'rxjs/operators';
import {UserDetailsService} from '../.././app/service/user-details.service';

@Component({
  selector: "app-check-auth",
  templateUrl: "./check-auth.component.html",
  styleUrls: ["./check-auth.component.css"]
})

export class CheckAuthComponent implements OnInit {
  userName: string;
  role: any;
  ntid: any;
  displayName: any;
  user: User = new User();
  isProd: any = environment.production;

  //Azure OpenId
  isIframe = false;
  loginDisplay = false;
  private readonly _destroying$ = new Subject<void>();
  displayedColumns: string[] = ['claim', 'value'];
  dataSource: any =[];
  public azuserdet: AzureADUserDetails;

  constructor(
    private _router: Router,
    private sharedService: SharedService,
    private commonService: CommonService,
    private http: HttpClient,
    @Inject(MSAL_GUARD_CONFIG) private msalGuardConfig: MsalGuardConfiguration,
    private authService: MsalService,
    private msalBroadcastService: MsalBroadcastService,
    private userDetailsService: UserDetailsService
  ){}

 // ngOnInit() {


 ngOnInit() {
  //debugger;

  this.sharedService.hide();
  this.isIframe = window !== window.parent && !window.opener;

  /**
   * You can subscribe to MSAL events as shown below. For more info,
   * visit: https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-angular/docs/v2-docs/events.md
   */
  this.msalBroadcastService.inProgress$
    .pipe(
      filter((status: InteractionStatus) => status === InteractionStatus.None),
      takeUntil(this._destroying$)
    )
    .subscribe(() => {
      this.setLoginDisplay();
    });

    // Attempt Silent SSO
 // this.silentLogin();


 this.msalBroadcastService.msalSubject$
 .pipe(
   filter((msg: EventMessage) => msg.eventType === EventType.LOGIN_SUCCESS),
   takeUntil(this._destroying$)
 )
 .subscribe((result: EventMessage) => {
   //debugger;
   console.log(result);
   const payload = result.payload as AuthenticationResult;
   this.authService.instance.setActiveAccount(payload.account);
 });

 this.msalBroadcastService.inProgress$
 .pipe(
   filter((status: InteractionStatus) => status === InteractionStatus.None)
 )
 .subscribe(() => {
   //debugger;
   this.setLoginDisplay();
   this.checkAndSetActiveAccount();
   this.getClaims(this.authService.instance.getActiveAccount()?.idTokenClaims)
 });

 this.login();

}

//  ngOnInit() {
//   debugger;
//   // Hide the shared service spinner or loader
//   this.sharedService.hide();
//   this.isIframe = window !== window.parent && !window.opener;

//   // Subscribe to MSAL events to update login display
//   this.msalBroadcastService.inProgress$
//     .pipe(
//       filter((status: InteractionStatus) => status === InteractionStatus.None),
//       takeUntil(this._destroying$),
//       catchError((error) => this.handleError(error)) // Add error handling
//     )
//     .subscribe(() => {
//       this.setLoginDisplay();
//     });

//   // Handle login success event
//   this.msalBroadcastService.msalSubject$
//     .pipe(
//       filter((msg: EventMessage) => msg.eventType === EventType.LOGIN_SUCCESS),
//       takeUntil(this._destroying$),
//       catchError((error) => this.handleError(error)) // Add error handling
//     )
//     .subscribe((result: EventMessage) => {
//       try {
//         const payload = result.payload as AuthenticationResult;
//         this.authService.instance.setActiveAccount(payload.account);
//       } catch (error) {
//         this.handleError(error); // Fallback error handling
//       }
//     });

//   // Update login display and handle account claims
//   this.msalBroadcastService.inProgress$
//     .pipe(
//       filter((status: InteractionStatus) => status === InteractionStatus.None),
//       takeUntil(this._destroying$),
//       catchError((error) => this.handleError(error)) // Add error handling
//     )
//     .subscribe(() => {
//       try {
//         this.setLoginDisplay();
//         this.checkAndSetActiveAccount();
//         this.getClaims(this.authService.instance.getActiveAccount()?.idTokenClaims);
//       } catch (error) {
//         this.handleError(error); // Fallback error handling
//       }
//     });

//   // Attempt login with error handling
//   try {
//     this.login();
//   } catch (error) {
//     this.handleError(error); // Handle any login errors
//   }
// }

// Error handling function
private handleError(error: any): Observable<never> {
  console.error('An error occurred:', error);
  this.sharedService.errorMessage = "<h3>You are not authorized to access eLPC application</h3>";
  this._router.navigate([environment.home + '/appinfo']);
  return throwError(() => new Error('Redirected due to error'));
}

setLoginDisplay() {
  this.loginDisplay = this.authService.instance.getAllAccounts().length > 0;
}

silentLogin() {
  const request = {
      scopes: [ 'profile',
      'openid',
      'email'],
      loginHint: "user@domain.com" // Optionally provide a login hint
  };

  this.authService.ssoSilent(request).subscribe({
      next: (response: AuthenticationResult) => {
          this.authService.instance.setActiveAccount(response.account);
          this.setLoginDisplay();
          console.log("Silent SSO successful:", response.accessToken);
      },
      error: (error: any) => {
          console.error("Silent SSO failed:", error);
          if (error instanceof InteractionRequiredAuthError) {
              // Fall back to interactive login
              this.login();
          } else if (error instanceof BrowserAuthError && error.errorCode === 'monitor_window_timeout') {
              console.error("Silent SSO timeout, retrying...");
              // Optionally implement retry logic here
              this.login();
          }
      }
  });
}


// checkAndSetActiveAccount() {
//   //debugger;
//   /**
//    * If no active account set but there are accounts signed in, sets first account to active account
//    * To use active account set here, subscribe to inProgress$ first in your component
//    * Note: Basic usage demonstrated. Your app may require more complicated account selection logic
//    */
//   let activeAccount = this.authService.instance.getActiveAccount();

//   if (!activeAccount && this.authService.instance.getAllAccounts().length > 0) {
//     let accounts = this.authService.instance.getAllAccounts();
//     this.authService.instance.setActiveAccount(accounts[0]);
//   }
// }

checkAndSetActiveAccount() {
  let activeAccount = this.authService.instance.getActiveAccount();
  const accounts = this.authService.instance.getAllAccounts();

  if (!activeAccount && accounts.length > 0) {
    this.authService.instance.setActiveAccount(accounts[0]); // Choose the first account (or implement logic for the correct one)
  }
}

// login_Azure() {
//   //debugger;
//   if (this.msalGuardConfig.interactionType === InteractionType.Popup) {
//     if (this.msalGuardConfig.authRequest) {
//       this.authService.loginPopup({ ...this.msalGuardConfig.authRequest,
//         scopes: [
//           'profile',
//           'openid',
//           'email',...protectedResources.todoListApi.scopes, 'User.ReadBasic.All'
//         ] } as PopupRequest)
//         .subscribe((response: AuthenticationResult) => {
//           this.authService.instance.setActiveAccount(response.account);
//         });
//     } else {
//       this.authService.loginPopup({
//         scopes: [
//           'profile',
//           'openid',
//           'email',...protectedResources.todoListApi.scopes, 'User.ReadBasic.All'
//         ]
//       })
//         .subscribe((response: AuthenticationResult) => {
//           this.authService.instance.setActiveAccount(response.account);
//         });
//     }
//   } else {
//     if (this.msalGuardConfig.authRequest) {
//       this.authService.loginRedirect({ ...this.msalGuardConfig.authRequest,
//         scopes: [
//           'profile',
//           'openid',
//           'email',...protectedResources.todoListApi.scopes, 'User.ReadBasic.All'
//         ] } as RedirectRequest);
//     } else {
//       this.authService.loginRedirect({
//         scopes: [
//           'profile',
//           'openid',
//           'email',...protectedResources.todoListApi.scopes, 'User.ReadBasic.All'
//         ]
//       });
//     }
//   }
// }

// login_Azure() {
//   const account = this.authService.instance.getActiveAccount();

//   if (this.msalGuardConfig.interactionType === InteractionType.Popup) {
//     this.authService.loginPopup({
//       scopes: [
//         'profile', 'openid', 'email',
//         ...protectedResources.todoListApi.scopes,
//         'User.ReadBasic.All'
//       ],
//       account: account // Specify the active account
//     } as PopupRequest).subscribe((response: AuthenticationResult) => {
//       this.authService.instance.setActiveAccount(response.account);
//     });
//   } else {
//     this.authService.loginRedirect({
//       scopes: [
//         'profile', 'openid', 'email',
//         ...protectedResources.todoListApi.scopes,
//         'User.ReadBasic.All'
//       ],
//       account: account // Specify the active account
//     } as RedirectRequest);
//   }
// }


login_Azure() {
  //debugger;
  if (this.msalGuardConfig.interactionType === InteractionType.Popup) {
    if (this.msalGuardConfig.authRequest) {
      this.authService.loginPopup({ ...this.msalGuardConfig.authRequest,
        scopes: [
          'profile',
          'openid',
          'email',...protectedResources.todoListApi.scopes, 'User.ReadBasic.All'
        ] } as PopupRequest)
        .subscribe((response: AuthenticationResult) => {
          this.authService.instance.setActiveAccount(response.account);
        });
    } else {
      this.authService.loginPopup({
        scopes: [
          'profile',
          'openid',
          'email',...protectedResources.todoListApi.scopes, 'User.ReadBasic.All'
        ]
      })
        .subscribe((response: AuthenticationResult) => {
          this.authService.instance.setActiveAccount(response.account);
        });
    }
  } else {
    if (this.msalGuardConfig.authRequest) {
      this.authService.loginRedirect({ ...this.msalGuardConfig.authRequest,
        scopes: [
          'profile',
          'openid',
          'email',...protectedResources.todoListApi.scopes, 'User.ReadBasic.All'
        ] } as RedirectRequest);
    } else {
      this.authService.loginRedirect({
        scopes: [
          'profile',
          'openid',
          'email',...protectedResources.todoListApi.scopes, 'User.ReadBasic.All'
        ]
      });
    }
  }
}

logout() {
  this.authService.logout();
}

// unsubscribe to events when component is destroyed
ngOnDestroy(): void {
  this._destroying$.next(undefined);
  this._destroying$.complete();
}

getClaims(claims: any) {
  debugger;
  console.log(claims);

  // Check if the user profile is already cached
  const cachedProfile = localStorage.getItem("azureuserprofile");
  // if (cachedProfile) {
  //   console.log("Using cached user profile.");
  //   this.azuserdet = JSON.parse(cachedProfile);
  //   this.sharedService.azuserdet = this.azuserdet;
  //   this.login(); // Proceed with the login using cached data
  //   return;
  // }

  this.dataSource = [
    {id: 1, claim: "Display Name", value: claims ? claims['name'] : null},
    {id: 2, claim: "User Principal Name (UPN)", value: claims ? claims['preferred_username'] : null},
    {id: 2, claim: "OID", value: claims ? claims['oid']: null}
  ];
  this.azuserdet = new AzureADUserDetails();
  this.azuserdet.CustomIConID = 0;
  this.azuserdet.Department = claims ? claims['Department'] : '';
  this.azuserdet.EmailAddress=  claims ? claims['email'] : '';
  this.azuserdet.EmployeeID = null;
  this.azuserdet.FirstName = claims ? claims['surname'] : '';
  this.azuserdet.IsGroupNameRequired = false;
  this.azuserdet.IsValueStream = false;
  this.azuserdet.LastName = claims ? claims['givenname'] : '';
  this.azuserdet.Location = null;
  this.azuserdet.NTID = claims ? claims['SamAccountName'] : '';
  this.azuserdet.Office = null;
  this.azuserdet.PlantID = 0;
  this.azuserdet.RoleName = null;
  this.azuserdet.Role_roleID = 0;
  this.azuserdet.UserID = 0;
  this.azuserdet.UserName = claims ? claims['DisplayName'] : '';
  this.azuserdet.Roles = claims ? claims['groups']: [];
  this.sharedService.azuserdet = this.azuserdet;
  localStorage.setItem("ntid", this.azuserdet.NTID);
  localStorage.setItem("azureuserprofile", JSON.stringify(this.azuserdet));

  this.login();
}

  login() {
    // debugger;
     this.sharedService.show();
     // var result = this.sharedService.login(this.user.ntid, this._router, environment.home + '/dashboard');
     if (this.azuserdet && this.azuserdet.NTID !== undefined && this.azuserdet.NTID !== null)
     {
       var resultLogin = this.sharedService.GetEnironmentConfigFromDBAndLogin(this.azuserdet.NTID, this._router, environment.home + '/dashboard',this.azuserdet);
       {
         if (this.user && this.user.ntid !== undefined && this.user.ntid !== null) {
           localStorage.setItem('ntid', this.user.ntid.toString().toUpperCase());
       }
       }
     }

   }
}
