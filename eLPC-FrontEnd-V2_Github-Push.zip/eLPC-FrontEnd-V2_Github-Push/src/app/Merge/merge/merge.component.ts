import { DatePipe } from "@angular/common";
import { Component, OnInit, TemplateRef, ViewChild } from "@angular/core";
import { Router } from "@angular/router";
import { BsModalService } from "ngx-bootstrap/modal";
import { LanguageService } from "src/app/language.service";
import { AssessorTemplateService } from "src/app/service/assessor/assessortemplate.service";
import { CommonService } from "src/app/service/common/common.service";
import { ValuestreamTemplateService } from "src/app/service/common/valuestreamtemplate.service";
import { MergeService } from "src/app/service/merge.service";
import { QuestionService } from "src/app/service/question.service";
import { SharedService } from "src/app/service/shared.service";
import { TagService } from "src/app/service/tag.service";
import { environment } from "src/environments/environment";
import {
  Assessor,
  AssessorTemplate,
} from "src/app/Assessor/assessor/assessortemplate";
import { Question } from "src/app/Datapool/QuestionModule/questions/question";
import { User } from "src/app/main/body/shared/common";
import { AssessorValueStreamList, Tag } from "src/app/Tag/tag/tag";
import {
  ValueStream,
  ValueStreamCategory,
  ValueStreamTemplate,
} from "src/app/Valuestream/valuestreams/valuestreamtemplate";
import { Merge, MergeProxy } from "./merge";
import { es } from "date-fns/locale";
import { SearchService } from "src/app/service/search.service";
@Component({
  selector: "app-merge",
  templateUrl: "./merge.component.html",
  styleUrls: ["./merge.component.css"],
})
export class MergeComponent implements OnInit {
  dateTimeFormat = environment.dateTimeFormat;
  filterdateFormat = environment.dateTimeFormat.split(" ")[0];

  @ViewChild("successPopup") successModal: TemplateRef<any>;
  @ViewChild("alertPopup") warningModal: TemplateRef<any>;
  labels: any;
  _subscription: any;
  valueStreamTemplates: ValueStreamTemplate[] = [];
  valueStreamCategories: ValueStreamCategory[] = [];
  valueStreams: ValueStream[] = [];

  assessorTemplateList: AssessorTemplate[] = [];
  assessorTemplate: AssessorTemplate = new AssessorTemplate();
  assessors: Assessor[] = [];
  assessor: Assessor;
  question: Question = new Question();

  //for multiselect dropdown
  selectedValueStreams: ValueStream[] = [];
  selectedValueStreamIDs = [];
  valueStreamSettings = {};
  dropdownOpened: boolean = false;
  categorydropdownOpened:boolean= false;
  //for Assessor Multiselect dropdown
  selectedAssessors = [];
  selectedAssessorIDs = [];
  assessorSettings = {};
  assignedTargetFrequency = [];

  //For multi select dropdown - Value stream template
  dropdownSettingsValueStreamTemplate = {};
  selectedItemValueStreamTemplate: ValueStreamTemplate[] = [];

  //For multi select dropdown - Value stream Category
  dropdownSettingsValueStreamCategories = {};
  selectedItemValueStreamCategories: ValueStreamCategory[] = [];

  //For multi select dropdown - Assign tag to assessor template
  dropdownSettingsAssessorTemplate = {};
  selectedItemAssessorTemplate: AssessorTemplate[] = [];

  //Input filters
  selectedquestionorTags: number;
  selectedassignmentremovalorproxy: any;

  tagUnChecked: boolean;
  questionUnChecked: boolean;

  assignmentUnChecked: boolean;
  removalUnChecked: boolean;
  proxyUnChecked: boolean = false;

  questionassignmentselected: boolean = false;
  questionremovalselected: boolean = false;
  questionproxyselected: boolean = false;

  tagassignmentselected: boolean = false;
  tagremovalselected: boolean = false;
  tagproxyselected: boolean = false;

  //for Tags selection
  availableTags: Tag[] = [];
  allavailableTags: Tag[] = [];
  selectedTags: Tag[] = [];
  selectedTagIDs: string;
  tagList: Tag[] = [];
  tag: Tag = new Tag();

  questionOrders: { id: number }[];
  questionList: Question[];
  filteredQuestions: Question[] = [];
  filteredTags: Tag[] = [];
  selectedQuestionIDs: any;

  isLoading: boolean = false;
  selectedQuestions: Question[] = [];
  orderSelectedQuestions: Question[] = [];

  assessorValueStreamList: AssessorValueStreamList =
    new AssessorValueStreamList();

  visulizationViewModeID: any;

  isAssignment: boolean = true;

  mergeQuestionAssignment: Merge;

  isDisabled: boolean = true;
  alertText: string;

  questionProxy: MergeProxy;
  tagProxy: MergeProxy;

  // Holds the complete list of questions from the API
  availableQuestions: Question[] = [];

  totalList: Question[] = [];
  questionDetail: Question[] = [];
  questionSearchText: string;

  totalTagList: Tag[] = [];
  tagDetail: Tag[] = [];

  QuestionOrderList: any = [];
  resultQuestionOrder: any = [];
  randomQuestionOrder: any = [];

  pageSize: number = 3;

  page1 = 1;
  page2 = 1;

  // Pagination state
  availablePageIndex = 1; // Current page index (starts from 1)
  itemsPerPage = 5; // Number of items to show per page
  availableTagPageIndex = 1; // Current page index (starts from 1)

  // Page indices for both lists
  selectedPageIndex: number = 1; // For orderSelectedQuestions
  //availablePageIndex: number=1; // For availableQuestions

  // Page indices for both lists
  selectedTagPageIndex: number = 1; // For orderSelectedQuestions

  selectedTagsPageIndex: number; // For orderSelectedQuestions
  availableTagsPageIndex: number; // For availableQuestions

  lastPage: number; // Total number of pages
  showEllipsisLeft: boolean = false; // Flag for showing ellipsis on the left
  showEllipsisRight: boolean = false; // Flag for showing ellipsis on the right
  showEllipsisTagLeft: boolean = false; // Flag for showing ellipsis on the left
  showEllipsisTagRight: boolean = false; // Flag for showing ellipsis on the right

  quest = { searchText: "" };
  errorMessage: string;

  constructor(
    private modalService: BsModalService,
    private local_label: LanguageService,
    private sharedService: SharedService,
    private datePipe: DatePipe,
    private router: Router,
    private valueStreamService: ValuestreamTemplateService,
    private assessorTemplateService: AssessorTemplateService,
    private tagService: TagService,
    private questionService: QuestionService,
    private commonService: CommonService,
    private mergeService: MergeService,
    private searchService: SearchService
  ) {}

  ngOnInit() {
    if (this.sharedService.role !== "Designer") {
      this.router.navigate([environment.home + "/accessdenied"]);
    }

    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
    });

    this.searchService.getSearchResults().subscribe({
      next: (response: any) => {
        if (response && response.value) {
          this.activeDirectoryData = response.value;
          console.log("AD Data",this.activeDirectoryData)
          this.errorMessage = ''; // Clear any previous error messages
        } else {
          this.activeDirectoryData = [];
          this.errorMessage = 'No users found.';
        }
      },
      error: (err) => {
        console.error('Failed to fetch users from Graph API', err);
        this.errorMessage = 'Failed to fetch users. Please try again later.';
      },
    });
    this.sharedService.show();
    this.getQuestionDetail();
    this.getTagDetail();
    this.getValueStreamList();
    this.getAssessorTemplateList();
    this.getavailabletags();
    this.getTagQuestionList();
    this.onAssessorSelect(null); //to load the default tags
    this.onLoadAssessorTemplate();

    this.tagUnChecked = true;
    this.assignmentUnChecked = true;

    this.valueStreamSettings = {
      singleSelection: false,
      idField: "valueStreamID",
      textField: "valueStreamName",
      selectAllText: "Select All",
      unSelectAllText: "UnSelect All",
      itemsShowLimit: 3,
      allowSearchFilter: true,
    };
    this.selectedValueStreams = [];
    this.selectedValueStreamIDs = [];

    //For multi select dropdown - Value stream template
    this.dropdownSettingsValueStreamTemplate = {
      singleSelection: false,
      idField: "valueStreamTemplateID",
      textField: "valueStreamTemplateName",
      selectAllText: "Select All",
      unSelectAllText: "UnSelect All",
      itemsShowLimit: 5,
      allowSearchFilter: true,
      closeDropDownOnSelection: true,
    };

    //For multi select dropdown - Value stream Category
    this.dropdownSettingsValueStreamCategories = {
      singleSelection: false,
      idField: "valueStreamCategoryID",
      textField: "valueStreamCategoryName",
      selectAllText: "Select All",
      unSelectAllText: "UnSelect All",
      itemsShowLimit: 5,
      allowSearchFilter: true,
      closeDropDownOnSelection: true,
    };

    //For multi select dropdown - Assign tag to assessor template
    this.dropdownSettingsAssessorTemplate = {
      singleSelection: false,
      idField: "assessorTemplateID",
      textField: "assessorTemplateName",
      selectAllText: "Select All",
      unSelectAllText: "UnSelect All",
      itemsShowLimit: 5,
      allowSearchFilter: true,
      closeDropDownOnSelection: true,
    };

    //for Assessor
    this.assessorSettings = {
      singleSelection: false,
      idField: "assessorID",
      textField: "assessorName",
      selectAllText: "Select All",
      unSelectAllText: "UnSelect All",
      itemsShowLimit: 3,
      allowSearchFilter: true,
    };
    this.selectedAssessors = [];
    this.valueStreams = [];
  }

  // Get the questions to display based on the current page
  get paginatedQuestions() {
    const startIndex = (this.availablePageIndex - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return this.availableQuestions.slice(startIndex, endIndex);
  }

  // Get the questions to display based on the current page
  get selectedpaginatedQuestions() {
    const startIndex = (this.selectedPageIndex - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return this.selectedQuestions.slice(startIndex, endIndex);
  }

  // Get the questions to display based on the current page
  get paginatedTags() {
    const startIndex = (this.availableTagPageIndex - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return this.availableTags.slice(startIndex, endIndex);
  }

  // Get the questions to display based on the current page
  get selectedpaginatedTags() {
    const startIndex = (this.selectedTagPageIndex - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return this.selectedTags.slice(startIndex, endIndex);
  }

  // Method to calculate the total number of pages
  get totalPages() {
    return Math.ceil(this.availableQuestions.length / this.itemsPerPage);
  }

  get selectedtotalPages() {
    return Math.ceil(this.selectedQuestions.length / this.itemsPerPage);
  }

  // Method to calculate the total number of pages
  get totalTagPages() {
    return Math.ceil(this.availableTags.length / this.itemsPerPage);
  }

  get selectedTagtotalPages() {
    return Math.ceil(this.selectedTags.length / this.itemsPerPage);
  }

  // Method to calculate the displayed page numbers dynamically
  get displayedPages() {
    const totalPages = this.totalPages;
    const currentPage = this.availablePageIndex;

    let startPage: number;
    let endPage: number;

    // Calculate displayed pages and set flags for ellipses
    if (totalPages <= 10) {
      startPage = 1;
      endPage = totalPages;
      this.showEllipsisLeft = false;
      this.showEllipsisRight = false;
    } else {
      if (currentPage <= 3) {
        // Pages: 1...3, 4, 5
        startPage = 2;
        endPage = 5;
        this.showEllipsisLeft = false;
        this.showEllipsisRight = true;
      } else if (currentPage + 2 >= totalPages) {
        // Pages: 1...8, 9, 10
        startPage = totalPages - 4;
        endPage = totalPages - 1;
        this.showEllipsisLeft = true;
        this.showEllipsisRight = false;
      } else {
        // Pages: 1...5, 6, 7, 8, 9...10
        startPage = currentPage - 2;
        endPage = currentPage + 2;
        this.showEllipsisLeft = true;
        this.showEllipsisRight = true;
      }
    }

    return Array.from(
      endPage === startPage ? "" : { length: endPage - startPage + 1 },
      (_, i) => startPage + i
    );
    //return Array.from({ length: endPage - startPage + 1 }, (_, i) => startPage + i);
  }

  get selecteddisplayedPages() {
    const totalPages = this.selectedtotalPages;
    const currentPage = this.selectedPageIndex;

    let startPage: number;
    let endPage: number;

    // Calculate displayed pages and set flags for ellipses
    if (totalPages <= 10) {
      startPage = 1;
      endPage = totalPages;
      this.showEllipsisLeft = false;
      this.showEllipsisRight = false;
    } else {
      if (currentPage <= 3) {
        // Pages: 1...3, 4, 5
        startPage = 2;
        endPage = 3;
        this.showEllipsisLeft = false;
        this.showEllipsisRight = true;
      } else if (currentPage + 2 >= totalPages) {
        // Pages: 1...8, 9, 10
        startPage = totalPages - 4;
        endPage = totalPages - 1;
        this.showEllipsisLeft = true;
        this.showEllipsisRight = false;
      } else {
        // Pages: 1...5, 6, 7, 8, 9...10
        startPage = currentPage - 2;
        endPage = currentPage + 2;
        this.showEllipsisLeft = true;
        this.showEllipsisRight = true;
      }
    }
    return Array.from(
      { length: endPage - startPage + 1 },
      (_, i) => startPage + i
    );
  }
  // Method to calculate the displayed page numbers dynamically
  get tagdisplayedPages() {
    const totalTagPages = this.totalTagPages;
    const currentTagPage = this.availableTagPageIndex;

    let startTagPage: number;
    let endTagPage: number;

    // Calculate displayed pages and set flags for ellipses
    if (totalTagPages <= 10) {
      startTagPage = 1;
      endTagPage = totalTagPages;
      this.showEllipsisTagLeft = false;
      this.showEllipsisTagRight = false;
    } else {
      if (currentTagPage <= 3) {
        // Pages: 1...3, 4, 5
        startTagPage = 2;
        endTagPage = 5;
        this.showEllipsisTagLeft = false;
        //this.showEllipsisTagRight = true;
      } else if (currentTagPage + 2 >= totalTagPages) {
        // Pages: 1...8, 9, 10
        startTagPage = totalTagPages - 4;
        endTagPage = totalTagPages - 1;
        this.showEllipsisTagLeft = true;
        this.showEllipsisTagRight = false;
      } else {
        // Pages: 1...5, 6, 7, 8, 9...10
        startTagPage = currentTagPage - 2;
        endTagPage = currentTagPage + 2;
        this.showEllipsisTagLeft = true;
        this.showEllipsisTagRight = true;
      }
    }
    return Array.from(
      endTagPage === startTagPage
        ? ""
        : { length: endTagPage - startTagPage + 1 },
      (_, i) => startTagPage + i
    );
    //return Array.from({ length: endTagPage - startTagPage + 1 }, (_, i) => startTagPage + i);
  }

  get tagselecteddisplayedPages() {
    const totalPages = this.selectedTagtotalPages;
    const currentPage = this.selectedTagPageIndex;

    let startPage: number;
    let endPage: number;

    // Calculate displayed pages and set flags for ellipses
    if (totalPages <= 10) {
      startPage = 1;
      endPage = totalPages;
      this.showEllipsisLeft = false;
      this.showEllipsisRight = false;
    } else {
      if (currentPage <= 3) {
        // Pages: 1...3, 4, 5
        startPage = 2;
        endPage = 3;
        this.showEllipsisLeft = false;
        this.showEllipsisRight = true;
      } else if (currentPage + 2 >= totalPages) {
        // Pages: 1...8, 9, 10
        startPage = totalPages - 4;
        endPage = totalPages - 1;
        this.showEllipsisLeft = true;
        this.showEllipsisRight = false;
      } else {
        // Pages: 1...5, 6, 7, 8, 9...10
        startPage = currentPage - 2;
        endPage = currentPage + 2;
        this.showEllipsisLeft = true;
        this.showEllipsisRight = true;
      }
    }
    return Array.from(
      { length: endPage - startPage + 1 },
      (_, i) => startPage + i
    );
  }

  // // Method to handle page change (Previous / Next)
  onAvailablePageChange(direction: "previous" | "next") {
    if (direction === "previous" && this.availablePageIndex > 1) {
      this.availablePageIndex--;
    } else if (
      direction === "next" &&
      this.availablePageIndex * this.itemsPerPage <
        this.availableQuestions.length
    ) {
      this.availablePageIndex++;
    }
  }

  // // Method to handle page change (Previous / Next)
  onSelectedPageChange(direction: "previous" | "next") {
    if (direction === "previous" && this.selectedPageIndex > 1) {
      this.selectedPageIndex--;
    } else if (
      direction === "next" &&
      this.selectedPageIndex * this.itemsPerPage < this.selectedQuestions.length
    ) {
      this.selectedPageIndex++;
    }
  }

  // // Method to handle page change (Previous / Next)
  onAvailableTagPageChange(direction: "previous" | "next") {
    if (direction === "previous" && this.availableTagPageIndex > 1) {
      this.availableTagPageIndex--;
    } else if (
      direction === "next" &&
      this.availableTagPageIndex * this.itemsPerPage < this.availableTags.length
    ) {
      this.availableTagPageIndex++;
    }
  }

  // // Method to handle page change (Previous / Next)
  onSelectedTagPageChange(direction: "previous" | "next") {
    if (direction === "previous" && this.selectedTagPageIndex > 1) {
      this.selectedTagPageIndex--;
    } else if (
      direction === "next" &&
      this.selectedTagPageIndex * this.itemsPerPage < this.selectedTags.length
    ) {
      this.selectedTagPageIndex++;
    }
  }

  // Method to handle individual page selection
  onPageSelect(page: number) {
    this.availablePageIndex = page;
  }

  onPageSeleSelect(page: number) {
    this.selectedPageIndex = page;
  }

  // Method to handle individual page selection
  onTagPageSelect(page: number) {
    this.availableTagPageIndex = page;
  }

  onTagPageSeleSelect(page: number) {
    this.selectedTagPageIndex = page;
  }

  //template
  public getValueStreamList() {
    this.valueStreamTemplates = [];
    this.valueStreamService.getValueStreamTemplate().subscribe(
      (res) => {
        this.valueStreamTemplates = [];
        this.valueStreamTemplates = res;
        this.valueStreamTemplates = this.valueStreamTemplates.filter(
          (x) => x.isAccessible == true
        );
        console.log(this.valueStreamTemplates);
        // this.onLoadValueStreamTemplate();
        this.valueStreamService.getValueStreamCategory().subscribe(
          (res1) => {
            this.valueStreamCategories = res1;
            this.valueStreamCategories = this.valueStreamCategories.filter(
              (x) =>
                x.valueStreamCategoryName !== "VS Responsible Employee" &&
                x.valueStreamCategoryName !== "SHIFT"
            );

            this.valueStreamService.getValueStream().subscribe(
              (res2) => {

                if (
                  this.selectedItemValueStreamTemplate.filter(
                    (x) => x.visualizationViewModeID == 2
                  ).length == 0
                ) {
                  this.question.assigned_ValueStreamCategoryID = undefined;
                  this.valueStreamCategories = [];
                }

                this.valueStreams = this.valueStreams.filter((r) =>
                  this.selectedItemValueStreamTemplate.find(
                    (x) => x.valueStreamTemplateID == r.valueStreamTemplateID
                  )
                );

                this.valueStreamCategories = this.valueStreamCategories.filter(
                  (r) =>
                    this.selectedItemValueStreamTemplate.find(
                      (x) =>
                        x.valueStreamTemplateID == r.valueStreamTemplateID &&
                        x.visualizationViewModeID == 2
                    )
                );

                this.assessors = this.assessors.filter((t) =>
                  this.selectedItemAssessorTemplate.find(
                    (x) => x.assessorTemplateID == t.assessorTemplateID
                  )
                );

                this.sharedService.hide();
              },
              (err) => {
                console.log(err);
              }
            );
          },
          (err) => {
            console.log(err);
          }
        );
      },
      (err) => {
        console.log(err);
      }
    );
  }

  public getAssessorTemplateList() {
    this.assessorTemplateList = [];
    this.assessorTemplateService.getAssessorTemplates().subscribe(
      (res) => {
        this.assessorTemplateList = res;
        console.log(res);
        this.assessorTemplateList = this.assessorTemplateList.filter(
          (x) => x.isAccessible == true
        );
        console.log(this.assessorTemplateList);
        this.onLoadAssessorTemplate();

      },
      (err) => {
        console.log(err);
      }
    );
  }

  //For multi select dropdown - Value stream template
  onSelectValueStreamTemplate(item: ValueStreamTemplate) {
    //this.question.assigned_ValueStreamTemplateID=undefined;
    this.valueStreamTemplateChange(item.valueStreamTemplateID);
  }

  onDeSelectValueStreamTemplate(item: ValueStreamTemplate) {

    var valueStreamsCategoryByTemplateID = this.valueStreamCategories
      .filter((x) => x.valueStreamTemplateID != item.valueStreamTemplateID)
      .map((y) => {
        return y.valueStreamCategoryID;
      });
    //Removing Value Streams from Original VS array on Unselecting the Template ID
    this.valueStreamCategories = this.valueStreamCategories.filter(
      (x) => x.valueStreamTemplateID != item.valueStreamTemplateID
    );
    //Removing Value Streams from selected Choice List
    this.selectedItemValueStreamCategories =
      this.selectedItemValueStreamCategories.filter((x) =>
        valueStreamsCategoryByTemplateID.includes(x.valueStreamCategoryID)
      );
    //Identifying the removed Template ValueStreams from ValueStream Array
    var valueStreamsByTemplateID = this.valueStreams
      .filter((x) => x.valueStreamTemplateID != item.valueStreamTemplateID)
      .map((y) => {
        return y.valueStreamID;
      });
    //Removing Value Streams from Original VS array on Unselecting the Template ID
    this.valueStreams = this.valueStreams.filter(
      (x) => x.valueStreamTemplateID != item.valueStreamTemplateID
    );
    //Removing Value Streams from selected Choice List
    this.selectedValueStreams = this.selectedValueStreams.filter((x) =>
      valueStreamsByTemplateID.includes(x.valueStreamID)
    );
  }

  onValueStreamTemplateSelectAll() {

    var TreeViewModeVS = Object.values(
      Object.assign({}, this.valueStreamTemplates)
    )
      .filter((x) => x.visualizationViewModeID == 2)
      .map((y) => {
        return y.valueStreamTemplateID;
      });
    this.valueStreams = [];
    this.valueStreamCategories = [];
    this.valueStreamService.getValueStreamCategory().subscribe(
      (res) => {
        this.valueStreamCategories = res.filter(
          (x) =>
            TreeViewModeVS.includes(x.valueStreamTemplateID) &&
            x.valueStreamCategoryName.trim() != "VS Responsible Employee" &&
            x.valueStreamCategoryName.trim() != "SHIFT"
        );
        this.valueStreamService.getValueStream().subscribe(
          (res) => {
            this.valueStreams = res;
          },
          (err) => {
            console.log(err);
          }
        );
      },
      (err) => {
        console.log(err);
      }
    );
  }

  onValueStreamTemplateDeSelectAll() {
    this.selectedItemValueStreamCategories = [];
    this.selectedItemValueStreamTemplate = [];
    this.selectedValueStreams = [];
    this.valueStreams = [];
    this.valueStreamCategories = [];
  }

  onLoadValueStreamTemplate() {
    this.selectedItemValueStreamTemplate = [];
    if (this.question.valueStreamTemplateNameArL == undefined) {
      return;
    } else {
      this.selectedItemValueStreamTemplate = this.valueStreamTemplates.filter(
        (x) =>
          this.question.valueStreamTemplateNameArL.find(
            (r) => r.vsTemplateID == x.valueStreamTemplateID
          )
      );
    }
  }

  // to load the value streams based on list/tree view in VS Template
  valueStreamTemplateChange(valueStreamTempID: any) {

    this.visulizationViewModeID = this.valueStreamTemplates.filter(
      (x) => x.valueStreamTemplateID == valueStreamTempID
    )[0].visualizationViewModeID;

    if (this.visulizationViewModeID == 2) {
      const selectedItem = this.valueStreamCategories.find(
        (x) => x.valueStreamTemplateID == valueStreamTempID
      );

      if (selectedItem === undefined) {
        this.valueStreamService
          .getValueStreamCategoryByTemplateID(valueStreamTempID)
          .subscribe(
            (res) => {
              //this.valueStreamCategories = [];
              //this.valueStreamCategories = res;
              this.valueStreamCategories.push(...res);
              this.valueStreamCategories = this.valueStreamCategories.filter(
                (x) =>
                  x.valueStreamCategoryName !== "VS Responsible Employee" &&
                  x.valueStreamCategoryName !== "SHIFT"
              );
              this.onLoadValueStreamCategories();
            },
            (err) => {
              console.log(err);
            }
          );
      }

      if (selectedItem !== undefined) {
        this.valueStreamService
          .getValueStreamCategoryByTemplateID(valueStreamTempID)
          .subscribe(
            (res) => {
              this.valueStreamCategories = [];
              //this.valueStreamCategories = res;
              this.valueStreamCategories.push(...res);
              this.valueStreamCategories = this.valueStreamCategories.filter(
                (x) =>
                  x.valueStreamCategoryName !== "VS Responsible Employee" &&
                  x.valueStreamCategoryName !== "SHIFT"
              );
              this.onLoadValueStreamCategories();
            },
            (err) => {
              console.log(err);
            }
          );
      }
    } else {
      const selectedItem = this.valueStreams.find(
        (x) => x.valueStreamTemplateID == valueStreamTempID
      );

      if (selectedItem === undefined) {
        this.valueStreamService
          .getValueStreamsByTemplateID(valueStreamTempID)
          .subscribe(
            (res) => {
              //this.valueStreams = [];
              //this.valueStreams = res;
              this.valueStreams.push(...res);
              this.valueStreams = this.valueStreams.filter(
                (x) => x.valueStreamName && x.responsible_UserID
              );
            },
            (err) => {
              console.log(err);
            }
          );
      }

      if (selectedItem !== undefined) {
        this.valueStreamService
          .getValueStreamsByTemplateID(valueStreamTempID)
          .subscribe(
            (res) => {
              this.valueStreams = [];
              //this.valueStreams = res;
              this.valueStreams.push(...res);
              this.valueStreams = this.valueStreams.filter(
                (x) => x.valueStreamName && x.responsible_UserID
              );
            },
            (err) => {
              console.log(err);
            }
          );
      }
    }
  }

  onSelectValueStreamCategories(item: ValueStreamCategory) { 
    this.categorydropdownOpened=false;
    this.tag.assigned_ValueStreamCategoryID = undefined;
    this.valueStreamCategoryChange(item.valueStreamCategoryID);
  }

  valueStreamCategoryChange(valueStreamCategoryID: any) {
    const selectedItem = this.valueStreams.find(
      (x) => x.valueStreamCategoryID == valueStreamCategoryID
    );

    if (selectedItem === undefined) {
      this.valueStreamService
        .getValueStreamsByCategoryID(valueStreamCategoryID)
        .subscribe(
          (res) => {
            this.valueStreams.push(...res);
            //this.valueStreams = res;
            this.valueStreams = this.valueStreams.filter(
              (x) => x.valueStreamName && x.responsible_UserID
            );
          },
          (err) => {
            console.log(err);
          }
        );
    }

    if (selectedItem !== undefined) {
      this.valueStreamService
        .getValueStreamsByCategoryID(valueStreamCategoryID)
        .subscribe(
          (res) => {
            this.valueStreams = [];
            this.valueStreams.push(...res);
            //this.valueStreams = res;
            this.valueStreams = this.valueStreams.filter(
              (x) => x.valueStreamName && x.responsible_UserID
            );
          },
          (err) => {
            console.log(err);
          }
        );
    }
  }

  onLoadValueStreamCategories() {
    this.selectedItemValueStreamCategories = [];

    if (
      !this.question.assigned_ValueStreamCategoryID ||
      this.question.assigned_ValueStreamCategoryID === []
    )
      return;
    for (
      let ind = 0;
      ind < this.question.assigned_ValueStreamCategoryID.length;
      ind++
    ) {
      const selectedItem = this.valueStreamCategories.find(
        (x) =>
          x.valueStreamCategoryID ===
          this.question.assigned_ValueStreamCategoryID[ind]
      );
      if (selectedItem)
        this.selectedItemValueStreamCategories.push(selectedItem);
    }
  }

  onSelectAllAssessorTemplate() {
    this.assessors = [];
    this.assessorTemplateService.getAssessors().subscribe(
      (res) => {
        this.assessors = res;
      },
      (err) => {
        console.log(err);
      }
    );
  }

  onDeSelectAllAssessorTemplate() {
    this.question.assigned_AssessorTemplateID = undefined;
    this.assessors = [];
    this.selectedAssessors = [];
  }

  onItemSelect(item: any) {
    this.onAssessorSelect();
  }

  onSelectAll(items: any) {
    this.onAssessorSelect();
  }

  onassessorOpen() {
    console.log(this.assessors);
    this.isLoading = true;
    this.assessors = JSON.parse(JSON.stringify(this.assessors));
    this.isLoading = false;
  }
  oncategoryDropdownclicked(){
    setTimeout(() => {
      if (!this.categorydropdownOpened) { 
        console.log("Dropdown Opened!");
        this. onValuestreamCategoryOpen();
        this.categorydropdownOpened = true;
      }
    }, 100); // Small delay to differentiate opening from selection
   
  }
  
  onDropdownClick() {
    setTimeout(() => {
      if (!this.dropdownOpened) { 
        console.log("Dropdown Opened!");
        this.onValuestreamOpen();
        this.dropdownOpened = true;
      }
    }, 100); // Small delay to differentiate opening from selection
  } 
  onValuestreamOpen() {
    this.isLoading = true;
    this.valueStreams = JSON.parse(JSON.stringify(this.valueStreams));
    this.isLoading = false;
  }
  onValuestreamCategoryOpen() {
    this.isLoading = true;
    this.valueStreamCategories = JSON.parse(
      JSON.stringify(this.valueStreamCategories)
    );
    this.isLoading = false;
  }

  assessorIDs: string;
  valueStreamIDs: string;
  onAssessorSelect(item?: any) {
    this.dropdownOpened = false; // Reset when selecting an option
    const valueStreamsIDArr = this.valueStreams.map((r) =>
      r.valueStreamID.toString()
    );
    const assessorIDArr = this.assessors.map((r) => r.assessorID.toString());
    if (this.isAssignment) {
      this.selectedValueStreams = this.selectedValueStreams.filter((t) =>
        this.valueStreams.find((x) => x.valueStreamID == t.valueStreamID)
      );

      this.selectedAssessors = this.selectedAssessors.filter((t1) =>
        this.assessors.find((x) => x.assessorID == t1.assessorID)
      );
    }

    this.assessorValueStreamList.assessorIDs = assessorIDArr.toString();
    this.assessorValueStreamList.valueStreamIDs = valueStreamsIDArr.toString();
    console.log(this.onAssessorSelectAll);
    //this.mergeassignment();

    this.mergeQuestionAssignment = new Merge();

    if (this.selectedValueStreams.length == 0 && this.onAssessorSelectAll) {
      this.mergeQuestionAssignment.valueStreams = this.valueStreams;
    } else {
      this.mergeQuestionAssignment.valueStreams = this.selectedValueStreams;
    }
    if (this.selectedAssessors.length == 0 && this.onAssessorSelectAll) {
      this.mergeQuestionAssignment.assessors = this.assessors;
    } else {
      this.mergeQuestionAssignment.assessors = this.selectedAssessors;
    }
    //this.mergeQuestionAssignment.assessors = this.selectedAssessors;
    this.mergeQuestionAssignment.tags = this.selectedTags;
    this.mergeQuestionAssignment.questions = this.selectedQuestions;
  }
  onAssessorSelectAll(items: any) {
    this.dropdownOpened = false; // Reset when selecting all options   
    this.onAssessorSelect(undefined);
  }

  //For multi select dropdown - Assign tag to assessor template
  onSelectAssessorTemplate(item: AssessorTemplate) {
    if (this.assessors.length == 0) {
      this.assessorTemplateService.getAssessors().subscribe(
        (res) => {
          this.assessors = res;
          this.getAssessorsByTemplateID(item.assessorTemplateID);
        },
        (err) => {
          console.log(err);
        }
      );
    } else {
      this.getAssessorsByTemplateID(item.assessorTemplateID);
    }
  }

  onDeSelectAssessorTemplate(item: AssessorTemplate) {
    if (
      !this.selectedItemAssessorTemplate ||
      this.selectedItemAssessorTemplate.length === 0
    ) {
      this.question.assigned_AssessorTemplateID = undefined;
    }

    //this.question.assigned_AssessorTemplateID = this.question.assigned_AssessorTemplateID.filter(x => { x != item.assessorTemplateID });

    var assessorsByTemplateID = this.assessors
      .filter((x) => x.assessorTemplateID != item.assessorTemplateID)
      .map((y) => {
        return y.assessorID;
      });
    //Removing Value Streams from Original VS array on Unselecting the Template ID
    this.assessors = this.assessors.filter(
      (x) => x.assessorTemplateID != item.assessorTemplateID
    );
    //Removing Value Streams from selected Choice List
    this.selectedAssessors = this.selectedAssessors.filter((x) =>
      assessorsByTemplateID.includes(x.assessorID)
    );

    if (this.selectedItemAssessorTemplate.length < 1) {
      this.assessors = [];
      this.selectedAssessors = [];
    }
  }

  onLoadAssessorTemplate() {
    this.selectedItemAssessorTemplate = [];

    if (this.question.assessorTemplateNameArL == undefined) {
      return;
      //this.sharedService.hide();
    } else {
      this.selectedItemAssessorTemplate = this.assessorTemplateList.filter(
        (x) =>
          this.question.assessorTemplateNameArL.find(
            (r) => r.vsTemplateID == x.assessorTemplateID
          )
      );
    }
    this.sharedService.hide();
  }

  public getAssessorsByTemplateID(templateID: any) {
    let selectedItem = this.assessors.find(
      (x) => x.assessorTemplateID == templateID
    );
    this.assessors = this.assessors.filter((t) =>
      this.selectedItemAssessorTemplate.find(
        (x) => x.assessorTemplateID == t.assessorTemplateID
      )
    );
    if (selectedItem == undefined) {
      this.assessorTemplateService
        .getAssessorsByTemplateID(templateID)
        .subscribe(
          (res) => {
            let X = this.assessors;
            this.assessors = res;
            this.assessors.push(...X);
            console.log(this.assessors);
          },
          (err) => {
            console.log(err);
          }
        );
    }

    if (selectedItem !== undefined) {
      this.assessorTemplateService
        .getAssessorsByTemplateID(templateID)
        .subscribe(
          (res) => {
            this.assessors = [];
            this.assessors.push(...res);
            console.log(this.assessors);
          },
          (err) => {
            console.log(err);
          }
        );
    }
  }
  //to clear Unselected tag or question  bases on selection
  clearTagQuestion(value: any) {
    this.reloadMerge();

    //
    if (value) {
      console.log(value, "On Clear ");
      this.selectedquestionorTags = value;
      if (value == 1) {
        this.tagUnChecked = true;
        this.questionUnChecked = false;
      } else {
        this.questionUnChecked = true;
        this.tagUnChecked = false;
      }
    }
  }

  // Method to perform the actual search based on the search text
  searchTagOrQuestion(searchText: string) {
    let text = searchText.trim().toLowerCase();

    // Start by assuming the filtered questions are all available questions
    let filteredQuestions = [...this.availableQuestions]; // Reset to all available questions

    // Check if text exists and is not empty
    if (text) {
      // Try to convert the text into a number
      let numericText = Number(text);

      if (isNaN(numericText)) {
        // If it's not a valid number, perform search based on questionText

        this.questionDetail = this.totalList;

        this.availableQuestions = this.totalList.filter(
          (x) =>
            x.isAccessible == true &&
            x.questionText.toLowerCase().includes(text)
        );
        this.availablePageIndex=1;
        // this.questionService.getQuestions().subscribe(
        //   (res) => {
        //     this.availableQuestions = res;
        //     this.availableQuestions = this.availableQuestions.filter(
        //       (x) =>
        //         x.isAccessible == true &&
        //         x.questionText.toLowerCase().includes(text)
        //     );
        //     console.log(this.availableQuestions, this.paginatedQuestions);
        //   },
        //   (err) => {
        //     console.log(err);
        //   }
        // );
      } else {
        // Perform filtering based on questionDisplayID being equal to numericText (strictly matching)

        this.availableQuestions = this.totalList.filter(
          (x) =>
            x.isAccessible == true && x.questionDisplayID === numericText
        );
        this.availablePageIndex=1;
        // this.questionService.getQuestions().subscribe(
        //   (res) => {
        //     this.availableQuestions = res;
        //     this.availableQuestions = this.availableQuestions.filter(
        //       (x) =>
        //         x.isAccessible == true && x.questionDisplayID === numericText
        //     );
        //     console.log(this.availableQuestions, this.paginatedQuestions);
        //   },
        //   (err) => {
        //     console.log(err);
        //   }
        // );
      }
    } else {
      // If no search text is provided, reset or fetch the full list of questions
      this.availableQuestions = this.totalList.filter(
        (x) => x.isAccessible == true
      );
     //this.getTagQuestionList();
    }
  }

  searchTag() {
    // Get and trim the search text, then convert to lowercase
    let text = this.tag.searchText?.trim().toLowerCase();

    console.log(text, this.availableTags, "Before");

    // Start by assuming the filtered questions are all available questions
    this.filteredTags = [...this.availableTags]; // Reset to all available questions

    // Check if text exists and is not empty
    if (text) {
      // Try to convert the text into a number
      let numericText = Number(text);

      if (isNaN(numericText)) {
        // If it's not a valid number, perform search based on questionText

        this.availableTags = this.totalTagList;

        this.availableTags = this.totalTagList.filter(
          (x) =>
            x.isAccessible == true && x.tagName.toLowerCase().includes(text)
        );
        this.availableTagPageIndex = 1;

        // this.tagService.getTags().subscribe(
        //   (res) => {
        //     this.availableTags = res;
        //     this.availableTags = this.availableTags.filter(
        //       (x) =>
        //         x.isAccessible == true && x.tagName.toLowerCase().includes(text)
        //     );
        //     this.availableTagPageIndex = 1;
        //     //this.sharedService.hide();
        //   },
        //   (err) => {
        //     console.log(err);
        //   }
        // );
      } else {
        // Perform filtering based on questionDisplayID being equal to numericText (strictly matching)

        this.availableTags = this.totalTagList.filter(
          (x) =>
            x.isAccessible == true && x.tagName.toLowerCase().includes(text)  
           );
          this.availableTagPageIndex = 1;
        // this.tagService.getTags().subscribe(
        //   (res) => {
        //     this.availableTags = res;
        //     this.availableTags = this.availableTags.filter(
        //       (x) =>
        //         x.isAccessible == true && x.tagName.toLowerCase().includes(text)
        //     );
        //     this.availableTagPageIndex = 1;
        //     //this.sharedService.hide();
        //   },
        //   (err) => {
        //     console.log(err);
        //   }
        // );
      }
    } else {
      // If no search text is provided, reset or fetch the full list of questions
      this.availableTags = this.availableTags.filter(
        (x) => x.isAccessible == true
      );

      // this.tagService.getTags().subscribe(
      //   (res) => {
      //     this.availableTags = res;
      //     this.availableTags = this.availableTags.filter(
      //       (x) => x.isAccessible == true
      //     );
      //     //this.sharedService.hide();
      //   },
      //   (err) => {
      //     console.log(err);
      //   }
      // );
    }
  }

  filterTagOrQuestion() {
    let text = this.tag.filterText;
  }

  removeTag(tag: Tag) {
    if (tag !== undefined && Object.keys(tag).length !== 0) {
      let id = tag.tagID;
      this.selectedTags = this.selectedTags.filter((x) => x.tagID !== id);
      this.availableTags.push(tag);
    }
  }

  removeQuestion(question: Question) {
    if (question !== undefined && Object.keys(question).length !== 0) {
      let id = question.questionID;
      this.selectedQuestions = this.selectedQuestions.filter(
        (x) => x.questionID !== id
      );
      this.orderSelectedQuestions = this.orderSelectedQuestions.filter(
        (x) => x.questionID !== id
      ); //to remove from questions order
      this.availableQuestions.push(question);
    }
  }

  //to clear Unselected Assignment or Tag or Proxy  bases on selection
  clearARP(value: any) {
    this.reloadMerge();
    //
    if (value) {
      this.selectedassignmentremovalorproxy = value;
      if (value == 3) {
        this.assignmentUnChecked = true;
        this.removalUnChecked = false;
        this.proxyUnChecked = false;
      } else if (value == 4) {
        this.assignmentUnChecked = false;
        this.removalUnChecked = true;
        this.proxyUnChecked = false;
      } else {
        this.assignmentUnChecked = false;
        this.removalUnChecked = false;
        this.proxyUnChecked = true;
      }
    }

    console.log(
      this.selectedquestionorTags,
      this.selectedassignmentremovalorproxy,
      "Combination"
    );

    if (this.selectedassignmentremovalorproxy == 5) {
      this.questionproxyselected = true;
    } else {
      this.questionproxyselected = false;
    }
  }

  lockTag() {
    // this.tagService.tag = this.tag;
    this.router.navigate([environment.home + "/taglist/tag-lock"]);
  }

  public getTagQuestionList() {
    this.questionService.getQuestions().subscribe(
      (res) => {
        this.questionList = res;
        this.availableQuestions = this.questionList;
        this.availableQuestions = this.availableQuestions.filter(
          (x) => x.isAccessible == true
        );
      },
      (err) => {
        console.log(err);
      }
    );
  }

  public questionSelected(question: Question) {
    if (this.selectedQuestions == undefined) {
      this.selectedQuestions = [];
    }
    var x = this.selectedQuestions.filter(
      (x) => x.questionID == question.questionID
    );
    if (x.length < 1) {
      this.selectedQuestions.push(question);
    }
    this.availableQuestions = this.availableQuestions.filter(
      (x) => x.questionID !== question.questionID
    );

    //to display the questions in branch order
    if (this.orderSelectedQuestions == undefined) {
      this.orderSelectedQuestions = [];
    }
    var x = this.orderSelectedQuestions.filter(
      (x) => x.questionID == question.questionID
    );
    if (x.length < 1) {
      this.orderSelectedQuestions.push(question);
    }
    console.log(this.orderSelectedQuestions, this.selectedQuestions);
  }

  getavailabletags() {
    this.tagService.fetchProcessConfirmationTags().subscribe((res) => {
      if (res && res.length > 0) {
        if (this.availableTags && this.availableTags.length > 1) {
          for (let tag of res) {
            if (
              this.availableTags.filter((x) => x.tagID == tag.tagID).length < 1
            ) {
              this.availableTags.push(tag);
              this.availableTags = this.availableTags.filter(
                (x) => x.isAccessible == true
              );
              this.allavailableTags = JSON.parse(
                JSON.stringify(this.availableTags)
              );
            }
          }
        } else {
          this.availableTags = res;
          this.availableTags = this.availableTags.filter(
            (x) => x.isAccessible == true
          );
          this.allavailableTags = JSON.parse(
            JSON.stringify(this.availableTags)
          );
        }
        //to filter the available tags based on selected tags
        if (this.selectedTags && this.selectedTags.length > 0) {
          for (let tag of this.selectedTags) {
            if (this.availableTags && this.availableTags.length > 0) {
              this.availableTags = this.availableTags.filter(
                (x) => x.tagID !== tag.tagID
              );
              this.availableTags = this.availableTags.filter(
                (x) => x.isAccessible == true
              );
              this.allavailableTags = JSON.parse(
                JSON.stringify(this.availableTags)
              );
            }
          }
        }
      }
      //this.sharedService.hide();
    });
  }

  //for tag selection

  public getTagList() {
    this.tagService.getTags().subscribe(
      (res) => {
        this.tagList = res;
        this.tagList = this.tagList.filter((x) => x.isAccessible == true);
        //this.sharedService.hide();
      },
      (err) => {
        console.log(err);
      }
    );
  }

  public tagSelected(tag: Tag) {
    if (this.selectedTags == undefined) {
      this.selectedTags = [];
    }

    var x = this.selectedTags.filter((x) => x.tagID == tag.tagID);
    if (x.length < 1) {
      this.selectedTags.push(tag);
    }
    this.availableTags = this.availableTags.filter(
      (x) => x.tagID !== tag.tagID
    );
    console.log(this.selectedTags);
  }

  //On Save Merge Setting
  saveMergettings() {
    this.isDisabled = false;

    if (this.assignmentUnChecked && this.tagUnChecked && !this.proxyUnChecked)
      if (
        !this.mergeQuestionAssignment.questions ||
        (this.mergeQuestionAssignment.questions.length < 1 &&
          !this.proxyUnChecked &&
          this.selectedQuestions.length < 1)
      ) {
        this.alertText = this.labels.default.selectAleastOneQuestion;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;
      } else if (
        this.mergeQuestionAssignment.valueStreams.length < 1 &&
        this.mergeQuestionAssignment.assessors.length < 1 &&
        this.mergeQuestionAssignment.tags.length < 1
      ) {
        this.alertText = this.labels.default.mergeoperation;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;

        return;
      } else {
        this.mergeService
          .mergeQuestionAssignment(this.mergeQuestionAssignment)
          .subscribe(
            (res) => {
              if (res.resultCode == 0) {
                this.sharedService.show();
                this.alertText = this.labels.default.saveSuccessfully;
                this.modalService.show(this.successModal);
                $("modal-container").removeClass("fade");
                $(".modal-dialog").addClass("modalSize");
                this.reloadMerge();
                this.sharedService.hide();
                return;
              }
            },
            (err) => {
              this.alertText = this.labels.default.insertOpertionFailed;
              this.modalService.show(this.warningModal);
              $("modal-container").removeClass("fade");
              $(".modal-dialog").addClass("modalSize");

              return;
            }
          );
      }

    if (
      this.assignmentUnChecked &&
      this.questionUnChecked &&
      !this.proxyUnChecked
    )
      if (
        !this.mergeQuestionAssignment.tags ||
        (this.mergeQuestionAssignment.tags.length < 1 &&
          !this.proxyUnChecked &&
          this.selectedTags.length < 1)
      ) {
        this.alertText = this.labels.default.selectAleastOneTag;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;
      } else if (
        this.mergeQuestionAssignment.valueStreams.length < 1 &&
        this.mergeQuestionAssignment.assessors.length < 1 &&
        this.mergeQuestionAssignment.questions.length < 1
      ) {
        this.alertText = this.labels.default.mergeoperation;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;

        return;
      } else {
        this.mergeService
          .mergeTagAssignment(this.mergeQuestionAssignment)
          .subscribe(
            (res) => {
              if (res.resultCode == 0) {
                this.sharedService.show();
                this.alertText = this.labels.default.saveSuccessfully;
                this.modalService.show(this.successModal);
                $("modal-container").removeClass("fade");
                $(".modal-dialog").addClass("modalSize");
                this.reloadMerge();
                this.sharedService.hide();

                return;
              }
            },
            (err) => {
              this.alertText = this.labels.default.insertOpertionFailed;
              this.modalService.show(this.warningModal);
              $("modal-container").removeClass("fade");
              $(".modal-dialog").addClass("modalSize");
              // this.sharedService.hide();
              return;
            }
          );
      }

    if (this.removalUnChecked && this.tagUnChecked && !this.proxyUnChecked)
      if (
        !this.mergeQuestionAssignment.questions ||
        (this.mergeQuestionAssignment.questions.length < 1 &&
          !this.proxyUnChecked &&
          this.selectedQuestions.length < 1)
      ) {
        this.alertText = this.labels.default.selectAleastOneQuestion;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;
      } else if (
        this.mergeQuestionAssignment.valueStreams.length < 1 &&
        this.mergeQuestionAssignment.assessors.length < 1 &&
        this.mergeQuestionAssignment.tags.length < 1
      ) {
        this.alertText = this.labels.default.mergeoperation;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;

        return;
      } else {
        this.mergeService
          .mergeQuestionRemoval(this.mergeQuestionAssignment)
          .subscribe(
            (res) => {
              if (res.resultCode == 0) {
                this.sharedService.show();
                this.alertText = this.labels.default.saveSuccessfully;
                this.modalService.show(this.successModal);
                $("modal-container").removeClass("fade");
                $(".modal-dialog").addClass("modalSize");
                this.reloadMerge();
                this.sharedService.hide();

                return;
              }
            },
            (err) => {
              this.alertText = this.labels.default.insertOpertionFailed;
              this.modalService.show(this.warningModal);
              $("modal-container").removeClass("fade");
              $(".modal-dialog").addClass("modalSize");
              // this.sharedService.hide();
              return;
            }
          );
      }

    if (this.removalUnChecked && this.questionUnChecked && !this.proxyUnChecked)
      if (
        !this.mergeQuestionAssignment.tags ||
        (this.mergeQuestionAssignment.tags.length < 1 &&
          !this.proxyUnChecked &&
          this.selectedTags.length < 1)
      ) {
        this.alertText = this.labels.default.selectAleastOneTag;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;
      } else if (
        this.mergeQuestionAssignment.valueStreams.length < 1 &&
        this.mergeQuestionAssignment.assessors.length < 1 &&
        this.mergeQuestionAssignment.questions.length < 1
      ) {
        this.alertText = this.labels.default.mergeoperation;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.isDisabled = true;

        return;
      } else {
        this.mergeService
          .mergeTagRemoval(this.mergeQuestionAssignment)
          .subscribe(
            (res) => {
              if (res.resultCode == 0) {
                this.sharedService.show();
                this.alertText = this.labels.default.saveSuccessfully;
                this.modalService.show(this.successModal);
                $("modal-container").removeClass("fade");
                $(".modal-dialog").addClass("modalSize");
                this.reloadMerge();
                this.sharedService.hide();

                return;
              }
            },
            (err) => {
              this.alertText = this.labels.default.insertOpertionFailed;
              this.modalService.show(this.warningModal);
              $("modal-container").removeClass("fade");
              $(".modal-dialog").addClass("modalSize");
              // this.sharedService.hide();
              return;
            }
          );
      }

    if (this.proxyUnChecked && this.tagUnChecked) {
      this.saveLockSettings();
    }

    if (this.proxyUnChecked && this.questionUnChecked) {
      this.saveLockSettings();
    }
    //
  }

  public closeAlertModal() {
    if (document.getElementsByTagName("modal-container").length > 1) {
      document
        .getElementsByTagName("modal-container")
        [
          document.getElementsByTagName("modal-container").length - 1
        ].parentNode.removeChild(
          document.getElementsByTagName("modal-container")[
            document.getElementsByTagName("modal-container").length - 1
          ]
        );
    } else {
      document
        .getElementsByTagName("modal-container")[0]
        .parentNode.removeChild(
          document.getElementsByTagName("modal-container")[0]
        );
      if (document.getElementsByTagName("bs-modal-backdrop").length > 0) {
        document
          .getElementsByTagName("bs-modal-backdrop")[0]
          .parentNode.removeChild(
            document.getElementsByTagName("bs-modal-backdrop")[0]
          );
      }
      document.querySelector("body").classList.remove("modal-open");
    }
  }

  /** for Proxy */

  removeProxy(event: any) {
    let ntid = event.target.id;
    this.proxies = this.proxies.filter((x) => x.ntid !== ntid);
  }

  //for new Active Directory Search
  user: any;
  proxies: any = [];
  activeDirectoryData: any[];

  onChangeSearch(term: string) {
    // let user = new User();
    // user.firstName = this.user;
    // this.commonService.activeDirectoryByName(user).subscribe(
    //   (res) => {
    //     this.activeDirectoryData = [];
    //     this.activeDirectoryData = res;
    //   },
    //   (err) => console.error(err)
    // );
    
  this.searchService.setSearchTerm(term);
  }

  // selectUser(user: any) {
  //   if (user !== null) {
  //     let x = this.proxies.filter((x) => x.ntid == user.ntid);
  //     if (x.length == 0) this.proxies.push(user);
  //     console.log(this.proxies);
  //   }

  //   this.activeDirectoryData = [];
  //   this.user = undefined;
  // }

  selectUser(user:any){

    if (user !== null) {
      let x = this.proxies.filter(x => x.ntid == user.ntid);
      if (x.length == 0)
      this.proxies.push(user);
      this.proxies.forEach(x => {
        // Check if the userPrincipalName of the current attendee matches the userPrincipalName of the new user
        if (x.userPrincipalName === user.userPrincipalName) {
          // If they match, set the ntid property to the userPrincipalName
          if (user.userPrincipalName && user.userPrincipalName.includes('@')) {
            x.ntid = user.userPrincipalName.split('@')[0].toUpperCase();
          }
          if (user.givenName && user.surname && user.mail && user.displayName)
          {
           x.emailAddress = user.mail;
           x.firstName = user.givenName;
           x.lastName = user.surname;
           x.userName = user.displayName;
         }
        }
      });
    }
  
  
    this.activeDirectoryData = [];
    this.user = undefined;
  }

  saveLockSettings() {
    if (
      this.selectedQuestions.length < 1 &&
      this.proxyUnChecked &&
      this.tagUnChecked
    ) {
      this.alertText = this.labels.default.selectAleastOneQuestion;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      this.isDisabled = true;

      return;
    }

    if (
      this.selectedTags.length < 1 &&
      this.proxyUnChecked &&
      this.questionUnChecked
    ) {
      this.alertText = this.labels.default.selectAleastOneTag;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      this.isDisabled = true;

      return;
    }
    if (this.tagUnChecked) {
      this.questionProxy = new MergeProxy();
      this.questionProxy.questions = this.selectedQuestions;
      this.questionProxy.proxies = this.proxies;

      this.mergeService.insertQuestionProxy(this.questionProxy).subscribe(
        (res) => {
          if (res.resultCode == 0) {
            this.sharedService.show();
            this.alertText = this.labels.default.saveSuccessfully;
            this.modalService.show(this.successModal);
            $("modal-container").removeClass("fade");
            $(".modal-dialog").addClass("modalSize");
            this.reloadMerge();
            this.sharedService.hide();
            return;
          }
        },
        (err) => {
          this.alertText = this.labels.default.insertOpertionFailed;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          // this.sharedService.hide();
          return;
        }
      );
    }

    if (this.questionUnChecked) {
      this.tagProxy = new MergeProxy();
      this.tagProxy.tags = this.selectedTags;
      this.tagProxy.proxies = this.proxies;

      this.mergeService.insertTagProxy(this.tagProxy).subscribe(
        (res) => {
          if (res.resultCode == 0) {
            this.sharedService.show();
            this.alertText = this.labels.default.saveSuccessfully;
            this.modalService.show(this.successModal);
            $("modal-container").removeClass("fade");
            $(".modal-dialog").addClass("modalSize");
            this.reloadMerge();
            this.sharedService.hide();
            return;
          }
        },
        (err) => {
          this.alertText = this.labels.default.insertOpertionFailed;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          // this.sharedService.hide();
          return;
        }
      );
    }
  }

  reloadMerge() {
    this.selectedItemValueStreamTemplate = [];
    this.selectedItemValueStreamCategories = [];
    this.selectedValueStreams = [];
    this.selectedItemAssessorTemplate = [];
    this.selectedAssessors = [];
    this.selectedQuestions = [];
    this.selectedTags = [];
    this.getTagQuestionList();
    this.availableTags = this.allavailableTags;
  }

  // Prevent default behavior of Enter key
  preventEnter(event: KeyboardEvent) {
    event.preventDefault();
    event.stopPropagation();
  }
  // Optimize Question Search filter : Search by Question DisplayID or QuestionText
  public async getQuestionDetail() {
   //Get all Questions List 
   await this.questionService.getQuestions().subscribe(res => {

    this.questionDetail = res;

    this.totalList=this.questionDetail;//mk

    this.sharedService.hide();
    if (this.sharedService.activeDateRange != null && this.sharedService.activeDateRange.questionSearchText != null 
      &&  this.sharedService.activeDateRange.questionSearchText.length > 0 ) {
      this.questionSearchText = this.sharedService.activeDateRange.questionSearchText;
      this.searchTagOrQuestion(this.quest.searchText);
    }
  },
    err => {
      console.log(err);
      this.sharedService.hide();
    });
      


}
  // Optimize Tag Search filter : Search by Tag Text
public async getTagDetail() {

  await this.tagService.getTags().subscribe(
    (res) => {
      this.tagList = res;

      this.totalTagList=this.tagList;//mk
      this.sharedService.hide();
      if ( this.totalTagList.length>0) {
        //this.questionSearchText = this.sharedService.activeDateRange.questionSearchText;
        this.searchTag();
      }
    },
      err => {
        console.log(err);
        this.sharedService.hide();
      });


}

}
