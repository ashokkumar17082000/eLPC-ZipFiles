import { Component, OnInit } from '@angular/core';
import { SharedService } from 'src/app/service/shared.service';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';

@Component({
  selector: 'app-plant',
  templateUrl: './plant.component.html',
  styleUrls: ['./plant.component.css']
})
export class PlantComponent implements OnInit {

  constructor(private sharedService: SharedService, private _router: Router,) {
    //debugger;
  }

  plantId: any;
  ngOnInit() {
    this.sharedService.hide();
  }

  selectPlant(plantId: any) {
    // if (plantId == 1) {
    //   this.sharedService.plant = "BhP";
    // }
    // else if (plantId == 2) {
    //   this.sharedService.plant = "ChP";
    // }
    // else if (plantId == 3) {
    //   this.sharedService.plant = "SzhP";
    // }

    this._router.navigate([environment.home + '/dashboard']);
  }

}
