export class ChoiceDisplayType {
  choiceDisplayTypeID?: number;
  choiceDisplayTypeName?: string;
  isDeleted?: boolean;
}

export class AnswerType {
  answerTypeID?: number;
  answerTypeName?: string;
  isDeleted?: boolean;
  isDefault?: boolean;
}

export class User {
  userID?: number;
  userName?: string;
  role_roleID?: number;
  roleName?: string;
  employeeID?: number;
  emailAddress?: string;
  ntid?: any;
  firstName?: string;
  lastName?: string;
  selectedUser?: any;
  plantID?: number;
  isGroupNameRequired?: boolean = false;
  userPrincipalName?: any; //ntid
  displayName?: string; //username
  mail?: string;
}

export class UserDetails {
  ntid?: string;
  firstName?: string;
  lastName?: string;
  department?: string;
  emailAddress?: string;
  roleName?: string;
  displayName?: string;
  userName?: string;
  plant?: Plant;
  avaliablePlants: Plant[] = [];
  additionalData: string;
  customIConID: number;
}

export class AzureADUserDetails {
  UserID?: number;
  UserName?: string;
  Role_roleID?: number;
  EmployeeID?: number;
  EmailAddress?: string;
  NTID?: any;
  FirstName?: string;
  LastName?: string;
  Department?: string;
  RoleName?: string;
  Location?: string;
  Office?: string;
  Roles?: [];
  IsValueStream?: boolean;
  IsGroupNameRequired?: boolean;
  PlantID?: number;
  CustomIConID?: number;
}

export class Plant {
  plantID?: number;
  plantCode?: string;
  plantName?: string;
  idMStandardRole?: string;
  idMDesignerRole?: string;
  defaultLanguage?: string;
  timeZone?: string;
  powerBISecurityGroup?: string;
  isTranslationFromAPI?: boolean;
  isActive?: boolean;
  generalMessage?: string;
  isUnderMaintenance?: boolean;
  underMaintenanceMessage?: string;
  notAuthorizedMessage?: string;
  plantAvaliablityMessage?: string;
  plaCurrentRoleIDntID?: number;
  currentRole?: string;
  isDefault?: boolean;
  marqueeAlert?:string;
}

export class Result {
  resultCode: number;
  resultMessage: string;
  count: number;
  insertedID: number;
  eventID:string;
  eventStartTime :string;
  attemptNumber:number;
  childEventID:string;
}

export class UserAdditionalData {
  additionalData: string;
  userNTID: string;
}
export class AdditionalData {
  QAwardResponded: boolean;
}

export class AppSettings {
  QAwardPopup: QAwardPopup;
}
export class QAwardPopup {
  Show: boolean;
  VotingUrl: string;
}
