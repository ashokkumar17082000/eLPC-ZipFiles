// import { Injectable } from '@angular/core';
// import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse, HttpResponse } from '@angular/common/http';
// import { Observable, throwError, timer, Subscription, interval } from 'rxjs';
// import { catchError, tap, finalize } from 'rxjs/operators';
// import { Router } from '@angular/router';
// import { SharedService } from './shared.service';
// import { Location } from '@angular/common';
// import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
// import { ErrorEventService } from './error-event.service';
// import { NetworkTrackingService } from '../network-tracking.service';

// interface ActiveRequest {
//   id: string;
//   url: string;
//   startTime: number;
//   immediateTimer?: Subscription;
//   checkTimer?: Subscription;
//   alertShown: boolean;
//   lastAlertTime?: number;
//   alertCount: number;
//   isInitialRequest?: boolean; // Track if this is an initial app load request
// }

// @Injectable()
// export class HttpErrorInterceptor implements HttpInterceptor {
//   modalRef?: BsModalRef;
//   private activeRequests = new Map<string, ActiveRequest>();
//   private readonly IMMEDIATE_CHECK_THRESHOLD = 3000; // Check after 3 seconds for immediate feedback
//   private readonly SLOW_REQUEST_THRESHOLD = 8000; // 8 seconds (reduced from 10)
//   private readonly CHECK_INTERVAL = 2000;
//   private readonly ALERT_REPEAT_INTERVAL = 12000; // Reduced from 15 seconds
//   private readonly MAX_ALERTS = 6; // Increased for longer running requests
//   private networkStatusSubscription?: Subscription;
//   private currentNetworkAlertShown = false;
//   private isAppInitializing = true; // Track app initialization state

//   constructor(
//     private router: Router,
//     private sharedService: SharedService,
//     private location: Location,
//     private modalService: BsModalService,
//     private errorEventService: ErrorEventService,
//     private networkTrackingService: NetworkTrackingService
//   ) {
//     this.subscribeToNetworkStatus();

//     // After 30 seconds, consider app as fully initialized
//     setTimeout(() => {
//       this.isAppInitializing = false;
//     }, 30000);
//   }

//   intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
//     const requestId = this.generateRequestId(req);
//     const startTime = Date.now();
//     const isInitialRequest = this.isAppInitializing;

//     // Track this active request immediately
//     this.trackActiveRequest(requestId, req.url, startTime, isInitialRequest);

//     return next.handle(req).pipe(
//       tap(event => {
//         if (event instanceof HttpResponse) {
//           this.handleSuccessfulResponse(req, requestId, startTime);
//         }
//       }),
//       catchError((error: HttpErrorResponse) => {
//         this.handleFailedResponse(req, requestId, startTime, error);
//         this.sharedService.hide();

//         console.error("🚨 API Error Occurred:", {
//           url: req.url,
//           method: req.method,
//           requestBody: req.body,
//           status: error.status,
//           errorMessage: error.message
//         });

//         if (error.status === 499) {
//           this.handle499Error(req.url);
//         } else {
//           this.handleHttpErrors(error);
//         }

//         return throwError(() => error);
//       }),
//       finalize(() => {
//         this.cleanupActiveRequest(requestId);
//       })
//     );
//   }

//   /**
//    * 🔹 Track active request with immediate and regular monitoring
//    */
//   private trackActiveRequest(requestId: string, url: string, startTime: number, isInitialRequest: boolean): void {
//     const activeRequest: ActiveRequest = {
//       id: requestId,
//       url,
//       startTime,
//       alertShown: false,
//       alertCount: 0,
//       isInitialRequest
//     };

//     // For initial requests or when network is already slow, start checking immediately
//     const initialCheckDelay = isInitialRequest || this.isCurrentNetworkSlow() ?
//       this.IMMEDIATE_CHECK_THRESHOLD : this.SLOW_REQUEST_THRESHOLD;

//     console.log(`🔍 Tracking request: ${url} (Initial: ${isInitialRequest}, Immediate check in: ${initialCheckDelay}ms)`);

//     // Start immediate monitoring for early detection
//     activeRequest.immediateTimer = timer(initialCheckDelay).subscribe(() => {
//       this.performImmediateCheck(activeRequest);
//     });

//     // Start regular monitoring after the normal threshold
//     activeRequest.checkTimer = timer(this.SLOW_REQUEST_THRESHOLD, this.CHECK_INTERVAL).subscribe(() => {
//       this.checkSlowRequestInRealTime(activeRequest);
//     });

//     this.activeRequests.set(requestId, activeRequest);
//   }

//   /**
//    * 🔹 Perform immediate check for potentially slow requests
//    */
//   private performImmediateCheck(activeRequest: ActiveRequest): void {
//     const currentTime = Date.now();
//     const elapsedTime = currentTime - activeRequest.startTime;

//     // Only check if request is still active
//     if (this.activeRequests.has(activeRequest.id)) {
//       console.log(`⏰ Immediate check for ${activeRequest.url} after ${elapsedTime}ms`);

//       // Get current network status
//       const networkStatus = this.networkTrackingService.getCurrentNetworkStatus();

//       // For initial requests, be more aggressive about showing alerts
//       if (activeRequest.isInitialRequest) {
//         if (elapsedTime > this.IMMEDIATE_CHECK_THRESHOLD) {
//           this.showInitialLoadingAlert(elapsedTime, networkStatus, activeRequest);
//         }
//       } else if (this.isNetworkSlow(networkStatus)) {
//         this.showSlowNetworkAlert(elapsedTime, networkStatus.quality, activeRequest);
//       }
//     }
//   }

//   /**
//    * 🔹 Show specific alert for initial app loading
//    */
//   private showInitialLoadingAlert(elapsedTime: number, networkStatus: any, activeRequest: ActiveRequest): void {
//     const seconds = Math.round(elapsedTime / 1000);
//     let message = '';

//     if (this.isNetworkSlow(networkStatus)) {
//       message = `🚀 Loading your application... (${seconds}s)
//                  Your network seems ${networkStatus.quality || 'slow'}, so it may take a bit longer.
//                  Please wait while we load everything for you.`;
//     } else {
//       message = `🚀 Loading your application... (${seconds}s)
//                  We're getting everything ready for you.
//                  This might take a moment on first load.`;
//     }

//     activeRequest.alertShown = true;
//     activeRequest.lastAlertTime = Date.now();
//     activeRequest.alertCount = 1;
//     this.currentNetworkAlertShown = true;

//     console.log(`🚀 Initial loading alert shown after ${seconds}s`);
//     this.createNonBlockingAlert(message, 'info');
//   }

//   /**
//    * 🔹 Enhanced regular monitoring with better timing
//    */
//   private checkSlowRequestInRealTime(activeRequest: ActiveRequest): void {
//     const currentTime = Date.now();
//     const elapsedTime = currentTime - activeRequest.startTime;

//     if (this.activeRequests.has(activeRequest.id)) {
//       const networkStatus = this.networkTrackingService.getCurrentNetworkStatus();

//       // Always show alerts for very long requests, regardless of network status
//       if (elapsedTime > 20000) { // 20 seconds
//         this.showSlowNetworkAlert(elapsedTime, 'very slow', activeRequest);
//       } else if (this.isNetworkSlow(networkStatus)) {
//         this.showSlowNetworkAlert(elapsedTime, networkStatus.quality, activeRequest);
//       }
//     }
//   }

//   /**
//    * 🔹 Check if current network is slow
//    */
//   private isCurrentNetworkSlow(): boolean {
//     const networkStatus = this.networkTrackingService.getCurrentNetworkStatus();
//     return this.isNetworkSlow(networkStatus);
//   }

//   /**
//    * 🔹 Enhanced network slow detection
//    */
//   private isNetworkSlow(networkStatus: any): boolean {
//     return !networkStatus.isOnline ||
//            networkStatus.quality === 'poor' ||
//            networkStatus.quality === 'fair' ||
//            networkStatus.speed < 2 || // Less than 2 Mbps
//            networkStatus.isApiSlow;
//   }

//   /**
//    * 🔹 Enhanced alert system with better message progression
//    */
//   private showSlowNetworkAlert(elapsedTime: number, quality: string, activeRequest: ActiveRequest): void {
//     const currentTime = Date.now();
//     const seconds = Math.round(elapsedTime / 1000);

//     // More aggressive timing for initial requests
//     const timingThreshold = activeRequest.isInitialRequest ?
//       this.ALERT_REPEAT_INTERVAL * 0.7 : this.ALERT_REPEAT_INTERVAL;

//     const shouldShowAlert =
//       !activeRequest.alertShown ||
//       (activeRequest.lastAlertTime &&
//        currentTime - activeRequest.lastAlertTime >= timingThreshold &&
//        activeRequest.alertCount < this.MAX_ALERTS);

//     if (shouldShowAlert) {
//       activeRequest.alertShown = true;
//       activeRequest.lastAlertTime = currentTime;
//       activeRequest.alertCount++;
//       this.currentNetworkAlertShown = true;

//       let message = this.getProgressiveMessage(seconds, quality, activeRequest);
//       let type: 'info' | 'warning' | 'error' = this.getAlertType(activeRequest.alertCount, seconds);

//       console.log(`🔔 Network alert #${activeRequest.alertCount} shown for ${activeRequest.url} after ${seconds}s`);
//       this.createNonBlockingAlert(message, type);
//     }
//   }

//   /**
//    * 🔹 Get progressive message based on alert count and timing
//    */
//   private getProgressiveMessage(seconds: number, quality: string, activeRequest: ActiveRequest): string {
//     const isInitial = activeRequest.isInitialRequest;
//     const count = activeRequest.alertCount;

//     if (isInitial) {
//       switch (count) {
//         case 1:
//           return `🚀 Still loading your app (${seconds}s)... Your ${quality} network is causing some delay. Please wait.`;
//         case 2:
//           return `⏳ App loading continues (${seconds}s)... Network speed is ${quality}. We're working on it.`;
//         default:
//           return `🔄 App loading taking longer than expected (${seconds}s)... Please check your connection.`;
//       }
//     } else {
//       switch (count) {
//         case 1:
//           return `⚠️ Request taking ${seconds}s... Your ${quality} network may be causing delays. Please wait.`;
//         case 2:
//           return `⏳ Still processing (${seconds}s)... Network appears ${quality}. Please be patient.`;
//         case 3:
//           return `🔄 Request ongoing (${seconds}s)... Network issues detected. Consider checking connection.`;
//         case 4:
//           return `⚠️ Extended delay (${seconds}s)... Significant network issues. Please check connectivity.`;
//         default:
//           return `🚨 Very long request (${seconds}s)... Please check your network and consider refreshing.`;
//       }
//     }
//   }

//   /**
//    * 🔹 Get alert type based on timing and count
//    */
//   private getAlertType(count: number, seconds: number): 'info' | 'warning' | 'error' {
//     if (seconds < 10) return 'info';
//     if (seconds < 30 && count < 3) return 'warning';
//     return 'error';
//   }

//   /**
//    * 🔹 Subscribe to network status changes
//    */
//   private subscribeToNetworkStatus(): void {
//     this.networkStatusSubscription = this.networkTrackingService.networkStatus$.subscribe(
//       networkStatus => {
//         if (this.currentNetworkAlertShown && !this.isNetworkSlow(networkStatus)) {
//           this.hideNetworkAlert();
//           this.currentNetworkAlertShown = false;
//           this.resetAllActiveRequestAlerts();
//         }
//       }
//     );
//   }

//   /**
//    * 🔹 Reset alerts for all active requests
//    */
//   private resetAllActiveRequestAlerts(): void {
//     this.activeRequests.forEach(request => {
//       request.alertShown = false;
//       request.alertCount = 0;
//       request.lastAlertTime = undefined;
//     });
//   }

//   /**
//    * 🔹 Enhanced toast notification with different styles
//    */
//   private createNonBlockingAlert(message: string, type: 'info' | 'warning' | 'error' | 'success'): void {
//     const toast = document.createElement('div');

//     const colors = {
//       info: '#2196F3',
//       warning: '#ff9800',
//       error: '#f44336',
//       success: '#4caf50'
//     };

//     toast.style.cssText = `
//       position: fixed;
//       top: 20px;
//       right: 20px;
//       z-index: 10000;
//       padding: 15px 20px;
//       border-radius: 8px;
//       color: white;
//       font-weight: bold;
//       max-width: 400px;
//       box-shadow: 0 4px 20px rgba(0,0,0,0.3);
//       background-color: ${colors[type]};
//       animation: slideIn 0.3s ease-out;
//       font-size: 14px;
//       line-height: 1.4;
//     `;

//     toast.innerHTML = `
//       <div style="display: flex; align-items: flex-start; justify-content: space-between;">
//         <span style="flex: 1; margin-right: 10px;">${message}</span>
//         <button onclick="this.parentElement.parentElement.remove()"
//                 style="background: none; border: none; color: white; font-size: 18px; cursor: pointer; padding: 0; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center;">×</button>
//       </div>
//     `;

//     if (!document.querySelector('#toast-animation-styles')) {
//       const style = document.createElement('style');
//       style.id = 'toast-animation-styles';
//       style.textContent = `
//         @keyframes slideIn {
//           from { transform: translateX(100%); opacity: 0; }
//           to { transform: translateX(0); opacity: 1; }
//         }
//       `;
//       document.head.appendChild(style);
//     }

//     document.body.appendChild(toast);

//     const duration = type === 'info' ? 5000 :
//                     type === 'warning' ? 8000 :
//                     type === 'error' ? 12000 : 3000;

//     setTimeout(() => {
//       if (toast.parentElement) {
//         toast.style.animation = 'slideOut 0.3s ease-in';
//         setTimeout(() => toast.remove(), 300);
//       }
//     }, duration);
//   }

//   private hideNetworkAlert(): void {
//     this.createNonBlockingAlert('✅ Network connection improved! Requests should be faster now.', 'success');
//   }

//   private handleSuccessfulResponse(req: HttpRequest<any>, requestId: string, startTime: number): void {
//     const endTime = Date.now();
//     const responseTime = endTime - startTime;
//     this.networkTrackingService.trackApiCall(req.url, responseTime);
//   }

//   private handleFailedResponse(req: HttpRequest<any>, requestId: string, startTime: number, error: HttpErrorResponse): void {
//     const endTime = Date.now();
//     const responseTime = endTime - startTime;
//     this.networkTrackingService.trackApiCall(req.url, responseTime, 'error');
//   }

//   private cleanupActiveRequest(requestId: string): void {
//     const activeRequest = this.activeRequests.get(requestId);
//     if (activeRequest) {
//       if (activeRequest.immediateTimer) {
//         activeRequest.immediateTimer.unsubscribe();
//       }
//       if (activeRequest.checkTimer) {
//         activeRequest.checkTimer.unsubscribe();
//       }
//       this.activeRequests.delete(requestId);
//     }
//   }

//   private generateRequestId(req: HttpRequest<any>): string {
//     return `${req.method}_${req.url}_${Date.now()}_${Math.random()}`;
//   }

//   private handle499Error(requestUrl: string): void {
//     if (requestUrl.includes('api/ProcessConfirmation/InsertProcessConfirmation')) {
//       this.errorEventService.emitError(1);
//     } else if (requestUrl.includes('api/ProcessConfirmation/GetProcessConfirmation')) {
//       this.errorEventService.emitError(2);
//     }
//   }

//   private handleHttpErrors(error: HttpErrorResponse): void {
//     switch (error.status) {
//       case 400:
//         this.errorEventService.emitError(400);
//         break;
//       case 401:
//         this.errorEventService.emitError(401);
//         break;
//       case 403:
//         this.errorEventService.emitError(403);
//         break;
//       case 404:
//         this.errorEventService.emitError(404);
//         break;
//       case 500:
//         this.errorEventService.emitError(500);
//         break;
//       default:
//         this.errorEventService.emitError(error.status);
//     }
//   }

//   ngOnDestroy(): void {
//     if (this.networkStatusSubscription) {
//       this.networkStatusSubscription.unsubscribe();
//     }

//     this.activeRequests.forEach(request => {
//       if (request.immediateTimer) {
//         request.immediateTimer.unsubscribe();
//       }
//       if (request.checkTimer) {
//         request.checkTimer.unsubscribe();
//       }
//     });
//     this.activeRequests.clear();
//   }
// }

//------------------new code -----------------------------

import { Injectable, Injector } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { Observable, throwError, timer, Subscription, interval } from 'rxjs';
import { catchError, tap, finalize } from 'rxjs/operators';
import { Router } from '@angular/router';
import { SharedService } from './shared.service';
import { Location } from '@angular/common';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ErrorEventService } from './error-event.service';
import { NetworkTrackingService, NetworkStatus } from '../network-tracking.service';

interface ActiveRequest {
  id: string;
  url: string;
  startTime: number;
  checkTimer?: Subscription;
  alertShown: boolean;
  lastAlertTime?: number;
  alertCount: number;
  isInitialRequest?: boolean;
  networkQualityAtStart: string;
}

@Injectable()
export class HttpErrorInterceptor implements HttpInterceptor {
  modalRef?: BsModalRef;
  private activeRequests = new Map<string, ActiveRequest>();
  private readonly API_SLOW_THRESHOLD = 5000; // 5 seconds as requested
  private readonly CHECK_INTERVAL = 2000; // Check every 2 seconds
  private readonly ALERT_REPEAT_INTERVAL = 10000; // Show follow-up messages every 10 seconds
  private readonly MAX_CONSECUTIVE_ALERTS = 6; // Maximum 6 follow-up messages
  private networkStatusSubscription?: Subscription;
  private currentNetworkAlertShown = false;
  private isAppInitializing = true;
  private networkStableMessageShown = false;

  // Lazy-loaded services to avoid circular dependency
  private router?: Router;
  private sharedService?: SharedService;
  private location?: Location;
  private modalService?: BsModalService;
  private errorEventService?: ErrorEventService;
  private networkTrackingService?: NetworkTrackingService;

  constructor(private injector: Injector) {
    // Initialize after a short delay to avoid circular dependency
    setTimeout(() => {
      this.initializeServices();
    }, 0);

    // After 30 seconds, consider app as fully initialized
    setTimeout(() => {
      this.isAppInitializing = false;
    }, 30000);
  }

  private initializeServices(): void {
    try {
      this.router = this.injector.get(Router);
      this.sharedService = this.injector.get(SharedService);
      this.location = this.injector.get(Location);
      this.modalService = this.injector.get(BsModalService);
      this.errorEventService = this.injector.get(ErrorEventService);
      this.networkTrackingService = this.injector.get(NetworkTrackingService);

      // Initialize network monitoring after services are loaded
      this.subscribeToNetworkStatus();
      this.startContinuousNetworkMonitoring();
    } catch (error) {
      console.error('Error initializing services in HttpErrorInterceptor:', error);
    }
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const requestId = this.generateRequestId(req);
    const startTime = Date.now();

    // Get current network status safely
    const currentNetworkStatus = this.networkTrackingService?.getCurrentNetworkStatus() || {
      isOnline: navigator.onLine,
      speed: 0,
      quality: 'good',
      apiResponseTime: 0,
      isApiSlow: false,
      consecutiveSlowRequests: 0,
      networkStability: 'stable'
    } as NetworkStatus;

    // Track this active request
    this.trackActiveRequest(requestId, req.url, startTime, currentNetworkStatus);

    return next.handle(req).pipe(
      tap(event => {
        if (event instanceof HttpResponse) {
          this.handleSuccessfulResponse(req, requestId, startTime);
        }
      }),
      catchError((error: HttpErrorResponse) => {
        this.handleFailedResponse(req, requestId, startTime, error);

        // Safely call sharedService.hide()
        if (this.sharedService) {
          this.sharedService.hide();
        }

        console.error("🚨 API Error Occurred:", {
          url: req.url,
          method: req.method,
          requestBody: req.body,
          status: error.status,
          errorMessage: error.message
        });

        if (error.status === 499) {
          this.handle499Error(req.url);
        } else {
          this.handleHttpErrors(error);
        }

        return throwError(() => error);
      }),
      finalize(() => {
        this.cleanupActiveRequest(requestId);
      })
    );
  }

  /**
   * Start continuous network monitoring across the application
   */
  private startContinuousNetworkMonitoring(): void {
    // Monitor network status every 5 seconds
    interval(5000).subscribe(() => {
      this.checkNetworkStatusAndShowToast();
    });
  }

  /**
   * Check network status and show appropriate toast messages
   */
  private checkNetworkStatusAndShowToast(): void {
    if (!this.networkTrackingService) return;

    const networkStatus = this.networkTrackingService.getCurrentNetworkStatus();

    // Check if network went down
    if (!networkStatus.isOnline || this.isNetworkSlow(networkStatus)) {
      if (!this.currentNetworkAlertShown) {
        this.showNetworkDownToast(networkStatus);
        this.currentNetworkAlertShown = true;
        this.networkStableMessageShown = false;
      }
    }
    // Check if network became stable
    else if (this.currentNetworkAlertShown && this.isNetworkGood(networkStatus)) {
      if (!this.networkStableMessageShown) {
        this.showNetworkStableToast(networkStatus);
        this.currentNetworkAlertShown = false;
        this.networkStableMessageShown = true;

        // Reset stable message flag after 30 seconds
        setTimeout(() => {
          this.networkStableMessageShown = false;
        }, 30000);
      }
    }
  }

  /**
   * Track active request with monitoring
   */
  private trackActiveRequest(requestId: string, url: string, startTime: number, networkStatus: NetworkStatus): void {
    const activeRequest: ActiveRequest = {
      id: requestId,
      url,
      startTime,
      alertShown: false,
      alertCount: 0,
      isInitialRequest: this.isAppInitializing,
      networkQualityAtStart: networkStatus.quality
    };

    // Start monitoring after 5 seconds
    activeRequest.checkTimer = timer(this.API_SLOW_THRESHOLD, this.CHECK_INTERVAL).subscribe(() => {
      this.checkSlowRequestAndShowToast(activeRequest);
    });

    this.activeRequests.set(requestId, activeRequest);
  }

  /**
   * Check slow request and show appropriate toast based on network condition
   */
  private checkSlowRequestAndShowToast(activeRequest: ActiveRequest): void {
    const currentTime = Date.now();
    const elapsedTime = currentTime - activeRequest.startTime;

    if (!this.activeRequests.has(activeRequest.id)) {
      return; // Request completed
    }

    const currentNetworkStatus = this.networkTrackingService?.getCurrentNetworkStatus();
    if (!currentNetworkStatus) return;

    const shouldShowAlert = this.shouldShowRequestAlert(activeRequest, currentTime);

    if (shouldShowAlert && elapsedTime > this.API_SLOW_THRESHOLD) {
      activeRequest.alertShown = true;
      activeRequest.lastAlertTime = currentTime;
      activeRequest.alertCount++;

      // Check network speed and show appropriate message
      if (this.isNetworkSlow(currentNetworkStatus)) {
        this.showNetworkSlowApiToast(elapsedTime, currentNetworkStatus, activeRequest);
      } else {
        this.showProcessingApiToast(elapsedTime, activeRequest);
      }
    }
  }

  /**
   * Determine if we should show request alert
   */
  private shouldShowRequestAlert(activeRequest: ActiveRequest, currentTime: number): boolean {
    // First alert
    if (!activeRequest.alertShown) {
      return true;
    }

    // Subsequent alerts - check timing and count limits
    const timeSinceLastAlert = activeRequest.lastAlertTime ?
      currentTime - activeRequest.lastAlertTime : 0;

    return timeSinceLastAlert >= this.ALERT_REPEAT_INTERVAL &&
           activeRequest.alertCount < this.MAX_CONSECUTIVE_ALERTS;
  }

  /**
   * Show network down toast
   */
  private showNetworkDownToast(networkStatus: NetworkStatus): void {
    let message = '';

    if (!networkStatus.isOnline) {
      message = '🚨 You are currently offline. Please check your internet connection.';
    }
    // else if (networkStatus.quality === 'poor') {
    //   message = `⚠️ Network connection is very slow (${networkStatus.speed.toFixed(1)} Mbps). This may affect performance.`;
    // }
     else if (networkStatus.quality === 'fair') {
      message = `⚠️ Network connection is slow (${networkStatus.speed.toFixed(1)} Mbps). Loading may take longer.`;
    } else if (networkStatus.isApiSlow) {
      message = '⚠️ Network response times are slow. Please be patient.';
    }

    if (message!=undefined && message != '') {
    this.createToastNotification(message, 'error', 8000);
    }

  }

  /**
   * Show network stable toast
   */
  private showNetworkStableToast(networkStatus: NetworkStatus): void {
    const message = `✅ Network connection is stable (${networkStatus.speed.toFixed(1)} Mbps). Performance should improve.`;
    this.createToastNotification(message, 'success', 4000);
  }

  /**
   * Show API slow due to network toast
   */
  private showNetworkSlowApiToast(elapsedTime: number, networkStatus: NetworkStatus, activeRequest: ActiveRequest): void {
    const seconds = Math.round(elapsedTime / 1000);
    const count = activeRequest.alertCount;

    let message = '';

    if (count === 1) {
      message = `⏳ Request taking ${seconds}s due to ${networkStatus.quality} network (${networkStatus.speed.toFixed(1)} Mbps). Please wait...`;
    } else if (count <= 3) {
      message = `⚠️ Still processing (${seconds}s) - Network is ${networkStatus.quality}. Please be patient.`;
    } else {
      message = `🔄 Extended delay (${seconds}s) - Poor network detected. Consider checking your connection.`;
    }

    const type = count <= 2 ? 'warning' : 'error';
    this.createToastNotification(message, type, 6000);
  }

  /**
   * Show processing API toast (when network is good)
   */
  private showProcessingApiToast(elapsedTime: number, activeRequest: ActiveRequest): void {
    const seconds = Math.round(elapsedTime / 1000);
    const count = activeRequest.alertCount;

    let message = '';

    if (count === 1) {
      message = `🔄 Processing your request (${seconds}s)... Please wait while we handle your request.`;
    } else if (count <= 3) {
      message = `⏳ Still processing (${seconds}s)... This is taking longer than usual, please be patient.`;
    } else {
      message = `⚠️ Processing continues (${seconds}s)... This request is taking longer than expected.`;
    }

    const type = count <= 2 ? 'info' : 'warning';
    this.createToastNotification(message, type, 5000);
  }

  /**
   * Subscribe to network status changes
   */
  private subscribeToNetworkStatus(): void {
    if (!this.networkTrackingService) return;

    this.networkStatusSubscription = this.networkTrackingService.networkStatus$.subscribe(
      networkStatus => {
        // Reset active request alerts when network improves
        if (this.currentNetworkAlertShown && this.isNetworkGood(networkStatus)) {
          this.resetAllActiveRequestAlerts();
        }
      }
    );
  }

  /**
   * Check if network is slow
   */
  private isNetworkSlow(networkStatus: NetworkStatus): boolean {
    return !networkStatus.isOnline ||
           networkStatus.quality === 'poor' ||
           networkStatus.quality === 'fair' ||
           networkStatus.speed < 2 ||
           networkStatus.isApiSlow ||
           networkStatus.networkStability === 'very_unstable';
  }

  /**
   * Check if network is good
   */
  private isNetworkGood(networkStatus: NetworkStatus): boolean {
    return networkStatus.isOnline &&
           networkStatus.quality === 'good' &&
           networkStatus.speed >= 2 &&
           !networkStatus.isApiSlow &&
           networkStatus.networkStability === 'stable';
  }

  /**
   * Reset alerts for all active requests
   */
  private resetAllActiveRequestAlerts(): void {
    this.activeRequests.forEach(request => {
      request.alertShown = false;
      request.alertCount = 0;
      request.lastAlertTime = undefined;
    });
  }

  /**
   * Create toast notification
   */
  private createToastNotification(message: string, type: 'info' | 'warning' | 'error' | 'success', duration: number = 5000): void {
    const toast = document.createElement('div');

    const colors = {
      info: '#2196F3',
      warning: '#ff9800',
      error: '#f44336',
      success: '#4caf50'
    };

    toast.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 10000;
      padding: 15px 20px;
      border-radius: 8px;
      color: white;
      font-weight: bold;
      max-width: 450px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.3);
      background-color: ${colors[type]};
      animation: slideIn 0.3s ease-out;
      font-size: 14px;
      line-height: 1.4;
    `;

    toast.innerHTML = `
      <div style="display: flex; align-items: flex-start; justify-content: space-between;">
        <span style="flex: 1; margin-right: 10px;">${message}</span>
        <button onclick="this.parentElement.parentElement.remove()"
                style="background: none; border: none; color: white; font-size: 18px; cursor: pointer; padding: 0; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center;">×</button>
      </div>
    `;

    // Add animation CSS if not already present
    if (!document.querySelector('#toast-animation-styles')) {
      const style = document.createElement('style');
      style.id = 'toast-animation-styles';
      style.textContent = `
        @keyframes slideIn {
          from { transform: translateX(100%); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
        @keyframes slideOut {
          from { transform: translateX(0); opacity: 1; }
          to { transform: translateX(100%); opacity: 0; }
        }
      `;
      document.head.appendChild(style);
    }

    document.body.appendChild(toast);

    // Auto-remove after duration
    setTimeout(() => {
      if (toast.parentElement) {
        toast.style.animation = 'slideOut 0.3s ease-in';
        setTimeout(() => toast.remove(), 300);
      }
    }, duration);
  }

  private handleSuccessfulResponse(req: HttpRequest<any>, requestId: string, startTime: number): void {
    const endTime = Date.now();
    const responseTime = endTime - startTime;
    if (this.networkTrackingService) {
      this.networkTrackingService.trackApiCall(req.url, responseTime);
    }
  }

  private handleFailedResponse(req: HttpRequest<any>, requestId: string, startTime: number, error: HttpErrorResponse): void {
    const endTime = Date.now();
    const responseTime = endTime - startTime;
    if (this.networkTrackingService) {
      this.networkTrackingService.trackApiCall(req.url, responseTime, 'error');
    }
  }

  private cleanupActiveRequest(requestId: string): void {
    const activeRequest = this.activeRequests.get(requestId);
    if (activeRequest) {
      if (activeRequest.checkTimer) {
        activeRequest.checkTimer.unsubscribe();
      }
      this.activeRequests.delete(requestId);
    }
  }

  private generateRequestId(req: HttpRequest<any>): string {
    return `${req.method}_${req.url}_${Date.now()}_${Math.random()}`;
  }

  private handle499Error(requestUrl: string): void {
    if (this.errorEventService) {
      if (requestUrl.includes('api/ProcessConfirmation/InsertProcessConfirmation')) {
        this.errorEventService.emitError(1);
      } else if (requestUrl.includes('api/ProcessConfirmation/GetProcessConfirmation')) {
        this.errorEventService.emitError(2);
      }
    }
  }

  private handleHttpErrors(error: HttpErrorResponse): void {
    if (this.errorEventService) {
      switch (error.status) {
        case 400:
          this.errorEventService.emitError(400);
          break;
        case 401:
          this.errorEventService.emitError(401);
          break;
        case 403:
          this.errorEventService.emitError(403);
          break;
        case 404:
          this.errorEventService.emitError(404);
          break;
        case 500:
          this.errorEventService.emitError(500);
          break;
        default:
          this.errorEventService.emitError(error.status);
      }
    }
  }

  ngOnDestroy(): void {
    if (this.networkStatusSubscription) {
      this.networkStatusSubscription.unsubscribe();
    }

    this.activeRequests.forEach(request => {
      if (request.checkTimer) {
        request.checkTimer.unsubscribe();
      }
    });
    this.activeRequests.clear();
  }
}
