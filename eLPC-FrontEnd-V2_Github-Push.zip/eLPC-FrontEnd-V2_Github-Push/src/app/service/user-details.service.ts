import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MsalService } from '@azure/msal-angular';
import { AuthenticationResult, InteractionRequiredAuthError } from '@azure/msal-browser';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { protectedResources } from '../Authentication/auth-config';

@Injectable({
  providedIn: 'root'
})
export class UserDetailsService {

  constructor(private http: HttpClient, private authService: MsalService) { }

  getUserDetails(): Observable<any> {
    const graphEndpoint = protectedResources.graphApi.endpoint;

    return this.authService.acquireTokenSilent({ scopes: protectedResources.graphApi.scopes }).pipe(
      map((tokenResponse: AuthenticationResult) => {
        const headers = new HttpHeaders().set('Authorization', `Bearer ${tokenResponse.accessToken}`);
        return this.http.get(graphEndpoint, { headers }).pipe(
          catchError(err => {
            if (err instanceof InteractionRequiredAuthError) {
              this.authService.acquireTokenRedirect({ scopes: protectedResources.graphApi.scopes });
            }
            return throwError(err);
          })
        );
      }),
      catchError(error => {
        console.error('Token acquisition failed', error);
        if (error instanceof InteractionRequiredAuthError) {
          this.authService.acquireTokenRedirect({ scopes: protectedResources.graphApi.scopes });
        }
        return throwError(error);
      })
    );
  }

  getUserDetails_3(username: string): Observable<any> {
    const url = `https://graph.microsoft.com/v1.0/users?$filter=userPrincipalName eq '${username}'`;
    return this.http.get(url);
  }
  getUserDetails_2(username: string): Observable<any> {
    const url = `https://graph.microsoft.com/v1.0/users?$filter=mail eq '${username}'`;
    return this.http.get(url);
  }

  getUserDetails_1(username: string): Observable<any> {
    //const url = `https://graph.microsoft.com/v1.0/users?$filter=startswith(userPrincipalName, '${username}')`;
    const url = `https://graph.microsoft.com/v1.0/users?$filter=startswith(userPrincipalName, '${username}') or startswith(displayName, '${username}')`;
    return this.http.get(url);
  }
}
