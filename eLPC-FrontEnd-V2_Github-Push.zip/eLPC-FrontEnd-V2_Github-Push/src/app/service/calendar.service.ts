import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';  
import 'rxjs/add/operator/map';
import { HttpHeaders } from '@angular/common/http'; 
import { SharedService } from './shared.service';
//import { Audit, AuditQuestion, AuditDetail, AuditAssessor, TagDetails, AuditStatus } from '../main/body/calendar/calendar';
import { Audit,AuditQuestion, AuditDetail, AuditAssessor, TagDetails, AuditStatus } from '../calendar/calendar/calendar';
import { ValueStream } from 'src/app/Valuestream/valuestreams/valuestreamtemplate';
import { User, Result } from '../main/body/shared/common';
import { environment } from 'src/environments/environment';
import { ProcessConfirmation } from '../pc/process-confirmation/process-confirmation';

@Injectable({
  providedIn: 'root',
})

export class CalendarService {
  private headers: HttpHeaders;
  apiURL: string;
  audit: Audit = new Audit();

  
    constructor(private http: HttpClient, private sharedService:SharedService ) {
      this.headers = new HttpHeaders();
      this.headers.append("Content-Type", "application/json");
      this.apiURL = this.sharedService.apiURL;
    }
  
      public getAudits() {
  
        return this.http.get<Audit[]>(this.apiURL + "Audit/GetAudits", { headers: this.headers , withCredentials: true });
      }

     //to fetch the audits based on Designer and Standard user ID
      public getAuditsByNTID(ntid: string,currmonth,curryear) {
        return this.http.get<Audit[]>(this.apiURL + "Audit/GetAuditsByNTID" + "/" + ntid  + "/" + currmonth + "/" + curryear ,{ withCredentials: true });
      }

      public  GetAuditStatusByType(module: string,currentMonth:string, currentYear : string, IsDesigner:number ,ntID : string) {
        return  this.http.get<AuditStatus[]>(this.apiURL + "Audit/GetAuditStatusByType" + "/" + module + "/" + currentMonth + "/" + currentYear + "/"+ IsDesigner + "/" + ntID, { withCredentials: true });
      }

  public insertAudit(audit: Audit) {
    return this.http.post<Audit>(this.apiURL + "Audit/InsertAudit", audit, { withCredentials: true });
  }
      public DeleteAudit(audit: Audit) {
    
        return this.http.post<Audit>(this.apiURL + "Audit/DeleteAudit", audit, {withCredentials: true});
    }

        public auditByAuditID(auditID: number) {
          return this.http.get<Audit>(this.apiURL + "Audit/AuditByAuditID" +"/"+ auditID, {withCredentials: true});
      }

      public auditQuestionsByAuditID(auditID: number) {
        return this.http.get<AuditQuestion[]>(this.apiURL + "Audit/AuditQuestionsByAuditID" + "/" + auditID, {withCredentials: true});
      }

      
      public auditQuestionsByAuditIDSelectedValuestream(auditID: number,valueStreamID: number) {
        return this.http.get<AuditQuestion[]>(this.apiURL + "Audit/AuditQuestionsByAuditIDSelectedValuestream" + "/" + auditID + "/" +valueStreamID , {withCredentials: true});
      }

      public pendingAuditsByAuditID(auditID: number) {
        return this.http.get<AuditQuestion[]>(this.apiURL + "Audit/PendingAuditsByAuditID" + "/" + auditID, {withCredentials: true});
      }
      
      public resetAuditByAuditID(auditID: number) {
        return this.http.post<AuditQuestion[]>(this.apiURL + "Audit/resetAuditByAuditID" + "/" + auditID, {withCredentials: true});
      }
      public auditQuestionsByAuditAndAssessorID(auditID: number, ntid: string) {
        return this.http.get<AuditQuestion[]>(this.apiURL + "Audit/AuditQuestionsByAuditAndAssessorID" + "/" + auditID + "/"+ntid, {withCredentials: true});
      }

      public auditQuestionsByCurrentAssessorAndTemplateID(auditID: number, ntid: string) {
        return this.http.get<AuditQuestion[]>(this.apiURL + "Audit/AuditQuestionsByCurrentAssessorAndTemplateID" + "/" + auditID + "/"+ntid, {withCredentials: true});
      }

      public auditQuestionsByAuditAndTemplateID(auditID: number, auditAnsweredTemplateID: number, ValueStreamID: number) {
        return this.http.get<AuditQuestion[]>(this.apiURL + "Audit/AuditQuestionsByAuditAndTemplateID" + "/" + auditID + "/"+ auditAnsweredTemplateID + "/" + ValueStreamID, {withCredentials: true});
      }

      public auditAssessorsByAuditID(auditID: number) {
        return this.http.get<AuditAssessor[]>(this.apiURL + "Audit/AuditAssessorsByAuditID" + "/" + auditID, {withCredentials: true});
      }

      public auditAssessorsByAuditAndTemplateID(auditID: number, templateID: number) {
        return this.http.get<AuditAssessor[]>(this.apiURL + "Audit/AuditAssessorsByAuditAndTemplateID" + "/" + auditID +"/"+templateID, {withCredentials: true});
      }

      public otherAuditAssessorsByAuditAndTemplateID(auditID: number, templateID: number) {
        return this.http.get<AuditAssessor[]>(this.apiURL + "Audit/OtherAuditAssessorsByAuditAndTemplateID" + "/" + auditID +"/"+templateID, {withCredentials: true});
      }

      public updateAuditQuestion(auditQuestion: AuditQuestion) {
        return this.http.post<AuditQuestion>(this.apiURL + "Audit/UpdateAuditQuestion", auditQuestion, {withCredentials: true});
      }

      public insertAuditDetail(auditDetail: AuditDetail) {

        return this.http.post<AuditDetail>(this.apiURL + "Audit/InsertAuditDetail", auditDetail, {withCredentials: true});
      }

      public addEditAuditQuestion(auditQuestion: AuditQuestion) {

        return this.http.post<Result>(this.apiURL + "Audit/AddEditAuditQuestion", auditQuestion, {withCredentials: true});
      }

      public valueStreamsByTagID(tagID: number) {
        return this.http.get<ValueStream[]>(this.apiURL + "Audit/valueStreamsByTagID" + "/" + tagID);
      }
      public validateAssessorByAuditAndNTID(auditID: number, ntid:string) {
        return this.http.get<User>(this.apiURL + "Audit/ValidateAssessorByAuditAndNTID" + "/" + auditID +"/" + ntid);
      }

      public requiredAttendeesByAuditID(auditID: number) {
        return this.http.get<AuditAssessor[]>(this.apiURL + "Audit/RequiredAttendeesByAuditID" + "/" + auditID, {withCredentials: true});
      }

      public optionalAttendeesByAuditID(auditID: number) {
        return this.http.get<AuditAssessor[]>(this.apiURL + "Audit/OptionalAttendeesByAuditID" + "/" + auditID, {withCredentials: true});
      }

      public emailToAttendees(audit:Audit){
        var plainText = {"plant": this.sharedService.plantID, "id":audit.auditID};
        var encryptedString = this.sharedService.encrypt(JSON.stringify(plainText));
        audit.calendarUrl  = environment.uiUrl + environment.home +'/calendar;auditid=' + encryptedString ;
        return this.http.post<Audit>(this.apiURL + "Audit/EmailToAttendees", audit, {withCredentials: true});
      }

      public completeAuditByAuditAndTemplateID(auditID: number, auditAnsweredTemplateID: number) {
        return this.http.get<Result[]>(this.apiURL + "Audit/CompleteAuditByAuditAndTemplateID" + "/" + auditID + "/"+ auditAnsweredTemplateID, {withCredentials: true});
      }

      public SendAuditAnswerEmail(audit: Audit) {
        return this.http.post<any>(this.apiURL + "Audit/SendAnswerSummaryEmail", audit, {withCredentials: true});
      }
      public SendTagModeAnswerEmail(processConfirmation:ProcessConfirmation) {
        return this.http.post<any>(this.apiURL + "Audit/SendTagModeAnswerSummaryEmail", processConfirmation, {withCredentials: true});
      }
      
      public AuditQuestionLinkedTagDetails(tagDetails: TagDetails) {
        return this.http.post<Result>(this.apiURL + "Audit/AuditQuestionLinkedTagDetails", tagDetails, {withCredentials: true});
      }

  }
