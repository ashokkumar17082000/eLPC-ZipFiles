import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { SearchFilter, SharedService } from './shared.service';
import { ProcessConfirmation } from '../pc/process-confirmation/process-confirmation'
import { HintImage } from 'src/app/Datapool/QuestionModule/questions/question';
import { DataPoolHistory } from 'src/app/Datapool/QuestionModule/data-pool/datapool';
import { saveAs } from 'file-saver';
import { DatePipe } from '@angular/common';
import moment from 'moment-timezone';

moment.tz.setDefault('Utc');

@Injectable({
  providedIn: 'root'
})
export class DataPoolService {

  private headers: HttpHeaders;
  apiURL: string;
  processConfirmation: ProcessConfirmation = new ProcessConfirmation();

  constructor(private http: HttpClient, private sharedService: SharedService, private datePipe: DatePipe) {
    this.headers = new HttpHeaders();
    this.headers.append("Content-Type", "application/json");
    this.apiURL = this.sharedService.apiURL;
  }

  // GetDataPool() {
  //   return this.http.get<ProcessConfirmation[]>(this.apiURL + "DataPool/GetDataPool/", { withCredentials: true });
  // }

  GetDataPool(filter: SearchFilter) {
    filter.fromDate = moment([filter.fromDate.getFullYear(), filter.fromDate.getMonth(), filter.fromDate.getDate()]).toDate();
    filter.toDate = moment([filter.toDate.getFullYear(), filter.toDate.getMonth(), filter.toDate.getDate()]).toDate();

    return this.http.post<ProcessConfirmation[]>(this.apiURL + "DataPool/GetDataPool/", filter, { withCredentials: true });
  }

  async GetExcelFile(moduleName: string,DateFilter? :boolean,fromDate?:string,toDate?:string) {
    debugger
    this.sharedService.show();
    var fileName = "";
    var spName = "";
    if (moduleName === "DataPool") {
      spName = "USP_DataPoolExport";
      fileName = "DataPool.xlsx";
    }
    else if(moduleName=='DataPoolFiltered'){
      spName = "USP_DataPoolExportFiltered";
      fileName = "DataPoolFiltered.xlsx";
    }else if (moduleName=='DeviationDataPool_Filtered'){
      spName = "USP_DeviationDataPoolExportFiltered";
      fileName = "DeviationDataPoolFiltered.xlsx";
    }
    // else if(moduleName=='FetchAuditAnswers'){
    //   spName = "USP_FetchAuditAnswers";
    //   fileName = "AuditData.xlsx";
    // }
    else if (moduleName === "ValueStream") {
      spName = "USP_ExportValueStreamTemplate";
      fileName = "ValueStreams.xlsx";
    }
    else if (moduleName === "Assessor") {
      spName = "USP_ExportAssessorTemplate";
      fileName = "Assessors.xlsx";
    }
    else if (moduleName === "Question") {
      spName = "USP_ExportQuestionTemplate";
      fileName = "Questions.xlsx";
    }
    else if (moduleName === "Tag") {
      spName = "USP_ExportTagTemplate";
      fileName = "Tags.xlsx";
    }
    else if (moduleName === "PlantReport") {
      spName = "USP_ExportPlantReport";
      let formatedFileName = this.sharedService.currentUserInfo.plantCode + "_Export_" + this.getFormattedTime();
      fileName = formatedFileName + ".xlsx";
    }
    else if (moduleName === "UserReport") {
      spName = "USP_ExportPlantReport";
      let formatedFileName = this.sharedService.currentUserInfo.plantCode + "_" + this.sharedService.ntid.toUpperCase() + "_Export_" + this.getFormattedTime();
      fileName = formatedFileName + ".xlsx";
    }
    else if (moduleName === "DeviationDataPool") {
      spName = "USP_DeviationDataPoolExport";
      fileName = "DeviationDataPool.xlsx";
    }
    if(DateFilter){
      
        spName = "USP_ExportPlantReportOneYear";
        let formatedFileName = this.sharedService.currentUserInfo.plantCode + "_" + this.sharedService.ntid.toUpperCase() + "_Export_" + this.getFormattedTime();
        fileName = formatedFileName + "OneYear.xlsx";
        await this.http.get(this.apiURL + "DataPool/DataPoolExportExcelTemplate/" + spName + '/' + moduleName, { responseType: 'blob' }).subscribe(blob => {
          this.sharedService.hide();
          saveAs(blob, fileName, {
            type: 'application/octet'
          });
        },
          err => {
            console.log(err);
            this.sharedService.hide();
          });
      
    }
    else{
      if(spName=='USP_DataPoolExportFiltered'){
        await this.http.get(this.apiURL + "DataPool/DataPoolExportExcelTemplateFilter/" + spName + '/'  +fromDate +'/'+toDate+'/'+ moduleName, { responseType: 'blob' }).subscribe(blob => {
          this.sharedService.hide();
          saveAs(blob, fileName, {
            type: 'application/octet'
          });
        },
          err => {
            console.log(err);
            this.sharedService.hide();
          });
      }else if (spName=='USP_DeviationDataPoolExportFiltered') {
        await this.http.get(this.apiURL + "DataPool/DeviationDataPoolExportExcelTemplateFilter/" + spName + '/'  +fromDate +'/'+toDate+'/'+ moduleName, { responseType: 'blob' }).subscribe(blob => {
          this.sharedService.hide();
          saveAs(blob, fileName, {
            type: 'application/octet'
          });
        },
          err => {
            console.log(err);
            this.sharedService.hide();
          });
      }else {
        await this.http.get(this.apiURL + "DataPool/DataPoolExportExcelTemplate/" + spName + '/' + moduleName, { responseType: 'blob' }).subscribe(blob => {
          this.sharedService.hide();
          saveAs(blob, fileName, {
            type: 'application/octet'
          });
        },
          err => {
            console.log(err);
            this.sharedService.hide();
          });
      }
     
    }
   
    
  }

  GetExcelFileByIDs(moduleName: string, ids : number[]) {
    console.log(moduleName)
    this.sharedService.show();
    var fileName = "";
    var spName = "";

    if (moduleName === "ValueStream") {
      spName = "USP_ExportValueStreamTemplate";
      fileName = "ValueStreams_Filtered.xlsx";
    }
    else if (moduleName === "Assessor") {
      spName = "USP_ExportAssessorTemplate";
      fileName = "Assessors_Filtered.xlsx";
    }
    else if (moduleName === "Question") {
      spName = "USP_ExportQuestionTemplate";
      fileName = "Questions_Filtered.xlsx";
    }
    else if (moduleName === "Tag") {
      spName = "USP_ExportTagTemplate";
      fileName = "Tags_Filtered.xlsx";
    }
    else if(moduleName=='DataPoolFiltered'){
      spName = "USP_DataPoolExportFilteredByIDs";
      fileName = "DataPoolFiltered.xlsx";
    }
    else if (moduleName=='DeviationDataPool_Filtered'){
      spName = "USP_DeviationDataPoolExportFilteredByIDs";
      fileName = "DeviationDataPoolFiltered.xlsx";
    }
    let filter = new SearchFilter();
    filter.uSPName = spName;
    filter.moduleName = moduleName;
    filter.ids = ids;

    this.http.post(this.apiURL + "DataPool/ExportExcelTemplateByInputIDs/", filter, { withCredentials: true, responseType: 'blob' }).subscribe(blob => {
      this.sharedService.hide();
      saveAs(blob, fileName, {
        type: 'application/octet'
      });
    },
      err => {
        console.log(err);
        this.sharedService.hide();
      });
  }

  getFormattedTime() {
    let now = new Date();
    return (this.datePipe.transform(now, 'yyyy-MM-dd_HH-mm-ss').toString());
  }

  // GetDeviationDataPool() {
  //   return this.http.get<ProcessConfirmation[]>(this.apiURL + "DataPool/GetDeviationDataPool/", { withCredentials: true });
  // }

  GetDeviationDataPool(filter: SearchFilter) {
    filter.fromDate = moment([filter.fromDate.getFullYear(), filter.fromDate.getMonth(), filter.fromDate.getDate()]).toDate();
    filter.toDate = moment([filter.toDate.getFullYear(), filter.toDate.getMonth(), filter.toDate.getDate()]).toDate();

    return this.http.post<ProcessConfirmation[]>(this.apiURL + "DataPool/GetDeviationDataPool/", filter, { withCredentials: true });
  }
 
  GetDeviationFileByAttachmentID(attachmentID: number) {
    return this.http.get<HintImage[]>(this.apiURL + "DataPool/GetDeviationFileByAttachmentID" + '/' + attachmentID, { withCredentials: true });
  }

  // public getProcessConfirmationByID(dataPoolID: number) {
  //   return this.http.get<DataPool[]>(this.apiURL + "/DataPool/getProcessConfirmationByID/" + '/' + dataPoolID);
  // }

  public getProcessConfirmationByID(dataPoolID: number) {
    return this.http.get<ProcessConfirmation[]>(this.apiURL + "DataPool/getProcessConfirmationByID" + '/' + dataPoolID, { withCredentials: true });
  }

  public hintImagesByDeviationID(deviationID: number) {
    return this.http.get<HintImage[]>(this.apiURL + "DataPool/HintImagesByDeviationID" + '/' + deviationID, { withCredentials: true });
  }

  public UpdateDataPool(processConfirmation: ProcessConfirmation) {
    return this.http.post<ProcessConfirmation>(this.apiURL + "DataPool/UpdateDataPool", processConfirmation, { withCredentials: true });
  }

  public removeDeviationImage(processConfirmation: ProcessConfirmation) {
    return this.http.post<ProcessConfirmation>(this.apiURL + "DataPool/RemoveDeviationImage", processConfirmation, { withCredentials: true });
  }

  public deleteDataPool(processConfirmation: ProcessConfirmation) {
    return this.http.post<ProcessConfirmation>(this.apiURL + "DataPool/DeleteDataPool", processConfirmation, { withCredentials: true });
  }

  // ***export****
  DataPoolExportExcel() {
    return this.http.get(this.apiURL + 'DataPool/DataPoolExportExcel', { withCredentials: true });
  }

  public getDataPoolTemplateHistory(templateID: number) {
    return this.http.get<DataPoolHistory[]>(this.apiURL + "DataPool/GetDataPoolHistory" + '/' + templateID, { headers: this.headers, withCredentials: true });
  }

  public dataPoolRestoreByTemplateHistoryID(historyID: number) {
    return this.http.get(this.apiURL + "DataPool/DataPoolRestoreByTemplateHistoryID" + '/' + historyID, { withCredentials: true });
  }
}
