import { Injectable } from '@angular/core';
import { Subject, Observable, of } from 'rxjs';
import { catchError, debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { UserDetailsService } from 'src/app/service/user-details.service';

@Injectable({
  providedIn: 'root',
})
export class SearchService {
  private searchTerms = new Subject<string>();
  private searchTerms_Optional = new Subject<string>();

  constructor(private userDetailsService: UserDetailsService) {}

  // Expose the search stream
  getSearchResults(): Observable<any> {
    console.log("service call")
    return this.searchTerms.pipe(
      debounceTime(300),
      distinctUntilChanged(),
      switchMap((term: string) =>
        term
          ? this.userDetailsService.getUserDetails_1(term).pipe(
              catchError((err) => {
                console.error('Failed to fetch users from Graph API', err);
                return of({ value: [] }); // Return an empty result set
              })
            )
          : of({ value: [] }) // Return an empty result set if the term is empty
      )
    );
  }

    // Expose the search stream
    getSearchResults_optional(): Observable<any> {
      
      return this.searchTerms_Optional.pipe(
        debounceTime(300),
        distinctUntilChanged(),
        switchMap((term: string) =>
          term
            ? this.userDetailsService.getUserDetails_1(term).pipe(
                catchError((err) => {
                  console.error('Failed to fetch users from Graph API', err);
                  return of({ value: [] }); // Return an empty result set
                })
              )
            : of({ value: [] }) // Return an empty result set if the term is empty
        )
      );
    }

  // Update the search term
  setSearchTerm(term: string): void {
    this.searchTerms.next(term.trim());
  }

  setSearchTerm_optional(term: string): void {
    this.searchTerms_Optional.next(term.trim());
  }
}
