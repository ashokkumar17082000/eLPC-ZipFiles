import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ErrorEventService {
  private errorEvent = new Subject<number>(); // Using number to indicate error code

  emitError(errorCode: number) {
    this.errorEvent.next(errorCode); // Emit error event
  }

  getErrorEvent() {
    return this.errorEvent.asObservable(); // Subscribe to this in the component
  }
}
