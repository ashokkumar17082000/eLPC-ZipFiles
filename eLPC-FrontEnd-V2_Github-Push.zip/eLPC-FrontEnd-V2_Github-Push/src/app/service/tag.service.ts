import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import { HttpHeaders } from '@angular/common/http';
import { Tag, TagProxy, TagStreamHistory, AssessorValueStreamList } from 'src/app/Tag/tag/tag';
import { Question } from 'src/app/Datapool/QuestionModule/questions/question';
import { SharedService } from '../service/shared.service';
import { Assessor } from 'src/app/Assessor/assessor/assessortemplate';
import { ValueStream } from 'src/app/Valuestream/valuestreams/valuestreamtemplate';


@Injectable({
  providedIn: 'root',
})

export class TagService {
  tag: Tag = new Tag();
  private headers: HttpHeaders;
  apiURL: string;

  constructor(private http: HttpClient, private sharedService: SharedService) {
    this.headers = new HttpHeaders();
    this.headers.append("Content-Type", "application/json");
    this.headers.append("Access-Control-Allow-Methods", "GET, POST, DELETE, PUT");

    this.headers.append("'Access-Control-Allow-Origin", "*");
    this.apiURL = this.sharedService.apiURL;
  }

    public getTags() {
    return this.http.get<Tag[]>(this.apiURL + "Tag/GetTags", { headers: this.headers, withCredentials: true });
  }

  public getTags_ProcessConfirmation() {
    return this.http.get<Tag[]>(this.apiURL + "Tag/GetTagsProcessConfirmation", { headers: this.headers, withCredentials: true });
  }

  public getTagsByID(tagID: number) {
    return this.http.get<Tag[]>(this.apiURL + "Tag/GetTagsByID" + "/" + tagID, { headers: this.headers, withCredentials: true });
  }

  public insertTag(tag: Tag) {
    return this.http.post<Tag>(this.apiURL + "Tag/InsertTag", tag, { withCredentials: true });
  }

  public deleteTag(tag: Tag) {
    return this.http.post<Tag>(this.apiURL + "Tag/DeleteTag", tag, { withCredentials: true });
  }

  public getQuestionsByTagID(tagID: number) {
    return this.http.get<Question[]>(this.apiURL + "Tag/GetQuestionsByTagID" + "/" + tagID, { withCredentials: true });
  }

  public getBranchLogicHistory(tag: Tag) {
    let tagID=tag.tagID;
    let Plantid=this.sharedService.plantID;
    return this.http.get<Question[]>(this.apiURL + "Tag/getBranchLogicHistory"+ '/' + Plantid + '/' + tagID, { headers: this.headers, withCredentials: true });
  }
  public insertQuestionIntoTagAssignedInlineMode(TagID: number, QuestionID: number, LinkedTagID: number, IsDeleteQuery: boolean, requestFrom: number = 0)
  {
    return this.http.get<any>(this.apiURL + "Tag/insertQuestionIntoTagAssignedInlineMode" + "/" + TagID+ "/" + QuestionID+ "/" + LinkedTagID+ "/" + IsDeleteQuery+ "/" + requestFrom, { withCredentials: true });
  }
  public getAssessorsByTagID(tags: string) {
    return this.http.post<Assessor[]>(this.apiURL + "Tag/GetAssessorsByTagIDs", { tagsIDs: tags }, { withCredentials: true });
  }

  public getTagsByTagID(tagID: number) {
    return this.http.get<Tag[]>(this.apiURL + "Tag/GetTagsByTagID" + "/" + tagID, { withCredentials: true });
  }

  public getTagStreamTemplateHistory(templateID: number) {
    return this.http.get<TagStreamHistory[]>(this.apiURL + "Tag/GetTagHistory" + '/' + templateID, { headers: this.headers, withCredentials: true });
  }

  public tagRestoreByTemplateHistoryID(historyID: number) {
    return this.http.get(this.apiURL + "Tag/TagRestoreByTemplateHistoryID" + '/' + historyID, { withCredentials: true });
  }

  public insertTagProxy(tagProxy: TagProxy) {
    return this.http.post<TagProxy>(this.apiURL + "Tag/InsertTagProxy", tagProxy, { withCredentials: true });
  }

  public fetchQuestionsByAssessorsAndValueStreams(assessorValueStreamList: AssessorValueStreamList) {
    return this.http.post<Question[]>(this.apiURL + "Tag/FetchQuestionsByAssessorsAndValueStreams", assessorValueStreamList, { withCredentials: true });
  }

  public fetchTagsByAssessorsAndValueStreams(assessorValueStreamList: AssessorValueStreamList) {
    return this.http.post<Tag[]>(this.apiURL + "Tag/FetchTagsByAssessorsAndValueStreams", assessorValueStreamList, { withCredentials: true });
  }

  public valueStreamsByTagID(tagID: number) {
    return this.http.get<ValueStream[]>(this.apiURL + "Tag/ValueStreamsByTagID" + '/' + tagID, { withCredentials: true });
  }

  public assessorsByTagID(tagID: number) {
    return this.http.get<Assessor[]>(this.apiURL + "Tag/AssessorsByTagID" + '/' + tagID, { withCredentials: true });
  }

  public tagProxiesByTagID(tagID: number) {
    return this.http.get(this.apiURL + "Tag/TagProxiesByTagID" + '/' + tagID, { withCredentials: true });
  }

  public fetchProcessConfirmationTags() {
    return this.http.get<Tag[]>(this.apiURL + "Tag/FetchProcessConfirmationTags", { headers: this.headers, withCredentials: true });
  }

  public fetchTagDetailsByTagID(tagID: number) {
    return this.http.get<Tag[]>(this.apiURL + "Tag/FetchTagDetailsByTagID" + '/' + tagID, { withCredentials: true });
  }

  public getTagModeTags() {
    return this.http.get<Tag[]>(this.apiURL + "TagMode/GetTagModeTags", { headers: this.headers, withCredentials: true });
  }

 
  

  public getTagModeTagsCalendar() {
    return this.http.get<Tag[]>(this.apiURL + "TagMode/GetTagModeTagsCalendar", { headers: this.headers, withCredentials: true });
  }

  public updateAuditByTagID(tagID: number) {
    return this.http.post(this.apiURL + "Tag/UpdateAuditByTagID" + '/' + tagID, { withCredentials: true });
  }

}
