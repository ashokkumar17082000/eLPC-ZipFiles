import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { SharedService } from './shared.service';
import { CustomMode } from '../custommode/custom-mode/custom-mode';
import { Tag } from 'src/app/Tag/tag/tag';
//import { Question } from '../main/body/questions/question';

@Injectable({
  providedIn: 'root'
})
export class CustomModeService {

  private headers: HttpHeaders;
  apiURL: string;
  constructor(private http:HttpClient,private sharedService:SharedService) {
    this.headers = new HttpHeaders();
    this.headers.append("Content-Type", "application/json");
    this.apiURL = this.sharedService.apiURL;
   }
   public GetCustomModeByNTID(NTID:string){
    return this.http.get<CustomMode[]>(this.apiURL+"CustomMode/GetCustomModeByNTID"+"/"+NTID,{ headers: this.headers, withCredentials: true });
  }
   public getCustomTags() {
    return this.http.get<Tag[]>(this.apiURL + "CustomMode/GetCustomTags", { headers: this.headers, withCredentials: true });
  }
  public  insertCustomMode(customMode:CustomMode){
    return this.http.post<CustomMode>(this.apiURL + "CustomMode/InsertCustomMode", customMode, {withCredentials: true});
  }
  public  removeFromCustomModeList(customMode:CustomMode){
    return this.http.post<CustomMode>(this.apiURL + "CustomMode/RemoveFromCustomModeList", customMode, {withCredentials: true});
  }
}
