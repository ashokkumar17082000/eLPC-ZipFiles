import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SharedService } from '../shared.service';
import { HttpHeaders } from '@angular/common/http';
import { ValueStream } from 'src/app/Valuestream/valuestreams/valuestreamtemplate';
import { Assessor } from 'src/app/Assessor/assessor/assessortemplate';
import { ProcessConfirmation } from '../../pc/process-confirmation/process-confirmation';
//import { ValueStream } from 'src/app/main/body/value-streams/valuestreamtemplate';
import { Observable } from 'rxjs';

import { map } from 'rxjs/operators';
import { Result } from 'src/app/main/body/shared/common';
import { Question } from 'src/app/Datapool/QuestionModule/questions/question';

@Injectable({
  providedIn: 'root'
})
export class ProcessConfirmationService {
  myquestionID:number;
  processConfirmation: ProcessConfirmation = new ProcessConfirmation();
  private headers: HttpHeaders;
  apiURL: string;
  constructor(private http:HttpClient,private sharedService:SharedService) {
    this.headers = new HttpHeaders();
    this.headers.append("Content-Type", "application/json");
    this.apiURL = this.sharedService.apiURL;
   }

   public getValueStreamByQuestionID(QuestionID:number) {
    // return this.http.get<ValueStream[]>(this.apiURL + "ProcessConfirmation/getValueStreamByQuestionID"+'/'+QuestionID);
    return this.http.get<ProcessConfirmation[]>(this.apiURL + "ProcessConfirmation/getValueStreamByQuestionID"+'/'+QuestionID);
  }
  public getTagInlineSelectedQuestionCount(TagId:number): Observable<number> {
    // return this.http.get<ValueStream[]>(this.apiURL + "ProcessConfirmation/getValueStreamByQuestionID"+'/'+QuestionID);
    return this.http.get<number>(this.apiURL + "ProcessConfirmation/getTagInlineSelectedQuestionCount"+'/'+TagId);
  }

  public getSelectedLinkedTagQuestionCount(TagId:number, maintablequestioncount: boolean = false): Observable<number>
  {
    return this.http.get<number>(this.apiURL + "ProcessConfirmation/getSelectedLinkedTagQuestionCount"+'/'+TagId+'/'+maintablequestioncount);
  }
  public getCurrentSelectionQuestionsAndTag(TagId: string, QuestionCount:number): Observable<number>
  {
    return this.http.get<number>(this.apiURL + "ProcessConfirmation/getCurrentSelectionQuestionsAndTag"+'/'+TagId+'/'+QuestionCount);
  }
  public  updateEventEndTime(eventIDStarttime:String,processconfirmation:ProcessConfirmation){

    const body = { 
      eventstarttime: eventIDStarttime,
     processconfirmationdata:processconfirmation 
    };
    return this.http.post(this.apiURL + "ProcessConfirmation/updateEventEndTime", body, {withCredentials: true});
  }

  public getAssessorsByQuestionID(QuestionID:number) {

    return this.http.get<Assessor[]>(this.apiURL + "ProcessConfirmation/getAssessorsByQuestionID"+'/'+QuestionID);
  }

  public getProcessConfirmation(ModeType: string, vsID: number, asID: number, NTID: string, PCTagID: number, myQuestionID: number, AnsweredAndSkippedQuestionID: any[],ResumeTagProcessConfirmation?:boolean) {
    let processConfirmation = new ProcessConfirmation();
    processConfirmation.modeType = ModeType;
    processConfirmation.valueStreamID = vsID;
    processConfirmation.assessorID = asID;
    processConfirmation.questionID = myQuestionID;
    processConfirmation.answeredAndSkippedQuestionID = AnsweredAndSkippedQuestionID;
    processConfirmation.tagID = PCTagID;
    processConfirmation.sessionID = this.sharedService.sessionID;
    processConfirmation.ResumeTagProcessConfirmation = ResumeTagProcessConfirmation;

    return this.http.post<ProcessConfirmation[]>(this.apiURL + "ProcessConfirmation/GetProcessConfirmation", processConfirmation, { withCredentials: true });
  }

  public  pendingTagModeStatus(processConfirmation:ProcessConfirmation){
    processConfirmation.sessionID = this.sharedService.sessionID;
    return this.http.post <Number> (this.apiURL + "ProcessConfirmation/pendingTagModeStatus", processConfirmation, {withCredentials: true});
  }
  public  insertProcessConfirmation(processConfirmation:ProcessConfirmation){
    processConfirmation.sessionID = this.sharedService.sessionID;
    return this.http.post<Result>(this.apiURL + "ProcessConfirmation/InsertProcessConfirmation", processConfirmation, {withCredentials: true});
  }
  public  addToCustomMode(processConfirmation:ProcessConfirmation){

    return this.http.post<ProcessConfirmation>(this.apiURL + "ProcessConfirmation/AddToCustomMode", processConfirmation, {withCredentials: true});
  }

  public  deleteFromCustomMode(processConfirmation:ProcessConfirmation){
    return this.http.post<ProcessConfirmation>(this.apiURL + "ProcessConfirmation/DeleteFromCustomMode", processConfirmation, {withCredentials: true});
  }

  public getProcessConfirmationByID(dataPoolID: number) {

    return this.http.get<ProcessConfirmation[]>(this.apiURL + "ProcessConfirmation/GetProcessConfirmationByID" + '/' + dataPoolID, {withCredentials: true});
  }
  DownloadFile(filePath: string, fileType:string): Observable<any>{
    let fileExtension = fileType;
    let input = filePath;
    // return this.http.post("http://localhost:21021/api/services/app/FormAttachment/DownloadFile?fileName="+input, '',
    // return this.http.post(this.apiURL + "DownloadFile/DownloadFile?fileName="+input, '',
    return this.http.post(this.apiURL + "DownloadFile/DownloadFile"+"/"+input, '',  { responseType: 'blob' })
    // { responseType: ResponseContentType.Blob })
    // { responseType: 'blob' as 'blob' })
    .pipe(
      map((res: any) => {
        // return new Blob([res.blob()], { type: 'application/pdf' });
        return new Blob([res], { type: 'application/pdf' });
      })
    );

    // .map(
    //   (res) => {
    //         var blob = new Blob([res.blob()], {type: fileExtension} )
    //         return blob;
    //   });
  }
  upload(file: any) {
    let input = new FormData();
    input.append("filesData", file);

    alert(this.http.post(this.apiURL+"DownloadFile/upload"+"/"+ input,{withCredentials: true}));
    return this.http.post(this.apiURL+"DownloadFile/upload", input)
        .map(res => res);
}

}
