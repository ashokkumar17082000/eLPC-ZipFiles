 import { Injectable } from '@angular/core';
// import { ApplicationInsights } from '@microsoft/applicationinsights-web';
// import { AngularPlugin } from '@microsoft/applicationinsights-angularplugin-js';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AppInsightsService {
  private appInsights: any;
  private angularPlugin: any;

  // constructor(private router: Router) {
  //   this.angularPlugin = new AngularPlugin();
    
  //   this.appInsights = new ApplicationInsights({
  //     config: {
  //       connectionString: 'InstrumentationKey=ef8068b0-661b-4f7f-8331-7f239f823660;IngestionEndpoint=https://germanywestcentral-1.in.applicationinsights.azure.com/;LiveEndpoint=https://germanywestcentral.livediagnostics.monitor.azure.com/;ApplicationId=ee1a779a-b261-4aa0-a97a-aa90a15e9c8c', // Replace with your connection string
  //       extensions: [this.angularPlugin],
  //       extensionConfig: {
  //         [this.angularPlugin.identifier]: { router: this.router }
  //       }
  //     }
  //   });
    
  //   this.appInsights.loadAppInsights();
  // }

  // logEvent(name: string, properties?: { [key: string]: any }) {
  //   this.appInsights.trackEvent({ name, properties });
  // }

  // logMetric(name: string, average: number, properties?: { [key: string]: any }) {
  //   this.appInsights.trackMetric({ name, average }, properties);
  // }

  // logException(exception: Error, severityLevel?: number) {
  //   this.appInsights.trackException({ exception, severityLevel });
  // }

  // logTrace(message: string, properties?: { [key: string]: any }) {
  //   this.appInsights.trackTrace({ message }, properties);
  // }
}