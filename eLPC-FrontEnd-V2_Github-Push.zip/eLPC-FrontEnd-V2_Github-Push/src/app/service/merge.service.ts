import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SharedService } from './shared.service';
import { Question } from 'src/app/Datapool/QuestionModule/questions/question';
import { Merge, MergeProxy } from 'src/app/Merge/merge/merge';

@Injectable({
  providedIn: 'root'
})
export class MergeService {

  private headers: HttpHeaders;
  apiURL: string;
  question: Question = new Question();
  
  constructor(private http: HttpClient, private sharedService: SharedService) {
    this.headers = new HttpHeaders();
    this.headers.append("Content-Type", "application/json");
    this.headers.append("Access-Control-Allow-Methods", "GET, POST, DELETE, PUT");

    this.headers.append("'Access-Control-Allow-Origin", "*");
    this.apiURL = this.sharedService.apiURL;
  }

  public mergeQuestionAssignment(mergeQuestionAssignment: Merge) {
    return this.http.post<Merge>(this.apiURL + "Merge/QuestionAssignment", mergeQuestionAssignment, { withCredentials: true });
  }

  public mergeTagAssignment(mergeTagAssignment: Merge) {
    return this.http.post<Merge>(this.apiURL + "Merge/TagAssignment", mergeTagAssignment, { withCredentials: true });
  }

  public mergeQuestionRemoval(mergeQuestionRemoval: Merge) {
    return this.http.post<Merge>(this.apiURL + "Merge/QuestionRemoval", mergeQuestionRemoval, { withCredentials: true });
  }

  public mergeTagRemoval(mergeTagRemoval: Merge) {
    return this.http.post<Merge>(this.apiURL + "Merge/TagRemoval", mergeTagRemoval, { withCredentials: true });
  }
  
  public insertQuestionProxy(questionProxy: MergeProxy) {
    return this.http.post<MergeProxy>(this.apiURL + "Merge/InsertQuestionProxy", questionProxy, { withCredentials: true });
  }
    
  public insertTagProxy(tagProxy: MergeProxy) {
    return this.http.post<MergeProxy>(this.apiURL + "Merge/InsertTagProxy", tagProxy, { withCredentials: true });
  }
}
