import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { SharedService } from './shared.service';
import { TagMode } from '../ProcessConfirmation/process-confirmationmode/tag-mode/tag-mode';
import { Tag } from 'src/app/Tag/tag/tag';
import { Question } from 'src/app/Datapool/QuestionModule/questions/question';
//import { AuditQuestion } from '../main/body/calendar/calendar';
import { AuditQuestion } from '../calendar/calendar/calendar';
@Injectable({
  providedIn: 'root'
})
export class TagModeService {

  private headers: HttpHeaders;
  apiURL: string;
  constructor(private http:HttpClient,private sharedService:SharedService) {
    this.headers = new HttpHeaders();
    this.headers.append("Content-Type", "application/json");
    this.apiURL = this.sharedService.apiURL;
   }

   public GetTagModeByNTID(NTID:string){
    return this.http.get<TagMode[]>(this.apiURL+"TagMode/GetTagModeByNTID"+"/"+NTID,{ headers: this.headers, withCredentials: true });
  }


   public getTagModeTags() {
    return this.http.get<Tag[]>(this.apiURL + "TagMode/GetTagModeTags", { headers: this.headers, withCredentials: true });
  }
 
  public  insertToTagMode(tagMode:TagMode){
    return this.http.post<TagMode>(this.apiURL + "TagMode/insertToTagMode", tagMode, {withCredentials: true});
  }

  public  removeFromTagMode(tagMode:TagMode){
    return this.http.post<TagMode>(this.apiURL + "TagMode/DeleteTagMode", tagMode, {withCredentials: true});
  }
  
  public getInfoQuestionsByTagID(tagID: number) {  
    return this.http.get<Question[]>(this.apiURL + "TagMode/GetInfoQuestionsByTagID" + "/" + tagID, {withCredentials: true});

  }

  //for tagmode audit
  public fetchTagModeQuestionsByCurrentAssessorAndTemplateID(tagID: number, ntid: string) {
    return this.http.get<AuditQuestion[]>(this.apiURL + "TagMode/FetchTagModeQuestionsByCurrentAssessorAndTemplateID" + "/" + tagID + "/" + ntid, { withCredentials: true });
  }

  public addEditTagModeQuestion(auditQuestion: AuditQuestion) {

    return this.http.post<AuditQuestion>(this.apiURL + "TagMode/AddEditTagModeQuestion", auditQuestion, { withCredentials: true });
  }
  //end of tagmode audit
}
