import { Injectable } from '@angular/core';
import { Deviation } from 'src/app/Deviation/deviation/deviation';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { SharedService } from './shared.service';

@Injectable({
  providedIn: 'root'
})
export class DeviationService {

  private headers: HttpHeaders;
  apiURL: string;
  constructor(private http:HttpClient,private sharedService:SharedService) {
    this.headers = new HttpHeaders();
    this.headers.append("Content-Type", "application/json");
    this.apiURL = this.sharedService.apiURL;
   }

  // use commonservice
  // public  insertIntoDeviation(deviation:Deviation){
  //   return this.http.post<Deviation>(this.apiURL + "Deviation/insertIntoDeviation", deviation, {withCredentials: true});
  // }
}
