import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {ValueStreamsComponent} from '../valuestreams/value-streams.component';
import { ValueStreamsEditComponent } from '../valuestreams/value-streams.edit.component';
import { ValueStreamsLockComponent } from '../valuestreams/value-streams.lock.component';

const routes: Routes = [
  { path: 'valuestreams-edit', component: ValueStreamsEditComponent },
  { path: 'valuestreams-lock', component: ValueStreamsLockComponent },
  { path: '', component: ValueStreamsComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ValuesreamRRoutingModule { }
