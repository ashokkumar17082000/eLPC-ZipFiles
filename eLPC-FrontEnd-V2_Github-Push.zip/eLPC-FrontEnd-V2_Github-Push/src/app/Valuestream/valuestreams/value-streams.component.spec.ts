import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ValueStreamsComponent } from './value-streams.component';

describe('ValueStreamsComponent', () => {
  let component: ValueStreamsComponent;
  let fixture: ComponentFixture<ValueStreamsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ValueStreamsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ValueStreamsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
