"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ValueStreamTemplate = /** @class */ (function () {
    function ValueStreamTemplate() {
    }
    return ValueStreamTemplate;
}());
exports.ValueStreamTemplate = ValueStreamTemplate;
var ValueStreamCategory = /** @class */ (function () {
    function ValueStreamCategory() {
    }
    return ValueStreamCategory;
}());
exports.ValueStreamCategory = ValueStreamCategory;
var ValueStream = /** @class */ (function () {
    function ValueStream() {
    }
    return ValueStream;
}());
exports.ValueStream = ValueStream;
var Shift = /** @class */ (function () {
    function Shift() {
        this.fromTime = new Date();
        this.toTime = new Date();
        this.isMonday = false;
        this.isTuesday = false;
        this.isWednesday = false;
        this.isThursday = false;
        this.isFriday = false;
        this.isSaturday = false;
        this.isSunday = false;
    }
    return Shift;
}());
exports.Shift = Shift;
var ValueStreamProxy = /** @class */ (function () {
    function ValueStreamProxy() {
    }
    return ValueStreamProxy;
}());
exports.ValueStreamProxy = ValueStreamProxy;
//# sourceMappingURL=valuestreamtemplate.js.map