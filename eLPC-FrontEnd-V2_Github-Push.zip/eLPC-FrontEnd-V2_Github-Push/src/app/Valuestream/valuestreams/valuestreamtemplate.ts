import { User } from "src/app/main/body/shared/common";

export class ValueStreamTemplate {
  valueStreamTemplateID?: number
  valueStreamTemplateDisplayID?: number;
  valueStreamTemplateName?: string;
  isLocked?: boolean;
  modifiedAt?: Date;
  createdAt?: Date;
  delimiter?: string;
  isOperatedInShifts?: boolean;
  visualizationViewModeID?: number;
  valuestreamCategories?: ValueStreamCategory[];
  valueStreams?: ValueStream[];

  modifiedBy?: string;
  createdBy?: string;
  shifts?: Shift[];
  createdBy_NTID?: string;
  modifiedBy_NTID?: string;
  resultCode: number;
  isAccessible?: boolean;
}

export class ValueStreamCategory {
  valueStreamCategoryID?: number;
  valueStreamCategoryName: string;
  valueStreamTemplateID?: number;
  isDataRequired: boolean;
  inputType: string = "text";
  typeOfInput_InputTypeID?: string;
  isDataRequiredToFitSpecLength: boolean = true;
  minimumNoOfCharacters: number;
  maximumNoOfCharacters: number;
  valueStreams?: ValueStream[];
  nodeID?: number;
  isColumnRequired?: boolean;
}

  export class ValueStreamHistory {
    ValueStreamTemplateHistoryID ?:number;
    ValueStreamTemplateHistoryDisplayID ?:number;
    ValueStreamTemplateID ?:number;
    ValueStreamTemplateName ?:string;
    ModifiedBy_NTID ?:any;
    ModifiedBy ?:string;
    ModifiedAt : Date;
    CreatedAt : Date;
    Remarks?:string;
  }

export class ValueStream {
  valueStreamID?: number;
  responsible_UserID?: string;
  responsibleEmployee?: string;
  valueStreamTemplateID?: number;
  valueStreamCategoryID?: number;
  valueStreamData: string;
  valueStreamCategoryName?: string;
  indexID?: number;
  shifts?: Shift[];
  nodeID?: number;
  rowID?: number;
  user?: User;
  valueStreamTemplateName?: string;
  delimiter?: string;
  valueStreamName?: string;
  //valueStreamNames?: string[];
  id?: number; //for assigned valuestream in Question
  ParentId?: string;
  FormattedValueStream?: string;

}

export class multiVs{
  valuestreamid:number;
  valuestreamName:string;
}

export class Shift {
  shiftName?: string;
  shiftID?: number;
  weekList?: any[];
  fromTime: any = new Date();
  toTime: any = new Date();
  rowID?: number;
  isMonday?: boolean = true;
  isTuesday?: boolean = true;
  isWednesday?: boolean = true;
  isThursday?: boolean = true;
  isFriday?: boolean = true;
  isSaturday?: boolean = false;
  isSunday?: boolean = false;
  displayName?: string;
  user?: User[];
  valueStreamTemplateID?: number;
  rowPosition? : number = -1;
}

export class ValueStreamProxy {
  id?: number;
  valueStreamTemplateID?: number;
  proxies: User[];
  createdBy_NTID?: string;
  modifiedBy_NTID?: string;
  resultCode: number;
  ntid?: string;
  userName?: string;
  isLocked?:boolean;
}
