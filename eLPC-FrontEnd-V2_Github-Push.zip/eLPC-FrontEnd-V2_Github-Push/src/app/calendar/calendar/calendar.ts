import { Tag } from 'src/app/Tag/tag/tag';
//import { User } from '../shared/common';
import { User } from 'src/app/main/body/shared/common';
import { Deviation } from 'src/app/Deviation/deviation/deviation';
import { ValueStream } from 'src/app/Valuestream/valuestreams/valuestreamtemplate';
//import { Assessor } from '../assessors/assessortemplate';

export class Audit {
  auditID?: number;
  startDate: Date;
  endDate?: Date;
  isRecurring?: boolean;
  isAllDay?: boolean;
  valueStreamID?: number=0;
  valueStreamIDs?:any;
  //valueStreamIDs?: number[]=[];
  assignedTags?: Tag[];
  assignedValueStreams?: number[];
  RequiredAttendees?: User[];
  OptionalAttendees?: User[];
  remarks?: string;
  createdBy_UserID?: number;
  modifiedBy_UserID?: number;
  createdBy?: string;
  modifiedBy?: string;
  isDeleted?: boolean;
  modifiedAt?: Date;
  createdAt?: Date;
  tagName?: string;
  tagDisplayName?: string;
  tagID?: number;
  tagTypeID?: number;
  startTime: string;
  endTime: string;
  sDate: string;
  eDate: string;
  createdBy_NTID?: string;
  modifiedBy_NTID?: string;
  location: string;
  valueStreamName: string;
  valueStreamNames:string[];
  ValueStreams?: ValueStream[];
  organizer: string;
  emailAddress: string;
  calendarUrl: string;
  languageCode: string;
  recurrence_TypeId: number;
  recurrence_Interval: number;
  recurrence_DayOfWeek: string;
  recurrence_DayOfMonth: number;
  recurrence_WeekOfMonth: number;
  recurrence_MonthOfYear: number;
  tagTypeName?: string;
  templateID?: number;
  answeredStatus?: string;
  assigned_ValueStreamCategoryID: any;
  valueStreamCategoryID: any;
  ValueStreamID: number;
  //assigned_ValueStreamCategoryID: any;
  isSearchableTag: number;
  isSkipQuestionDefined: number;
	isQuestionOverviewDefined: boolean;
	isProgressPercentageDefined: number;
	isResultOverviewDefined: number;
	isResumeTagDefined: number;
	isReportingEmailDefined: number;
  isMandatoryAssessorsDefined : number;
  anonymizeUserDataSettingID : number;
}

export class AuditStatus extends Audit
{
  auditID?: number;
  assessorName?: string;
  answerPercentage?: string;
  answerdQuestionCount? : number;
  unAnswerdQuestionCount? : number;
  answerStartDate?: Date;
  answerEndDate?: Date;
  requiredAttendeeStr?: string;
  optionalAttendeeStr?: string;
  createdBy_NTID?: string;
  Tag?:string;
}

export class AuditDetail {
  auditID?: number;
  auditDetailID?: number;
  valueStreamID?: number;
  leadAuditor?: User;
  hod?: User;
  floorManager?: User;
  qmm?: User;
  createdAt?: Date;
  modifiedAt?: Date;
  createdBy_UserID?: number;
  modifiedBy_UserID?: number;
  others?: User[];
}

export class TagDetails {
 questionID?: number;
 responseType: string;
}

export class AuditQuestion {
  // valueStreamName(arg0: string, valueStreamName: any) {
  //   throw new Error('Method not implemented.');
  // }
  auditTemplateID?: number;
  id?: number;
  auditID?: number;
  questionID?: number;
  questionDisplayID?: number;
  questionText?: string;
  answer?: string;
  choiceAnswer?: string;
  answerTypeID?: number;
  isAnswered?: boolean;
  createdBy_NTID?: string;
  modifiedBy_NTID?: string;
  isAnswerRequired?: string;
  createdAt?: Date;
  modifiedAt?: Date;
  auditAssessors?: AuditAssessor[];
  others?: AuditAssessor[];
  modifiedBy?: string;
  valueStreamName: string;
  valueStreamID?: number;
  ValueStreamIDs: number[];
  questionHintText?: string;
  isDefaultAnswerRequired: boolean = false;
  defaultChoiceID: number = 0;
  answerType_AnswerTypeID?: number;
  tagTemplateID?: number;
  tagID?: number;
  deviationID?: number;
  deviation?: Deviation;
  //assessorID?: number;
  //assessorName?: string;
  //valueStreamID: number;
}

export class AuditHintData {
  QuestionHintText: string = '';
  HyperLinkURLs?: any = [];
  ImageURLs?: any = [];
  TitleList?: any = [];
  DisplayList?: any = [];
}

export class AuditAssessor {
  auditAssessorID?: number;
  auditID?: number;
  assessorName?: string;
  isMandatoryAssessor?: boolean;
  userName?: string;
  emailAddress: string;
  ntid?: string;
  displayname:string;
}

export enum RecurrencePattern {
  Daily_NDays = 11,
  Weekly_XDayofWeek = 21,
  Monthly_DayOfMonth = 31,
  Monthly_Nth_DayOfMonth = 32,
  Monthly_Nth_WeekDayOfMonth = 33,
  Monthly_Nth_WeekendDayOfMonth = 34,
  Monthly_Nth_XDayOfMonth = 35,
  Yearly_DayOfMonth = 41,
  Yearly_Nth_DayOfMonth = 42,
  Yearly_Nth_WeekDayOfMonth = 43,
  Yearly_Nth_WeekendDayOfMonth = 44,
  Yearly_Nth_XDayOfMonth = 45
}
export class DayOfWeek {
  Sunday: boolean;
  Monday: boolean;
  Tuesday: boolean;
  Wednesday: boolean;
  Thursday: boolean;
  Friday: boolean;
  Saturday: boolean;
  constructor(Sun = false, Mon= false, Tue= false, Wed= false, Thu= false, Fri= false, Sat= false) {
    this.Sunday = Sun;
    this.Monday = Mon;
    this.Tuesday = Tue;
    this.Wednesday = Wed;
    this.Thursday = Thu;
    this.Friday = Fri;
    this.Saturday = Sat;
  }
}
