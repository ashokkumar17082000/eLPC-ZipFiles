import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CalendarComponent } from './calendar/calendar.component';
import { CalendarRoutingModule } from './calendar-routing.module';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';
import { CalendarModule as AngularCalendarModule, DateAdapter } from 'angular-calendar';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { NgxPaginationModule } from 'ngx-pagination';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { OrderModule } from 'ngx-order-pipe';
import { DatePipe } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared/shared.module'
import { TimepickerModule } from 'ngx-bootstrap/timepicker';
import { SafeHtmlPipe } from '../service/common/safeHtml.pipe';
import { MyFilterPipe } from '../my-filter.pipe';
import { Audit, DayOfWeek, RecurrencePattern } from './calendar/calendar';
import {
  CalendarEventAction,
  CalendarEventTimesChangedEvent,
  CalendarView,
  CalendarEvent,
  CalendarMonthViewBeforeRenderEvent,
  CalendarWeekViewBeforeRenderEvent,
  CalendarDayViewBeforeRenderEvent
} from 'angular-calendar';
import {
  startOfDay,
  endOfDay,
  subDays,
  addDays,
  endOfMonth,
  isSameDay,
  isSameMonth,
  addHours
} from 'date-fns';
@NgModule({
  declarations: [CalendarComponent],
  imports: [
    CommonModule,
    CalendarRoutingModule,
   // MyFilterPipe,
    PopoverModule.forRoot(),
    BsDatepickerModule.forRoot(),
    TimepickerModule.forRoot(),
    NgMultiSelectDropDownModule.forRoot(),
    AngularCalendarModule.forRoot({
      provide: DateAdapter,
      useFactory: adapterFactory,
    }),
    FormsModule,
    FormsModule,
    ReactiveFormsModule,
    OrderModule,
    SharedModule,
    NgxPaginationModule
  ],
  providers: [
    DatePipe,  ],
  exports: [CalendarComponent], 
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class CustomCalendarModule { } // Renamed to avoid conflict
