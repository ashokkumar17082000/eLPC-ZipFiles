import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CanActivateChild, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { ErrorComponent } from './error/error.component';
//import { CheckAuthComponent } from './Authentication/checkauth/check-auth/check-auth.component';
import { CheckAuthComponent } from './check-auth/check-auth.component';
import { MainComponent } from './main/main.component';
//import { DashboardComponent } from './main/body/dashboard/dashboard.component';
//import { CalendarComponent } from './main/body/calendar/calendar.component';
//import { RoleComponent } from './main/body/role/role.component';
//import { UserComponent } from './main/body/user/user.component';
//import { AssessorsComponent } from './main/body/assessors/assessors.component';
//import { QuestionsComponent } from './main/body/questions/questions.component';
//import { DataPoolComponent } from './main/body/data-pool/data-pool.component';
//import { RecycleBinComponent } from 'src/app/RecycleBin/recycle-bin/recycle-bin.component';
//import { TagListComponent } from './main/body/tag/tag-list/tag-list.component';
//import { TagEditComponent } from './main/body/tag/tag-edit/tag-edit.component';
//import { UserEditComponent } from './main/body/user/user.addedit.component';
//import { AddEditRoleComponent } from './main/body/role/role.addedit.component';
//import { ProcessConfirmationComponent } from './main/body/process-confirmation/process-confirmation.component';
//import { CustomModeComponent } from './main/body/custom-mode/custom-mode.component';
//import { ShuffleModeComponent } from './main/body/shuffle-mode/shuffle-mode.component';
//import { AuditComponent } from './main/body/audit/audit.component';
//import { ValueStreamsComponent } from './main/body/value-streams/value-streams.component';
//import { TagLockComponent } from './main/body/tag/tag-edit/tag.lock.component';
//import { AssessorEditComponent } from './main/body/assessors/assessors.edit.component';
//import { AssessorLockComponent } from './main/body/assessors/assessor.lock.component';
import { CanActivateGuard } from './service/auth.guard.service';
import { CanActivateUser } from './service/authguard.standarduser.service';
//import { TagModeComponent } from './main/body/tag-mode/tag-mode.component';

//import { DataPoolEditComponent } from './main/body/data-pool/data-pool-edit.component';
//import { QuestionLockComponent } from './main/body/questions/questions.lock.component';
import { environment } from 'src/environments/environment';
import { TestComponent } from './test/test.component';
//import { AdminreportComponent } from './main/body/reports/adminreport/adminreport.component';
//import { UserreportComponent } from './main/body/reports/userreport/userreport.component';

import { PlantComponent } from './main/body/plant/plant.component';
//import { SuperOPLComponent } from './main/body/super-opl/super-opl.component';
import { AuthErrorComponent } from './auth-error/auth-error.component';
import { MyModalComponentComponent } from './my-modal-component/my-modal-component.component';
//import { AuthErrorComponent } from './autherrormodule/auth-error/auth-error.component';
//import { DeviationDataPoolComponent } from './main/body/deviation-data-pool/deviation-data-pool.component';
//import { UserProfileComponent } from './main/body/user-profile/user-profile.component';
//import { InfoAndHelpComponent } from './main/body/info-and-help/info-and-help.component';
//import { PowerBIExportComponent } from './main/body/powerbi-export/powerbi-export.component';
//import { CalenderListComponent } from './main/body/calender-list/calender-list.component';
//import { MergeComponent } from './main/body/merge/merge.component';
//import { LaunchpadComponent } from './main/body/reports/launchpad/launchpad.component';
//import { LaunchpadsettingsComponent } from './main/body/reports/launchpadsettings/launchpadsettings.component';

// import { DeviationComponent } from './main/body/deviation/deviation.component';

const routes: Routes = [
  { path: 'my-modal', component: MyModalComponentComponent },
  { path: 'appinfo', component: AuthErrorComponent, pathMatch: 'full'},
  { path: ':plant', component: CheckAuthComponent, pathMatch: 'full' },
  { path: '', component: CheckAuthComponent, pathMatch: 'full' },
  { path: 'test', component: TestComponent, pathMatch: 'full' },
  { path: 'plant', component: PlantComponent, pathMatch: 'full' },
  {
    // path: environment.home, component: MainComponent, canActivate:[CanActivateUser], children:
    path: ':plant', component: MainComponent, canActivate:[CanActivateUser], children:
      [
        {path: 'dashboard', loadChildren: () => import('./dashboard-elpc/dashboard-elpc.module').then(m => m.DashboardElpcModule) ,canActivateChild:[CanActivateUser]},
        //{ path: 'dashboard', component: DashboardComponent,canActivateChild:[CanActivateUser]  },
        // { path: 'role', component: RoleComponent,canActivateChild:[CanActivateUser] },
        // { path: 'role-edit', component: AddEditRoleComponent,canActivateChild:[CanActivateUser] },
        // { path: 'user', component: UserComponent,canActivateChild:[CanActivateUser] },
        // { path: 'user-edit', component: UserEditComponent,canActivateChild:[CanActivateUser] },
      //{ path: 'valuestreams', component: ValueStreamsComponent,canActivateChild:[CanActivateGuard] },
       {path: 'valuestreams', loadChildren: () => import('./Valuestream/valuesream-r/valuesream-r.module').then(m => m.ValuesreamRModule),canActivateChild:[CanActivateUser] },
       // { path: 'valuestreams-edit', component: ValueStreamsEditComponent ,canActivateChild:[CanActivateGuard]},
       {path: 'valuestreams-edit', loadChildren: () => import('./Valuestream/valuesream-r/valuesream-r.module').then(m => m.ValuesreamRModule),canActivateChild:[CanActivateUser] },
       // { path: 'valuestreams-lock', component: ValueStreamsLockComponent ,canActivateChild:[CanActivateGuard]},
        {path: 'valuestreams-lock', loadChildren: () => import('./Valuestream/valuesream-r/valuesream-r.module').then(m => m.ValuesreamRModule),canActivateChild:[CanActivateUser] },
        //{ path: 'assessors', component: AssessorsComponent,canActivateChild:[CanActivateGuard] },
        {path: 'assessors', loadChildren: () => import('./Assessor/assessor-r/assessor-r.module').then(m => m.AssessorRModule),canActivateChild:[CanActivateGuard] },
        //{ path: 'assessor-edit', component: AssessorEditComponent,canActivateChild:[CanActivateGuard] },
        {path: 'assessor-edit', loadChildren: () => import('./Assessor/assessor-r/assessor-r.module').then(m => m.AssessorRModule),canActivateChild:[CanActivateGuard] },
       // { path: 'assessor-lock', component: AssessorLockComponent,canActivateChild:[CanActivateGuard] },
        {path: 'assessor-lock', loadChildren: () => import('./Assessor/assessor-r/assessor-r.module').then(m => m.AssessorRModule),canActivateChild:[CanActivateGuard]},
        {path: 'questions', loadChildren: () => import('./Datapool/QuestionModule/question-dp/question-dp.module').then(m => m.QuestionDPModule), canActivateChild:[CanActivateGuard]},
       // { path: 'questions', component: QuestionsComponent,canActivateChild:[CanActivateGuard] },
       {path: 'question-lock', loadChildren: () => import('./Datapool/QuestionModule/question-dp/question-dp.module').then(m => m.QuestionDPModule),canActivateChild:[CanActivateGuard] },
        //{ path: 'question-lock', component: QuestionLockComponent,canActivateChild:[CanActivateGuard] },
       // { path: 'taglist', component: TagListComponent,canActivateChild:[CanActivateGuard] },
        {path: 'taglist', loadChildren: () => import('./Tag/tag-r/tag-r.module').then(m => m.TagRModule),canActivateChild:[CanActivateGuard] },
        //{ path: 'tag-edit', component: TagEditComponent,canActivateChild:[CanActivateGuard] },
        {path: 'tag-edit', loadChildren: () => import('./Tag/tag-r/tag-r.module').then(m => m.TagRModule),canActivateChild:[CanActivateGuard] },
       // { path: 'tag-lock', component: TagLockComponent,canActivateChild:[CanActivateGuard] },
        {path: 'tag-lock', loadChildren: () => import('./Tag/tag-r/tag-r.module').then(m => m.TagRModule),canActivateChild:[CanActivateGuard] },
        {path: 'datapool', loadChildren: () => import('./Datapool/QuestionModule/question-dp/question-dp.module').then(m => m.QuestionDPModule), canActivateChild:[CanActivateGuard]},
      //  { path: 'datapool', component: DataPoolComponent,canActivateChild:[CanActivateGuard] },
       // { path: 'recyclebin', component: RecycleBinComponent,canActivateChild:[CanActivateGuard] },
        {path: 'recyclebin', loadChildren: () => import('./RecycleBin/recyclebin-r/recyclebin-r.module').then(m => m.RecyclebinRModule),canActivateChild:[CanActivateGuard] },
       // { path: 'calendar', component: CalendarComponent,canActivateChild:[CanActivateUser] },
       {path: 'calendar', loadChildren: () => import('./calendar/calendar.module').then(m => m.CustomCalendarModule),canActivateChild:[CanActivateGuard] },
       // { path: 'processConfirmation', component: ProcessConfirmationComponent,canActivateChild:[CanActivateUser] },
       
       {path: 'processConfirmation', loadChildren: () => import('./pc/pc.module').then(m => m.PCModule), canActivateChild:[CanActivateGuard]},
         // { path: 'dataPool-edit', component: DataPoolEditComponent,canActivateChild:[CanActivateGuard] },
        {path: 'dataPool-edit', loadChildren: () => import('./Datapool/QuestionModule/question-dp/question-dp.module').then(m => m.QuestionDPModule),canActivateChild:[CanActivateGuard] },
        //{ path: 'customMode', component: CustomModeComponent,canActivateChild:[CanActivateUser] },
        {path: 'customMode', loadChildren: () => import('./custommode/custommode.module').then(m => m.CustommodeModule),canActivateChild:[CanActivateGuard] },
        //{ path: 'shufflemode', component: ShuffleModeComponent, canActivateChild: [CanActivateUser] },
        //{ path: 'tagMode', component: TagModeComponent, canActivateChild: [CanActivateUser] },
        {path: 'tagMode', loadChildren: () => import('./ProcessConfirmation/process-confirmationmode/process-confirmationmode.module').then(m => m.ProcessConfirmationmodeModule,), canActivateChild:[CanActivateGuard]},
       // { path: 'deviation', component: DeviationComponent, canActivateChild: [CanActivateUser] },
        //{ path: 'tagMode', component: TagModeComponent, canActivateChild: [CanActivateUser] },
       // { path: 'deviation', component: DeviationComponent, canActivateChild: [CanActivateUser] },
       {path: 'deviation', loadChildren: () => import('./Deviation/deviation-r/deviation-r.module').then(m => m.DeviationRModule),canActivateChild:[CanActivateUser] },
        //{ path: 'audit', component: AuditComponent,canActivateChild:[CanActivateUser] },
        {path: 'audit', loadChildren: () => import('./audit/audit.module').then(m => m.AuditModule),canActivateChild:[CanActivateGuard] },
        { path: '', redirectTo: environment.home +'/dashboard', pathMatch: 'full' },
        //{ path: 'adminReport', component: AdminreportComponent,canActivateChild:[CanActivateUser]  },
        {path: 'adminReport', loadChildren: () => import('./Report/report.module').then(m => m.ReportModule), canActivateChild:[CanActivateGuard]},
        //{ path: 'userReport', component: UserreportComponent,canActivateChild:[CanActivateGuard]  },
        //{ path: 'superOPL', component: SuperOPLComponent, canActivateChild: [CanActivateUser] },
        {path: 'superOPL', loadChildren: () => import('./Report/report.module').then(m => m.ReportModule), canActivateChild:[CanActivateGuard]},
        //{ path: 'deviationpool', component: DeviationDataPoolComponent, canActivateChild: [CanActivateGuard] },
        {path: 'deviationpool', loadChildren: () => import('./Datapool/DeviationModule/deviation-dp/deviation-dp.module').then(m => m.DeviationDPModule),canActivateChild:[CanActivateGuard] },
       // { path: 'userProfile', component: UserProfileComponent,canActivateChild:[CanActivateUser]  },
        {path: 'userProfile', loadChildren: () => import('./UserProfile/userprofile-r/userprofile-r.module').then(m => m.UserprofileRModule),canActivateChild:[CanActivateGuard] },
        //{ path: 'infoAndHelp', component:InfoAndHelpComponent, canActivateChild:[CanActivateUser]},
        {path: 'infoAndHelp', loadChildren: () => import('./app-info-and-help/app-info-and-help.module').then(m => m.AppInfoAndHelpModule), canActivateChild:[CanActivateGuard]},
       //{ path: 'powerBIExport', component:PowerBIExportComponent, canActivateChild:[CanActivateUser]},
       {path: 'powerBIExport', loadChildren: () => import('./Report/report.module').then(m => m.ReportModule),canActivateChild:[CanActivateGuard] }, 
       // { path: 'calendarListing', component: CalenderListComponent, canActivateChild: [CanActivateUser] },
       {path: 'calendarListing', loadChildren: () => import('./Datapool/Calendar-dpModule/calendar-dp/calendar-dp.module').then(m => m.CalendarDPModule), canActivateChild:[CanActivateGuard]}, 
       //{ path: 'merge', component: MergeComponent, canActivateChild: [CanActivateUser] },
       {path: 'merge', loadChildren: () => import('./Merge/merge-r/merge-r.module').then(m => m.MergeRModule),canActivateChild:[CanActivateGuard] },
      //{ path: 'launchpad', component: LaunchpadComponent, canActivateChild: [CanActivateUser] },
     {path: 'launchpad', loadChildren: () => import('./Report/launch-pad-r/launch-pad-r.module').then(m =>m.LaunchPadRModule), canActivateChild:[CanActivateGuard]},
      //  { path: 'launchpadsettings', component: LaunchpadsettingsComponent, canActivateChild: [CanActivateUser] },
       {path: 'launchpadsettings', loadChildren: () => import('./Report/launch-pad-r/launch-pad-r.module').then(m =>m.LaunchPadRModule), canActivateChild:[CanActivateGuard]},

      ]

  },
  //{ path: environment.home +'/'+environment.home +'/appinfo', component: AuthErrorComponent, pathMatch: 'full' },
  //{ path: ':plant' +'/appinfo', component: AuthErrorComponent, pathMatch: 'full' },
  { path: ':plant' +'/appinfo', component: AuthErrorComponent, pathMatch: 'full' },
  //{path: 'appinfo', loadChildren: () => import('./autherrormodule/autherrormodule.module').then(m => m.AutherrormoduleModule),canActivateChild:[CanActivateGuard] },
  { path: '**', component: ErrorComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: false, enableTracing: false })],  
  exports: [RouterModule]
})
export class AppRoutingModule { }

