import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserprofileCComponent } from 'src/app/UserProfile/userprofile-c/userprofile-c.component';

const routes: Routes = [
  { path: '', component: UserprofileCComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserprofileRRoutingModule { }
