import { Component, OnInit } from '@angular/core';
import { DataPoolService } from 'src/app/service/data-pool.service';
import { environment } from 'src/environments/environment';
import { LanguageService } from '../../language.service';
import { SharedService } from 'src/app/service/shared.service';

@Component({
  selector: 'app-powerbi-export',
  templateUrl: './powerbi-export.component.html',
  styleUrls: ['./powerbi-export.component.css']
})
export class PowerBIExportComponent implements OnInit {
  labels: any;
  _subscription: any;
  sharedPlantiD: any;
  
  constructor(private dataPoolService : DataPoolService, private local_label: LanguageService,private sharedService: SharedService,) {

    this.labels = local_label.localizeLanguage;
    this._subscription = local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
    });

   }

  ngOnInit() {
    this.sharedPlantiD = this.sharedService.plantID;
    console.log(this.sharedService)
  }

  public ExportExcelUserReport(){
    this.dataPoolService.GetExcelFile("UserReport");
  }

  public ExportExcelPlantReport(){
    this.dataPoolService.GetExcelFile("PlantReport");
  }
  public ExportExcelPlantReport1(){
    this.dataPoolService.GetExcelFile("PlantReportOneYear",true);
  }

  public ExportPowerBIDesigner(){
   
    window.open(environment.powerBISharePointURL, "_blank");
  }
}

