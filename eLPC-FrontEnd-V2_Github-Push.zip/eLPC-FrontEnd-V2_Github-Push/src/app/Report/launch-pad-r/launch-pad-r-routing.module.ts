import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LaunchPadCComponent } from '../launch-pad-c/launch-pad-c.component';
import { LaunchPadSettingsCComponent } from '../launch-pad-c/launch-pad-settings-c.component';

const routes: Routes = [
  { path: '', component: LaunchPadCComponent },
  { path: 'launchpadsettings', component: LaunchPadSettingsCComponent },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LaunchPadRRoutingModule { }
