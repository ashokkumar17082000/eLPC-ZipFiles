import { Component, OnInit } from '@angular/core';
import {BrowserModule, DomSanitizer} from '@angular/platform-browser'
import { environment } from '../../../environments/environment';
import { Router } from '@angular/router';
import { SharedService } from 'src/app/service/shared.service';

@Component({
  selector: 'app-adminreport',
  //template: '<iframe [src]="iframe" width="100%" height="800px"></iframe>',
  templateUrl: './adminreport.component.html',
  styleUrls: ['./adminreport.component.css']
})
export class AdminreportComponent implements OnInit {

  iframe : any;
  urlSrc :any;

  constructor(private sanitizer: DomSanitizer, private sharedService: SharedService, private router: Router) {
    this.urlSrc = environment.powerBIURL 
                  + "&filter=Translation/LanguageCode eq '" + this.sharedService.selectedLanguage 
                  + "' and PlantIDkey/PlantID eq " + this.sharedService.plantID.toString();
    //console.log("22",this.iframe)
    this.iframe = sanitizer.bypassSecurityTrustResourceUrl(this.urlSrc);
  }

  ngOnInit() {
    this.sharedService.hide();
    // if(this.sharedService.role !=="Designer")
    // {
    //   this.router.navigate([environment.home +'/accessdenied']);
    // }
  }

}
