import { NgModule ,CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminreportComponent } from './adminreport/adminreport.component';
import { PowerBIExportComponent } from './powerbi-export/powerbi-export.component';
import { ReportRoutingModule } from './report-routing.module';
import { SuperOPLComponent } from './super-opl/super-opl.component';

@NgModule({
  declarations: [AdminreportComponent,PowerBIExportComponent,SuperOPLComponent],
  imports: [
    CommonModule,
    ReportRoutingModule,
    
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class ReportModule { }
