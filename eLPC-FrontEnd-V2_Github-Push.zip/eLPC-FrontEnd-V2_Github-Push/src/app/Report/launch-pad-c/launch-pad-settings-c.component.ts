//import { Component, OnInit } from '@angular/core';
import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { Assessor, AssessorStreamHistory, AssessorTemplate } from 'src/app/Assessor/assessor/assessortemplate';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { environment } from 'src/environments/environment';
import { LanguageService } from 'src/app/language.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AssessorTemplateService } from 'src/app/service/assessor/assessortemplate.service';
import { SharedService } from 'src/app/service/shared.service';
import { reportText, reportrestore, reports } from './launchpadsetting';
import { LaunchpadsettingService } from 'src/app/service/launchpadsetting.service';


@Component({
  selector: 'app-launch-pad-c',
  templateUrl:'./launch-pad-settings-c.component.html',
  styleUrls: ['./launch-pad-settings-c.component.css']
})
export class LaunchPadSettingsCComponent implements OnInit {

  @ViewChild('fileInput') fileInput;
  @ViewChild('alertPopup') warningModal : TemplateRef<any>;
  @ViewChild('successPopup') successModal : TemplateRef<any>;
  isDisabled:boolean=true;
  alertText: string;
  apiUrl: any;
  assessorTemplateList: AssessorTemplate[] = [];

  filterPopUp: any;
 
  assessorTemplate: AssessorTemplate = new AssessorTemplate();
  reportText: reportText = new reportText();
  reportTextList: reportText[] = [];
  restoredata:reportrestore[]=[];
  reports: reports[] = [];
  isAdd: boolean = false;
  isEdit: boolean = false;
  isTargetFrequencyDefined: boolean = false;
  assessors: Assessor[] = [];
  restorereport:Assessor[]=[];
  historyId:any;
  assessor: Assessor;
  dataTable: any;
  modalRef: BsModalRef | null;
  assessorStreamHistoryDetails: AssessorStreamHistory[];
  assessorTemplateHistoryID: number;
  templateId: number;
  dateTimeFormat = environment.dateTimeFormat;

  config = {
    animated: false,
    keyboard: true,
    ignoreBackdropClick: true
  };
  @ViewChild('answerOverView1') public answerOverViewModal1: TemplateRef<any>;  

  constructor(private local_label: LanguageService ,route: ActivatedRoute, private modalService: BsModalService, private LaunchpadsettingService: LaunchpadsettingService, private sharedService: SharedService, private router: Router) {

   
    if (this.assessorTemplate == undefined) {
      this.isAdd = true;
      this.isEdit = false;
      this.assessorTemplate = new AssessorTemplate();
    }
    else if (Object.keys(this.assessorTemplate).length == 0) {
      this.isAdd = true;
      this.isEdit = false;
      this.assessorTemplate = new AssessorTemplate();
    }
    else {
      this.isAdd = false;
      this.isEdit = true;
    }

    if (this.isEdit) {
      this.templateId = this.assessorTemplate.assessorTemplateID;
      //this.editAsessor(this.assessorTemplate);
    }

  }

  labels: any;
  _subscription: any;


  ngOnInit() {
    if(this.sharedService.role !=="Designer")
    {
      this.router.navigate([environment.home +'/accessdenied']);
    }

    this.getLaunchpadSettingList();
    this.getrestoredata();


    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
    });
    

    //this.assessors = [{ assessorName: "",category: "", targetFrequencyLowLimit: "", targetFrequencyValue: undefined }];
   
  }



  redirect() {
    this.isEdit = false;
    this.isAdd = false;
    this.assessorTemplate = new AssessorTemplate();
    this.assessors = [{ assessorName: "",category: "", targetFrequencyLowLimit: "", targetFrequencyValue: undefined }];
    this.router.navigate([environment.home +'/launchpad']);
    //this.router.navigate([environment.home +'/launchpad/launchpadsettings']);
  }
    //to fix scroll issue after pop up

  // public getAssessorTemplateList() {
  //   this.assessorTemplateService.getAssessorTemplates().subscribe(res => {
  //     this.assessorTemplateList = res;     
  //   },
  //     err => {
  //       console.log(err);
  //     }
  //   );
  // }

  public getLaunchpadSettingList() {
    this.LaunchpadsettingService.getLaunchpadSetting().subscribe(res => {
      this.reportTextList = res;   
      console.log("125",this.reportTextList)
      if(this.reportTextList.length) {    

        for(let each of this.reportTextList) {
          ////debugger
          let assess={
            assessorName:"",
            category: "", 
            CreatedBy:"",
            targetFrequencyLowLimit: "", 
            targetFrequencyValue: undefined,
          //   historyId:undefined,
          //  CreatedAt:undefined,
           }
          assess.assessorName=each.reportTextName;
          assess.category=each.reportTextURL;
          assess.CreatedBy=each.createdBy;
          //assess.CreatedAt=each.createdAt;
         //assess.historyId=each.historyId;
          this.assessors.push(assess);
          console.log("139assessors",this.assessors)
        }
      }else {
        this.assessors = [{ assessorName: "",category: "", targetFrequencyLowLimit: "", targetFrequencyValue: undefined }];
      }
      this.addAssessorRow(this.reportTextList.length -1);
    },
      err => {
        console.log(err);
      }
    );
  }
  public getrestoredata() {
    this.LaunchpadsettingService.getrestoredata().subscribe(res => {
      this.restoredata = res;   
      console.log("restoredata",this.restoredata)
      if(this.restoredata.length) {    

        for(let each of this.restoredata) {
          ////debugger
          let restdata={
            assessorName:"",
            category: "", 
            createdBy:"",
            targetFrequencyLowLimit: "", 
            targetFrequencyValue: undefined,
            historyId:0,
           createdAt:undefined,
           }
          restdata.assessorName=each.reportTextName;
          restdata.category=each.reportTextURL;
          restdata.createdBy=each.createdBy;
          restdata.createdAt=each.createdAt;
          restdata.historyId=each.historyId;
          this.restorereport.push(restdata);
          console.log("139assessors",this.restorereport)
        }
      }else {
        this.restorereport = [{ assessorName: "",category: "", targetFrequencyLowLimit: "", targetFrequencyValue: undefined }];
      }
      this.addAssessorRow(this.restoredata.length -1);
    },
      err => {
        console.log(err);
      }
    );
  }
  goToLink(url: string) {
    console.log("132",url)
    if (url.toLocaleLowerCase().includes('https://') || url.toLocaleLowerCase().includes('http://')) {
      window.open(url, "_blank");
    }
    else {
      window.open('//' + url, "_blank");
    }
  }
  openLaunchHistory(LaunchHistory: TemplateRef<any>) {
    this.modalRef = this.modalService.show(LaunchHistory, this.config);
    this.modalRef.setClass('modal-lg');
    $('.isRestoreDisabled').prop('disabled', true);

    setTimeout(function () {
      $("#valueHistory tbody tr").click(function () {
        $(".selected").removeClass('selected');
        $(this).addClass('selected');
        $('.isRestoreDisabled').prop('disabled', false);
      });
    }, 100);
  }
  restoreVersion() {
    this.historyId= $("#valueHistory tbody tr.selected td:first").html();
    this.LaunchpadsettingService.LaunchPadrestore(this.historyId).subscribe(res => {
//debugger;
      if (res) {
        this.closeAlertModal();
        // this.alertText = this.labels.default.restoreSuccessfully;
        // this.modalService.show(this.successModal);
        // $("modal-container").removeClass("fade");
        // $(".modal-dialog").addClass("modalSize");
       this.router.navigate(['../' + environment.home + '/launchpad']);
      }
      else {
        this.closeAlertModal();
        this.alertText = this.labels.default.restoreFailed;
        this.modalService.show(this.successModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
      }
    },
      (err) => {
        alert(err.message);
        this.closeAlertModal();
      });
  }

  editAsessor(assessorTemplate: any) {
      this.isAdd = false;
      this.isEdit = true;
      this.assessors = [];
      this.assessorTemplate = Object.assign(new AssessorTemplate(), assessorTemplate);

      // this.assessorTemplateService.getAssessorsByTemplateID(this.assessorTemplate.assessorTemplateID).subscribe(
      //   res => {
      //     this.assessors = res;
      //     this.addAssessorRow(this.assessors.length -1);
      //   },
      //   err => {
      //     console.log(err);
      //   }
      // );
    

  }

  showModal()
  {
    document.getElementById('deleteModal').style.display = "block";
  }

  closeModal()
  {
    document.getElementById('deleteModal').style.display = "none"; 
    document.querySelector('body').classList.remove('-is-modal');
  }

  deleteTemplate()
  {
    this.closeModal();
    console.log("182",this.assessorTemplate)
    this.delete(this.assessorTemplate);
  }

  delete(assessorTemplate: any) {
    if(this.sharedService.ntid){
      this.assessorTemplate.modifiedBy_NTID = this.sharedService.ntid;
      var d = new Date();
      this.assessorTemplate.modifiedAt = new Date(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate(),d.getHours(),d.getMinutes(),d.getSeconds()));
    }
    // this.assessorTemplateService.deleteAssessorTemplate(this.assessorTemplate).subscribe(
    //   res => {
    //     if (res.resultCode == 0) {

    //       this.getAssessorTemplateList();
    //       this.alertText = this.labels.default.deleteSuccessfully;
    //       this.modalService.show(this.successModal);
    //       $("modal-container").removeClass("fade");
    //       $(".modal-dialog").addClass("modalSize");
          
    //       this.assessors = [];
    //       this.isAdd = false;
    //       this.isEdit = false;
    //       this.router.navigate([environment.home +'/assessors']);
    //     }
    //     else if(res.resultCode == 1){
    //       this.alertText = this.labels.default.assessorLinked;
    //       this.modalService.show(this.warningModal);
    //       $("modal-container").removeClass("fade");
    //       $(".modal-dialog").addClass("modalSize");
    //     }
    //     else {
    //       this.alertText = this.labels.default.failedDeleteAssessor;
    //       this.modalService.show(this.warningModal);
    //       $("modal-container").removeClass("fade");
    //       $(".modal-dialog").addClass("modalSize");
    //     }
    //   },
    //   err => {
    //     console.log(err);
    //   });
  }

  assessorObj: AssessorTemplate = new AssessorTemplate();

  onSubmitlaunchpad(reportText :any)
  {
    //debugger
    console.log ("Enter" , reportText);

    reportText.createdAt = new Date();


    this.assessors.forEach((item, index) => {
      if(index != this.assessors.length-1){
        if(item.assessorName == undefined || item.assessorName == ''  ||  item.targetFrequencyTypeID == undefined || item.targetFrequencyValue == undefined){
    
          reportText.reportText=item.assessorName;
          reportText.reportTextURL=item.category;
        }
      }

      this.reportText.reports = this.assessors.filter(x => x.assessorName != undefined ,y => y.category != undefined );

      console.log ("Enter" , reportText);
    });

    console.log ("Enter" , reportText);
    let flag=0
    for(let each of reportText.reports) {
      console.log("263",each)
      if(each.assessorName=="" || each.assessorName==undefined || each.category =="" || each.category ==undefined) {
        flag=1;
        break
      }
    }
    console.log("270",flag)
    if(flag==0) {
    this.LaunchpadsettingService.insertLaunchpadURL(this.reportText).subscribe(
      res => {
       // alert(274)
        console.log(res)
        if (res.resultCode >0) {

  
          this.alertText = this.labels.default.saveSuccessfully;
          // this.modalService.show(this.successModal);
          // $("modal-container").removeClass("fade");
          // $(".modal-dialog").addClass("modalSize");
          this.assessors = [];
          this.isAdd = false;
          this.isEdit = false;
          this.router.navigate([environment.home +'/launchpad'])
        }
        else {
          this.alertText = this.labels.default.failedAssessor;
          // this.modalService.show(this.warningModal);
          // $("modal-container").removeClass("fade");
          // $(".modal-dialog").addClass("modalSize");
       this.isDisabled=false;

        }

      },
      err => {
        console.log(err);
      });
    }else {
      this.modalService.show(this.answerOverViewModal1, this.config);
      $("modal-container").removeClass("fade");
    }


  }
  closeAuditAlertModal() {
    if (document.getElementsByTagName("modal-container").length > 1) {
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1]);
    }
    else {
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if (document.getElementsByTagName("bs-modal-backdrop").length > 0) {
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }
  }
  letterOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;

    if ((charCode <= 93 && charCode >= 65) || (charCode <= 122 && charCode >= 97)) {
      return true;
    }
    return false;;


  }


  columnsData: Array<any> = [{ assessorCategoryName: 'Assessor', inputType: 'text', isDataRequiredToFitSpecLength: false, minimumNoOfCharacters: 1, maximumNoOfCharacters: 3, isDataRequired: true }]

  order: string = "displayName";
  reverse: boolean = false;
  setOrder(value: string) {
    if (this.order === value) {
      this.reverse = !this.reverse;
    }

    this.order = value
                  }

  idvalue = 0;
  myvalue = "";
  rows: any[] = [{

  }];
  // ************************************************
  //This function is called on keyup and checks the checkbox on that row and adds new row if the action was on the last row  
  checkAndAddRow(i) {
    this.idvalue++;
    this.myvalue = "first";

    if (this.rows.length - 1 == i) {//insert new empty row, incase this keyup event was on the last row, you might want to enhance this logic... 
      this.rows.push({
        key: '',
      })

    }
  }

  addAssessorRow(i) {
    if (this.assessors.length - 1 == i) {
      this.assessor = new Assessor();
      this.assessors.push(this.assessor);
    }
  }


  removeAssessor(index: number) {
    console.log("334",index,this.assessor)
    if (!this.assessors || this.assessors.length <= 1)
      return;
    this.assessors.splice(index, 1);
  }

  closeAlert()
  {
    if(document.getElementsByTagName("modal-container").length > 1){
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length-1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length-1]);
    }
    else{
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if(document.getElementsByTagName("bs-modal-backdrop").length > 0){
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }
  }

  public openAlertModal(popUp:any) {
    this.filterPopUp = popUp;
  }
  public closeAlertModal() {
    if (document.getElementsByTagName("modal-container").length > 1) {
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1]);
    }
    else {
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if (document.getElementsByTagName("bs-modal-backdrop").length > 0) {
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }
  }
  // public closeAlertModal() {
  //   this.filterPopUp.hide();

  // }
  

}
