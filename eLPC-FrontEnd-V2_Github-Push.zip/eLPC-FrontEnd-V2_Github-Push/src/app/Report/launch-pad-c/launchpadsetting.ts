export class reportText
{
  reportTextID : number;
  plantID:number;
  reportTextName: string;
  reportTextURL: string;
  reports : reports[];
  modifiedAt: Date;
  //createdAt: Date;
 // historyId:number;
  isTargetFrequencyDefined?: boolean;
  createdBy?: string;
  modifiedBy?: string;
  resultCode: number;
  createdBy_NTID?: string;
  modifiedBy_NTID?: string;
  isAccessible?: boolean;
}
export class reportrestore
{
  reportTextID : number;
  plantID:number;
  reportTextName: string;
  reportTextURL: string;
  reports : reports[];
  modifiedAt: Date;
  createdAt: Date;
  historyId:number;
  HistId:number;
  isTargetFrequencyDefined?: boolean;
  createdBy?: string;
  modifiedBy?: string;
  resultCode: number;
  createdBy_NTID?: string;
  modifiedBy_NTID?: string;
  isAccessible?: boolean;
}
export class reports {
    id?: number; //for assigned Assessors in questions table

    assessorName?: string;
    category?: string;
  }