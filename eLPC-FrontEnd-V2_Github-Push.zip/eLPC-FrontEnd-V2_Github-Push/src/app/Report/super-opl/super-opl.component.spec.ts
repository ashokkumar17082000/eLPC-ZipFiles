import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuperOPLComponent } from './super-opl.component';

describe('SuperOPLComponent', () => {
  let component: SuperOPLComponent;
  let fixture: ComponentFixture<SuperOPLComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SuperOPLComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuperOPLComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
