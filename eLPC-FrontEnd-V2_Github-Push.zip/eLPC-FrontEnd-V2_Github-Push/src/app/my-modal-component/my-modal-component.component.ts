import { Component, OnInit, TemplateRef,ViewChild  } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { SharedService } from '../service/shared.service';
//import { template } from '@angular/core/src/render3';
import { Router } from '@angular/router';
import { LanguageService } from '../language.service';
import { CommonService } from '../service/common/common.service';
import { ModalModule } from 'ngx-bootstrap/modal';
// import * as english from "../../assets/localize/eng.json";
import { User } from '../main/body/shared/common';

@Component({
  selector: 'app-my-modal-component',
  templateUrl: './my-modal-component.component.html',
  styleUrls: ['./my-modal-component.component.css']
})
export class MyModalComponentComponent implements OnInit {
  displayMessage: string;
  UserPlantDetails: any;
  originalPlantID : number;
  key: string = 'name';//for sorting
  reverse1: boolean = false;//for sorting
  headerFilterName:string="";//for filtering
  page: number = 1;
  resultPerPage: number = 5;
  startPage: number;
  endPage: number;
  defaultPlantID: any;
  defaultPlantName: string;
  slectedPlantDescription: string;
  isSetAsDefault: boolean = false;
  showPopup: boolean = true;

  modalRef: BsModalRef;
  @ViewChild('plantTemplate') plantTemplateModal: TemplateRef<any>;
  @ViewChild('alertPopup') warningModal : TemplateRef<any>;

  config = {
    animated: false,
    keyboard: true,
    ignoreBackdropClick: true
  };
  labels: any;
  private _subscription: any;
  alertText: any;
  showAlert: boolean;
  showDesc: boolean=false;
  isHovered: boolean=false;

  constructor(private router: Router, private commonService: CommonService, public sharedService:SharedService,private local_label:LanguageService, private modalService: BsModalService) {
    debugger;
    sharedService.hide();
    console.log("auth error")
    if (this.sharedService.sharedUserDetails != null && this.sharedService.sharedUserDetails.avaliablePlants != null && this.sharedService.sharedUserDetails.avaliablePlants.length > 0) {
      this.UserPlantDetails = JSON.parse(JSON.stringify(this.sharedService.sharedUserDetails.avaliablePlants));
    }

    // if(this.sharedService.showPlantSelectionPopup)
    // {
    //   console.log("55",this.plantTemplateModal)
    //   this.open(this.plantTemplateModal);

    // }
  }

  ngOnInit() {
    this.sharedService.hide();
    this.displayMessage = this.sharedService.errorMessage;

    // if (this.sharedService.showPlantSelectionPopup) {
    //   this.open(this.plantTemplateModal);
    // }
    this.updateLanguage("EN");
  }

  async updateLanguage(languageCode) {
     // Wait for language file to load before assigning labels
     this.local_label.changeLanguage(this.sharedService.selectedLanguage).then((data) => {
      this.labels = data;
      console.log("Loaded labels", this.labels);  // Ensure it's loaded
    }).catch((error) => {
      console.error('Language loading failed:', error);
    });
    //this.labels = await this.local_label.changeLanguage(languageCode);
  }


  open(template: TemplateRef<any>) {
    this.isSetAsDefault = false;
    let defaultPlant = JSON.parse(JSON.stringify(this.sharedService.sharedUserDetails.avaliablePlants)).filter(item => item.isDefault == true);
    if (defaultPlant.length > 0) {
      this.defaultPlantID = defaultPlant[0].plantID;
      this.defaultPlantName = defaultPlant[0].plantCode + '-' + defaultPlant[0].plantName;
    }

    this.modalRef = this.modalService.show(this.plantTemplateModal, this.config);
    this.modalRef.setClass('modal-lg calendar-modal');
  }

  onHover(state: boolean): void {
    console.log(state)
    this.isHovered = state;
  }

  enableButton(button: HTMLButtonElement): void {
    if (this.UserPlantDetails.length > 0) {
      button.disabled = false;
    }
  }

  disableButton(button: HTMLButtonElement): void {
    if (this.UserPlantDetails.length == 0) {
      button.disabled = true;
    }
  }
  onPlantDescriptionChange(plantID: Number) {   
    this.showDesc=true; 
    this.slectedPlantDescription = "";
    let selectedPlant = this.UserPlantDetails.filter(item => item.plantID == plantID);
    if (selectedPlant.length > 0) {
      this.slectedPlantDescription = selectedPlant[0].generalMessage;
    }
  }

  onPlantSelectionChange(plantID: Number) {
    //alert(1)
    this.showAlert=false;
    this.UserPlantDetails.forEach(item => {
      item.isDefault = false;
      if (item.plantID == plantID) {
        item.isDefault = true;
      }
    });
  }

  doFilter = (value: string) => {
    this.UserPlantDetails = JSON.parse(JSON.stringify(this.sharedService.sharedUserDetails.avaliablePlants));

    if (value.length > 0) {
      this.UserPlantDetails = this.UserPlantDetails.filter(x =>
        x.plantCode.trim().toLowerCase().includes(value.trim().toLowerCase()) || 
        x.plantName.trim().toLowerCase().includes(value.trim().toLowerCase()) || 
        x.currentDisplayRole.trim().toLowerCase().includes(value.trim().toLowerCase()) 
      );
      this.page = 1;
    }
  }

  save() {
    debugger;
    this.page = 1;
    let selectedPlant = this.UserPlantDetails.filter(item => item.isDefault == true);
    if (selectedPlant.length > 0) {
      
      if(!selectedPlant[0].isActive || selectedPlant[0].isUnderMaintenance)
        return;

      if (this.defaultPlantID == selectedPlant[0].plantID) {
        this.closePopup();
      }
      else {
        this.closePopup();
        this.sharedService.show();
        this.sharedService.apiURL = "";
        this.sharedService.plantID = selectedPlant[0].plantID;
        this.sharedService.currentUserInfo = selectedPlant[0];
        //this.sharedService.currentRole = selectedPlant[0].currentRole;

        var NTID = this.sharedService.ntid;

        if (NTID == null || NTID == undefined || NTID == "") {
          NTID = localStorage.getItem('ntid');
          this.sharedService.ntid = NTID;
        }

        //If first time login set current selected plant as default
        if(this.defaultPlantID == undefined)
        {
          this.isSetAsDefault = true;
        }

        if (this.isSetAsDefault) {

          var user = new User();
          user.emailAddress = this.sharedService.sharedUserDetails.emailAddress;
          user.firstName = this.sharedService.sharedUserDetails.firstName;
          user.lastName = this.sharedService.sharedUserDetails.lastName;
          user.ntid  = this.sharedService.sharedUserDetails.ntid;
          user.plantID = selectedPlant[0].plantID;
          user.userName = this.sharedService.sharedUserDetails.userName;

          this.sharedService.SetDefaultPlant(user).subscribe(res => {

          });
        }
        this.sharedService.GetEnironmentConfigFromDBAndLogin(NTID, this.router, "/dashboard");
        this.sharedService.hide();
      }
    }
    else {
      this.showAlert=true;
    }
  }

  public closeAlertInfo() {
    this.showAlert=false;
  }

  closePopup() {
    this.showPopup = false; // Method to close the popup
  }

  public closeAlertModal(isCancel:boolean = true) {
    this.page = 1;
    if(isCancel)
    {
      this.UserPlantDetails = JSON.parse(JSON.stringify(this.sharedService.sharedUserDetails.avaliablePlants));
    }
    if (document.getElementsByTagName("modal-container").length > 1) {
      //document.getElementsByTagName("modal-container").parentNode.removeChild(document.getElementsByTagName("modal-container"));
      if (document.getElementsByTagName("bs-modal-backdrop").length > 0) {
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      $("modal-container").remove();
    }
    else {
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if (document.getElementsByTagName("bs-modal-backdrop").length > 0) {
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }
  }


  isFirstPage() {
    if (this.page == 1) {
      return;
    }
    else {
    }

    this.page = 1;
    this.startPage = (this.page - 1) * 4 + 1;
    this.endPage = this.page * this.resultPerPage;
  }

  /** Method is responsible to move to last page of the pagination. */
  isLastPage() {
    if (Math.ceil(this.UserPlantDetails.length / this.resultPerPage) <= this.page) {
      return;
    }
    else {

    }

    this.page = Math.ceil(this.UserPlantDetails.length / this.resultPerPage);
    this.startPage = (this.page - 1) * 4 + 1;
    this.endPage = this.page * this.resultPerPage;
  }

  /** Method is responsible to change page of the pagination. */
  pageChanged(event): void {

    if (event == 0) {
      return;
    }
    else if (Math.ceil(this.UserPlantDetails.length / this.resultPerPage) < event) {
      return;
    }
    else {
      this.page = event;
      this.startPage = (this.page - 1) * 4 + 1;
      this.endPage = this.page * this.resultPerPage;
    }
  }
}
