// //---------------------------------------new code-----------------------------------------

// import { Injectable } from '@angular/core';
// import { BehaviorSubject, Observable, interval, fromEvent } from 'rxjs';
// import { map, switchMap, startWith } from 'rxjs/operators';

// export interface NetworkStatus {
//   isOnline: boolean;
//   speed: number; // in Mbps
//   quality: 'good' | 'fair' | 'poor' | 'offline';
//   apiResponseTime: number; // in milliseconds
//   isApiSlow: boolean;
//   consecutiveSlowRequests: number; // Track consecutive slow requests
//   networkStability: 'stable' | 'unstable' | 'very_unstable';
// }

// export interface ApiCallMetrics {
//   url: string;
//   responseTime: number;
//   timestamp: number;
//   status: 'success' | 'error' | 'timeout';
// }

// @Injectable({
//   providedIn: 'root'
// })
// export class NetworkTrackingService {
//   private networkStatusSubject = new BehaviorSubject<NetworkStatus>({
//     isOnline: navigator.onLine,
//     speed: 0,
//     quality: 'good',
//     apiResponseTime: 0,
//     isApiSlow: false,
//     consecutiveSlowRequests: 0,
//     networkStability: 'stable'
//   });

//   public networkStatus$ = this.networkStatusSubject.asObservable();

//   private isMonitoring = false;
//   private lowSpeedStartTime: number | null = null;
//   private alertShown = false;
//   private apiCallMetrics: ApiCallMetrics[] = [];
//   private readonly API_SLOW_THRESHOLD = 5000; // 5 seconds
//   private readonly API_VERY_SLOW_THRESHOLD = 10000; // 10 seconds
//   private readonly API_METRICS_LIMIT = 20; // Increased to 20 for better analysis
//   private readonly CONSECUTIVE_SLOW_LIMIT = 3; // Trigger after 3 consecutive slow requests
//   private consecutiveSlowCount = 0;
//   private lastSpeedTest = 0;
//   private readonly SPEED_TEST_COOLDOWN = 30000; // 30 seconds cooldown between speed tests

//   constructor() {
//     this.initializeNetworkMonitoring();
//   }

//   private initializeNetworkMonitoring(): void {
//     // Listen to online/offline events
//     fromEvent(window, 'online').subscribe(() => {
//       this.updateNetworkStatus(true);
//       this.hideAlert();
//       this.resetSlowRequestTracking();
//     });

//     fromEvent(window, 'offline').subscribe(() => {
//       this.updateNetworkStatus(false);
//       this.showAlert('You are currently offline. Please check your internet connection.');
//     });

//     // Start monitoring if online
//     if (navigator.onLine) {
//       this.startSpeedMonitoring();
//     }
//   }

//   private startSpeedMonitoring(): void {
//     if (this.isMonitoring) return;

//     this.isMonitoring = true;

//     // Check speed every 15 seconds (increased for better performance)
//     interval(15000).pipe(
//       switchMap(() => this.measureNetworkSpeed())
//     ).subscribe(speed => {
//       this.handleSpeedResult(speed);
//     });
//   }

//   private measureNetworkSpeed(): Promise<number> {
//     return new Promise((resolve) => {
//       // Use multiple image sizes for better accuracy
//       const testSizes = [
//         { url: 'https://via.placeholder.com/300x300.jpg', size: 300 * 300 },
//         { url: 'https://via.placeholder.com/500x500.jpg', size: 500 * 500 }
//       ];

//       const testImage = testSizes[Math.floor(Math.random() * testSizes.length)];
//       const imageAddr = testImage.url + '?' + Math.random();
//       const downloadSize = testImage.size;

//       const startTime = Date.now();
//       const img = new Image();

//       img.onload = () => {
//         const endTime = Date.now();
//         const duration = (endTime - startTime) / 1000; // in seconds
//         const bitsLoaded = downloadSize * 8;
//         const speedBps = bitsLoaded / duration;
//         const speedMbps = speedBps / (1024 * 1024);

//         resolve(Math.round(speedMbps * 100) / 100);
//       };

//       img.onerror = () => {
//         resolve(0); // No connection
//       };

//       img.src = imageAddr;

//       // Timeout after 20 seconds for very slow connections
//       setTimeout(() => {
//         resolve(0);
//       }, 20000);
//     });
//   }

//   // Enhanced method to track API call performance
//   trackApiCall(url: string, responseTime: number, status: 'success' | 'error' | 'timeout' = 'success'): void {
//     const metric: ApiCallMetrics = {
//       url,
//       responseTime,
//       timestamp: Date.now(),
//       status
//     };

//     this.apiCallMetrics.push(metric);

//     // Keep only the last N API calls
//     if (this.apiCallMetrics.length > this.API_METRICS_LIMIT) {
//       this.apiCallMetrics.shift();
//     }

//     // Track consecutive slow requests
//     if (responseTime > this.API_SLOW_THRESHOLD) {
//       this.consecutiveSlowCount++;
//     } else {
//       this.consecutiveSlowCount = 0;
//     }

//     // Calculate metrics
//     const avgResponseTime = this.calculateAverageApiResponseTime();
//     const isApiSlow = this.isApiResponseSlow(avgResponseTime);
//     const networkStability = this.calculateNetworkStability();

//     // Update network status with API metrics
//     this.updateNetworkStatusWithApiMetrics(avgResponseTime, isApiSlow, networkStability);

//     // Handle slow API response patterns
//     if (this.consecutiveSlowCount >= this.CONSECUTIVE_SLOW_LIMIT && !this.alertShown) {
//       this.showSlowApiAlert(avgResponseTime);
//     }

//     // Trigger speed test if network seems unstable
//     if (networkStability === 'very_unstable' && this.shouldTriggerSpeedTest()) {
//       this.triggerSpeedTest();
//     }
//   }

//   private calculateAverageApiResponseTime(): number {
//     if (this.apiCallMetrics.length === 0) return 0;

//     // Calculate weighted average (more weight to recent requests)
//     const recentMetrics = this.apiCallMetrics.slice(-10);
//     const totalTime = recentMetrics.reduce((sum, metric, index) => {
//       const weight = (index + 1) / recentMetrics.length; // More weight to recent calls
//       return sum + (metric.responseTime * weight);
//     }, 0);

//     const totalWeight = recentMetrics.reduce((sum, _, index) => {
//       return sum + ((index + 1) / recentMetrics.length);
//     }, 0);

//     return Math.round(totalTime / totalWeight);
//   }

//   private isApiResponseSlow(avgResponseTime: number): boolean {
//     return avgResponseTime > this.API_SLOW_THRESHOLD || this.consecutiveSlowCount >= 2;
//   }

//   private calculateNetworkStability(): 'stable' | 'unstable' | 'very_unstable' {
//     if (this.apiCallMetrics.length < 5) return 'stable';

//     const recentMetrics = this.apiCallMetrics.slice(-10);
//     const slowRequests = recentMetrics.filter(m => m.responseTime > this.API_SLOW_THRESHOLD).length;
//     const errorRequests = recentMetrics.filter(m => m.status === 'error').length;
//     const totalRequests = recentMetrics.length;

//     const slowRatio = slowRequests / totalRequests;
//     const errorRatio = errorRequests / totalRequests;

//     if (slowRatio > 0.6 || errorRatio > 0.3 || this.consecutiveSlowCount >= 4) {
//       return 'very_unstable';
//     } else if (slowRatio > 0.3 || errorRatio > 0.1 || this.consecutiveSlowCount >= 2) {
//       return 'unstable';
//     }

//     return 'stable';
//   }

//   private updateNetworkStatusWithApiMetrics(
//     apiResponseTime: number,
//     isApiSlow: boolean,
//     networkStability: 'stable' | 'unstable' | 'very_unstable'
//   ): void {
//     const currentStatus = this.networkStatusSubject.value;
//     const newStatus: NetworkStatus = {
//       ...currentStatus,
//       apiResponseTime,
//       isApiSlow,
//       consecutiveSlowRequests: this.consecutiveSlowCount,
//       networkStability
//     };

//     this.networkStatusSubject.next(newStatus);
//   }

//   private handleSpeedResult(speed: number): void {
//     const quality = this.getSpeedQuality(speed);

//     this.updateNetworkStatus(navigator.onLine, speed, quality);

//     // Handle low speed detection with improved logic
//     if (quality === 'poor' || speed === 0) {
//       if (!this.lowSpeedStartTime) {
//         this.lowSpeedStartTime = Date.now();
//       } else {
//         const lowSpeedDuration = Date.now() - this.lowSpeedStartTime;

//         // Show alert if low speed for more than 10 seconds (reduced from 15)
//         if (lowSpeedDuration > 10000 && !this.alertShown) {
//           this.showAlert('We are experiencing slow network speed. Please check your internet connection.');
//           this.alertShown = true;
//         }
//       }
//     } else {
//       // Reset low speed tracking when speed improves
//       this.lowSpeedStartTime = null;
//       if (this.alertShown) {
//         this.hideAlert();
//         this.alertShown = false;
//       }
//     }
//   }

//   private getSpeedQuality(speed: number): 'good' | 'fair' | 'poor' | 'offline' {
//     if (speed === 0) return 'offline';
//     if (speed < 0.3) return 'poor';  // Very slow connection
//     if (speed < 1.5) return 'fair';  // Slow connection
//     return 'good';
//   }

//   private updateNetworkStatus(
//     isOnline: boolean,
//     speed: number = 0,
//     quality?: 'good' | 'fair' | 'poor' | 'offline'
//   ): void {
//     const currentStatus = this.networkStatusSubject.value;
//     const newStatus: NetworkStatus = {
//       ...currentStatus,
//       isOnline,
//       speed,
//       quality: quality || (isOnline ? 'good' : 'offline')
//     };

//     this.networkStatusSubject.next(newStatus);
//   }

//   private showAlert(message: string): void {
//     this.createToastNotification(message, 'warning');
//   }

//   private showSlowApiAlert(avgResponseTime: number): void {
//     const seconds = Math.round(avgResponseTime / 1000);
//     const currentStatus = this.networkStatusSubject.value;

//     let message = `We're experiencing slow response times (${seconds}s average).`;

//     if (currentStatus.networkStability === 'very_unstable') {
//       message += ' Your network connection appears very unstable. Please check your internet connection.';
//     } else if (currentStatus.quality === 'poor' || currentStatus.quality === 'fair') {
//       message += ` Your network quality is ${currentStatus.quality}. This may be affecting performance.`;
//     } else {
//       message += ' This may be due to server load or network conditions.';
//     }

//     this.createToastNotification(message, 'warning');
//     this.alertShown = true;
//   }

//   private hideAlert(): void {
//     if (this.alertShown) {
//       this.createToastNotification('Network connection restored! Performance should improve.', 'success');
//       this.alertShown = false;
//     }
//   }

//   private createToastNotification(message: string, type: 'warning' | 'success'): void {
//     const toast = document.createElement('div');
//     toast.style.cssText = `
//       position: fixed;
//       top: 20px;
//       right: 20px;
//       z-index: 10000;
//       padding: 15px 20px;
//       border-radius: 8px;
//       color: white;
//       font-weight: bold;
//       max-width: 450px;
//       box-shadow: 0 4px 20px rgba(0,0,0,0.3);
//       background-color: ${type === 'warning' ? '#ff9800' : '#4caf50'};
//       animation: slideIn 0.3s ease-out;
//       font-size: 14px;
//       line-height: 1.4;
//     `;

//     toast.innerHTML = `
//       <div style="display: flex; align-items: flex-start; justify-content: space-between;">
//         <span style="flex: 1; margin-right: 10px;">${message}</span>
//         <button onclick="this.parentElement.parentElement.remove()"
//                 style="background: none; border: none; color: white; font-size: 18px; cursor: pointer; padding: 0; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center;">×</button>
//       </div>
//     `;

//     // Add animation CSS if not already present
//     if (!document.querySelector('#toast-animation-styles')) {
//       const style = document.createElement('style');
//       style.id = 'toast-animation-styles';
//       style.textContent = `
//         @keyframes slideIn {
//           from { transform: translateX(100%); opacity: 0; }
//           to { transform: translateX(0); opacity: 1; }
//         }
//         @keyframes slideOut {
//           from { transform: translateX(0); opacity: 1; }
//           to { transform: translateX(100%); opacity: 0; }
//         }
//       `;
//       document.head.appendChild(style);
//     }

//     document.body.appendChild(toast);

//     // Auto-remove after duration
//     const duration = type === 'warning' ? 12000 : 4000;
//     setTimeout(() => {
//       if (toast.parentElement) {
//         toast.style.animation = 'slideOut 0.3s ease-in';
//         setTimeout(() => toast.remove(), 300);
//       }
//     }, duration);
//   }

//   private shouldTriggerSpeedTest(): boolean {
//     const now = Date.now();
//     return (now - this.lastSpeedTest) > this.SPEED_TEST_COOLDOWN;
//   }

//   private triggerSpeedTest(): void {
//     this.lastSpeedTest = Date.now();
//     this.measureNetworkSpeed().then(speed => {
//       this.handleSpeedResult(speed);
//     });
//   }

//   private resetSlowRequestTracking(): void {
//     this.consecutiveSlowCount = 0;
//     this.alertShown = false;
//   }

//   // Public method to get current network status
//   getCurrentNetworkStatus(): NetworkStatus {
//     return this.networkStatusSubject.value;
//   }

//   // Public method to manually trigger speed test
//   testSpeed(): Promise<number> {
//     return this.measureNetworkSpeed();
//   }

//   // Public method to get API performance metrics
//   getApiMetrics(): ApiCallMetrics[] {
//     return [...this.apiCallMetrics];
//   }

//   // Public method to get recent slow requests
//   getRecentSlowRequests(): ApiCallMetrics[] {
//     return this.apiCallMetrics.filter(metric =>
//       metric.responseTime > this.API_SLOW_THRESHOLD &&
//       Date.now() - metric.timestamp < 300000 // Last 5 minutes
//     );
//   }

//   // Public method to reset API metrics
//   resetApiMetrics(): void {
//     this.apiCallMetrics = [];
//     this.consecutiveSlowCount = 0;
//     this.alertShown = false;
//   }

//   // Public method to check if network is currently experiencing issues
//   isNetworkExperiencingIssues(): boolean {
//     const status = this.getCurrentNetworkStatus();
//     return !status.isOnline ||
//            status.quality === 'poor' ||
//            status.isApiSlow ||
//            status.networkStability === 'very_unstable';
//   }

//   // Public method to get network quality score (0-100)
//   getNetworkQualityScore(): number {
//     const status = this.getCurrentNetworkStatus();

//     if (!status.isOnline) return 0;

//     let score = 100;

//     // Deduct points based on speed
//     if (status.speed < 0.5) score -= 50;
//     else if (status.speed < 1.5) score -= 30;
//     else if (status.speed < 3) score -= 15;

//     // Deduct points based on API performance
//     if (status.isApiSlow) score -= 20;
//     if (status.consecutiveSlowRequests > 2) score -= 15;

//     // Deduct points based on stability
//     if (status.networkStability === 'very_unstable') score -= 25;
//     else if (status.networkStability === 'unstable') score -= 10;

//     return Math.max(0, Math.min(100, score));
//   }
// }
//-----------------------------new code ----------------------------------

// import { Injectable } from '@angular/core';
// import { BehaviorSubject, Observable, interval, fromEvent } from 'rxjs';
// import { map, switchMap, startWith } from 'rxjs/operators';

// export interface NetworkStatus {
//   isOnline: boolean;
//   speed: number; // in Mbps
//   quality: 'good' | 'fair' | 'poor' | 'offline';
//   apiResponseTime: number; // in milliseconds
//   isApiSlow: boolean;
//   consecutiveSlowRequests: number;
//   networkStability: 'stable' | 'unstable' | 'very_unstable';
// }

// export interface ApiCallMetrics {
//   url: string;
//   responseTime: number;
//   timestamp: number;
//   status: 'success' | 'error' | 'timeout';
// }

// @Injectable({
//   providedIn: 'root'
// })
// export class NetworkTrackingService {
//   private networkStatusSubject = new BehaviorSubject<NetworkStatus>({
//     isOnline: navigator.onLine,
//     speed: 0,
//     quality: 'good',
//     apiResponseTime: 0,
//     isApiSlow: false,
//     consecutiveSlowRequests: 0,
//     networkStability: 'stable'
//   });

//   public networkStatus$ = this.networkStatusSubject.asObservable();

//   private isMonitoring = false;
//   private networkAlertShown = false;
//   private apiCallMetrics: ApiCallMetrics[] = [];
//   private readonly API_SLOW_THRESHOLD = 5000; // 5 seconds
//   private readonly API_VERY_SLOW_THRESHOLD = 10000; // 10 seconds
//   private readonly API_METRICS_LIMIT = 20;
//   private readonly CONSECUTIVE_SLOW_LIMIT = 3;
//   private consecutiveSlowCount = 0;
//   private lastSpeedTest = 0;
//   private readonly SPEED_TEST_COOLDOWN = 30000; // 30 seconds cooldown between speed tests
//   private networkStabilityCheckInterval: any;

//   constructor() {
//     this.initializeNetworkMonitoring();
//     this.startContinuousNetworkMonitoring();
//   }

//   private initializeNetworkMonitoring(): void {
//     // Listen to online/offline events
//     fromEvent(window, 'online').subscribe(() => {
//       this.updateNetworkStatus(true);
//       this.showNetworkStatusToast('✅ Internet connection restored!', 'success');
//       this.networkAlertShown = false;
//       this.resetSlowRequestTracking();
//     });

//     fromEvent(window, 'offline').subscribe(() => {
//       this.updateNetworkStatus(false);
//       this.showNetworkStatusToast('🚨 You are currently offline. Please check your internet connection.', 'error');
//       this.networkAlertShown = true;
//     });

//     // Start monitoring if online
//     if (navigator.onLine) {
//       this.startSpeedMonitoring();
//     }
//   }

//   private startContinuousNetworkMonitoring(): void {
//     // Continuous network quality monitoring every 10 seconds
//     this.networkStabilityCheckInterval = setInterval(() => {
//       this.checkNetworkStability();
//     }, 10000);
//   }

//   private checkNetworkStability(): void {
//     if (!navigator.onLine) {
//       if (!this.networkAlertShown) {
//         this.showNetworkStatusToast('🚨 No internet connection detected. Please check your network.', 'error');
//         this.networkAlertShown = true;
//       }
//       return;
//     }

//     // Test network speed periodically
//     this.measureNetworkSpeed().then(speed => {
//       const quality = this.getSpeedQuality(speed);
//       const currentStatus = this.networkStatusSubject.value;

//       // Update network status
//       this.updateNetworkStatus(true, speed, quality);

//       // Check if network went from good to bad
//       if (quality === 'poor' || quality === 'fair') {
//         if (!this.networkAlertShown) {
//           this.showNetworkStatusToast(
//             `⚠️ Network speed is ${quality} (${speed.toFixed(1)} Mbps). This may affect performance.`,
//             'warning'
//           );
//           this.networkAlertShown = true;
//         }
//       } else if (quality === 'good' && this.networkAlertShown) {
//         // Network improved
//         this.showNetworkStatusToast('✅ Network speed improved! Performance should be better now.', 'success');
//         this.networkAlertShown = false;
//       }
//     });
//   }

//   private startSpeedMonitoring(): void {
//     if (this.isMonitoring) return;

//     this.isMonitoring = true;

//     // Initial speed test
//     this.measureNetworkSpeed().then(speed => {
//       this.handleSpeedResult(speed);
//     });
//   }

//   private measureNetworkSpeed(): Promise<number> {
//     return new Promise((resolve) => {
//       // Use multiple image sizes for better accuracy
//       const testSizes = [
//         { url: 'https://via.placeholder.com/300x300.jpg', size: 300 * 300 },
//         { url: 'https://via.placeholder.com/500x500.jpg', size: 500 * 500 }
//       ];

//       const testImage = testSizes[Math.floor(Math.random() * testSizes.length)];
//       const imageAddr = testImage.url + '?' + Math.random();
//       const downloadSize = testImage.size;

//       const startTime = Date.now();
//       const img = new Image();

//       img.onload = () => {
//         const endTime = Date.now();
//         const duration = (endTime - startTime) / 1000; // in seconds
//         const bitsLoaded = downloadSize * 8;
//         const speedBps = bitsLoaded / duration;
//         const speedMbps = speedBps / (1024 * 1024);

//         resolve(Math.round(speedMbps * 100) / 100);
//       };

//       img.onerror = () => {
//         resolve(0); // No connection
//       };

//       img.src = imageAddr;

//       // Timeout after 20 seconds for very slow connections
//       setTimeout(() => {
//         resolve(0);
//       }, 20000);
//     });
//   }

//   // Enhanced method to track API call performance
//   trackApiCall(url: string, responseTime: number, status: 'success' | 'error' | 'timeout' = 'success'): void {
//     const metric: ApiCallMetrics = {
//       url,
//       responseTime,
//       timestamp: Date.now(),
//       status
//     };

//     this.apiCallMetrics.push(metric);

//     // Keep only the last N API calls
//     if (this.apiCallMetrics.length > this.API_METRICS_LIMIT) {
//       this.apiCallMetrics.shift();
//     }

//     // Track consecutive slow requests
//     if (responseTime > this.API_SLOW_THRESHOLD) {
//       this.consecutiveSlowCount++;
//     } else {
//       this.consecutiveSlowCount = 0;
//     }

//     // Calculate metrics
//     const avgResponseTime = this.calculateAverageApiResponseTime();
//     const isApiSlow = this.isApiResponseSlow(avgResponseTime);
//     const networkStability = this.calculateNetworkStability();

//     // Update network status with API metrics
//     this.updateNetworkStatusWithApiMetrics(avgResponseTime, isApiSlow, networkStability);
//   }

//   private calculateAverageApiResponseTime(): number {
//     if (this.apiCallMetrics.length === 0) return 0;

//     // Calculate weighted average (more weight to recent requests)
//     const recentMetrics = this.apiCallMetrics.slice(-10);
//     const totalTime = recentMetrics.reduce((sum, metric, index) => {
//       const weight = (index + 1) / recentMetrics.length;
//       return sum + (metric.responseTime * weight);
//     }, 0);

//     const totalWeight = recentMetrics.reduce((sum, _, index) => {
//       return sum + ((index + 1) / recentMetrics.length);
//     }, 0);

//     return Math.round(totalTime / totalWeight);
//   }

//   private isApiResponseSlow(avgResponseTime: number): boolean {
//     return avgResponseTime > this.API_SLOW_THRESHOLD || this.consecutiveSlowCount >= 2;
//   }

//   private calculateNetworkStability(): 'stable' | 'unstable' | 'very_unstable' {
//     if (this.apiCallMetrics.length < 5) return 'stable';

//     const recentMetrics = this.apiCallMetrics.slice(-10);
//     const slowRequests = recentMetrics.filter(m => m.responseTime > this.API_SLOW_THRESHOLD).length;
//     const errorRequests = recentMetrics.filter(m => m.status === 'error').length;
//     const totalRequests = recentMetrics.length;

//     const slowRatio = slowRequests / totalRequests;
//     const errorRatio = errorRequests / totalRequests;

//     if (slowRatio > 0.6 || errorRatio > 0.3 || this.consecutiveSlowCount >= 4) {
//       return 'very_unstable';
//     } else if (slowRatio > 0.3 || errorRatio > 0.1 || this.consecutiveSlowCount >= 2) {
//       return 'unstable';
//     }

//     return 'stable';
//   }

//   private updateNetworkStatusWithApiMetrics(
//     apiResponseTime: number,
//     isApiSlow: boolean,
//     networkStability: 'stable' | 'unstable' | 'very_unstable'
//   ): void {
//     const currentStatus = this.networkStatusSubject.value;
//     const newStatus: NetworkStatus = {
//       ...currentStatus,
//       apiResponseTime,
//       isApiSlow,
//       consecutiveSlowRequests: this.consecutiveSlowCount,
//       networkStability
//     };

//     this.networkStatusSubject.next(newStatus);
//   }

//   private handleSpeedResult(speed: number): void {
//     const quality = this.getSpeedQuality(speed);
//     this.updateNetworkStatus(navigator.onLine, speed, quality);
//   }

//   private getSpeedQuality(speed: number): 'good' | 'fair' | 'poor' | 'offline' {
//     if (speed === 0) return 'offline';
//     if (speed < 0.5) return 'poor';  // Very slow connection
//     if (speed < 2.0) return 'fair';  // Slow connection
//     return 'good';
//   }

//   private updateNetworkStatus(
//     isOnline: boolean,
//     speed: number = 0,
//     quality?: 'good' | 'fair' | 'poor' | 'offline'
//   ): void {
//     const currentStatus = this.networkStatusSubject.value;
//     const newStatus: NetworkStatus = {
//       ...currentStatus,
//       isOnline,
//       speed,
//       quality: quality || (isOnline ? 'good' : 'offline')
//     };

//     this.networkStatusSubject.next(newStatus);
//   }

//   private showNetworkStatusToast(message: string, type: 'warning' | 'success' | 'error'): void {
//     this.createToastNotification(message, type);
//   }

//   private createToastNotification(message: string, type: 'warning' | 'success' | 'error'): void {
//     const toast = document.createElement('div');

//     const colors = {
//       warning: '#ff9800',
//       success: '#4caf50',
//       error: '#f44336'
//     };

//     toast.style.cssText = `
//       position: fixed;
//       top: 20px;
//       right: 20px;
//       z-index: 10000;
//       padding: 15px 20px;
//       border-radius: 8px;
//       color: white;
//       font-weight: bold;
//       max-width: 450px;
//       box-shadow: 0 4px 20px rgba(0,0,0,0.3);
//       background-color: ${colors[type]};
//       animation: slideIn 0.3s ease-out;
//       font-size: 14px;
//       line-height: 1.4;
//     `;

//     toast.innerHTML = `
//       <div style="display: flex; align-items: flex-start; justify-content: space-between;">
//         <span style="flex: 1; margin-right: 10px;">${message}</span>
//         <button onclick="this.parentElement.parentElement.remove()"
//                 style="background: none; border: none; color: white; font-size: 18px; cursor: pointer; padding: 0; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center;">×</button>
//       </div>
//     `;

//     // Add animation CSS if not already present
//     if (!document.querySelector('#toast-animation-styles')) {
//       const style = document.createElement('style');
//       style.id = 'toast-animation-styles';
//       style.textContent = `
//         @keyframes slideIn {
//           from { transform: translateX(100%); opacity: 0; }
//           to { transform: translateX(0); opacity: 1; }
//         }
//         @keyframes slideOut {
//           from { transform: translateX(0); opacity: 1; }
//           to { transform: translateX(100%); opacity: 0; }
//         }
//       `;
//       document.head.appendChild(style);
//     }

//     document.body.appendChild(toast);

//     // Auto-remove after duration
//     const duration = type === 'error' ? 8000 : type === 'warning' ? 6000 : 4000;
//     setTimeout(() => {
//       if (toast.parentElement) {
//         toast.style.animation = 'slideOut 0.3s ease-in';
//         setTimeout(() => toast.remove(), 300);
//       }
//     }, duration);
//   }

//   private resetSlowRequestTracking(): void {
//     this.consecutiveSlowCount = 0;
//   }

//   // Public method to get current network status
//   getCurrentNetworkStatus(): NetworkStatus {
//     return this.networkStatusSubject.value;
//   }

//   // Public method to manually trigger speed test
//   testSpeed(): Promise<number> {
//     return this.measureNetworkSpeed();
//   }

//   // Public method to get API performance metrics
//   getApiMetrics(): ApiCallMetrics[] {
//     return [...this.apiCallMetrics];
//   }

//   // Public method to get recent slow requests
//   getRecentSlowRequests(): ApiCallMetrics[] {
//     return this.apiCallMetrics.filter(metric =>
//       metric.responseTime > this.API_SLOW_THRESHOLD &&
//       Date.now() - metric.timestamp < 300000 // Last 5 minutes
//     );
//   }

//   // Public method to reset API metrics
//   resetApiMetrics(): void {
//     this.apiCallMetrics = [];
//     this.consecutiveSlowCount = 0;
//   }

//   // Public method to check if network is currently experiencing issues
//   isNetworkExperiencingIssues(): boolean {
//     const status = this.getCurrentNetworkStatus();
//     return !status.isOnline ||
//            status.quality === 'poor' ||
//            status.quality === 'fair' ||
//            status.isApiSlow ||
//            status.networkStability === 'very_unstable';
//   }

//   // Public method to check if network speed is good
//   isNetworkSpeedGood(): boolean {
//     const status = this.getCurrentNetworkStatus();
//     return status.isOnline && status.quality === 'good';
//   }

//   // Public method to get network quality score (0-100)
//   getNetworkQualityScore(): number {
//     const status = this.getCurrentNetworkStatus();

//     if (!status.isOnline) return 0;

//     let score = 100;

//     // Deduct points based on speed
//     if (status.speed < 0.5) score -= 50;
//     else if (status.speed < 1.5) score -= 30;
//     else if (status.speed < 3) score -= 15;

//     // Deduct points based on API performance
//     if (status.isApiSlow) score -= 20;
//     if (status.consecutiveSlowRequests > 2) score -= 15;

//     // Deduct points based on stability
//     if (status.networkStability === 'very_unstable') score -= 25;
//     else if (status.networkStability === 'unstable') score -= 10;

//     return Math.max(0, Math.min(100, score));
//   }

//   ngOnDestroy(): void {
//     if (this.networkStabilityCheckInterval) {
//       clearInterval(this.networkStabilityCheckInterval);
//     }
//   }
// }

//-------------------------------------New code -------------------------------------

import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, interval, fromEvent } from 'rxjs';
import { map, switchMap, startWith } from 'rxjs/operators';

export interface NetworkStatus {
  isOnline: boolean;
  speed: number; // in Mbps
  quality: 'good' | 'fair' | 'poor' | 'offline';
  apiResponseTime: number; // in milliseconds
  isApiSlow: boolean;
  consecutiveSlowRequests: number;
  networkStability: 'stable' | 'unstable' | 'very_unstable';
}

export interface ApiCallMetrics {
  url: string;
  responseTime: number;
  timestamp: number;
  status: 'success' | 'error' | 'timeout';
}

@Injectable({
  providedIn: 'root'
})
export class NetworkTrackingService {
  private networkStatusSubject = new BehaviorSubject<NetworkStatus>({
    isOnline: navigator.onLine,
    speed: 0,
    quality: 'good',
    apiResponseTime: 0,
    isApiSlow: false,
    consecutiveSlowRequests: 0,
    networkStability: 'stable'
  });

  public networkStatus$ = this.networkStatusSubject.asObservable();

  private isMonitoring = false;
  private networkAlertShown = false;
  private apiCallMetrics: ApiCallMetrics[] = [];
  private readonly API_SLOW_THRESHOLD = 5000; // 5 seconds
  private readonly API_VERY_SLOW_THRESHOLD = 10000; // 10 seconds
  private readonly API_METRICS_LIMIT = 20;
  private readonly CONSECUTIVE_SLOW_LIMIT = 3;
  private consecutiveSlowCount = 0;
  private lastSpeedTest = 0;
  private readonly SPEED_TEST_COOLDOWN = 30000; // 30 seconds cooldown between speed tests
  private networkStabilityCheckInterval: any;

  constructor() {
    this.initializeNetworkMonitoring();
    this.startContinuousNetworkMonitoring();
  }

  private initializeNetworkMonitoring(): void {
    // Listen to online/offline events
    fromEvent(window, 'online').subscribe(() => {
      this.updateNetworkStatus(true);
      this.showNetworkStatusToast('✅ Internet connection restored!', 'success');
      this.networkAlertShown = false;
      this.resetSlowRequestTracking();
    });

    fromEvent(window, 'offline').subscribe(() => {
      this.updateNetworkStatus(false);
      this.showNetworkStatusToast('🚨 You are currently offline. Please check your internet connection.', 'error');
      this.networkAlertShown = true;
    });

    // Start monitoring if online
    if (navigator.onLine) {
      this.startSpeedMonitoring();
    }
  }

  private startContinuousNetworkMonitoring(): void {
    // Continuous network quality monitoring every 10 seconds
    this.networkStabilityCheckInterval = setInterval(() => {
      this.checkNetworkStability();
    }, 10000);
  }

  private checkNetworkStability(): void {
    if (!navigator.onLine) {
      if (!this.networkAlertShown) {
        this.showNetworkStatusToast('🚨 No internet connection detected. Please check your network.', 'error');
        this.networkAlertShown = true;
      }
      return;
    }

    // Test network speed periodically
    this.measureNetworkSpeed().then(speed => {
      console.log('🌐 Measured network speed:', speed, 'Mbps'); // Add logging
      const quality = this.getSpeedQuality(speed);
      const currentStatus = this.networkStatusSubject.value;

      // Update network status
      this.updateNetworkStatus(true, speed, quality);

      // Check if network went from good to bad
      if (quality === 'poor' || quality === 'fair') {
        if (!this.networkAlertShown) {
          this.showNetworkStatusToast(
            `⚠️ Network speed is ${quality} (${speed.toFixed(1)} Mbps). This may affect performance.`,
            'warning'
          );
          this.networkAlertShown = true;
        }
      } else if (quality === 'good' && this.networkAlertShown) {
        // Network improved
        this.showNetworkStatusToast('✅ Network speed improved! Performance should be better now.', 'success');
        this.networkAlertShown = false;
      }
    });
  }

  private startSpeedMonitoring(): void {
    if (this.isMonitoring) return;

    this.isMonitoring = true;

    // Initial speed test
    this.measureNetworkSpeed().then(speed => {
      this.handleSpeedResult(speed);
    });
  }

  // // FIXED: Better network speed measurement using multiple methods
  // private measureNetworkSpeed(): Promise<number> {
  //   return new Promise((resolve) => {
  //     // Method 1: Use Connection API if available
  //     if ('connection' in navigator) {
  //       const connection = (navigator as any).connection;
  //       if (connection && connection.downlink) {
  //         const speedMbps = connection.downlink;
  //         console.log('📡 Using Connection API speed:', speedMbps, 'Mbps');
  //         resolve(speedMbps);
  //         return;
  //       }
  //     }

  //     // Method 2: Fallback to image download test with reliable CDN
  //     const testImages = [
  //       'https://httpbin.org/image/png?size=100x100',
  //       'https://httpbin.org/image/jpeg?size=100x100',
  //       'https://jsonplaceholder.typicode.com/photos/1' // Reliable test endpoint
  //     ];

  //     const imageUrl = testImages[Math.floor(Math.random() * testImages.length)];
  //     const downloadSize = 50000; // Approximate size in bytes
  //     const startTime = Date.now();

  //     const img = new Image();
  //     img.crossOrigin = 'anonymous';

  //     img.onload = () => {
  //       const endTime = Date.now();
  //       const duration = (endTime - startTime) / 1000; // in seconds
  //       const bitsLoaded = downloadSize * 8;
  //       const speedBps = bitsLoaded / duration;
  //       const speedMbps = speedBps / (1024 * 1024);
  //       const calculatedSpeed = Math.max(0.1, Math.round(speedMbps * 100) / 100);

  //       console.log('📊 Speed test result:', {
  //         duration: duration + 's',
  //         estimatedSize: downloadSize + ' bytes',
  //         calculatedSpeed: calculatedSpeed + ' Mbps'
  //       });

  //       resolve(calculatedSpeed);
  //     };

  //     img.onerror = () => {
  //       console.log('⚠️ Image speed test failed, estimating speed...');
  //       // Estimate based on typical performance if test fails
  //       resolve(this.estimateSpeedFromLatency());
  //     };

  //     img.src = imageUrl + '?' + Math.random();

  //     // Timeout after 15 seconds
  //     setTimeout(() => {
  //       console.log('⏰ Speed test timeout, estimating...');
  //       resolve(this.estimateSpeedFromLatency());
  //     }, 15000);
  //   });
  // }

  // ADDED: Estimate speed based on API response times

  // FIXED: Better network speed measurement using multiple methods with cross-browser compatibility
private measureNetworkSpeed(): Promise<number> {
  return new Promise((resolve) => {
    // Method 1: Use Connection API if available (Chrome/Edge work best)
    if ('connection' in navigator) {
      const connection = (navigator as any).connection;
      if (connection && connection.downlink && connection.downlink > 0) {
        const speedMbps = connection.downlink;
        console.log('📡 Using Connection API speed:', speedMbps, 'Mbps');
        resolve(speedMbps);
        return;
      }
    }

    // Method 2: Enhanced fallback with browser-specific optimizations
    const browserType = this.getBrowserType();
    let testImages: string[] = [];
    let downloadSize = 50000;

    // Browser-specific test URLs and sizes for better accuracy
    // if (browserType === 'firefox' || browserType === 'safari') {
    //   // Firefox and Safari work better with these endpoints
    //   testImages = [
    //     'https://httpbin.org/bytes/75000',  // Exact 75KB for better calculation
    //     'https://via.placeholder.com/300x300.png',
    //     'https://picsum.photos/200/200.jpg'
    //   ];
    //   downloadSize = 75000;
    // } else {
    //   // Chrome and Edge can handle larger files
    //   testImages = [
    //     'https://httpbin.org/bytes/100000', // Exact 100KB
    //     'https://httpbin.org/image/png?size=200x200',
    //     'https://jsonplaceholder.typicode.com/photos/1'
    //   ];
    //   downloadSize = 100000;
    // }

      const isProduction = !window.location.hostname.includes('localhost');
      const baseUrl = isProduction ? window.location.origin : 'https://orange-glacier-05f90e403.5.azurestaticapps.net';
      console.log("isProduction -->" + isProduction);
      console.log("baseUrl -->" + baseUrl);
    // Browser-specific test files configuration
    if (browserType === 'firefox' || browserType === 'safari') {
      // Firefox and Safari work better with smaller files
      testImages = [
         `${baseUrl}/assets/speed-test/test-75kb.png`,
         `${baseUrl}/assets/speed-test/test-75kb.jpg`,
         `${baseUrl}/assets/speed-test/test-75kb-alt.png`  // Create 3 different 75KB files
      ];
      downloadSize = 75000; // 75KB
    } else {
      // Chrome and Edge can handle larger files
      testImages = [
       `${baseUrl}/assets/speed-test/test-100kb.png`,
       `${baseUrl}/assets/speed-test/test-100kb.jpg`,
       `${baseUrl}/assets/speed-test/test-100kb-alt.png`  // Create 3 different 100KB files
      ];
      downloadSize = 100000; // 100KB
    }

    const imageUrl = testImages[Math.floor(Math.random() * testImages.length)];
    const startTime = performance.now(); // Use performance.now() for better precision
    let isResolved = false;

    // Create cache-busting URL
    const cacheBuster = Date.now() + Math.random().toString(36);
    const testUrl = imageUrl + (imageUrl.includes('?') ? '&' : '?') + 'cb=' + cacheBuster;

    // Try fetch method first for better reliability in Firefox/Safari
    if (browserType === 'firefox' || browserType === 'safari') {
      fetch(testUrl, {
        method: 'GET',
        cache: 'no-cache',
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache',
          'Expires': '0'
        }
      })
      .then(response => {
        if (!response.ok) throw new Error('Fetch failed');
        return response.blob();
      })
      .then(() => {
        if (isResolved) return;
        isResolved = true;

        const endTime = performance.now();
        const duration = (endTime - startTime) / 1000;
        const bitsLoaded = downloadSize * 8;
        const speedBps = bitsLoaded / duration;
        const speedMbps = speedBps / (1024 * 1024);
        const calculatedSpeed = Math.max(0.1, Math.round(speedMbps * 100) / 100);

        console.log('🚀 Fetch speed test result:', {
          browser: browserType,
          duration: duration + 's',
          actualSize: downloadSize + ' bytes',
          calculatedSpeed: calculatedSpeed + ' Mbps'
        });

        resolve(calculatedSpeed);
      })
      .catch(() => {
        if (!isResolved) {
          // Fallback to image method if fetch fails
          console.warn("Catch Fallback --> "+testUrl + " Browser --> "+browserType);
          this.fallbackToImageMethod(testUrl, downloadSize, startTime, resolve, browserType);
        }
      });
    } else {
      console.warn("Catch Fallback --> "+testUrl + " Browser --> "+browserType);
      // Use image method for Chrome/Edge (more reliable for these browsers)
      this.fallbackToImageMethod(testUrl, downloadSize, startTime, resolve, browserType);
    }

    // Enhanced timeout with browser-specific timing
    const timeoutDuration = browserType === 'safari' ? 20000 : 15000;
    setTimeout(() => {
      if (!isResolved) {
        isResolved = true;
        console.log('⏰ Speed test timeout, estimating...', 'Browser:', browserType);
        resolve(this.estimateSpeedFromLatency());
      }
    }, timeoutDuration);
  });
}

// Helper method for image-based speed testing
private fallbackToImageMethod(testUrl: string, downloadSize: number, startTime: number, resolve: Function, browserType: string): void {
  const img = new Image();
  img.crossOrigin = 'anonymous';

  img.onload = () => {
    const endTime = performance.now();
    const duration = (endTime - startTime) / 1000;

    // Apply browser-specific size corrections
    let actualSize = downloadSize;
    if (browserType === 'safari') {
      actualSize = downloadSize * 0.8; // Safari often compresses images
    } else if (browserType === 'firefox') {
      actualSize = downloadSize * 0.9; // Firefox has slight compression
    }

    const bitsLoaded = actualSize * 8;
    const speedBps = bitsLoaded / duration;
    const speedMbps = speedBps / (1024 * 1024);
    const calculatedSpeed = Math.max(0.1, Math.round(speedMbps * 100) / 100);

    console.log('📊 Image speed test result:', {
      browser: browserType,
      duration: duration + 's',
      estimatedSize: actualSize + ' bytes',
      calculatedSpeed: calculatedSpeed + ' Mbps'
    });

    resolve(calculatedSpeed);
  };

  img.onerror = () => {
    console.log('⚠️ Image speed test failed, estimating speed...', 'Browser:', browserType);
    resolve(this.estimateSpeedFromLatency());
  };

  img.src = testUrl;
}

// Helper method to detect browser type
private getBrowserType(): 'chrome' | 'firefox' | 'safari' | 'edge' | 'other' {
  const userAgent = navigator.userAgent.toLowerCase();

  if (userAgent.includes('edg/')) return 'edge';
  if (userAgent.includes('chrome') && !userAgent.includes('edg/')) return 'chrome';
  if (userAgent.includes('firefox')) return 'firefox';
  if (userAgent.includes('safari') && !userAgent.includes('chrome')) return 'safari';

  return 'other';
}

// Enhanced estimateSpeedFromLatency method (you might already have this)
private estimateSpeedFromLatencyFallback(): number {
  const browserType = this.getBrowserType();

  // Browser-specific fallback speeds based on typical performance
  const fallbackSpeeds = {
    'chrome': 25,
    'edge': 25,
    'firefox': 20,
    'safari': 18,
    'other': 15
  };

  const estimatedSpeed = fallbackSpeeds[browserType];
  console.log(`🔄 Using fallback speed for ${browserType}:`, estimatedSpeed, 'Mbps');

  return estimatedSpeed;
}

  private estimateSpeedFromLatency(): number {
    const avgApiTime = this.calculateAverageApiResponseTime();

    if (avgApiTime === 0) {
      return 5.0; // Default assumption for good connection
    }

    // Rough estimation based on API response times
    if (avgApiTime < 200) return 10.0;      // Very fast
    if (avgApiTime < 500) return 5.0;       // Fast
    if (avgApiTime < 1000) return 3.0;      // Good
    if (avgApiTime < 2000) return 1.5;      // Fair
    if (avgApiTime < 5000) return 0.8;      // Slow
    return 0.3; // Very slow
  }

  // Enhanced method to track API call performance
  trackApiCall(url: string, responseTime: number, status: 'success' | 'error' | 'timeout' = 'success'): void {
    const metric: ApiCallMetrics = {
      url,
      responseTime,
      timestamp: Date.now(),
      status
    };

    this.apiCallMetrics.push(metric);

    // Add logging for API calls
    console.log('📡 API Call tracked:', {
      url: url.substring(url.lastIndexOf('/') + 1), // Show only endpoint name
      responseTime: responseTime + 'ms',
      status: status
    });

    // Keep only the last N API calls
    if (this.apiCallMetrics.length > this.API_METRICS_LIMIT) {
      this.apiCallMetrics.shift();
    }

    // Track consecutive slow requests
    if (responseTime > this.API_SLOW_THRESHOLD) {
      this.consecutiveSlowCount++;
    } else {
      this.consecutiveSlowCount = 0;
    }

    // Calculate metrics
    const avgResponseTime = this.calculateAverageApiResponseTime();
    const isApiSlow = this.isApiResponseSlow(avgResponseTime);
    const networkStability = this.calculateNetworkStability();

    console.log('📊 API Performance:', {
      averageResponseTime: avgResponseTime + 'ms',
      isApiSlow: isApiSlow,
      consecutiveSlowRequests: this.consecutiveSlowCount,
      networkStability: networkStability
    });

    // Update network status with API metrics
    this.updateNetworkStatusWithApiMetrics(avgResponseTime, isApiSlow, networkStability);
  }

  private calculateAverageApiResponseTime(): number {
    if (this.apiCallMetrics.length === 0) return 0;

    // Calculate weighted average (more weight to recent requests)
    const recentMetrics = this.apiCallMetrics.slice(-10);
    const totalTime = recentMetrics.reduce((sum, metric, index) => {
      const weight = (index + 1) / recentMetrics.length;
      return sum + (metric.responseTime * weight);
    }, 0);

    const totalWeight = recentMetrics.reduce((sum, _, index) => {
      return sum + ((index + 1) / recentMetrics.length);
    }, 0);

    return Math.round(totalTime / totalWeight);
  }

  private isApiResponseSlow(avgResponseTime: number): boolean {
    return avgResponseTime > this.API_SLOW_THRESHOLD || this.consecutiveSlowCount >= 2;
  }

  private calculateNetworkStability(): 'stable' | 'unstable' | 'very_unstable' {
    if (this.apiCallMetrics.length < 5) return 'stable';

    const recentMetrics = this.apiCallMetrics.slice(-10);
    const slowRequests = recentMetrics.filter(m => m.responseTime > this.API_SLOW_THRESHOLD).length;
    const errorRequests = recentMetrics.filter(m => m.status === 'error').length;
    const totalRequests = recentMetrics.length;

    const slowRatio = slowRequests / totalRequests;
    const errorRatio = errorRequests / totalRequests;

    if (slowRatio > 0.6 || errorRatio > 0.3 || this.consecutiveSlowCount >= 4) {
      return 'very_unstable';
    } else if (slowRatio > 0.3 || errorRatio > 0.1 || this.consecutiveSlowCount >= 2) {
      return 'unstable';
    }

    return 'stable';
  }

  private updateNetworkStatusWithApiMetrics(
    apiResponseTime: number,
    isApiSlow: boolean,
    networkStability: 'stable' | 'unstable' | 'very_unstable'
  ): void {
    const currentStatus = this.networkStatusSubject.value;
    const newStatus: NetworkStatus = {
      ...currentStatus,
      apiResponseTime,
      isApiSlow,
      consecutiveSlowRequests: this.consecutiveSlowCount,
      networkStability
    };

    this.networkStatusSubject.next(newStatus);
  }

  private handleSpeedResult(speed: number): void {
    const quality = this.getSpeedQuality(speed);
    this.updateNetworkStatus(navigator.onLine, speed, quality);
  }

  // FIXED: Better quality calculation
  private getSpeedQuality(speed: number): 'good' | 'fair' | 'poor' | 'offline' {
    if (!navigator.onLine) return 'offline';
    if (speed === 0) return 'poor';  // Changed from 'offline' to 'poor'
    if (speed < 1.0) return 'poor';  // Very slow connection
    if (speed < 3.0) return 'fair';  // Slow connection
    return 'good';
  }

  private updateNetworkStatus(
    isOnline: boolean,
    speed: number = 0,
    quality?: 'good' | 'fair' | 'poor' | 'offline'
  ): void {
    const currentStatus = this.networkStatusSubject.value;

    // FIXED: Better quality determination
    let finalQuality = quality;
    if (!finalQuality) {
      if (!isOnline) {
        finalQuality = 'offline';
      } else if (speed === 0) {
        finalQuality = 'poor';
      } else {
        finalQuality = this.getSpeedQuality(speed);
      }
    }

    const newStatus: NetworkStatus = {
      ...currentStatus,
      isOnline,
      speed,
      quality: finalQuality
    };

    console.log('🔄 Network status updated:', {
      isOnline: newStatus.isOnline,
      speed: newStatus.speed + ' Mbps',
      quality: newStatus.quality,
      apiResponseTime: newStatus.apiResponseTime + 'ms'
    });

    this.networkStatusSubject.next(newStatus);
  }

  private showNetworkStatusToast(message: string, type: 'warning' | 'success' | 'error'): void {
    this.createToastNotification(message, type);
  }

  private createToastNotification(message: string, type: 'warning' | 'success' | 'error'): void {
    const toast = document.createElement('div');

    const colors = {
      warning: '#ff9800',
      success: '#4caf50',
      error: '#f44336'
    };

    toast.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 10000;
      padding: 15px 20px;
      border-radius: 8px;
      color: white;
      font-weight: bold;
      max-width: 450px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.3);
      background-color: ${colors[type]};
      animation: slideIn 0.3s ease-out;
      font-size: 14px;
      line-height: 1.4;
    `;

    toast.innerHTML = `
      <div style="display: flex; align-items: flex-start; justify-content: space-between;">
        <span style="flex: 1; margin-right: 10px;">${message}</span>
        <button onclick="this.parentElement.parentElement.remove()"
                style="background: none; border: none; color: white; font-size: 18px; cursor: pointer; padding: 0; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center;">×</button>
      </div>
    `;

    // Add animation CSS if not already present
    if (!document.querySelector('#toast-animation-styles')) {
      const style = document.createElement('style');
      style.id = 'toast-animation-styles';
      style.textContent = `
        @keyframes slideIn {
          from { transform: translateX(100%); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
        @keyframes slideOut {
          from { transform: translateX(0); opacity: 1; }
          to { transform: translateX(100%); opacity: 0; }
        }
      `;
      document.head.appendChild(style);
    }

    document.body.appendChild(toast);

    // Auto-remove after duration
    const duration = type === 'error' ? 8000 : type === 'warning' ? 6000 : 4000;
    setTimeout(() => {
      if (toast.parentElement) {
        toast.style.animation = 'slideOut 0.3s ease-in';
        setTimeout(() => toast.remove(), 300);
      }
    }, duration);
  }

  private resetSlowRequestTracking(): void {
    this.consecutiveSlowCount = 0;
  }

  // Public method to get current network status
  getCurrentNetworkStatus(): NetworkStatus {
    return this.networkStatusSubject.value;
  }

  // Public method to manually trigger speed test
  testSpeed(): Promise<number> {
    return this.measureNetworkSpeed();
  }

  // Public method to get API performance metrics
  getApiMetrics(): ApiCallMetrics[] {
    return [...this.apiCallMetrics];
  }

  // Public method to get recent slow requests
  getRecentSlowRequests(): ApiCallMetrics[] {
    return this.apiCallMetrics.filter(metric =>
      metric.responseTime > this.API_SLOW_THRESHOLD &&
      Date.now() - metric.timestamp < 300000 // Last 5 minutes
    );
  }

  // Public method to reset API metrics
  resetApiMetrics(): void {
    this.apiCallMetrics = [];
    this.consecutiveSlowCount = 0;
  }

  // Public method to check if network is currently experiencing issues
  isNetworkExperiencingIssues(): boolean {
    const status = this.getCurrentNetworkStatus();
    return !status.isOnline ||
           status.quality === 'poor' ||
           status.quality === 'fair' ||
           status.isApiSlow ||
           status.networkStability === 'very_unstable';
  }

  // Public method to check if network speed is good
  isNetworkSpeedGood(): boolean {
    const status = this.getCurrentNetworkStatus();
    return status.isOnline && status.quality === 'good';
  }

  // Public method to get network quality score (0-100)
  getNetworkQualityScore(): number {
    const status = this.getCurrentNetworkStatus();

    if (!status.isOnline) return 0;

    let score = 100;

    // Deduct points based on speed
    if (status.speed < 0.5) score -= 50;
    else if (status.speed < 1.5) score -= 30;
    else if (status.speed < 3) score -= 15;

    // Deduct points based on API performance
    if (status.isApiSlow) score -= 20;
    if (status.consecutiveSlowRequests > 2) score -= 15;

    // Deduct points based on stability
    if (status.networkStability === 'very_unstable') score -= 25;
    else if (status.networkStability === 'unstable') score -= 10;

    return Math.max(0, Math.min(100, score));
  }

  ngOnDestroy(): void {
    if (this.networkStabilityCheckInterval) {
      clearInterval(this.networkStabilityCheckInterval);
    }
  }
}
