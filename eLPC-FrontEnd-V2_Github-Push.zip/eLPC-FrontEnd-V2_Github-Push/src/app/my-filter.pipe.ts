import { Pipe, PipeTransform } from '@angular/core';
// import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
@Pipe({
  name: 'myFilter'
})
export class MyFilterPipe implements PipeTransform {

  // transform(value: any, args?: any): any {
    transform(value: any, args1:any,args2:any,args3:any): any {
  // args3='valueStreamTemplateName'
   if(!args1 || args2=='test'){
     return value;
   }
   else{
     args1=args1.toUpperCase();
    //value=value.toUpperCase();
   }
   return value.filter(items=>{
      // items.valueStreamTemplateName=items.valueStreamTemplateName.toUpperCase();
      items[args3]=items[args3].toUpperCase();

      if(args2=='equals'){
        alert(args1);
        if(args1.contains(",")){
          var arr=[];
         
          arr=args1.split(',');
          alert(arr[0]);
          alert(arr[1]);
        }
        // return (items.valueStreamTemplateName==args1||items.modifiedBy==args1||items.modifiedAt==args1)==true;
      return items[args3]==args1==true;
      }
      else if(args2=='notEquals'){
        // return items.valueStreamTemplateName==args1==false;
        return items[args3]==args1==false;
       }
        
      else if(args2=='startsWith'){
// return items.valueStreamTemplateName.startsWith(args1)==true
return items[args3].startsWith(args1)==true
      }
    else if(args2=='endsWith'){
      // return items.valueStreamTemplateName.endsWith(args1)==true
      return items[args3].endsWith(args1)==true
    }
    else if(args2=='contains'){
      // return items.valueStreamTemplateName.indexOf(args1) !== -1
      return items[args3].indexOf(args1) !== -1
    }
else if(args2=='notContains'){
  // return items.name.search(args2)==-1;
  // return items.valueStreamTemplateName.indexOf(args1) == -1
  return items[args3].indexOf(args1) == -1
}
    
  
  
     
    // return items.name.indexOf(args)!= -1      // if letetrs are lowercase then it may create problem..example while searching Fifa
    // return items.valueStreamTemplateName.indexOf(args) < -1 //for contains
     //return items.name.search(args)==-1;//does not contain
    // return items.name==args==false;
  
    //return items.filter(item => item.title.indexOf(args.title) !== -1);
  // return items.title.toLowerCase().indexOf(args.toLowerCse())>-1

   })
  }

}
