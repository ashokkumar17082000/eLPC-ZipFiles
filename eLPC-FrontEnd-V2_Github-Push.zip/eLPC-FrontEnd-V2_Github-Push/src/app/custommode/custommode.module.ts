import { NgModule ,CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomModeComponent } from './custom-mode/custom-mode.component';

import { FormsModule,ReactiveFormsModule  } from '@angular/forms';
import { CustommodeRoutingModule } from './custommode-routing.module';


@NgModule({
  declarations: [CustomModeComponent],
  imports: [
    CommonModule,
    CustommodeRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class CustommodeModule { }
