import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
//import { User } from '../shared/common';
import { User } from 'src/app/main/body/shared/common';
import { Duedate } from 'src/app/Deviation/deviation/deviation'
//import { Audit, AuditDetail, AuditQuestion, AuditAssessor, AuditHintData, TagDetails } from '../calendar/calendar';
import { Audit , AuditDetail, AuditQuestion, AuditAssessor, AuditHintData, TagDetails} from 'src/app/calendar/calendar/calendar';
import { ValueStream } from 'src/app/Valuestream/valuestreams/valuestreamtemplate';
import { SharedService } from 'src/app/service/shared.service';
import { CalendarService } from 'src/app/service/calendar.service';
import { CommonService } from 'src/app/service/common/common.service';
import { ValuestreamTemplateService } from 'src/app/service/common/valuestreamtemplate.service';
import { Router } from '@angular/router';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { QuestionService } from 'src/app/service/question.service';
import { Choice, HintImage, SingleLineText, MultipleLinesText } from 'src/app/Datapool/QuestionModule/questions/question';
import { LanguageService } from 'src/app/language.service';
import { setTime } from 'ngx-bootstrap/chronos/utils/date-setters';
//import { ProcessConfirmation } from '../../../pc/process-confirmation/process-confirmation';
import { ProcessConfirmation } from 'src/app/pc/process-confirmation/process-confirmation';
import { ProcessConfirmationService } from 'src/app/service/common/process-confirmation.service';
import { environment } from 'src/environments/environment';
import { formatDate } from '@angular/common';
import { Deviation } from 'src/app/Deviation/deviation/deviation';
import { saveAs } from 'file-saver';
import { Tag } from 'src/app/Tag/tag/tag';
import { TagService } from 'src/app/service/tag.service';
import $ from 'jquery';
import { EventValidationErrorMessage } from 'calendar-utils';
import { SuperOPLService } from 'src/app/service/superopl.service';
import { SearchService } from 'src/app/service/search.service';

//import { FormBuilder, FormGroup, Validators } from '@angular/forms';
//import { Assessor } from '../assessors/assessortemplate';

@Component({
  selector: 'app-audit',
  templateUrl: './audit.component.html',
  styleUrls: ['./audit.component.css']
})
export class AuditComponent implements OnInit {
  hintData: AuditHintData = new AuditHintData();
  url: HintImage = new HintImage();
  urls: HintImage[] = [];
  deviation: Deviation;
  vsUser: User;
  processConfirmation: ProcessConfirmation = new ProcessConfirmation();

  @ViewChild('auditorDet') public auditorDetailModal: TemplateRef<any>;
  //processConfirmationForm: FormGroup;
  //selectedValueStreamIDOnPC: number;
  //selectedAssessorIDOnPC: number;

  bsModalRef: BsModalRef;
  modalRef: BsModalRef;
  audit: Audit = new Audit();
  auditDetail: AuditDetail = new AuditDetail();
  questionList: AuditQuestion[] = [];
  questionListss: AuditQuestion[] = [];
  valueStreamName:string;
  valueStreamID: number;
  auditList: AuditQuestion[] = [];
  auditQuestion: AuditQuestion = new AuditQuestion();
  selectedValueStreamData: any;
  valueStreamList: ValueStream[] = [];
  valueStreamLists: ValueStream[] = [];
  //assessorList: Assessor[] = [];
  closeResult: string;
  selectedValueStreamID: number;
  answeredPercentage: any;
  otherAssessors: AuditAssessor[] = [];
  isDeviationEntryRequired: boolean = false;
  deviationDescription: string;
  responsibleEmployee: string;
  responsibleEmployeeNTID: string;
  data: any = [];
  @ViewChild('alertPopup') warningModal: TemplateRef<any>;
  @ViewChild('successPopup') successModal: TemplateRef<any>;
  @ViewChild('answerOverView') public answerOverViewModal: TemplateRef<any>;
  @ViewChild('answerOverView1') public answerOverViewModal1: TemplateRef<any>;  
  @ViewChild('questionOverView') public questionOverViewModal: TemplateRef<any>;

  config = {
    animated: false,
    keyboard: true,
    ignoreBackdropClick: true
  };

  choices: Choice[] = [];
  singleLineText: SingleLineText = new SingleLineText();
  multiLineText: MultipleLinesText = new MultipleLinesText();
  isLastQuestion: boolean = false;
  labels: any;
  _subscription: any;
  user: User;
  isQuestionOverviewed: boolean = false;
  deviationTypeID: number;
  managerEmailAddress: string;
  responsibleEmployeeID: any;
  auditAssessorList: AuditAssessor[] = [];
  auditAssessorNameList: string[] = [];
  valueStreamTemplate: any[];
  duedate: Duedate = new Duedate();
  questionoverView: any;
  auditAsr: AuditAssessor;
  isDesktop: boolean = true;
  tagNameList: any;
  tagIDList: any;
  tagList: Tag[] = [];
  multiselectTagIDs:any[]=[];
  data1:any;
  selectedItemValueStreamID: number;
  requiredAttendee: any;
  requiredAttendees: User[] = [];
  requiredAttendeesNTID:String[]=[];
  ngMultiSelectDropdownTagSettings = {};
  ngMultiSelectSelectedTagItem:Tag[];
  duedatecount:number;
 finalDate:any;
 additionalInfoyes:boolean=false;
  //For multi select dropdown - Value stream
  dropdownSettingsValueStream = {};
  multiselectVSIds: number[]=[];
  selectedItemValueStream: ValueStream[] = [];
  ngMultiSelectSelectedItem = [];
  selectedValueStream: ValueStream[]=[];
  selectedValueStreams: any;
  valueStreams: any;
  ifresumeaudit: boolean;
  ValueStreamID: number;
  vsid: number;
  auditansweredquestionlength:number=0;
  valueStreamList1: ValueStream[]=[];
  errorMessage: string;
  activeDirectoryData: any;
  constructor(private modalService: BsModalService, private superOPLService: SuperOPLService, private sharedService: SharedService, private auditService: CalendarService, private questionService: QuestionService,private tagService: TagService,
    private commonService: CommonService, private valueStreamService: ValuestreamTemplateService, private router: Router, private local_label: LanguageService, private processConfirmationService: ProcessConfirmationService,private searchService: SearchService)/*private formBuilder: FormBuilder*/ {
    
    if (this.sharedService.audit != undefined && this.sharedService.audit.auditID > 0) {
    
      this.auditService.audit = this.sharedService.audit;
      this.sharedService.audit = new Audit();
    }
    
    this.audit = this.auditService.audit;
    this.auditService.audit.valueStreamName=null;
    for(let each of this.auditService.audit.valueStreamNames)
                {
                this.auditService.audit.valueStreamName += each+",";
                }
                this.auditService.audit.valueStreamName = this.auditService.audit.valueStreamName.slice(4);
                this.auditService.audit.valueStreamName = this.auditService.audit.valueStreamName.substring(0, this.auditService.audit.valueStreamName.length - 1);
                //console.log("132",this.auditService.audit);
               
               if(this.auditService.audit.isResumeTagDefined) {
               
                this.pendingAuditsByAuditID(this.audit);
               }else {
                //alert(151)
                //console.log("reset the audit",this.audit)
                //this.resetAuditByAuditID(this.audit)
                //this.questionListByAuditID()
                this.pendingAuditsByAuditID(this.audit);
               }
               
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
      this.isDesktop = false;
    }
  }

  
  ngOnInit() {
    
    this.sharedService.hide();
    debugger;
    if(this.auditService.audit.valueStreamIDs.length == 1){
      this.ngMultiSelectSelectedItem = [{"valueStreamID" : this.auditService.audit.valueStreamID, "valueStreamName" : this.auditService.audit.valueStreamName}];
      this.valueStreamName = this.auditService.audit.valueStreamName;
      this.valueStreamID = this.auditService.audit.valueStreamID;
      this.audit.valueStreamName=this.valueStreamName;
      this.audit.valueStreamID=this.valueStreamID;
    }
   
    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
    });
    this.valueStreamService.getValueStreamTemplate().subscribe(res => {
      this.valueStreamTemplate = res;

      // this.valueStreamTemplate.forEach(item => {

      // });
    });
    this.getTagList();
    this.calculateDuration(); 
    setTimeout(function () {
      $("#audits tr").click(function () {
        $(".selected").removeClass('selected');
        $(this).addClass('selected');
      });
    }, 100);

    this.searchService.getSearchResults().subscribe({
      next: (response: any) => {
        if (response && response.value) {
          this.activeDirectoryData = response.value;
          this.data = response.value;
          this.errorMessage = ''; // Clear any previous error messages
        } else {
          this.activeDirectoryData = [];
          this.errorMessage = 'No users found.';
        }
      },
      error: (err) => {
        console.error('Failed to fetch users from Graph API', err);
        this.errorMessage = 'Failed to fetch users. Please try again later.';
      },
    });


    //to avoid the ngContent checked issue, this below code is removed
    // if(this.audit && this.audit.tagTypeID !== 1)
    // {
    // this.modalService.show(this.auditorDetailModal);
    // }

    //this.processConfirmationForm = this.formBuilder.group({
    //  vStream: [" ", Validators.required],
    //  assessor: [" ", Validators.required]
    //});m

    $("modal-container").removeClass("fade");
    
   
    //For multi select dropdown - 
    this.dropdownSettingsValueStream = {
      singleSelection: true,
      idField: 'valueStreamID',
      textField: 'valueStreamName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 5,
      allowSearchFilter: true,
      closeDropDownOnSelection: true
    };
 
  this.ngMultiSelectDropdownTagSettings={
    singleSelection: false,
        idField: 'tagID',
        textField: 'FormattedTag',
        selectAllText: 'Select All',
        unSelectAllText: 'UnSelect All',
        itemsShowLimit: 5,
        allowSearchFilter: true,
        closeDropDownOnSelection: true
  };
  }
  onNgMultiSelectDropdownTagItemSelect(item:Tag){
    this.multiselectTagIDs.push(item.tagID);
  }
  onNgMultiSelectDropdownTagItemDeSelect(item:Tag){
    if(!this.ngMultiSelectSelectedTagItem||this.ngMultiSelectSelectedTagItem.length===0)
  this.ngMultiSelectSelectedTagItem=this.ngMultiSelectSelectedTagItem.filter(x=>x.tagID!==item.tagID)
    }
     SelectedItemVS(valuestreamid : number){
      let auditID = this.audit.auditID; 
      let valueStreamID = valuestreamid;
      this.auditService.auditQuestionsByAuditIDSelectedValuestream(auditID,valueStreamID).subscribe(res => {
        this.questionList = res;
        if (this.questionList && this.questionList.length > 0) {
          //from the response the id order is not in sequence but the Question order is in sequence with the RandomQuestionOrder
          // assigning the new id value to the response
          for (let i = 0; i < this.questionList.length; i++) {
            this.questionList[i].id = i + 1
          }
        }
        if (this.questionList && this.questionList.length < 1) {
          this.alertText = this.labels.default.noQuestionsLinkedWithTag;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          return;
        }
        this.auditQuestion = this.questionList[0];
        this.isAuditStarted = true; //to hide and show the Audit History
      if (this.auditQuestion && this.auditQuestion.questionID === this.questionList[this.questionList.length - 1].questionID) {
        this.isLastQuestion = true;
      }
      this.valueStreamService.getValueStream().subscribe(res => {
        this.valueStreamList = res;
        this.valueStreamList = this.valueStreamList.filter(x => x.valueStreamID == this.audit.valueStreamID); //to show the valuestream from the audit appointment
      }, err => console.error(err));
      this.getQuestionHint(this.auditQuestion.questionID);
          this.BindQuestionData();
        }, err => console.error(err));
     }
    
    onSelectValueStream(item: ValueStream) {
      let onSelectVS = true;
      this.valueStreamID = item.valueStreamID;
      this.valueStreamName = item.valueStreamName;
      this.audit.valueStreamName=this.valueStreamName;
      // this.questionListByAuditID() 
      //let auditID = this.audit.auditID; 
      let valueStreamID = item.valueStreamID;
      this.audit.valueStreamID=this.valueStreamID;
      this.SelectedItemVS(valueStreamID);         
    }
    onDeSelectValueStream() {
        if (!this.ngMultiSelectSelectedItem || this.ngMultiSelectSelectedItem.length === 0)
          this.audit.valueStreamID = 0;
    }

  onFilterChange(value: string) {
  }
  getTagList(){
    this.tagService.getTags().subscribe(res => {
      this.tagList = res;
      this.tagList.forEach(x=>x.FormattedTag=x.tagDisplayName)
      this.tagList=this.tagList.filter(x=>x.tagDisplayName);
    }, err =>console.error(err));
  }
  calculateDuration(){
    this.finalDate=new Date(new Date().setDate(new Date().getDate()+environment.superoplEndDateCount));
     this.duedate.datecount=this.finalDate;
 }
 OnSearch(term: string) {
  // let user = new User();
  // user.firstName = this.responsibleEmployee;
  // this.commonService.activeDirectoryByName(user).subscribe(
  //   res => {
  //     this.data = [];
  //     this.data = res;
  //   },
  //   err => console.error(err)
  // );
  this.data = [];
   this.data = this.searchService.setSearchTerm(term);
}

 onRequiredAttendeeSearch() {
   let user = new User();
   user.firstName = this.requiredAttendee;
   user.isGroupNameRequired = true;
   this.commonService.activeDirectoryByName(user).subscribe(res => {
     this.data1 = [];
     this.data1 = res;
     //console.log("data",this.data);
     
   },
   
     err => console.error(err));
    
 } 
selectRequiredAttendee(user: any) {
//console.log("user name",this.user.userName);
    if (user !== null) {
     
      let x = this.requiredAttendees.filter(x => x.ntid == user.ntid);
     if (x.length == 0){
      if(user.userName==this.responsibleEmployee){
        this.alertText = this.labels.default.SelectedUser;
         this.modalService.show(this.warningModal);
         $("modal-container").removeClass("fade");
         $(".modal-dialog").addClass("modalSize");
         return;
      }
   
     this.requiredAttendees.push(user);
     this.requiredAttendeesNTID.push(user.ntid);
     this.deviation.AddItionalEmployeeNTID=this.requiredAttendeesNTID;
     }
   }
      this.data = [];
   this.requiredAttendee = undefined;
 }
 removeRequiredAttendee(user: any) {

   this.requiredAttendees = this.requiredAttendees.filter(x => x.ntid !== user.ntid);
 }
 onChangedSearch() {
   let user = new User();
   user.firstName = this.responsibleEmployee;
   this.commonService.activeDirectoryByName(user).subscribe(res => {
     this.data = [];
     this.data = res;
   },
     err => console.error(err));
 // fetch remote data from here
 // And reassign the 'data' which is binded to 'data' property.
 }
 selectUsers(user:User){
  this.data = [];
  this.user = user;

  this.responsibleEmployee = user.userName;
  this.responsibleEmployeeNTID = user.ntid;
  this.managerEmailAddress = user.emailAddress;
 }

  loadTag(tagID: number) { // on Tag Hyperlink selection corresponding tag gets loaded
    this.sharedService.show();
    this.sharedService.GetTagModeQuestions(0, tagID, this.router);
  }


  BindQuestionData() {
    //this method fetches the tagID as comma separated string
    var getTagID = new  TagDetails();
    getTagID.questionID = this.auditQuestion.questionID;
    getTagID.responseType = "strTagID";

    //this method fetches the tagID as comma separated string
    var getTagName = new TagDetails();
    getTagName.questionID = this.auditQuestion.questionID;
    getTagName.responseType = "strTagName";

    this.tagNameList = "";
    this.tagIDList = "";

    this.auditService.AuditQuestionLinkedTagDetails(getTagID).subscribe(res => {
      var resultID = res.resultMessage;
      this.auditService.AuditQuestionLinkedTagDetails(getTagName).subscribe(res => {
      this.tagNameList = res.resultMessage;
      this.tagIDList = resultID;
      }, error => console.error(error));
    }, error => console.error(error));

    if (this.auditQuestion && this.auditQuestion.answerTypeID === 3) {
      var QuestionID =this.auditQuestion.questionID
      this.questionService.getChoicesByQuestionID(QuestionID).subscribe(res => {
        this.choices = res;
        if (this.auditQuestion.answer == null || this.auditQuestion.answer == "" || this.auditQuestion.answer == "0") {
          this.auditQuestion.answer = this.auditQuestion.defaultChoiceID.toString();// for default asnwer
        }
        var selectedChoiceID = Number(this.auditQuestion.answer);
        this.choiceSelectionChange(selectedChoiceID);
      }, error => console.error(error));
    }

    if (this.auditQuestion && this.auditQuestion.answerTypeID === 1) {
      this.questionService.singleLineTextByQuestionID(this.auditQuestion.questionID).subscribe(res => {
        this.singleLineText = res[0];
        if (!this.auditQuestion.answer)
          this.auditQuestion.answer = this.singleLineText.defaultValue;

      }, error => console.error(error));

    }

    if (this.auditQuestion && this.auditQuestion.answerTypeID === 2) {
      this.questionService.multipleLinesTextByQuestionID(this.auditQuestion.questionID).subscribe(res => {
        this.multiLineText = res[0];
      }, error => console.error(error));
    }
  }

  AssignDeviationInfo() {
    if (this.auditQuestion.deviation != null) {
      this.urls = this.auditQuestion.deviation.hintImages;
      this.deviationDescription = this.auditQuestion.deviation.deviationDescription;
      this.responsibleEmployee = this.auditQuestion.deviation.responsibleEmployee;
      this.responsibleEmployeeNTID = this.auditQuestion.deviation.responsibleEmpNTID;
      this.managerEmailAddress = this.auditQuestion.deviation.managerEmailAddress;
      this.deviationTypeID = this.auditQuestion.deviation.deviationTypeID;
    }
  }

  updateAuditAssessorNameList(){
    this.auditAssessorNameList = [];
    if(this.auditAssessorList != null){
      this.auditAssessorList.map((a)=> {if(a.userName != null && a.userName.trim() != '' && this.auditAssessorNameList.indexOf(a.userName) < 0){ this.auditAssessorNameList.push(a.userName); }});
    }
    if(this.others != null){

      this.others.map((o)=>{ if(o.userName != null && o.userName.trim() != '' && this.auditAssessorNameList.indexOf(o.userName) < 0){ this.auditAssessorNameList.push(o.userName); } });
    }
  }

  /** Method is responsible to show pending audits */
  open(template: TemplateRef<any>) {
    console.log("329")
    this.modalRef = this.modalService.show(template, this.config);
    this.modalRef.setClass('modal-lg calendar-modal');
  }

  pendingAudits(pendingAudits) {
    this.open(pendingAudits);
  }

  resetAuditByAuditID(audit:Audit){
    this.auditService.resetAuditByAuditID(audit.auditID).subscribe(res => {
      console.log(res)
    }, err => console.error(err));
  }

  //To fetch the pending audit history
  pendingAuditsByAuditID(audit: Audit) {
    let auditID = audit.auditID;
    
    //this method fetches the pending audits
    this.auditService.pendingAuditsByAuditID(auditID).subscribe(res => {
    //  console.log("name",audit.valueStreamName)
    debugger;
      this.auditList = [];
      if(this.auditService.audit.isResumeTagDefined) {
        this.auditList = res;
      }
      
      console.log("477",this.auditList)
      this.valueStreamService.getValueStream().subscribe(res => {
        this.valueStreamList = res;
        this.selectedItemValueStream = [];
   for(let i=0;i<this.audit.valueStreamNames.length;i++){
    let vs = new ValueStream();
    vs.valueStreamName = this.audit.valueStreamNames[i];
    vs.valueStreamID = this.audit.valueStreamIDs[i];
    //this.selectedItemValueStream = [];
    this.selectedItemValueStream.push(vs);
  }
        this.valueStreamLists =this.selectedItemValueStream;
        this.valueStreamList = this.valueStreamList.filter(x => x.valueStreamID == this.audit.valueStreamID);
        this.valueStreamList1 =JSON.parse(JSON.stringify( this.valueStreamLists))
        this.auditService.auditAssessorsByAuditID(audit.auditID).subscribe(res => {
          this.auditAssessorList = res;
          //console.log("490",this.auditService)
          if(this.auditService.audit.isMandatoryAssessorsDefined){
           // alert("isassessordefined")
          }else {
           // alert(491)
            for (let i=0;i< this.auditAssessorList.length;i++) {
                this.auditAssessorList[i].isMandatoryAssessor= false;
            }
          }
          console.log("497 assessorlist",this.auditAssessorList)
          this.updateAuditAssessorNameList();
          let leadAuditor = this.auditAssessorList.filter(x => x.assessorName.toLowerCase() == 'leadauditor');
          if (leadAuditor && leadAuditor.length < 1) {
            let leadAuditorObj: AuditAssessor = new AuditAssessor();
            leadAuditorObj.assessorName = 'LeadAuditor';
            leadAuditorObj.isMandatoryAssessor = true;
            leadAuditorObj.auditID = this.audit.auditID;
            leadAuditorObj.ntid = this.sharedService.ntid;
            leadAuditorObj.userName = this.sharedService.ADdisplayName;

            this.auditAssessorList.push(leadAuditorObj);
          }



          if (this.auditList && this.auditList.length < 1 && this.audit.tagTypeID !== 1) {
            this.modalService.show(this.auditorDetailModal, this.config);
            $("modal-container").removeClass("fade");
          }
          else {
            if (!this.isQuestionOverviewed && this.auditList.length == 0) {
              //this.questionoverView = "temp";
              //this.questionOverView(this.questionoverView, this.questionoverView);
              this.modalService.show(this.questionOverViewModal, this.config);
              $("modal-container").removeClass("fade");
              this.isQuestionOverviewed = true;
            }
          }
        }, err => console.error(err));
      }, err => console.error(err));
    }, err => console.error(err));
  }

  selectedAuditTemplate: AuditQuestion = new AuditQuestion();
  isAuditStarted: boolean = false;
  selectAuditTemplate(audit: AuditQuestion) {

    this.selectedAuditTemplate = audit;
    setTimeout(function () {
      $("#audits tr").click(function () {
        $(".selected").removeClass('selected');
        $(this).addClass('selected');
      });
    }, 100);
  }

  onDropdownOpen(){
    debugger;
    if(this.valueStreamLists!==undefined && this.valueStreamLists!==null && this.valueStreamLists.length>0) {
      this.valueStreamLists=JSON.parse(JSON.stringify(this.valueStreamList1))
      console.log(this.valueStreamList)
    }
    
  
  }
  //To continue the audit which is not answered completely
  resumeAudit() {
    
    this.ifresumeaudit = true;
    //this.calculatePercentage();
    if(!this.selectedAuditTemplate.auditID) {
      this.alertText = this.labels.default.ResumeRow;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      return;
    }
    let auditID = this.selectedAuditTemplate.auditID;
    let auditTemplateID = this.selectedAuditTemplate.auditTemplateID;
    let ValueStreamID = this.selectedAuditTemplate.valueStreamID;

    this.auditService.auditQuestionsByAuditAndTemplateID(auditID, auditTemplateID, ValueStreamID).subscribe(res => {
      this.questionList = res;
      //from the response the id order is not in sequence but the Question order is in sequence with the RandomQuestionOrder
      // assigning the new id value to the response
      for (let i = 0; i < this.questionList.length; i++) {
        this.questionList[i].id = i + 1
      }
      this.isAuditStarted = true; //to hide and show the Audit History
      this.auditQuestion = this.questionList[0];
      
     
      // if(this.audit.tagTypeID == 1){
      //   this.processConfirmationService.getAssessorsByQuestionID(this.auditQuestion.questionID).subscribe(
      //     res => {
      //       this.assessorList = res;
      //       this.assessorList = this.assessorList.filter(x => x.assessorName);

      //     },
      //     err => console.error(err)
      //   );
      // }

      this.AssignDeviationInfo();
      if (this.auditQuestion && this.auditQuestion.questionID === this.questionList[this.questionList.length - 1].questionID) {
        this.isLastQuestion = true;
      }
      this.valueStreamService.getValueStream().subscribe(res => {
        this.valueStreamList = res;
        this.audit.valueStreamID=this.selectedAuditTemplate.valueStreamID;
        this.valueStreamList = this.valueStreamList.filter(x => x.valueStreamID == this.audit.valueStreamID);

        this.auditService.auditAssessorsByAuditID(auditID).subscribe(res => {
          this.auditAssessorList = res;
         // console.log("577 assessorlist",this.auditAssessorList)
          this.updateAuditAssessorNameList();
          let leadAuditor = this.auditAssessorList.filter(x => x.assessorName.toLowerCase() == 'leadauditor');
          if (leadAuditor && leadAuditor.length < 1) {
            let leadAuditorObj: AuditAssessor = new AuditAssessor();
            leadAuditorObj.assessorName = 'LeadAuditor';
            leadAuditorObj.isMandatoryAssessor = true;
            leadAuditorObj.auditID = this.audit.auditID;

            this.auditAssessorList.push(leadAuditorObj);
          }
          this.getQuestionHint(this.auditQuestion.questionID);
          this.BindQuestionData();
          if (this.auditQuestion && this.auditQuestion.auditTemplateID !== 0) {
            this.auditService.auditAssessorsByAuditAndTemplateID(auditID, auditTemplateID).subscribe(res => {
              //
              this.auditAssessorList = res;
             // console.log("594 assessorlist",this.auditAssessorList)
              this.updateAuditAssessorNameList();
              this.auditService.otherAuditAssessorsByAuditAndTemplateID(this.auditQuestion.auditID, this.auditQuestion.auditTemplateID).subscribe(res => {
                this.others = res;
                this.updateAuditAssessorNameList();
              }, err => console.error(err));
            }, err => console.error(err));
          }
          //if(this.audit.tagTypeID !== 1 && (this.questionList && this.questionList.length >0)){
          if (this.audit.tagTypeID !== 1) { //removed question length as it is validated while creating the audit
            this.modalService.show(this.auditorDetailModal);
            $("modal-container").removeClass("fade");
          }
        }, err => console.error(err));
      }, err => console.error(err));
    }, err => console.error(err));
  }

  questionListByAuditID(audit?: Audit) {
    
     let auditID = this.audit.auditID;
    
      this.valueStreamService.getValueStream().subscribe(res => {
        this.valueStreamList = res;
        this.valueStreamList = this.valueStreamList.filter(x => x.valueStreamID == this.audit.valueStreamID); //to show the valuestream from the audit appointment
        this.auditService.auditAssessorsByAuditID(auditID).subscribe(res => {
          this.auditAssessorList = res;
         // console.log("620 assessorlist",this.auditAssessorList)
          this.updateAuditAssessorNameList();
          let leadAuditor = this.auditAssessorList.filter(x => x.assessorName.toLowerCase() == 'leadauditor');
          if (leadAuditor && leadAuditor.length < 1) {
            let leadAuditorObj: AuditAssessor = new AuditAssessor();
            leadAuditorObj.assessorName = 'LeadAuditor';
            leadAuditorObj.isMandatoryAssessor = true;
            leadAuditorObj.auditID = this.audit.auditID;
            this.auditAssessorList.push(leadAuditorObj);
          }
          // this.getQuestionHint(this.auditQuestion.questionID);
         // this.BindQuestionData();
          if (this.audit.tagTypeID !== 1) {
            this.modalService.show(this.auditorDetailModal);
            $("modal-container").removeClass("fade");
          }
         }, err => console.error(err));

     }, err => console.error(err));
   //}, err => console.error(err));
  }


  save(auditQuestion: AuditQuestion) {
   
  }

  calculatePercentage(SkipQues) {
    //to calculate the percentage
   
    console.log("518",this.audit)
    //alert(634)
    
    if(this.audit.tagTypeID ==1 && this.audit.isProgressPercentageDefined || this.audit.tagTypeID ==2 && this.audit.isProgressPercentageDefined ||  this.audit.tagTypeID ==3 && this.audit.isProgressPercentageDefined ||  (this.audit.tagTypeID ==4 && this.audit.isProgressPercentageDefined)) {
      //let answeredQuestions = this.questionList.filter(x => x.answer);
      if(SkipQues== 'skip') {
        this.auditansweredquestionlength +=1;
      } else if (SkipQues == 'previous') {
        if (this.auditansweredquestionlength) {
          this.auditansweredquestionlength -= 1;
        }        
      }else {
        this.auditansweredquestionlength +=1;
      }
      if (this.questionList.length == this.auditansweredquestionlength) {
        this.answeredPercentage = 100;
      }
      else {
        this.answeredPercentage = ((this.auditansweredquestionlength / this.questionList.length) * 100).toFixed(0);
      }
    }else{
      console.log("529")
    }
    if(this.answeredPercentage > 100) {
      this.answeredPercentage = 100
    }
  }

  
  nextQuestion(event: Event, auditQuestion: AuditQuestion, template: any, temp: any ,SkipQues?:string, ) {
   //  validation of deviation details
      //console.log("650",auditQuestion)
      //console.log("653",SkipQues)
      event.preventDefault(); // Prevent the default form submission
      event.stopPropagation(); // Stop further event propagation if necessary
      console.log('Button clicked, method executed');
      debugger;
      if(SkipQues ){
        if(auditQuestion.isAnswerRequired) {
          if (!auditQuestion.answer || auditQuestion.answer == "0") {
            this.alertText = this.labels.default.calendarSkip;
            this.modalService.show(this.warningModal);
            $("modal-container").removeClass("fade");
            $(".modal-dialog").addClass("modalSize");
            return;
          }
          if (auditQuestion.isAnswerRequired && this.isDeviationEntryRequired == true && (this.deviationTypeID == 2 || this.deviationTypeID == 3 || this.deviationTypeID == 5)) {
            if (!this.deviationDescription || !this.audit.valueStreamID ) {
              if (!this.audit.valueStreamID && !this.deviationDescription) {
                this.alertText = this.labels.default.devivationFieldMandatory;
                this.modalService.show(this.warningModal);
                $("modal-container").removeClass("fade");
                $(".modal-dialog").addClass("modalSize");
              }
              else if (!this.audit.valueStreamID && !this.ifresumeaudit == true) {
                this.alertText = this.labels.default.selectValueStream;
                this.modalService.show(this.warningModal);
                $("modal-container").removeClass("fade");
                $(".modal-dialog").addClass("modalSize");
              }
              else if (!this.deviationDescription) {
                this.alertText = this.labels.default.fillDeviationOnly;
                this.modalService.show(this.warningModal);
                $("modal-container").removeClass("fade");
                $(".modal-dialog").addClass("modalSize");
              }
              
              return false;
            }
          }
          if(auditQuestion.answer) {
            this.alertText = this.labels.default.NoSkip;
            this.modalService.show(this.warningModal);
            $("modal-container").removeClass("fade");
            $(".modal-dialog").addClass("modalSize");
            return;
          }

          if(!auditQuestion.answer || auditQuestion.answer == "0" ||auditQuestion.answer == "" || SkipQues){
            //  auditQuestion.answer= 'Question Skipped';
              //auditQuestion.isAnswered = true;
              if((auditQuestion.answerTypeID ==3 ||auditQuestion.answerTypeID ==5) && SkipQues ){
                auditQuestion.answer = null;
                auditQuestion.isAnswered = false;
              }
            
            }
          
        }else { 
          if(auditQuestion.answer && !(auditQuestion.answer == "0" ||auditQuestion.answer == "")) {
            this.alertText = this.labels.default.NoSkip;
            this.modalService.show(this.warningModal);
            $("modal-container").removeClass("fade");
            $(".modal-dialog").addClass("modalSize");
            return;
          }

          if(!auditQuestion.answer || auditQuestion.answer == "0" ||auditQuestion.answer == "" || SkipQues){
            //  auditQuestion.answer= 'Question Skipped';
              //auditQuestion.isAnswered = true;
              if((auditQuestion.answerTypeID ==3 ||auditQuestion.answerTypeID ==5) && SkipQues ){
                auditQuestion.answer = null;
                auditQuestion.isAnswered = false;
              }
              auditQuestion.answer= null;
              auditQuestion.isAnswered=false;
            }
        }
       
        
        //console.log("inside skip button")
      }
      else {
              if (auditQuestion.isAnswerRequired && this.isDeviationEntryRequired == true && (this.deviationTypeID == 2 || this.deviationTypeID == 3 || this.deviationTypeID == 5)) {
                if (!this.deviationDescription || !this.audit.valueStreamID ) {
                  if (!this.audit.valueStreamID && !this.deviationDescription) {
                    this.alertText = this.labels.default.devivationFieldMandatory;
                    this.modalService.show(this.warningModal);
                    $("modal-container").removeClass("fade");
                    $(".modal-dialog").addClass("modalSize");
                  }
                  else if (!this.audit.valueStreamID && !this.ifresumeaudit == true) {
                    this.alertText = this.labels.default.selectValueStream;
                    this.modalService.show(this.warningModal);
                    $("modal-container").removeClass("fade");
                    $(".modal-dialog").addClass("modalSize");
                  }
                  else if (!this.deviationDescription) {
                    this.alertText = this.labels.default.fillDeviationOnly;
                    this.modalService.show(this.warningModal);
                    $("modal-container").removeClass("fade");
                    $(".modal-dialog").addClass("modalSize");
                  }
                  
                  return false;
                }
              }
              // **************deviation details validation ends************
              // if(this.audit.tagTypeID !==1){
              //    this.insertAssessorDetail('alertPopup','questionOverView');
              //  }
                if (auditQuestion.isAnswerRequired) {
                  // if(SkipQues){
                  //   console.log("685")
                  //   auditQuestion.answer='Question Skipped'
                  // }else {
                    if (!auditQuestion.answer || auditQuestion.answer == "0") {
                      this.alertText = this.labels.default.fillAnswer;
                      this.modalService.show(this.warningModal);
                      $("modal-container").removeClass("fade");
                      $(".modal-dialog").addClass("modalSize");
                      return;
                    }
                  // }
                
                }else if(!auditQuestion.answer || auditQuestion.answer == "0") {
                  console.log("hello")
                  this.alertText = this.labels.default.fillAnswer;
                  this.modalService.show(this.warningModal);
                  $("modal-container").removeClass("fade");
                  $(".modal-dialog").addClass("modalSize");
                  return;
                }
              
              
              let x = this.auditAssessorList.filter(x => x.ntid == '' || x.ntid == undefined || x.ntid == null);
              if (x && x.length > 1) {
                let y = x.filter(x => x.isMandatoryAssessor);
                if (y && y.length > 1) {
                  this.alertText = this.labels.default.fillMandatoryAssessors;
                  this.modalService.show(this.warningModal);
                  $("modal-container").removeClass("fade");
                  $(".modal-dialog").addClass("modalSize");
                  //to show the assessor list
                  this.modalService.show(this.auditorDetailModal);
                  $("modal-container").removeClass("fade");
                  return;
                }
              }
              
              if (!this.audit.valueStreamID && !this.ifresumeaudit == true) {
                this.alertText = this.labels.default.selectValueStream;
                this.modalService.show(this.warningModal);
                $("modal-container").removeClass("fade");
                $(".modal-dialog").addClass("modalSize");
                return;
              }
  }
    //if(this.audit.tagTypeID == 1 &&  auditQuestion.assessorID == null){
    //  this.alertText = this.labels.default.selectAssessor;
    //  this.modalService.show(this.warningModal);
    //  $("modal-container").removeClass("fade");
    //  $(".modal-dialog").addClass("modalSize");
    //  return;
    //}

    //to validate if all the questions are answered
    if (this.isLastQuestion) {
      console.log("603")
      let x = this.questionList.filter(x => x.isDefaultAnswerRequired && !x.answer);
      if (x && x.length > 0) {
        this.alertText = this.labels.default.answerAllQuestion;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        return;
      }
    }
    
    this.calculatePercentage(SkipQues);
    let questionID = this.auditQuestion.questionID;
    let id = this.auditQuestion.id + 1;
    this.auditQuestion.modifiedBy_NTID = this.sharedService.ntid;
    if (!this.auditQuestion.createdBy_NTID) {
      this.auditQuestion.createdBy_NTID = this.sharedService.ntid;
    }
    this.auditQuestion.auditAssessors = this.auditAssessorList;
//
    this.auditQuestion.others = this.others;
    //this.auditQuestion.createdAt = new Date(localStorage.getItem("AnsweredTimeStamp"));
    //this method will insert the question with answer and will fetch the question list from Audit Answered table 
    

      this.sharedService.show();
    this.auditService.addEditAuditQuestion(this.auditQuestion).subscribe(res => {
      // **************************************deviation handler***************
      //to send the deviation email based on deviation type
    
      this.deviation = new Deviation();
      if ((this.deviationTypeID > 1) && (this.deviationDescription != "")) {
         if( this.ifresumeaudit == true){
          this.valueStreamService.valueStreamByValueStreamID(this.audit.valueStreamID).subscribe(res => {
            this.deviation.valueStreamName = res[0].valueStreamName;
           })
         }
           else {
        this.valueStreamService.valueStreamByValueStreamID(this.audit.valueStreamID).subscribe(res => {
          this.deviation.valueStreamName = res[0].valueStreamName;
        })
      }
      this.deviation.selectedTagData=this.ngMultiSelectSelectedTagItem;
        this.deviation.deviationDescription = this.deviationDescription;
        this.deviation.responsibleEmployee = this.responsibleEmployee;
        this.deviation.deviationTypeID = this.deviationTypeID;
        if (this.sharedService.emailAddress) {
          this.deviation.userEmailAddress = this.sharedService.emailAddress;
        }
        this.deviation.managerEmailAddress = this.managerEmailAddress;
        this.deviation.questionID = this.auditQuestion.questionID;
        this.deviation.questionDisplayID = this.auditQuestion.questionDisplayID;
        this.deviation.questionText = this.auditQuestion.questionText;
        this.deviation.questionChoiceAnswer = this.auditQuestion.choiceAnswer;
        this.duedate.datecount= new Date(this.duedate.datecount);
        this.duedate.datecount= new Date(Date.UTC( this.duedate.datecount.getFullYear(), this.duedate.datecount.getMonth(), this.duedate.datecount.getDate()));
         this.deviation.duedatecount=this.duedate.datecount;
         this.deviation.AdditionalEmployee=this.requiredAttendees;
         this.deviation.questionLinkedTags= this.audit.tagDisplayName;
        // this.questionService.tagsByQuestionID(auditQuestion.questionID).subscribe(res => {
        //   if(res != null && res.length > 0)
        //   {
        //     this.deviation.questionLinkedTags = res.map(e => e.tagDisplayName).join(";");
        //   }
        // })
         if( this.ifresumeaudit  == true){
           this.deviation.valueStreamID = this.audit.valueStreamID;
        }
         else{
        this.deviation.valueStreamID = this.audit.valueStreamID;
       }
        this.deviation.valueStreamName = this.selectedValueStreamData;
        this.deviation.responsibleEmpNTID = this.responsibleEmployeeNTID;
        this.deviation.hintImages = this.urls;
        this.deviation.auditTemplateID = (this.auditQuestion.auditTemplateID != null && this.auditQuestion.auditTemplateID > 0 ) ? this.auditQuestion.auditTemplateID : 0;
        this.deviation.auditID = this.auditQuestion.auditID;
        if (this.sharedService.ntid) {
          this.deviation.createdBy_NTID = this.sharedService.ntid;
          this.deviation.modifiedBy_NTID = this.sharedService.ntid;
        }

        if (this.vsUser) {
          this.processAndSendEmail();
        }
        else {
          if (this.valueStreamList && this.valueStreamList.length > 0) {
            this.responsibleEmployeeID = this.valueStreamList.filter(x => x.valueStreamID == this.deviation.valueStreamID)[0]!.responsible_UserID;
            this.commonService.getUserByNTID(this.responsibleEmployeeID).subscribe(res => {
              this.vsUser = res;
              this.processAndSendEmail();
            });
          }
          else {
            this.valueStreamService.valueStreamByValueStreamID(this.deviation.valueStreamID).subscribe(
              res => {
                this.responsibleEmployeeID = res[0].responsible_UserID;
                this.commonService.getUserByNTID(this.responsibleEmployeeID).subscribe(res => {
                  this.vsUser = res;
                  this.processAndSendEmail();
                });
              }
            )
          }
        }
      }
      else {
        this.sharedService.hide();
        this.clearDeviation();
      }

      // if(this.audit.tagTypeID == 1){
      //   this.processConfirmationService.getAssessorsByQuestionID(this.auditQuestion.questionID).subscribe(
      //     res => {
      //       this.assessorList = res;
      //       this.assessorList = this.assessorList.filter(x => x.assessorName);

      //     },
      //     err => console.error(err)
      //   );
      // }

      //
      // ****************************************deviation handler ends****************
      if (!this.auditQuestion.auditTemplateID) {
       // alert(858)
        this.auditService.auditQuestionsByCurrentAssessorAndTemplateID(this.auditQuestion.auditID, this.sharedService.ntid).subscribe(res => {
          if (res && res.length > 0) {            console.log("fsfwf",this.questionList)
            console.log(res)
            // Creating a map from the firstArray for quick lookup
            const orderMap = this.questionList.reduce((map, item, index) => {
              map[item.questionID] = index;
              return map;
            }, {});

        // Sorting secondArray based on the order in firstArray
            res.sort((a, b) => orderMap[a.questionID] - orderMap[b.questionID]);
            this.questionList = res;
            //from the response the id order is not in sequence but the Question order is in sequence with the RandomQuestionOrder
            // assigning the new id value to the response
            for (let i = 0; i < this.questionList.length; i++) {
              this.questionList[i].id = i + 1
            }
            if (this.questionList[0].auditTemplateID != 0 && res.length != 1) {
              this.auditQuestion.auditTemplateID = this.questionList[0].auditTemplateID;
              this.deviation.auditTemplateID=this.auditQuestion.auditTemplateID;
            }
            //If first question is of type choice then add choice answer
            if (this.auditQuestion.choiceAnswer != null && this.auditQuestion.choiceAnswer != "")
            {
              this.questionList[0].choiceAnswer = this.auditQuestion.choiceAnswer;
              this.questionList[0].deviation = this.deviation;
            }
          }

          if (this.auditQuestion && this.auditQuestion.questionID === this.questionList[this.questionList.length - 1].questionID) {
            this.isLastQuestion = true;
          }

          if (!this.isLastQuestion) {
           
            this.auditQuestion = new AuditQuestion();
            this.auditQuestion = this.questionList.filter(x => x.id == id)[0];
          }

          //
          if (this.isLastQuestion) {
            this.isAuditStarted = false;
            console.log("752",this.audit.isResultOverviewDefined)
            if(this.audit.tagTypeID ==1 && this.audit.isResultOverviewDefined || this.audit.tagTypeID ==2 && this.audit.isResultOverviewDefined||  this.audit.tagTypeID ==3 && this.audit.isResultOverviewDefined ||  (this.audit.tagTypeID ==4 && this.audit.isResultOverviewDefined)) {
              this.modalService.show(this.answerOverViewModal, this.config);
              $("modal-container").removeClass("fade");
            }else {
              console.log("else",this.answerOverViewModal1)
              console.log("759",this.config)
              this.modalService.show(this.answerOverViewModal1, this.config);
              $("modal-container").removeClass("fade");
            }
            
            return false;
          }
          this.getQuestionHint(this.auditQuestion.questionID);
          this.BindQuestionData();
        }, err => console.error(err));
      }
      else {
        //
        if (this.auditQuestion && this.auditQuestion.questionID === this.questionList[this.questionList.length - 1].questionID) {
          this.isLastQuestion = true;
        }

        if (!this.isLastQuestion) {
          this.auditQuestion = new AuditQuestion();
          this.auditQuestion = this.questionList.filter(x => x.id == id)[0];
        }

        if (this.isLastQuestion) {
          //
          console.log("770",this.audit)
          console.log("771",this.audit.isResultOverviewDefined)
          if(this.audit.tagTypeID ==1 && this.audit.isResultOverviewDefined || this.audit.tagTypeID ==2 && this.audit.isResultOverviewDefined||  this.audit.tagTypeID ==3 && this.audit.isResultOverviewDefined ||  (this.audit.tagTypeID ==4 && this.audit.isResultOverviewDefined)) {
            this.modalService.show(this.answerOverViewModal, this.config);
            $("modal-container").removeClass("fade");
          }else {
            console.log("else",this.answerOverViewModal1)
            console.log("759",this.config)
            this.modalService.show(this.answerOverViewModal1, this.config);
            $("modal-container").removeClass("fade");
          }
          // this.modalService.show(this.answerOverViewModal, this.config);
          // $("modal-container").removeClass("fade");
          return false;
        }
        this.getQuestionHint(this.auditQuestion.questionID);
        //this.BindQuestionData();
        if (this.auditQuestion && this.auditQuestion.auditTemplateID !== 0) {
          this.auditService.auditAssessorsByAuditAndTemplateID(this.auditQuestion.auditID, this.auditQuestion.auditTemplateID).subscribe(res => {
            this.auditAssessorList = res;
            //console.log("965 assessorlist",this.auditAssessorList)
            this.updateAuditAssessorNameList();
            this.auditService.otherAuditAssessorsByAuditAndTemplateID(this.auditQuestion.auditID, this.auditQuestion.auditTemplateID).subscribe(res => {
              this.others = res;
              this.updateAuditAssessorNameList();
              this.BindQuestionData();
            }, err => console.error(err));
          }, err => console.error(err));
        }
      }
    }, error => console.error(error));
  
  }

  processAndSendEmail() {
    console.log("813",this.audit)
    if (!this.isDeviationEntryRequired) {
      this.clearDeviation();
      this.sharedService.hide();
      return;
    }

    if (!this.deviation.responsibleEmployee) {
      if (this.vsUser) {
        this.deviation.responsibleEmployee = this.vsUser.userName;
        this.deviation.managerEmailAddress = this.vsUser.emailAddress;
      }
    }
    if (this.vsUser) {
      this.deviation.owner = this.vsUser.userName;
      this.deviation.ownerNTID = this.vsUser.ntid;
      this.deviation.responsibleEmployeeEmailAddress = this.vsUser.emailAddress;
      this.deviation.createdBy_Name = this.sharedService.displayName;
      this.deviation.CreatedByEmployee = this.sharedService.ADdisplayName;
    }

    this.questionList.forEach(element => {
      if (element.questionID == this.deviation.questionID) {
        element.deviation = this.deviation;
      }
    });
    this.commonService.insertIntoAuditDeviation(this.deviation).subscribe(res => {

      this.sharedService.hide();
      this.clearDeviation();
    }, err => {
      this.sharedService.hide();
      this.clearDeviation();
    });

    // this.commonService.insertIntoDeviation(this.deviation).subscribe(res => {
    //   if(this.deviationTypeID == 3)
    //   {
    //     this.commonService.CreateDeviationSuperOPL(this.deviation);
    //   }
    //   this.commonService.sendDeviationEmail(this.deviation).subscribe(res =>{
    //     this.clearDeviation();
    //     this.sharedService.hide();
    //   },
    //   err => {
    //     this.clearDeviation();
    //     this.sharedService.hide();
    //   })
    // });
  }


  removeHintImage(name) {
    this.urls = this.urls.filter(x => x.imageTitle !== name);
  }

    previousQuestion(auditQuestion: AuditQuestion) {

    this.calculatePercentage('previous')
    let id = this.auditQuestion.id - 1;
    let previousQuestion = this.questionList.filter(x => x.id == id)[0];
    if (previousQuestion) {
      this.auditQuestion = new AuditQuestion();
      this.auditQuestion = previousQuestion;
      this.getQuestionHint(this.auditQuestion.questionID);
      if (this.auditQuestion && this.auditQuestion.answerTypeID === 3) {
        var QuestionID=this.auditQuestion.questionID;
        this.questionService.getChoicesByQuestionID(QuestionID).subscribe(res => {
          if(res.length >0 && res !=null){
                this.choices = res;
                if (this.auditQuestion.answer == null || this.auditQuestion.answer == "" || this.auditQuestion.answer == "0") {
                  this.auditQuestion.answer = this.auditQuestion.defaultChoiceID.toString();// for default asnwer
                }
                var selectedChoiceID = Number(this.auditQuestion.answer);
                this.choiceSelectionChange(selectedChoiceID);
           }else {
            
           }
        }, error => console.error(error));
        
      }
      this.isLastQuestion = false;
    }
  }
  skipQuestion(auditQuestion: AuditQuestion) {

    let id = this.auditQuestion.id + 1;
    this.auditQuestion = new AuditQuestion();
    this.auditQuestion = this.questionList.filter(x => x.id == id)[0];
  }

  //public valueStreamOnChange(event): void {

  //  const newVal = event.target.value;
  //  this.selectedValueStreamData = this.valueStreamList.filter(x => x.valueStreamID == newVal)[0].valueStreamData;
  //}

  //----------modal pop up for Asessor details
  auditorDetail(auditorDet, event) {
    if (this.audit.tagTypeID !== 1) {
      this.open(auditorDet);
    }
  }

  //processConfDetail(processconfDet, event) {
  //  if (this.audit.tagTypeID == 1) {
  //    this.selectedValueStreamIDOnPC = this.audit.valueStreamID;

  //    this.modalRef = this.modalService.show(processconfDet, this.config);
  //    this.modalRef.setClass('modal-lg');
  //    //this.open(processconfDet);
  //  }
  //}

  questionOverView(questionOverView, event) {
    console.log("901",this.auditService.audit)
    console.log("901",this.audit)
    console.log("902",this.audit.isQuestionOverviewDefined)
    if(this.audit.tagTypeID ==1  && this.audit.isQuestionOverviewDefined || this.audit.tagTypeID ==2  && this.audit.isQuestionOverviewDefined ||  this.audit.tagTypeID ==3  && this.audit.isQuestionOverviewDefined ||  (this.audit.tagTypeID ==4   && this.audit.isQuestionOverviewDefined)){
      this.open(questionOverView);
    }else {
      console.log("overviewnotdefined")
    }
   
  }

  answerOverView(answerOverView, event) {
   
    console.log("916",this.audit)
    console.log("917",this.audit.isResultOverviewDefined)
    if(this.audit.isResultOverviewDefined){
    this.open(answerOverView);
    }
  }

  //---for Active Directory Search and audit detail
  keyword = 'userName';
  hod: User = new User();
  leadAuditor: User = new User();
  floorManager: User = new User();
  qmm: User = new User();
  others: AuditAssessor[] = [];

  hodSelection(item) {
    this.hod = item;
  }
  leadAuditorSelection(item) {
    this.leadAuditor = item;
  }
  floorManagerSelection(item) {
    this.floorManager = item;
  }
  qmmSelection(item) {
    this.qmm = item;
  }
  selectEvent(item) {

    // if (item !== null) {
    //   let x = this.others.filter(x => x.ntid == item.ntid);
    //   if (x.length == 0)
    //     this.others.push(item);
    // }
    if (item !== null) {
      let x = this.others.filter(x => x.ntid == item.ntid);
      if (x.length == 0) {
        this.auditAsr = new AuditAssessor();
        this.auditAsr.userName = item.userName;
        this.auditAsr.ntid = item.ntid;
        this.auditAsr.isMandatoryAssessor = false;
        this.auditAsr.auditID = this.audit.auditID;
        this.others.push(this.auditAsr);
      }
    }
    this.data = [];
  }

  removeUser(ntid: any) {
    //let ntid = event.target.id;

    this.others = this.others.filter(x => x.ntid !== ntid);
  }

  // **********************responsible user***************
  onChangeSearch(val: string) {
    //
    this.currentRowSelection = undefined; //for hiding the search results in other dropdowns
    let user = new User();
    user.firstName = val;
    this.commonService.activeDirectoryByName(user).subscribe(res => {
      this.data = [];
      this.data = res;
    },
      err => console.error(err));
    // fetch remote data from here
    // And reassign the 'data' which is binded to 'data' property.
  }


  onFocused(e) {
    // do something when input is focused
  }

  onClose() {
    this.bsModalRef.hide();
  }

  //for new Active Directory Search
  currentRowSelection: any;
  onAssessorSearch(val: any, i: number) {

     this.currentRowSelection = i;
    // let user = new User();
    // user.firstName = val;
    // this.commonService.activeDirectoryByName(user).subscribe(res => {
    //   this.data = [];
    //   this.data = res;
    // },
    //   err => console.error(err));
    this.searchService.setSearchTerm(val);
    console.log(this.activeDirectoryData)
  }

  selectAssessor(user: any, i: number) {

    this.currentRowSelection = i;
    if (user !== null) {
      let x = this.data.filter(x => x.ntid == user.ntid)[0];
      if (x) {
        //let asr = this.auditAssessorList.filter(x =>x.assessorName == assessorName)[0];
        this.auditAssessorList[i].userName = x.displayName;
        this.auditAssessorList[i].ntid = x.ntid;
      }
    }
    this.data = [];
  }

  updateAudit() {
    this.modalRef.hide();
  }

  public insertAuditDetail() {

    this.auditDetail.auditID = this.audit.auditID;
    this.auditDetail.valueStreamID = this.selectedValueStreamID;
    this.auditDetail.leadAuditor = this.leadAuditor;
    this.auditDetail.hod = this.hod;
    this.auditDetail.floorManager = this.floorManager;
    this.auditDetail.qmm = this.qmm;
    this.auditDetail.others = this.others;
    this.auditService.insertAuditDetail(this.auditDetail).subscribe(res => {
      this.modalRef.hide();
    }, err => console.error(err));
  }
  alertText;
  modalRef2: BsModalRef;
  public insertAssessorDetail(template: any, temp: any) {
    //
    debugger
    console.log("1030",template,temp)
    let x = this.auditAssessorList.filter(x => x.ntid == '' || x.ntid == undefined || x.ntid == null || x.userName);
    if (x && x.length > 0) {
      let y = x.filter(x => x.isMandatoryAssessor);
      if (y && y.length > 0) {
        this.alertText = this.labels.default.fillMandatoryAssessors;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        return;
      }
    }
   
     

    if (this.ngMultiSelectSelectedItem == undefined && !this.ifresumeaudit == true) {
      this.alertText = this.labels.default.selectValueStream;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      return;
    }
    if(!this.ifresumeaudit == true){
      this.SelectedItemVS(this.audit.valueStreamID);
    }
    this.updateAuditAssessorNameList();

    this.closeAlertModal();
    if (!this.isQuestionOverviewed) {
      console.log("1058",temp)
      this.questionOverView(temp, null);
      this.isQuestionOverviewed = true;
    }
  }

  //public insertprocessConfAssessorDetail(template: any, temp: any) {
  //  
  //  if (!this.selectedAssessorIDOnPC) {
  //    this.alertText = this.labels.default.fillMandatoryAssessors;
  //    this.modalService.show(this.warningModal);
  //    $("modal-container").removeClass("fade");
  //    $(".modal-dialog").addClass("modalSize");
  //    return;
  //  }
  //  if (!this.selectedValueStreamIDOnPC) {
  //    this.alertText = this.labels.default.selectValueStream;
  //    this.modalService.show(this.warningModal);
  //    $("modal-container").removeClass("fade");
  //    $(".modal-dialog").addClass("modalSize");
  //    return;
  //  }

  //  let assessor = this.assessorList.filter(x => x.assessorID == this.selectedAssessorIDOnPC);
  //  if (assessor != null && assessor.length > 0) {
  //    this.auditQuestion.assessorID = assessor[0].assessorID;
  //    this.auditQuestion.assessorName = assessor[0].assessorName;
  //  }

  //  this.closeAlertModal();
  //  if (!this.isQuestionOverviewed) {
  //    this.questionOverView(temp, null);
  //    this.isQuestionOverviewed = true;
  //  }
  //}

  closeAlertModal() {
    if (document.getElementsByTagName("modal-container").length > 1) {
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1]);
    }
    else {
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if (document.getElementsByTagName("bs-modal-backdrop").length > 0) {
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }

  }

  async ProcessDeviation(question: AuditQuestion) {
    if (question.deviation.deviationTypeID == 3) {
      var request = this.superOPLService.CreateDeviationSuperOPL(question.deviation);
      var superOPLList: any = environment.superopl != undefined ? Object.values(JSON.parse(environment.superopl)) : [];
      var result = superOPLList;
      if (result != null && result.length > 0) {
        (await this.superOPLService.createOPLTask(request, result[0].oplID, result[0].apiKey, question.deviation)).subscribe(async res => {
          if (res != "") {
            console.log("1115",res)
            await this.SendEmail(question.deviation, res);
          }
          else {
            console.log("1119",res)
           await  this.SendEmail(question.deviation, null);
          }
        },
          async err => {
            console.log("1124")
            await this.SendEmail(question.deviation, null);
            this.sharedService.hide();
            console.log(err);
          });
      }
    }
    else if (question.deviation.deviationTypeID == 5) {
      var request = await this.superOPLService.CreateDeviationSuperOPL(question.deviation);
      var superOPLList: any = environment.superopl != undefined ? Object.values(JSON.parse(environment.superopl)) : [];
      var result = superOPLList;
      if (result != null && result.length > 0) {
        (await this.superOPLService.createOPLTask(request, result[0].oplID, result[0].apiKey, question.deviation)).subscribe(async res => {
          if (res != "") {
           await  this.SendEmail(question.deviation, res);
          }
          else {
            this.SendEmail(question.deviation, null);
          }
        },
          err => {
            this.SendEmail(question.deviation, null);
            this.sharedService.hide();
            console.log(err);
          });
      }
    }
    else if (question.deviation.deviationTypeID == 2) {
      console.log("1132")
      this.SendEmail(question.deviation, null);
    }
    else if (question.deviation.deviationTypeID == 4) {
      console.log("1136")
      this.sharedService.hide();
    }
  }

  completeAuditAlertModal() {
    if (document.getElementsByTagName("modal-container").length > 1) {
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1]);
    }
    else {
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if (document.getElementsByTagName("bs-modal-backdrop").length > 0) {
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }
    this.sharedService.show();
    for (var i = 0; i < this.questionList.length; i++) {
      var question = this.questionList[i];
      if (question.deviation != null && (question.deviation.deviationTypeID > 1)) {
        this.ProcessDeviation(question);
      }
    }
    
    let auditID = this.auditQuestion.auditID;
    let auditTemplateID = this.questionList.length == 1 ? this.questionList[0].auditTemplateID : this.auditQuestion.auditTemplateID;
    var audit = new Audit();
    audit.auditID =  auditID;
    audit.templateID = auditTemplateID;
    audit.languageCode = this.sharedService.plantLanguageCode;
    if (this.audit.tagTypeID == 1)
    {
      audit.tagName = "#" + this.audit.tagName;
      audit.tagTypeName = this.labels.default.vsProcessConfirmation;

    }
    else if (this.audit.tagTypeID == 2) {
      audit.tagName = "#" + this.audit.tagName;
      audit.tagTypeName = this.labels.default.vsAudit;

    }
    else if (this.audit.tagTypeID == 3) {
      audit.tagName = "#" + this.audit.tagName;
      audit.tagTypeName = this.labels.default.vsSurvey;
    }
    else if (this.audit.tagTypeID == 4) {
      audit.tagName = "#" + this.audit.tagName;
      audit.tagTypeName = this.labels.default.vsGlobal;
    }
    this.auditService.completeAuditByAuditAndTemplateID(auditID, auditTemplateID).subscribe(res => {
      
      this.alertText = this.labels.default.dataSentSuccessfully;
      this.modalService.show(this.successModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      console.log("1226",this.audit)
      //console.log("1374",audit)
      if(this.audit.tagTypeID ==1 && this.audit.isReportingEmailDefined || this.audit.tagTypeID ==2 && this.audit.isReportingEmailDefined||  this.audit.tagTypeID ==3 && this.audit.isReportingEmailDefined ||  (this.audit.tagTypeID ==4 && this.audit.isReportingEmailDefined)){
        
         
        this.auditService.SendAuditAnswerEmail(audit).subscribe(res => {
        }, err => { });
      }
      this.router.navigate(['/' + environment.home + '/calendar']); 
    }, err => { });
  }

  private async SendEmail(deviation, OPLTaskID) {
    if(OPLTaskID != null)
    {
      deviation.superOPLURL = environment.superOPLTaskURL + OPLTaskID.toString();
    }
    else
    {
      if (deviation.superOPLURL == environment.superOPLTaskURL) {
        deviation.superOPLURL = "";
      }

      var superOPLList: any = environment.superopl != undefined ? Object.values(JSON.parse(environment.superopl)) : [];
      if (superOPLList != null && superOPLList.length > 0) {
        deviation.superOPLNewTaskURL = environment.superOPLPortalURL + superOPLList[0].oplID;
      }
    }
    await this.commonService.sendDeviationEmail(deviation).subscribe(res => {
      this.sharedService.hide();
    },
      err => {
        this.sharedService.hide();
      });
  }

  closeAuditAlertModal() {
    if (document.getElementsByTagName("modal-container").length > 1) {
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1]);
    }
    else {
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if (document.getElementsByTagName("bs-modal-backdrop").length > 0) {
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }
  }

  public valueStreamOnChange(event): void {

    const newVal = event.target.value;
    this.selectedValueStreamData = this.valueStreamList.filter(x => x.valueStreamID == newVal)[0].valueStreamData;
    this.selectedValueStreamID = this.valueStreamList.filter(x => x.valueStreamID == newVal)[0].valueStreamID;
    this.loadDefaultVSResponsibleUser();
  }

  loadDefaultVSResponsibleUser() {
  
       if( this.ifresumeaudit == true){
        this.audit.valueStreamID=this.selectedAuditTemplate.valueStreamID
       var responsibleEmployeeID = this.valueStreamList.filter(
        x => x.valueStreamID == this.selectedAuditTemplate.valueStreamID
       )[0].responsible_UserID;
     }
      else{
     var responsibleEmployeeID = this.valueStreamList.filter(
      x => x.valueStreamID == this.audit.valueStreamID
     )[0].responsible_UserID;
    }
    if (responsibleEmployeeID) {
      this.commonService.getUserByNTID(responsibleEmployeeID).subscribe(res => {
        this.vsUser = res;
        if (this.vsUser != null && this.vsUser.ntid.length > 0) {
          this.selectUser(this.vsUser);
        }
      });
    }
  }

  //for default value change
  choiceSelectionChange(id: number) {
    if (id > 0) {
      this.deviationTypeID = this.choices.filter(x => x.choiceID == id)[0].deviationTypeID;
      if (this.deviationTypeID > 1) {
        this.isDeviationEntryRequired = true;
        this.loadDefaultVSResponsibleUser();
      }
      else {
        this.isDeviationEntryRequired = false;
        this.deviation = new Deviation();
        this.deviationDescription = undefined;
        this.responsibleEmployee = undefined;
      }
      this.auditQuestion.choiceAnswer = this.choices.filter(x => x.choiceID == id)[0].choiceName;
      this.AssignDeviationInfo();
    }
  }

  // ************************selectign the file************
  // *******************Image atatchment selection************************
  onSelectFile(event) {
    //validate the file if file size is more than 10MB
    for (var i = 0; i < event.target.files.length; i++) {
      var name = event.target.files[i].name;
      var type = event.target.files[i].type;
      var size = event.target.files[i].size;
      var modifiedDate = event.target.files[i].lastModifiedDate;

      if (size > environment.maxFileSize) {
        this.alertText = this.labels.default.maximumFileSize;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        return;
      }
    }
    // *************************validation of file size ends here**************

    let now = new Date();
    var jstoday;
    jstoday = formatDate(now, 'dd_MM_yyyy hh_mm_ss_a', 'en-US', '+0530').toString();

    let totalSize = 0;
    if (event.target.files && event.target.files[0]) {
      var filesAmount = event.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        let name = event.target.files[i].name;

        //  ************************ validation of file Type*********************************************************************************

        //if (!name.match(/.(jpg|jpeg|png|gif|txt|pdf|doc|docx|xls|xlsx|csv|mp4)$/i))

          var fileTypes = environment.fileTypes.split(",").map(function (item) {
            return item.trim();
          });
          var extension = name.slice((Math.max(0, name.lastIndexOf(".")) || Infinity) + 1);
          let x = fileTypes.filter(x => x.toLocaleLowerCase() == extension.toLocaleLowerCase());
    
          if (x.length == 0) {
            this.alertText = name + this.labels.default.fileUploadError.replace("((FileTypes))", environment.fileTypes);
            this.modalService.show(this.warningModal);
            $("modal-container").removeClass("fade");
            $(".modal-dialog").addClass("modalSize");
            return;
          }
       
        //  *************************Validation Ends*****************************************************************************************
        let size = event.target.files[i].size;
        reader.onload = (event: any) => {
          this.url = new HintImage();
          this.url.imageTitle = jstoday + "_" + name;
          this.url.displayFileName = name; //adding displayname

          this.url.size = size;
          this.url.fileContent = event.target.result;

          this.url.imagePath = event.target.path;
          
          if (extension == "jpg" || extension == "jpeg" || extension == "png") {
            var compressed = this.sharedService.compressImage(event.target.result, "image/jpeg", 0.5, 0.9);
            if (compressed != "data:,")
              this.url.fileContent = compressed;
          }


          for (let row of this.urls) {
            totalSize += row.size;
          }
          totalSize += size;
          if (totalSize > (environment.maxFileSize*environment.maxAttachments) || this.urls.length >= environment.maxAttachments) {
            this.alertText = name + this.labels.default.maximumFileSize;
            this.modalService.show(this.warningModal);
            $("modal-container").removeClass("fade");
            $(".modal-dialog").addClass("modalSize");
            return;
          }
          if (this.urls == undefined) {
            this.urls = [];
          }
          this.urls.push(this.url);
        };

        reader.readAsDataURL(event.target.files[i]);
      }
    }
  }
  // *************************file selection end************

  //active directory search
  selectUser(user: User) {
    this.responsibleEmployee = user.userName;
    this.data = [];
    this.user = user;

    this.responsibleEmployee = user.displayName;
    this.responsibleEmployeeNTID = user.ntid;
    this.managerEmailAddress = user.emailAddress;
  }
  onChangeDeviationSearch() {
    let user = new User();
    user.firstName = this.responsibleEmployee;
    this.commonService.activeDirectoryByName(user).subscribe(
      res => {
        this.data = [];
        this.data = res;
      },
      err => console.error(err)
    );
    // fetch remote data from here
    // And reassign the 'data' which is binded to 'data' property.
  }
  // clear the previous selected deviation
  clearDeviation() {
    this.deviation = new Deviation();
    this.deviationDescription = undefined;
    this.responsibleEmployee = undefined;
    this.requiredAttendees=[];
    this.ngMultiSelectSelectedTagItem=undefined;
    this.duedate.datecount=this.finalDate;
    this.urls = [];
    this.isDeviationEntryRequired = false; // to clear the values so that it will be removed from cache
    this.deviationTypeID = undefined;
    this.additionalInfoyes=false;
  }

  droppedImage: any;
  droppedImageName: any;


  base64toBlob(base64Data, contentType) {
    contentType = contentType || '';
    var sliceSize = 1024;
    var byteCharacters = atob(base64Data);
    var bytesLength = byteCharacters.length;
    var slicesCount = Math.ceil(bytesLength / sliceSize);
    var byteArrays = new Array(slicesCount);

    for (var sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {
      var begin = sliceIndex * sliceSize;
      var end = Math.min(begin + sliceSize, bytesLength);

      var bytes = new Array(end - begin);
      for (var offset = begin, i = 0; offset < end; ++i, ++offset) {
        bytes[i] = byteCharacters[offset].charCodeAt(0);
      }
      byteArrays[sliceIndex] = new Uint8Array(bytes);
    }
    return new Blob(byteArrays, { type: contentType });
  }

  getDroppedImage(url: any) {
    let fileName = url.imageTitle;
    let checkFileType = "." + fileName.split('.').pop();
    var fileType = this.sharedService.GetMIMETypeByExtenstion(checkFileType);

    this.droppedImage = url.fileContent;
    this.droppedImageName = url.imageTitle;
    this.alertText = name + this.labels.default.droppedImageName;

    let base64Str = url.fileContent.split(';base64,').pop();
    var blob = this.base64toBlob(base64Str, fileType)
    saveAs(blob, fileName);

    if (checkFileType != ".png" && checkFileType != ".jpg" && checkFileType != ".jpeg") {
      this.closeAlertModal();
    }

  }

  DownloadProcessConfirmationHintImages(titlename: string) {
    //
    //  var name =this.items.filter(x => x.questionID == ID)[0].imageTitle;
    var name = titlename;

    let fileName = name;
    //file type extension
    // let checkFileType =  fileName.split('.').pop();
    let checkFileType = "." + fileName.split('.').pop();
    var fileType = this.sharedService.GetMIMETypeByExtenstion(checkFileType);


    this.questionService.DownloadQuestionAttachment(fileName, fileType)
      .subscribe(
        success => {
          saveAs(success, fileName);
        },
        err => {
          this.alertText = this.labels.default.serverErrorLoadingFile;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          console.log(err);
        }
      );
  }

  getQuestionHint(questionID: any) {
    //

    this.hintData.QuestionHintText = this.auditQuestion.questionHintText;
    this.hintData.ImageURLs = [];
    this.hintData.HyperLinkURLs = [];

    this.hintData.TitleList = [];
    this.hintData.DisplayList = [];
    var _this = this;

    this.questionService.hintImagesByQuestionID(questionID).subscribe(res => {
      _this.hintData.ImageURLs = res;

      this.questionService.hintHyperLinksByQuestionID(questionID).subscribe(res => {
        for (var i = 0; i < res.length; i++) {
          _this.hintData.HyperLinkURLs.push(res[i].hyperLinkURL);
        }

        for (var i = 0; i < _this.hintData.ImageURLs.length; i++) {
          if (_this.hintData.ImageURLs[i].displayFileName || _this.hintData.ImageURLs[i].imageTitle) {
            _this.hintData.DisplayList.push(_this.hintData.ImageURLs[i].displayFileName);
            _this.hintData.TitleList.push(_this.hintData.ImageURLs[i].imageTitle);
          }
        }
      }, err => console.log(err));
    }, err => console.log(err));
  }

  //for data validation
  MultiPleLineText(event, oField) {
    //
    // if(!this.selectedValueStreamID || !this.selectedAssessorID){
    //   this.open(contentShift);
    // }
    var textLines = oField.value.substr(0, oField.selectionStart).split("\n");
    var currentLineNumber = textLines.length;
    var currentColumnIndex = textLines[textLines.length - 1].length;

    var text = this.auditQuestion.answer;
    if (this.auditQuestion.answer) {
      var lines = text.toString().split(/\r|\r\n|\n/);
      var count = lines.length;
    }

    if ((count >= this.multiLineText.maxLines)) {
      // alert("can not type more than"+" " +this.multiLineText[0].maxLines+" "+"Lines for this question");
      this.alertText = this.labels.default.cannotTypeMoreLinesForThisQuestion + " " + this.multiLineText.maxLines;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      event.preventDefault();
      return;
    }
    else if ((currentLineNumber <= this.multiLineText.maxLines && count > this.multiLineText.maxLines)) {
      event.preventDefault();
      return;
    } else {
      //console.log("currentLineNumber:" + currentLineNumber + "maxcount:" + this.multiLineText[0].maxLines + "count:" + count);
    }

  }

  goToLink(url: string) {

    if (url.toLocaleLowerCase().includes('https://') || url.toLocaleLowerCase().includes('http://')) {
      window.open(url, "_blank");
    }
    else {
      window.open('//' + url, "_blank");
    }
  }

}




//====================================

