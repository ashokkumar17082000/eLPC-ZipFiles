import { Component, OnInit, ElementRef, ViewChild, TemplateRef } from '@angular/core';
//import { ProcessConfirmation } from 'src/app/main/body/process-confirmation/process-confirmation';
import { ProcessConfirmation } from 'src/app/pc/process-confirmation/process-confirmation';
import { ValueStream } from 'src/app/Valuestream/valuestreams/valuestreamtemplate';
import { ValuestreamTemplateService } from 'src/app/service/common/valuestreamtemplate.service';
import { AssessorTemplateService } from 'src/app/service/assessor/assessortemplate.service';
import { Assessor } from 'src/app/Assessor/assessor/assessortemplate';
import { HintImage, Question } from 'src/app/Datapool/QuestionModule/questions/question';
import { User } from 'src/app/main/body/shared/common';
import { Tag } from 'src/app/Tag/tag/tag';
import { TagService } from 'src/app/service/tag.service';
import { CommonService } from 'src/app/service/common/common.service';
import { Duedate } from './deviation';
import { DatePipe } from '@angular/common';
import { Tag1 } from './deviation';
import { Deviation } from './deviation';
import { DeviationService } from 'src/app/service/deviation.service';
import { Router } from '@angular/router';
import { DataPoolService } from 'src/app/service/data-pool.service';
import { SharedService } from 'src/app/service/shared.service';
import { LanguageService } from 'src/app/language.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { environment } from 'src/environments/environment';
import { formatDate } from '@angular/common';
import { SuperOPLService } from 'src/app/service/superopl.service';
import { SearchService } from 'src/app/service/search.service';

@Component({
  selector: 'app-deviation',
  templateUrl: './deviation.component.html',
  styleUrls: ['./deviation.component.css']
})
export class DeviationComponent implements OnInit {
  question: Question = new Question();
  
  @ViewChild('alertPopup') warningModal : TemplateRef<any>;
  @ViewChild('successPopup') successModal : TemplateRef<any>;
  @ViewChild('fileInput') fileInputVariable: ElementRef;
  alertText: string;
  deviation:Deviation=new Deviation();
  valueStreamList:ValueStream[]=[];
  assessorList: Assessor[] = [];
  duedate: Duedate = new Duedate();
  tag1: Tag1 = new Tag1();
  url: HintImage = new HintImage();
  urls: HintImage[] = [];
  urltemp: HintImage[] = [];
  
  user: User = new User();
  users: User[] = [];
  tagList: Tag[] = [];
  multiselectTagIDs:any[]=[];
  data: any;
  data1:any;
  usr: any;
  isAdd: boolean;
  isEdit: boolean;
  selectedUser: string;
  userName: string;
  requiredAttendee: any;
  requiredAttendees: User[] = [];
  requiredAttendeesNTID:String[]=[];
  labels: any;
  _subscription: any;
  selectedValueStreamID: any;
  selectedTagID:number[]=[];
  selectedTagData:any;
  selectedValueStreamData: string;
  selectedValueStreamManagerNTID: string;
  vsUser: User
 duedatecount:number;
 finalDate:any;
 emp:any[]=[];
  //For multi select dropdown - single selection
  ngMultiSelectDropdownSettings = {};
  ngMultiSelectSelectedItem: ValueStream[];

  ngMultiSelectDropdownTagSettings = {};
  ngMultiSelectSelectedTagItem:Tag[];
  errorMessage: string;


  constructor( private modalService: BsModalService,private superOPLService : SuperOPLService,  private local_label: LanguageService, private valuestreamService:ValuestreamTemplateService,private tagService: TagService,private assessorService:AssessorTemplateService,private sharedService: SharedService,
    private commonService: CommonService, private router: Router,private searchService: SearchService) {
    this.data = [];
    this.user = this.commonService.user;
    this.commonService.user = undefined;
    if (this.user == undefined) {
      this.isAdd = true;
      this.isEdit = false;
      this.user = new User();
    }
    else if (Object.keys(this.user).length == 0) {
      this.isAdd = true;
      this.isEdit = false;
      this.user = new User();
    }
    else {
      this.isAdd = false;
      this.isEdit = true;
      this.selectedUser = "";
      this.commonService.getUserByNTID(this.user.ntid).subscribe(res =>{
      
        let usr = res;
        this.deviation.responsibleEmployee = usr.userName;
        this.user = usr;
       },
      err => console.error(err));

    }
    this.deviation.additionalInfoyes=false;
   }

  ngOnInit() {
    this.getValueStreamAndAssessorList();
    this.getTagList();
   this.calculateDuration(); 

    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
    });
this.ngMultiSelectDropdownTagSettings={
  singleSelection: false,
      idField: 'tagID',
      textField: 'FormattedTag',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 5,
      allowSearchFilter: true,
      closeDropDownOnSelection: true
};
    //For multi select dropdown - single selection
    this.ngMultiSelectDropdownSettings = {
      singleSelection: true,
      idField: 'valueStreamID',
      textField: 'FormattedValueStream',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 5,
      allowSearchFilter: true, 
      closeDropDownOnSelection: true
    };

    
    this.searchService.getSearchResults().subscribe({
      next: (response: any) => {
        if (response && response.value) {

          this.data = response.value;
          this.errorMessage = ''; // Clear any previous error messages
        } else {
          this.data = [];
          this.errorMessage = 'No users found.';
        }
      },
      error: (err) => {
        console.error('Failed to fetch users from Graph API', err);
        this.errorMessage = 'Failed to fetch users. Please try again later.';
      }
    });


    this.searchService.getSearchResults_optional().subscribe({
      next: (response: any) => {
        if (response && response.value) {

          this.data1 = response.value;
          this.errorMessage = ''; // Clear any previous error messages
        } else {
          this.data1 = [];
          this.errorMessage = 'No users found.';
        }
      },
      error: (err) => {
        console.error('Failed to fetch users from Graph API', err);
        this.errorMessage = 'Failed to fetch users. Please try again later.';
      }
    });

  }

  
  onNgMultiSelectDropdownTagItemSelect(item:Tag){
    this.multiselectTagIDs.push(item.tagID);
  //  this.deviation.selectedTag=this.multiselectTagIDs;
   // console.log("tag",this.deviation.selectedTag);

    // this.ngMultiSelectSelectedTagItem= this.multiselectTagIDs;
   


    // this.selectedTagData = this.tagList.filter(x => x.tagID == this.multiselectTagIDs)[0].tagName;
    // this.selectedTagData=this.tagList.filter(x => x.tagID==this.multiselectTagIDs)[0].tagName;
    
  }
  onNgMultiSelectDropdownTagItemDeSelect(item:Tag){
  if(!this.ngMultiSelectSelectedTagItem||this.ngMultiSelectSelectedTagItem.length===0)
this.ngMultiSelectSelectedTagItem=this.ngMultiSelectSelectedTagItem.filter(x=>x.tagID!==item.tagID)
//this.deviation.selectedTag=[];
//this.audit.valueStreamIDs = [];
  }
  onNgMultiSelectDropdownItemSelect(item: ValueStream) {
    this.deviation.valueStreamID = item.valueStreamID;
    this.selectedValueStreamID = item.valueStreamID;
    this.selectedValueStreamData = this.valueStreamList.filter(x => x.valueStreamID == this.selectedValueStreamID)[0].valueStreamName;
    this.selectedValueStreamManagerNTID = this.valueStreamList.filter(x => x.valueStreamID == this.selectedValueStreamID)[0].responsible_UserID;
    if (this.selectedValueStreamManagerNTID) {
      this.commonService.getUserByNTID(this.selectedValueStreamManagerNTID).subscribe(res => {
        this.vsUser = res;
        if (this.vsUser != null && this.vsUser.ntid.length > 0) {
          this.selectUser(this.vsUser);
        }
      });
    }
  }
  onNgMultiSelectDropdownItemDeSelect() {
    if (!this.ngMultiSelectSelectedItem || this.ngMultiSelectSelectedItem.length === 0) {
      this.deviation.valueStreamID = 0;
      this.selectedValueStreamID = 0;
    }
  }

  redirect()
  {
    console.log(this.deviation.hintImages);
    this.commonService.deletetempAttachments(this.deviation).subscribe( res => {
    res.insertedID = res.resultCode;  });
    this.router.navigate([environment.home +'/dashboard']);
  }
  loadTag(){
    this.tagService.getTags().subscribe(res => {
      this.tagList = res;
      this.tagList.forEach(x=>x.FormattedTag=x.tagDisplayName)
      this.tagList=this.tagList.filter(x=>x.tagDisplayName);
    }, err =>console.error(err));
  }

  getTagList(){
    
    this.tagService.getTags().subscribe(res => {
      this.tagList = res;
      this.tagList.forEach(x=>x.FormattedTag=x.tagDisplayName)
      this.tagList=this.tagList.filter(x=>x.tagDisplayName);
    }, err =>console.error(err));
  }

  getValueStreamAndAssessorList(){
    this.valuestreamService.getValueStream().subscribe(res =>{
      this.valueStreamList = res;
      this.valueStreamList.forEach(x => x.FormattedValueStream = x.valueStreamTemplateName + x.delimiter + x.valueStreamName );
      this.valueStreamList = this.valueStreamList.filter(x => x.valueStreamName && x.responsibleEmployee);
      this.assessorService.getAssessors().subscribe(res=>{
        this.assessorList = res;
          // this.availableTags = this.tagList;
      }, err =>console.error(err));
    }, err =>console.error(err));
  }

  //  increaseValue() {
  //   var value = parseInt(document.getElementById('number').value, 10);
  //   value = isNaN(value) ? 0 : value;
  //   value++;
  //   document.getElementById('number').value = value;
  // }
  
  // decreaseValue() {
  //   var value = parseInt(document.getElementById('number').value, 10);
  //   value = isNaN(value) ? 0 : value;
  //   value < 1 ? value = 1 : '';
  //   value--;
  //   document.getElementById('number').value = value;
  // }

  calculateDuration(){
     this.finalDate=new Date(new Date().setDate(new Date().getDate()+environment.superoplEndDateCount));
      this.duedate.datecount=this.finalDate;
  }


  onRequiredAttendeeSearch(term: string) {
    // let user = new User();
    // user.firstName = this.requiredAttendee;
    // user.isGroupNameRequired = true;
    // this.commonService.activeDirectoryByName(user).subscribe(res => {
    //   this.data1 = [];
    //   this.data1 = res;
    //   //console.log("data",this.data);
      
    // },
    
    //   err => console.error(err));
    this.searchService.setSearchTerm_optional(term);
     
  } 
selectRequiredAttendee(user: any) {
//console.log("user name",this.user.userName);
     if (user !== null) {
      
       let x = this.requiredAttendees.filter(x => x.ntid == user.ntid);
      if (x.length == 0){
       if(user.userName==this.deviation.responsibleEmployee){
         this.alertText = this.labels.default.SelectedUser;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          return;
       }
       if (user.userPrincipalName && user.userPrincipalName.includes('@')) {
        user.ntid  = user.userPrincipalName.split('@')[0].toUpperCase();
      }
      this.requiredAttendees.push(user);
      this.requiredAttendeesNTID.push(user.ntid);
      this.deviation.AddItionalEmployeeNTID=this.requiredAttendeesNTID;
      }
    }
       this.data = [];
    this.requiredAttendee = undefined;
  }
  removeRequiredAttendee(user: any) {

    this.requiredAttendees = this.requiredAttendees.filter(x => x.ntid !== user.ntid);
  }
  onChangeSearch(term: string) {
    // let user = new User();
    // user.firstName = this.deviation.responsibleEmployee;
    // this.commonService.activeDirectoryByName(user).subscribe(res => {
    //   this.data = [];
    //   this.data = res;
    // },
    //   err => console.error(err));
  // fetch remote data from here
 
  // And reassign the 'data' which is binded to 'data' property.
    console.log("332")
  this.searchService.setSearchTerm(term);
  }
  selectUser(user:User){
    //debugger;
    this.deviation.responsibleEmployee = user?.displayName || user?.userName;
    this.deviation.managerEmailAddress = user.mail; //Responsible Employee EmailID from UI TextBox
    if (user.userPrincipalName && user.userPrincipalName.includes('@')) {
      user.ntid  = user.userPrincipalName.split('@')[0].toUpperCase();

    }

    this.deviation.responsibleEmpNTID = user.ntid;
    this.data = [];
    this.user = user;
  }

// *******************Image atatchment selection************************
onSelectFile(event) {


  //validate the file if file size is more than 10MB
  for (var j = 0; j < event.target.files.length; j++) { 
    var name = event.target.files[j].name;
    var type = event.target.files[j].type;
    var size = event.target.files[j].size;
    var modifiedDate = event.target.files[j].lastModifiedDate;

    if(size > environment.maxFileSize){
      this.alertText = this.labels.default.maximumFileSize;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      return;
    }
    
    // console.log ('Name: ' + name + "\n" + 
    //   'Type: ' + type + "\n" +
    //   'Last-Modified-Date: ' + modifiedDate + "\n" +
    //   'Size: ' + Math.round(size / 1024) + " KB");
  }
// *************************validation of file size ends here**************

  
  let now = new Date();
  var  jstoday;
  jstoday = formatDate(now, 'dd_MM_yyyy hh_mm_ss_a', 'en-US', '+0530').toString();
  let flagfiles=0 ;
  let totalSize = 0;
  if (event.target.files && event.target.files[0]) {
    var filesAmount = event.target.files.length;
    for (let i = 0; i < filesAmount; i++) {
      var reader = new FileReader();
      let name = event.target.files[i].name;

      
      //  ************************ validation of file Type*********************************************************************************
      // if (!name.match(/.(jpg|jpeg|png|gif|txt|pdf|doc|docx|xls|xlsx|csv|mp4)$/i)){
      var fileTypes = environment.fileTypes.split(",").map(function (item) {
        return item.trim();
      });
      var extension = name.slice((Math.max(0, name.lastIndexOf(".")) || Infinity) + 1);
      let x = fileTypes.filter(x => x.toLocaleLowerCase() == extension.toLocaleLowerCase());
      
      if (x.length == 0) {
        this.alertText = name + this.labels.default.fileUploadError.replace("((FileTypes))", environment.fileTypes);
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        return;
      }
     
      //  *************************Validation Ends*****************************************************************************************
      let size = event.target.files[i].size;
      reader.onload = (event: any) => {
  
        this.url = new HintImage();
        this.url.imageTitle =jstoday+"_"+ name;
        this.url.displayFileName = name;


        this.url.size = size;
        this.url.fileContent = event.target.result;

        if (extension == "jpg" || extension == "jpeg" || extension == "png") {
          var compressed = this.sharedService.compressImage(event.target.result, "image/jpeg", 0.5, 0.9);
          if (compressed != "data:,")
            this.url.fileContent = compressed;
        }

        for (let row of this.urls) {
          totalSize += row.size;
        }
        totalSize += size;
        if (totalSize > (environment.maxFileSize*environment.maxAttachments) || this.urls.length >= environment.maxAttachments) {
          this.alertText = this.labels.default.maximumFileSize;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          return;
        }
        if (this.urls == undefined) {
          this.urls = [];
        }
        this.urls.push(this.url);


       
        //Upload file Code 

        this.deviation.hintImages=this.urls;
        this.insertIntoDeviationAttachments(this.deviation,flagfiles,filesAmount);
        flagfiles=flagfiles+1;
      }

      reader.readAsDataURL(event.target.files[i]);

    }
   
  }


 // this.fileInputVariable.nativeElement.value = "";


}

// *************************remove attachment******************

removeHintImage(name) {

  this.urltemp = this.urls.filter(x => x.imageTitle == name);
  this.deviation.hintImages=this.urltemp;
  this.commonService.deletetempAttachments(this.deviation).subscribe( res => {
  res.insertedID = res.resultCode;  });
    this.urls = this.urls.filter(x => x.imageTitle !== name);
  }
// ******************************************Image atatchemnt end***********************************************
public valueStreamOnChange(event): void {  

  this.selectedValueStreamID = event.target.value;
  this.selectedValueStreamData = this.valueStreamList.filter(x=>x.valueStreamID==this.selectedValueStreamID)[0].valueStreamName;

  this.selectedValueStreamManagerNTID = this.valueStreamList.filter(x=>x.valueStreamID==this.selectedValueStreamID)[0].responsible_UserID;
  if(this.selectedValueStreamManagerNTID){
  this.commonService.getUserByNTID(this.selectedValueStreamManagerNTID).subscribe(res =>{
    this.vsUser = res;
  })
}

} 

  public  insertIntoDeviation(deviation:Deviation){
    
    this.deviation.selectedTagData=this.ngMultiSelectSelectedTagItem;
  
  //  if(!deviation.selectedTagData){
  //     this.alertText = "select Tag";
  //     this.modalService.show(this.warningModal);
  //     $("modal-container").removeClass("fade");
  //     $(".modal-dialog").addClass("modalSize");
  //     return false;
  //   }
    if (!deviation.valueStreamID || !deviation.deviationDescription ) {
      if (!deviation.valueStreamID && !deviation.deviationDescription  ) {
        this.alertText = this.labels.default.devivationFieldMandatory;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
      }
      else if (!deviation.valueStreamID) {
        this.alertText = this.labels.default.selectValueStream;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
      }
      
      else if (!deviation.deviationDescription) {
        this.alertText = this.labels.default.fillDeviationOnly;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
      }
    
     return false;
    }

    this.sharedService.show();
    this.deviation.deviationTypeID = 99; //99 - Document A deviation
    this.deviation.deviationDescription = this.deviation.deviationDescription;
    this.deviation.createdBy_NTID=this.sharedService.ntid;
    if(this.sharedService.emailAddress){
      this.deviation.userEmailAddress = this.sharedService.emailAddress;
    }
    this.deviation.valueStreamName = this.selectedValueStreamData;
    // let today=new Date();
    // let specifiedDate=30;
    // let finalDate=new Date(today.getTime()+(specifiedDate*24*60*60*1000));
    
    // if(this.finalDate!=this.duedate.datecount){
    //   this.deviation.duedatecount=this.duedate.datecount;
    // }

    this.duedate.datecount= new Date(this.duedate.datecount);
    this.duedate.datecount= new Date(Date.UTC( this.duedate.datecount.getFullYear(), this.duedate.datecount.getMonth(), this.duedate.datecount.getDate()));
     this.deviation.duedatecount=this.duedate.datecount;
    if(!this.deviation.managerEmailAddress)
    {
       if(this.vsUser){ 
         this.deviation.responsibleEmployee = this.vsUser.userName;
         this.deviation.managerEmailAddress = this.vsUser.emailAddress;

       }
    }
    this.deviation.hintImages = this.urls; //mk

    if(this.vsUser){
      this.deviation.owner = this.vsUser.userName;
      this.deviation.ownerNTID = this.vsUser.ntid;
      this.deviation.responsibleEmployeeEmailAddress = this.vsUser.emailAddress;

    }
 
this.deviation.AdditionalEmployee=this.requiredAttendees;
//  console.log("inside else");
    this.commonService.insertIntoDeviation(deviation).subscribe( res => {
    deviation.deviationId = res.insertedID;
    this.alertText = this.labels.default.insertedSuccessfully;
    this.modalService.show(this.successModal);
    $("modal-container").removeClass("fade");
    $(".modal-dialog").addClass("modalSize");
    this.router.navigate([environment.home +'/dashboard'])
    deviation.createdBy_Name = this.sharedService.displayName;
    deviation.CreatedByEmployee = this.sharedService.ADdisplayName;
   var request =  this.superOPLService.CreateDeviationSuperOPL(deviation);
    if(deviation.AddItionalEmployeeNTID!=null){
      
      for(let each of deviation.AddItionalEmployeeNTID){
     
             // infoEmp+=","+each+",";
             request.informationTo.push(each);
              
      }

    }
   var superOPLList: any = environment.superopl != undefined ? Object.values(JSON.parse(environment.superopl)) : [];
    var result = superOPLList;
    if (result != null && result.length > 0) {
        ( this.superOPLService.createOPLTask(request, result[0].oplID, result[0].apiKey, deviation)).subscribe( res => {
       
        if (res != "") {
           this.SendEmail(deviation,res);
        }
        else
        {
           this.SendEmail(deviation, null);
        }
      },
       err => {
         this.SendEmail(deviation, null);
        this.sharedService.hide();
        console.log(err);
      });
    }
  });

   
  }

  //to Upload Files on Click of Select File
  insertIntoDeviationAttachments(deviation:Deviation,i: number,filesAmount:number)
  {
    if((filesAmount-i)==1)

    {
    this.deviation.createdBy_NTID=this.sharedService.ntid;

    this.deviation.hintImages = this.urls; //mk
 
    if(this.deviation.hintImages.length >0)
    {
      console.log("Working Code ");
      this.commonService.insertIntoDeviationAttachments(deviation).subscribe( res => {
      deviation.auditID = res.resultCode;  });
    }

    }

    else
    {
      console.log("IGNORE");
    }
 
  }

  private  SendEmail(deviation, OPLTaskID) {
    if(OPLTaskID != null)
    {
      deviation.superOPLURL = environment.superOPLTaskURL + OPLTaskID.toString();
    }
    else
    {
      if (deviation.superOPLURL == environment.superOPLTaskURL) {
        deviation.superOPLURL = "";
      }
      
      var superOPLList: any = environment.superopl != undefined ? Object.values(JSON.parse(environment.superopl)) : [];
      if (superOPLList != null && superOPLList.length > 0) {
        deviation.superOPLNewTaskURL = environment.superOPLPortalURL + superOPLList[0].oplID;
      }
    }
     this.commonService.sendDeviationEmail(deviation).subscribe(res => {
      this.sharedService.hide();
    },
      err => {
        this.sharedService.hide();
      });
  }
  
   //to fix scroll issue after pop up
   public closeAlertModal(){
    if(document.getElementsByTagName("modal-container").length > 1){
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length-1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length-1]);
    }
    else{
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if(document.getElementsByTagName("bs-modal-backdrop").length > 0){
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }
  }

}
