import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DeviationDataPoolComponent } from '../deviation-data-pool/deviation-data-pool.component';
const routes: Routes = [
  { path: '', component: DeviationDataPoolComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DeviationDPRoutingModule { }
