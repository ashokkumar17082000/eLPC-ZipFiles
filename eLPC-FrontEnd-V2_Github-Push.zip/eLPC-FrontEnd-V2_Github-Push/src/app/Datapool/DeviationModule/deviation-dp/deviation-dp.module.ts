import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DeviationDataPoolComponent } from '../deviation-data-pool/deviation-data-pool.component';
import { DeviationDPRoutingModule } from './deviation-dp-routing.module';
import { FormsModule,ReactiveFormsModule  } from '@angular/forms';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { NgxPaginationModule } from 'ngx-pagination';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { OrderModule } from 'ngx-order-pipe';
import { DatePipe } from '@angular/common';
import { SharedModule } from '../../../shared/shared.module'
import { PopoverModule } from 'ngx-bootstrap/popover';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { ModalModule } from 'ngx-bootstrap/modal';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { AlertModule } from 'ngx-bootstrap/alert';
import { CarouselModule } from 'ngx-bootstrap/carousel';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { ProgressbarModule } from 'ngx-bootstrap/progressbar';
//import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { MyFilterPipe } from 'src/app/my-filter.pipe';
import { AutocompleteLibModule } from 'angular-ng-autocomplete';
import { SafeHtmlPipe } from 'src/app/service/common/safeHtml.pipe';

import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NO_ERRORS_SCHEMA } from '@angular/core';
//import { UserProfileValueStream, UserProfileAssessor, UserProfileValueStreamAssessor, usercustomIcon } from  '../userprofile-c/userProfile';;
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
@NgModule({
  declarations: [DeviationDataPoolComponent],
  imports: [
    CommonModule,
    DeviationDPRoutingModule,
    OrderModule,
    AutocompleteLibModule,
    FormsModule,
    FormsModule,
    ReactiveFormsModule,
    PaginationModule.forRoot(),
    BsDatepickerModule.forRoot(),
    AlertModule.forRoot(),
    ModalModule.forRoot(),
    TooltipModule.forRoot(),
    BsDropdownModule.forRoot(),
    CollapseModule.forRoot(),
    CarouselModule.forRoot(),
    TabsModule.forRoot(),
    ProgressbarModule.forRoot(),
    PaginationModule.forRoot(),
    ToastrModule.forRoot(),
    ToastrModule.forRoot(),
    PopoverModule.forRoot(),
    OrderModule,
    SharedModule,
    NgxPaginationModule,
    NgMultiSelectDropDownModule,
    PopoverModule.forRoot(),
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class DeviationDPModule { }
