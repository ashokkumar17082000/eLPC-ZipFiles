import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeviationDataPoolComponent } from './deviation-data-pool.component';

describe('DeviationDataPoolComponent', () => {
  let component: DeviationDataPoolComponent;
  let fixture: ComponentFixture<DeviationDataPoolComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeviationDataPoolComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeviationDataPoolComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
