
import { DatePipe } from '@angular/common';
import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { LanguageService } from 'src/app/language.service';
import { CalendarService } from 'src/app/service/calendar.service';
import { ExcelService } from 'src/app/service/excel.service';
import { SharedService } from 'src/app/service/shared.service';
import { environment } from 'src/environments/environment';
//import { Audit, AuditStatus } from 'src/app/main/body/calendar/calendar';
import { Audit,AuditStatus } from 'src/app/calendar/calendar/calendar';
import { DataPoolService } from 'src/app/service/data-pool.service';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-calender-list',
  templateUrl: './calender-list.component.html',
  styleUrls: ['./calender-list.component.css']
})
// export class CalenderListComponent implements OnInit {
//   constructor() { }
//   ngOnInit() {
//   }
// }

export class CalenderListComponent implements OnInit {
  @ViewChild("alertPopup") warningModal: TemplateRef<any>;
  @ViewChild('ResumeModal') public ResumeModal: TemplateRef<any>;
  labels: any;
  _subscription: any;
  alertText: any;
  dateTimeFormat = environment.dateTimeFormat;
  filterdateFormat = environment.dateTimeFormat.split(" ")[0];
  filtertimeFormat = environment.dateTimeFormat.split(" ")[1];
  auditAnswerStatusList: AuditStatus[] = [];
  ntid: string;
  page: number = 1;
  resultPerPage: number = 10;
  startPage: number;
  endPage: number;
  auditAnswerStatusListAll: AuditStatus[];
  auditAnswerStatusListFiltered: AuditStatus[];
  totalList: AuditStatus[];
  config = {
    animated: false,
    keyboard: true,
    ignoreBackdropClick: true
  };
  filteredItems: any;
  dataPoolList: AuditStatus[];
  filtertext: string;
  filterId: boolean=true;
  filterStarttime: boolean =true;
  filterUser: boolean =true;
  filterStaus: boolean =true;
  filterAnswer: boolean =true;
  filterValueStream: boolean =true;
  filterAssessor: boolean =true;
  filterScore: boolean =true;
  filterTagName: boolean =true;
  filterTag: boolean =true;
  headerFilterName: any;
  public popUpInstances: any[] = []; // Store all popups  
  data: any[];
  str1: string;
  dataCopy: any;
  settings: { //setting for multiselect dropdown
    singleSelection: boolean; idField: string; textField: any; enableCheckAll: boolean; selectAllText: string; unSelectAllText: string; allowSearchFilter: boolean; limitSelection: number; clearSearchFilter: boolean; maxHeight: number; itemsShowLimit: number; searchPlaceholderText: string; noDataAvailablePlaceholderText: string; closeDropDownOnSelection: boolean; showSelectedItemsAtTop: boolean; defaultOpen: boolean;
  };
  form: FormGroup;
  loadContent: boolean;
  filterPopUp: any;
  filterendtime: boolean=true;
  filterapointmentStarttime: boolean=true;
  filterapointmentEndtime: boolean=true;
  constructor(public sharedService: SharedService, private excelService: ExcelService,private dataPoolService: DataPoolService,
    private modalService: BsModalService, private datePipe: DatePipe,
    private auditService: CalendarService, private local_label: LanguageService) {
      if (this.sharedService.ntid) {
        this.ntid = this.sharedService.ntid;
      }
  }
  ngOnInit() {
    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
    })
    this.getAuditStatus();   
    //this.sharedService.hide();
  }


 
public openAlertModal(popUp:any) {
    this.closeAllPopups();
    this.popUpInstances.push(popUp);
    this.filterPopUp = popUp;

  }


  public closeAlertModal(selectedFilter) {
   debugger;
   this.closeAllPopups();
   this.filterPopUp.hide();
  }

  private closeAllPopups() {
    this.popUpInstances.forEach((popUp) => popUp.hide());
   this.popUpInstances = []; // Clear the array
  }

  public async getAuditStatus(modulename?:string) {    
    this.sharedService.show();
     let IsDesigner = 1
    if(this.sharedService.role !=="Designer")
    {
      IsDesigner=0
    }
    console.log(this.sharedService.role)


    var  fromDate=new Date(this.sharedService.activeDateRange.fromDate)
    var dateObject = new Date(this.sharedService.activeDateRange.fromDate);
    // Extract year, month, and day
    console.log()
    var fromyear = dateObject.getFullYear();
    var frommonth = ('0' + (dateObject.getMonth() + 1)).slice(-2); // Adding 1 because getMonth() returns zero-based month index
    var fromday = ('0' + dateObject.getDate()).slice(-2);
    //TODATE
    var  toDate=new Date(this.sharedService.activeDateRange.toDate)
    var dateObject = new Date(this.sharedService.activeDateRange.toDate);
    // Extract year, month, and day
    var toyear = dateObject.getFullYear();
    var tomonth = ('0' + (dateObject.getMonth() + 1)).slice(-2); // Adding 1 because getMonth() returns zero-based month index
    var today = ('0' + dateObject.getDate()).slice(-2);

    // Construct the desired date format
    var currmonth = fromyear + '-' + frommonth + '-' + fromday;

    var curryear = toyear + '-' + tomonth + '-' + today;
    console.log(currmonth);
    console.log(curryear); // Output: "2024-02-01"
    var module;
    if(modulename=='ReportFiltered') {
      module=modulename
    }else if(modulename=='ReportExportAll')
    {
        module=modulename
    }else {
      module='Report'
    }
   
    await this.auditService.GetAuditStatusByType(module,currmonth,curryear,IsDesigner,this.ntid).subscribe(resultStatus => {      
      
      debugger
      this.auditAnswerStatusListAll = JSON.parse(JSON.stringify(resultStatus));
      if(this.auditAnswerStatusListAll != null){
      this.auditAnswerStatusListAll.sort(function(a, b) {
        var dateA = new Date(a.startDate).getTime();
        var dateB = new Date(b.startDate).getTime();        
        return dateA < dateB ? 1 : -1;  
      });
        this.auditAnswerStatusListAll.forEach(item => {
          if (item.tagTypeID === 1) {
            item.answeredStatus = 'Not yet due';
          }
      });
    }
      if(module=="Report") {
        this.GetData();
  
      }
      
    
    if(modulename=='ReportFiltered' || modulename=='ReportExportAll'){
      debugger;
      var excelData = this.auditAnswerStatusListAll.map((r, index) => ({
        ID : index + 1,
        OriginTag : r.tagDisplayName,
        Status : r.answeredStatus,
        UserName : r.createdBy_NTID,
        ValueStreamData: r.valueStreamName,
        AssessorName: r.assessorName,
        Completion: r.answerPercentage != null ? r.answerPercentage + " %" : "",
        NumberOfAnsweredQuestions: r.answerdQuestionCount,
        NumberOfUnansweredQuestions: r.unAnswerdQuestionCount,
        StartDateTime: r.answerStartDate != null ? this.datePipe.transform(r.answerStartDate,this.dateTimeFormat).toString() : "",
        EndDateTime: r.answerEndDate != null ? this.datePipe.transform(r.answerEndDate,this.dateTimeFormat).toString() : "",
        AppointmentStartDateTime: r.startDate != null ? this.datePipe.transform(r.startDate,this.filterdateFormat).toString() + " " + r.startTime.toString() : "",
        AppointmentEndDateTime: r.endDate != null ?this.datePipe.transform(r.endDate,this.filterdateFormat).toString() + " " + r.endTime.toString() : "",
        Recurrence: r.isRecurring,  
        ReqAttendee: r.requiredAttendeeStr,
        OptAttendee: r.optionalAttendeeStr, 
        Remarks: r.remarks
      }));
      if (modulename == 'ReportFiltered') {
   
        this.excelService.exportAsExcelFile(excelData, 'AuditStatus_Filtered');
      }
      else {
        this.excelService.exportAsExcelFile(excelData, 'AuditStatus');
      }
    }
      //console.log("65",resultStatus)
      
       
    
     
    });
  }
  async GetDataBySelectedRange() {
    await this.getAuditStatus()
    this.GetData();
  }

  public onDeSelect(item: any) {
    debugger;
    if (this.filteredItems == undefined) {
      this.filteredItems = [];
    }

    if (this.headerFilterName == 'valueStreamName') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.valueStreamName);
      this.auditAnswerStatusList = this.totalList.filter(f => this.filteredItems.includes(f.valueStreamName));
    }
    if (this.headerFilterName == 'assessorName') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.assessorName);
      this.auditAnswerStatusList = this.totalList.filter(f => this.filteredItems.includes(f.assessorName));
    }
    
    if (this.headerFilterName == 'answeredStatus') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.answeredStatus);
      this.auditAnswerStatusList = this.totalList.filter(f => this.filteredItems.includes(f.answeredStatus));
    }
    // if (this.headerFilterName == 'answeredStatus') {
    //   this.filteredItems = this.filteredItems.filter(obj => obj !== item.answeredStatus);
    //   this.auditAnswerStatusList = this.totalList.filter(f => this.filteredItems.includes(f.answeredStatus));
    // }
    
    if (this.headerFilterName == 'tagDisplayName') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.tagDisplayName);
      this.auditAnswerStatusList = this.totalList.filter(f => this.filteredItems.includes(f.tagDisplayName));
    }
    
    if (this.headerFilterName == 'createdBy_NTID') {
      this.filteredItems = this.filteredItems.filter(obj => obj !== item.createdBy_NTID);
      this.auditAnswerStatusList = this.totalList.filter(f => this.filteredItems.includes(f.createdBy_NTID));
    }

  }
  getColumnName(headername: any) {
   console.log(headername)
    if (this.filteredItems == undefined) {
      this.filteredItems = []
    }

    this.dataPoolList = this.totalList;//newly added
    this.filtertext = '';
    // this.filterId = false;
    // this.filterStarttime = false;
    // this.filterUser = false;
    // this.filterStaus = false;
    // this.filterAnswer = false;
    // this.filterValueStream = false;
    // this.filterAssessor = false;
    // this.filterScore = false;
    // this.filterTagName = false;
    // this.filterTag = false;
    //    this.filterId = !this.filterId;
   
    if (headername == 'startDate') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.datePipe.transform(this.totalList[i].startDate,this.filterdateFormat));
      }
      //this.filterStarttime = !this.filterStarttime;
    }
    if (headername == 'apppointmentStart') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].startTime);
      }
    //  this.filterapointmentStarttime = !this.filterapointmentStarttime;
    }
    if (headername == 'apppointmentEnd') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].endTime);
      }
     // this.filterapointmentEndtime = !this.filterapointmentEndtime;
    }
    if (headername == 'endDate') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.datePipe.transform(this.totalList[i].endDate,this.filterdateFormat));
      }
     // this.filterendtime = !this.filterStarttime;
    }
     if (headername == 'createdBy_NTID') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].createdBy_NTID);
      }
      // this.filterUser = !this.filterUser;
    }
    else if (headername == 'answeredStatus') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].answeredStatus
        );
      }
     // this.filterStaus = !this.filterStaus;
    }
    else if (headername == 'tagDisplayName') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].tagDisplayName);
      }
      //this.filterTag = !this.filterTag;
    }
    // else if (headername == 'answer') {
    //   for (var i = 0; i < this.totalList.length; i++) {
    //     this.filteredItems.push(this.totalList[i].answer);
    //   }
    //   this.filterAnswer = !this.filterAnswer;
    // }
     else if (headername == 'valueStreamName') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].valueStreamName);
      }
      //this.filterValueStream = !this.filterValueStream;
    }

    if (this.headerFilterName == 'answeredStatus') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].answeredStatus);
      }
    }
    else if (headername == 'assessorName') {
      for (var i = 0; i < this.totalList.length; i++) {
        this.filteredItems.push(this.totalList[i].assessorName);
      }
     // this.filterAssessor = !this.filterAssessor;
    }

   
    // else if (headername == 'obtainedScore') {
    //   for (var i = 0; i < this.totalList.length; i++) {
    //     this.filteredItems.push(this.totalList[i].obtainedScore);
    //   }
    //   this.filterScore = !this.filterScore;
    // }
    this.headerFilterName = headername;
    this.searchFilter();
  }
  searchFilter(num?:number) {
    debugger;
    if(num!=1){
      this.data = [];
    }
    // ********************************searching
    var prefix = 'Q';
    if (this.headerFilterName == "startDate") {
      for (var dataPoolDet of this.dataPoolList) {
        this.str1 = this.datePipe.transform(dataPoolDet.startDate, this.filterdateFormat);//converting the date format
        let newItem = {
          deviationID: dataPoolDet.auditID,
          startDate: this.str1
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.startDate ===  this.str1 )) {//newly added
            this.data.push(newItem);
          }
        }
      }
    }

    
    if (this.headerFilterName == "apppointmentStart") {
      for (var dataPoolDet of this.dataPoolList) {
        this.str1 = this.datePipe.transform(dataPoolDet.startDate, this.filterdateFormat);//converting the date format
        let newItem = {
          deviationID: dataPoolDet.auditID,
          apppointmentStart: this.str1
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.apppointmentStart ===  this.str1 )) {//newly added
            this.data.push(newItem);
          }
        }
      }
    }

    if (this.headerFilterName == "apppointmentEnd") {
      for (var dataPoolDet of this.dataPoolList) {
        this.str1 = this.datePipe.transform(dataPoolDet.endTime, this.filterdateFormat);//converting the date format
        let newItem = {
          deviationID: dataPoolDet.auditID,
          apppointmentEnd: this.str1
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.apppointmentEnd ===  this.str1 )) {//newly added
            this.data.push(newItem);
          }
        }
      }
    }
    if (this.headerFilterName == "endDate") {
      for (var dataPoolDet of this.dataPoolList) {
        this.str1 = this.datePipe.transform(dataPoolDet.endDate, this.filterdateFormat);//converting the date format
        let newItem = {
          deviationID: dataPoolDet.auditID,
          endDate: this.str1
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.endDate ===  this.str1 )) {//newly added
            this.data.push(newItem);
          }
        }
      }
    }
    
     if (this.headerFilterName == "createdBy_NTID") {
      for (var dataPoolDet of this.dataPoolList) {
        let newItem = {
          deviationID: dataPoolDet.auditID,
          createdBy_NTID: dataPoolDet.createdBy_NTID
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.createdBy_NTID === dataPoolDet.createdBy_NTID)) {//newly added
            this.data.push(newItem);
          }
        }
      }
    }
   
    // else if (this.headerFilterName == "responsibleEmployee") {
    //   for (var dataPoolDet of this.dataPoolList) {
    //     let newItem = {
    //       deviationID: dataPoolDet.deviationID,
    //       responsibleEmployee: dataPoolDet.responsibleEmployee
    //     };
    //     if (!this.data.includes(newItem)) {
    //       if (!this.data.some(e => e.responsibleEmployee === dataPoolDet.responsibleEmployee)) {
    //         this.data.push(newItem);
    //       }
    //     }
    //   }
    // }
    

    else if (this.headerFilterName == "tagDisplayName") {
      for (var dataPoolDet of this.dataPoolList) {
        let newItem = {
          deviationID: dataPoolDet.auditID,
          tagDisplayName: dataPoolDet.tagDisplayName
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.tagDisplayName === dataPoolDet.tagDisplayName)) {
            this.data.push(newItem);
          }
        }
      }
    }

     if (this.headerFilterName == "valueStreamName") {
      for (var dataPoolDet of this.dataPoolList) {
        let newItem = {
          deviationID: dataPoolDet.auditID,
          valueStreamName: dataPoolDet.valueStreamName
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.valueStreamName === dataPoolDet.valueStreamName)) {
            this.data.push(newItem);
          }
        }
      }
    }

    

    if (this.headerFilterName == "assessorName") {
      for (var dataPoolDet of this.dataPoolList) {
        let newItem = {
          deviationID: dataPoolDet.auditID,
          assessorName: dataPoolDet.assessorName
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.assessorName === dataPoolDet.assessorName)) {
            this.data.push(newItem);
          }
        }
      }
    }

    else if (this.headerFilterName == "answeredStatus") {
      for (var dataPoolDet of this.dataPoolList) {
        let newItem = {
          deviationID: dataPoolDet.auditID,
          answeredStatus:dataPoolDet.answeredStatus
          
        };
        if (!this.data.includes(newItem)) {
          if (!this.data.some(e => e.answeredStatus ===dataPoolDet.answeredStatus
          )) {//newly added
            this.data.push(newItem);
          }
        }
      }
    }

   
    // else if (this.headerFilterName == "deviationDescription") {
    //   for (var dataPoolDet of this.dataPoolList) {
    //     let newItem = {
    //       deviationID: dataPoolDet.deviationID,
    //       deviationDescription: dataPoolDet.deviationDescription
    //     };
    //     if (!this.data.includes(newItem)) {
    //       if (!this.data.some(e => e.deviationDescription === dataPoolDet.deviationDescription)) {
    //         this.data.push(newItem);
    //       }
    //     }
    //   }
    // }
    // else if (this.headerFilterName == "obtainedScore") {
    //   for (var dataPoolDet of this.dataPoolList) {
    //     let newItem = {
    //       deviationID: dataPoolDet.deviationID,
    //       obtainedScore: dataPoolDet.obtainedScore
    //     };
    //     if (!this.data.includes(newItem)) {
    //       if (!this.data.some(e => e.obtainedScore === dataPoolDet.obtainedScore)) {
    //         this.data.push(newItem);
    //       }
    //     }
    //   }
    //}
    this.dataCopy=JSON.parse(JSON.stringify(this.data))
    this.settings = {//setting for multiselect dropdown
      singleSelection: false,
      idField:'deviationID',
      textField: this.headerFilterName,


      enableCheckAll: true,
      selectAllText: 'Select All',
      unSelectAllText: 'Unselect All',
      allowSearchFilter: true,
      limitSelection: -1,
      clearSearchFilter: true,
      maxHeight: 197,
      itemsShowLimit: 0,
      searchPlaceholderText: 'Search',
      noDataAvailablePlaceholderText: 'No Data Available',
      closeDropDownOnSelection: false,
      showSelectedItemsAtTop: false,
      defaultOpen: false
    };
    this.setForm();
    // ************************************************
  }


  public onDeSelectAll(items: any) {
    debugger;
    this.filteredItems = [];
    this.dataPoolList = this.totalList;
  }
  onSelectAll(items: any) {
    if (this.filteredItems == undefined) {
      this.filteredItems = [];
    }
    for (var i = 0; i < items.length; i++) {
      if (this.headerFilterName == 'timeStamp') {
        this.filteredItems.push(items[i].timeStamp)
      }
      else if (this.headerFilterName == 'createdBy_NTID') {
        this.filteredItems.push(items[i].createdBy_NTID)
      }
      else if (this.headerFilterName == 'questionID') {
        this.filteredItems.push(items[i].questionID)
      }
      else if (this.headerFilterName == 'createdBy_NTID') {
        this.filteredItems.push(items[i].createdBy_NTID)
      }
      else if (this.headerFilterName == 'deviationDisplayID') {
        this.filteredItems.push(items[i].deviationDisplayID)
      }
      else if (this.headerFilterName == 'responsibleEmployee') {
        this.filteredItems.push(items[i].createdBy_NTID)
      }
     
      else if (this.headerFilterName == 'valueStreamName') {
        this.filteredItems.push(items[i].valueStreamName)
      }
      
      else if (this.headerFilterName == 'assessorName') {
        this.filteredItems.push(items[i].assessorName)
      }
      else if (this.headerFilterName == 'answeredStatus') {
        this.filteredItems.push(items[i].answeredStatus)
      }
      else if (this.headerFilterName == 'tagDisplayName') {
        this.filteredItems.push(items[i].tagDisplayName)
      }
    }
    this.dataPoolList = this.totalList;
  }

  onItemSelect(item: any) {
    debugger;
   if (this.filteredItems == undefined) {
      this.filteredItems = [];
    }

    if (this.headerFilterName == 'startDate') {
      if (this.filteredItems.indexOf(item.startDate) < 0) {
        this.filteredItems.push(item.startDate);
      }
      this.auditAnswerStatusList = this.totalList.filter(f => this.filteredItems.includes(this.datePipe.transform(f.startDate, this.filterdateFormat)));
    }
    else if (this.headerFilterName == 'createdBy_NTID') {
      if (this.filteredItems.indexOf(item.createdBy_NTID) < 0) {
        this.filteredItems.push(item.createdBy_NTID);
      }
      this.auditAnswerStatusList = this.totalList.filter(f => this.filteredItems.includes(f.createdBy_NTID));
    }
    // else if (this.headerFilterName == 'questionID') {
    //   item.questionID = item.questionID.replace("Q", "");
    //   if (this.filteredItems.indexOf(item.questionID) < 0) {
    //     this.filteredItems.push(item.questionID);
    //   }
    //   this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.questionID.toString()));
    // }
    // else if (this.headerFilterName == 'responsibleEmployee') {
    //   if (this.filteredItems.indexOf(item.responsibleEmployee) < 0) {
    //     this.filteredItems.push(item.responsibleEmployee);
    //   }
    //   this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.responsibleEmployee));
    // }
    
    // else if (this.headerFilterName == 'deviationDisplayID') {
    //   if (this.filteredItems.indexOf(item.deviationDisplayID) < 0) {
    //     this.filteredItems.push(item.deviationDisplayID);
    //   }
    //   this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.deviationDisplayID));
    // }
    else if (this.headerFilterName == 'valueStreamName') {
      if (this.filteredItems.indexOf(item.valueStreamName) < 0) {
        this.filteredItems.push(item.valueStreamName);
      }
      this.auditAnswerStatusList = this.totalList.filter(f => this.filteredItems.includes(f.valueStreamName));
    }
    

    else if (this.headerFilterName == 'assessorName') {
      if (this.filteredItems.indexOf(item.assessorName) < 0) {
        this.filteredItems.push(item.assessorName);
      }
      this.auditAnswerStatusList = this.totalList.filter(f => this.filteredItems.includes(f.assessorName));
    }

    else if (this.headerFilterName == 'answeredStatus') {
      if (this.filteredItems.indexOf(item.answeredStatus) < 0) {
        this.filteredItems.push(item.answeredStatus);
      }
      this.auditAnswerStatusList = this.totalList.filter(f => this.filteredItems.includes(f.answeredStatus));
    }
    
    
    else if (this.headerFilterName == 'tagDisplayName') {
      if (this.filteredItems.indexOf(item.tagDisplayName) < 0) {
        this.filteredItems.push(item.tagDisplayName);
      }
      this.auditAnswerStatusList = this.totalList.filter(f => this.filteredItems.includes(f.tagDisplayName));
    }
    
    // else if (this.headerFilterName == 'deviationDescription') {
    //   if (this.filteredItems.indexOf(item.deviationDescription) < 0) {
    //     this.filteredItems.push(item.deviationDescription);
    //   }
    //   this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.deviationDescription));
    // }
    // else if (this.headerFilterName == 'obtainedScore') {
    //   if (this.filteredItems.indexOf(item.obtainedScore) < 0) {
    //     this.filteredItems.push(item.obtainedScore);
    //   }
    //   this.dataPoolList = this.totalList.filter(f => this.filteredItems.includes(f.obtainedScore));
    // }
  }


  onOpenDropdown(){
    console.log("open ")
    console.log("datcopy",this.dataCopy)
    console.log(this.data)
    this.dataCopy = [...this.dataCopy];
   // this.cdr.detectChanges();
  }
  
  setForm() {
    this.form = new FormGroup({
      name: new FormControl(
        this.dataCopy
      )
    });
    this.loadContent = true;
  }
  GetData() {
    this.sharedService.show();
    this.auditAnswerStatusListFiltered = this.auditAnswerStatusListAll;
   // var filtered = this.auditAnswerStatusListFiltered != null ? JSON.parse(JSON.stringify(this.auditAnswerStatusListFiltered.filter(r => new Date(r.startDate) >= this.sharedService.activeDateRange.fromDate && new Date(r.endDate) <= this.sharedService.activeDateRange.toDate))) : null;
    var filtered = this.auditAnswerStatusListFiltered
    this.auditAnswerStatusList = filtered;
    this.totalList = filtered;
    this.sharedService.hide();
    // var d1 = new Date(this.sharedService.activeDateRange.fromDate.getUTCFullYear(),  this.sharedService.activeDateRange.fromDate.getUTCMonth(),   this.sharedService.activeDateRange.fromDate.getUTCDate());
    // var d2 = new Date(this.sharedService.activeDateRange.toDate.getUTCFullYear(),  this.sharedService.activeDateRange.toDate.getUTCMonth(),   this.sharedService.activeDateRange.toDate.getUTCDate())
    // this.auditAnswerStatusList = this.auditAnswerStatusListFiltered.filter(r => new Date(r.startDate) >= d1 && new Date(r.endDate) <= d2);
    //JSON.parse(JSON.stringify(this.auditAnswerStatusListFiltered.filter(r => new Date(r.startDate) >= this.sharedService.activeDateRange.fromDate && new Date(r.endDate) <= this.sharedService.activeDateRange.toDate)));
  }
  async exportAsXLSX(IsFilterd: boolean) {
    //debugger;
    this.sharedService.show();
    
    if (IsFilterd == true) {
 
     await  this.getAuditStatus('ReportFiltered')
    }
    else {
      await this.getAuditStatus('ReportExportAll')
    }
    var auditAnswerStatus = (IsFilterd == false) ?
      JSON.parse(JSON.stringify(this.auditAnswerStatusListAll)) :
      JSON.parse(JSON.stringify(this.auditAnswerStatusList));

     
    // var excelData = auditAnswerStatus.map((r, index) => ({
    //   ID : index + 1,
    //   OriginTag : r.tagDisplayName,
    //   Status : r.answeredStatus,
    //   UserName : r.createdBy_NTID,
    //   ValueStreamData: r.valueStreamName,
    //   AssessorName: r.assessorName,
    //   Completion: r.answerPercentage != null ? r.answerPercentage + " %" : "",
    //   NumberOfAnsweredQuestions: r.answerdQuestionCount,
    //   NumberOfUnansweredQuestions: r.unAnswerdQuestionCount,
    //   StartDateTime: r.answerStartDate != null ? this.datePipe.transform(r.answerStartDate,this.dateTimeFormat).toString() : "",
    //   EndDateTime: r.answerEndDate != null ? this.datePipe.transform(r.answerEndDate,this.dateTimeFormat).toString() : "",
    //   AppointmentStartDateTime: r.startDate != null ? this.datePipe.transform(r.startDate,this.filterdateFormat).toString() + " " + r.startTime.toString() : "",
    //   AppointmentEndDateTime: r.endDate != null ?this.datePipe.transform(r.endDate,this.filterdateFormat).toString() + " " + r.endTime.toString() : "",
    //   Recurrence: r.isRecurring,  
    //   ReqAttendee: r.requiredAttendeeStr,
    //   OptAttendee: r.optionalAttendeeStr, 
    //   Remarks: r.remarks
    // }));
    // if (IsFilterd == true) {
 
    //   this.excelService.exportAsExcelFile(excelData, 'AuditStatus_Filtered');
    // }
    // else {
    //   this.excelService.exportAsExcelFile(excelData, 'AuditStatus');
    // }
   
  }
  public searchGrid = (value: string) => {
    if (value.length > 0) {
      var searchText = value.trim().toLowerCase();
      this.auditAnswerStatusList = this.totalList;
      this.auditAnswerStatusList = this.auditAnswerStatusList.filter(x =>
        x.tagDisplayName.trim().toLowerCase().includes(searchText) 
        || (x.answeredStatus != null && x.answeredStatus.trim().toLowerCase().includes(searchText))
        || (x.createdBy_NTID != null && x.createdBy_NTID.trim().toLowerCase().includes(searchText))
        || (x.valueStreamName != null && x.valueStreamName.trim().toLowerCase().includes(searchText)) 
        || (x.assessorName != null && x.assessorName.trim().toLowerCase().includes(searchText))
        || (x.answerPercentage != null && x.answerPercentage.toString().trim().toLowerCase().includes(searchText.replace("q","")))
        || (x.answerdQuestionCount != null && x.answerdQuestionCount.toString().trim().toLowerCase().includes(searchText.replace("q","")))
        || (x.unAnswerdQuestionCount != null && x.unAnswerdQuestionCount.toString().trim().toLowerCase().includes(searchText.replace("q","")))
        || (x.answerStartDate != null && this.datePipe.transform(x.answerStartDate,this.dateTimeFormat).trim().toLowerCase().includes(searchText)) 
        || (x.answerEndDate != null && this.datePipe.transform(x.answerEndDate,this.dateTimeFormat).trim().toLowerCase().includes(searchText)) 
        || (x.startDate != null && this.datePipe.transform(x.startDate,this.filterdateFormat).trim().toLowerCase().includes(searchText)) 
        || (x.endDate != null && this.datePipe.transform(x.endDate,this.filterdateFormat).trim().toLowerCase().includes(searchText)) 
        || (x.remarks != null && x.remarks.toString().trim().toLowerCase().includes(searchText))
        || (x.requiredAttendeeStr != null && x.requiredAttendeeStr.split(";").map(item => item).toString().toLowerCase().includes(searchText))
        || (x.optionalAttendeeStr != null && x.optionalAttendeeStr.split(";").map(item => item).toString().toLowerCase().includes(searchText))
      );
      this.page = 1;
    }
    else {
      this.auditAnswerStatusList = this.totalList;
    }
  }
  isFirstPage() {
    if (this.page == 1) {
      return;
    }
    else {
    }
    this.page = 1;
    this.startPage = (this.page - 1) * 4 + 1;
    this.endPage = this.page * this.resultPerPage;
  }
  isLastPage() {
    if (Math.ceil(this.auditAnswerStatusList.length / this.resultPerPage) <= this.page) {
      return;
    }
    else {
    }
    this.page = Math.ceil(this.auditAnswerStatusList.length / this.resultPerPage);
    this.startPage = (this.page - 1) * 4 + 1;
    this.endPage = this.page * this.resultPerPage;
  }
  ShowPopUp(){
    this.modalService.show(this.ResumeModal, this.config);
    $("modal-container").removeClass("fade");
  }
  
  closeAlertModal1(num?:number) {
    //alert(1)
    
    if (document.getElementsByTagName("modal-container").length > 1) {
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length - 1]);
    }
    else {
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if (document.getElementsByTagName("bs-modal-backdrop").length > 0) {
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }
    if(num) {
      
     this.exportAsXLSX(false)
    }
  }
  pageChanged(event): void {
    if (event == 0) {
      return;
    }
    else if (Math.ceil(this.auditAnswerStatusList.length / this.resultPerPage) < event) {
      return;
    }
    else {
      this.page = event;
      this.startPage = (this.page - 1) * 4 + 1;
      this.endPage = this.page * this.resultPerPage;
    }
  }
}
