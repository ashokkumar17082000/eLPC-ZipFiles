import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataPoolComponent } from './data-pool.component';

describe('DataPoolComponent', () => {
  let component: DataPoolComponent;
  let fixture: ComponentFixture<DataPoolComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataPoolComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataPoolComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
