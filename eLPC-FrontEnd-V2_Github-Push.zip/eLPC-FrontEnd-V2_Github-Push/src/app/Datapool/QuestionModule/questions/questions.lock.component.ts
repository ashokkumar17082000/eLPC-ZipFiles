import { Component, OnInit, ViewChild, ElementRef, TemplateRef, Output, EventEmitter, Input } from '@angular/core';
import { SharedService } from 'src/app/service/shared.service';
import { HttpClient } from '@angular/common/http';
import { CommonService } from 'src/app/service/common/common.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import {ToastrService} from 'ngx-toastr';
import { ActivatedRoute, Router } from "@angular/router";
import { LanguageService } from 'src/app/language.service';
import { DatePipe } from '@angular/common';
import { QuestionProxy, Question } from './question';
import { QuestionService } from 'src/app/service/question.service';
import { User } from 'src/app/main/body/shared/common';
import { ValuestreamTemplateService } from 'src/app/service/common/valuestreamtemplate.service';
import { AssessorTemplateService } from 'src/app/service/assessor/assessortemplate.service';
import { TagService } from 'src/app/service/tag.service';
import { QuestionsComponent } from './questions.component';
import { environment } from 'src/environments/environment';
import { DataPoolService } from 'src/app/service/data-pool.service';
import { SearchService } from 'src/app/service/search.service';
declare var $;

@Component({
  selector: 'app-questions',
  templateUrl: './questions.lock.component.html',
  styleUrls: ['./questions.component.css']
})
export class QuestionLockComponent implements OnInit {
  @ViewChild('alertPopup') warningModal : TemplateRef<any>;
  @ViewChild('successPopup') successModal : TemplateRef<any>;
  isDisabled:boolean=true;

  alertText;

  question: Question = new Question();

  labels: any;
  _subscription: any;
  questionProxy: QuestionProxy;
  errorMessage: string;

  constructor(private assessorTemplateService: AssessorTemplateService, private dataPoolService: DataPoolService,private tagService: TagService, private valueStreamService: ValuestreamTemplateService, private local_label: LanguageService, private router: Router, private modalService: BsModalService, private sharedService: SharedService, private questionService: QuestionService, private commonService: CommonService,
   private http: HttpClient,private toastr: ToastrService,
   private route: ActivatedRoute,private datePipe: DatePipe,private searchService: SearchService) {
        this.question = this.questionService.question;
        this.proxies = [];
        this.questionService.questionProxiesByQuestionID(this.question.questionID).subscribe(res => {
            this.proxies = [];
            let usrs = res;
            if(usrs!){
            this.proxies = res;;
            }
        },
    );
    }

    redirect()
    {
      this.router.navigate([environment.home +'/questions']);
    }

    callEditQuestion = new QuestionsComponent(this.local_label, this.router, this.modalService, this.sharedService, this.questionService, this.commonService, this.valueStreamService,
      this.dataPoolService,
      this.assessorTemplateService, this.tagService, this.http, this.toastr, this.route , this.datePipe);

    cancel(question) {
     this.callEditQuestion.editQuestion(question);
    }


    ngOnInit() {
      if(this.sharedService.role !=="Designer")
      {
        this.router.navigate([environment.home +'/accessdenied']);
      }
      this.labels = this.local_label.localizeLanguage;
      this._subscription = this.local_label.LanguageChange.subscribe((value) => {
        this.labels = value;
      });


      this.searchService.getSearchResults().subscribe({
        next: (response: any) => {
          if (response && response.value) {
            this.activeDirectoryData = response.value;
            console.log("AD Data",this.activeDirectoryData)
            this.errorMessage = ''; // Clear any previous error messages
          } else {
            this.activeDirectoryData = [];
            this.errorMessage = 'No users found.';
          }
        },
        error: (err) => {
          console.error('Failed to fetch users from Graph API', err);
          this.errorMessage = 'Failed to fetch users. Please try again later.';
        },
      });
    }

/** for Proxy */

  removeProxy(event: any) {
    let ntid = event.target.id;
    this.proxies = this.proxies.filter(x => x.ntid !== ntid);
  }

  //for new Active Directory Search
user: any;
proxies: any = [];
activeDirectoryData: any[];

onChangeSearch(term: string) {

  // let user = new User();
  // user.firstName = this.user;
  // this.commonService.activeDirectoryByName(user).subscribe(res => {
  //   this.activeDirectoryData = [];
  //   this.activeDirectoryData = res;
  // },
  //   err => console.error(err));
  console.log(term)
  this.searchService.setSearchTerm(term);
}

// selectUser(user:any){

//   if (user !== null) {
//     let x = this.proxies.filter(x => x.ntid == user.ntid);
//     if (x.length == 0)
//     this.proxies.push(user);
//   }


//   this.activeDirectoryData = [];
//   this.user = undefined;
// }


selectUser(user:any){

  if (user !== null) {
    let x = this.proxies.filter(x => x.ntid == user.ntid);
    if (x.length == 0)
    this.proxies.push(user);
    this.proxies.forEach(x => {
      // Check if the userPrincipalName of the current attendee matches the userPrincipalName of the new user
      if (x.userPrincipalName === user.userPrincipalName) {
        // If they match, set the ntid property to the userPrincipalName
        if (user.userPrincipalName && user.userPrincipalName.includes('@')) {
          x.ntid = user.userPrincipalName.split('@')[0].toUpperCase();
        }
        if (user.givenName && user.surname && user.mail && user.displayName)
        {
         x.emailAddress = user.mail;
         x.firstName = user.givenName;
         x.lastName = user.surname;
         x.userName = user.displayName;
       }
      }
    });
  }


  this.activeDirectoryData = [];
  this.user = undefined;
}
saveLockSettings() {

  if(this.question.isLocked){
    if(this.proxies.length <1){
      this.alertText = this.labels.default.proxyRequired;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
      return;
    }
  }
  this.questionProxy = new QuestionProxy();
  this.questionProxy.questionID = this.question.questionID;
  this.questionProxy.proxies = this.proxies;
  if(this.question.isLocked){
    if(this.questionService.question){
      this.questionService.question.isLocked = true;
    }
    if(this.sharedService.ntid){
      if(!this.questionProxy.createdBy_NTID)
      {
      this.questionProxy.createdBy_NTID = this.sharedService.ntid;
      }
      this.questionProxy.modifiedBy_NTID = this.sharedService.ntid;
    }
  this.questionService.insertQuestionProxy(this.questionProxy).subscribe(res => {
    if (res.resultCode == 0) {
      this.alertText = this.labels.default.saveSuccessfully;
      this.modalService.show(this.successModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      this.questionService.question = this.question;
      this.router.navigate([environment.home +'/datapool/questions']);
    }
  }, err => {
      console.error(err);
      this.alertText = this.labels.default.insertOpertionFailed;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
}
  );}
  else{
    this.questionService.insertQuestion(this.question).subscribe(res =>{
      if (res.resultCode == 0) {
        this.alertText = this.labels.default.saveSuccessfully;
        this.modalService.show(this.successModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.questionService.question = this.question;
        this.router.navigate([environment.home +'/questions']);
      }
    })
  }
}

 //to fix scroll issue after pop up
 public closeAlertModal(){
  if(document.getElementsByTagName("modal-container").length > 1){
    document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length-1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length-1]);
  }
  else{
    document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
    if(document.getElementsByTagName("bs-modal-backdrop").length > 0){
      document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
    }
    document.querySelector('body').classList.remove('modal-open');
  }

}
//-===============

}
