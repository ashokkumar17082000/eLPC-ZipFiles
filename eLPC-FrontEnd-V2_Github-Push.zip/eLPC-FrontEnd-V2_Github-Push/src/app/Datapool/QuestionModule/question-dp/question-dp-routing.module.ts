import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { QuestionsComponent } from 'src/app/Datapool/QuestionModule/questions/questions.component';
import { QuestionLockComponent } from 'src/app/Datapool/QuestionModule/questions/questions.lock.component';
import { DataPoolComponent } from 'src/app/Datapool/QuestionModule/data-pool/data-pool.component';
import { DataPoolEditComponent } from 'src/app/Datapool/QuestionModule/data-pool/data-pool-edit.component';

const routes: Routes = [
  { path: 'questions', component: QuestionsComponent },
  { path: 'question-lock', component: QuestionLockComponent },
  { path: '', component: DataPoolComponent },
  { path: 'dataPool-edit', component: DataPoolEditComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class QuestionDPRoutingModule { }
