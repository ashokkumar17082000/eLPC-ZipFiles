import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { Question } from 'src/app/Datapool/QuestionModule/questions/question';
//import { Tag } from '../../../../app/main/body/tag/tag';
import { Tag } from 'src/app/Tag/tag/tag';
import { TagService } from 'src/app/service/tag.service';
//import { Assessor } from '../../../../app/main/body/assessors/assessortemplate';
import { Assessor } from 'src/app/Assessor/assessor/assessortemplate';
import { Router } from '@angular/router';
import { QuestionService } from 'src/app/service/question.service';
import { SharedService } from 'src/app/service/shared.service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ThrowStmt } from '@angular/compiler';
import { TagMode } from './tag-mode';
import { TagModeService } from 'src/app/service/tag-mode.service';
import { LanguageService } from 'src/app/language.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-tag-mode',
  templateUrl: './tag-mode.component.html',
  styleUrls: ['./tag-mode.component.css']
})
export class TagModeComponent implements OnInit {
  tagMode:TagMode=new TagMode();
  showTagList:boolean=false;
  bsModalRef: BsModalRef;
  modalRef: BsModalRef;

  @ViewChild('alertPopup') warningModal : TemplateRef<any>;
  @ViewChild('successPopup') successModal : TemplateRef<any>;
  
  alertText;
  // closeResult:string;
  // constructor(private modalService:NgbModal) { }

  // ngOnInit() {
  // }

  config = {
    animated: false,
    keyboard: true,
    ignoreBackdropClick: true
  };

 

  IsQuestionAndTagListShow:boolean=false;
  tagList: Tag[] = [];
  availableTags: Tag[] = [];
  selectedTags: Tag[] = [];
  selectedQuestions: Question[] = [];

  tag: Tag = new Tag();
  isEdit: boolean = false;
  isAdd: boolean = false;
  dateTimeFrom = new Date();
  dateTimeTo = new Date();
  bsValue = new Date();
  suppressedDateRangeFrom = new Date();
  suppressesDateRangeTo = new Date();
  questionOrders: { id:number }[];
  questionList: Question[];
  availableQuestions: Question[] = [];
    selectedTagIDs: string;
    selectedAssessors: Assessor[] = [];
    selectedQuestionIDs: any;
    closeResult: string;
    headeFilterName: any;
  TagInfoID: number;
  TagInfoText: string;
  selectedQuestionsByTagID: Question[]=[];

  constructor(private local_label: LanguageService, private modalService: BsModalService, private sharedService: SharedService, private tagService: TagService,private router: Router, private questionService: QuestionService,
    private tagModeService:TagModeService) {

    this.dateTimeFrom = new Date();
    this.dateTimeTo = new Date();
    //this.bsValue = new Date();
    //this.bsValue = '';
   
    //this.tag = new Tag();
    this.tag = this.tagService.tag;
    this.tagService.tag = undefined;
   
    //if (Object.keys(this.tag).length == 0) {
    if (this.tag == undefined) {
      this.isAdd = true;
      this.isEdit = false;
      this.tag = new Tag();    
    }
    else if (Object.keys(this.tag).length == 0) {
      this.isAdd = true;
      this.isEdit = false;
      this.tag = new Tag();
    }    
    else {
      this.isAdd = false;
      this.isEdit = true;
    }

    if (this.isEdit) {
      this.tag.suppressedDateRangeFrom = new Date(this.tag.suppressedDateRangeFrom);
      this.tag.suppressedDateRangeTo = new Date(this.tag.suppressedDateRangeTo);
      this.suppressedDateRangeFrom = this.tag.suppressedDateRangeFrom;
      this.suppressesDateRangeTo = this.tag.suppressedDateRangeTo;
      if (this.tag.tagID != undefined && this.tag.tagID != null && this.tag.tagID > 0) {
        this.fetchTagsAndQuestions();
      }
    }

    if (this.isAdd) {
      if (this.tag == undefined) {
        this.tag = Object.assign(new Tag());
      }
      this.tag.tagTypeID = 1;
      this.tag.isBranchLogicToBeFollowed = false;
      this.tag.anonymizeUserDataSettingID = 1;
      this.tag.isBranchLogicToBeFollowed = false;
      this.tag.isSingleQuestionSuppressed = false;
      this.tag.tag_PriorityID = 4;
      this.tag.isDeleted = false;
      this.tag.isLocked = false;
      this.tag.isMandatoryAssessorsDefined = false;
      this.tag.isTargetFrequencyDefined = false;
      this.tag.createdAt = new Date();
      this.tag.modifiedAt = new Date();
      this.tag.createdBy = null;
      this.tag.modifiedBy = null;
      this.tag.suppressedDateRangeFrom = null;
      this.tag.suppressedDateRangeTo = null;
      this.tag.tagID = 0;
      this.tag.tagName = null;
      this.tag.targetFrequencyTypeID = null;
      this.tag.targetFrequencyValue = null;
    }
    this.availableTags = [];
    this.selectedTags = [];
    this.selectedQuestions = [];
    }

    labels: any;
    _subscription: any;

  ngOnInit() {

//debugger;
    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
    });

    //this.getTagQuestionList(); //move this call into onclick of add tag
    this.sharedService.hide();
    this.GetTagModeByNTID();
  }
  // PushTagQuestiontags() {
 
  //  this.IsQuestionAndTagListShow=true;
  
  // }
  closeTagModePopup() {
    this.GetTagModeByNTID();
    this.showTagList = true;
   this.closeAlertModal();
  }

  //to fix scroll issue after pop up
  public closeAlertModal(){
    //console.log(document.getElementsByTagName("modal-container"));
    if(document.getElementsByTagName("modal-container").length > 1){
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length-1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length-1]);
    }
    else{
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if(document.getElementsByTagName("bs-modal-backdrop").length > 0){
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }
    
  }
  
  tagModeList:TagMode[]=[];
 public async GetTagModeByNTID(){
    
    var NTID= this.sharedService.ntid;
    await this.tagModeService.GetTagModeByNTID(NTID).subscribe(res=>{
      
      if(res[0].tags[0].tagID){
        this.tagMode=res[0];
        this.sharedService.tagMode = res[0];
        this.sharedService.tagDisplayName = res[0].tags[0].tagDisplayName;
      //console.log("187 da",this.tagMode)
      
      
      //console.log("188 da",this.tagMode.tags[0].tagModeTagsID)
      this.sharedService.SharedServiceTags = this.tagMode.tags[0];
      this.sharedService.TagModeID = this.tagMode.tags[0].tagModeTagsID;
      this.sharedService.TagName = this.tagMode.tags[0].tagName;
      this.sharedService.tagTypeID = this.tagMode.tags[0].tagTypeID;
      this.sharedService.tagmodetagID = this.tagMode.tags[0].tagID;
      
      // this.selectedTags=this.tagMode.tags;
      // this.selectedQuestions=this.tagMode.questions;

      //if the selected question list has atleast one item then show the list
      if(this.tagMode.tags.length>0){
        this.showTagList=true;
      }
     
      }
      else {
        
        this.alertText = name + this.labels.default.selectTag;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
       //this.router.navigate([environment.home +'/tagMode']);
      }

    },
   err=> console.error(err));
  }


  // public async insertToTagMode(tagMode:TagMode , event?: Event){
  //   event.preventDefault(); // Prevent the default form submission
  //   event.stopPropagation(); // Stop further event propagation if necessary
  //   console.log('Button clicked, method executed');
  //   alert(1)
  // }
  public async insertToTagMode(tagMode:TagMode, event?: Event){
       event.preventDefault(); // Prevent the default form submission
    event.stopPropagation(); // Stop further event propagation if necessary
    console.log('Button clicked, method executed');
    //alert(1)
// if nothing got selected in current selection and clicking on save then validation message should come
    if (this.selectedTags.length <= 0) {
      this.alertText = name + this.labels.default.selectTag;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      return;
    }
  // if(!tagMode.tags){
  //   this.alertText = name + this.labels.default.fileUploadError;
  //   this.modalService.show(this.warningModal);
  //   $("modal-container").removeClass("fade");
  //   $(".modal-dialog").addClass("modalSize");
  //   return;
  // }

    this.tagMode.tags = this.selectedTags;
    this.tagMode.questions = this.selectedQuestions;
    this.tagMode.createdBy_NTID=this.sharedService.ntid;

    this.IsQuestionAndTagListShow=true;

    await  this.tagModeService.insertToTagMode(tagMode).subscribe(res => {
      this.closeAlertModal();
      this.alertText = this.labels.default.insertedSuccessfully;
      this.modalService.show(this.successModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      this.GetTagModeByNTID();
      this.showTagList=true;
      //this.getProcessConfirmation(this.modeType,this.selectedValueStreamID,this.selectedAssessorID);
    });
    this.selectedTags=[];
  }
  
 addTagModeTag(contentTag){
//  debugger;
  this.open(contentTag);
  }

  // private getDismissReason(reason: any): string {
  //   if (reason === ModalDismissReasons.ESC) {
  //     return 'by pressing ESC';
  //   } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
  //     return 'by clicking on a backdrop';
  //   } else {
  //     return `with: ${reason}`;
  //   }
  // }



  public getTagQuestionList() {
//    debugger;
    this.tagModeService.getTagModeTags().subscribe(res => {
//      debugger;
      this.tagList = res;
      console.log(this.tagList);
      this.searchTagOrQuestion();
      // this.questionService.getQuestions().subscribe(res => {
      //   this.questionList = res;
      // }, err => { console.log(err) });
    },
      err => {
        console.log(err);
      }
    );
  }
  modeSelection(){
//debugger;
    // this.sharedService.sendMessage("tag");
    //  this.router.navigate([environment.home +'/processConfirmation']);
    if (this.tagMode.tags.length > 0) {
      var tagID =this.tagMode.tags[0].tagID;
      console.log("273",this.tagMode)
      //this.sharedService.GetTagModeQuestions(0, tagID, this.router); 
      this.sharedService.GetTagModeQuestions_Optimized(0, tagID, this.router); 
    }
    else {
      //this.router.navigate([environment.home + '/processConfirmation', { mode: "tag" }]);
      this.alertText = name + this.labels.default.selectTag;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
     
     // this.router.navigate([environment.home + '/processConfirmation', { mode: "tag" }]);
    }

  }

  redirect() {
    this.tag = undefined;
    
    this.router.navigate(['/tag-list']);
    
  }

  fetchTagsAndQuestions() {
    
    this.tagService.getTagsByTagID(this.tag.tagID).subscribe(res => {
      this.selectedTags = [];
      this.selectedTags = res;
      this.tagService.getQuestionsByTagID(this.tag.tagID).subscribe(res => {
        this.selectedQuestions = [];
        res = res.filter((value, index, self) =>
        index === self.findIndex((t) => (
          t.questionDisplayID === value.questionDisplayID
        ))
      )  
        this.selectedQuestions = res;
      }, err => console.log(err));
    }, err => console.log(err));
  }


  public tagSelected(tag:Tag) { //here we are selecting tags from available list of tags
//  
  console.log("308",tag)
 if (this.selectedTags == undefined) {
    this.selectedTags = [];
  }
if(tag){
  if(this.selectedTags.length>0){
    this.removeTag(this.selectedTags[0]);
  }
  this.selectedTags.push(tag);
  if (this.selectedTagIDs == null) {
    this.selectedTagIDs = String(tag.tagID);
  }
  else {
    this.selectedTagIDs += "," + tag.tagID;
  }
  // this.availableTags = this.availableTags.filter(x => x.tagID !== tag.tagID);
    // mk
    var y = this.tagMode.tags.filter(
      y => y.tagID == tag.tagID
    );
    this.availableTags = this.availableTags.filter(y => y.tagID !== tag.tagID);
    // ****
}
// ********************

    // if (this.selectedTags == undefined) {
    //   this.selectedTags = [];
    // }
    // this.selectedTags.push(tag);
    // if (this.selectedTagIDs == null) {
    //   this.selectedTagIDs = String(tag.tagID);
    // }
    // else {
    //   this.selectedTagIDs += "," + tag.tagID;
    // }
    // // this.availableTags = this.availableTags.filter(x => x.tagID !== tag.tagID);
    //   // mk
    //   var y = this.tagMode.tags.filter(
    //     y => y.tagID == tag.tagID
    //   );
    //   this.availableTags = this.availableTags.filter(y => y.tagID !== tag.tagID);
    //   // ****
  }

  public questionSelected(question: Question) {

    if (this.selectedQuestions == undefined) {
      this.selectedQuestions = [];
    }
    var x = this.selectedQuestions.filter(x => x.questionID == question.questionID);
    if (x.length <1) {
      this.selectedQuestions.push(question);
    }
    this.availableQuestions = this.availableQuestions.filter(x => x.questionID !== question.questionID);

  }


  // searchTagOrQuestion() {
  //   debugger;
  //   if(this.tag.searchText==undefined){
  //     this.tag.searchText="";
  //   }
  //   let text = this.tag.searchText.toLowerCase();
  //   this.availableTags = [];
    
  //   if (this.tagList.length > 0) {
  //     // let filteredTags = this.tagList.filter(x => x.tagName.indexOf(text) > -1);
  //     let filteredTags = this.tagList.filter(x => x.tagDisplayName.toLowerCase().indexOf(text) > -1);
  //     for (let tg of filteredTags) {
  //       let x = this.selectedTags.filter(x => x.tagID == tg.tagID);
  //       if (x.length < 1) {
  //         this.availableTags.push(tg);
  //       }
  //     }
  //   }

  //   this.availableQuestions = [];
  //   if (this.questionList.length > 0) {
  //     let filteredQuestions = this.questionList.filter(x => x.questionText.toLowerCase().indexOf(text) > -1);
  //     for (let qn of filteredQuestions) {
  //       let x = this.selectedQuestions.filter(x => x.questionID == qn.questionID);
  //       if (x.length < 1) {
  //         this.availableQuestions.push(qn);
  //       }
  //     }
  //   }

  //     // for tag
  //     this.availableTags = this.availableTags.filter(at => {
  //       let result = true;
  //       this.tagMode.tags.forEach(cq => {
  //         if (cq.tagID == at.tagID) {
  //           result = false;
  //         }
  //       });
  //       return result;
  //     }
  //     );
  //     // ****

  // }

  searchTagOrQuestion() {
    console.log(this.tag.searchText)
    const searchText = this.tag.searchText || "";
    const text = searchText.toLowerCase();
    
    // Filter available tags based on tagDisplayName
    this.availableTags = this.tagList.filter(tag => 
        tag.tagDisplayName.toLowerCase().includes(text) &&
        this.selectedTags.every(selectedTag => selectedTag.tagID !== tag.tagID)
    );
    
    // Filter available questions based on questionText
    this.availableQuestions = this.questionList.filter(question => 
        question.questionText.toLowerCase().includes(text) &&
        this.selectedQuestions.every(selectedQuestion => selectedQuestion.questionID !== question.questionID)
    );

    // Exclude tags that are already in tagMode.tags
    this.availableTags = this.availableTags.filter(tag => 
        !this.tagMode.tags.some(cq => cq.tagID === tag.tagID)
    );
}


  filterTagOrQuestion() {
   
    let text = this.tag.filterText;
  }

  save() {

    this.tag.tags = this.selectedTags;
    this.tag.questions = this.selectedQuestions;
    //if (this.tag.tagTypeID == 1) {
    //  this.tag.tagName = '#' + this.tag.tagName;
    //}
    //else if (this.tag.tagTypeID == 2) {
    //  this.tag.tagName = '@' + this.tag.tagName;
    //}
    //else if (this.tag.tagTypeID == 3) {
    //  this.tag.tagName = '§' + this.tag.tagName;
    //}
    this.tagService.insertTag(this.tag).subscribe(res => {
      this.alertText = this.labels.default.insertedSuccessfully;
      this.modalService.show(this.warningModal);
      $("modal-container").removeClass("fade");
      $(".modal-dialog").addClass("modalSize");
      this.router.navigate(['/tag-list']);
    },
      err => console.log(err));

  }

  delete(tag: any) {
    this.tagService.deleteTag(tag).subscribe(
      res => {
        
        if (res.tagID !== 0) {

          this.alertText = this.labels.default.deleteSuccessfully;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
          this.router.navigate(['/tag-list']);

          //this.isAdd = false;
          //this.isEdit = false;
        }
        else {
          
          this.alertText = this.labels.default.failedDeleteQuestion;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
        }

      },
      err => {
        console.log(err);
      });
  }


  removeTag(tag: Tag) {
  
    if (tag !== undefined && Object.keys(tag).length !== 0) {
      let id = tag.tagID;
      this.selectedTags = this.selectedTags.filter(x => x.tagID !== id);
      this.availableTags.push(tag);
    };
    
  }

  removeQuestion(question: Question) {
  
    if (question !== undefined && Object.keys(question).length !== 0) {
      let id = question.questionID;
      this.selectedQuestions = this.selectedQuestions.filter(x => x.questionID !== id);
      this.availableQuestions.push(question);
    };
  }

  onClose(){
    this.bsModalRef.hide();
  }


    /** Method is responsible to show View All Supplier pop up table */
    open(template: TemplateRef<any>) {
      this.modalRef = this.modalService.show(template, this.config);
      this.modalRef.setClass('modal-lg');
      this.getTagQuestionList(); //moev this call into onclick of add tag
     // this.searchTagOrQuestion();
    }


  filterModal(contentFilter, event) {
    // this.modalService.open(contentShift, {centered:true,backdropClass: 'light-blue-backdrop',windowClass: 'dark-modal' });
    // this.buttonId=event.target.id;

    this.open(contentFilter);
  }
  
  //------------to fetch the questions related wth the particular tagID in taginfo popup
  TagQuestionPopInfo(id: number) {

    this.TagInfoID = id;
    this.TagInfoText = this.tagMode.tags.filter(
      x => x.tagID == this.TagInfoID
    )[0].tagName;


    // this.tagService.getQuestionsByTagID(id).subscribe(res => {
      this.tagModeService.getInfoQuestionsByTagID(id).subscribe(res => {
      
      this.selectedQuestionsByTagID = res;
    }, err => console.log(err));

  }


}
