import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
//import { ProcessConfirmationComponent } from './process-confirmation/process-confirmation.component';
import { TagModeComponent } from './tag-mode/tag-mode.component';
import { ProcessConfirmationmodeRoutingModule } from './process-confirmationmode-routing.module';
import { EmptyProcessconfirmationComponent } from './empty-processconfirmation/empty-processconfirmation.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { DatePipe } from '@angular/common';
import { SharedModule } from 'src/app/shared/shared.module'
import { TimepickerModule } from 'ngx-bootstrap/timepicker';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';



import { PaginationModule } from 'ngx-bootstrap/pagination';
import { NgxPaginationModule } from 'ngx-pagination';
import { OrderModule } from 'ngx-order-pipe';
import { ModalModule } from 'ngx-bootstrap/modal';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
@NgModule({
  declarations: [
    //ProcessConfirmationComponent,
    TagModeComponent,
    EmptyProcessconfirmationComponent,
    
  ],
  imports: [
    CommonModule,
    ProcessConfirmationmodeRoutingModule,
    NgMultiSelectDropDownModule.forRoot(),    
    BsDatepickerModule.forRoot(),
    TimepickerModule.forRoot(),
    ModalModule.forRoot(),
    TooltipModule.forRoot(),
    FormsModule,    
    NgxPaginationModule,
    ReactiveFormsModule,
    SharedModule,
    PaginationModule.forRoot(),
    OrderModule,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class ProcessConfirmationmodeModule { }
