import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';


@Component({
  selector: 'app-empty-processconfirmation',
  templateUrl: './empty-processconfirmation.component.html',
  styleUrls: ['./empty-processconfirmation.component.css']
})
export class EmptyProcessconfirmationComponent implements OnInit {
  modeType: any;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
  ) { 
   
  }

  ngOnInit(): void {

    
    this.route.params.subscribe(params => {
      this.startProcessConfirmation();
      // this.modeType = params["mode"] || "shuffle";
      // alert(this.modeType)
      // if (params["mode"] == "tag") {
        
      // }
    });
  }
  startProcessConfirmation () {
    alert(this.router.navigate)
    this.router.  navigate([ '/plant/processConfirmation'
    ]);}

}
