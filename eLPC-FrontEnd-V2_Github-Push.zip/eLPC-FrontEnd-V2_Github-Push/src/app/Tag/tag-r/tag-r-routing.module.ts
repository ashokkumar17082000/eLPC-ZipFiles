import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TagEditComponent } from '../tag/tag-edit.component';
import { TagListComponent } from '../tag/tag-list.component';
import { TagLockComponent } from '../tag/tag.lock.component';

const routes: Routes = [
  { path: 'tag-edit', component: TagEditComponent },
  { path: 'tag-lock', component: TagLockComponent },
  { path: '', component: TagListComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TagRRoutingModule { }
