import { User } from "src/app/main/body/shared/common";
import { ValueStream } from "src/app/Valuestream/valuestreams/valuestreamtemplate";
import { Assessor } from "src/app/Assessor/assessor/assessortemplate";
import { assessorTemplateData, valueStreamTemplateData } from "src/app/Datapool/QuestionModule/questions/question";

export class Tag {
  tagID?: number;
  tagDisplayID?: number;
  tagModeTagsID?:number;
  tagName?: string;
  customModeID?:number;
  isSingleQuestionSuppressed?: boolean;
  suppressedDateRangeFrom?: Date;
  suppressedDateRangeTo?: Date;
  isTargetFrequencyDefined?: boolean;
  targetFrequencyTypeID?: number;
  targetFrequencyValue?: string;
  tag_PriorityID?: number;
  tagTypeID?: number;
  isLocked?: boolean;
  anonymizeUserDataSettingID?: number;
  isBranchLogicToBeFollowed?: boolean;
  isMandatoryAssessorsDefined?: boolean;
  isSaveTag:number;
  isRandomQuestion?:boolean;
  isDeleted?: boolean;
  modifiedAt?: Date;
  createdAt?: Date;
  createdBy?: string;
  modifiedBy?: string;
  searchText: any;
  filterText: any;
  tags?: any;
  questions?: any;
  resultCode: number;
  createdBy_NTID?: string;
  modifiedBy_NTID?: string;
 tagDisplayName?:string;
 assessors?: Assessor[];
 valueStreams?: ValueStream[];
 assigned_ValueStreamTemplateID?: number[] = [];
 assigned_ValueStreamCategoryID?: number[] = [];
 assigned_AssessorTemplateID?: number[] = [];
 FormattedTag?:String;


//  **newly added to fetch full tagdetails***

 valueStreamNameList:string;
 assessorNameList:string
 valueStreamTemplateName:string;
 assessorTemplateName:string;
 valueStreamIDList : string;

 assessorIDList : string;


 valueStreamTemplateNameArL: valueStreamTemplateData[];
 assessorTemplateNameArL: assessorTemplateData[];

 isAccessible?: boolean;
 isSearchableTag?: boolean;
 isSkipQuestionDefined?:boolean;
 isQuestionOverviewDefined?:boolean;
 isProgressPercentageDefined?:boolean;
 isResultOverviewDefined?:boolean;
 isResumeTagDefined?:boolean;
 isReportingEmailDefined?:boolean;
 FinalQuestionOrder=[];
 RandomQuestionsOnly=[];

 IsTagModeSelected?: boolean;
 inlineCount?: number = 0;
 isInlineModeOn: boolean = false;

}
export class TagProxy {
  id?: number;
  tagID?: number;
  proxies: User[];
  createdBy_NTID?: string;
  modifiedBy_NTID?: string;
  resultCode: number;

  customQuestionTagsID:number;
  tagModeTagsID:number;
  ntid:string;
  userName:string;
}

export class TagStreamHistory {
  TagHistoryID ?:number;
  TagHistoryDisplayID ?:number;
  TagID ?:number;
  TagName ?:string;
  ModifiedBy_NTID ?:any;
  ModifiedBy ?:string;
  ModifiedAt : Date;
  CreatedAt : Date;
}

export class AssessorValueStreamList {
assessorIDs?: string;
valueStreamIDs?: string;
}

export class TagDetails {
  tagID?: number;
  tagName?: string;
  isSingleQuestionSuppressed?: boolean;
  suppressedDateRangeFrom?: Date;
  suppressedDateRangeTo?: Date;
  isTargetFrequencyDefined?: boolean;
  targetFrequencyTypeID?: number;
  targetFrequencyValue?: string;
  tag_PriorityID?: number;
  tagTypeID?: number;
  isLocked?: boolean;
  anonymizeUserDataSettingID?: number;
  isBranchLogicToBeFollowed?: boolean;
  isMandatoryAssessorsDefined?: boolean;
  isDeleted?: boolean;
  modifiedAt?: Date;
  createdAt?: Date;
  createdBy?: string;
  modifiedBy?: string;
    searchText: any;
  filterText: any;
  tags?: any;
  questions?: any;
  resultCode: number;
  createdBy_NTID?: string;
  modifiedBy_NTID?: string;
 tagDisplayName?:string;
 assessors?: Assessor[];
 valueStreams?: ValueStream[];
 assigned_ValueStreamTemplateID?: number[] = [];
 assigned_ValueStreamCategoryID?: number[] = [];
 assigned_AssessorTemplateID?: number[] = [];

 valueStreamNameList:string;
 assessorNameList:string
 valueStreamTemplateName:string;
 assessorTemplateName:string;
 IsTagModeSelected?: boolean;
 InlineCount?: number = 0;
}
