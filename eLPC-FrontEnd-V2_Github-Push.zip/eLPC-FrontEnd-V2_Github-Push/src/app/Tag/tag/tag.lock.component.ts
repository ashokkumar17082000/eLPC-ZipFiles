import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { SharedService } from 'src/app/service/shared.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { OrderPipe } from 'ngx-order-pipe';
import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { Router } from '@angular/router';
import { TagProxy, Tag } from 'src/app/Tag/tag/tag';
import { CommonService } from 'src/app/service/common/common.service';
import { TagService } from 'src/app/service/tag.service';
import { User } from 'src/app/main/body/shared/common';
import { LanguageService } from 'src/app/language.service';
import { environment } from 'src/environments/environment';
import {SearchService} from 'src/app/service/search.service';
declare var $;

@Component({
  selector: 'app-tag-lock',
  templateUrl: './tag.lock.component.html',
  styleUrls: ['./tag-edit.component.css']
})
export class TagLockComponent implements OnInit {
  tag: Tag = new Tag();
  tagProxy: TagProxy = new TagProxy();
  activeDirectoryData: any[];
  labels: any;
  _subscription: any;
  @ViewChild('alertPopup') warningModal : TemplateRef<any>;
  @ViewChild('successPopup') successModal : TemplateRef<any>;
  errorMessage: string;

  constructor(private local_label:LanguageService, private modalService: BsModalService, private sharedService: SharedService, private tagService: TagService, private orderPipe: OrderPipe,
    private fb: FormBuilder, private datePipe: DatePipe, private http: HttpClient, private commonService: CommonService, private router: Router,private searchService: SearchService) {
    this.tag = this.tagService.tag;
    this.proxies = [];

    this.tagService.tagProxiesByTagID(this.tag.tagID).subscribe(res => {
      this.proxies = [];
      let usrs = res;
      if(usrs!){
      this.proxies = res;;
      }
  },
  );
  }

  ngOnInit() {
    this.labels = this.local_label.localizeLanguage;
    this._subscription = this.local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
    });
    this.searchService.getSearchResults().subscribe({
      next: (response: any) => {
        if (response && response.value) {
          this.activeDirectoryData = response.value;
          //this.usersAD = response.value;
          this.errorMessage = ''; // Clear any previous error messages
        } else {
          this.activeDirectoryData = [];
          this.errorMessage = 'No users found.';
        }
      },
      error: (err) => {
        console.error('Failed to fetch users from Graph API', err);
        this.errorMessage = 'Failed to fetch users. Please try again later.';
      }
    });
  }

  /** for Proxy */

  removeProxy(event: any) {
    let ntid = event.target.id;
    this.proxies = this.proxies.filter(x => x.ntid !== ntid);
  }

  //for new Active Directory Search
user: any;
proxies: any;
onChangeSearch(term: string) {

  // let user = new User();
  // user.firstName = this.user;
  // this.commonService.activeDirectoryByName(user).subscribe(res => {
  //   this.activeDirectoryData = [];
  //   this.activeDirectoryData = res;
  // },
  //   err => console.error(err));
  this.searchService.setSearchTerm(term);
}

// selectUser(user:any){

//   if (user !== null) {
//     let x = this.proxies.filter(x => x.ntid == user.ntid);
//     if (x.length == 0)
//     this.proxies.push(user);
//   }

//   this.activeDirectoryData = [];
//   this.user = undefined;
// }
selectUser(user:any){

  if (user !== null) {
    let x = this.proxies.filter(x => x.ntid == user.ntid);
    if (x.length == 0)
    this.proxies.push(user);
    this.proxies.forEach(x => {
      // Check if the userPrincipalName of the current attendee matches the userPrincipalName of the new user
      if (x.userPrincipalName === user.userPrincipalName) {
        // If they match, set the ntid property to the userPrincipalName
        if (user.userPrincipalName && user.userPrincipalName.includes('@')) {
          x.ntid = user.userPrincipalName.split('@')[0].toUpperCase();
        }
        if (user.givenName && user.surname && user.mail && user.displayName)
        {
         x.emailAddress = user.mail;
         x.firstName = user.givenName;
         x.lastName = user.surname;
         x.userName = user.displayName;
       }
      }
    });
  }

  this.activeDirectoryData = [];
  this.user = undefined;
}

//-===============
setLock(){
  if(!this.tag.isLocked){
   this.proxies = [];
  }
}
alertText;
  saveLockSettings() {
    if(this.tag.isLocked){
      if(this.proxies.length <1){
        this.alertText = this.labels.default.proxyRequired;
          this.modalService.show(this.warningModal);
          $("modal-container").removeClass("fade");
          $(".modal-dialog").addClass("modalSize");
        return;
      }
    }
    this.tagProxy = new TagProxy();
    this.tagProxy.tagID = this.tag.tagID;
    this.tagProxy.proxies = this.proxies;
    if(this.tag.isLocked){
      if(this.tagService.tag){
        this.tagService.tag.isLocked = true;
      }
      if(this.sharedService.ntid){
        if(!this.tagProxy.createdBy_NTID)
        {
        this.tagProxy.createdBy_NTID = this.sharedService.ntid;
        }
        this.tagProxy.modifiedBy_NTID = this.sharedService.ntid;
      }
    this.tagService.insertTagProxy(this.tagProxy).subscribe(res => {
      if (res.resultCode == 0) {
        this.alertText = this.labels.default.saveSuccessfully;
        this.modalService.show(this.successModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
        this.router.navigate([environment.home +'/taglist/tag-edit']);
      }
    }, err => {console.error(err);
        this.alertText = this.labels.default.insertOpertionFailed;
        this.modalService.show(this.warningModal);
        $("modal-container").removeClass("fade");
        $(".modal-dialog").addClass("modalSize");
  }
    );
}
    else
    {
     this.tagService.insertTag(this.tag).subscribe(res => {
     this.alertText = this.labels.default.saveSuccessfully;
     this.modalService.show(this.successModal);
     $("modal-container").removeClass("fade");
     $(".modal-dialog").addClass("modalSize");
     this.router.navigate([environment.home +'/taglist/tag-edit']);
  });
 }
  }


  redirect()
  {
    this.router.navigate([environment.home +'/taglist/tag-edit']);
  }

  //to fix scroll issue after pop up
  public closeAlertModal(){
    if(document.getElementsByTagName("modal-container").length > 1){
      document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length-1].parentNode.removeChild(document.getElementsByTagName("modal-container")[document.getElementsByTagName("modal-container").length-1]);
    }
    else{
      document.getElementsByTagName("modal-container")[0].parentNode.removeChild(document.getElementsByTagName("modal-container")[0]);
      if(document.getElementsByTagName("bs-modal-backdrop").length > 0){
        document.getElementsByTagName("bs-modal-backdrop")[0].parentNode.removeChild(document.getElementsByTagName("bs-modal-backdrop")[0]);
      }
      document.querySelector('body').classList.remove('modal-open');
    }

  }

}//end of the class





