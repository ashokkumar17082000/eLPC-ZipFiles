import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
//import { SharedService } from '../../../service/shared.service';
import { SharedService } from 'src/app/service/shared.service';
//import { LanguageService } from '../../../language.service';
import { LanguageService } from 'src/app/language.service';
import { UserProfileService } from 'src/app/service/user-profile.service';
//import { usercustomIcon } from '../user-profile/userProfile';
import { usercustomIcon } from 'src/app/UserProfile/userprofile-c/userProfile';
import { Subscription } from 'rxjs';
import { ErrorEventService } from 'src/app/service/error-event.service';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  role: any;
  displayName: any;
  labels: any;
  _subscription: any;
  errorSubscription:Subscription;
  firstCustomIcon:any;
  secondCustomIcon:any;
  firstcustomiconsrc:string;
  firstcustomicon_Iconname:string;
  firstcustomicon_routerlink:string;
  secondcustomiconsrc:string;
  secondcustomicon_Iconname:string;
  secondcustomicon_routerlink:string;
  

   routes = {
    1: "../processConfirmation",
    2: "../customMode",
    3: "../tagMode",
    4: "../calendar",
    5: "../valuestreams",
    6:"../assessors",
    7:"../datapool/questions",
    8:"../taglist",
    9:"../merge",
    10:"../recyclebin",
    11:"../datapool",
    12:"../deviationpool",
    13:"../calendarListing",
    14:"../superOPL",
    15:"../adminReport",
    16:"../adminReport/powerBIExport",
    17:"../launchpad",
    18:"../launchpad/launchpadsettings",
    19:"../userProfile",
    20:"../infoAndHelp",
    // Add mappings for other icons
  };

  
  

  constructor(private sharedService: SharedService, private local_label: LanguageService,
    private userProfileService: UserProfileService,private errorEventService: ErrorEventService,
  ) {
    this.role = this.sharedService.role;
    this.displayName = this.sharedService.displayName;
    this.labels = local_label.localizeLanguage;
    this._subscription = local_label.LanguageChange.subscribe((value) => {
      this.labels = value;
    });
  }

  /** Load the initial data for the dashboard to show the error message 'No matching records found for this filter criteria'
   *  if data does not exists */
  ngOnInit() {
    this.sharedService.setIconName("Shuffle Mode");
    this.sharedService.hide();
    this.getUserProfileVSAS();
  //    this.errorSubscription = this.errorEventService.getErrorEvent().subscribe((errorCode) => {
  //    // alert(367)
  //  //  alert(78)
     
  //       // this.showModal499(errorCode);
     
  //   });
  }

  //   ngOnDestroy(): void {
  //   if (this.errorSubscription) {
  //     this.errorSubscription.unsubscribe();
  //   }
  // }

  ngAfterViewInit()
  {
    setTimeout(() => {
      this.sharedService.setIcon("assets/image/Material.svg");
    }, 100);
  }

  public getUserProfileVSAS() {
    this.userProfileService.getUserProfileVSAS().subscribe(res => {
      console.log(res)   
      if(res!==undefined && res.usercustomIcon!== undefined && res.usercustomIcon[0]!==undefined && res.usercustomIcon[0].customeIconID!==undefined &&res.usercustomIcon[0].customeIconID!==null){
        this.firstCustomIcon=res.usercustomIcon[0].customeIconID;
      }
      if(res!==undefined && res.usercustomIcon!== undefined && res.usercustomIcon[1]!==undefined &&res.usercustomIcon[1].customeIconID!==undefined &&res.usercustomIcon[1].customeIconID!==null){
        this.secondCustomIcon=res.usercustomIcon[1].customeIconID;
      }

      if(this.firstCustomIcon)
      //debugger;
      console.log("first",this.firstCustomIcon)
      console.log("second",this.secondCustomIcon)

     
      

      switch (this.firstCustomIcon) {
        case 1:
          this.firstcustomiconsrc='assets/image/settings-arrows.svg'
          break;
          case 2:
          this.firstcustomicon_Iconname='wand'
          break;
          case 3:
          this.firstcustomicon_Iconname='user'
          break;
          case 4:
          this.firstcustomicon_Iconname='calendar'
          break;
          case 5:
          this.firstcustomicon_Iconname='industry'
          break;
        case 6:
          this.firstcustomiconsrc='assets/image/assessor.svg'
          break;
        case 7:
          this.firstcustomicon_Iconname='question'
          break;
        case 8:
          this.firstcustomicon_Iconname='bookmark'
          break;
        case 9:
          this.firstcustomiconsrc='assets/svg/shrinking-arrows-circle.svg'
          break;
        case 10:
          this.firstcustomiconsrc='assets/svg/shrinking-arrows-circle.svg'
          break;
        case 11:
          this.firstcustomicon_Iconname='question'
          break;
        case 12:
           this.firstcustomicon_Iconname='clipboard'
          break;
        case 13:
         this.firstcustomicon_Iconname='calendar-clock'
        break;
        case 14:
         this.firstcustomicon_Iconname='calendar-clock'
        break;
        case 15:
         this.firstcustomicon_Iconname='clipboard-list'
        break;
        case 16:
         this.firstcustomicon_Iconname='clipboard'
        break;
        case 17:
        this.firstcustomicon_Iconname='clipboard'
        break;
        case 18:
         this.firstcustomicon_Iconname='clipboard'
        break;
        case 19:
        this.firstcustomicon_Iconname='user'
        break;
        case 20:
         this.firstcustomicon_Iconname='welcome'
        break;

        default:
          // Code to execute if no case matches
          break;
      }

      switch (this.secondCustomIcon) {
        case 1:
          this.secondcustomiconsrc='assets/image/settings-arrows.svg'
          break;
          case 2:
          this.secondcustomicon_Iconname='wand'
          break;
          case 3:
          this.secondcustomicon_Iconname='user'
          break;
          case 4:
          this.secondcustomicon_Iconname='calendar'
          break;
          case 5:
          this.secondcustomicon_Iconname='industry'
          break;
        case 6:
          this.secondcustomiconsrc='assets/image/assessor.svg'
          break;
        case 7:
          this.secondcustomicon_Iconname='question'
          break;
        case 8:
          this.secondcustomicon_Iconname='bookmark'
          break;
        case 9:
          this.secondcustomiconsrc='assets/svg/shrinking-arrows-circle.svg'
          break;
        case 10:
          this.secondcustomiconsrc='assets/svg/shrinking-arrows-circle.svg'
          break;
        case 11:
          this.secondcustomicon_Iconname='question'
          break;
        case 12:
           this.secondcustomicon_Iconname='clipboard'
          break;
        case 13:
         this.secondcustomicon_Iconname='calendar-clock'
        break;
        case 14:
         this.secondcustomicon_Iconname='calendar-clock'
        break;
        case 15:
         this.secondcustomicon_Iconname='clipboard-list'
        break;
        case 16:
         this.secondcustomicon_Iconname='clipboard'
        break;
        case 17:
        this.secondcustomicon_Iconname='clipboard'
        break;
        case 18:
         this.secondcustomicon_Iconname='clipboard'
        break;
        case 19:
        this.secondcustomicon_Iconname='user'
        break;
        case 20:
         this.secondcustomicon_Iconname='welcome'
        break;

        default:
          // Code to execute if no case matches
          break;
      }


      this.sharedService.hide();

    }, err => {
      console.log(err);
      //this.getValueStreamList(); this.getAssessorTemplateList(); 
    });
  }


  
  getButtonLabel(icon: number): string {
  //  debugger;
    const labels = {
      1: this.labels.default.shuffleMode,
      2: this.labels.default.customMode,
      3: this.labels.default.tagMode,
      4: this.labels.default.menu_calendar,
      5: this.labels.default.subMenuVS,
      6: this.labels.default.subMenuAssessor,
      7: this.labels.default.subMenuQuestion,
      8: this.labels.default.subMenuTag,
      9: this.labels.default.merge,
      10: this.labels.default.subMenuRecycle,
      11: this.labels.default.subMenuDataPool + " - " + this.labels.default.answers,
      12: this.labels.default.subMenuDataPool+ " - " + this.labels.default.deviationName,
      13: this.labels.default.subMenuDataPool + " - " + this.labels.default.menu_calendar,
      14: this.labels.default.menu_superOPL,
      15: this.labels.default.menu_reports_Admin,
      16: this.labels.default.export,
      17: this.labels.default.launchpad,
      18: this.labels.default.launchpadsetting,
      19: this.labels.default.menu_UserProfile,
      20: this.labels.default.infoAndHelp,
      // Add mappings for other icons
    };
    return labels[icon] || "Default";
  }


}
