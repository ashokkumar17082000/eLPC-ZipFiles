import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';
import { applyPolyfills,defineCustomElements } from '../node_modules/rb.frontend.kit-npm/dist/loader/index';

//const QUOTE = "example quote";


platformBrowserDynamic().bootstrapModule(AppModule)
  .catch(err => console.error(err));
  defineCustomElements(window);
  applyPolyfills().then(() => {
    defineCustomElements(window)
  })
