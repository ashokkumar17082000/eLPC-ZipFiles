
alter table grp10.[T_TRN_Deviation] add IsDeviationEntry  nvarchar(20) null
GO

CREATE TABLE  grp10.[T_TRN_AddtoOPL] (
    [ScheduleId] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [PlantId] INT NOT NULL,
    [ScheduleName] NVARCHAR(250) NOT NULL,
    [DataObj] NVARCHAR(MAX) NULL,
    [ExecutionCount] INT NOT NULL DEFAULT (0),
    [IsCompleted] BIT NOT NULL DEFAULT (0),
    [LastRunAt] DATETIME NULL,
    [ErrorDetail] NVARCHAR(MAX) NULL,
    [CreatedAt] DATETIME NOT NULL DEFAULT (GETDATE()),
    [ModifiedAt] DATETIME NULL DEFAULT (GETDATE()),
    [IsDeleted] BIT NOT NULL DEFAULT (0),
    [CreatedBy_NTID] NVARCHAR(20) NOT NULL,
    [ModifiedBy_NTID] NVARCHAR(20) NULL,
    [MaxExecutionCount] INT NOT NULL DEFAULT (-1),
    [RecentErrorDetail] NVARCHAR(MAX) NULL
);
GO
---------------------------------------


/****** Object:  StoredProcedure [uatgrp10].[USP_AddCreateOPL]    Script Date: 27.04.2025 14:43:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE   grp10.[USP_AddCreateOPL]
(
    @PlantId INT,
    @ScheduleName NVARCHAR(250),
    @DataObj NVARCHAR(MAX) NULL,
    @ErrorDetail NVARCHAR(MAX) NULL,    
    @CreatedBy_NTID NVARCHAR(20)

)
AS 
BEGIN
    SET NOCOUNT ON;
    SET LOCK_TIMEOUT 5000;

    DECLARE @InsertedId INT;

    INSERT INTO [T_TRN_AddtoOPL] (
        [PlantId],
        [ScheduleName],
		[DataObj],
        [ErrorDetail],
        [CreatedAt],
        [CreatedBy_NTID]
       )
    VALUES
    (
        @PlantId,
        @ScheduleName,
		   @DataObj,
        @ErrorDetail,
        GETDATE(),
        @CreatedBy_NTID
     
    );

    -- Get the last inserted ID
    SET @InsertedId = SCOPE_IDENTITY();
	
    -- Return the value explicitly
    SELECT @InsertedId AS ScheduleId;
END

--------------------------------------------


GO
/****** Object:  StoredProcedure [uatgrp10].[USP_Insertprocessconfimration_TagMode_DeviationWithoutPicAdditionalsettings]    Script Date: 27.04.2025 14:45:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO






CREATE PROCEDURE   grp10.[USP_GetAllActiveDeviation]
@OnlyMaxExecuted BIT = NULL
AS BEGIN
	SET LOCK_TIMEOUT 5000;

	SELECT * FROM [T_TRN_AddtoOPL] 
		WHERE [IsDeleted] = 0 
				AND [IsCompleted] = 0
				AND 
				(
					(@OnlyMaxExecuted = 1 AND ([ExecutionCount] = [MaxExecutionCount]))
					OR
					(@OnlyMaxExecuted IS NULL AND ([MaxExecutionCount] = -1 OR [ExecutionCount] < [MaxExecutionCount]))
				);
		END
-----------------------------------------------------------------


GO
/****** Object:  StoredProcedure [uatgrp10].[USP_SetDeviationCompleted]    Script Date: 27.04.2025 14:49:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE  grp10.[USP_SetDeviationCompleted]
@ScheduleId INT,
	@MaxExecutionCount INT,
	@ModifiedBy_NTID NVARCHAR(20)
AS BEGIN
	SET LOCK_TIMEOUT 5000;
	IF (EXISTS(SELECT * FROM [T_TRN_AddtoOPL] WHERE [ScheduleId] = @ScheduleId AND [IsDeleted] =0 AND [IsCompleted] =0 AND ([MaxExecutionCount] IS NULL OR [MaxExecutionCount] = -1))
				AND @MaxExecutionCount > 0)
	BEGIN
		UPDATE [T_TRN_AddtoOPL] SET [MaxExecutionCount] = @MaxExecutionCount 
			WHERE [ScheduleId] = @ScheduleId AND [IsDeleted]=0 AND [IsCompleted] =0;
	END


	UPDATE [T_TRN_AddtoOPL]  SET [IsCompleted] = 1, [ExecutionCount] = ([ExecutionCount]+1), [LastRunAt] = GETDATE(), [ModifiedAt] = GETDATE()
		WHERE [ScheduleId] = @ScheduleId AND [IsDeleted] =0 AND [IsCompleted] =0;

	
END
------------------------------------


GO
/****** Object:  StoredProcedure [uatgrp10].[USP_SetDeviationFailed]    Script Date: 27.04.2025 14:50:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE  grp10.[USP_SetDeviationFailed]
(
	@ScheduleId INT,
	@PlantID INT,
    @DataObj NVARCHAR(MAX),
	@ErrorDetail NVARCHAR(MAX),
	@MaxExecutionCount INT,
	@ModifiedBy_NTID NVARCHAR(20)
)
AS BEGIN
	SET LOCK_TIMEOUT 5000;

	IF (EXISTS(SELECT * FROM [T_TRN_AddtoOPL] WHERE [ScheduleId] = @ScheduleId AND [IsDeleted] = 0 AND [IsCompleted] = 0 AND ([MaxExecutionCount] IS NULL OR [MaxExecutionCount] = -1))
				AND @MaxExecutionCount > 0)
	BEGIN
		UPDATE [T_TRN_AddtoOPL] SET [MaxExecutionCount] = @MaxExecutionCount 
			WHERE [ScheduleId] = @ScheduleId AND [IsDeleted] = 0 AND [IsCompleted] = 0;
	END

	UPDATE [T_TRN_AddtoOPL]  SET [ExecutionCount] = ([ExecutionCount]+1), [LastRunAt] = GETDATE(), [RecentErrorDetail] = @ErrorDetail
		WHERE [ScheduleId] = @ScheduleId AND [IsDeleted] = 0 AND [IsCompleted] = 0;

		IF (EXISTS (SELECT * FROM [T_TRN_AddtoOPL] 
                WHERE [ScheduleId] = @ScheduleId 
                  AND [MaxExecutionCount] = 3 
                  AND [IsCompleted] = 0 
                  AND [ExecutionCount] = 3))
    BEGIN
        -- Insert data into T_TRN_Scheduler
        INSERT INTO T_TRN_Scheduler ( PlantID,ScheduleName,DataObj,ExecutionCount,IsCompleted, ErrorDetail, CreatedAt,ModifiedAt,IsDeleted,CreatedBy_NTID,ModifiedBy_NTID,RecentErrorDetail)
        values( @PlantID,'SuperOPL',@DataObj,0,0, @ErrorDetail,GETDATE(), GETDATE(),0,'','',@ErrorDetail
        );
	--SET @ScheduleId=SCOPE_IDENTITY();

		--EXEC [USP_AddSchedule]
        -- Update IsDeleted and Modified_By_NTID in T_TRN_AddtoOPL
       UPDATE [T_TRN_AddtoOPL]
        SET [IsDeleted] = 1, 
            [ModifiedBy_NTID] = 'Moved to scheduler'
        WHERE [ScheduleId] = @ScheduleId;
    END
	
END;
 -------------------------------------------------





Go



/****** Object:  StoredProcedure [USP_Insertprocessconfimration_TagMode_DeviationWithoutPicAdditionalsettings]    Script Date: 4/8/2025 11:36:49 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE grp10.[USP_Insertprocessconfimration_TagMode_DeviationWithoutPicAdditionalsettings]
    @ModeTypeID INT,
    @ValueStreamID INT,
    @AssessorID INT,
    @QuestionID INT,
    @Answer NVARCHAR(MAX),
    @AnswerType_AnswerTypeID INT,
    @CreatedAt DATETIME,
    @ModifiedAt DATETIME,
    @TagId INT,
    @AnsweredBy_NTID NVARCHAR(20),
    @IsDeviation BIT,
    @ObtainedSCore DECIMAL(10, 2),
    @DeviationDescription NVARCHAR(MAX),
    @ResponsibleEmployee NVARCHAR(50),
    @HintImages XML = NULL,
    @ChoiceID INT,
    @IsSHowVsAs BIT,
    @SessionID NVARCHAR(20) = NULL,
    @PlantID INT,
    @AdditionalEmployee XML = NULL,
    @TagName XML = NULL,
    @IsDeleted BIT = NULL,
    @CurrentUserNTID NVARCHAR(20) = NULL,
    @TagmodeID INT,
    @CustomModeID INT,
	@IsSkipMandatory BIT,
	@formattedDateTime NVARCHAR(50)=NULL,
	@EventID NVARCHAR(50)=NULL,
	@ResumeActive BIT,
	@AttemptNumber INT,
	@ChildEventID NVARCHAR(50)=NULL,
	@isinlineinsertprocess BIT,
	@frominline BIT,
	@isResumeActivated BIT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @DeviationID INT;
    DECLARE @Timestamp DATETIME;
	DECLARE @GeneratedDatapoolID INT;
	DECLARE @DeviationEntry INT;

    BEGIN TRY
        BEGIN TRANSACTION TRNINSERTPC;
		
		 -- Retrieve formatted date and time using the function fnGetDateTime
        SELECT @TimeStamp = FormattedDateTime
        FROM fnGetDateTime(@PlantID);

		 -- Set CreatedAt and ModifiedAt to the same value as Timestamp
        SET @CreatedAt = @Timestamp;
        SET @ModifiedAt = @Timestamp;
		
        -- Insert into T_TRN_Deviation
		 IF @IsSkipMandatory = 0 
		 		IF @IsDeviation =1
		BEGIN
		  SET @DeviationEntry =0
		  END
		ELSE 
		  SET @DeviationEntry =4


		 BEGIN
        INSERT INTO T_TRN_Deviation (
            DeviationDescription, ValueStreamID, ResponsibleEmployee,
            QuestionID, CreatedBy_NTID, CreatedAt, ModifiedAt,
            PlantID, DeviationDisplayID,IsDeviationEntry
        )
        VALUES (
            @DeviationDescription, @ValueStreamID, @ResponsibleEmployee,
            @QuestionID, @AnsweredBy_NTID, @CreatedAt, @ModifiedAt,
            @PlantID,
            (SELECT DisplayID FROM [FN_GetNextDisplayID](@PlantID, 'T_TRN_Deviation')),@DeviationEntry
        );
		END
        SET @DeviationID = SCOPE_IDENTITY();

        -- Insert into T_LNK_Tag_AnsweredQuestions if ModeTypeID is 3
        IF @ModeTypeID = 3 and @isinlineinsertprocess = 0
        BEGIN
            INSERT INTO T_LNK_Tag_AnsweredQuestions (
                TagID, QuestionID, CreatedAt, ModifiedAt,
                IsDeleted, AnswerTypeID, IsAnswered, Answer,
                CreatedBy_NTID, ModifiedBy_NTID, IsTagCompleted,
                IsTagActive, ValueStreamID, TagModeID, PlantID,
                DeviationDescription, ChoiceID
            )
            VALUES (
                @TagId, @QuestionID, @CreatedAt, @ModifiedAt,
                0, @AnswerType_AnswerTypeID, 1, @Answer,
                @AnsweredBy_NTID, @AnsweredBy_NTID, 0,
                1, @ValueStreamID, @TagmodeID, @PlantID,
                @DeviationDescription, @ChoiceID
            );
        END

		   IF @ModeTypeID = 2 
        BEGIN
            INSERT INTO T_LNK_Custom_AnsweredQuestions (
             TagID,QuestionID,CreatedAt,ModifiedAt
			,IsDeleted,AnswerTypeID	,IsAnswered	,Answer
			,CreatedBy_NTID	,ModifiedBy_NTID,IsCustomModeCompleted
			,ValueStreamID,CustomModeID	,PlantID,ChoiceID,DeviationDescription
            )
            VALUES (
              	@TagId,@QuestionID,@CreatedAt
			,@ModifiedAt,0,@AnswerType_AnswerTypeID
			,1,@Answer,@AnsweredBy_NTID	,@AnsweredBy_NTID
			,0	,@ValueStreamID,@CustomModeID
			,@PlantID	,@ChoiceID	,@DeviationDescription
			--@DeviationID	
            );
        END

		 IF @IsSkipMandatory = 0
		 BEGIN
        -- Insert into T_LNK_Deviation_AdditionalEmployee
        INSERT INTO T_LNK_Deviation_AdditionalEmployee (
            DeviationID, NTID, CreatedAt, ModifiedAt,
            IsDeleted, CreatedBy_NTID, UserName
        )
        SELECT
            @DeviationID,
            Emp.value('(NTID/text())[1]', 'NVARCHAR(100)'),
            @CreatedAt,
            @ModifiedAt,
            0,
            @AnsweredBy_NTID,
            Emp.value('(UserName/text())[1]', 'NVARCHAR(100)')
        FROM @AdditionalEmployee.nodes('/ArrayOfUser/User') AS TEMPTABLE(Emp);

        -- Insert into T_LNK_Deviation_AssignedTags
        INSERT INTO T_LNK_Deviation_AssignedTags (
            DeviationID, TagID, IsDeleted,
            CreatedAt, ModifiedAt, CreatedBy_NTID, TagName
        )
        SELECT
            @DeviationID,
            TagName.value('(TagID/text())[1]', 'int'),
            @IsDeleted,
            @CreatedAt,
            @ModifiedAt,
            @AnsweredBy_NTID,
            TagName.value('(FormattedTag/text())[1]', 'nvarchar(100)')
        FROM @TagName.nodes('/ArrayOfTag1/Tag1') AS TEMPTABLE(TagName);
		END
        -- Insert into T_TRN_DataPool

		 IF @IsSkipMandatory = 0
		 BEGIN
        INSERT INTO T_TRN_DataPool (
            TIMESTAMP, ValueStreamID, AssessorID, QuestionID,
            Answer, AnswerType_AnswerTypeID, AnsweredBy_NTID,
            CreatedAt, ModifiedBy_NTID, ModifiedAt, TagId,
            IsDeviation, ObtainedSCore, ChoiceID,DeviationID,
            IsSHowVsAs, SessionID, PlantID
        )
        VALUES (
            @Timestamp, @ValueStreamID, @AssessorID, @QuestionID,
            @Answer, @AnswerType_AnswerTypeID, @AnsweredBy_NTID,
            @CreatedAt, @AnsweredBy_NTID, @ModifiedAt, @TagId,
            @IsDeviation, @ObtainedSCore, @ChoiceID,@DeviationID,
            @IsSHowVsAs, @SessionID, @PlantID
        );
		END
		SET @GeneratedDatapoolID = SCOPE_IDENTITY();
		
		IF @isResumeActivated =1 and (@ModeTypeID=3 or @ModeTypeID=2) and @EventID is not null AND @EventID <> '' and @IsSkipMandatory=0
		BEGIN

		IF 	@frominline = 1
		BEGIN
			SET @ModeTypeID = 5;
		END
		INSERT INTO T_TRN_Eventid_Childtable (DatapoolID,EventID,childEventID,Attempt,modeid,createdon,modifiedon,EventID_Start_time,plantid)
		values (
		@GeneratedDatapoolID,@EventID,@ChildEventID,@AttemptNumber,@ModeTypeID
		,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,@formattedDateTime,@PlantID)
		END

		IF @isResumeActivated=0 and (@ModeTypeID=3 or @ModeTypeID=1 or @ModeTypeID=2) and @EventID is not null AND @EventID <> '' and @IsSkipMandatory=0
		BEGIN
		IF 	@frominline = 1
		BEGIN
			SET @ModeTypeID = 5;
		END
		INSERT INTO  T_TRN_EventId_Maintable
		(DatapoolID,EventID,valuestreamID,TagID,userNTID,EventID_Start_time,ModeID,CreatedAt,plantid)
		VALUES (
		@GeneratedDatapoolID,@EventID,@ValueStreamID,@TagID,@AnsweredBy_NTID,@formattedDateTime,@ModeTypeID,@ModifiedAt,@PlantID)
 		END

        COMMIT TRANSACTION TRNINSERTPC;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION TRNINSERTPC;

        EXEC [USP_LogError] @PlantID, @CurrentUserNTID;

        -- Set the DeviationID to indicate failure (optional)
        SET @DeviationID = 0; -- or any other value to indicate failure
    END CATCH;

    -- Select the DeviationID to return it
    SELECT @DeviationID AS DeviationID;
END
GO


/****** Object:  StoredProcedure [USP_Insertprocessconfimration_TagMode_DeviationWithPicAdditionalsettings]    Script Date: 4/8/2025 11:39:34 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE grp10.[USP_Insertprocessconfimration_TagMode_DeviationWithPicAdditionalsettings]
    @ModeTypeID INT,
    @ValueStreamID INT,
    @AssessorID INT,
    @QuestionID INT,
    @Answer NVARCHAR(MAX),
    @AnswerType_AnswerTypeID INT,
    @CreatedAt DATETIME,
    @ModifiedAt DATETIME,
    @TagId INT,
    @AnsweredBy_NTID NVARCHAR(20),
    @IsDeviation BIT,
    @ObtainedSCore DECIMAL(10, 2),
    @DeviationDescription NVARCHAR(MAX),
    @ResponsibleEmployee NVARCHAR(50),
    @HintImages XML = NULL,
    @ChoiceID INT,
    @IsSHowVsAs BIT,
    @SessionID NVARCHAR(20) = NULL,
    @PlantID INT,
    @AdditionalEmployee XML = NULL,
    @TagName XML = NULL,
    @IsDeleted BIT = NULL,
    @CurrentUserNTID NVARCHAR(20) = NULL,
    @TagmodeID INT,
    @CustomModeID INT,
	@IsSkipMandatory BIT,
	@formattedDateTime NVARCHAR(50)=NULL,
	@EventID NVARCHAR(50)=NULL,
	@ResumeActive BIT,
	@AttemptNumber INT,
	@ChildEventID NVARCHAR(50)=NULL,
	@isinlineinsertprocess BIT,
	@frominline BIT,
	@isResumeActivated BIT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @DeviationID INT;
    DECLARE @Timestamp DATETIME;
	DECLARE @GeneratedDatapoolID INT;
	DECLARE @DeviationEntry INT;
    BEGIN TRY
        BEGIN TRANSACTION TRNINSERTPC;
		INSERT  into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('START_TAG_PC_WITHPIC_Addsetting',@PlantID,@CurrentUserNTID, getdate(),@ModeTypeID)

		
		 -- Retrieve formatted date and time using the function fnGetDateTime
        SELECT @TimeStamp = FormattedDateTime
        FROM fnGetDateTime(@PlantID);

		 -- Set CreatedAt and ModifiedAt to the same value as Timestamp
        SET @CreatedAt = @Timestamp;
        SET @ModifiedAt = @Timestamp;
		
		IF @IsSkipMandatory = 0

		 		IF @IsDeviation =1
		BEGIN
		  SET @DeviationEntry =0
		  END
		ELSE 
		  SET @DeviationEntry =4
		 BEGIN
        -- Insert into T_TRN_Deviation
        INSERT INTO T_TRN_Deviation (
            DeviationDescription, ValueStreamID, ResponsibleEmployee,
            QuestionID, CreatedBy_NTID, CreatedAt, ModifiedAt,
            PlantID, DeviationDisplayID,IsDeviationEntry
        )
        VALUES (
            @DeviationDescription, @ValueStreamID, @ResponsibleEmployee,
            @QuestionID, @AnsweredBy_NTID, @CreatedAt, @ModifiedAt,
            @PlantID,
            (SELECT DisplayID FROM [FN_GetNextDisplayID](@PlantID, 'T_TRN_Deviation')),@DeviationEntry
        );
		 END

        SET @DeviationID = SCOPE_IDENTITY();

        -- Insert into T_LNK_Tag_AnsweredQuestions if ModeTypeID is 3
        IF @ModeTypeID = 3 and @isinlineinsertprocess = 0
        BEGIN
            INSERT INTO T_LNK_Tag_AnsweredQuestions (
                TagID, QuestionID, CreatedAt, ModifiedAt,
                IsDeleted, AnswerTypeID, IsAnswered, Answer,
                CreatedBy_NTID, ModifiedBy_NTID, IsTagCompleted,
                IsTagActive, ValueStreamID, TagModeID, PlantID,
                DeviationDescription, ChoiceID
            )
            VALUES (
                @TagId, @QuestionID, @CreatedAt, @ModifiedAt,
                0, @AnswerType_AnswerTypeID, 1, @Answer,
                @AnsweredBy_NTID, @AnsweredBy_NTID, 0,
                1, @ValueStreamID, @TagmodeID, @PlantID,
                @DeviationDescription, @ChoiceID
            );
        END

		IF @ModeTypeID = 2
        BEGIN
            INSERT INTO T_LNK_Custom_AnsweredQuestions (
             TagID,QuestionID,CreatedAt,ModifiedAt
			,IsDeleted,AnswerTypeID	,IsAnswered	,Answer
			,CreatedBy_NTID	,ModifiedBy_NTID,IsCustomModeCompleted
			,ValueStreamID,CustomModeID	,PlantID,ChoiceID,DeviationDescription
            )
            VALUES (
              	@TagId,@QuestionID,@CreatedAt
			,@ModifiedAt,0,@AnswerType_AnswerTypeID
			,1,@Answer,@AnsweredBy_NTID	,@AnsweredBy_NTID
			,0	,@ValueStreamID,@CustomModeID
			,@PlantID	,@ChoiceID	,@DeviationDescription
			--@DeviationID	
            );
        END

		IF @IsSkipMandatory = 0
		 BEGIN
        -- Insert into T_LNK_Deviation_AdditionalEmployee
        INSERT INTO T_LNK_Deviation_AdditionalEmployee (
            DeviationID, NTID, CreatedAt, ModifiedAt,
            IsDeleted, CreatedBy_NTID, UserName
        )
        SELECT
            @DeviationID,
            Emp.value('(NTID/text())[1]', 'NVARCHAR(100)'),
            @CreatedAt,
            @ModifiedAt,
            0,
            @AnsweredBy_NTID,
            Emp.value('(UserName/text())[1]', 'NVARCHAR(100)')
        FROM @AdditionalEmployee.nodes('/ArrayOfUser/User') AS TEMPTABLE(Emp);

        -- Insert into T_LNK_Deviation_AssignedTags
        INSERT INTO T_LNK_Deviation_AssignedTags (
            DeviationID, TagID, IsDeleted,
            CreatedAt, ModifiedAt, CreatedBy_NTID, TagName
        )
        SELECT
            @DeviationID,
            TagName.value('(TagID/text())[1]', 'int'),
            @IsDeleted,
            @CreatedAt,
            @ModifiedAt,
            @AnsweredBy_NTID,
            TagName.value('(FormattedTag/text())[1]', 'nvarchar(100)')
        FROM @TagName.nodes('/ArrayOfTag1/Tag1') AS TEMPTABLE(TagName);

        -- Insert into T_TRN_DeviationAttachments
		--INSERT INTO [T_TRN_DeviationAttachments] (
		--	ImagePath
		--	,ImageTitle
		--	,FileContent
		--	,DisplayFileName
		--	,CreatedBy_NTID
		--	,DeviationID
		--	)
		--SELECT HintImage.value('(ImagePath/text())[1]', 'NVARCHAR(50)') AS ImagePath
		--	,HintImage.value('(ImageTitle/text())[1]', 'NVARCHAR(100)') AS ImageTitle
		--	,HintImage.value('(ByteData/text())[1]', 'varbinary(max)') AS FileContent
		--	,HintImage.value('(DisplayFileName/text())[1]', 'NVARCHAR(100)') AS DisplayFileName
		--	,@CurrentUserNTID
		--	,@DeviationID AS DeviationID
		--FROM @HintImages.nodes('/ArrayOfHintImage/HintImage') AS TEMPTABLE(HintImage)
		--select @HintImages.value('count(/ArrayOfHintImage/HintImage/*)', 'int')

		UPDATE [T_TRN_DeviationAttachments]
		SET DeviationID = @DeviationID  ,IsDeleted=0
		WHERE IsDeleted=1 and CreatedBy_NTID=@CurrentUserNTID;

		   --- To Remove Redundant /Duplicate File Type -----
		WITH cte AS (
			SELECT DeviationAttachmentsID,
				   ROW_NUMBER() OVER (PARTITION BY DeviationID, FileContent ORDER BY DeviationAttachmentsID) AS rn
			FROM T_TRN_DeviationAttachments
			WHERE DeviationID= @DeviationID 
		)
		DELETE FROM T_TRN_DeviationAttachments
		WHERE DeviationAttachmentsID IN (
			SELECT DeviationAttachmentsID
			FROM cte
			WHERE rn > 1
		);
			
        -- Insert into T_TRN_DataPool
	
        INSERT INTO T_TRN_DataPool (
            TIMESTAMP, ValueStreamID, AssessorID, QuestionID,
            Answer, AnswerType_AnswerTypeID, AnsweredBy_NTID,
            CreatedAt, ModifiedBy_NTID, ModifiedAt, TagId,
            IsDeviation, ObtainedSCore, ChoiceID,DeviationID,
            IsSHowVsAs, SessionID, PlantID
        )
        VALUES (
            @Timestamp, @ValueStreamID, @AssessorID, @QuestionID,
            @Answer, @AnswerType_AnswerTypeID, @AnsweredBy_NTID,
            @CreatedAt, @AnsweredBy_NTID, @ModifiedAt, @TagId,
            @IsDeviation, @ObtainedSCore, @ChoiceID,@DeviationID,
            @IsSHowVsAs, @SessionID, @PlantID
        );
		SET @GeneratedDatapoolID = SCOPE_IDENTITY();

		IF @isResumeActivated =1 and (@ModeTypeID=3 or @ModeTypeID=2) and @EventID is not null AND @EventID <> '' and @IsSkipMandatory=0
		BEGIN

		IF 	@frominline = 1
		BEGIN
			SET @ModeTypeID = 5;
		END
		INSERT INTO T_TRN_Eventid_Childtable (DatapoolID,EventID,childEventID,Attempt,modeid,createdon,modifiedon,EventID_Start_time,Plantid)
		values (
		@GeneratedDatapoolID,@EventID,@ChildEventID,@AttemptNumber,@ModeTypeID
		,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,@formattedDateTime,@PlantID)
		END

		IF @isResumeActivated=0 and (@ModeTypeID=3 or @ModeTypeID=1 or @ModeTypeID=2)  and @EventID is not null AND @EventID <> '' and @IsSkipMandatory=0
		BEGIN

		IF 	@frominline = 1
		BEGIN
			SET @ModeTypeID = 5;
		END
		
		INSERT INTO  T_TRN_EventId_Maintable
		(DatapoolID,EventID,valuestreamID,TagID,userNTID,EventID_Start_time,ModeID,CreatedAt,Plantid)
		VALUES (
		@GeneratedDatapoolID,@EventID,@ValueStreamID,@TagID,@AnsweredBy_NTID,@formattedDateTime,@ModeTypeID,@ModifiedAt,@PlantID)
 		END


		INSERT  into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('END_TAG_PC_WITHPIC_Addsetting',@PlantID,@CurrentUserNTID, getdate(),@ModeTypeID)
        COMMIT TRANSACTION TRNINSERTPC;
		END
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION TRNINSERTPC;

        EXEC [USP_LogError] @PlantID, @CurrentUserNTID;

        -- Set the DeviationID to indicate failure (optional)
        SET @DeviationID = 0; -- or any other value to indicate failure
    END CATCH;

    -- Select the DeviationID to return it
    SELECT @DeviationID AS DeviationID;
END
GO



/****** Object:  StoredProcedure [USP_Insertprocessconfirmation_TagMode_NormalAnswer]    Script Date: 4/8/2025 11:40:33 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


ALTER PROCEDURE grp10.[USP_Insertprocessconfirmation_TagMode_NormalAnswer]
    @ModeTypeID INT,
    @ValueStreamID INT,
    @AssessorID INT,
    @QuestionID INT,
    @Answer NVARCHAR(MAX),
    @AnswerType_AnswerTypeID INT,
	@CreatedAt DATETIME,
	@ModifiedAt DATETIME,
    @TagId INT,
    @AnsweredBy_NTID NVARCHAR(20),
    @IsDeviation BIT,
    @ObtainedSCore DECIMAL(10, 2),
    @DeviationDescription NVARCHAR(MAX),
    @ResponsibleEmployee NVARCHAR(50),
    @HintImages XML = NULL,
    @ChoiceID INT,
    @IsSHowVsAs BIT,
    @SessionID NVARCHAR(20) = NULL,
    @PlantID INT,
    @AdditionalEmployee XML = NULL,
    @TagName XML = NULL,
    @IsDeleted BIT = NULL,
    @CurrentUserNTID NVARCHAR(20) = NULL,
    @TagmodeID INT,
    @CustomModeID INT,
	@IsSkipMandatory BIT,
	@formattedDateTime NVARCHAR(50)=NULL,
	@EventID NVARCHAR(50)=NULL,
	@ResumeActive BIT,
	@AttemptNumber INT,
	@ChildEventID NVARCHAR(50)=NULL,
	@isinlineinsertprocess BIT,
	@frominline BIT,
	@isResumeActivated BIT
AS
BEGIN
    SET NOCOUNT ON;

	DECLARE @DeviationID INT;
    DECLARE @TimeStamp DATETIME;
	DECLARE @GeneratedDatapoolID INT;
    BEGIN TRY
        BEGIN TRANSACTION TRNINSERTPC;

        -- Retrieve formatted date and time using the function fnGetDateTime
        SELECT @TimeStamp = FormattedDateTime
        FROM fnGetDateTime(@PlantID);

		 -- Set CreatedAt and ModifiedAt to the same value as Timestamp
        SET @CreatedAt = @Timestamp;
        SET @ModifiedAt = @Timestamp;

		IF @ModeTypeID = 2 
        BEGIN
            INSERT INTO T_LNK_Custom_AnsweredQuestions (
             TagID,QuestionID,CreatedAt,ModifiedAt
			,IsDeleted,AnswerTypeID	,IsAnswered	,Answer
			,CreatedBy_NTID	,ModifiedBy_NTID,IsCustomModeCompleted
			,ValueStreamID,CustomModeID	,PlantID,ChoiceID,DeviationDescription
            )
            VALUES (
              	@TagId,@QuestionID,@CreatedAt
			,@ModifiedAt,0,@AnswerType_AnswerTypeID
			,1,@Answer,@AnsweredBy_NTID	,@AnsweredBy_NTID
			,0	,@ValueStreamID,@CustomModeID
			,@PlantID	,@ChoiceID	,@DeviationDescription
			--@DeviationID	
            );
        END

		IF @ModeTypeID = 3 and @isinlineinsertprocess = 0
		BEGIN
        -- Insert into T_LNK_Tag_AnsweredQuestions
        INSERT INTO T_LNK_Tag_AnsweredQuestions (
            TagID, QuestionID, CreatedAt, ModifiedAt,
            IsDeleted, AnswerTypeID, IsAnswered, Answer,
            CreatedBy_NTID, ModifiedBy_NTID, IsTagCompleted,
            IsTagActive, ValueStreamID, TagModeID, PlantID,
            DeviationDescription, ChoiceID
        )
        VALUES (
            @TagId, @QuestionID, @CreatedAt, @ModifiedAt,
            0, @AnswerType_AnswerTypeID, 1, @Answer,
            @AnsweredBy_NTID, @AnsweredBy_NTID, 0,
            1, @ValueStreamID, @TagmodeID, @PlantID,
            @DeviationDescription, @ChoiceID
        );
		END

        -- Insert into T_TRN_DataPool
		 IF @IsSkipMandatory = 0
		 BEGIN
        INSERT INTO T_TRN_DataPool (
            TIMESTAMP, ValueStreamID, AssessorID, QuestionID,
            Answer, AnswerType_AnswerTypeID, AnsweredBy_NTID,
            CreatedAt, ModifiedBy_NTID, ModifiedAt, TagId,
            IsDeviation, ObtainedSCore, ChoiceID, DeviationID,
            IsSHowVsAs, SessionID, PlantID
        )
        VALUES (
            @TimeStamp, @ValueStreamID, @AssessorID, @QuestionID,
            @Answer, @AnswerType_AnswerTypeID, @AnsweredBy_NTID,
            @CreatedAt, @AnsweredBy_NTID, @ModifiedAt, @TagId,
            @IsDeviation, @ObtainedSCore, @ChoiceID, NULL,
            @IsSHowVsAs, @SessionID, @PlantID
        );
		END
		SET @GeneratedDatapoolID = SCOPE_IDENTITY();
	
		IF @isResumeActivated =1 and (@ModeTypeID=3 or @ModeTypeID=2) and @EventID is not null AND @EventID <> '' and @IsSkipMandatory=0
		BEGIN

		IF 	@frominline = 1
		BEGIN
			SET @ModeTypeID = 5;
		END

		INSERT INTO T_TRN_Eventid_Childtable (DatapoolID,EventID,childEventID,Attempt,modeid,createdon,modifiedon,EventID_Start_time,Plantid)
		values (
		@GeneratedDatapoolID,@EventID,@ChildEventID,@AttemptNumber,@ModeTypeID
		,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,@formattedDateTime,@PlantID)
		END

		IF @isResumeActivated=0 and (@ModeTypeID=3 or @ModeTypeID=1 or @ModeTypeID=2) and @EventID is not null AND @EventID <> '' and @IsSkipMandatory=0
		BEGIN

		IF 	@frominline = 1
		BEGIN
			SET @ModeTypeID = 5;
		END

		INSERT INTO  T_TRN_EventId_Maintable
		(DatapoolID,EventID,valuestreamID,TagID,userNTID,EventID_Start_time,ModeID,CreatedAt,Plantid)
		VALUES (
		@GeneratedDatapoolID,@EventID,@ValueStreamID,@TagID,@AnsweredBy_NTID,@formattedDateTime,@ModeTypeID,@ModifiedAt,@PlantID)
 		END

		SET @DeviationID = 1;
        COMMIT TRANSACTION TRNINSERTPC;
		
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION TRNINSERTPC;

        EXEC [USP_LogError] @PlantID, @CurrentUserNTID;
		SET @DeviationID = 0;
    END CATCH;

	SELECT @DeviationID AS DeviationID;

END
GO


/****** Object:  StoredProcedure [USP_Insertprocessconfirmation_TagMode_onlydeviation_withImage_withoutadditionalsettings]    Script Date: 4/8/2025 11:41:51 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE grp10.[USP_Insertprocessconfirmation_TagMode_onlydeviation_withImage_withoutadditionalsettings]
    @ModeTypeID INT,
    @ValueStreamID INT,
    @AssessorID INT,
    @QuestionID INT,
    @Answer NVARCHAR(MAX),
    @AnswerType_AnswerTypeID INT,
    @CreatedAt DATETIME,
    @ModifiedAt DATETIME,
    @TagId INT,
    @AnsweredBy_NTID NVARCHAR(20),
    @IsDeviation BIT,
    @ObtainedSCore DECIMAL(10, 2),
    @DeviationDescription NVARCHAR(MAX),
    @ResponsibleEmployee NVARCHAR(50),
    @HintImages XML = NULL,
    @ChoiceID INT,
    @IsSHowVsAs BIT,
    @SessionID NVARCHAR(20) = NULL,
    @PlantID INT,
	@AdditionalEmployee XML NULL,
	@TagName XML NULL,
	@IsDeleted BIT NULL,
    @CurrentUserNTID NVARCHAR(20) = NULL,
    @TagmodeID INT,
    @CustomModeID INT,
	@IsSkipMandatory BIT,
	@formattedDateTime NVARCHAR(50)=NULL,
	@EventID NVARCHAR(50)=NULL,
	@ResumeActive BIT,
	@AttemptNumber INT,
	@ChildEventID NVARCHAR(50)=NULL,
	@isinlineinsertprocess BIT,
	@frominline BIT,
	@isResumeActivated BIT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @DeviationID INT;
    DECLARE @Timestamp DATETIME;
	DECLARE @GeneratedDatapoolID INT;
	DECLARE @DeviationEntry INT;
    BEGIN TRY
        BEGIN TRANSACTION TRNINSERTPC;
				INSERT  into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('START_TAG_PC_WITHPIC',@PlantID,@CurrentUserNTID, getdate(),@ModeTypeID)
		 -- Retrieve formatted date and time using the function fnGetDateTime
        SELECT @TimeStamp = FormattedDateTime
        FROM fnGetDateTime(@PlantID);

		 -- Set CreatedAt and ModifiedAt to the same value as Timestamp
        SET @CreatedAt = @Timestamp;
        SET @ModifiedAt = @Timestamp;
		
		IF @IsSkipMandatory = 0
		
		 		IF @IsDeviation =1
		BEGIN
		  SET @DeviationEntry =0
		  END
		ELSE 
		  SET @DeviationEntry =4
		 BEGIN
        -- Insert into T_TRN_Deviation
        INSERT INTO T_TRN_Deviation (
            DeviationDescription, ValueStreamID, ResponsibleEmployee,
            QuestionID, CreatedBy_NTID, CreatedAt, ModifiedAt,
            PlantID, DeviationDisplayID,IsDeviationEntry
        )
        VALUES (
            @DeviationDescription, @ValueStreamID, @ResponsibleEmployee,
            @QuestionID, @AnsweredBy_NTID, @CreatedAt, @ModifiedAt,
            @PlantID,
            (SELECT DisplayID FROM [FN_GetNextDisplayID](@PlantID, 'T_TRN_Deviation')),@DeviationEntry
        );
		END
        SET @DeviationID = SCOPE_IDENTITY();

		IF @ModeTypeID = 2
        BEGIN
            INSERT INTO T_LNK_Custom_AnsweredQuestions (
             TagID,QuestionID,CreatedAt,ModifiedAt
			,IsDeleted,AnswerTypeID	,IsAnswered	,Answer
			,CreatedBy_NTID	,ModifiedBy_NTID,IsCustomModeCompleted
			,ValueStreamID,CustomModeID	,PlantID,ChoiceID,DeviationDescription
            )
            VALUES (
              	@TagId,@QuestionID,@CreatedAt
			,@ModifiedAt,0,@AnswerType_AnswerTypeID
			,1,@Answer,@AnsweredBy_NTID	,@AnsweredBy_NTID
			,0	,@ValueStreamID,@CustomModeID
			,@PlantID	,@ChoiceID	,@DeviationDescription
			--@DeviationID	
            );
        END

		IF @ModeTypeID = 3 and @isinlineinsertprocess = 0
        BEGIN
        -- Insert into T_LNK_Tag_AnsweredQuestions
        INSERT INTO T_LNK_Tag_AnsweredQuestions (
            TagID, QuestionID, CreatedAt, ModifiedAt,
            IsDeleted, AnswerTypeID, IsAnswered, Answer,
            CreatedBy_NTID, ModifiedBy_NTID, IsTagCompleted,
            IsTagActive, ValueStreamID, TagModeID, PlantID,
            DeviationDescription, ChoiceID
        )
        VALUES (
            @TagId, @QuestionID, @CreatedAt, @ModifiedAt,
            0, @AnswerType_AnswerTypeID, 1, @Answer,
            @AnsweredBy_NTID, @AnsweredBy_NTID, 0,
            1, @ValueStreamID, @TagmodeID, @PlantID,
            @DeviationDescription, @ChoiceID
        );
		END
        -- Insert into T_TRN_DeviationAttachments
		--INSERT INTO [T_TRN_DeviationAttachments] (
		--	ImagePath
		--	,ImageTitle
		--	,FileContent
		--	,DisplayFileName
		--	,CreatedBy_NTID
		--	,DeviationID
		--	)
		--SELECT HintImage.value('(ImagePath/text())[1]', 'NVARCHAR(50)') AS ImagePath
		--	,HintImage.value('(ImageTitle/text())[1]', 'NVARCHAR(100)') AS ImageTitle
		--	,HintImage.value('(ByteData/text())[1]', 'varbinary(max)') AS FileContent
		--	,HintImage.value('(DisplayFileName/text())[1]', 'NVARCHAR(100)') AS DisplayFileName
		--	,@CurrentUserNTID
		--	,@DeviationID AS DeviationID
		--FROM @HintImages.nodes('/ArrayOfHintImage/HintImage') AS TEMPTABLE(HintImage)
		--select @HintImages.value('count(/ArrayOfHintImage/HintImage/*)', 'int')

		IF @IsSkipMandatory = 0
		 BEGIN
		UPDATE [T_TRN_DeviationAttachments]
		SET DeviationID = @DeviationID  ,IsDeleted=0
		WHERE IsDeleted=1 and CreatedBy_NTID=@CurrentUserNTID;

		 --- To Remove Redundant /Duplicate File Type -----
		WITH cte AS (
			SELECT DeviationAttachmentsID,
				   ROW_NUMBER() OVER (PARTITION BY DeviationID, FileContent ORDER BY DeviationAttachmentsID) AS rn
			FROM T_TRN_DeviationAttachments
			WHERE DeviationID= @DeviationID 
		)
		DELETE FROM T_TRN_DeviationAttachments
		WHERE DeviationAttachmentsID IN (
			SELECT DeviationAttachmentsID
			FROM cte
			WHERE rn > 1
		);
			

        -- Insert into T_TRN_DataPool
        INSERT INTO T_TRN_DataPool (
            TIMESTAMP, ValueStreamID, AssessorID, QuestionID,
            Answer, AnswerType_AnswerTypeID, AnsweredBy_NTID,
            CreatedAt, ModifiedBy_NTID, ModifiedAt, TagId,
            IsDeviation, ObtainedSCore, ChoiceID,DeviationID,
            IsSHowVsAs, SessionID, PlantID
        )
        VALUES (
            @Timestamp, @ValueStreamID, @AssessorID, @QuestionID,
            @Answer, @AnswerType_AnswerTypeID, @AnsweredBy_NTID,
            @CreatedAt, @AnsweredBy_NTID, @ModifiedAt, @TagId,
            @IsDeviation, @ObtainedSCore, @ChoiceID,@DeviationID,
            @IsSHowVsAs, @SessionID, @PlantID
        );

		SET @GeneratedDatapoolID = SCOPE_IDENTITY();
		IF @isResumeActivated = 1 and (@ModeTypeID=3 or @ModeTypeID=2)  and @EventID is not null AND @EventID <> '' and @IsSkipMandatory=0
		BEGIN

		IF 	@frominline = 1
		BEGIN
			SET @ModeTypeID = 5;
		END

		INSERT INTO T_TRN_Eventid_Childtable (DatapoolID,EventID,childEventID,Attempt,modeid,createdon,modifiedon,EventID_Start_time,Plantid)
		values (
		@GeneratedDatapoolID,@EventID,@ChildEventID,@AttemptNumber,@ModeTypeID
		,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,@formattedDateTime,@PlantID)
		END

		IF @isResumeActivated=0 and (@ModeTypeID=3 or @ModeTypeID=1 or @ModeTypeID=2) and @EventID is not null AND @EventID <> '' and @IsSkipMandatory=0
		BEGIN

		IF 	@frominline = 1
		BEGIN
			SET @ModeTypeID = 5;
		END

		INSERT INTO  T_TRN_EventId_Maintable
		(DatapoolID,EventID,valuestreamID,TagID,userNTID,EventID_Start_time,ModeID,CreatedAt,Plantid)
		VALUES (
		@GeneratedDatapoolID,@EventID,@ValueStreamID,@TagID,@AnsweredBy_NTID,@formattedDateTime,@ModeTypeID,@ModifiedAt,@PlantID)
 		END

		INSERT  into tempinsertprocesstiming(linenum,plantid,ntid,currtime,ModeType) values('END_TAG_PC_WITHPIC',@PlantID,@CurrentUserNTID, getdate(),@ModeTypeID)

        COMMIT TRANSACTION TRNINSERTPC;
		END
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION TRNINSERTPC;

        EXEC [USP_LogError] @PlantID, @CurrentUserNTID;
    END CATCH;

    -- Return the DeviationID
    SELECT @DeviationID AS DeviationID;
END
GO


/****** Object:  StoredProcedure [USP_Insertprocessconfirmation_TagMode_onlydeviation_withoutImage_withoutadditionalsettings]    Script Date: 4/8/2025 11:42:32 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE grp10.[USP_Insertprocessconfirmation_TagMode_onlydeviation_withoutImage_withoutadditionalsettings]
    @ModeTypeID INT,
    @ValueStreamID INT,
    @AssessorID INT,
    @QuestionID INT,
    @Answer NVARCHAR(MAX),
    @AnswerType_AnswerTypeID INT,
	@CreatedAt DATETIME,
    @ModifiedAt DATETIME,
	@TagId INT,
    @AnsweredBy_NTID NVARCHAR(20),
    @IsDeviation BIT,
    @ObtainedSCore DECIMAL(10, 2),
    @DeviationDescription NVARCHAR(MAX),
    @ResponsibleEmployee NVARCHAR(50),
    @HintImages XML = NULL,
    @ChoiceID INT,
    @IsSHowVsAs BIT,
    @SessionID NVARCHAR(20) = NULL,
    @PlantID INT,
    @AdditionalEmployee XML = NULL,
    @TagName XML = NULL,
    @IsDeleted BIT = NULL,
    @CurrentUserNTID NVARCHAR(20) = NULL,
    @TagmodeID INT,
    @CustomModeID INT,
	@IsSkipMandatory BIT,
	@formattedDateTime NVARCHAR(50)=NULL,
	@EventID NVARCHAR(50)=NULL,
	@ResumeActive BIT,
	@AttemptNumber INT,
	@ChildEventID NVARCHAR(50)=NULL,
	@isinlineinsertprocess BIT,
	@frominline BIT,
	@isResumeActivated BIT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @DeviationID INT;
    DECLARE @Timestamp DATETIME;
	DECLARE @GeneratedDatapoolID INT;
	DECLARE @DeviationEntry INT;
    BEGIN TRY
        BEGIN TRANSACTION TRNINSERTPC;
		
		-- Retrieve formatted date and time using the function fnGetDateTime
        SELECT @TimeStamp = FormattedDateTime
        FROM fnGetDateTime(@PlantID);
		
		 -- Set CreatedAt and ModifiedAt to the same value as Timestamp
        SET @CreatedAt = @Timestamp;
        SET @ModifiedAt = @Timestamp;
		
        -- Insert into T_TRN_Deviation
		 IF @IsSkipMandatory = 0
	
		 		IF @IsDeviation =1
		BEGIN
		  SET @DeviationEntry =0
		  END
		ELSE 
		  SET @DeviationEntry =4
		 BEGIN
        INSERT INTO T_TRN_Deviation (
            DeviationDescription, ValueStreamID, ResponsibleEmployee,
            QuestionID, CreatedBy_NTID, CreatedAt, ModifiedAt,
            PlantID, DeviationDisplayID,IsDeviationEntry)
        VALUES (
            @DeviationDescription, @ValueStreamID, @ResponsibleEmployee,
            @QuestionID, @AnsweredBy_NTID, @CreatedAt, @ModifiedAt,
            @PlantID,
            (SELECT DisplayID FROM [FN_GetNextDisplayID](@PlantID, 'T_TRN_Deviation')),@DeviationEntry
        );
		END
		

        SET @DeviationID = SCOPE_IDENTITY();

		IF @ModeTypeID = 2 
        BEGIN
            INSERT INTO T_LNK_Custom_AnsweredQuestions (
             TagID,QuestionID,CreatedAt,ModifiedAt
			,IsDeleted,AnswerTypeID	,IsAnswered	,Answer
			,CreatedBy_NTID	,ModifiedBy_NTID,IsCustomModeCompleted
			,ValueStreamID,CustomModeID	,PlantID,ChoiceID,DeviationDescription
            )
            VALUES (
              	@TagId,@QuestionID,@CreatedAt
			,@ModifiedAt,0,@AnswerType_AnswerTypeID
			,1,@Answer,@AnsweredBy_NTID	,@AnsweredBy_NTID
			,0	,@ValueStreamID,@CustomModeID
			,@PlantID	,@ChoiceID	,@DeviationDescription
			--@DeviationID	
            );
        END
		IF @ModeTypeID = 3 and @isinlineinsertprocess = 0
        BEGIN
        -- Insert into T_LNK_Tag_AnsweredQuestions
        INSERT INTO T_LNK_Tag_AnsweredQuestions (
            TagID, QuestionID, CreatedAt, ModifiedAt,
            IsDeleted, AnswerTypeID, IsAnswered, Answer,
            CreatedBy_NTID, ModifiedBy_NTID, IsTagCompleted,
            IsTagActive, ValueStreamID, TagModeID, PlantID,
            DeviationDescription, ChoiceID
        )
        VALUES (
            @TagId, @QuestionID, @CreatedAt, @ModifiedAt,
            0, @AnswerType_AnswerTypeID, 1, @Answer,
            @AnsweredBy_NTID, @AnsweredBy_NTID, 0,
            1, @ValueStreamID, @TagmodeID, @PlantID,
            @DeviationDescription, @ChoiceID
        );
		END
        -- Insert into T_TRN_DataPool
		 IF @IsSkipMandatory = 0
		 BEGIN
        INSERT INTO T_TRN_DataPool (
            TIMESTAMP, ValueStreamID, AssessorID, QuestionID,
            Answer, AnswerType_AnswerTypeID, AnsweredBy_NTID,
            CreatedAt, ModifiedBy_NTID, ModifiedAt, TagId,
            IsDeviation, ObtainedSCore, ChoiceID,DeviationID,
            IsSHowVsAs, SessionID, PlantID
        )
        VALUES (
            @Timestamp, @ValueStreamID, @AssessorID, @QuestionID,
            @Answer, @AnswerType_AnswerTypeID, @AnsweredBy_NTID,
            @CreatedAt, @AnsweredBy_NTID, @ModifiedAt, @TagId,
            @IsDeviation, @ObtainedSCore, @ChoiceID,@DeviationID,
            @IsSHowVsAs, @SessionID, @PlantID
        );
		END
		SET @GeneratedDatapoolID = SCOPE_IDENTITY();
		
		IF @isResumeActivated =1 and (@ModeTypeID=3 or @ModeTypeID=2) and @EventID is not null AND @EventID <> '' and @IsSkipMandatory=0
		BEGIN

		IF 	@frominline = 1
		BEGIN
			SET @ModeTypeID = 5;
		END
		INSERT INTO T_TRN_Eventid_Childtable (DatapoolID,EventID,childEventID,Attempt,modeid,createdon,modifiedon,EventID_Start_time,Plantid)
		values (
		@GeneratedDatapoolID,@EventID,@ChildEventID,@AttemptNumber,@ModeTypeID
		,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,@formattedDateTime,@PlantID)
		END

		IF @isResumeActivated=0 and (@ModeTypeID=3 or @ModeTypeID=1 or @ModeTypeID=2) and @EventID is not null AND @EventID <> '' and @IsSkipMandatory=0
		BEGIN

		IF 	@frominline = 1
		BEGIN
			SET @ModeTypeID = 5;
		END

		INSERT INTO  T_TRN_EventId_Maintable
		(DatapoolID,EventID,valuestreamID,TagID,userNTID,EventID_Start_time,ModeID,CreatedAt,Plantid)
		VALUES (
		@GeneratedDatapoolID,@EventID,@ValueStreamID,@TagID,@AnsweredBy_NTID,@formattedDateTime,@ModeTypeID,@ModifiedAt,@PlantID)
 		END

        COMMIT TRANSACTION TRNINSERTPC;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION TRNINSERTPC;

        EXEC [USP_LogError] @PlantID, @CurrentUserNTID;

        -- Set the DeviationID to indicate failure (optional)
        SET @DeviationID = 0; -- or any other value to indicate failure
    END CATCH;

    -- Select the DeviationID to return it
    SELECT @DeviationID AS DeviationID;
END
GO



/****** Object:  StoredProcedure [dbo].[USP_CompleteAuditByAuditAndTemplateID]    Script Date: 4/8/2025 11:44:36 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/*  
///<SUMMARY>  
///DESCRIPTION                  : STORE PROCEDURE - [USP_CompleteAuditByAuditAndTemplateID]
///AUTHOR                       : JANARTHANAN KRISHNASAMY
///CREATED DATE                 : 25-NOV-2020
///SEE ALSO                     : THIS PROCEDURE FOR RETRIEVING COMPLETE AUDIT BY AUDIT AND TEMPLATE ID
///MODIFICATION HISTORY			:  
************************************************************************************************************ 
///REF						DATE				MODIFIED BY					CHANGE DESCRIPTION  
************************************************************************************************************ 
ELPC_LH_001					25-NOV-2020			JANARTHANAN KRISHNASAMY		INITIAL VERSION
ELPC_LH_002					23-MAR-2021			RAJASEKAR S					PLANTID,CURRENTUSERNTID ADDED
ELPC_LH_002					27-MAR-2021			RAJASEKAR S					HISTORY LOGIC ADDED
ELPC_LH_003					23-JUL-2021			RAJASEKAR S					ISDEVIATION WRONGLY UPDATING TO QUESTIONS IN DATAPOOL- FIXED
ELPC_LH_002_CR05				06-DEC-2021			VENKATESH GOVINDARAJ		QUESTION ORDER BY LOGIC CHANGED
ELPC_LH_006					18-AUG-2023			ASHOK KUMAR R B, GOPIKA 		V4.0
************************************************************************************************************ 
///</SUMMARY>
--SAMPLE EXECUTION EXEC SP_NAME INPUT PARAMETER/S(IF REQUIRED)
EXEC [USP_CompleteAuditByAuditAndTemplateID] 1,1
*/
ALTER PROCEDURE grp10.[USP_CompleteAuditByAuditAndTemplateID] @PlantID INT  
 ,@AuditID INT  
 ,@AuditTemplateID INT  
 ,@CurrentUserNTID NVARCHAR(20)  
AS  
BEGIN  
 BEGIN TRY  
  --Inputs filed variable for triggers  
  DECLARE @Scope_Identity_Table_Trigger TABLE (id INT);--Scope identities for all inserted rows  
  DECLARE @Input_Ids_Trigger VARCHAR(MAX);  
  DECLARE @TableName_Trigger VARCHAR(100);  
  DECLARE @ActionType VARCHAR(10);  
  DECLARE @EventID NVARCHAR(50)='';
  DECLARE @ModeTypeID int=4;
  DECLARE @formattedDateTime NVARCHAR(50)=NULL;
  DECLARE @InsertedID INT; 
  DECLARE @EventID_Start_time NVARCHAR(50)=NULL;
  DECLARE @isFirstInsertion  int=0;
  BEGIN TRANSACTION TRNCOMPLETEAUDIT  
  
  EXEC [USP_PlantIDValidation] @PlantID = @PlantID  
   ,@ID = @AuditID  
   ,@Mode = 'AUDIT'  
   ,@CurrentUserNTID = @CurrentUserNTID  
  
  DECLARE @ValueStreamID INT  
  DECLARE @TagID INT  
  Declare @AssessorID INT
  
  SET @ValueStreamID = (  
    SELECT TOP 1 ValueStreamID  
    FROM T_TRN_Audit WITH(NOLOCK)  
    WHERE AuditID = @AuditID  
     AND PlantID = @PlantID  
    )  
  SET @TagID = (  
    SELECT TOP 1 TagID  
    FROM T_TRN_Audit WITH(NOLOCK)  
    WHERE AuditID = @AuditID  
     AND PlantID = @PlantID  
    )
	
  If(@AuditTemplateID = 0 OR @AuditTemplateID IS NULL)
  Begin
    Set @AuditTemplateID = 1
  End
  UPDATE T_LNK_Audit_AnsweredQuestions  
  SET IsAuditCompleted = 1  
  WHERE AuditID = @AuditID  
   AND AuditTemplateID = @AuditTemplateID  
  
  --List the questions avaliable on AuditTemplate  
  SELECT Identity(INT, 1, 1) AS RowID  
   ,convert(INT, QuestionID) AS QuestionID  
  INTO #tmpAuditQuestions  
  FROM T_LNK_Audit_AnsweredQuestions WITH(NOLOCK)  
  WHERE AuditID = @AuditID  
   AND AuditTemplateID = @AuditTemplateID  
  
  --SELECT * FROM #tmpAuditQuestions  
  DECLARE @min INT = 0  
   ,@max INT = 0;  
  
  SET @min = (  
    SELECT MIN(RowID)  
    FROM #tmpAuditQuestions  
    );--Get minimum row number from temp table  
  SET @max = (  
    SELECT Max(RowID)  
    FROM #tmpAuditQuestions  
    );--Get maximum row number from temp table  
-- set @EventID = FORMAT(GETDATE(), 'yyyy-MM-dd HH:mm:ss.fff');
	SET @EventID = CONVERT(NVARCHAR(50), GETDATE(), 121);
	SET @EventID_Start_time = CONVERT(NVARCHAR(50), GETDATE(), 121);
  WHILE (@min <= @max)  
  BEGIN  
   DECLARE @DeviationID INT=0;  
   DECLARE @AuditQuestionID INT=0;  
  
   --Retrive aduit template current questionID from temp Table  
   SET @AuditQuestionID = (  
     SELECT TOP 1 QuestionID  
     FROM #tmpAuditQuestions  
     WHERE RowID = @min  
     );  
  set @AssessorID= (select TOP 1 AssessorID from T_LNK_Audit_AnsweredQuestions where AuditID =@AuditID
	 AND AuditTemplateID=@AuditTemplateID
	 AND QuestionID=@AuditQuestionID)

   --Retrive aduit template current question having any deviations or not  
   DECLARE @AuditDeviationID INT=0;  
  
   SET @AuditDeviationID = (  
     SELECT TOP 1 AuditDeviationID  
     FROM T_TRN_AuditDeviation WITH(NOLOCK)  
     WHERE QuestionID = @AuditQuestionID  
      AND AuditID = @AuditID  
      AND AuditTemplateID = @AuditTemplateID  
     )  
  
   --If current question having deviation then enter if condition else insert into datappol and increment loop by 1  
   IF (ISNULL(@AuditDeviationID,0)<>0)  
   BEGIN  
    --SELECT @AuditQuestionID as AuditQuestionID  
    --Retrive data from AuditDeviation & insert into Deviation table   
    INSERT INTO [T_TRN_Deviation] (  
     PlantID  
     ,DeviationDisplayID  
     ,ValueStreamID  
     ,DeviationDescription  
     ,ResponsibleEmployee  
     ,CreatedBy_NTID  
     ,CreatedAt  
     ,ModifiedAt  
     ,QuestionID  
     )  
    SELECT @PlantID  
     ,(  
      SELECT DisplayID  
      FROM [FN_GetNextDisplayID](@PlantID, 'T_TRN_Deviation')  
      )  
     ,ValueStreamID  
     ,DeviationDescription  
     ,ResponsibleEmployee  
     ,CreatedBy_NTID  
     ,(  
      SELECT FormattedDateTime  
      FROM fnGetDateTime(@PlantID)  
      )  
     ,(  
      SELECT FormattedDateTime  
      FROM fnGetDateTime(@PlantID)  
      )  
     ,@AuditQuestionID  
    FROM T_TRN_AuditDeviation WITH(NOLOCK)  
    WHERE QuestionID = @AuditQuestionID  
     AND AuditID = @AuditID  
     AND AuditTemplateID = @AuditTemplateID  
  
    SET @DeviationID = SCOPE_IDENTITY()  
     --(SELECT AuditDeviationID  
     --FROM T_TRN_AuditDeviation WITH(NOLOCK)  
     --WHERE QuestionID = @AuditQuestionID  
     -- AND AuditID = @AuditID  
     -- AND AuditTemplateID = @AuditTemplateID  
     --)  
    --SELECT @DeviationID AS DeviationID  
    --Check current deviation is having any attachment files,   
    --if yes then enter into if condition or else delete the deviation details  
    IF (  
      (  
       SELECT count(*)  
       FROM T_LNK_AuditDeviation_AdditionalEmployee WITH(NOLOCK)  
       WHERE DeviationID = @AuditDeviationID  
       ) > 0  
      )  
    BEGIN  
    insert into [T_LNK_Deviation_AdditionalEmployee]  
    (  
   DeviationID  
   ,NTID  
   ,CreatedAt  
   ,ModifiedAt  
   ,IsDeleted  
   ,CreatedBy_NTID  
   ,ModifiedBy_NTID  
   ,UserName  
    )  
    select  @DeviationID AS DeviationID  
    ,NTID  
    ,CreatedAt  
    ,ModifiedAt  
   ,IsDeleted  
   ,CreatedBy_NTID  
   ,ModifiedBy_NTID  
   ,UserName  
   from T_LNK_AuditDeviation_AdditionalEmployee WITH(NOLOCK)  
     WHERE DeviationID = @AuditDeviationID  
     IF (  
       (  
        SELECT Count(*)  
        FROM T_LNK_Audit_AnsweredQuestions WITH(NOLOCK)  
        WHERE AuditID = @AuditID  
         AND AuditTemplateID = @AuditTemplateID  
         AND IsAnswered = 1  
         AND QuestionID = @AuditQuestionID  
        ) > 0  
       )  
     BEGIN  
      --Delete data from AuditDeviationAttachment table  
      DELETE T_LNK_AuditDeviation_AdditionalEmployee  
      WHERE DeviationID = @AuditDeviationID  
     END  
    END  
    IF (  
      (  
       SELECT count(*)  
       FROM T_LNK_AuditDeviation_AssignedTags WITH(NOLOCK)  
       WHERE DeviationID = @AuditDeviationID  
       ) > 0  
      )  
    BEGIN  
    INSERT INTO T_LNK_Deviation_AssignedTags (  
   DeviationID  
   ,TagID  
   ,IsDeleted  
   ,CreatedAt  
   ,ModifiedAt  
   ,CreatedBy_NTID  
   ,ModifiedBy_NTID  
   ,TagName  
   )  
   select  @DeviationID AS DeviationID  
   ,TagID  
   ,IsDeleted  
   ,CreatedAt  
   ,ModifiedAt  
   ,CreatedBy_NTID  
   ,ModifiedBy_NTID  
   ,TagName  
   from T_LNK_AuditDeviation_AssignedTags WITH(NOLOCK)  
     WHERE DeviationID = @AuditDeviationID  
     IF (  
       (  
        SELECT Count(*)  
        FROM T_LNK_Audit_AnsweredQuestions WITH(NOLOCK)  
        WHERE AuditID = @AuditID  
         AND AuditTemplateID = @AuditTemplateID  
         AND IsAnswered = 1  
		 AND QuestionID = @AuditQuestionID  
        ) > 0  
       )  
     BEGIN  
      --Delete data from AuditDeviationAttachment table  
      DELETE T_LNK_AuditDeviation_AssignedTags  
      WHERE DeviationID = @AuditDeviationID  
     END  
    END  
  
    IF (  
      (  
       SELECT count(*)  
       FROM T_TRN_AuditDeviationAttachments WITH(NOLOCK)  
       WHERE AuditDeviationID = @AuditDeviationID  
       ) > 0  
      )  
    BEGIN  
     --select @AuditDeviationID as AuditDeviationID  
     --Retrive data from AuditDeviationAttachment table & insert into DeviationAttachment table   
     INSERT INTO [T_TRN_DeviationAttachments] (  
      DeviationID  
      ,QuestionID  
      ,ImageTitle  
      ,ImagePath  
      ,FileContent  
      ,CreatedBy_NTID  
      ,ModifiedBy_NTID  
      ,IsDeleted  
      ,DisplayFileName  
      )  
     SELECT @DeviationID AS DeviationID  
      ,QuestionID  
      ,ImageTitle  
      ,ImagePath  
      ,FileContent  
      ,CreatedBy_NTID  
      ,ModifiedBy_NTID  
      ,IsDeleted  
      ,DisplayFileName  
     FROM T_TRN_AuditDeviationAttachments WITH(NOLOCK)  
     WHERE AuditDeviationID = @AuditDeviationID  
  
     IF (  
       (  
        SELECT Count(*)  
        FROM T_LNK_Audit_AnsweredQuestions WITH(NOLOCK)  
        WHERE AuditID = @AuditID  
         AND AuditTemplateID = @AuditTemplateID  
          AND IsAuditCompleted=1
         AND QuestionID = @AuditQuestionID  
        ) > 0  
       )  
     BEGIN  
      --Delete data from AuditDeviationAttachment table  
      DELETE T_TRN_AuditDeviationAttachments  
      WHERE AuditDeviationID = @AuditDeviationID  
     END  
    END  
  
    IF (  
      (  
       SELECT Count(*)  
       FROM T_LNK_Audit_AnsweredQuestions WITH(NOLOCK)  
       WHERE AuditID = @AuditID  
        AND AuditTemplateID = @AuditTemplateID  
        AND IsAnswered = 1
        AND QuestionID = @AuditQuestionID 
		
       ) > 0  
      )  
    BEGIN  
     --delete data from deviation details  
     DELETE T_TRN_AuditDeviation  
     WHERE AuditDeviationID = @AuditDeviationID  
    END  
   END  
  
   DELETE  
   FROM @Scope_Identity_Table_Trigger  
 
   --To insert the completed audit questions into the Datapool  
   INSERT INTO T_TRN_DataPool (  
    [TIMESTAMP]  
    ,QuestionID  
    ,Answer  
    ,AnswerType_AnswerTypeID  
    ,CreatedAt  
    ,AnsweredBy_NTID  
    ,ModifiedAt  
    ,ModifiedBy_NTID  
    ,IsAnswered  
    ,AuditID  
    ,AuditTemplateID  
    ,ValueStreamID  
	,AssessorID
    ,TagID  
    ,ChoiceID  
    ,IsDeviation  
    ,DeviationID  
    ,PlantID  
    ,ObtainedScore  
    )  
   OUTPUT inserted.DataPoolID  
   INTO @Scope_Identity_Table_Trigger  
   SELECT (  
     SELECT FormattedDateTime  
     FROM fnGetDateTime(@PlantID)  
     )  
    ,QuestionID  
    ,CASE   
     WHEN AnswerTypeID = 3  
      THEN (  
        SELECT TOP 1 ChoiceName  
        FROM T_TRN_Choice WITH(NOLOCK)  
        WHERE choiceID = Answer  
        )  
     ELSE Answer  
     END AS Answer  
    ,AnswerTypeID AS AnswerType_AnswerTypeID  
    ,CreatedAt  
    ,CreatedBy_NTID AS AnsweredBy_NTID  
    ,ModifiedAt  
    ,ModifiedBy_NTID  
    ,1  
    ,@AuditID  
    ,@AuditTemplateID  
    ,@ValueStreamID 
	,@AssessorID
    ,@TagID  
    ,CASE   
     WHEN AnswerTypeID = 3  
      THEN Answer  
     ELSE NULL  
     END AS ChoiceID  
    ,CASE   
     WHEN (  
       @DeviationID IS NULL  
       OR @DeviationID = 0  
       )  
      THEN NULL  
     ELSE 1  
     END AS IsDeviation  
    ,CASE   
     WHEN (  
       @DeviationID IS NULL  
       OR @DeviationID = 0  
       )  
      THEN NULL  
     ELSE @DeviationID  
     END AS DeviationID  
    ,@PlantID  
    ,CASE   
     WHEN AnswerTypeID = 3  
      THEN (  
        SELECT TOP 1 ChoiceScore  
        FROM T_TRN_Choice WITH(NOLOCK)  
        WHERE choiceID = Answer  
        )  
     ELSE 0  
     END AS ObtainedScore  
   FROM T_LNK_Audit_AnsweredQuestions WITH(NOLOCK)  
   WHERE AuditID = @AuditID  
    AND AuditTemplateID = @AuditTemplateID  
    AND IsAuditCompleted = 1  -- TO insert the datapool entry only when the audit is comleted enen though by using the Skip Functionality
    AND QuestionID = @AuditQuestionID  

	SELECT @InsertedID = SCOPE_IDENTITY();
	if @isFirstInsertion=0
	set @EventID = @EventID+'_'+CONVERT(NVARCHAR(50), @ValueStreamID)+'_'+CONVERT(NVARCHAR(50), @Tagid)+'_'+@CurrentUserNTID;

	INSERT INTO  T_TRN_EventId_Maintable
		(DatapoolID,EventID,valuestreamID,TagID,userNTID,EventID_Start_time,ModeID,CreatedAt,plantid,EndTime)
		VALUES (
		@InsertedID,@EventID,@ValueStreamID,@TagID,@CurrentUserNTID,@EventID_Start_time,@ModeTypeID,GETDATE(),@PlantID,@EventID_Start_time)
 		
	set @isFirstInsertion =1
  
   SELECT @TableName_Trigger = 'DATAPOOL'  
    ,@ActionType = 'I'  
    ,@Input_Ids_Trigger = (  
     SELECT CAST(id AS VARCHAR(MAX)) + ', '  
     FROM @Scope_Identity_Table_Trigger  
     FOR XML PATH('')  
     );  
  
   EXEC [USP_DATAPOOL_HISTORY] @PlantID = @PlantID  
    ,@CurrentUserNTID = @CurrentUserNTID  
    ,@TableName = @TableName_Trigger  
    ,@ActionType = @ActionType  
    ,@INPUT_IDS = @Input_Ids_Trigger;  
  
   EXEC [USP_UpdateDataPool_SummaryByQuestionID] @AuditQuestionID  
  
   --Increment of current row number  
   SET @min = @min + 1  
   SET @DeviationID = NULL  
  END  
  
  COMMIT TRANSACTION TRNCOMPLETEAUDIT  
 END TRY  
  
 BEGIN CATCH  
  ROLLBACK TRANSACTION TRNCOMPLETEAUDIT  
  
  EXEC USP_LogError @PlantID  
   ,@CurrentUserNTID  
 END CATCH  
END
GO



ALTER PROCEDURE grp10.[USP_AddEditAuditQuestion] 
    @PlantID INT,  
    @ID INT,  
    @AuditTemplateID INT,  
    @AuditID INT,  
    @QuestionID INT,  
    @IsDeleted BIT,  
    @AnswerTypeID INT,  
    @IsAnswered BIT,  
    @Answer NVARCHAR(max) = NULL,  
    @IsAnswerRequired BIT = NULL,  
    @Assessors XML = NULL,  
    @Others XML = NULL,  
    @CurrentUserNTID NVARCHAR(20)  
AS  
BEGIN  
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    
    DECLARE @NotAnswered INT,  
            @CreatedAt DATETIME,  
            @ModifiedAt DATETIME,  
            @NTID NVARCHAR(20),  
            @AssessorName NVARCHAR(100),  
            @AssessorID INT,
            @IsMandatoryAssessor BIT,  
            @ValueStreamID INT,  
            @TagID INT,  
            @min INT = 0,  
            @max INT = 0,  
            @UserName NVARCHAR(200);  

    -- Use snapshot isolation if available (reduces blocking)
    IF (SELECT snapshot_isolation_state FROM sys.databases WHERE name = DB_NAME()) = 1
        SET TRANSACTION ISOLATION LEVEL SNAPSHOT;
    ELSE
        SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

    -- Pre-fetch values outside transaction to minimize lock duration
    EXEC [USP_PlantIDValidation] 
        @PlantID = @PlantID,  
        @ID = @AuditID,  
        @Mode = 'AUDIT',  
        @CurrentUserNTID = @CurrentUserNTID;  

    SELECT TOP (1) 
        @TagID = [TagID],
        @ValueStreamID = [ValueStreamID]  
    FROM T_TRN_Audit WITH (NOLOCK)  
    WHERE AuditID = @AuditID AND PlantID = @PlantID; 

    -- Get assessor ID outside transaction if possible
    SET @AssessorID = (
        SELECT TOP (1) AssessorID 
        FROM T_TRN_Assessor WITH (NOLOCK)  
        WHERE AssessorName IN (
            SELECT @Assessors.value('(/ArrayOfAuditAssessor/AuditAssessor/AssessorName[1]/text())[1]', 'nvarchar(100)')
        )
    );

    BEGIN TRY  
        BEGIN TRANSACTION;
        
        -- Minimal locked section for decision making
        IF (@Answer IS NULL OR @Answer = '')  
            SET @IsAnswered = 0;  
        ELSE  
            SET @IsAnswered = 1;  

        -- For insert case - use targeted locks
        IF (@AuditTemplateID = 0 OR @AuditTemplateID IS NULL)  
        BEGIN  
            IF EXISTS (
                SELECT 1 
                FROM T_LNK_Audit_AnsweredQuestions WITH (UPDLOCK, ROWLOCK) 
                WHERE AuditID = @AuditID
            )  
            BEGIN  
                SELECT @AuditTemplateID = MAX(AuditTemplateID) + 1  
                FROM T_LNK_Audit_AnsweredQuestions WITH (UPDLOCK, ROWLOCK)  
                WHERE AuditID = @AuditID;  
            END  
            ELSE  
            BEGIN  
                SET @AuditTemplateID = 1;  
            END  

            -- Create temp table outside transaction if possible
            SELECT DISTINCT QuestionID  
            INTO #questionIDs  
            FROM [FN_GetNestedQuestionsByTagID](@TagID, @PlantID);
            
            -- Main insert with minimal lock escalation
            INSERT INTO T_LNK_Audit_AnsweredQuestions WITH (ROWLOCK) (
                ID, AuditID, QuestionID, CreatedAt, ModifiedAt, 
                AnswerTypeID, CreatedBy_NTID, ModifiedBy_NTID, 
                AuditTemplateID, IsAnswerRequired, ValueStreamID, AssessorID
            )  
            SELECT 
                ROW_NUMBER() OVER (ORDER BY QT.QuestionID) AS ID,
                @AuditID,
                Q.QuestionID,
                (SELECT FormattedDateTime FROM fnGetDateTime(@PlantID)),
                (SELECT FormattedDateTime FROM fnGetDateTime(@PlantID)),
                Q.AnswerType_AnswerTypeID,
                @CurrentUserNTID,
                @CurrentUserNTID,
                @AuditTemplateID,
                IsAnswerRequired,
                @ValueStreamID,
                @AssessorID
            FROM #questionIDs QT  
            INNER JOIN T_TRN_Question Q WITH (NOLOCK) 
                ON Q.QuestionID = QT.QuestionID  
                AND Q.PlantID = @PlantID  
                AND Q.IsDeleted = 0  
                AND Q.QuestionID IN (
                    SELECT q.QuestionID  
                    FROM #questionIDs q  
                    INNER JOIN (
                        SELECT DISTINCT QuestionID  
                        FROM T_LNK_AssignedValueStreams WITH (NOLOCK)  
                        WHERE IsDeleted = 0 AND ValueStreamID = @ValueStreamID
                    ) AS vs ON vs.QuestionID = q.QuestionID  
                );

            -- Conditional update with rowlock
            IF EXISTS (
                SELECT 1  
                FROM T_LNK_Audit_AnsweredQuestions WITH (UPDLOCK, ROWLOCK)  
                WHERE AuditID = @AuditID AND QuestionID = @QuestionID AND AuditTemplateID = @AuditTemplateID
            )
            BEGIN
                UPDATE T_LNK_Audit_AnsweredQuestions WITH (ROWLOCK)  
                SET 
                    AuditID = @AuditID,
                    QuestionID = @QuestionID,
                    ModifiedAt = (SELECT FormattedDateTime FROM fnGetDateTime(@PlantID)),
                    IsDeleted = @IsDeleted,
                    ModifiedBy_NTID = @CurrentUserNTID,
                    IsAnswered = @IsAnswered,
                    Answer = @Answer,
                    IsAnswerRequired = @IsAnswerRequired
                WHERE 
                    AuditID = @AuditID AND 
                    QuestionID = @QuestionID AND 
                    AuditTemplateID = @AuditTemplateID;
            END
            
            -- Insert assessors with minimal locking
            INSERT INTO T_LNK_AuditTemplate_AssessorDetail WITH (ROWLOCK) (
                AssessorName, UserName, NTID, IsMandatoryAssessor, AuditID, AuditTemplateID
            )  
            SELECT 
                Asr.value('(AssessorName/text())[1]', 'nvarchar(100)'),
                Asr.value('(UserName/text())[1]', 'nvarchar(200)'),
                Asr.value('(NTID/text())[1]', 'nvarchar(20)'),
                Asr.value('(IsMandatoryAssessor/text())[1]', 'bit'),
                Asr.value('(AuditID)[1]', 'INT'),
                @AuditTemplateID
            FROM @Assessors.nodes('/ArrayOfAuditAssessor/AuditAssessor') AS TEMPTABLE(Asr);
            
            -- Insert other assessors
            INSERT INTO T_LNK_AuditTemplate_OtherAssessorDetail WITH (ROWLOCK) (
                AssessorName, UserName, NTID, AuditID, AuditTemplateID
            )  
            SELECT 
                Asr.value('(AssessorName/text())[1]', 'nvarchar(100)'),
                Asr.value('(UserName/text())[1]', 'nvarchar(200)'),
                Asr.value('(NTID/text())[1]', 'nvarchar(20)'),
                Asr.value('(AuditID)[1]', 'INT'),
                @AuditTemplateID
            FROM @Others.nodes('/ArrayOfAuditAssessor/AuditAssessor') AS TEMPTABLE(Asr);
        END  
        ELSE -- Update case
        BEGIN  
            -- Conditional update with rowlock
            IF EXISTS (
                SELECT 1  
                FROM T_LNK_Audit_AnsweredQuestions WITH (UPDLOCK, ROWLOCK)  
                WHERE AuditID = @AuditID AND QuestionID = @QuestionID AND AuditTemplateID = @AuditTemplateID
            )
            BEGIN
                UPDATE T_LNK_Audit_AnsweredQuestions WITH (ROWLOCK)  
                SET 
                    AuditID = @AuditID,
                    QuestionID = @QuestionID,
                    ModifiedAt = (SELECT FormattedDateTime FROM fnGetDateTime(@PlantID)),
                    IsDeleted = @IsDeleted,
                    ModifiedBy_NTID = @CurrentUserNTID,
                    IsAnswered = @IsAnswered,
                    Answer = @Answer,
                    IsAnswerRequired = @IsAnswerRequired
                WHERE 
                    AuditID = @AuditID AND 
                    QuestionID = @QuestionID AND 
                    AuditTemplateID = @AuditTemplateID;
            END
            
            -- Required attendees processing with minimal locks
            SELECT 
                @AuditID AS AuditID,
                Identity(INT, 1, 1) AS ID,
                Asr.value('(AssessorName/text())[1]', 'nvarchar(100)') AS AssessorName,
                Asr.value('(UserName/text())[1]', 'nvarchar(200)') AS UserName,
                Asr.value('(NTID/text())[1]', 'nvarchar(20)') AS NTID,
                Asr.value('(IsMandatoryAssessor/text())[1]', 'bit') AS IsMandatoryAssessor,
                @AuditTemplateID AS AuditTemplateID
            INTO #R1  
            FROM @Assessors.nodes('/ArrayOfAuditAssessor/AuditAssessor') AS TEMPTABLE(Asr);
            
            -- Conditional update with rowlock
            IF EXISTS (
                SELECT 1  
                FROM T_LNK_AuditTemplate_AssessorDetail WITH (UPDLOCK, ROWLOCK)  
                WHERE NTID NOT IN (SELECT NTID FROM #R1)  
                AND AuditID = @AuditID  
                AND AuditTemplateID = @AuditTemplateID
            )
            BEGIN
                UPDATE T_LNK_AuditTemplate_AssessorDetail WITH (ROWLOCK)  
                SET IsDeleted = 1  
                WHERE NTID NOT IN (SELECT NTID FROM #R1)  
                AND AuditID = @AuditID  
                AND AuditTemplateID = @AuditTemplateID;
            END
            
            -- Process required attendees with minimal locks
            SELECT @min = MIN(ID), @max = MAX(ID) FROM #R1;
            
            WHILE (@min <= @max)  
            BEGIN  
                SELECT 
                    @AuditID = AuditID,
                    @AuditTemplateID = AuditTemplateID,
                    @AssessorName = AssessorName,
                    @NTID = NTID,
                    @UserName = UserName
                FROM #R1 WHERE ID = @min;  
                
                IF EXISTS (
                    SELECT 1  
                    FROM T_LNK_AuditTemplate_AssessorDetail WITH (UPDLOCK, ROWLOCK)  
                    WHERE AssessorName = @AssessorName  
                    AND AuditTemplateID = @AuditTemplateID  
                    AND AuditID = @AuditID
                )  
                BEGIN  
                    UPDATE T_LNK_AuditTemplate_AssessorDetail WITH (ROWLOCK)  
                    SET 
                        NTID = @NTID,
                        IsDeleted = 0,
                        UserName = @UserName
                    WHERE 
                        AssessorName = @AssessorName  
                        AND AuditTemplateID = @AuditTemplateID  
                        AND AuditID = @AuditID;
                END  
                SET @min = @min + 1;  
            END  
            
            -- Process other attendees with minimal locks
            SELECT 
                @AuditID AS AuditID,
                Identity(INT, 1, 1) AS ID,
                Asr.value('(AssessorName/text())[1]', 'nvarchar(100)') AS AssessorName,
                Asr.value('(UserName/text())[1]', 'nvarchar(200)') AS UserName,
                Asr.value('(NTID/text())[1]', 'nvarchar(20)') AS NTID,
                Asr.value('(IsMandatoryAssessor/text())[1]', 'bit') AS IsMandatoryAssessor,
                @AuditTemplateID AS AuditTemplateID
            INTO #R2  
            FROM @Others.nodes('/ArrayOfAuditAssessor/AuditAssessor') AS TEMPTABLE(Asr);
            
            UPDATE T_LNK_AuditTemplate_OtherAssessorDetail WITH (ROWLOCK)  
            SET IsDeleted = 1  
            WHERE NTID NOT IN (SELECT NTID FROM #R2)  
            AND AuditID = @AuditID  
            AND AuditTemplateID = @AuditTemplateID;
            
            -- Process other attendees inserts
            SELECT @min = MIN(ID), @max = MAX(ID) FROM #R2;
            
            WHILE (@min <= @max)  
            BEGIN  
                SELECT 
                    @AuditID = AuditID,
                    @AuditTemplateID = AuditTemplateID,
                    @UserName = UserName,
                    @NTID = NTID
                FROM #R2 WHERE ID = @min;  
                
                IF NOT EXISTS (
                    SELECT 1  
                    FROM T_LNK_AuditTemplate_OtherAssessorDetail WITH (UPDLOCK, ROWLOCK)  
                    WHERE AuditID = @AuditID  
                    AND NTID = @NTID  
                    AND AuditTemplateID = @AuditTemplateID
                )  
                BEGIN  
                    INSERT INTO T_LNK_AuditTemplate_OtherAssessorDetail WITH (ROWLOCK) (
                        AuditID, AuditTemplateID, NTID, UserName, IsDeleted
                    )  
                    VALUES (
                        @AuditID, @AuditTemplateID, @NTID, @UserName, 0
                    );  
                END  
                SET @min = @min + 1;  
            END  
        END  
        
        -- Final calculations
        SELECT @NotAnswered = COUNT(ID)  
        FROM T_LNK_Audit_AnsweredQuestions WITH (NOLOCK)  
        WHERE IsAnswered IS NULL  
        AND AuditID = @AuditID  
        AND AuditTemplateID = @AuditTemplateID;
        
        IF (@NotAnswered = 0 OR @NotAnswered IS NULL)  
        BEGIN  
            SELECT TOP 1 
                @ValueStreamID = ValueStreamID,
                @TagID = TagID
            FROM T_TRN_Audit WITH (NOLOCK)  
            WHERE AuditID = @AuditID AND PlantID = @PlantID;  
        END  
        
        -- Return results
        SELECT 
            @NotAnswered AS PendingCount,
            (SELECT TOP 1 AuditAnsweredQuestionID  
             FROM T_LNK_Audit_AnsweredQuestions WITH (NOLOCK)  
             WHERE AuditID = @AuditID  
             AND QuestionID = @QuestionID  
             AND AuditTemplateID = @AuditTemplateID) AS AuditAnsweredQuestionID;
        
        COMMIT TRANSACTION;  
    END TRY  
    BEGIN CATCH  
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;  
        EXEC USP_LogError @PlantID, @CurrentUserNTID;  
        THROW;  
    END CATCH  
END
GO





/****** Object:  StoredProcedure [grp10].[USP_AddEditUserProfileVSAS]    Script Date: 02.04.2025 07:10:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE grp10.[USP_AddEditUserProfileVSAS] (
	@PlantID INT
	,@UserProfileVSXML XML NULL
	,@UserProfileASXML XML NULL
	,@CurrentUserNTID NVARCHAR(20)
	,@customeIconID INT
	,@customeIconID1 INT
	)
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION TRNADDEDITUSERVSAS

		DECLARE @min INT = 0
			,@max INT = 0
		DECLARE @Scope_Identity_Table_VS TABLE (UserProfileValueStreamID INT);--Scope identities for all inserted rows  
		DECLARE @Scope_Identity_Table_AS TABLE (UserProfileAssessorID INT);--Scope identities for all inserted rows  

		SELECT Identity(INT, 1, 1) AS ID
			,ValueStreamConfig.value('(UserProfileValueStreamID/text())[1]', 'INT') AS UserProfileValueStreamID
			,ValueStreamConfig.value('(RowID/text())[1]', 'INT') AS RowID
			,ValueStreamConfig.value('(ValueStreamTemplateID/text())[1]', 'INT') AS ValueStreamTemplateID
			,ValueStreamConfig.value('(ValueStreamCategoryID/text())[1]', 'INT') AS ValueStreamCategoryID
			,ValueStreamConfig.value('(ValueStreamID/text())[1]', 'INT') AS ValueStreamID
			,ValueStreamConfig.value('(IsForgotValueStream/text())[1]', 'BIT') AS IsForgotValueStream
			,ValueStreamConfig.value('(SessionID/text())[1]', 'NVARCHAR(20)') AS SessionID
		INTO #T1
		FROM @UserProfileVSXML.nodes('/ArrayOfUserProfileValueStream/UserProfileValueStream') AS TEMPTABLE(ValueStreamConfig);

		--select * from #T1  
		SELECT Identity(INT, 1, 1) AS ID
			,AssessorConfig.value('(UserProfileAssessorID/text())[1]', 'INT') AS UserProfileAssessorID
			,AssessorConfig.value('(RowID/text())[1]', 'INT') AS RowID
			,AssessorConfig.value('(AssessorTemplateID/text())[1]', 'INT') AS AssessorTemplateID
			,AssessorConfig.value('(AssessorID/text())[1]', 'INT') AS AssessorID
			,AssessorConfig.value('(IsForgotAssessor/text())[1]', 'BIT') AS IsForgotAssessor
			,AssessorConfig.value('(SessionID/text())[1]', 'NVARCHAR(20)') AS SessionID
		INTO #T2
		FROM @UserProfileASXML.nodes('/ArrayOfUserProfileAssessor/UserProfileAssessor') AS TEMPTABLE(AssessorConfig);

		--select * from #T2  
		INSERT INTO @Scope_Identity_Table_VS
		SELECT UserProfileValueStreamID
		FROM T_TRN_ValueStreamConfig WITH (NOLOCK)
		WHERE UserProfileValueStreamID NOT IN (
				SELECT UserProfileValueStreamID
				FROM #T1 WITH (NOLOCK)
				WHERE (
						UserProfileValueStreamID IS NOT NULL
						AND UserProfileValueStreamID > 0
						)
				)
			AND PlantID = @PlantID
			AND User_NTID = @CurrentUserNTID

		--select * from @Scope_Identity_Table_VS  
		DELETE T_TRN_ValueStreamConfig
		WHERE UserProfileValueStreamID IN (
				SELECT UserProfileValueStreamID
				FROM @Scope_Identity_Table_VS
				)

		/*** New User Profile Table Data ***/
		/***Start***/
		UPDATE T_TRN_UserProfile
		SET ValueStreamTemplateID = NULL
			,ValueStreamTemplateName = NULL
			,ValueStreamID = NULL
			,ValueStreamName = NULL
		WHERE UserProfileValueStreamID IN (
				SELECT UserProfileValueStreamID
				FROM @Scope_Identity_Table_VS
				)
			AND user_NTID = @CurrentUserNTID
			AND PlantID = @PlantID

		/***End***/
		INSERT INTO T_TRN_ValueStreamConfig (
			ValueStreamTemplateID
			,ValueStreamCategoryID
			,ValueStreamID
			,RowID
			,IsForgotValueStream
			,SessionID
			,IsDeleted
			,CreatedAt
			,ModifiedAt
			,PlantID
			,User_NTID
			)
		OUTPUT inserted.UserProfileValueStreamID
		INTO @Scope_Identity_Table_VS
		SELECT ValueStreamTemplateID
			,ValueStreamCategoryID
			,ValueStreamID
			,RowID
			,IsForgotValueStream
			,SessionID
			,0
			,(
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				)
			,(
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				)
			,@PlantID
			,@CurrentUserNTID
		FROM #T1 WITH (NOLOCK)
		WHERE (
				UserProfileValueStreamID IS NULL
				OR UserProfileValueStreamID = 0
				)

		/*** New User Profile Table Data ***/
		/***Start***/
		INSERT INTO T_TRN_UserProfile (
			User_NTID
			,PlantID
			,UserProfileValueStreamID
			,ValueStreamTemplateID
			,ValueStreamTemplateName
			,ValueStreamID
			,ValueStreamName
			,UserProfileAssessorID
			,AssessorTemplateID
			,AssessorTemplateName
			,AssessorID
			,AssessorName
			,CustomIConID
			)
		SELECT @CurrentUserNTID
			,@PlantID
			,vsc.UserProfileValueStreamID
			,vsc.ValueStreamTemplateID
			,vst.ValueStreamTemplateName
			,vsc.ValueStreamID
			,vs.ValueStreamName
			,NULL
			,NULL
			,NULL
			,NULL
			,NULL
			,NULL
		FROM T_TRN_ValueStreamConfig vsc WITH (NOLOCK)
		INNER JOIN T_TRN_ValueStreamTemplate vst WITH (NOLOCK) ON vsc.ValueStreamTemplateID = vst.ValueStreamTemplateID
		INNER JOIN T_TRN_ValueStream vs WITH (NOLOCK) ON vsc.ValueStreamID = vs.ValueStreamID
		WHERE vsc.UserProfileValueStreamID NOT IN (
				SELECT DISTINCT UserProfileValueStreamID
				FROM T_TRN_UserProfile
				WHERE PlantID = @PlantID
					AND user_NTID = @CurrentUserNTID
					AND UserProfileValueStreamID IS NOT NULL
				)
			AND vsc.PlantID = @PlantID
			AND vsc.User_NTID = @CurrentUserNTID

	
		SET @min = (
				SELECT MIN(ID)
				FROM #T1
				);--Get minimum row number from temp table  
		SET @max = (
				SELECT Max(ID)
				FROM #T1
				);--Get maximum row number from temp table  

		WHILE (@min <= @max)
		BEGIN
			DECLARE @UserProfileValueStreamID INT
				,@RowID INT
				,@ValueStreamTemplateID INT
				,@ValueStreamCategoryID INT
				,@ValueStreamID INT
				,@IsForgotValueStream BIT
				,@SessionID NVARCHAR(20)

			--select * from #T1 WHERE ID = @min;  
			SELECT @UserProfileValueStreamID = UserProfileValueStreamID
				,@RowID = RowID
				,@ValueStreamTemplateID = ValueStreamTemplateID
				,@ValueStreamCategoryID = ValueStreamCategoryID
				,@ValueStreamID = ValueStreamID
				,@IsForgotValueStream = IsForgotValueStream
				,@SessionID = SessionID
			FROM #T1 WITH (NOLOCK)
			WHERE ID = @min;

			IF EXISTS (
					SELECT 1
					FROM T_TRN_ValueStreamConfig WITH (NOLOCK)
					WHERE UserProfileValueStreamID = @UserProfileValueStreamID
					)
			BEGIN
				-- Update the Assessor data if that exists  
				UPDATE T_TRN_ValueStreamConfig
				SET RowID = @RowID
					,ValueStreamTemplateID = @ValueStreamTemplateID
					,ValueStreamCategoryID = @ValueStreamCategoryID
					,ValueStreamID = @ValueStreamID
					,IsForgotValueStream = @IsForgotValueStream
					,SessionID = @SessionID
					,User_NTID = @CurrentUserNTID
					,PlantID = @PlantID
					,IsDeleted = 0
					,ModifiedAt = (
						SELECT FormattedDateTime
						FROM fnGetDateTime(@PlantID)
						)
				WHERE UserProfileValueStreamID = @UserProfileValueStreamID;
			END

			/*** New User Profile Table Data ***/
			/***Start***/
			IF EXISTS (
					SELECT 1
					FROM T_TRN_UserProfile WITH (NOLOCK)
					WHERE UserProfileValueStreamID = @UserProfileValueStreamID
						AND PlantID = @PlantID
						AND user_NTID = @CurrentUserNTID
					)
			BEGIN
				UPDATE u
				SET u.User_NTID = @CurrentUserNTID
					,u.PlantID = @PlantID
					,u.ValueStreamTemplateID = @ValueStreamTemplateID
					,u.ValueStreamTemplateName = vst.ValueStreamTemplateName
					,u.ValueStreamID = @ValueStreamID
					,u.ValueStreamName = vs.ValueStreamName
				FROM T_TRN_UserProfile u WITH (NOLOCK)
				INNER JOIN #T1 TEMP
				WITH (NOLOCK) ON u.UserProfileValueStreamID = TEMP.UserProfileValueStreamID
				INNER JOIN T_TRN_ValueStreamTemplate vst WITH (NOLOCK) ON TEMP.ValueStreamTemplateID = vst.ValueStreamTemplateID
				INNER JOIN T_TRN_ValueStream vs WITH (NOLOCK) ON TEMP.ValueStreamID = vs.ValueStreamID
				WHERE u.UserProfileValueStreamID = @UserProfileValueStreamID;
			END

			/***End***/
			SET @min = @min + 1;
				--select @min  
		END

		INSERT INTO @Scope_Identity_Table_AS
		SELECT UserProfileAssessorID
		FROM T_TRN_AssessorConfig WITH (NOLOCK)
		WHERE UserProfileAssessorID NOT IN (
				SELECT UserProfileAssessorID
				FROM #T2 WITH (NOLOCK)
				WHERE (
						UserProfileAssessorID IS NOT NULL
						AND UserProfileAssessorID > 0
						)
				)
			AND PlantID = @PlantID
			AND User_NTID = @CurrentUserNTID

		--select * from @Scope_Identity_Table_AS  
		DELETE T_TRN_AssessorConfig
		WHERE UserProfileAssessorID IN (
				SELECT UserProfileAssessorID
				FROM @Scope_Identity_Table_AS
				)

		/*** New User Profile Table Data ***/
		/***Start***/
		UPDATE T_TRN_UserProfile
		SET AssessorTemplateID = NULL
			,AssessorTemplateName = NULL
			,AssessorID = NULL
			,AssessorName = NULL
		WHERE UserProfileAssessorID IN (
				SELECT UserProfileAssessorID
				FROM @Scope_Identity_Table_AS
				)
			AND user_NTID = @CurrentUserNTID
			AND PlantID = @PlantID

		/***End***/
		INSERT INTO T_TRN_AssessorConfig (
			AssessorTemplateID
			,AssessorID
			,RowID
			,IsForgotAssessor
			,SessionID
			,IsDeleted
			,CreatedAt
			,ModifiedAt
			,PlantID
			,User_NTID
			)
		OUTPUT inserted.UserProfileAssessorID
		INTO @Scope_Identity_Table_VS
		SELECT AssessorTemplateID
			,AssessorID
			,RowID
			,IsForgotAssessor
			,SessionID
			,0
			,(
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				)
			,(
				SELECT FormattedDateTime
				FROM fnGetDateTime(@PlantID)
				)
			,@PlantID
			,@CurrentUserNTID
		FROM #T2 WITH (NOLOCK)
		WHERE (
				UserProfileAssessorID IS NULL
				OR UserProfileAssessorID = 0
				)

		/*** New User Profile Table Data ***/
		/***Start***/
		INSERT INTO T_TRN_UserProfile (
			User_NTID
			,PlantID
			,UserProfileValueStreamID
			,ValueStreamTemplateID
			,ValueStreamTemplateName
			,ValueStreamID
			,ValueStreamName
			,UserProfileAssessorID
			,AssessorTemplateID
			,AssessorTemplateName
			,AssessorID
			,AssessorName
			,CustomIConID
			)
		SELECT @CurrentUserNTID
			,@PlantID
			,NULL
			,NULL
			,NULL
			,NULL
			,NULL
			,a.UserProfileAssessorID
			,a.AssessorTemplateID
			,ast.AssessorTemplateName
			,a.AssessorID
			,ts.AssessorName
			,NULL
		FROM T_TRN_AssessorConfig a WITH (NOLOCK)
		INNER JOIN T_TRN_AssessorTemplate ast WITH (NOLOCK) ON a.AssessorTemplateID = ast.AssessorTemplateID
		INNER JOIN T_TRN_Assessor ts WITH (NOLOCK) ON a.AssessorID = ts.AssessorID
		WHERE a.UserProfileAssessorID NOT IN (
				SELECT DISTINCT UserProfileAssessorID
				FROM T_TRN_UserProfile
				WHERE PlantID = @PlantID
					AND user_NTID = @CurrentUserNTID
					AND UserProfileAssessorID IS NOT NULL
				)
			AND a.PlantID = @PlantID
			AND a.User_NTID = @CurrentUserNTID
	
		SET @min = (
				SELECT MIN(ID)
				FROM #T2
				);--Get minimum row number from temp table  
		SET @max = (
				SELECT Max(ID)
				FROM #T2
				);--Get maximum row number from temp table  

		WHILE (@min <= @max)
		BEGIN
			DECLARE @UserProfileAssessorID INT
				,@AS_RowID INT
				,@AssessorTemplateID INT
				,@AssessorID INT
				,@IsForgotAssessor BIT
				,@AS_SessionID NVARCHAR(20)

			--select * from #T2 WHERE ID = @min;  
			SELECT @UserProfileAssessorID = UserProfileAssessorID
				,@AS_RowID = RowID
				,@AssessorTemplateID = AssessorTemplateID
				,@AssessorID = AssessorID
				,@IsForgotAssessor = IsForgotAssessor
				,@AS_SessionID = SessionID
			FROM #T2 WITH (NOLOCK)
			WHERE ID = @min;

			IF EXISTS (
					SELECT 1
					FROM T_TRN_AssessorConfig WITH (NOLOCK)
					WHERE UserProfileAssessorID = @UserProfileAssessorID
					)
			BEGIN
				-- Update the Assessor data if that exists  
				UPDATE T_TRN_AssessorConfig
				SET RowID = @AS_RowID
					,AssessorTemplateID = @AssessorTemplateID
					,AssessorID = @AssessorID
					,IsForgotAssessor = @IsForgotAssessor
					,SessionID = @AS_SessionID
					,User_NTID = @CurrentUserNTID
					,PlantID = @PlantID
					,IsDeleted = 0
					,ModifiedAt = (
						SELECT FormattedDateTime
						FROM fnGetDateTime(@PlantID)
						)
				WHERE UserProfileAssessorID = @UserProfileAssessorID;
			END

			/*** New User Profile Table Data ***/
			/***Start***/
			IF EXISTS (
					SELECT 1
					FROM T_TRN_UserProfile WITH (NOLOCK)
					WHERE UserProfileAssessorID = @UserProfileAssessorID
						AND PlantID = @PlantID
						AND user_NTID = @CurrentUserNTID
					)
			BEGIN
				UPDATE u
				SET u.User_NTID = @CurrentUserNTID
					,u.PlantID = @PlantID
					,u.AssessorTemplateID = @AssessorTemplateID
					,u.AssessorTemplateName = ast.AssessorTemplateName
					,u.AssessorID = @AssessorID
					,u.AssessorName = a.AssessorName
				FROM T_TRN_UserProfile u WITH (NOLOCK)
				INNER JOIN #T2 temp2 WITH (NOLOCK) ON u.UserProfileAssessorID = temp2.UserProfileAssessorID
				INNER JOIN T_TRN_AssessorTemplate ast WITH (NOLOCK) ON temp2.AssessorTemplateID = ast.AssessorTemplateID
				INNER JOIN T_TRN_Assessor a WITH (NOLOCK) ON temp2.AssessorID = a.AssessorID
				WHERE u.UserProfileAssessorID = @UserProfileAssessorID;
			END

			/***End***/
			SET @min = @min + 1;
		END

		UPDATE T_MST_USER
		SET CustomIConID = @customeIconID
		WHERE PlantID = @PlantID
			AND NTID = @CurrentUserNTID

		/*** New User Profile Table Data ***/
		/***Start***/
		UPDATE T_TRN_UserProfile
		SET CustomIConID = @customeIconID
		WHERE PlantID = @PlantID
			AND user_NTID = @CurrentUserNTID

		/***End***/
		DELETE
		FROM T_TRN_CustomIcons
		WHERE PlantID = @PlantID
			AND ntid = @CurrentUserNTID

		IF @customeIconID = 0
		BEGIN
			INSERT INTO T_TRN_CustomIcons
			VALUES (
				@PlantID
				,@CurrentUserNTID
				,getdate()
				,@customeIconID
				)
		END

		IF @customeIconID > 0
		BEGIN
			INSERT INTO T_TRN_CustomIcons
			VALUES (
				@PlantID
				,@CurrentUserNTID
				,getdate()
				,@customeIconID
				)
		END

		IF @customeIconID1 > 0
		BEGIN
			INSERT INTO T_TRN_CustomIcons
			VALUES (
				@PlantID
				,@CurrentUserNTID
				,getdate()
				,@customeIconID1
				)
		END

		COMMIT TRANSACTION TRNADDEDITUSERVSAS;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION TRNADDEDITUSERVSAS;

		EXEC [USP_LogError] @PlantID
			,@CurrentUserNTID;
	END CATCH
END
GO